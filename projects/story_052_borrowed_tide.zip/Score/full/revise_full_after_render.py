import pathlib,json,copy
P=pathlib.Path(__file__).parent;old=json.loads((P/'revisions/score_full_v1.json').read_text());approved=json.loads((P.parent/'revisions/score_v2.json').read_text());v=copy.deepcopy(old);v['stage']='full_v2_approved_hook_and_earned_return';newbars=[]
for b in approved['bars'][:4]:
 x=copy.deepcopy(b);x.update(section='Clock waiting for the water',role_plan='intro');newbars.append(x)
for b in old['bars'][8:]:
 x=copy.deepcopy(b);x['bar']-=4;x['start']-=16;newbars.append(x)
v['bars']=newbars;v['events']=[copy.deepcopy(e) for e in approved['events'] if e['bar']<=4]
for e in old['events']:
 if e['bar']>8:
  x=copy.deepcopy(e);x['bar']-=4;x['onset']-=16;v['events'].append(x)
v['pedals']=[copy.deepcopy(e) for e in approved['pedals'] if e['onset']<16]
v['pedals'] += [dict(onset=e['onset']-16,value=e['value']) for e in old['pedals'] if e['onset']>=32]
v['total_beats']-=16;v['tail_seconds']=3.7
cad=[b for b in v['bars'] if b['role_plan']=='cadenza']
for j,b in enumerate(cad[-4:]):
 b['bpm']=[80,92,108,128][j]
 for e in v['events']:
  if e['bar']==b['bar']:
   e['velocity']+=j*(4 if e['voice'].startswith('melody') else 2)
(P/'revisions/score_full_v2.json').write_text(json.dumps(v,indent=2));(P/'score.json').write_text(json.dumps(v,indent=2));duration=sum(b['beats']*60/b['bpm'] for b in v['bars'])+v['tail_seconds'];baseline=json.loads((P/'revisions/052_full_v1.qa.json').read_text());log={'pass':2,'basis':'Actual full_v1 REAPER export, the user-approved52 direction score, and formal pacing review','changes':['Restore the exact approved4-bar opening rather than extend it to a low-register8-bar introduction. This keeps the recognized hook and coordinated left-hand support immediately present.','In the last4 bars of the quiet restitution section, grow phrase dynamics and move80→92→108→128BPM together so the144BPM return is earned rather than a disconnected loud jump.','Remove1.8seconds of excess tail allowance while retaining natural decay.','All new lyrical theme, cadenza, thematic combination and newly composed ending remain; the work is not a repeated direction excerpt.'],'baseline_peak_dbfs':baseline['peak_dbfs'],'baseline_last_sound_seconds':baseline['last_sound_seconds'],'duration_seconds':duration,'approved_intro_bars':4,'new_full_bar_count':len(v['bars']),'validation_pending':'Actual REAPER full_v2 export, PCM/phrase checks, and comparison of the opening against approved direction audio.'};(P/'revisions/full_pass2.json').write_text(json.dumps(log,indent=2));print('Final development score duration',duration)
