# Composition revisions: 076《空椅子的华尔兹》

All three preserved versions contain the whole 96-bar work. Revision order is intentional and deterministic. No audio was rendered or auditioned during these revisions; the reasons below are compositional judgments based on the written score, not listening claims.

## v0 — complete first composition

B-flat major exposition, a D-minor/G-minor middle, G-major trio, bridge, familiar return and eight-bar cadence were all present. The score established the empty chair’s circling bow and a complete tonal route. Its weaker points were a middle too regularly square for the stage mishaps, a trio too close to the opening’s arpeggiated manner, accompaniment that continued through some phrase endings, and a return that had not yet paid off the changed stage direction.

916 events. Estimated duration including tail: 175.368865 seconds. All held-hand and key-overlap audits pass.

## Revision 1 — v0 to v1: contrasting scene and genuinely new trio

Substantive changes:

1. Recompose bars 29–40. The old sequence of straight quarter-note arpeggios becomes late entrances, half-beat neighbours, held off-axis accents and explicit space. Melodic transformations at bars 29–30 and 33–34 make the two failed turns related but not identical. This is a change of thematic material and rhythm, not cosmetic velocity editing.
2. Recompose the 24-bar trio at bars 41–64 into a separate held-note/stepwise theme. The first and second periods have different ranges and continuations; the final eight bars prepare the tonal return.
3. Replace the trio’s repeated beat-two/beat-three left-hand chords with one gently held chord after a short bass note. The melody gains its own room without an independent bass tune.
4. Rearticulate the comic middle and use lighter pedal there. Coordinate phrase rests in the exposition, trio and later cadences by removing third-beat accompaniment attacks and releasing pedal earlier.

The exact before/after report contains 47 changed bars: 12, 20, 27–64, 68, 76, 84, 88, 92, 95 and 96. Some phrase-rest changes lie outside the re-composed sections. Source of truth: `revision_v0_to_v1_exact.json` and the unified diff.

815 events. Estimated duration including tail: 175.368865 seconds. The duration is unchanged because this revision changes content and phrasing rather than padding or cutting the timeline. All held-hand and key-overlap audits pass.

## Revision 2 — v1 to v2: moving the chair changes the actual form

Substantive changes:

1. Recompose bars 65–68. A real all-hand pause at bar 65 precedes a small semitone hinge and a more deliberate re-entry. Tempo is reshaped around the move.
2. Preserve bars 69–76 as the recognizable first eight bars of A. Recompose bars 77–88: the former D7/G-minor answer turns through E-flat and C minor, climbs to D6 at bar 81, breathes collectively at bar 84 and ends in a four-bar tonic answer. This twenty-bar return avoids a mechanical replay of the original twenty-four-bar exposition.
3. Replace the entire eight-bar coda (89–96). The delayed shared entrance, compressed bow, F9 color and definite B-flat ending correspond to the revised stage entrances and the teacher finally sitting still. Tempo relaxes locally toward the last chord rather than producing a general slow, mournful piece.
4. Add just five supportive right-hand chord tones at selected trio/return arrivals and a compact final left-hand B-flat chord. Right-hand reinforcement stays inside a seventh overall; the last left-hand chord is an octave.

The exact before/after report contains 26 changed bars: 53, 54, 65–68 and 77–96. Source of truth: `revision_v1_to_v2_exact.json` and the unified diff.

807 events. Estimated duration including tail: 176.503350 seconds. The roughly 1.13-second increase comes from the revised bridge and closing tempo map, not copied bars. Maximum held spans: left 12 semitones, right 7. Same-key overlaps: 0. Full/partial pedal downs: 36/60. Final pedal state: released.

## Exactness and reproducibility

The generator emits all three versions, two unified diffs and two full structured before/after diffs, and runs each version’s symbolic audit. `score.json` is byte-identical to `score_v2.json`. `python generate_score.py --verify` reconstructs the output set in memory and checks every generated file byte for byte. The stored result checks 12 files and reports no mismatches. No randomness or third-party Python package is involved.

This is a composition handoff. Native REAPER import, Moonlight rendering, listening and final audio delivery are intentionally not part of this folder.
