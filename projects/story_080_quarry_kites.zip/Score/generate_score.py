#!/usr/bin/env python3
"""Work 080: deterministic, standard-library-only symbolic score and audits.
Run from any directory. No media, sample loading, rendering, or network access.
"""
import difflib
import hashlib
import json
from collections import Counter, defaultdict
from copy import deepcopy
from pathlib import Path

OUT = Path(__file__).resolve().parent
N_BARS, BAR_BEATS, TAIL = 120, 2.5, 6
CH = {
    'D': (38, [62, 66, 69]), 'G': (43, [59, 62, 67]),
    'C': (36, [60, 64, 67]), 'Am': (45, [60, 64, 69]),
    'Em': (40, [59, 64, 67]), 'Dsus': (38, [62, 67, 69]),
    'Gm': (43, [58, 62, 67]), 'Bb': (46, [58, 62, 65]),
}
SECTIONS = [
    (1, 16, 'A', '把纸变成一只可用的风筝', 84),
    (17, 40, 'B', '第一条试风线', 88),
    (41, 56, 'C', '崖口的回流把线压低', 86),
    (57, 80, 'D', '改尾、换位置、再放线', 90),
    (81, 104, 'E', '几个人把风连成图', 88),
    (105, 120, 'F', '院子开门，线轴留下', 82),
]

# Four-bar sentences, with literal pitch choices. The first two sentences of B
# establish the eight-bar tune: D-A / G-E / F#-A / E; D-E / F#-G / E-C / D.
# Every list entry is a bar, not an audio/sample loop.
BASE = [
    ([[74, 81], [79, 76], [78, 81], [74]], ['D','G','D','D'], 'pp', 'piano', 'paper_measure'),
    ([[74, 81], [79, 76], [78, 81], [76]], ['D','G','D','Am'], 'pp', 'flute', 'first_fold'),
    ([[74, 76], [78, 79], [76, 72], [74]], ['D','G','C','D'], 'pp', 'flute', 'tail_and_knot'),
    ([[78, 81], [79, 78], [76, 72], [74]], ['D','G','C','D'], 'pp', 'flute', 'step_into_yard'),
    ([[74, 81], [79, 76], [78, 81], [76]], ['D','G','D','Am'], 'mf', 'flute', 'line_A_question'),
    ([[74, 76], [78, 79], [76, 72], [74]], ['D','G','C','D'], 'mf', 'flute', 'line_A_answer'),
    ([[83, 81], [79, 78], [76, 79], [81]], ['G','D','Em','D'], 'mf', 'flute', 'kite_reaches_rim'),
    ([[79, 76], [78, 74], [72, 76], [74]], ['C','D','C','D'], 'mf', 'flute', 'returning_tension'),
    ([[74, 78], [81, 79], [78, 76], [79]], ['D','G','D','G'], 'mf', 'flute', 'long_diagonal'),
    ([[81, 83], [79, 76], [78, 72], [74]], ['D','Em','C','D'], 'mf', 'flute', 'apparently_clear'),
    ([[81, 79], [78, 76], [79, 78], [76]], ['D','G','D','Am'], 'mf', 'flute', 'wind_trial_one'),
    ([[79, 81], [83, 79], [76, 72], [74]], ['G','Em','C','D'], 'mf', 'flute', 'wind_trial_two'),
    ([[74, 76], [78, 79], [76, 72], [74]], ['D','G','C','D'], 'pp', 'flute', 'pause_at_mark'),
    ([[76, 79], [78, 74], [72, 76], [74]], ['Em','D','C','D'], 'pp', 'flute', 'look_at_angle'),
    ([[74, 78], [81, 79], [76, 78], [81]], ['D','G','Am','D'], 'pp', 'flute', 'change_tail'),
    ([[81, 79], [78, 76], [74, 72], [74]], ['D','Em','C','D'], 'pp', 'flute', 'move_anchor'),
    ([[74, 79], [78, 76], [74, 78], [79]], ['Dsus','D','D','G'], 'pp', 'flute', 'short_test_call'),
    ([[79, 81], [83, 79], [78, 76], [74]], ['G','Em','Am','D'], 'pp', 'piano', 'measure_answer'),
    ([[74, 81], [79, 78], [76, 79], [81]], ['D','G','Em','D'], 'mf', 'flute', 'second_launch'),
    ([[83, 81], [79, 76], [78, 72], [74]], ['G','C','C','D'], 'mf', 'flute', 'safe_corridor'),
    ([[74, 81], [79, 76], [78, 81], [76]], ['D','G','D','Am'], 'mf', 'flute', 'lines_together_A'),
    ([[74, 76], [78, 79], [76, 72], [74]], ['D','G','C','D'], 'mf', 'flute', 'lines_together_B'),
    ([[83, 81], [79, 78], [76, 79], [81]], ['G','D','Em','D'], 'mf', 'flute', 'map_upper_edge'),
    ([[79, 76], [78, 74], [72, 76], [74]], ['C','D','C','D'], 'mf', 'flute', 'map_lower_edge'),
    ([[81, 83], [79, 81], [83, 79], [81]], ['D','G','Em','D'], 'mf', 'flute', 'all_three_kites'),
    ([[79, 78], [76, 79], [78, 72], [74]], ['G','C','C','D'], 'mf', 'flute', 'joint_cadence'),
    ([[74, 81], [79, 76], [78, 79], [76]], ['D','G','D','Am'], 'pp', 'flute', 'new_use_for_yard'),
    ([[74, 76], [78, 79], [76, 72], [74]], ['D','G','C','D'], 'pp', 'piano', 'spool_on_table'),
    ([[78, 81], [79, 76], [74, 72], [74]], ['D','C','C','D'], 'pp', 'flute', 'open_gate'),
    ([[79, 76], [78, 76], [72, 76], [74]], ['D','C','Am','D'], 'pp', 'flute', 'leave_a_measuring_line'),
]


def dump(name, obj):
    (OUT / name).write_text(json.dumps(obj, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


def plan(version):
    p = deepcopy(BASE)
    if version >= 1:
        # Revision 1: a genuine interruption, then a practical piano-led redesign.
        p[10] = ([[81,79],[78,76],[74,72],[74]], ['D','C','Gm','Gm'], 'mf','flute','down_draft')
        p[11] = ([[82,79],[76,74],[72,74],[74]], ['Bb','Gm','C','Gm'], 'pp','flute','line_below_mark')
        p[12] = ([[79],[76],[74,72],[74]], ['Gm','C','C','D'], 'pp','flute','stop_and_observe')
        p[13] = ([[74,76],[79,78],[76,72],[74]], ['D','G','C','D'], 'pp','flute','read_the_return_flow')
        p[14] = ([[74,78],[81,79],[76,78],[81]], ['D','G','Am','D'], 'pp','piano','cut_a_broader_tail')
        p[15] = ([[81,79],[78,76],[74,72],[74]], ['D','Em','C','D'], 'pp','piano','move_to_next_mark')
    if version >= 2:
        # Revision 2: real exchanges and a return whose contour encodes new knowledge.
        p[16] = ([[74],[79],[78,76],[79]], ['Dsus','G','D','G'], 'pp','flute','relaunch_listen')
        p[18] = ([[74,79],[78,81],[79,76],[81]], ['Dsus','D','Em','D'], 'mf','flute','shallower_climb')
        p[22] = ([[83],[79,78],[76],[81]], ['G','D','Em','D'], 'mf','exchange','call_across_marks')
        p[23] = ([[79,76],[78],[72,76],[74]], ['C','D','C','D'], 'mf','exchange_reverse','answers_make_a_map')
        p[24] = ([[81,83],[79,81],[83,79],[79]], ['D','G','Em','G'], 'mf','flute','three_separate_paths')
        p[25] = ([[78,81],[79,76],[72,76],[74]], ['D','G','C','D'], 'mf','flute','shared_G_C_D_cadence')
        p[29] = ([[79,74],[76,72],[79,76],[74]], ['G','C','G','D'], 'pp','flute','wind_map_left_at_gate')
    return p


def make_score(version):
    bars, events, pedals, cadences = [], [], [], []
    pp = plan(version)
    for b in range(1, N_BARS + 1):
        _, _, sec, sectitle, bpm = next(s for s in SECTIONS if s[0] <= b <= s[1])
        pi, local = (b-1)//4, (b-1)%4
        melody, harmony, layer, owner, label = pp[pi]
        owner = ('flute' if local in (0,2) else 'piano') if owner == 'exchange' else owner
        owner = ('piano' if local in (0,2) else 'flute') if owner == 'exchange_reverse' else owner
        chord = harmony[local]
        root, rh = CH[chord]
        grouping = '2+3' if version >= 1 and 41 <= b <= 48 else '3+2'
        start = round((b-1)*BAR_BEATS, 5)
        bar = dict(bar=b, start=start, beats=BAR_BEATS, bpm=bpm, meter='5/8',
                   meter_numerator=5, meter_denominator=8, section=sec,
                   section_title_zh=sectitle, harmony_name=chord,
                   harmony=[root,root+7]+rh, lead_instrument=owner,
                   grouping=grouping, role_plan=f'{owner} foreground; piano owns {grouping} pulse and one common harmony. {label}')
        bars.append(bar)
        counters = Counter()
        def add(inst, offset, dur, pitch, vel, voice, hand=None, role=None):
            counters[inst] += 1
            pid = f'P{pi+1:02d}_{inst}'
            e = dict(event_id=f'w80-b{b:03d}-{inst}-{counters[inst]:02d}', bar=b,
                     onset=round(start+offset,5), duration=round(dur,5), pitch=pitch,
                     velocity=vel, instrument=inst, voice=voice,
                     role=role or ('lead' if inst == owner else 'support'),
                     layer=layer if inst=='flute' else 'soft',
                     phrase_id=pid, phrase_label=label, onset_reference='ordinary_trigger',
                     target_on_beats=round(start+offset,5), target_off_beats=round(start+offset+dur,5))
            if inst == 'piano':
                e.update(hand=hand, articulation='light_detached' if dur < 1 else 'shared_cadence',
                         sample_layer='Moonlight', timing_intent='Ordinary piano trigger; a single harmonic pulse, not independent bass and treble melodies.')
            else:
                e.update(articulation='separately_tongued_sample', sample_layer=f'Iowa_flute_{layer}',
                         velocity_controls='recorded_layer_then_amplitude',
                         timing_intent='Ordinary sample trigger. No pre-shift, true legato, looping, or synthetic sustain. Owner compensates measured attack once after rendering.')
            events.append(e)
        # Sparse but mobile accompaniment: changing pitch is only chord unfolding.
        # At a cadence all hands and the flute agree on the same named harmony.
        quiet = layer == 'pp'
        vbase = 40 if quiet else 46
        if owner == 'piano':
            pitches = melody[local]
            a, z = pitches[0]-12, pitches[-1]-12
            # Five written attacks, with the cell's end note approached through chord tones.
            fig = [a, rh[0], rh[1], z, rh[2]]
            if local == 3:
                fig = [a]
            for j,n in enumerate(fig):
                add('piano', j*.5, 1.72 if local==3 else .39, n, 60+(j in (0,3))*4,
                    'foreground_melody', 'right', 'lead')
            add('piano',0,1.72 if local==3 else .73,root,vbase+2,'harmonic_root','left','support')
            if local != 3:
                add('piano',1.5,.72,root+7,vbase,'harmonic_fifth','left','support')
            elif all(abs(a-n)>0 for n in (rh[0],rh[1])):
                for n in rh[:2]:
                    add('piano',0,1.72,n,vbase,'cadence_inner','right','support')
        elif local == 3:
            for n in [root,root+7]:
                add('piano',0,1.70,n,vbase,'cadence_bass','left','support')
            for n in rh:
                add('piano',0,1.70,n,vbase+1,'cadence_chord','right','support')
            if b != N_BARS:
                add('piano',2.0,.32,rh[-1],vbase-4,'pulse_pickup','right','support')
        else:
            accent = 1 if grouping=='2+3' else 1.5
            add('piano',0,.73,root,vbase+2,'harmonic_root','left','support')
            add('piano',accent,.70,root+7,vbase,'harmonic_fifth','left','support')
            for j,n in enumerate([rh[0],rh[1],rh[2],rh[1]],1):
                t=j*.5
                add('piano',t,.34,n,vbase-2+(3 if abs(t-accent)<1e-6 else 0),'chord_pulse','right','support')
        if owner == 'flute':
            notes = melody[local]
            for j,n in enumerate(notes):
                offset = (0 if j==0 else (1 if grouping=='2+3' else 1.5))
                dur = (1.65 if len(notes)==1 else (.9 if grouping=='2+3' and j==0 else 1.3 if grouping=='2+3' else 1.15 if j==0 else .9))
                velocity = ((48 if j==0 else 46) if layer=='pp' else (68 if j==0 else 65))
                add('flute',offset,dur,n,velocity,'flute_melody',role='lead')
        # Lift before each new harmony; only the last chord takes full pedal.
        down = .06
        release = 1.78 if local==3 else 1.19 if grouping=='2+3' else 1.39
        if b == N_BARS:
            release = 2.36
        pedals.extend([
            dict(onset=round(start+down,5),value=76 if b==N_BARS else 42,instrument='piano',controller=64,bar=b,phrase_id=f'P{pi+1:02d}_piano',kind='full' if b==N_BARS else 'partial'),
            dict(onset=round(start+release,5),value=0,instrument='piano',controller=64,bar=b,phrase_id=f'P{pi+1:02d}_piano',kind='release'),
        ])
        if local == 3:
            cadences.append(dict(bar=b,harmony=chord,flute_pitch=melody[local][0] if owner=='flute' else None,
                                 piano_lead_pitch=melody[local][0]-12 if owner=='piano' else None,
                                 shared_root=root,shared_attack=start,structural=b in [16,40,56,80,104,120]))
    cumulative = [0.0]
    for b in bars:
        cumulative.append(cumulative[-1]+b['beats']*60/b['bpm'])
    def secs(t):
        if t >= N_BARS*BAR_BEATS:
            return cumulative[-1]+(t-N_BARS*BAR_BEATS)*60/bars[-1]['bpm']
        ix=int(t//BAR_BEATS)
        return cumulative[ix]+(t-ix*BAR_BEATS)*60/bars[ix]['bpm']
    for e in events:
        e['target_on_seconds']=round(secs(e['onset']),6)
        e['target_off_seconds']=round(secs(e['onset']+e['duration']),6)
    for p in pedals:
        p['target_on_seconds']=round(secs(p['onset']),6)
    events.sort(key=lambda e:(e['onset'], e['instrument'], e['pitch'], e['event_id']))
    grouped=defaultdict(list)
    for e in events:
        grouped[e['phrase_id']].append(e)
    phrases=[]
    for pid,ev in sorted(grouped.items()):
        instrument=ev[0]['instrument']
        end=max(e['target_off_seconds'] for e in ev)
        next_on=min((e['target_on_seconds'] for e in events if e['instrument']==instrument and e['phrase_id']!=pid and e['target_on_seconds']>max(x['target_on_seconds'] for x in ev)),default=None)
        phrases.append(dict(phrase_id=pid,instrument=instrument,phrase_label=ev[0]['phrase_label'],
                            first_bar=min(e['bar'] for e in ev),last_bar=max(e['bar'] for e in ev),
                            section=bars[ev[0]['bar']-1]['section'],layer=ev[0]['layer'],
                            role='foreground' if instrument=='flute' else 'pulse_and_assigned_answer',
                            layers_used=sorted(set(e['layer'] for e in ev)),roles_used=sorted(set(e['role'] for e in ev)),
                            voices_used=sorted(set(e['voice'] for e in ev)),
                            target_on_beats=min(e['onset'] for e in ev),target_off_beats=max(e['onset']+e['duration'] for e in ev),
                            target_on_seconds=min(e['target_on_seconds'] for e in ev),target_off_seconds=end,
                            breath_to_next_phrase_seconds=round(next_on-end,6) if next_on is not None else None,
                            timing_intent='Written ordinary triggers; interphrase rests are score rests, not a claim about sampled tails.'))
    return dict(id=80,title='Kites Above the Silent Quarry',title_zh='静采石场上空的风筝',version=f'v{version}',
                instrumentation=['piano','flute'],bars=bars,events=events,phrases=phrases,pedals=pedals,
                cadences=cadences,total_beats=N_BARS*BAR_BEATS,tail_seconds=TAIL,
                music_seconds=round(cumulative[-1],6),total_seconds_with_tail=round(cumulative[-1]+TAIL,6),
                performance_contract=dict(
                    audio_status='Symbolic draft only: no audio, render, sample download, installation, publication, or human listening.',
                    beat_unit='absolute quarter note; each 5/8 bar is 2.5 quarter beats',
                    key='D Mixolydian; v1/v2 borrow B-flat at the lee-wind failure before returning by C-G-D.',
                    piano_instrument='Approved Moonlight piano; integration belongs to owner.',
                    flute_instrument='Real Iowa C5-B5 pp/mf single-note samples, integrated by owner.',
                    flute_register=[72,83],flute_layers='pp velocities 44-50; mf 64-70; a phrase uses one real recorded layer.',
                    flute_nominal_gate_seconds=[0.6,1.6],flute_articulation='Separate ordinary triggers; no true legato, sample loops, artificial sustain, or pre-shift.',
                    flute_attack_latency_ms=[50,209],attack_compensation='None applied. Owner measures actual rendered attack and compensates once, then checks breathing and endings.',
                    piano_pedal='CC64, piano only; 0 off / 42 partial / 76 full. Explicit final clear.',
                    piano_hand_span_semitones=12,piano_same_key_overlap='Forbidden across both hands.',
                    balance='Flute owns foreground except the declared piano/exchange bars. Piano chord unfolding supplies the dance pulse; no competing bass melody.',
                    nominal_vs_sample='Gate, gap and range audits concern symbolic MIDI. Actual sample attack/release, balance and sustain validity remain owner integration checks.'))


def audit(s):
    ev=s['events']; flute=[e for e in ev if e['instrument']=='flute']; piano=[e for e in ev if e['instrument']=='piano']
    checks={}
    checks['exact_120_bars_5_8']=len(s['bars'])==120 and all(b['beats']==2.5 and b['meter_numerator']==5 and b['meter_denominator']==8 for b in s['bars'])
    checks['within_duration_target']=200<=s['total_seconds_with_tail']<=225
    gates=[e['target_off_seconds']-e['target_on_seconds'] for e in flute]
    checks['flute_C5_B5']=all(72<=e['pitch']<=83 for e in flute)
    checks['flute_gate_0_6_to_1_6_seconds']=all(.6-1e-5<=g<=1.6+1e-5 for g in gates)
    checks['real_velocity_layers']=all((44<=e['velocity']<=50 if e['layer']=='pp' else 64<=e['velocity']<=70 if e['layer']=='mf' else False) for e in flute)
    checks['one_layer_per_flute_phrase']=all(len(p['layers_used'])==1 for p in s['phrases'] if p['instrument']=='flute')
    checks['ordinary_triggers']=all(e['onset_reference']=='ordinary_trigger' for e in ev)
    checks['flute_monophonic']=all(a['onset']+a['duration']<=b['onset']+1e-8 for a,b in zip(flute,flute[1:]))
    checks['inside_bar_and_total']=all(e['onset']>=s['bars'][e['bar']-1]['start'] and e['onset']+e['duration']<=s['bars'][e['bar']-1]['start']+2.5+1e-8 for e in ev)
    overlaps=[]
    bykey=defaultdict(list)
    for e in piano: bykey[e['pitch']].append(e)
    for pitch,es in bykey.items():
        for a,b in zip(es,es[1:]):
            if a['onset']+a['duration']>b['onset']+1e-8: overlaps.append([pitch,a['event_id'],b['event_id']])
    checks['no_piano_same_key_gate_overlap']=not overlaps
    spans={'left':0,'right':0}; badspans=[]
    for hand in spans:
        es=[e for e in piano if e['hand']==hand]
        for t in sorted(set(e['onset'] for e in es)):
            sounding=[e['pitch'] for e in es if e['onset']<=t+1e-8 and e['onset']+e['duration']>t+1e-8]
            span=max(sounding)-min(sounding) if sounding else 0
            spans[hand]=max(spans[hand],span)
            if span>12: badspans.append([hand,t,span])
    checks['hand_span_le_12']=not badspans
    checks['piano_only_legal_pedals']=all(p['instrument']=='piano' and p['controller']==64 and p['value'] in [0,42,76] for p in s['pedals'])
    checks['final_clear']=s['pedals'][-1]['value']==0 and s['pedals'][-1]['onset']<=s['total_beats']
    cadence_results=[]
    for c in s['cadences']:
        pitches=[e['pitch'] for e in ev if e['bar']==c['bar'] and abs(e['onset']-c['shared_attack'])<1e-8]
        root,rh=CH[c['harmony']]
        pcs={p%12 for p in [root,root+7]+rh}
        okay=all(n%12 in pcs for n in pitches)
        cadence_results.append(dict(bar=c['bar'],harmony=c['harmony'],all_attacks_in_harmony=okay,pitches=pitches))
    checks['shared_harmonic_cadences']=all(c['all_attacks_in_harmony'] for c in cadence_results)
    roles=[]
    for b in s['bars']:
        bs=[e for e in ev if e['bar']==b['bar']]
        leads={e['instrument'] for e in bs if e['role']=='lead'}
        if leads!={b['lead_instrument']}: roles.append(dict(bar=b['bar'],leads=sorted(leads)))
    checks['one_foreground_per_bar']=not roles
    fp=[p for p in s['phrases'] if p['instrument']=='flute']
    breaths=[p['breath_to_next_phrase_seconds'] for p in fp if p['breath_to_next_phrase_seconds'] is not None]
    checks['phrase_breath_ge_0_5sec']=all(x>=.5-1e-5 for x in breaths)
    gaps=[b['target_on_seconds']-a['target_off_seconds'] for a,b in zip(flute,flute[1:])]
    assert all(checks.values()), checks
    return dict(version=s['version'],all_passed=all(checks.values()),checks=checks,
                event_counts=dict(Counter(e['instrument'] for e in ev)),
                flute_gate_seconds_min_max=[round(min(gates),6),round(max(gates),6)],
                flute_inter_note_gate_gap_seconds_min=round(min(gaps),6),
                flute_inter_phrase_breath_seconds_min=round(min(breaths),6),
                flute_pitch_range=[min(e['pitch'] for e in flute),max(e['pitch'] for e in flute)],
                hand_span_max_semitones=spans,same_key_overlap_violations=overlaps,
                hand_span_violations=badspans,foreground_violations=roles,
                cadence_results=cadence_results,
                music_seconds=s['music_seconds'],tail_seconds=TAIL,total_seconds_with_tail=s['total_seconds_with_tail'],
                limitations='No sound has been generated or heard. Same-key and handspan checks concern key-down gates, not pedal resonance or sample release. Actual audio latency, tails, balance and musical impression require owner review.')


def differences(a,b):
    keys=['bar','onset','duration','pitch','velocity','instrument','voice','hand','role','layer','phrase_label']
    aa={e['event_id']:e for e in a['events']}; bb={e['event_id']:e for e in b['events']}
    added=[bb[x] for x in sorted(bb.keys()-aa.keys())]
    removed=[aa[x] for x in sorted(aa.keys()-bb.keys())]
    changed=[]
    for eid in sorted(aa.keys()&bb.keys()):
        d={k:{'from':aa[eid].get(k),'to':bb[eid].get(k)} for k in keys if aa[eid].get(k)!=bb[eid].get(k)}
        if d: changed.append(dict(event_id=eid,changes=d))
    changed_bars=[dict(bar=x['bar'],from_bar=x,to_bar=y) for x,y in zip(a['bars'],b['bars']) if x!=y]
    substantive=sum(any(k in c['changes'] for k in ['onset','duration','pitch','instrument','role','voice']) for c in changed)+len(added)+len(removed)
    return dict(from_version=a['version'],to_version=b['version'],added_events=added,removed_events=removed,
                changed_events=changed,changed_bars=changed_bars,
                summary=dict(added=len(added),removed=len(removed),changed=len(changed),bars=len(changed_bars),substantive_event_changes=substantive))


def main():
    scores=[]; audits=[]
    for v in range(3):
        s=make_score(v); scores.append(s)
        a=audit(s); audits.append(a)
        dump(f'score_v{v}.json',s); dump(f'audit_v{v}.json',a)
    for i,j in [(0,1),(1,2)]:
        dump(f'diff_v{i}_v{j}.json', differences(scores[i],scores[j]))
        text=''.join(difflib.unified_diff((OUT/f'score_v{i}.json').read_text().splitlines(True),
                                        (OUT/f'score_v{j}.json').read_text().splitlines(True),
                                        fromfile=f'score_v{i}.json',tofile=f'score_v{j}.json'))
        (OUT/f'diff_v{i}_v{j}.patch').write_text(text,encoding='utf-8')
    dump('audit_summary.json',dict(all_versions_passed=all(a['all_passed'] for a in audits),versions=[dict(version=a['version'],checks=a['checks'],music_seconds=a['music_seconds'],total_seconds_with_tail=a['total_seconds_with_tail'],event_counts=a['event_counts']) for a in audits]))
    dump('delivery_manifest.json',dict(work_id=80,title='Kites Above the Silent Quarry',final_score='score_v2.json',
         status='complete symbolic score; owner sample/MIDI/REAPER integration pending',
         reproducible_command='python generate_score.py',dependencies='Python standard library only',
         audio_created=False,human_listening_claimed=False,downloads=False,installation=False,publication=False,
         total_seconds_with_tail=scores[-1]['total_seconds_with_tail'],sample_attack_pre_shift_applied=False))
    hashes={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(OUT.iterdir()) if p.is_file() and p.name!='sha256.json'}
    dump('sha256.json',hashes)
    print(json.dumps({'all_passed':True,'final_seconds_with_tail':scores[-1]['total_seconds_with_tail'],'v2_event_counts':audits[-1]['event_counts'],'flute_gate_seconds':audits[-1]['flute_gate_seconds_min_max'],'max_hand_span':audits[-1]['hand_span_max_semitones']},ensure_ascii=False))

if __name__=='__main__':
    main()
