#!/usr/bin/env python3
"""Work 69: deterministic original solo piano score; standard library only.
Writes three review stages and data/physical-playability audits. No rendering.
All event onsets/durations use quarter-note beats; MIDI middle C is C4=60.
"""
from pathlib import Path
import copy
import hashlib
import json
from fractions import Fraction

OUT = Path(__file__).resolve().parent
TITLE = 'Postcard from Tomorrow’s Harbor'
ZH = '来自明日港口的明信片'
PC = {'C':0,'D':2,'E':4,'F':5,'G':7,'A':9,'B':11}
def midi(s):
    letter=s[0]; rest=s[1:]; alter=0
    if rest and rest[0] in '#b':
        alter=1 if rest[0]=='#' else -1; rest=rest[1:]
    return (int(rest)+1)*12 + PC[letter]+alter

def note_line(s):
    out=[]
    for item in s.split():
        note, timing=item.split('@'); onset,duration=timing.split('/')
        out.append((float(Fraction(onset)),float(Fraction(duration)),midi(note)))
    return out

# Each line is a newly composed monophonic right-hand phrase, not an imported theme.
MELODY = {
1:'F#4@1/.5 A4@1.75/.75 B4@3/.5',
2:'A4@.5/.75 E4@1.5/1 G4@3/.5',
3:'F#4@0/.75 A4@1/.5 B4@1.75/1 A4@3/.5',
4:'G4@.5/.75 E4@1.5/1 C#4@3/.5',
5:'F#4@.5/.5 A4@1/.75 B4@1.75/1 A4@3/.5 F#4@3.5/.5',
6:'E4@0/.75 F#4@.75/.5 A4@1.5/.5 F#4@2/.75 D4@3/1',
7:'E4@.5/.5 G4@1/.75 B4@1.75/.75 A4@2.75/.5 F#4@3.5/.5',
8:'E4@0/.75 C#4@.75/.5 E4@1.5/1 F#4@2.75/.5 E4@3.5/.5',
9:'F#4@0/1 A4@1.5/.5 C#5@2/.75 B4@3/.5 A4@3.5/.5',
10:'B4@.5/.75 A4@1.5/.5 F#4@2/1 E4@3.5/.5',
11:'G4@0/.75 F#4@1/.5 E4@1.75/1 B4@3/.5 A4@3.5/.5',
12:'C#5@.5/.75 B4@1.5/.5 A4@2/.75 E4@3/.5',
13:'F#4@.5/.5 A4@1/.75 B4@1.75/.5 C#5@2.5/.75 A4@3.5/.5',
14:'A#4@0/.75 C#5@.75/.5 E5@1.5/1 C#5@2.75/.5 A#4@3.5/.5',
15:'B4@.5/1 F#4@1.75/.75 A4@2.75/.5 F#4@3.5/.5',
16:'D5@0/.75 C#5@1/.5 B4@1.75/1 A4@3/.75',
17:'B4@.5/.5 D5@1/.75 E5@1.75/1 D5@3/.5 B4@3.5/.5',
18:'Bb4@0/.75 A4@.75/.5 G4@1.5/1 E4@2.75/.5 G4@3.5/.5',
19:'F#4@0/1 A4@1.5/.75 B4@2.5/.5 A4@3.25/.5',
20:'G4@.5/.75 F#4@1.5/.5 E4@2/1.5',
21:'D5@0/1.5 B4@1.75/.75 A4@2.75/.5 B4@3.5/.5',
22:'C#5@0/1 E5@1.25/.75 D5@2.25/.75 C#5@3.25/.5',
23:'C#5@.5/1 A4@1.75/.75 F#4@2.75/1',
24:'A4@0/.75 F#4@1/.5 D#4@1.75/1 F#4@3/.75',
25:'G4@0/1.5 B4@1.75/.75 F#4@2.75/.5 E4@3.5/.5',
26:'F#4@.5/.75 G4@1.5/.5 B4@2/1 C#5@3.5/.5',
27:'E5@0/1.5 C#5@1.75/.75 A4@2.75/1',
28:'C5@0/.75 A4@1/.5 F#4@1.75/1 A4@3/.5 C5@3.5/.5',
29:'D5@.5/.75 B4@1.5/.5 A4@2/1 F#4@3.5/.5',
30:'G4@0/.75 Bb4@.75/.5 A4@1.5/1 G4@2.75/.5 E4@3.5/.5',
31:'F#4@0/.75 A4@1/.5 D5@1.75/1 E5@3/.5 D5@3.5/.5',
32:'C#5@.5/.75 B4@1.5/.5 G4@2/1.5',
33:'F#4@0/.75 B4@1/.5 C#5@1.75/1 D5@3/.75',
34:'C#5@.5/.75 A#4@1.5/.5 F#4@2/.75 E4@3.25/.5',
35:'F#4@0/.5 A4@.75/.5 B4@1.5/.75 D5@2.5/.75 C#5@3.5/.5',
36:'B4@0/.75 G#4@1/.5 F#4@1.75/1 E4@3/.75',
37:'B4@.5/.5 D5@1/.75 F#5@1.75/1 E5@3/.5 D5@3.5/.5',
38:'E5@0/.75 D5@1/.5 B4@1.75/.75 G4@2.75/.5 F#4@3.5/.5',
39:'E4@0/1 G4@1.5/.5 A4@2/1 B4@3.25/.5',
40:'C#5@.5/1 B4@1.75/.5 A4@2.5/.5 E4@3.25/.5',
41:'F#4@0/.75 A4@1/.5 B4@1.75/1 A4@3/.5 F#4@3.5/.5',
42:'E4@.5/.75 F#4@1.5/.5 A4@2/.75 F#4@3/.5 D4@3.5/.5',
43:'G4@0/.75 B4@1/.5 D5@1.75/1 B4@3/.5 G4@3.5/.5',
44:'F#4@.5/.75 E4@1.5/.5 C#4@2/.75 E4@3/.5',
45:'A4@0/.75 C#5@1/.5 E5@1.75/1 D5@3/.5 C#5@3.5/.5',
46:'B4@.5/.75 D5@1.5/.5 A4@2/1 F#4@3.5/.5',
47:'G4@0/.75 F#4@1/.5 E4@1.75/1 A4@3/.75',
48:'C#5@.5/.75 B4@1.5/.5 A4@2/1.25',
49:'F#4@.5/.5 A4@1/.75 B4@1.75/.5 E5@2.5/.75 C#5@3.5/.5',
50:'A#4@0/.75 C#5@.75/.5 E5@1.5/.75 F#5@2.5/.5 E5@3.25/.5',
51:'D5@.5/.75 C#5@1.5/.5 B4@2/1 F#4@3.5/.5',
52:'G#4@0/.75 B4@1/.5 D5@1.75/1 B4@3/.5 G#4@3.5/.5',
53:'B4@.5/.75 D5@1.5/.5 E5@2/1 D5@3.5/.5',
54:'Bb4@0/.75 A4@.75/.5 G4@1.5/.75 E4@2.5/.5 G4@3.25/.5',
55:'F#4@.5/.75 A4@1.5/.5 D5@2/.75 C#5@3/.5 B4@3.5/.5',
56:'A4@0/.75 G4@1/.5 E4@1.75/1 C#4@3/.5',
57:'F#4@.5/.5 A4@1/.75 B4@1.75/1 A4@3/.75',
58:'G4@0/.75 F#4@1/.5 E4@1.75/1 D4@3/1',
59:'F#4@.5/.75 A4@1.5/.5 C#5@2/1 B4@3.25/.5',
60:'G4@0/1 F#4@1.5/.5 E4@2/.75 B4@3.25/.5',
61:'A4@.5/.75 G4@1.5/.5 E4@2/1 D4@3.25/.5',
62:'C#4@0/.75 E4@1/.5 G4@1.75/.75 F#4@2.75/.5 E4@3.5/.5',
63:'F#4@0/1 A4@1.5/.75 E5@2.5/1',
64:'D5@0/3.75',
}

# root, answering bass, compact LH voicing, full harmonic collection.
HARM = {
'D6/9':('D3','A2','E3 F#3 B3','D3 F#3 A3 B3 E4'),
'A13sus':('A2','E3','D3 G3 B3','A2 D3 E3 G3 B3 F#4'),
'Gmaj9/D':('D3','G2','F#3 A3 B3','D3 G3 B3 F#4 A4'),
'A13':('A2','E3','C#3 F#3 G3','A2 C#3 E3 G3 B3 F#4'),
'Bm9':('B2','F#3','D3 F#3 C#4','B2 D3 F#3 A3 C#4'),
'Em9':('E3','B2','D3 F#3 G3','E3 G3 B3 D4 F#4'),
'Dmaj9/F#':('F#2','D3','E3 A3 C#4','F#2 D3 A3 C#4 E4'),
'Gmaj9':('G2','D3','F#3 A3 B3','G2 B2 D3 F#3 A3'),
'Em7/A':('A2','E3','D3 G3 B3','A2 E3 G3 B3 D4'),
'Dmaj9':('D3','A2','F#3 A3 C#4','D3 F#3 A3 C#4 E4'),
'F#7':('F#2','C#3','E3 A#3 C#4','F#2 A#2 C#3 E3'),
'Bm7/A':('A2','F#3','D3 F#3 B3','A2 B2 D3 F#3'),
'Gm6':('G2','D3','E3 G3 Bb3','G2 Bb2 D3 E3'),
'D6/9/F#':('F#2','A2','D3 F#3 B3','F#2 A2 B2 D3 E3'),
'A/G':('G2','E3','C#3 A3 B3','G2 A2 C#3 E3 B3'),
'F#m7':('F#2','C#3','E3 A3 C#4','F#2 A2 C#3 E3'),
'B7(b9)':('B2','F#3','D#3 A3 C4','B2 D#3 F#3 A3 C4'),
'D9':('D3','A2','E3 F#3 C4','D3 F#3 A3 C4 E4'),
'D/F#':('F#2','A2','D3 F#3 A3','F#2 A2 D3'),
'F#7/A#':('A#2','F#2','E3 F#3 C#4','A#2 F#3 C#4 E4'),
'E9/G#':('G#2','E3','D3 F#3 B3','G#2 E3 B3 D4 F#4'),
'Em9/A':('A2','E3','D3 G3 B3','A2 E3 G3 B3 D4 F#4'),
'D6add9':('D3','A2','E3 F#3 A3 B3','D3 F#3 A3 B3 E4'),
}
HARM={k:{'root':midi(v[0]),'answer':midi(v[1]),'voicing':[midi(x) for x in v[2].split()], 'collection':[midi(x) for x in v[3].split()]} for k,v in HARM.items()}
HARMONY = [
'D6/9','A13sus','Gmaj9/D','A13',
'D6/9','Bm9','Em9','A13','Dmaj9/F#','Gmaj9','Em7/A','A13',
'Dmaj9','F#7','Bm9','Bm7/A','Gmaj9','Gm6','D6/9/F#','A13sus',
'Gmaj9','A/G','F#m7','B7(b9)','Em9','A13','Dmaj9','D9',
'Gmaj9','Gm6','D/F#','A13',
'Bm9','F#7/A#','Bm7/A','E9/G#','Gmaj9','Em9','A13sus','A13',
'D6/9','Bm9','Em9','A13','Dmaj9/F#','Gmaj9','Em9/A','A13',
'Dmaj9','F#7','Bm9','E9/G#','Gmaj9','Gm6','D6/9/F#','A13',
'D6/9','Gmaj9/D','Bm9','Em9','Em7/A','A13','D6/9','D6add9']

SECTIONS = [(1,4,'序：潮汐邮戳'),(5,12,'A1：尚未建成的岸'),(13,20,'A2：窗边旧长椅'),(21,28,'B1：另一条水路'),(29,32,'B2：看见堵塞'),(33,40,'C：移动一张长椅'),(41,48,"A′1：为潮水留白"),(49,56,"A′2：人的等候"),(57,64,'尾声：港口明日')]
# Short note-offs articulate comping; starts stay on a straight sixteenth grid.
# B = root bass; Q = second bass; C = chord. No independent LH counter-theme.
PATTERNS = {
'i': [('B',0,.65),('C',1,.55),('C',2.75,.55)],
'j': [('B',0,.65),('C',.75,.5),('Q',2.5,.45)],
'a': [('B',0,.65),('C',.75,.42),('Q',2,.35),('C',2.5,.42),('C',3.5,.30)],
'b': [('B',0,.55),('C',1,.42),('C',1.75,.35),('Q',2.5,.35),('C',3,.55)],
'c': [('B',0,.65),('C',.75,.5),('Q',2,.4),('C',2.5,.75)],
'd': [('B',0,.7),('C',1,.8),('Q',2.5,.4),('C',3,.55)],
'e': [('B',0,.7),('C',1,.8),('Q',2.25,.4),('C',3,.6)],
'f': [('B',0,.6),('C',.75,.7),('Q',2.5,.35),('C',3.25,.5)],
'g': [('B',0,.7),('C',1,.65),('C',2.5,.5),('Q',3.25,.5)],
'h': [('B',0,.55),('C',.75,.4),('C',1.5,.3),('Q',2.25,.35),('C',2.75,.4),('C',3.5,.3)],
'k': [('B',0,.7),('C',1,.65),('C',2.75,.65)],
'l': [('B',0,.7),('C',1,.6)],
'm': [('B',0,3.75),('C',1,2.75)],
}
FINAL_PATTERN=list('ijij')+list('abcdabcc')+list('abacadcl')+list('efedefed')+list('efdl')+list('gfgfhgcl')+list('bcadbccl')+list('abcbcdcl')+list('ckckkklm')
assert len(FINAL_PATTERN)==64

# v0 is a complete first draft. The later versions replace actual composed material.
V0_MIDDLE={
33:'F#4@0/1 B4@1.5/.5 A4@2/1 F#4@3.5/.5',
34:'A#4@0/1 C#5@1.5/.5 A#4@2/1 F#4@3.5/.5',
35:'F#4@0/1 B4@1.5/.5 A4@2/1 F#4@3.5/.5',
36:'G#4@0/1 B4@1.5/.5 G#4@2/1 E4@3.5/.5',
37:'B4@0/1 D5@1.5/.5 B4@2/1 A4@3.5/.5',
38:'G4@0/1 B4@1.5/.5 G4@2/1 E4@3.5/.5',
39:'G4@0/1 A4@1.5/.5 G4@2/1 E4@3.5/.5',
40:'F#4@0/1 E4@1.5/.5 C#4@2/1 E4@3.5/.5',
}
V0_CODA={
57:'F#4@.5/.5 A4@1/.75 B4@1.75/1 A4@3/.5 F#4@3.5/.5',
58:'B4@.5/.75 A4@1.5/.5 F#4@2/1 E4@3.5/.5',
59:'D5@0/.75 C#5@1/.5 B4@1.75/1 A4@3/.75',
60:'E4@.5/.5 G4@1/.75 B4@1.75/.75 A4@2.75/.5 F#4@3.5/.5',
61:'G4@0/.75 F#4@1/.5 E4@1.75/1 B4@3/.5 A4@3.5/.5',
62:'C#5@.5/.75 B4@1.5/.5 A4@2/.75 E4@3/.5',
63:'F#4@0/1 A4@1.5/.5 B4@2/.75 A4@3/.75',
64:'F#4@0/1 E4@1.5/.5 D4@2/1.75',
}

def score(version):
    lines=copy.deepcopy(MELODY); hs=HARMONY[:]; pats=FINAL_PATTERN[:]
    if version==0:
        for n in range(29,33): lines[n]=MELODY[n-8]; hs[n-1]=HARMONY[n-9]
        lines.update(V0_MIDDLE)
        for n in range(49,57): lines[n]=MELODY[n-36]; hs[n-1]=HARMONY[n-37]
        for n in range(33,41): pats[n-1]='e' if n%2 else 'f'
    if version<2:
        for n in range(41,49): lines[n]=MELODY[n-36]; pats[n-1]=FINAL_PATTERN[n-37]
        lines.update(V0_CODA)
        for n in range(57,65): pats[n-1]='c' if n%2 else 'd'
    bars=[]; events=[]; pedals=[]
    for n in range(1,65):
        start=(n-1)*4.; h=HARM[hs[n-1]]; melody=note_line(lines[n])
        sec=next(name for a,b,name in SECTIONS if a<=n<=b)
        bpm=88 if n<=60 or version<2 else {61:88,62:86,63:84,64:76}[n]
        role=('右手单旋律，以和声内短支撑衬托长音；左手按本小节同一和声，用低音落点和错拍和弦回应句子。')
        if n in (12,20,32,40,48,56): role+='句末撤去后半拍／末拍的左手应答，给下一句留出入口。'
        if n>=57 and version==2: role='右手逐渐收拢主题尾部；左手减少落点，最后以一次根音和延后和弦托住长音。'
        bars.append(dict(bar=n,start=start,beats=4,bpm=bpm,section=sec,meter_numerator=4,meter_denominator=4,harmony_name=hs[n-1],harmony=h['collection'],role_plan=role,lead_instrument='piano'))
        section_level = (65 if n<=4 else 75 if n<=20 else 71 if n<=32 else 75 if n<=36 else 83 if n<=38 else 73 if n<=40 else 75 if n<=48 else 79 if n<=56 else 70 if n<=60 else 64)
        for i,(on,dur,p) in enumerate(melody):
            vel=section_level+([0,2,3,-1,-3,0][i%6])+(2 if n in (17,37,50) and p==max(z[2] for z in melody) else 0)
            events.append(dict(bar=n,onset=start+on,duration=dur,pitch=p,velocity=vel,voice='melody',instrument='piano'))
        # RH support is selected only at phrase-color/arrival bars, always attached to a lead note.
        support_bars=({3,9,12,17,20,21,25,27,29,31,33,37,39,43,45,48,49,50,53,55,57,59,61,63,64} if version==2 else {3,9,12,17,20,21,25,27,29,31,33,37,39,43,45,48,49,50,53,55,57,59,61,63,64})
        if n in support_bars:
            candidates=[(i,z) for i,z in enumerate(melody) if z[1]>=.75]
            if candidates:
                # Prefer the phrase's longest note. Early ties keep the support sparse.
                i,(on,dur,p)=max(candidates,key=lambda x:(x[1][1],-x[0]))
                pcs={x%12 for x in h['collection']}
                support=[q for q in range(max(62,p-10),p-2) if q%12 in pcs]
                if support:
                    q=min(support,key=lambda q:abs((p-q)-6))
                    events.append(dict(bar=n,onset=start+on,duration=max(.25,dur-.08),pitch=q,velocity=section_level-16,voice='upper_support',instrument='piano'))
        if n==64 and version==2:
            events.append(dict(bar=n,onset=start,duration=3.67,pitch=midi('F#4'),velocity=48,voice='upper_support',instrument='piano'))
        for kind,on,dur in PATTERNS[pats[n-1]]:
            if kind=='C':
                voicing=h['voicing'][:]
                # Keep a clean gap under any simultaneous lead; no key duplication with melody.
                overlaps=[p for mo,md,p in melody if mo<on+dur-1e-8 and mo+md>on+1e-8]
                if overlaps: voicing=[p for p in voicing if p<=min(overlaps)-3]
                if n<=4 or (version==2 and n>=61):
                    if len(voicing)>2: voicing=[voicing[0],voicing[-1]]
                for j,p in enumerate(voicing):
                    events.append(dict(bar=n,onset=start+on,duration=dur,pitch=p,velocity=section_level-23+(1 if j==len(voicing)-1 else -1),voice='accompaniment',instrument='piano'))
            else:
                p=h['root'] if kind=='B' else h['answer']
                events.append(dict(bar=n,onset=start+on,duration=dur,pitch=p,velocity=section_level-14-(3 if kind=='Q' else 0),voice='bass',instrument='piano'))
        # Partial pedal; guaranteed clear at every harmonic boundary. Deliberately dry middle.
        depth=24 if 33<=n<=40 else 31 if n<=56 else 27
        if n<=4: depth=25
        if n==64 and version==2:
            pedals += [dict(onset=start,value=0),dict(onset=start+.10,value=34),dict(onset=start+3.9,value=0)]
        else:
            pedals += [dict(onset=start,value=0),dict(onset=start+.10,value=depth),dict(onset=start+1.7,value=0),dict(onset=start+2.10,value=max(18,depth-4)),dict(onset=start+3.8,value=0)]
    events.sort(key=lambda e:(e['onset'], {'bass':0,'accompaniment':1,'upper_support':2,'melody':3}[e['voice']],e['pitch']))
    return dict(id=69,title=TITLE,title_zh=ZH,bars=bars,events=events,pedals=pedals,total_beats=256,tail_seconds=4)

def audit(s):
    ev=s['events']; violations=[]
    for e in ev:
        if not(21<=e['pitch']<=108 and 1<=e['velocity']<=127 and e['duration']>0): violations.append(['event_bounds',e])
        b=s['bars'][e['bar']-1]
        if not(b['start']<=e['onset']<b['start']+4 and e['onset']+e['duration']<=b['start']+4+1e-8): violations.append(['bar_bounds',e])
        if abs(e['onset']*4-round(e['onset']*4))>1e-8: violations.append(['not_straight_grid',e])
    collisions=[]; spans={'right':0,'left':0}; max_poly={'right':0,'left':0}; max_total=0
    times=sorted(set([e['onset'] for e in ev]+[e['onset']+e['duration'] for e in ev]))
    for t in times:
        active=[e for e in ev if e['onset']<=t+1e-8 and e['onset']+e['duration']>t+1e-8]
        max_total=max(max_total,len(active))
        seen={}
        for e in active:
            if e['pitch'] in seen: collisions.append(dict(time=t,pitch=e['pitch'],voices=[seen[e['pitch']]['voice'],e['voice']]))
            seen[e['pitch']]=e
        for hand,voices in [('right',{'melody','upper_support'}),('left',{'bass','accompaniment'})]:
            ps=[e['pitch'] for e in active if e['voice'] in voices]
            span=max(ps)-min(ps) if ps else 0
            spans[hand]=max(spans[hand],span); max_poly[hand]=max(max_poly[hand],len(ps))
            if span>12: violations.append(['hand_span',hand,t,span])
        lead=[e for e in active if e['voice']=='melody']
        if len(lead)>1: violations.append(['non_monophonic_lead',t])
    nonharm=[]
    for e in ev:
        if e['voice'] in {'bass','accompaniment','upper_support'}:
            pcs={p%12 for p in s['bars'][e['bar']-1]['harmony']}
            if e['pitch']%12 not in pcs: nonharm.append(e)
    melody=[e for e in ev if e['voice']=='melody']
    sync=[e for e in melody if abs(e['onset']-round(e['onset']))>1e-8 and int(e['onset'])+1<e['onset']+e['duration']-1e-8]
    pcdata={voice:[min(e['pitch'] for e in ev if e['voice']==voice),max(e['pitch'] for e in ev if e['voice']==voice)] for voice in ('melody','upper_support','bass','accompaniment')}
    harmonic_clears=all(any(p['onset']==b['start'] and p['value']==0 for p in s['pedals']) for b in s['bars'])
    pedal_ok=all(0<=p['value']<=63 for p in s['pedals']) and s['pedals'][-1]['value']==0
    onset_patterns={tuple(round(e['onset']-b['start'],3) for e in ev if e['bar']==b['bar'] and e['voice']=='bass') for b in s['bars']}
    exact_phrase_pairs=[]
    sig={n:tuple((e['onset']-(n-1)*4,e['duration'],e['pitch']) for e in melody if e['bar']==n) for n in range(1,65)}
    # Document intentional self-recurrence; no outside themes are consulted.
    for n in range(5,21):
        m=n+36
        if sig[n]==sig[m]: exact_phrase_pairs.append([n,m])
    duration=sum(b['beats']*60/b['bpm'] for b in s['bars'])
    return dict(event_count=len(ev),bars=len(s['bars']),quarter_beats=s['total_beats'],music_seconds=round(duration,6),with_tail_seconds=round(duration+s['tail_seconds'],6),pitch_ranges=pcdata,simultaneous_hand_span_semitones=spans,max_hand_polyphony=max_poly,max_total_polyphony=max_total,same_key_overlap_count=len(collisions),same_key_overlaps=collisions,nonharmonic_support_count=len(nonharm),nonharmonic_support_events=nonharm,straight_note_onset_grid='quarter-beat (straight sixteenth); no swing offset',syncopated_melody_notes_sustaining_across_next_quarter=len(sync),bass_onset_pattern_count=len(onset_patterns),literal_A_return_bar_pairs=exact_phrase_pairs,pedal_range=[min(p['value'] for p in s['pedals']),max(p['value'] for p in s['pedals'])],pedal_clear_at_every_bar=harmonic_clears,final_pedal_released=pedal_ok,violations=violations,pass_all=not violations and not collisions and not nonharm and harmonic_clears and pedal_ok,limitations='Symbolic checks only. No audio was rendered, heard, or judged. Pedal resonance and instrumental balance require a later listening review; these checks do not guarantee musical quality.')

def changes(a,b):
    melodic=[]; harmony=[]; lh=[]; tempo=[]
    for n in range(1,65):
        def sig(s,voices):
            return [(e['onset']-4*(n-1),e['duration'],e['pitch']) for e in s['events'] if e['bar']==n and e['voice'] in voices]
        if sig(a,{'melody'})!=sig(b,{'melody'}): melodic.append(n)
        if a['bars'][n-1]['harmony_name']!=b['bars'][n-1]['harmony_name']: harmony.append(n)
        if sig(a,{'bass','accompaniment'})!=sig(b,{'bass','accompaniment'}): lh.append(n)
        if a['bars'][n-1]['bpm']!=b['bars'][n-1]['bpm']: tempo.append(n)
    return dict(melody_recomposed_bars=melodic,harmony_changed_bars=harmony,left_hand_rewritten_bars=lh,tempo_changed_bars=tempo)

def main():
    scores=[score(v) for v in range(3)]
    audits={}
    for v,s in enumerate(scores):
        path=OUT/f'score_v{v}.json'
        path.write_text(json.dumps(s,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
        a=audit(s); a['sha256']=hashlib.sha256(path.read_bytes()).hexdigest(); audits[f'v{v}']=a
    audits['revision_1']=changes(scores[0],scores[1]); audits['revision_2']=changes(scores[1],scores[2])
    (OUT/'technical_audit.json').write_text(json.dumps(audits,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    assert all(audits[f'v{v}']['pass_all'] for v in range(3)), 'Audit failures; inspect technical_audit.json'
    for v in range(3):
        a=audits[f'v{v}']
        print(f"v{v}: {a['event_count']} events; {a['with_tail_seconds']:.3f}s with tail; RH/LH spans {a['simultaneous_hand_span_semitones']}; PASS")
    print('No renderer, audio engine, download, external package, or DAW was invoked.')

if __name__=='__main__': main()
