"""A composed melodic line divided between hands; later reassembled over a tonal lower line."""
from pathlib import Path
import json,sys
P=Path(__file__).resolve().parent;sys.path.insert(0,str(P));from composition_data import *
PARAM={'reflections':('六音倒影',100,54),'feet':('先看脚下',116,67),'tilt':('左右不是同一边',128,82),'count':('少数了一次',108,39),'pursuit':('倒影一起奔跑',136,93),'recognize':('把碎句连起来',120,74),'outside':('纸环碰到风',96,46)}
def write(p,x):p.write_text(json.dumps(x,ensure_ascii=False,separators=(',',':'))+'\n')
def pitch(s):return 12*(int(s[-1])+1)+{'C':0,'D':2,'E':4,'F':5,'G':7,'A':9,'B':11}[s[0]]+s[1:-1].count('#')-s[1:-1].count('b')
def build(level):
 rows=[]
 for sec,hs,ls in GROUPS:assert len(hs.split())==len(ls),(sec,len(hs.split()),len(ls));rows.extend((sec,h,l) for h,l in zip(hs.split(),ls))
 assert len(rows)==88
 events=[];bars=[];pedals=[]
 for n,(sec,h,line) in enumerate(rows,1):
  if level>=1:line=REV1.get(n,line)
  if level>=2:line=REV2.get(n,line)
  label,bpm,dyn=PARAM[sec];ch=H[h];start=(n-1)*4
  if n>=85:bpm-=3*(n-84)
  bars.append(dict(bar=n,start=start,beats=4,bpm=bpm,meter='4/4',meter_numerator=4,meter_denominator=4,section=sec,section_title_zh=label,harmony_name=h,harmony=ch,key_region='D whole-tone reflections; G minor footprint; G-major reassembly'))
  def add(p,t,d,v,voice,hand):
   assert 0<=t<t+d<=4.00001,(n,t,d)
   events.append(dict(bar=n,onset=round(start+t,6),duration=round(d,6),pitch=p,velocity=int(v),instrument='piano',voice=voice,hand=hand))
  divided=sec in ['reflections','count'] or (sec=='recognize' and level<2) or (sec=='tilt' and level>=1)
  at=0;mel=[];played=0;tokens=line.split()
  for i,tok in enumerate(tokens):
   name,u=tok.split(':');dur=float(u)/2
   if name!='R':
    p=pitch(name);hand='left' if divided and played%2 else 'right';p-=12 if hand=='left' else 0;v=dyn-(5 if hand=='left' else 0)+(3 if at in [0,2] and sec=='pursuit' else -4 if i==len(tokens)-1 else 0);mel.append(p);add(p,at,dur-.07,v,'interlocking_subject' if divided else 'assembled_subject',hand);played+=1
   at+=dur
  assert at==4,(n,line,at)
  if not divided:
   pat=[(0,ch[0],.6),(1.5,ch[2],.4),(3,ch[1],.5)]
   if sec=='tilt':pat=[(0,ch[0],.35),(1,ch[1],.3),(2,ch[2],.35),(3,ch[0]+12,.35)]
   if sec=='pursuit':pat=[(.5,ch[0],.3),(1.5,ch[2],.3),(2.5,ch[1],.3),(3.5,ch[0]+12,.3)]
   if sec=='recognize':pat=[(0,ch[0],.55),(2,ch[1],.55),(3,ch[2],.6)] if n%2 else [(0,ch[2],.5),(1.5,ch[1],.45),(3,ch[0],.6)]
   if sec=='outside':pat=[(0,ch[0],.75)] if n%2 else [(2,ch[1],.65)]
   if level>=2 and n>=84:pat=[(0,ch[0],.65),(2.5,ch[2],.7)] if n<88 else [(0,31,3.85)]
   for t,p,d in pat:
    while p>=min(mel):p-=12
    add(p,t,d,dyn-23,'tonal_lower_answer','left')
  pedals.append(dict(bar=n,onset=start,controller=64,value=0,instrument='piano'))
 events.sort(key=lambda e:(e['onset'],e['pitch']))
 for i,e in enumerate(events):e['event_id']=f'119-v{level}-{i}'
 return dict(id=119,title='No Sixth Person in the Mirror Hall',title_zh='镜厅没有第六个人',version=f'v{level}',bars=bars,events=events,pedals=pedals,total_beats=352,tail_seconds=5,instrument_map={'piano':'piano'},performance_contract='Original acoustic piano hocket-like hand transfer of one composed subject, followed by a tonal lower answer. Not claimed as strict two-subject counterpoint or a human performance.')
def proj(d,n):return {'bar':d['bars'][n-1],'events':[{k:v for k,v in e.items() if k!='event_id'} for e in d['events'] if e['bar']==n],'pedals':[e for e in d['pedals'] if e['bar']==n]}
for v in range(3):
 d=build(v);write(P/f'score_v{v}.json',d);report=dict(version=f'v{v}',bars=88,events=len(d['events']),duration_seconds=sum(b['beats']*60/b['bpm'] for b in d['bars'])+5,human_listening_review=False);write(P/f'audit_v{v}.json',report)
 if v:
  a=build(v-1);changes=[{'bar':n,'before':proj(a,n),'after':proj(d,n)} for n in range(1,89) if proj(a,n)!=proj(d,n)];write(P/f'exact_diff_v{v-1}_to_v{v}.json',{'count':len(changes),'changed_bars':[x['bar'] for x in changes],'comparison_excludes':['version','event_id'],'changes':changes});lines=[]
  for x in changes:
   lines.append(f"BAR {x['bar']}\n")
   for side in ['before','after']:
    q=x[side];lines.append(side+' '+q['bar']['harmony_name']+' '+str([(e['voice'],e['hand'],e['onset'],e['pitch'],e['duration'],e['velocity']) for e in q['events']])+'\n')
  (P/f'exact_diff_v{v-1}_to_v{v}.patch').write_text(''.join(lines))
write(P/'score.json',d);write(P/'ensemble_score.json',d);write(P/'piano_score.json',d);print(json.dumps(report))
