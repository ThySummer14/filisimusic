# 086 — A Caravan of Broken Compasses / 坏罗盘车队

Self-contained symbolic solo-piano composition. No audio was generated.

- Selected score: `score.json`, byte-identical to `score_v2.json`
- Source: `generate_score.py`, deterministic Python standard library only
- Story: `story_zh.txt`
- Musical form, story causality, performance intent, and limitations: `music_notes_zh.md`
- Revision narrative: `revision_notes.md`
- Retained full drafts: `score_v0.json`, `score_v1.json`, `score_v2.json`
- Per-version checks: `audit_v0.json`, `audit_v1.json`, `audit_v2.json`
- Exact note/bar/pedal changes: `exact_diff_v0_to_v1.json`, `exact_diff_v1_to_v2.json`
- Independent check: `verify_symbolic.py` and `independent_verification.json`
- SHA-256 manifest: `hash_manifest.json`

Regenerate only this draft folder:

```sh
python generate_score.py
python verify_symbolic.py
python generate_score.py
```

The final regeneration updates the hash manifest to include the independent verification file. It does not change the music. All starts, onsets, durations, `beats`, and `total_beats` are quarter-note beats. 9/8 means 4.5 beats per bar. Tempo is quarter notes per minute and may change once per bar. `tail_seconds` is wall-clock tail time. The score schema follows works 084 and 082.

Duration for v2: 190.698319 seconds of score plus 7 seconds of tail = 197.698319 seconds. A numerical audit is not a listening review; no sound-quality or listener-preference claim is made.

Only files inside this dedicated draft directory are authored. Existing collection works, manifest, rendering tools, live-owner files, and published galleries are untouched.
