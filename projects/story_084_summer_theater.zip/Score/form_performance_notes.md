# Snow at the Summer Theater / 夏日剧场的雪

Work 084. Original natural-piano ballet in F major, 144 bars of 3/8. The middle changes to D minor, then B-flat major. Every bar is 1.5 absolute quarter-note beats. The approved Moonlight piano is the sole intended instrument. This package contains symbolic source only: it does not load a sampler, download anything, generate audio, or publish the piece.

## Theme and continuity

The identifying entrance is A4–C5–Bb4 | G4–A4 | F4–G4–A4. Its first bar reaches up a third and withdraws; its second bar holds the first note for a quarter; its third walks back into the dance. Bars 1–8 complete the sentence with an ordinary, audible C7–F arrival. The following sixteen bars develop the upper reach and leave the curtain opening on C7.

The theme returns ornamented in bars 25–32, minor-colored as F4–A4–G4 | E4–F4 | D4–E4–F4 in bars 49–56, and transposed and lowered in bars 73–80. Bars 97–104 explore its upper register and quicker internal rhythm. Bars 113–120 begin its return and interrupt the expected tonic with D minor before reopening C7. The final scene restores the original register, shortens one of the returning sentences, then supplies a new eight-bar bow. There are eighteen distinct complete eight-bar melody/rhythm/harmony sentences in v2; thematic recurrence is deliberate, and whole scenes are not copied loops.

## Six scenes

1. Bars 1–24, 瓷碟里的十八位观众. F major. Three measured supports per bar establish feet on wood, with a right-hand melody and a moving phrase contour. The first sentence reaches F; the next two keep the stage moving and end on C7.
2. Bars 25–48, 前排正在变矮. F major with D-minor foreshadowing. Quarter-beat ornaments and a rising final sentence accompany the dancer lowering her gesture, turning around the chairs, and almost catching the skirt. The scene reaches C6 once; it earns that height through an ascent, then contracts before the minor scene.
3. Bars 49–72, 把追光撤下来. D minor. The same entrance loses its major third, and the question tightens. No long dead pause represents the wrong light cue: the pianist and dancer have to keep going while it is corrected. Bars 65–72 introduce D7–Gm–C7–F7–Bb, moving toward the new lower stage arrangement.
4. Bars 73–96, 舞台移到脚边. B-flat major. The theme passes to the left hand; the right hand supplies quiet, narrow upper chords and single tones. This reverses the roles while preserving the shared harmonic sentence. On the last note of bar 96 the right hand takes over the melody, freeing the left hand to return to the low register with ample released time.
5. Bars 97–120, 最后一粒雪的节目单. F major and D minor. Small bursts of sixteenth notes support the briefly launched full-size dance. The program is then crossed out: bars 105–112 fold the high line downward, and bars 113–120 return to the small theme early. The D-minor deceptive turn is the caught skirt and canceled circuit, not a new unrelated episode.
6. Bars 121–144, 落幕以前先鞠躬. F major. First a recognizable return, then a condensed three-bar head with a five-bar continuation, then the new bow. The F6 color at bar 137 is gentle openness; C7sus–C7 makes the final release audible. Bar 143 contains the melodic arrival F4, and bar 144 settles both hands on F major. The snow has disappeared before the curtain lands.

## Playing and realization

- Quarter-note tempo is written per bar, spanning 44–74 BPM with small internal phrase curves and a slower close. In 3/8 this is a light single-bar dance pulse with three audible eighths, not a broad three-quarter waltz. The last four bars slow deliberately to 54, 51, 48, and 44 BPM.
- Keep the melody foremost. Written support velocities normally sit substantially below the melody; the upper support in the left-hand melody scene must remain background. No artificial harmonics, other instruments, or tremolo effects are intended.
- Left-hand broken figures normally release each note after 0.31 quarter beats. The remaining 0.19 beat allows the wrist to move. Before the larger low-register returns, the last support shortens to 0.21 beat. Wide moves are released transfers rather than stretches held under a melody. The final left-hand F2–C3–F3 chord is exactly an octave.
- The short high gestures should remain balletic. Do not add large delays before every leap. Sixteenth-note groups are actual moving pitches, not repeated-note tremolos.
- CC64 uses only 0, 42, and 76. Each bar clears at its beginning, catches after 0.055 beat, and clears near its end. Value 42 keeps moving supports legible; 76 is reserved for the final eight bars. There is an explicit final release at beat 216 and a six-second tail.
- Dynamics and note lengths are deterministic. These are editable performance instructions, not claims that a listener has already approved an audio rendering.

## Files and reproduction

Run `python generate.py` from any directory. Python's standard library is sufficient. It writes full score_v0.json, score_v1.json, score_v2.json, the final score.json, per-version audit JSON, exact event-level revision diffs, and manifest.json. score.json and score_v2.json have identical contents and hashes. No random number generator, sample file, renderer, package install, or external service is used.

The source score follows the supplied structural schema, with absolute quarter-note onsets and durations, explicit piano and hand fields, full bar harmony, three-eighth meter, and piano leadership. Additional phrase and key-region fields make editorial review easier. Instrument/sample assignment and REAPER rendering belong to the owner of the larger collection.

## What the audit establishes

The audit checks every note against the score bounds; active key-held spans in each hand; all same-pitch overlaps across both hands; released time between wide hand moves; all eighteen phrase entrances and final melody pitches against the actual chord; every bar's melody downbeat and all accompaniment pitches against their actual chord; complete bar spacing; the allowed pedal values; and the explicit final release. Transfers above an octave require at least 0.12 seconds of complete release, transfers above seventeen semitones 0.18 seconds, and transfers above twenty-one semitones 0.22 seconds. It reports the largest interval during which neither hand holds a key, scene timestamps, and actual durations integrated over every bar tempo.

The hand-span calculation is based on held notes, not lingering damper resonance. Passing and neighboring tones inside phrases are allowed. A chord-tone test at the boundaries does not prove the expressive quality of an entire melody; that still warrants listening after the owner renders the approved instrument.
