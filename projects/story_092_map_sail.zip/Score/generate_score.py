#!/usr/bin/env python3
"""Work 092, wholly original symbolic piano/flute score. Standard library only.
No sound is rendered. Quarter-note beats are absolute; one 12/8 bar = six beats.
"""
import argparse
import difflib
import hashlib
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parent
PCS={'C':0,'D':2,'E':4,'F':5,'G':7,'A':9,'B':11}
def pitch(s):return 12*(int(s[-1])+1)+PCS[s[0]]+s[1:-1].count('#')-s[1:-1].count('b')
def line(text):
    out=[(None if t.split(':')[0]=='R' else pitch(t.split(':')[0]),float(t.split(':')[1])) for t in text.split()]
    assert sum(w for _,w in out)==6,text
    return out

# Authored sentences, including purposeful returns. A rising E-G-A-B pickup
# and the long fourth dotted-quarter are the hook; no borrowed melody or RNG.
MELODY=[
 'E4:.5 G4:.5 A4:.5 B4:1.5 A4:.5 G4:.5 E4:1 F#4:1',
 'A4:1.5 C#5:.5 B4:.5 A4:.5 F#4:1.5 E4:1.5',
 'G4:.5 B4:.5 D5:1 E5:1 D5:.5 B4:.5 G4:2',
 'F#4:1 A4:.5 F#4:.5 E4:1 D4:1 B3:2',
 'E4:.5 G4:.5 A4:.5 B4:1.5 A4:.5 G4:.5 E4:1 B4:1',
 'A4:1 C#5:.5 B4:.5 A4:1 F#4:.5 E4:.5 F#4:2',
 'G4:.5 B4:.5 D5:1 E5:1 D5:1 B4:1 G4:1',
 'F#4:.5 A4:.5 B4:1 D5:1 B4:1 A4:1 F#4:1',
 'E4:.5 G4:.5 A4:.5 B4:1.5 D5:1 B4:.5 A4:.5 G4:1',
 'A4:1.5 C#5:.5 B4:.5 A4:.5 E5:1.5 C#5:1.5',
 'B4:.5 D5:.5 E5:1 D5:.5 B4:.5 A4:1 F#4:2',
 'G4:1 B4:.5 A4:.5 G4:1 F#4:1 E4:2',
 'E4:.5 G4:.5 A4:1 B4:.5 A4:.5 G4:1 E4:1 F#4:1',
 'A4:1 C#5:.5 E5:.5 C#5:1 B4:1 A4:2',
 'B4:1 D5:.5 E5:.5 D5:1 B4:1 A4:1 F#4:1',
 'G4:.5 B4:.5 A4:1 G4:1 F#4:1 E4:2',
 'F#4:.5 A4:.5 B4:1 C#5:1 B4:.5 A4:.5 F#4:2',
 'G4:1 B4:.5 D5:.5 E5:1 D5:1 B4:2',
 'A4:.5 C#5:.5 D5:1 E5:1 D5:.5 C#5:.5 A4:2',
 'B4:1 A4:.5 F#4:.5 E4:1 F#4:1 A4:2',
 'G4:.5 B4:.5 C#5:1 E5:1 C#5:.5 B4:.5 G4:2',
 'A4:1 C#5:.5 B4:.5 A4:1 F#4:1 E4:2',
 'F#4:.5 A4:.5 B4:1 D5:1 B4:.5 A4:.5 F#4:2',
 'G4:1 B4:.5 A4:.5 G4:1 F#4:1 E4:2',
 'E4:.5 G4:.5 A4:.5 B4:1.5 D5:1 B4:1 A4:1',
 'C#5:1.5 E5:.5 D5:.5 C#5:.5 A4:1.5 G4:1.5',
 'B4:.5 D5:.5 E5:1 F#5:1 E5:.5 D5:.5 B4:2',
 'A4:1 C#5:.5 B4:.5 A4:1 F#4:1 E4:2',
 'G4:.5 B4:.5 D5:1 E5:1 D5:1 B4:1 G4:1',
 'A4:1 C#5:.5 E5:.5 C#5:1 B4:.5 A4:.5 E5:2',
 'B4:1 D5:.5 C#5:.5 A4:1 F#4:1 A4:2',
 'G4:1 B4:1 A4:.5 G4:.5 F#4:1 E4:2',
 # In bars 33–48 the piano retreats to harmonic threads under the flute.
 'E4:3 B4:3','F#4:3 A4:3','G4:3 B4:3','E4:3 A4:3',
 'F#4:3 A4:3','E4:3 G4:3','F#4:3 B4:3','E4:3 B4:3',
 'G4:3 B4:3','A4:3 C#5:3','F#4:3 A4:3','E4:3 G4:3',
 'E4:3 A4:3','F#4:3 A4:3','F#4:3 B4:3','E4:3 B4:3',
 'E4:1 G4:.5 A4:.5 B4:1 A4:1 G4:1 E4:1',
 'F#4:.5 A4:.5 C#5:1 B4:1 A4:.5 F#4:.5 E4:2',
 'G4:.5 B4:.5 D5:1 E5:1 D5:1 B4:2',
 'A4:1 C#5:.5 B4:.5 A4:1 F#4:1 E4:2',
 'E4:.5 G4:.5 A4:.5 B4:1.5 A4:.5 G4:.5 E4:2',
 'A4:1 C#5:.5 E5:.5 C#5:1 B4:1 A4:2',
 'B4:.5 D5:.5 E5:1 D5:1 B4:1 A4:1 F#4:1',
 'G4:1 B4:.5 A4:.5 G4:1 F#4:1 E4:2',
 'E4:.5 G4:.5 A4:.5 B4:1.5 D5:1 B4:.5 A4:.5 G4:1',
 'A4:1 C#5:.5 B4:.5 A4:1 E5:1 C#5:2',
 'B4:.5 D5:.5 E5:1 F#5:1 E5:.5 D5:.5 B4:2',
 'A4:1 C#5:.5 B4:.5 A4:1 F#4:1 E4:2',
 'G4:.5 B4:.5 D5:1 E5:1 D5:1 B4:1 G4:1',
 'A4:1 C#5:.5 E5:.5 C#5:1 B4:1 A4:2',
 'B4:.5 D5:.5 C#5:1 A4:1 F#4:1 A4:2',
 'G4:1 B4:.5 A4:.5 G4:1 F#4:1 E4:2',
 'B4:.5 D5:.5 E5:.5 F#5:1.5 E5:1 D5:1 B4:1',
 'C#5:1 E5:.5 F#5:.5 E5:1 C#5:1 A4:2',
 'D5:.5 F#5:.5 G5:1 F#5:1 E5:1 D5:2',
 'C#5:1 E5:.5 D5:.5 C#5:1 B4:1 A4:2',
 'B4:.5 D5:.5 E5:1 F#5:1 E5:.5 D5:.5 B4:2',
 'C#5:.5 E5:.5 F#5:1 G5:1 F#5:.5 E5:.5 C#5:2',
 'D5:.5 F#5:.5 A5:1 G5:1 F#5:1 D5:2',
 'D#5:1 F#5:.5 A5:.5 F#5:1 E5:1 D#5:2',
 'E5:.5 G5:.5 A5:.5 B5:1.5 A5:.5 G5:.5 E5:2',
 'F#5:.5 A5:.5 B5:1 C#6:1 B5:.5 A5:.5 F#5:2',
 'G5:.5 B5:.5 D6:1 E6:1 D6:.5 B5:.5 G5:2',
 'F#5:1 A5:.5 F#5:.5 E5:1 D#5:1 B4:2',
 'E5:1 B4:.5 A4:.5 G4:1 B4:1 G4:2',
 'A4:1 C#5:.5 B4:.5 A4:1 F#4:1 E4:2',
 'D#4:1 F#4:1 A4:.5 F#4:.5 E4:1 D#4:2',
 'E4:1 G4:1 B4:1 E4:3',
]

HARMONIES={
 'Em':[40,43,47],'Em/G':[43,47,52],'Em/B':[47,52,55],
 'Em(add9)':[40,43,47,54],'Em7':[40,43,47,50],
 'A':[45,49,52],'A/C#':[49,52,57],'A/E':[40,45,49],
 'D':[50,54,57],'D/F#':[42,45,50],'D/A':[45,50,54],
 'G':[43,47,50],'G/B':[47,50,55],'G/D':[50,55,59],
 'Bm':[47,50,54],'Bm/F#':[42,47,50],'F#m':[42,45,49],
 'F#m7':[42,45,49,52],'B7':[47,51,54,57],'B7/F#':[42,47,51],
 'B7sus4':[47,52,54,57],
}
# The ninth is voiced as a close upper inversion, not an unplayable stretch.
HARMONIES['Em(add9)']=[43,47,52,54]
HARM=[
 'Em','A/E','G','Bm/F#','Em','A','G/B','Bm',
 'Em/G','A','D','Em','Em','A/C#','Bm','Em',
 'F#m','G','A','Bm/F#','Em/G','A/E','Bm','Em',
 'Em','A/C#','G/B','A','G','A','Bm','Em',
 'Em','F#m','G','A/E','D/F#','Em/G','Bm','Em',
 'G','A','D/F#','Em','A/E','F#m','Bm','Em',
 'Em','F#m','G/B','A','Em','A/C#','Bm','Em',
 'Em/G','A','G/B','A/E','G','A/C#','Bm','Em',
 'Em/B','A/C#','G/D','A/C#','Em/B','F#m7','D','B7',
 'Em/G','A/C#','G/D','B7','Em','A','B7/F#','Em',
]

V1_MELODY={
17:'F#4:.5 A4:.5 B4:.5 C#5:1.5 B4:1 A4:.5 F#4:.5 A4:1',
18:'G4:1 B4:.5 D5:.5 E5:.5 D5:.5 B4:1 D5:2',
19:'A4:.5 C#5:.5 D5:.5 E5:1.5 D5:1 C#5:1 A4:1',
20:'B4:1 A4:.5 F#4:.5 E4:.5 F#4:.5 A4:1 F#4:2',
21:'G4:.5 B4:.5 C#5:.5 E5:1.5 C#5:1 B4:1 G4:1',
22:'A4:1 C#5:.5 B4:.5 A4:.5 F#4:.5 E4:1 F#4:2',
23:'F#4:.5 A4:.5 B4:.5 D5:1.5 B4:1 A4:1 F#4:1',
24:'G4:1 B4:.5 A4:.5 G4:.5 F#4:.5 E4:1 B4:2',
25:'E4:.5 G4:.5 A4:.5 B4:1.5 D5:1 B4:.5 A4:.5 G4:1',
26:'C#5:1 E5:.5 D5:.5 C#5:.5 A4:.5 G4:1 A4:2',
27:'B4:.5 D5:.5 E5:.5 F#5:1.5 E5:1 D5:1 B4:1',
28:'A4:1 C#5:.5 B4:.5 A4:.5 F#4:.5 E4:1 C#5:2',
29:'G4:.5 B4:.5 D5:.5 E5:1.5 D5:1 B4:1 G4:1',
30:'A4:.5 C#5:.5 E5:1 C#5:1 B4:.5 A4:.5 C#5:2',
31:'B4:1 D5:.5 C#5:.5 A4:.5 F#4:.5 A4:1 F#4:2',
32:'G4:1 B4:.5 A4:.5 G4:.5 F#4:.5 E4:1 R:2',
}
V1_HARM={18:'G/B',20:'Bm',21:'Em(add9)',22:'A',26:'A/E',28:'A/C#',30:'A/C#',35:'G/B',37:'D/A',41:'G/B',44:'Em/G'}
V2_MELODY={
57:'E4:.5 G4:.5 A4:.5 B4:1.5 D5:1 B4:1 A4:1',
58:'C#5:1 E5:.5 D5:.5 C#5:1 B4:1 A4:2',
59:'B4:.5 D5:.5 E5:.5 F#5:1.5 E5:1 D5:1 B4:1',
60:'A4:1 C#5:.5 B4:.5 A4:.5 F#4:.5 E4:1 A4:2',
61:'G4:.5 B4:.5 D5:.5 E5:1.5 D5:1 B4:.5 A4:.5 G4:1',
62:'A4:1 C#5:.5 E5:.5 F#5:1 E5:1 C#5:2',
63:'B4:.5 D5:.5 F#5:1 E5:1 D5:.5 B4:.5 A4:2',
64:'G4:1 B4:.5 A4:.5 G4:.5 F#4:.5 E4:1 B4:2',
65:'B4:.5 D5:.5 E5:.5 F#5:1.5 E5:1 D5:.5 B4:.5 E5:1',
66:'C#5:.5 E5:.5 F#5:1 E5:.5 C#5:.5 A4:1 C#5:2',
67:'D5:.5 F#5:.5 G5:.5 A5:1.5 G5:1 F#5:1 D5:1',
68:'C#5:1 E5:.5 F#5:.5 E5:.5 C#5:.5 B4:1 C#5:2',
69:'B4:.5 D5:.5 E5:.5 F#5:1.5 E5:.5 D5:.5 B4:1 E5:1',
70:'C#5:.5 E5:.5 F#5:.5 G5:1.5 F#5:1 E5:.5 C#5:.5 F#5:1',
71:'D5:.5 F#5:.5 A5:1 B5:1 A5:.5 F#5:.5 D5:2',
72:'D#5:1 F#5:.5 A5:.5 B5:1 A5:.5 F#5:.5 D#5:2',
73:'E5:.5 G5:.5 A5:.5 B5:1.5 A5:1 G5:.5 E5:.5 B5:1',
74:'F#5:.5 A5:.5 B5:.5 C#6:1.5 B5:1 A5:1 F#5:1',
75:'G5:.5 B5:.5 D6:.5 E6:1.5 D6:1 B5:1 G5:1',
76:'F#5:1 A5:.5 F#5:.5 E5:.5 D#5:.5 B4:1 D#5:2',
77:'E5:1 B4:.5 A4:.5 G4:1 B4:1 G4:2',
78:'A4:1 C#5:.5 B4:.5 A4:.5 F#4:.5 E4:1 F#4:2',
79:'D#4:.5 F#4:.5 A4:1 F#4:1 E4:1 D#4:2',
80:'E4:.5 G4:.5 B4:1 G4:1 E4:3',
}
V2_HARM={57:'Em(add9)',59:'G/D',61:'Em/G',62:'A/C#',63:'B7sus4',64:'Em',67:'D',69:'Em/B',70:'F#m7',71:'D/A',72:'B7',73:'Em/G',74:'A/C#',75:'G/D',76:'B7',77:'Em/G'}

SECTIONS=[(1,4,'Intro','把折痕压平','E Dorian'),(5,16,'A','帆形第一次铺开','E Dorian'),
 (17,24,'B','不够长的补强带','E Dorian / A major'),(25,32,'A2','从旧航线旁裁开','E Dorian'),
 (33,40,'C','把出港改成近岸试帆','D major / E Dorian'),(41,48,'C2','在背风处重画孔位','D major / E Dorian'),
 (49,56,'Build','一人压布一人收线','E Dorian'),(57,64,'Return','让同一条缝多走半寸','E Dorian'),
 (65,72,'Climb','沿短绳试着升起','E Dorian to B dominant'),(73,76,'Peak','帆角离开帆布台','E Dorian with raised leading tone'),
 (77,80,'Coda','给新孔打一个记号','E minor tonic')]
LABELS=['玻璃瓶压住地图角','针脚绕过旧航线','帆顶在门口亮起来','铅笔沿着帆底返回','补强带只够一边','拆下旧袋的提手','裁口停在红线旁','把长航程从表上划掉','风沿背墙变小','新位置多留一个指宽','把旧孔留在图外','把短绳穿回滑轮','两人换了站位','针的方向重新一致','缝份再留半寸','先拉近岸那根绳','第一段受力','第二段缓慢展开','布角抬过木台','蓝铅笔停在新孔旁']

# Two unlooped notes per flute bar, with scored release/breath intervals.
FLUTE_C=[('B5','A5'),('A5','F#5'),('G5','B5'),('A5','E5'),('F#5','A5'),('G5','E5'),('F#5','D5'),('E5','G5'),
 ('B5','G5'),('A5','C#5'),('F#5','A5'),('G5','E5'),('A5','E5'),('F#5','C#5'),('D5','F#5'),('E5','B5')]
V1_FLUTE={33:('B5','G5'),34:('A5','F#5'),35:('G5','D5'),36:('E5','A5'),37:('A5','F#5'),38:('G5','B5'),39:('F#5','D5'),40:('E5','G5'),41:('B5','D5'),42:('C#5','E5'),43:('F#5','A5'),44:('B5','G5'),45:('A5','C#5'),46:('F#5','E5'),47:('D5','F#5'),48:('E5','G5')}
ANSWER={8:('D5','F#5'),16:('G5','E5'),24:('G5','E5'),32:('B5','G5'),52:('C#5','E5'),56:('G5','E5'),60:('C#5','E5'),64:('B5','G5')}

def dumps(x):return json.dumps(x,ensure_ascii=False,indent=2)+'\n'
def save(root,name,x):(root/name).write_text(dumps(x),encoding='utf-8')
def sec(bars,t):return sum(min(max(t-b['start'],0),b['beats'])*60/b['bpm'] for b in bars)
def fingermap(keys,hand):
    fs={1:[3],2:[1,5],3:[1,3,5],4:[1,2,4,5],5:[1,2,3,4,5]}[len(keys)]
    if len(keys)==4:
        gaps=[b-a for a,b in zip(keys,keys[1:])]
        widest=max(range(3),key=lambda i:gaps[i])
        fs=([1,3,4,5],[1,2,4,5],[1,2,3,5])[widest]
        if hand=='left':return dict(zip(keys,([5,3,2,1],[5,4,2,1],[5,4,3,1])[widest]))
    return dict(zip(keys,fs if hand=='right' else fs[::-1]))
def tempo(n):
    if n<=4:return [144,146,148,144][n-1]
    if n<=16:return [148,150,150,146][(n-1)%4]
    if n<=32:return [152,154,152,148][(n-1)%4]
    if n<=40:return [110,112,112,108][(n-1)%4]
    if n<=48:return [114,116,116,112][(n-1)%4]
    if n<=56:return [140,142,144,140,146,148,148,144][n-49]
    if n<=64:return [150,152,154,150][(n-1)%4]
    if n<=76:return [154,156,156,150][(n-1)%4]
    return {77:148,78:144,79:138,80:128}[n]

def compose(version):
    ms=list(MELODY);hs=list(HARM)
    assert len(ms)==len(hs)==80
    for stage in range(1,version+1):
        for n,m in (V1_MELODY if stage==1 else V2_MELODY).items():ms[n-1]=m
        for n,h in (V1_HARM if stage==1 else V2_HARM).items():hs[n-1]=h
    bars=[];events=[];plans=[];pedals=[];breaths=[]
    for n in range(1,81):
        start=float((n-1)*6);scene=next(s for s in SECTIONS if s[0]<=n<=s[1]);chord=HARMONIES[hs[n-1]]
        quiet=33<=n<=48;answer=n in ANSWER;phrase=f'P{(n-1)//4+1:02d}';bpm=tempo(n)
        mode='flute_foreground' if quiet else 'piano_then_flute' if answer else 'piano_foreground'
        bar={'bar':n,'start':start,'beats':6.0,'bpm':bpm,'meter':'12/8','meter_numerator':12,'meter_denominator':8,
          'section':scene[2],'section_title_zh':scene[3],'key_region':scene[4],'harmony_name':hs[n-1],'harmony':chord,
          'lead_instrument':'flute' if quiet else 'piano','lead_hand':'not_applicable' if quiet else 'right',
          'phrase_id':phrase,'phrase_position':(n-1)%4+1,'macro_phrase_id':phrase,'macro_phrase_length_bars':4,
          'metrical_grouping':'3+3+3+3 eighth notes','texture':mode,
          'role_plan':'Flute sings; both piano hands supply spare shared chord arrivals.' if quiet else 'Piano finishes at beat 2.1, flute answers after beat 2.3, LH maintains the same harmony.' if answer else 'One piano melody, with a lower-register left-hand compound-meter pulse.'}
        bars.append(bar)
        melody=line(ms[n-1])
        if answer:
            # A deliberate half-bar handoff, not a second foreground laid over
            # a complete piano line. The motive's pitches remain in this grip.
            nonrest=[p for p,w in melody if p is not None]
            melody=[(nonrest[0],.5),(nonrest[1],.5),(nonrest[2],1.1),(None,3.9)]
        rightkeys=sorted({p for p,w in melody if p is not None})
        # Quiet piano threads are two connected chord tones with separate
        # physical releases. No countermelody or unrelated bright ping notes.
        if quiet:
            rightkeys=sorted({chord[0]+24,chord[-1]+12})
            while rightkeys[-1]>=72:rightkeys=[p-12 for p in rightkeys]
            rightkeys=sorted(set(rightkeys))
            melody=[(rightkeys[0],3.0),(rightkeys[-1],3.0)]
        keys={'left':list(chord),'right':rightkeys};maps={h:fingermap(ks,h) for h,ks in keys.items()}
        for h,ks in keys.items():
            assert len(ks)<=5 and max(ks)-min(ks)<=12,(version,n,h,ks)
            plans.append({'bar':n,'hand':h,'position_id':f'{h[0].upper()}-b{n:02d}','range':[min(ks),max(ks)],
              'pitch_finger_map':{str(p):maps[h][p] for p in ks},'active':True,
              'within_position_method':'Fixed uncrossed, ordered fingers span this close grip; broken-chord motion uses different fingers without whole-hand translation.',
              'next_position_method':'Release all physical keys before next bar position. Pedal does not extend physical holds.'})
        dyn=76 if n<=4 else 86 if n<=16 else 89 if n<=32 else 41 if quiet else 77 if n<=52 else 86 if n<=56 else 93 if n<=64 else 98 if n<=72 else 104 if n<=76 else 83
        if n>=77:dyn={77:86,78:80,79:76,80:72}[n]
        def add(hand,voice,offset,duration,p,vel,written,role,art):
            events.append({'event_id':f'w92-b{n:02d}-{voice}-{sum(e["bar"]==n and e["voice"]==voice for e in events)+1:02d}',
              'bar':n,'onset':round(start+offset,6),'duration':round(duration,6),'pitch':p,'velocity':vel,
              'instrument':'piano','voice':voice,'hand':hand,'role':role,'layer':'not_applicable','sample_layer':'not_applicable',
              'phrase_id':phrase+'_piano','phrase_label':LABELS[(n-1)//4],'harmony_name':hs[n-1],
              'harmonic_function':'chord_tone' if p%12 in {q%12 for q in chord} else 'melodic_nonchord_tone',
              'written_value_beats':written,'articulation':art,'onset_reference':'ordinary_trigger',
              'hand_position_id':f'{hand[0].upper()}-b{n:02d}','hand_position_range':[min(keys[hand]),max(keys[hand])],
              'position_keys':keys[hand],'finger':maps[hand][p],
              'fingering_intent':'One assigned pitch per ordered finger inside this position; no hidden substitution or pedal-as-key-hold.'})
        offset=0
        for i,(p,w) in enumerate(melody):
            if p is not None:
                last=(i==len(melody)-1);release=.68 if last else .045
                if n==80 and last:release=0
                if answer:release=.10 if i==2 else .04
                gate=w-release
                add('right','piano_thread' if quiet else 'melody',offset,gate,p,dyn+[0,3,1,4,0,-2,-1,-3][i%8],w,
                  'support' if quiet else 'lead','quiet_harmonic_thread' if quiet else 'driven_connected_phrase')
            offset+=w
        # Four dotted-quarter impulses, filled asymmetrically to preserve
        # phrase direction. All arpeggio keys have fixed explicit fingers.
        low=chord[0];mid=chord[1];high=chord[-1]
        if quiet:
            pattern=[(0,2.32,[low,high]),(3,2.30,[mid,high])]
        elif n==80:
            pattern=[(0,6.0,chord)]
        elif n<=4:
            pattern=[(0,.9,[low]),(1.5,.7,[mid,high]),(3,.9,[low]),(4.5,.72,[mid,high])]
        else:
            shape=(n-1)%4
            if shape==0:pattern=[(0,.42,[low]),(.5,.40,[mid]),(1,.36,[high]),(1.5,.62,[mid,high]),(2.5,.36,[mid]),(3,.42,[low]),(3.5,.38,[mid]),(4,.36,[high]),(4.5,.48,[mid,high]),(5.1,.24,[mid])]
            elif shape==1:pattern=[(0,.60,[low]),(1,.36,[high]),(1.5,.42,[mid]),(2,.38,[high]),(2.5,.32,[mid]),(3,.60,[low]),(4,.36,[high]),(4.5,.64,[mid,high])]
            elif shape==2:pattern=[(0,.42,[low]),(.5,.36,[mid]),(1,.36,[high]),(1.5,.62,[mid,high]),(2.5,.32,[mid]),(3,.40,[low]),(3.5,.34,[mid]),(4,.34,[high]),(4.5,.42,[mid,high]),(5,.30,[mid])]
            else:pattern=[(0,.64,[low]),(1,.36,[mid]),(1.5,.66,[mid,high]),(3,.60,[low]),(4,.36,[mid]),(4.5,.82,[mid,high])]
            if version>=1 and 17<=n<=32 and n%2==1:
                # A real rhythmic revision: the second half-bar now points at
                # the next downbeat with two short chord impulses.
                pattern=[x for x in pattern if x[0]<3]+[(3,.58,[low,mid]),(4,.34,[high]),(4.5,.36,[mid]),(5,.30,[high])]
            if version>=2 and 57<=n<=76 and n%2==1:
                pattern=[(0,.60,[low,mid]),(1,.36,[high]),(1.5,.60,[mid,high]),(2.5,.34,[mid]),(3,.60,[low,mid]),(4,.34,[high]),(4.5,.60,[mid,high])]
        supportvel=31 if quiet else dyn-27
        for i,(off,gate,ps) in enumerate(pattern):
            for p in ps:add('left','harmonic_pulse',off,gate,p,supportvel+(3 if off in (0,3) else 0),max(gate,.5),'support','quiet_shared_arrival' if quiet else 'compound_meter_broken_chord')
        if quiet or answer:
            fl=V1_FLUTE[n] if quiet and version>=1 else FLUTE_C[n-33] if quiet else ANSWER[n]
            if version>=2 and n==60:fl=('E5','C#5')
            if version>=2 and n==64:fl=('G5','B5')
            offsets=[.24,3.25] if quiet else [2.3,4.3]
            gates=[2.08,1.96] if quiet else [1.6,1.6]
            if quiet and version>=1:offsets=[.22,3.40];gates=[2.16,1.84]
            layer='pp' if quiet else 'mf'
            for j,(name,off,gate) in enumerate(zip(fl,offsets,gates)):
                p=pitch(name);pid=phrase+'_flute';fvel=52 if layer=='pp' else 69
                events.append({'event_id':f'w92-b{n:02d}-flute-{j+1:02d}','bar':n,'onset':round(start+off,6),'duration':gate,'pitch':p,
                  'velocity':fvel+(2 if j==0 else -2),'instrument':'flute','voice':'breath_phrase' if quiet else 'phrase_answer','hand':'not_applicable',
                  'role':'lead' if quiet else 'answer','phrase_id':pid,'phrase_label':LABELS[(n-1)//4],
                  'harmony_name':hs[n-1],'harmonic_function':'chord_tone' if p%12 in {q%12 for q in chord} else 'melodic_nonchord_tone',
                  'layer':layer,'sample_layer':layer,'source_family':'University of Iowa flute','source_pitch_midi':p,
                  'nominal_gate_seconds':round(gate*60/bpm,9),'onset_reference':'ordinary_trigger',
                  'articulation':'separate_breath_shaped_note','breath_id':f'{pid}-b{n:02d}-{j+1}',
                  'release_reason':'Physical note release before the next explicit breath; no held sample loop or sampled legato.',
                  'velocity_controls':'within_recorded_layer_amplitude_intent',
                  'timing_intent':'Uncompensated ordinary trigger. Owner measures source attack and applies compensation once; pitch stays in the recorded C5–B5 range.'})
            breaths.append({'bar':n,'instrument':'flute','phrase_id':phrase+'_flute','start':round(start+offsets[0]+gates[0],6),
              'end':round(start+offsets[1],6),'reason':'Written inhalation/release interval between separate notes.'})
            breaths.append({'bar':n,'instrument':'flute','phrase_id':phrase+'_flute','start':round(start+offsets[-1]+gates[-1],6),
              'end':start+6,'reason':'Phrase-end release and breath before any next-bar entry.'})
        points=[(0,0),(.10,34 if quiet else 42),(2.82,0),(3.10,30 if quiet else 38),(5.82,0)]
        if n==80:points=[(0,0),(.10,38),(6,0)]
        for off,val in points:pedals.append({'bar':n,'onset':round(start+off,6),'controller':64,'value':val,'instrument':'piano'})
    events.sort(key=lambda e:(e['onset'],e['instrument'],e['hand'],e['pitch'],e['voice']))
    flute_events=[e for e in events if e['instrument']=='flute']
    breaths=[]
    for i,e in enumerate(flute_events):
        following=flute_events[i+1] if i+1<len(flute_events) else None
        breaths.append({'bar':e['bar'],'instrument':'flute','phrase_id':e['phrase_id'],
          'after_event_id':e['event_id'],'before_event_id':following['event_id'] if following else None,
          'start':round(e['onset']+e['duration'],6),'end':following['onset'] if following else 480.0,
          'reason':'Full scored release/breath interval through the next ordinary trigger.' if following else 'Flute finishes; remaining piano climb contains no flute triggers.'})
    for b in bars:b['time_start_seconds']=round(sec(bars,b['start']),9)
    for e in events:
        e['target_on_beats']=e['onset'];e['target_off_beats']=round(e['onset']+e['duration'],6)
        e['target_on_seconds']=round(sec(bars,e['onset']),9);e['target_off_seconds']=round(sec(bars,e['target_off_beats']),9)
    for b in breaths:
        b['start_seconds']=round(sec(bars,b['start']),9);b['end_seconds']=round(sec(bars,b['end']),9)
    phrases=[]
    for i,label in enumerate(LABELS):
        for inst in ('piano','flute'):
            pid=f'P{i+1:02d}_{inst}';es=[e for e in events if e['phrase_id']==pid]
            if not es:continue
            a=min(e['onset'] for e in es);z=max(e['target_off_beats'] for e in es);layers=sorted({e['layer'] for e in es if e['layer']!='not_applicable'})
            phrases.append({'phrase_id':pid,'instrument':inst,'phrase_label':label,'first_bar':i*4+1,'last_bar':i*4+4,
              'section':bars[i*4]['section'],'role':'lead_and_support' if inst=='piano' else es[0]['role'],
              'layer':layers[0] if len(layers)==1 else 'not_applicable','layers_used':layers,
              'roles_used':sorted({e['role'] for e in es}),'voices_used':sorted({e['voice'] for e in es}),
              'target_on_beats':a,'target_off_beats':z,'target_on_seconds':round(sec(bars,a),9),'target_off_seconds':round(sec(bars,z),9),
              'timing_intent':'Four-bar sentence; breath and physical release entries are explicit. All targets use absolute quarter-note beats.'})
    return {'id':92,'title':'A Sail Sewn from Maps','title_zh':'用地图缝成的帆','version':f'v{version}',
      'instrumentation':['natural_acoustic_piano','University_of_Iowa_flute_pp_mf'],'bars':bars,'events':events,'phrases':phrases,
      'pedals':pedals,'breaths':breaths,'hand_position_plan':plans,'total_beats':480.0,'tail_seconds':6.0,
      'music_seconds':round(sec(bars,480),9),'total_seconds_with_tail':round(sec(bars,480)+6,9),
      'cadences':[{'bar':32,'kind':'modal Em withdrawal before changed launch plan'}, {'bar':48,'kind':'quiet Em to renewed impulse'},
                  {'bar':72,'kind':'B7 points to registral peak'}, {'bar':79,'kind':'B7/F# altered leading-tone preparation'}, {'bar':80,'kind':'E minor final tonic'}],
      'performance_contract':{'audio_status':'Symbolic only. No audio rendering, DSP, downloads, installs or listening.',
        'beat_unit':'Absolute quarter-note beats. 12/8 contains six quarter beats; tempo is quarter-note BPM, never dotted-quarter BPM.',
        'piano_instrument':'Natural acoustic piano is the principal instrument; actual source realism and audible balance await owner integration.',
        'maximum_held_span_semitones':12,'same_key_overlaps':'Forbidden within piano across all voices and both hands. Separate instruments are independently monophonic where required.',
        'position_transfer_rule':'Release every physical key before a changed bar-position. Travel uses the larger of actual held-grip edge and declared position-edge distance. Above four semitones require 75 ms + 12 ms per extra semitone; every changed position gets at least 75 ms.',
        'finger_plan':'Explicit, distinct and ordered fingers within each octave-contained grip. Broken-chord movement inside a fixed grip does not imply translation; simultaneous finger reuse is forbidden.',
        'flute_source':'Existing Iowa C5–B5 chromatic recordings only, true pp and mf source layers selected explicitly; no pitch-shift extension, looping or sampled legato.',
        'flute_gate_seconds':[.6,1.5],'flute_attack_compensation':'No anticipation or measured offset in this score. Owner applies measured attack compensation once downstream.',
        'pedal':'CC64 is only resonance intent, never physical hold duration or a substitute for release time.',
        'foreground':'Piano leads all energetic sections. Quiet bars 33–48 give the flute foreground. Answer bars contain a real RH rest before flute entry.',
        'limits':'Saved-file symbolic evidence only; not listening approval or proof of human comfort, acoustic realism or performance quality.'}}

def json_patch(a,b,path=''):
    if type(a)!=type(b):return [{'op':'replace','path':path,'value':b}]
    if isinstance(a,dict):
        out=[]
        for key in sorted(a.keys()-b.keys()):out.append({'op':'remove','path':path+'/'+key.replace('~','~0').replace('/','~1')})
        for key in sorted(b):
            sub=path+'/'+key.replace('~','~0').replace('/','~1')
            if key not in a:out.append({'op':'add','path':sub,'value':b[key]})
            else:out.extend(json_patch(a[key],b[key],sub))
        return out
    return [{'op':'replace','path':path,'value':b}] if a!=b else []
def exact_diff(root,a,b):
    sa=json.loads((root/f'score_{a}.json').read_text());sb=json.loads((root/f'score_{b}.json').read_text());changes=[]
    for n in range(1,81):
        row={'bar':n,'before_bar':sa['bars'][n-1],'after_bar':sb['bars'][n-1]}
        for field in ('events','pedals','breaths'):
            row['before_'+field]=[e for e in sa[field] if e['bar']==n];row['after_'+field]=[e for e in sb[field] if e['bar']==n]
        if any(row['before_'+k]!=row['after_'+k] for k in ('bar','events','pedals','breaths')):changes.append(row)
    sha=lambda name:hashlib.sha256((root/name).read_bytes()).hexdigest()
    save(root,f'exact_diff_{a}_to_{b}.json',{'from':a,'to':b,'before_sha256':sha(f'score_{a}.json'),'after_sha256':sha(f'score_{b}.json'),
      'changed_bars':[r['bar'] for r in changes],'changes':changes,'phrase_metadata_before':sa['phrases'],'phrase_metadata_after':sb['phrases'],
      'position_plan_before':sa['hand_position_plan'],'position_plan_after':sb['hand_position_plan'],'json_patch':json_patch(sa,sb)})
    patch=''.join(difflib.unified_diff(dumps(sa).splitlines(True),dumps(sb).splitlines(True),fromfile=f'score_{a}.json',tofile=f'score_{b}.json'))
    (root/f'exact_diff_{a}_to_{b}.patch').write_text(patch,encoding='utf-8')

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--outdir',type=Path,default=ROOT);args=ap.parse_args();root=args.outdir.resolve()
    if root!=ROOT and ROOT not in root.parents:raise SystemExit('Outputs must remain within this isolated work folder.')
    root.mkdir(parents=True,exist_ok=True)
    for v in range(3):save(root,f'score_v{v}.json',compose(v))
    (root/'score.json').write_bytes((root/'score_v2.json').read_bytes())
    for a,b in [('v0','v1'),('v1','v2')]:exact_diff(root,a,b)
    s=compose(2);print(dumps({'selected':'v2','bars':80,'total_beats':480,'duration_with_tail_seconds':s['total_seconds_with_tail']}))
if __name__=='__main__':main()
