"""No-audio subprocess fixture: own a descendant and optionally ignore SIGTERM."""
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

ready = Path(sys.argv[1])
ignore = sys.argv[2] == 'ignore'
if ignore:
    signal.signal(signal.SIGTERM, signal.SIG_IGN)
child_code = 'import signal,time; signal.signal(signal.SIGTERM, signal.SIG_IGN); time.sleep(120)' if ignore else 'import time; time.sleep(120)'
child = subprocess.Popen([sys.executable, '-c', child_code])
# Give the descendant time to install its handler before declaring readiness.
time.sleep(0.1)
ready.write_text(json.dumps({'stage_pid': os.getpid(), 'descendant_pid': child.pid, 'pgid': os.getpgrp()}))
time.sleep(120)
