import pathlib,aifc,numpy as np,json,math
P=pathlib.Path(__file__).parent;results=[]
for layer in ['pp','mf','ff']:
 f=P/f'BbClar.{layer}.C4B4.aiff'
 with aifc.open(str(f),'rb')as w:sr=w.getframerate();sw=w.getsampwidth();ch=w.getnchannels();raw=w.readframes(w.getnframes())
 assert sw==2 and ch==1,(layer,sw,ch);y=np.frombuffer(raw,dtype='>i2').astype(np.float32)/32768;hop=round(sr*.02);a=np.pad(y,(0,(-len(y))%hop)).reshape(-1,hop);rms=np.sqrt(np.mean(a*a,axis=1));noise=float(np.quantile(rms,.15));threshold=max(float(rms.max())*.035,noise*8,.00006);mask=rms>threshold;spans=[];start=None;last=None
 for i,v in enumerate(mask):
  if v:
   if start is None:start=i
   last=i
  elif start is not None and i-last>=6:
   if last-start>=12:spans.append((start,last+1))
   start=None;last=None
 if start is not None and last-start>=12:spans.append((start,last+1))
 rows=[]
 for j,(a,b)in enumerate(spans):
  lo=a*hop;hi=min(len(y),b*hop);mid=(lo+hi)//2;seg=y[max(lo,mid-sr//4):min(hi,mid+sr//4)].astype(np.float64);seg-=seg.mean();win=seg*np.hanning(len(seg));n=1<<(2*len(win)-1).bit_length();spec=np.fft.rfft(win,n);ac=np.fft.irfft(spec*np.conj(spec),n)[:len(win)];expected=440*2**((60+j-69)/12);lmin=math.floor(sr/(expected*2**(1.1/12)));lmax=math.ceil(sr/(expected/2**(1.1/12)));k=lmin+int(np.argmax(ac[lmin:lmax+1]));delta=.5*(ac[k-1]-ac[k+1])/(ac[k-1]-2*ac[k]+ac[k+1]);freq=sr/(k+delta);cents=1200*math.log2(freq/expected);rows.append(dict(midi=60+j,active_start_frame=int(lo),active_end_frame=int(hi),active_seconds=(hi-lo)/sr,estimated_frequency_hz=freq,deviation_cents=cents,periodicity=float(ac[k]/ac[0]),body_rms=float(np.sqrt(np.mean(seg*seg)))))
 results.append(dict(layer=layer,source_file=f.name,sample_rate=sr,channels=ch,bits=sw*8,duration=len(y)/sr,noise_rms=noise,threshold=threshold,detected_notes=len(rows),notes=rows));print(layer,'notes',len(rows),'durations',[round(x['active_seconds'],2)for x in rows],'cents',[round(x['deviation_cents'],1)for x in rows])
(P/'scale_analysis.json').write_text(json.dumps(results,indent=2));assert all(r['detected_notes']==12 for r in results),'Expected exactly12chromatic notes';assert all(abs(n['deviation_cents'])<40 for r in results for n in r['notes']),'Unexpected pitch order or tuning';print('All36notes mapped with expected pitch range')
