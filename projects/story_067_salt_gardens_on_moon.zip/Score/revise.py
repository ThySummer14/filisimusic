from pathlib import Path
import json
P=Path(__file__).parent;d=json.loads((P/'revisions/score_v0.json').read_text())
C=[[(72,1),(68,.5),(65,.5),(68,1),(72,1)],[(73,.5),(77,.5),(80,1),(79,.5),(77,.5),(75,1)],[(77,1),(73,.5),(70,.5),(68,1),(65,1)],[(67,.5),(70,.5),(73,1),(75,1),(79,1)],[(80,1),(75,.5),(72,.5),(70,.5),(72,.5),(75,1)],[(79,1),(75,.5),(72,.5),(67,1),(72,1)],[(77,.5),(80,.5),(85,1),(84,.5),(80,.5),(77,1)],[(79,1),(82,.5),(85,.5),(84,1),(82,1)],[(80,.5),(79,.5),(77,1),(75,.5),(72,.5),(68,1)],[(70,.5),(73,.5),(77,1),(80,1),(77,1)],[(79,.5),(77,.5),(75,1),(73,1),(70,1)],[(68,1),(72,1),(75,1),(-1,1)]]
H={'Fm':[41,53,56,60],'Db':[37,53,56,61],'Bbm':[46,53,58,61],'Eb7':[39,55,58,61],'Ab':[44,51,56,60],'Cm':[48,55,60,63]};prog=['Fm','Db','Bbm','Eb7','Ab','Cm','Db','Eb7','Fm','Bbm','Eb7','Ab']
for j,line in enumerate(C):
 b=d['bars'][36+j];h=prog[j];ch=H[h];b.update(harmony_name=h,harmony=ch);d['events']=[e for e in d['events'] if e['bar']!=b['bar']];off=0
 for n,l in line:
  if n>=0:d['events'].append(dict(bar=b['bar'],onset=b['start']+off,duration=l*.975,pitch=n,velocity=73,voice='melody'))
  off+=l
 assert off==4
 d['events'].append(dict(bar=b['bar'],onset=b['start'],duration=.56,pitch=ch[0],velocity=50,voice='bass'))
 for t,n in [(.75,ch[1]),(1.25,ch[2]),(1.75,ch[3]),(2.25,ch[2]),(2.75,ch[1]),(3.25,ch[2])]:d['events'].append(dict(bar=b['bar'],onset=b['start']+t,duration=.46,pitch=n,velocity=39,voice='accompaniment'))
d['stage']='v1_new_outward_letter_theme_and_harmonic_route';(P/'revisions/score_v1.json').write_text(json.dumps(d,indent=2));(P/'revisions/pass1.json').write_text(json.dumps({'round':1,'kind':'substantive_composition_revision','changes':['Replace all12bars of the outward-letter section with a new melody, starting lower and finding a new high point rather than reusing the earlier branching theme.','Change its harmonic route toFm–Db–Bbm–Eb7–Ab–Cm and a different return, so speaking her own message changes the music rather than just the story text.']},indent=2))
arc=[-3,0,2,-4,-1,2,3,-5,-2,1,3,-5];removed=[]
for b in d['bars']:
 k=b['role_plan'];j=b['phrase_position'];base={'intro':60,'letters':68,'branches':74,'reread':59,'outward':73,'coda':58}[k];ns=[e for e in d['events'] if e['bar']==b['bar'] and e['voice']=='melody'];end=max(e['onset']+e['duration'] for e in ns);breath=end<b['start']+3.3
 for e in [e for e in d['events'] if e['bar']==b['bar']]:
  if e['voice']=='melody':e['velocity']=base+arc[j%12]+(2 if e['duration']>1.2 else 0)
  else:
   e['velocity']=base-(25 if e['voice']=='bass' else 35)+arc[j%12]//2
   if breath and e['onset']>=b['start']+3:e['remove']=True;removed.append([e['bar'],e['pitch']])
   if k=='reread':e['duration']*=.8
 # Old edges become drier; an outward phrase acquires a larger connected resonant span.
 for x in d['pedals']:
  if b['start']<=x['onset']<b['start']+4 and x['value']>0:x['value']=32 if k=='reread' else 52 if k=='outward' else 46
# The final open ninth is intentionally quiet and supported by one common chord.
b=d['bars'][-1];d['events']=[e for e in d['events'] if not(e['bar']==b['bar'] and e['voice']!='melody')]
for off,n,dur,vel in [(0,44,.55,34),(.75,51,2.3,27),(.75,56,2.3,27),(.75,60,2.3,27)]:d['events'].append(dict(bar=b['bar'],onset=b['start']+off,duration=dur,pitch=n,velocity=vel,voice='bass' if off==0 else'accompaniment'))
d['events']=[e for e in d['events'] if not e.pop('remove',False)];d['events'].sort(key=lambda e:(e['onset'],e['pitch']));d['stage']='v2_joint_phrase_arcs_dry_old_edges_and_open_ninth'
for f in ['score.json','revisions/score_v2.json']:(P/f).write_text(json.dumps(d,indent=2))
(P/'revisions/pass2.json').write_text(json.dumps({'round':2,'kind':'substantive_performance_revision','changes':['Give each long melodic sentence a specific dynamic arc; low and middle notes follow that arc and withdraw at written breaths.','Dry the old-letter section with shorter inner notes and shallower pedal; the new outward letter uses a more connected pedal span.','Replace final moving accompaniment with one soft compact chord supporting the melodic ninth, leaving space beside the new branch.'],'withdrawn_support':removed,'human_listening_review':False},indent=2))
