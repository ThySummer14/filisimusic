# Two substantive revisions

The three JSON files are complete 64-bar scores. They are reproducible from the same source script; revision differences are calculated by the script and included in technical_audit.json. These are written-score revisions, not claims based on listening.

## Revision 1 — v0 → v1: make the observation lead to an actual choice

Problem in the first written draft: bars 29–32 repeated the opening of the contrasting section, the decision passage had eight similarly shaped one-bar units, and the entire A return repeated the first A melody. The future image arrived, but the protagonist's response did not sufficiently change the form.

Changes:
- Recompose melody in bars 29–40 and 49–56: 20 bars of actual pitch/rhythm changes.
- Redirect bars 30–32 from A/G–F♯m7–B7(b9) to Gm6–D/F♯–A13. The contrast now returns toward the decision instead of restarting its own circuit.
- Turn bars 33–40 into a growing phrase over B–A♯–A–G♯ bass motion, with a new upper-register F♯5 peak at 37 and a descending response.
- Rewrite the left-hand support at 33, 35, 37–40, including a more active chord response at the peak and a withdrawn bar 40.
- Recompose 49–56 rather than copying 13–20. E9/G♯ at 52 recalls the decision, and the cadence at 56 now uses A13.

Result visible in score: the return’s second half is changed by the middle passage; the highest melody pitch grows from E5 in v0 to F♯5 in v1. There is now a harmonic and registral reason for the middle to exist.

## Revision 2 — v1 → v2: let the changed harbor alter the return and ending

Problem remaining in v1: bars 41–48 were still a literal reprise, and the coda mainly recycled earlier phrases with ordinary comping. The ending did not yet distinguish preservation from simply resetting the clock.

Changes:
- Recompose bars 41–48 and 57–64: 16 bars of actual pitch/rhythm changes.
- Start bar 41’s F♯ on the downbeat; retain the recognizable F♯–A–B–A–F♯ contour while changing its entry and duration profile.
- Give bars 43 and 45 new rising continuations; lengthen the return’s cadence at 48 while removing the late left-hand answer.
- Reduce left-hand activity through the coda rather than sustaining the earlier groove unchanged.
- Replace the original final three-note descent with the two-bar F♯–A–E / D arrival at 63–64. The final D lasts 3.75 beats, with attached F♯–A support and a single sustained bass/root plus delayed compact shell.
- Add the small final tempo relaxation at bars 62, 63, and 64: 86, 84, and 76 BPM. The main groove remains at 88 BPM.
- Use 34/63 partial pedal only for the last arrival, then explicitly release it before the tail.

Result visible in score: no bar of the 16-bar A return is an exact pitch/rhythm copy of its corresponding original A bar, while the main motive remains recognizable. Total events reduce from 832 to 800, and the last eight bars actually make space.

## Technical comparison

| Property | v0 | v1 | v2 |
|---|---:|---:|---:|
| Bars | 64 | 64 | 64 |
| Note events | 824 | 832 | 800 |
| Approx. time including 4-second tail | 178.545 s | 178.545 s | 179.169 s |
| Melody maximum MIDI pitch | 76 | 78 | 78 |
| Maximum simultaneous RH span | 7 semitones | 7 semitones | 8 semitones |
| Maximum simultaneous LH span | 11 semitones | 11 semitones | 11 semitones |
| Exact corresponding A/return bars | 16 | 8 | 0 |
| Same-key overlaps | 0 | 0 | 0 |

These measurements document the rewrite and practical constraints. They are not a substitute for listening and do not establish aesthetic quality.
