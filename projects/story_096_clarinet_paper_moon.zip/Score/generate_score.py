#!/usr/bin/env python3
"""Work096. Original symbolic composition; standard library; no media access."""
import argparse, copy, difflib, hashlib, json
from collections import defaultdict
from pathlib import Path
ROOT=Path(__file__).resolve().parent

# Concert MIDI. The first array is the real left-hand grip; the second is
# harmonic right-hand support, never a second melodic foreground.
H={
 'Am':([45,52,57],[60,64,69]), 'Am/C':([48,52,57],[60,64,69]),
 'Am/E':([40,45,52],[60,64,69]), 'Am(add9)':([45,52,57],[59,60,64]),
 'E7':([40,47,50],[56,62,64]), 'E7/G#':([44,47,50],[56,62,64]),
 'Dm':([38,45,50],[57,62,65]), 'F':([41,48,53],[57,60,65]),
 'C':([48,52,55],[60,64,67]), 'C/E':([40,48,55],[60,64,67]),
 'G':([43,50,55],[59,62,67]), 'G/B':([47,50,55],[59,62,67]),
 'G7':([43,50,53],[59,62,65]), 'Em':([40,47,52],[59,64,67]),
 'Bdim':([47,50,53],[59,62,65])}
# Avoid a 15-semitone C/E grip: a true first inversion with compact voicing.
H['C/E']=([40,43,48],[60,64,67])

# Each sentence has eight independently authored bars. Values include rests
# and sum to four quarter-note beats; clarinet never uses shorter than .75.
FINAL=[
 ('A','街边的旧月亮',82,'A minor','open_dyads',[
 'Am|C|64/1.25 69/.75 67/1 64/1',
 'E7/G#|C|68/.75 71/.75 68/1.5 64/1',
 'Am/C|C|64/1 60/.75 62/.75 64/1.5',
 'Dm|C|65/1.5 64/1 62/.75 -/.75',
 'F|C|65/1.25 69/.75 67/1 65/1',
 'C/E|C|64/.75 67/1.25 64/1 60/1',
 'Dm|C|62/1 65/1 64/1 62/1',
 'E7|C|64/1.5 68/1.25 -/1.25']),
 ('A','搬进门时要侧过来',84,'A minor','answering_dyads',[
 'Am|C|69/1.25 64/.75 67/1 69/1',
 'G|C|71/1 67/1.5 62/1.5',
 'F|C|69/.75 65/1.25 64/1 60/1',
 'E7|C|62/1.25 64/1.25 68/.75 -/.75',
 'Dm|C|69/1 65/.75 62/.75 65/1.5',
 'Am/E|C|64/1.5 60/.75 64/.75 69/1',
 'E7|C|71/.75 68/1.25 64/1 62/1',
 'Am|C|60/1 64/1 69/1 -/1']),
 ('B','第一个挂钩',86,'A minor / F major','piano_arcs',[
 'Dm|P|74/1 77/.5 76/.5 74/1 69/1',
 'Am/C|P|72/1.5 76/.5 74/1 72/1',
 'F|P|77/1 76/.5 74/.5 72/2',
 'C/E|P|76/1.5 74/.5 72/1 -/1',
 'Dm|P|74/.5 77/.5 81/1 79/1 77/1',
 'E7|P|76/1 74/.5 71/.5 68/2',
 'Am|P|69/1.5 72/.5 76/1 74/1',
 'E7|P|71/1 68/1 64/1 -/1']),
 ('C','换到长椅的这面',82,'C major / F major','warm_sustained',[
 'C|C|67/1.5 64/.75 60/.75 64/1',
 'G/B|C|62/1.25 67/1.25 71/1.5',
 'Am|C|69/1.5 67/.75 64/.75 60/1',
 'F|C|65/1.5 69/1.5 -/1',
 'Dm|C|65/.75 62/1.25 69/1 65/1',
 'G7|C|67/1.5 65/.75 62/.75 67/1',
 'C|C|60/1.25 64/.75 67/1 64/1',
 'C/E|C|67/1.5 64/1.5 -/1']),
 ('C','灯离纸面远一点',84,'F major to A minor','piano_spaced',[
 'F|P|77/1.5 72/.5 74/1 77/1',
 'C/E|P|76/1.5 79/.5 76/1 72/1',
 'Dm|P|74/1 77/1 76/.5 74/.5 69/1',
 'G7|P|71/1.5 74/.5 77/1 -/1',
 'Em|P|76/1 79/.5 78/.5 76/1 71/1',
 'Am|P|72/1 76/1.5 74/.5 72/1',
 'Dm|P|74/1.5 77/.5 76/1 74/1',
 'E7|P|71/1 68/1 64/1 -/1']),
 ('D','第二只钩的旧螺孔',88,'A minor / dominant tension','development_pulse',[
 'Am|C|64/.75 69/1.25 64/1 60/1',
 'F|C|65/.75 69/1.25 65/1 60/1',
 'Bdim|C|65/1 62/1 65/.75 71/1.25',
 'E7|C|68/1 71/1 64/1 -/1',
 'Dm|C|69/1.25 65/.75 62/1 65/1',
 'F|C|69/1 65/.75 60/.75 65/1.5',
 'E7|C|68/.75 71/1.25 68/1 64/1',
 'E7|C|62/1 64/1 68/1 -/1']),
 ('R','朝候场的人转过身',84,'A minor with retained warmth','return_displaced',[
 'Am/C|C|64/1.5 69/1 71/.75 69/.75',
 'F|C|67/.75 65/1.25 64/1 60/1',
 'Dm|C|62/1.25 65/.75 69/1 67/1',
 'Am/E|C|64/1.5 60/1.5 -/1',
 'F|C|65/1 69/1.5 67/.75 65/.75',
 'Dm|C|64/.75 62/1.25 65/1 69/1',
 'E7|C|68/1.25 64/.75 62/1 64/1',
 'Am(add9)|C|71/.75 69/1.25 64/1 -/1']),
 ('R','声音停在长椅前',82,'A minor / F major','piano_return',[
 'F|P|77/1 81/.5 79/.5 77/1 72/1',
 'C/E|P|76/1.5 72/.5 74/1 76/1',
 'Dm|P|77/.5 74/.5 69/1 74/1.5 76/.5',
 'Am/C|P|72/1.5 76/1.5 -/1',
 'F|P|77/1 76/.5 74/.5 72/1 69/1',
 'Dm|P|74/1.5 77/.5 76/1 74/1',
 'E7|P|71/1 74/.5 72/.5 68/1 64/1',
 'Am|P|69/1.5 72/1.5 -/1']),
 ('Z','不用再扶着它',78,'A minor','quiet_close',[
 'Dm|C|65/1.5 64/.75 62/.75 65/1',
 'Am/C|C|64/1.5 60/1 64/1.5',
 'E7|C|62/1 64/1 68/1 -/1',
 'Am|C|69/1.5 64/1.5 -/1',
 'F|P|69/1.5 72/.5 77/1 76/1',
 'Dm|P|74/1.5 69/.5 65/1 -/1',
 'E7|P|68/1.5 71/.5 64/1 -/1',
 'Am|P|69/4'])]
# This candidate is a complete earlier middle, with its own real pitches,
# rhythms, harmonies and accompaniment. Revision1 rewrites fifteen bars of
# the sixteen-bar middle and retains its dominant cadence.
EARLY_MIDDLE=[
 ['Am|C|64/1 69/1 67/1 64/1','E7|C|68/1 64/1 62/1 64/1','Am/C|C|60/1 64/1 69/1 64/1','Dm|C|65/1 62/1 65/1 -/1',
  'F|C|65/1 69/1 65/1 60/1','E7|C|64/1 68/1 71/1 68/1','Dm|C|65/1 62/1 64/1 65/1','E7|C|68/1 64/1 62/1 -/1'],
 ['Am|P|76/1 72/1 69/1 72/1','E7|P|71/1 68/1 64/1 68/1','F|P|72/1 77/1 76/1 72/1','E7|P|74/1 71/1 68/1 -/1',
  'Am|P|76/1 72/1 69/1 72/1','Dm|P|74/1 69/1 65/1 69/1','Am/E|P|72/1 76/1 74/1 72/1','E7|P|71/1 68/1 64/1 -/1']]
EARLY_RETURN=[
 ['Am|C|64/1.25 69/.75 67/1 64/1','E7/G#|C|68/.75 71/.75 68/1.5 64/1','Am/C|C|64/1 60/.75 62/.75 64/1.5','Dm|C|65/1.5 64/1 62/.75 -/.75',
  'F|C|65/1.25 69/.75 67/1 65/1','C/E|C|64/.75 67/1.25 64/1 60/1','Dm|C|62/1 65/1 64/1 62/1','E7|C|64/1.5 68/1.25 -/1.25'],
 ['Dm|P|74/1 77/.5 76/.5 74/1 69/1','Am/C|P|72/1.5 76/.5 74/1 72/1','F|P|77/1 76/.5 74/.5 72/2','C/E|P|76/1.5 74/.5 72/1 -/1',
  'Dm|P|74/.5 77/.5 81/1 79/1 77/1','E7|P|76/1 74/.5 71/.5 68/2','Am|P|69/1.5 72/.5 76/1 74/1','E7|P|71/1 68/1 64/1 -/1']]

def dumps(x):return json.dumps(x,ensure_ascii=False,indent=2)+'\n'
def save(root,n,x):(root/n).write_text(dumps(x),encoding='utf-8')
def parse(s):return [(None if p=='-' else int(p),float(v)) for p,v in (t.split('/') for t in s.split())]
def seconds(bars,t):return sum(min(max(t-b['start'],0),4)*60/b['bpm'] for b in bars)
def finger_map(keys,hand):
    # Every named grip uses actual scored keys; wide pairs receive fingers1/5.
    fs={1:[3],2:[1,5],3:[1,3,5],4:[1,2,4,5],5:[1,2,3,4,5]}[len(keys)]
    if hand=='left':fs=[6-f for f in fs]
    return dict(zip(keys,fs))

def build(version):
    bars=[];melodies=[]
    for q,(section,label,tempo,key,texture,source) in enumerate(FINAL):
        rows=source
        if version=='v0' and q in (3,4):rows=EARLY_MIDDLE[q-3];key='A minor';texture='early_regular'
        if version in ('v0','v1') and q in (6,7):rows=EARLY_RETURN[q-6];texture='early_reprise'
        for j,row in enumerate(rows):
            hn,lead,tokens=row.split('|');n=len(bars)+1;mel=parse(tokens)
            assert sum(w for p,w in mel)==4,(n,mel)
            assert all(p is None or 60<=p<=71 for p,w in mel) if lead=='C' else True,(n,mel)
            bpm=tempo+[0,0,1,-1,1,0,0,-2][j]
            if q==8:bpm=[80,80,78,76,78,76,74,70][j]
            b={'bar':n,'start':float((n-1)*4),'beats':4.0,'bpm':bpm,'meter':'4/4','meter_numerator':4,'meter_denominator':4,
               'section':section,'section_title_zh':{'A':'门外','B':'第一个挂钩','C':'长椅这面','D':'换钩','R':'转过身','Z':'放手'}[section],
               'harmony_name':hn,'harmony':H[hn][0]+H[hn][1],'key_region':key,'lead_instrument':'clarinet' if lead=='C' else 'piano',
               'phrase_id':f'P{q+1:02d}','macro_phrase_id':f'P{q+1:02d}','macro_phrase_length_bars':8,'phrase_position':j+1,
               'phrase_label':label,'texture':texture,'written_melody':[{'pitch':p,'value_beats':w} for p,w in mel],
               'role_plan':'Clarinet melody with quiet piano chord support.' if lead=='C' else 'Piano cantabile foreground; clarinet has a complete scored rest.'}
            bars.append(b);melodies.append(mel)
    for b in bars:b['time_start_seconds']=round(seconds(bars,b['start']),9)
    events=[];pedals=[];plans=[]
    def add(b,on,dur,p,v,inst,hand,voice,role,written):
        e={'bar':b['bar'],'onset':round(b['start']+on,6),'duration':round(dur,6),'pitch':p,'velocity':v,'instrument':inst,'hand':hand,'voice':voice,'role':role,
           'phrase_id':b['phrase_id']+'_'+inst+('_a' if b['phrase_position']<=4 else '_b') if inst=='clarinet' else b['phrase_id']+'_piano',
           'phrase_label':b['phrase_label'],'harmony_name':b['harmony_name'],'written_value_beats':written,
           'harmonic_function':'chord_tone' if p%12 in {x%12 for x in b['harmony']} else 'melodic_nonchord_tone',
           'onset_reference':'ordinary_trigger','timing_correction_applied_seconds':0}
        if inst=='clarinet':
            layer='pp' if v<=55 else 'mf' if v<=95 else 'ff'
            e.update(layer=layer,sample_layer=layer,source_pitch_midi=p,source_family='University of Iowa clarinet',sample_transition='none',
                     articulation='naturally_separated_breathed_tone',velocity_controls='recorded_layer_selection_and_within_layer_amplitude_intent',
                     timing_intent='Ordinary unshifted trigger; breath rests are composed. No extra sample attack compensation.')
        else:e.update(layer='natural',sample_layer='approved_natural_piano',articulation='separated_cantabile' if role=='lead' else 'soft_harmonic_support')
        events.append(e)
    for b,mel in zip(bars,melodies):
        n=b['bar'];q=(n-1)//8;j=(n-1)%8;sb=60/b['bpm'];is_c=b['lead_instrument']=='clarinet';lh,rh=H[b['harmony_name']]
        # Literal accompaniment families, tied to compositional section.
        texture=b['texture'];energy=4 if b['section']=='D' else -4 if b['section']=='Z' else 0
        if texture in ('open_dyads','early_regular','early_reprise'):
            lp=[(0,[0],1.45),(2,[1,2],1.40)];rp=[(.20,[0,1],1.4),(2.45,[1,2],1.20)]
        elif texture=='answering_dyads':
            lp=[(0,[0,2],1.65),(2.65,[1],.85)];rp=[(.35,[0,1],1.5),(2.50,[1,2],1.0)]
        elif texture=='warm_sustained':
            lp=[(0,[0,1,2],3.45)];rp=[(.25,[0,1],2.9)]
        elif texture=='development_pulse':
            lp=[(0,[0,2],.9),(1.5,[1,2],.8),(3,[0,1],.65)];rp=[(.35,[0,1],1.0),(2.15,[1,2],1.1)]
        elif texture=='return_displaced':
            lp=[(0,[0,2],2.05),(2.75,[1],.8)];rp=[(.5,[0,1],1.6),(2.6,[0,2],.95)]
        elif texture=='quiet_close':
            lp=[(0,[0,2],3.1)];rp=[(.35,[0,1],2.5)]
        elif texture=='piano_spaced':
            lp=[(0,[0,2],2.25),(2.75,[1],.7)];rp=[]
        elif texture=='piano_return':
            lp=[(0,[0,1,2],1.9),(2.75,[1,2],.7)];rp=[]
        else:lp=[(0,[0],1.1),(1.5,[1,2],1.05),(3,[0,2],.65)];rp=[]
        if j in (3,7) and n!=72:
            # A gentle piano connection can continue underneath the real air gap.
            lp=[(0,[0,2],2.20),(3.05,[1],.72)]
        if n==72:lp=[(0,[0,1,2],4.0)]
        for on,ix,dur in lp:
            for k in ix:add(b,on,dur,lh[k],(29 if is_c else 43)+energy+(2 if k==0 else 0),'piano','left','harmonic_foundation','support',dur)
        if is_c:
            for on,ix,dur in rp:
                for k in ix:add(b,on,dur,rh[k],27+energy,'piano','right','chordal_support','support',dur)
        t=0
        for k,(p,w) in enumerate(mel):
            if p is not None:
                if is_c:
                    gate=min(1.38,w*sb-.095)
                    assert .35<=gate<=1.45,(n,p,w,gate)
                    v=49 if q==0 else 67 if q==1 else 52 if q==3 else 80 if q==5 else 62 if q==6 else 45
                    v += [0,2,-2,1,0][k%5]
                    if n in (45,46) and k==0:v=98 if n==45 else 96
                    add(b,t,gate/sb,p,v,'clarinet','not_applicable','cantabile_melody','lead',w)
                else:
                    v=66+(7 if q==4 else 0)-(15 if q==8 else 0)+[0,2,-2,1,0][k%5]
                    add(b,t,w if n==72 else max(.15,w-.07/sb),p,v,'piano','right','melody','lead',w)
            t+=w
        for hand in ('left','right'):
            es=[e for e in events if e['bar']==n and e['instrument']=='piano' and e['hand']==hand];keys=sorted({e['pitch'] for e in es})
            assert 0<len(keys)<=5 and keys[-1]-keys[0]<=12,(n,hand,keys)
            fm=finger_map(keys,hand);pid=('L' if hand=='left' else 'R')+'_'.join(map(str,keys))
            plan={'bar':n,'hand':hand,'active':True,'position_id':pid,'range':[keys[0],keys[-1]],'pitch_finger_map':{str(p):f for p,f in fm.items()},
                  'grip_strategy':'Actual scored keys, ordered fingers; complete key release at every new attack including the same named position.'}
            plans.append(plan)
            for e in es:e.update(finger=fm[e['pitch']],hand_position_id=pid,hand_position_range=plan['range'],position_keys=keys,hand_position_keys=keys)
        pedals.extend([{'bar':n,'onset':b['start']+.10,'controller':64,'value':30 if texture=='warm_sustained' else 22,'instrument':'piano'},
                       {'bar':n,'onset':b['start']+3.90 if n!=72 else 288.0,'controller':64,'value':0,'instrument':'piano'}])
    hp={(p['bar'],p['hand']):p for p in plans}
    for hand in ('left','right'):
        ns=[e for e in events if e['instrument']=='piano' and e['hand']==hand];groups=defaultdict(list)
        for e in ns:groups[e['onset']].append(e)
        gg=sorted(groups.items())
        for (a,old),(z,new) in zip(gg,gg[1:]):
            ok=[e['pitch'] for e in old];nk=[e['pitch'] for e in new];op=hp[(old[0]['bar'],hand)];np=hp[(new[0]['bar'],hand)]
            edge=max(abs(min(ok)-min(nk)),abs(max(ok)-max(nk)));movement=max(abs(p-r) for p in ok for r in nk)
            position=max(abs(x-y) for x,y in zip(op['range'],np['range'])) if op['position_id']!=np['position_id'] else 0
            required=.075+.012*max(0,max(edge,movement,position)-4)+.014;limit=seconds(bars,z)-required
            for e in ns:
                if e['onset']>=z:continue
                if seconds(bars,e['onset']+e['duration'])>limit:
                    e['duration']=round((limit-seconds(bars,e['onset']))*bars[e['bar']-1]['bpm']/60,6)
                    assert e['duration']>.08,(n,e)
                    e['release_adjustment']='Actual full-key release for maximum grip-edge/held-key/position-edge transfer, with 14 ms margin. Pedal excluded.'
    events.sort(key=lambda e:(e['onset'],e['instrument'],e['hand'],e['pitch'],e['voice']));counter=defaultdict(int)
    for e in events:
        k=(e['bar'],e['instrument'],e['voice']);counter[k]+=1;e['event_id']=f'w96-b{e["bar"]:03d}-{e["instrument"]}-{e["voice"]}-{counter[k]:02d}'
        e.update(target_on_beats=e['onset'],target_off_beats=round(e['onset']+e['duration'],6),target_on_seconds=round(seconds(bars,e['onset']),9),target_off_seconds=round(seconds(bars,e['onset']+e['duration']),9))
        if e['instrument']=='clarinet':e['nominal_gate_seconds']=round(seconds(bars,e['onset']+e['duration'])-seconds(bars,e['onset']),9)
    for p in pedals:p['target_on_seconds']=round(seconds(bars,p['onset']),9)
    phrases=[]
    for pid in sorted({e['phrase_id'] for e in events}):
        es=[e for e in events if e['phrase_id']==pid];a=min(e['onset'] for e in es);z=max(e['onset']+e['duration'] for e in es)
        phrases.append({'phrase_id':pid,'instrument':es[0]['instrument'],'first_bar':min(e['bar'] for e in es),'last_bar':max(e['bar'] for e in es),
          'phrase_label':es[0]['phrase_label'],'layers_used':sorted({e['layer'] for e in es}),'roles_used':sorted({e['role'] for e in es}),'voices_used':sorted({e['voice'] for e in es}),
          'target_on_beats':a,'target_off_beats':round(z,6),'target_on_seconds':round(seconds(bars,a),9),'target_off_seconds':round(seconds(bars,z),9),
          'timing_intent':'Four-bar clarinet breath unit or eight-bar piano sentence, all times in quarter-note beats.'})
    return {'id':96,'title':'Clarinet Under the Paper Moon','title_zh':'纸月亮下的单簧管','version':version,
      'instrumentation':['natural_acoustic_piano','University_of_Iowa_clarinet_C4_B4'],'bars':bars,'events':events,'phrases':phrases,'pedals':pedals,'hand_position_plan':plans,
      'total_beats':288.0,'tail_seconds':4.0,'music_seconds':round(seconds(bars,288),9),'total_seconds_with_tail':round(seconds(bars,288)+4,9),
      'performance_contract':{'beat_unit':'All absolute and relative musical time is quarter-note beats; BPM is quarter notes per minute.',
       'audio_status':'Symbolic only; no audio, DSP, downloads, installation or sample editing.',
       'clarinet':'Actual concert MIDI60–71 only. pp1–55, mf56–95, ff96–127. Ordinary triggers, no attack compensation or sampled legato. Gates .35–1.45 s, individual release at least .08 s, .35 s or longer breath at least every four bars.',
       'foreground':'One monophonic foreground: clarinet or piano right hand; other instrument has harmonic support or scored rests.',
       'position_transfer_rule':'Every attack, both hands, no melody exemption: full real release at least 75 ms plus12 ms per semitone above4 of max(grip-edge travel, all actual held-key movement, changed whole-position edges).',
       'maximum_held_span_semitones':12,'same_key_overlaps':'Forbidden across piano hands and voices; finger collisions and hand crossings forbidden.',
       'pedal':'Resonance only; never substitutes for physical key release.',
       'limitations':'Symbolic constraints do not certify actual sample envelopes, acoustic balance, listening quality or performer comfort.'}}

def patch(a,b,path=''):
    if a==b:return []
    if isinstance(a,dict) and isinstance(b,dict):
        out=[]
        for k in sorted(set(a)|set(b)):
            p=path+'/'+k.replace('~','~0').replace('/','~1')
            if k not in b:out.append({'op':'remove','path':p})
            elif k not in a:out.append({'op':'add','path':p,'value':b[k]})
            else:out+=patch(a[k],b[k],p)
        return out
    return [{'op':'replace','path':path,'value':b}]
def emit_diff(root,a,b):
    before=dumps(a);after=dumps(b);av=a['version'];bv=b['version'];changes=[]
    for n in range(1,73):
        row={'bar':n,'before_bar':a['bars'][n-1],'after_bar':b['bars'][n-1],
          'before_events':[e for e in a['events'] if e['bar']==n],'after_events':[e for e in b['events'] if e['bar']==n],
          'before_pedals':[e for e in a['pedals'] if e['bar']==n],'after_pedals':[e for e in b['pedals'] if e['bar']==n]}
        if any(row['before_'+k]!=row['after_'+k] for k in ('bar','events','pedals')):changes.append(row)
    save(root,f'exact_diff_{av}_to_{bv}.json',{'from_version':av,'to_version':bv,'before_sha256':hashlib.sha256(before.encode()).hexdigest(),'after_sha256':hashlib.sha256(after.encode()).hexdigest(),
      'changed_bars':[r['bar'] for r in changes],'changes':changes,'phrase_metadata_before':a['phrases'],'phrase_metadata_after':b['phrases'],
      'position_plan_before':a['hand_position_plan'],'position_plan_after':b['hand_position_plan'],'json_patch':patch(a,b)})
    (root/f'exact_diff_{av}_to_{bv}.patch').write_text(''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile=f'score_{av}.json',tofile=f'score_{bv}.json')),encoding='utf-8')
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--outdir',default=str(ROOT));args=ap.parse_args();root=Path(args.outdir);root.mkdir(parents=True,exist_ok=True)
    ss=[build(v) for v in ('v0','v1','v2')]
    for s in ss:save(root,f'score_{s["version"]}.json',s)
    save(root,'score.json',ss[-1]);emit_diff(root,ss[0],ss[1]);emit_diff(root,ss[1],ss[2])
    print(json.dumps({'bars':72,'events':len(ss[-1]['events']),'seconds_with_tail':ss[-1]['total_seconds_with_tail']}))
if __name__=='__main__':main()
