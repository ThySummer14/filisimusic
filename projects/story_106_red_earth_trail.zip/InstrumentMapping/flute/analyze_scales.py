#!/usr/bin/env python3
"""Reproducible, bounded offline analysis; Python stdlib + existing NumPy only.

No audio rendering, download, normalization, resampling, or sample mutation.
Resource ceiling: one allowed CPU, 150 MiB virtual memory, 90 CPU seconds.
"""
import os
for variable in ('OPENBLAS_NUM_THREADS', 'OMP_NUM_THREADS', 'MKL_NUM_THREADS', 'NUMEXPR_NUM_THREADS'):
    os.environ[variable] = '1'
import resource
resource.setrlimit(resource.RLIMIT_AS, (150 * 1024**2, 150 * 1024**2))
resource.setrlimit(resource.RLIMIT_CPU, (90, 90))
if hasattr(os, 'sched_getaffinity'):
    os.sched_setaffinity(0, {min(os.sched_getaffinity(0))})
import aifc, hashlib, json, math, pathlib, struct, time
import numpy as np

P = pathlib.Path(__file__).resolve().parent
START = time.monotonic()
NOTE_NAMES = ['C5','Cs5','D5','Ds5','E5','F5','Fs5','G5','Gs5','A5','As5','B5']

def read_source(path):
    with aifc.open(str(path), 'rb') as reader:
        parameters = reader.getparams()
        assert parameters.nchannels == 1 and parameters.sampwidth == 2
        assert parameters.framerate == 44100 and parameters.comptype == b'NONE'
        raw = reader.readframes(parameters.nframes)
    assert len(raw) == parameters.nframes * 2
    return parameters, raw

def inspect_chunks(path):
    chunks = []
    with path.open('rb') as f:
        header = f.read(12)
        assert header[:4] == b'FORM' and header[8:] == b'AIFF'
        declared = struct.unpack('>I', header[4:8])[0] + 8
        assert declared == path.stat().st_size
        while f.tell() + 8 <= declared:
            position = f.tell(); h = f.read(8)
            name, size = h[:4].decode('ascii'), struct.unpack('>I',h[4:])[0]
            chunks.append({'id':name,'header_offset':position,'data_bytes':size})
            f.seek(size + size % 2, 1)
    return {'container':'AIFF','declared_container_bytes':declared,'chunks':chunks}

def pitch_frame(y, sr, t):
    lo, hi = round((t - .04) * sr), round((t + .04) * sr)
    x = y[lo:hi].astype(np.float64); x -= x.mean()
    window = np.hanning(len(x)); z = x * window
    nfft = 1 << (2 * len(z) - 1).bit_length()
    fft = np.fft.rfft(z, nfft)
    ac = np.fft.irfft(fft * np.conj(fft), nfft)[:150]
    wf = np.fft.rfft(window, nfft)
    overlap = np.fft.irfft(wf * np.conj(wf), nfft)[:150]
    ac /= overlap; ac /= ac[0]
    # This broad 300–1500 Hz search has no expected-note input.
    lower, upper = int(sr / 1500), int(sr / 300)
    peaks = [k for k in range(lower + 1, upper) if ac[k-1] < ac[k] >= ac[k+1]]
    assert peaks, 'No periodic fundamental found'
    best = max(ac[k] for k in peaks)
    # First sufficiently strong periodic maximum avoids octave-down subharmonics.
    candidates = [k for k in peaks if ac[k] > .92 * best and ac[k] > .6]
    assert candidates, 'No reliable periodic maximum'
    k = candidates[0]
    delta = .5 * (ac[k-1] - ac[k+1]) / (ac[k-1] - 2*ac[k] + ac[k+1])
    hz = sr / (k + delta)
    midi = 69 + 12 * math.log2(hz / 440)
    return {'center_seconds':float(t),'frequency_hz':float(hz),
            'independent_midi_float':float(midi),'nearest_midi':round(midi),
            'periodicity':float(ac[k]),'rms':float(np.sqrt(np.mean(x*x)))}

def main():
    download = json.loads((P / 'download_report.json').read_text())
    assert download['complete'] and download['actual_total_bytes'] <= 7_000_000
    results = []
    for layer in ['pp','mf']:
        f = P / f'Flute.vib.{layer}.C5B5.aiff'
        source_record = next(x for x in download['files'] if x['filename'] == f.name)
        assert hashlib.sha256(f.read_bytes()).hexdigest() == source_record['sha256']
        parameters, raw = read_source(f); sr = parameters.framerate
        y = np.frombuffer(raw, dtype='>i2').astype(np.float32) / 32768
        hop = 441
        padded = np.pad(y, (0, (-len(y)) % hop))
        rms = np.sqrt(np.mean(padded.reshape(-1, hop)**2, axis=1))
        del padded
        noise = float(np.quantile(rms,.15))
        threshold = max(float(rms.max())*.035, noise*8, .00006)
        mask = rms > threshold
        spans = []; start = None; last = None
        for i, value in enumerate(mask):
            if value:
                if start is None: start = i
                last = i
            elif start is not None and i-last >= 8:
                if last-start >= 20: spans.append((start,last+1))
                start = None; last = None
        if start is not None and last-start >= 20: spans.append((start,last+1))
        assert len(spans) == 12, (layer,'Unexpected segment count',len(spans))
        notes = []
        for j, (a,b) in enumerate(spans):
            midi = 72+j; expected = 440 * 2**((midi-69)/12)
            lo, hi = a*hop, min(len(y),b*hop)
            onset, ending = lo/sr, hi/sr
            # Extend the coarse voiced region to quiet attack/tail energy, bounded
            # within its own separated note. Then retain 40 ms pre-onset and
            # 120 ms after this lower-threshold tail. Exact PCM is cropped later.
            low_threshold = max(noise*2, float(rms[a:b].max())*.01)
            early = max(0,a-20); late = min(len(rms),b+25)
            previous_end = spans[j-1][1] if j else 0
            next_start = spans[j+1][0] if j+1<len(spans) else len(rms)
            early = max(early,previous_end+12 if j else 0)
            late = min(late,next_start-8 if j+1<len(spans) else len(rms))
            low_start = lo; low_end = hi; quiet = 0
            for i in range(a, early-1, -1):
                if rms[i] > low_threshold:
                    low_start = i*hop; quiet = 0
                else:
                    quiet += 1
                    if quiet >= 3: break
            quiet = 0
            for i in range(b-1, late):
                if rms[i] > low_threshold:
                    low_end = min(len(y),(i+1)*hop); quiet = 0
                else:
                    quiet += 1
                    if quiet >= 3: break
            crop_start = max(0,low_start-round(.04*sr))
            crop_end = min(len(y),low_end+round(.12*sr))
            windows = []; all_frames = []
            for fraction in [.25,.5,.75]:
                center = onset + (ending-onset)*fraction
                assert center-.24 > onset and center+.24 < ending
                frames = [pitch_frame(y,sr,t) for t in np.linspace(center-.2,center+.2,17)]
                cents = np.array([(x['independent_midi_float']-midi)*100 for x in frames])
                assert all(x['nearest_midi']==midi for x in frames), (layer,midi,'Pitch order mismatch')
                assert min(x['periodicity'] for x in frames)>.9, (layer,midi,'Low periodicity')
                assert min(x['rms'] for x in frames)>threshold, (layer,midi,'Unvoiced window')
                for x,c in zip(frames,cents): x['deviation_cents']=float(c)
                windows.append({'body_fraction':fraction,'span_seconds':[center-.24,center+.24],
                                'median_deviation_cents':float(np.median(cents)),
                                'mean_deviation_cents':float(np.mean(cents)),
                                'min_deviation_cents':float(cents.min()),
                                'max_deviation_cents':float(cents.max()),
                                'p05_p95_cents':[float(x) for x in np.quantile(cents,[.05,.95])],
                                'min_periodicity':min(x['periodicity'] for x in frames),
                                'frames':frames})
                all_frames.extend(frames)
            centers = [x['median_deviation_cents'] for x in windows]
            central = float(np.median(centers)); center_span=float(np.ptp(centers))
            assert abs(central)<30, (layer,midi,'Correction exceeds small-detuning bound')
            # No claim that natural vibrato is flat: retain all variation in PCM.
            tune=round(-central,2) if center_span<=15 else 0.0
            observed = [x['deviation_cents'] for x in all_frames]
            notes.append({'midi':midi,'name':NOTE_NAMES[j], 'expected_frequency_hz':expected,
                          'active_start_frame':lo,'active_end_frame':hi,'active_seconds':(hi-lo)/sr,
                          'low_threshold_start_frame':low_start,'low_threshold_end_frame':low_end,
                          'crop_start_frame':crop_start,'crop_end_frame':crop_end,
                          'low_threshold_rms':low_threshold,
                          'pre_onset_seconds':(low_start-crop_start)/sr,
                          'post_tail_seconds':(crop_end-low_end)/sr,
                          'crop_duration_seconds':(crop_end-crop_start)/sr,
                          'three_window_median_deviation_cents':central,
                          'central_frequency_hz':expected*2**(central/1200),
                          'window_center_spread_cents':center_span,
                          'measured_vibrato_and_drift_peak_to_peak_cents':max(observed)-min(observed),
                          'instantaneous_cents_range': [min(observed),max(observed)],
                          'tune_cents':tune,'central_tuning_reliable_within_15_cent_window_spread':center_span<=15,
                          'independent_nearest_midi_set':sorted(set(x['nearest_midi'] for x in all_frames)),
                          'body_rms':float(np.sqrt(np.mean(y[lo:hi]**2))),
                          'peak_sample':int(np.max(np.abs(y[lo:hi]))*32768),
                          'windows':windows})
        for a,b in zip(notes,notes[1:]):
            assert a['crop_end_frame'] < b['crop_start_frame'], 'Crops must be separate'
        result={'layer':layer,'source_file':f.name,'sha256':source_record['sha256'],
                'sample_rate':sr,'channels':parameters.nchannels,'bits':parameters.sampwidth*8,
                'pcm_byte_order':'big endian','compression':'NONE','frame_count':parameters.nframes,
                'duration_seconds':len(y)/sr,'actual_header':inspect_chunks(f),
                'noise_rms_15th_percentile':noise,'segmentation_threshold_rms':threshold,
                'analysis_hop_seconds':hop/sr,'detected_notes':len(notes),'notes':notes}
        results.append(result)
        print(layer,'notes',len(notes),'active seconds',[round(n['active_seconds'],2) for n in notes],flush=True)
        print(layer,'SFZ corrections cents',[n['tune_cents'] for n in notes],flush=True)
        del y,raw
    report={'method':{
        'segmentation':'10 ms RMS; threshold=max(3.5% peak RMS, 8x 15th-percentile RMS, 0.00006); gaps under 80 ms joined; segments shorter than 200 ms ignored; require exactly 12 separated notes per scale.',
        'pitch':'Three post-attack/pre-release body windows at 25%, 50%, 75%; 17 centered 80 ms Hann frames spanning 480 ms per window. Window-overlap-corrected autocorrelation, broad 300–1500 Hz search without expected-pitch constraint; first sufficiently strong periodic peak, parabolic lag interpolation. Every frame independently rounds to the expected MIDI note.',
        'tuning':'Negative median of the three window medians, rounded to 0.01 cents as metadata only. Precision of metadata is not a claim of 0.01-cent estimator accuracy. No correction if the three medians span more than 15 cents.',
        'stability':'Stable means voiced post-attack/pre-release periodic windows, not a flat pitch. Natural vibrato, amplitude variation, and drift are preserved. No sustain loops or artificial legato.',
        'crop':'Extend the coarse region at max(2x noise RMS, 1% local peak RMS) until 30 ms consecutive quiet, within 200 ms before and 250 ms after the coarse boundaries. Retain this quiet attack/tail plus 40 ms pre-onset and 120 ms post-tail. Preserve exact original integer PCM values; WAV changes only container and endian order.'},
        'layers':results,
        'execution':{'elapsed_seconds':time.monotonic()-START,
                     'peak_rss_mib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss/1024,
                     'virtual_memory_limit_mib':150,'cpu_seconds_limit':90,'cpu_affinity':sorted(os.sched_getaffinity(0))}}
    (P/'scale_analysis.json').write_text(json.dumps(report,indent=2)+'\n')
    print('Analysis resource use:',report['execution'],flush=True)

if __name__=='__main__': main()
