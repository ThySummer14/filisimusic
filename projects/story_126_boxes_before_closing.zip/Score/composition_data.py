"""126. Original through-worked market rondo. Nominal score, no audio offsets."""
from copy import deepcopy
ID=126;TITLE='Boxes Before Closing';TITLE_ZH='收摊前的纸箱'
RENDERER_NOTES='Piano, clarinet C4–B4, cello pizzicato C2–B2 only. Clarinet has explicit gaps; no sustained cello or legato claim. Keep the 7/8 corner and two empty-bar turns intact.'
H={'Eb':[39,55,58,62],'Bb':[46,53,58,62],'Cm':[36,55,60,63],'Ab':[44,51,56,60],'Fm':[41,53,56,60],'G7':[43,53,59,62],'Bb7':[46,56,60,62],'Eb/G':[43,55,58,63],'Ab6':[44,53,56,60],'Cm9':[36,50,55,63],'Db':[37,53,56,61],'Gsus':[43,55,60,62]}
# Every cell is an authored four-bar phrase; the second four-bar answer has its own cadence.
ROWS=[
('Opening',108,4,'boxes','Eb Bb Cm Bb7','Eb5:1 G5:1 R:1 Bb5:1 G5:2 Eb5:2|F5:1 D5:1 R:1 F5:1 Bb5:1 A5:1 F5:2|G5:1 Eb5:1 C5:2 R:1 G5:1 Eb5:2|D5:1 F5:1 Ab5:1 F5:1 D5:2 R:2', 'Ab Eb/G Fm Bb7','C6:1 Ab5:1 G5:2 Eb5:1 G5:1 R:2|Bb5:1 G5:1 Eb5:1 G5:1 Bb5:2 G5:2|Ab5:2 F5:1 C5:1 Eb5:1 F5:1 R:2|D5:1 F5:1 Bb5:2 R:4'),
('A',116,4,'aisle','Eb Cm Ab Bb','Eb5:2 G5:1 F5:1 Bb5:1 G5:1 F5:2|Eb5:1 G5:1 C6:2 Bb5:1 G5:1 Eb5:2|Ab5:1 C6:1 Bb5:1 Ab5:1 G5:2 Eb5:2|F5:1 D5:1 Bb4:2 R:1 F5:1 D5:2','Eb/G Fm Bb7 Eb','G5:1 Bb5:1 Eb6:2 D6:1 Bb5:1 G5:2|Ab5:1 G5:1 F5:2 C5:1 Eb5:1 F5:2|F5:1 Ab5:1 D6:1 C6:1 Bb5:2 Ab5:2|G5:2 Eb5:1 Bb4:1 R:2 Eb5:2'),
('A_answer',116,4,'countercart','Cm Ab Fm Bb7','G5:1 C6:1 Bb5:2 G5:1 Eb5:1 D5:2|Eb5:1 Ab5:1 G5:1 Eb5:1 C5:2 R:2|C5:1 F5:1 Ab5:2 G5:1 F5:1 Eb5:2|D5:2 F5:1 Ab5:1 Bb5:1 F5:1 R:2','Eb Ab Bb7 Eb','Bb5:1 G5:1 Eb5:2 F5:1 G5:1 Bb5:2|C6:1 Ab5:1 F5:1 Eb5:1 C5:2 Eb5:2|D5:1 F5:1 Ab5:1 Bb5:1 D6:2 C6:2|Bb5:1 G5:1 Eb5:2 R:4'),
('Corner',124,3.5,'seven','Cm G7 Ab Bb','C5:1 G5:1 Eb5:1 D5:2 C5:2|B4:1 D5:1 G5:1 F5:1 D5:1 R:2|C5:1 Eb5:1 Ab5:2 G5:1 Eb5:2|D5:1 F5:1 Bb5:1 Ab5:1 F5:1 D5:2','Cm Fm G7 Cm','G5:1 Eb5:1 C5:2 D5:1 Eb5:2|F5:1 Ab5:1 C6:1 Bb5:1 Ab5:1 F5:2|B5:1 G5:1 F5:1 D5:2 B4:2|C5:2 G4:1 C5:2 R:2'),
('Narrow_turn',124,3.5,'seven','Ab Db Fm G7','Eb5:1 Ab5:1 C6:1 Bb5:2 Ab5:2|F5:1 Db5:1 Ab4:2 C5:1 Db5:2|C5:1 F5:1 Ab5:1 G5:1 F5:1 Eb5:2|D5:1 B4:1 G4:1 B4:1 D5:1 R:2','Cm Ab Gsus G7','Eb5:1 G5:1 C6:2 Bb5:1 G5:2|C6:1 Ab5:1 Eb5:2 C5:1 Eb5:2|D5:1 G5:1 C6:1 B5:1 G5:1 D5:2|B4:2 G4:1 R:4'),
('Suspended',82,4,'empty','Cm Cm Ab G7','R:2 G4:2 C5:1 Eb5:1 R:2|R:8|Eb5:2 C5:1 Ab4:1 R:2 Eb5:2|D5:1 B4:1 R:2 G4:2 R:2','Cm Fm G7 Cm','G4:2 C5:1 Eb5:1 G5:2 R:2|Ab5:2 F5:2 C5:2 R:2|B4:1 D5:1 F5:2 R:4|C5:2 R:6'),
('Shared_load',110,4,'relay','Ab Eb/G Fm Bb7','Ab4:1 C5:1 Eb5:2 F5:1 Eb5:1 C5:2|Bb4:1 Eb5:1 G5:2 F5:1 Eb5:1 Bb4:2|C5:1 F5:1 Ab5:2 G5:1 F5:1 C5:2|D5:2 F5:1 Ab5:1 Bb5:2 R:2','Eb Cm Fm Bb','G5:1 Eb5:1 Bb4:2 G4:1 Bb4:1 Eb5:2|Eb5:1 G5:1 C6:2 Bb5:1 G5:1 Eb5:2|F5:1 C5:1 Ab4:1 C5:1 Eb5:2 F5:2|F5:2 D5:1 Bb4:1 R:2 F5:2'),
('Joined_stride',110,4,'relay','Eb/G Ab Bb7 Cm','G5:2 Bb5:1 G5:1 Eb5:1 F5:1 G5:2|Ab5:1 C6:1 Eb6:2 C6:1 Ab5:1 G5:2|F5:1 Bb5:1 Ab5:1 F5:1 D5:2 R:2|Eb5:1 G5:1 C6:2 G5:1 Eb5:1 C5:2','Ab Fm Bb7 Eb','Ab5:1 G5:1 F5:2 Eb5:1 C5:1 Ab4:2|C5:2 F5:1 Ab5:1 G5:2 F5:2|D5:1 F5:1 Bb5:1 Ab5:1 F5:2 D5:2|Eb5:2 Bb4:2 Eb5:2 R:2'),
('A_rebuilt',124,4,'braid','Eb Cm Ab Bb','Eb5:1 G5:1 Bb5:1 G5:1 F5:1 G5:1 Eb5:2|G5:1 C6:1 Eb6:1 D6:1 C6:2 Bb5:2|C6:1 Ab5:1 Eb5:1 F5:1 Ab5:2 G5:2|Bb5:1 F5:1 D5:1 F5:1 Ab5:2 F5:2','Eb/G Fm Bb7 Eb','G5:1 Bb5:1 Eb6:1 D6:1 Bb5:1 G5:1 Eb5:2|F5:1 Ab5:1 C6:1 Bb5:1 Ab5:1 G5:1 F5:2|F5:1 Bb5:1 D6:1 C6:1 Bb5:2 Ab5:2|G5:2 Eb5:1 Bb4:1 Eb5:2 R:2'),
('Last_round',124,4,'braid','Cm Ab Fm G7','C6:1 G5:1 Eb5:1 G5:1 C6:2 Bb5:2|C6:1 Ab5:1 G5:1 F5:1 Eb5:2 C5:2|Ab5:1 F5:1 C5:1 F5:1 Ab5:2 G5:2|B5:1 G5:1 F5:1 D5:1 B4:2 R:2','Cm Ab Bb7 Eb','G5:1 C6:1 Eb6:2 D6:1 C6:1 Bb5:2|C6:1 Ab5:1 Eb5:1 Ab5:1 C6:2 Bb5:2|D6:1 Bb5:1 Ab5:1 F5:1 D5:2 F5:2|Eb5:1 G5:1 Bb5:2 R:4'),
('Final_stack',136,4,'stack','Ab Bb Cm Eb/G','Ab5:1 C6:1 Eb6:1 C6:1 Ab5:1 G5:1 F5:2|Bb5:1 D6:1 F6:1 D6:1 Bb5:1 Ab5:1 F5:2|C6:1 Eb6:1 G6:1 Eb6:1 C6:1 Bb5:1 G5:2|Bb5:1 Eb6:1 G6:2 F6:1 Eb6:1 Bb5:2','Ab Fm Bb7 Eb','C6:1 Ab5:1 F5:1 Eb5:1 C5:2 Ab4:2|F5:1 Ab5:1 C6:2 Bb5:1 Ab5:1 F5:2|D6:1 Bb5:1 F5:1 D5:1 R:4|Eb5:2 G5:1 Bb5:1 Eb6:2 R:2'),
('Doors_open',104,4,'firm_end','Eb Ab Eb/G Bb7','Eb5:1 G5:1 R:1 Bb5:1 G5:2 Eb5:2|C6:1 Ab5:1 G5:2 Eb5:1 C5:1 Ab4:2|Bb4:1 Eb5:1 G5:2 F5:1 Eb5:1 Bb4:2|D5:1 F5:1 Ab5:2 F5:2 R:2','Cm Ab Bb7 Eb','G5:1 Eb5:1 C5:2 G4:1 C5:1 Eb5:2|Ab5:2 Eb5:1 C5:1 Ab4:2 C5:2|Bb4:1 D5:1 F5:1 Ab5:1 D6:2 R:2|Eb5:2 Bb4:1 G4:1 Eb4:2 R:2')]
REV1={25:('Cm9','R:1 Eb5:1 G5:1 Bb5:1 G5:1 Eb5:2'),26:('G7','B4:1 D5:1 F5:2 G5:1 R:2'),27:('Ab6','C5:1 F5:1 Ab5:1 G5:1 Eb5:1 C5:2'),28:('Bb7','D5:1 Ab5:1 F5:1 D5:2 R:2'),29:('Cm','G5:1 C6:1 Bb5:1 G5:1 Eb5:1 C5:2'),30:('Fm','Ab5:1 C6:1 Bb5:1 Ab5:2 F5:2'),31:('Gsus','D5:1 G5:1 C6:1 B5:1 G5:1 R:2'),32:('G7','F5:1 D5:1 B4:1 G4:2 R:2')}
REV2={81:('Ab6','C6:1 Ab5:1 F5:1 Eb5:1 Ab5:1 C6:1 Eb6:2'),82:('Bb7','D6:1 Bb5:1 Ab5:1 F5:1 Bb5:1 D6:1 F6:2'),83:('Cm9','Eb6:1 D6:1 C6:1 G5:1 Bb5:1 C6:1 Eb6:2'),84:('Eb/G','G6:2 Eb6:1 Bb5:1 G5:1 F5:1 Eb5:2'),85:('Ab','C6:1 Ab5:1 Eb5:1 C5:1 R:4'),86:('Fm','R:2 C5:1 F5:1 Ab5:1 C6:1 Ab5:2'),87:('Bb7','D6:1 C6:1 Bb5:1 Ab5:1 F5:2 R:2'),88:('Eb','G5:1 Bb5:1 Eb6:2 Bb5:1 G5:1 Eb5:2'),95:('Bb7','F5:1 D5:1 Bb4:2 R:1 D5:1 F5:2'),96:('Eb','Eb5:1 Bb4:1 G4:2 Eb4:2 R:2')}
def pitch(s):return 12*(int(s[-1])+1)+{'C':0,'D':2,'E':4,'F':5,'G':7,'A':9,'B':11}[s[0]]+s[1:-1].count('#')-s[1:-1].count('b')
def build(level):
 bars=[];events=[];pedals=[];start=0;num=0
 for sec,bpm,beats,texture,hs,a,hs2,b in ROWS:
  for h,line in zip((hs+' '+hs2).split(),(a+'|'+b).split('|')):
   num+=1
   for lv,rv in [(1,REV1),(2,REV2)]:
    if level>=lv and num in rv:h,line=rv[num]
   chord=H[h];dyn={'boxes':89,'aisle':79,'countercart':83,'seven':87,'empty':51,'relay':73,'braid':91,'stack':101,'firm_end':84}[texture]
   bars.append(dict(bar=num,start=start,beats=beats,bpm=bpm,meter_numerator=7 if beats==3.5 else 4,meter_denominator=8 if beats==3.5 else 4,section=sec,harmony_name=h,harmony=chord))
   def add(p,t,d,v,inst,voice,hand='none',art='detached'):
    if d>0:events.append(dict(bar=num,onset=round(start+t,6),duration=round(min(d,beats-t),6),pitch=int(p),velocity=int(v),instrument=inst,voice=voice,hand=hand,articulation=art))
   t=0;wind=(texture in ('relay','countercart') and num%2==0);wind_notes=[]
   for j,tok in enumerate(line.split()):
    p,u=tok.split(':');dur=int(u)/2
    if p!='R':
     q=pitch(p)
     if wind:wind_notes.append(q)
     else:add(q,t,max(.12,dur-.09),dyn,'piano','theme','right')
    t+=dur
   assert abs(t-beats)<1e-7,(num,t,beats)
   if wind and wind_notes:
    for q,t,d in zip([wind_notes[0],wind_notes[len(wind_notes)//2],wind_notes[-1]],[.25,1.5,2.75],[1,.9,.85]):add(60+q%12,t,d,dyn-7,'clarinet','breathed_answer')
   if texture=='empty':
    if num not in (42,48):add(chord[0],0,.7,dyn-11,'piano','isolated_foot','left')
    if num in (43,45,47):add(60+chord[2]%12,2.5,.85,52,'clarinet','across_empty_aisle')
   else:
    # Upper rhythm and lower hand form one staggered pattern, never two unrelated loops.
    ts={'boxes':[0,1.5,3],'aisle':[0,2.5],'countercart':[0,.75,2.5],'seven':[0,1.5,2.5],'relay':[0,2],'braid':[0,1.5,3],'stack':[0,1,2.5],'firm_end':[0,1.5,3]}[texture]
    if level>=1 and 25<=num<=32:ts=[.5,1.5,2.75]
    if num in (8,24,40,80,87):ts=[0]
    for j,t in enumerate(ts):
     if t<beats-.1:add(chord[0]+(12 if j%2 else 0),t,.32,dyn-24,'piano','box_step','left')
    if num%4 in (1,3) and texture in ('boxes','aisle','braid','firm_end'):add(chord[1],1,.30,dyn-29,'piano','hinge','left')
    if texture in ('relay','braid','stack','firm_end') and num%4!=0:
     ct=1.25 if texture=='relay' else .75
     add(36+chord[0]%12,ct,.72,72,'cello','single_plucked_reply',art='pizzicato')
    if texture in ('boxes','aisle','braid') and num%4==0:
     add(60+chord[-1]%12,2.1,.72,67,'clarinet','short_call');add(60+chord[2]%12,3.1,.72,62,'clarinet','short_answer')
    if level>=2 and 81<=num<=88:
     # The final stack becomes a relay, not fortissimo doubling.
     if num%2: add(60+chord[2]%12,2.75,.75,79,'clarinet','stack_pass')
     if num==85: add(36+chord[0]%12,2.75,.72,73,'cello','caught_box',art='pizzicato')
   pedals.append(dict(bar=num,onset=start,controller=64,value=0,instrument='piano'))
   if texture in ('relay','empty') and num not in (42,48):
    pedals.extend([dict(bar=num,onset=start+.04,controller=64,value=34,instrument='piano'),dict(bar=num,onset=start+.72,controller=64,value=0,instrument='piano')])
   start+=beats
 pedals.append(dict(bar=num,onset=start-.01,controller=64,value=0,instrument='piano'))
 return dict(id=ID,title=TITLE,title_zh=TITLE_ZH,version=f'v{level}',bars=bars,events=events,pedals=pedals,total_beats=start,tail_seconds=5,instrument_map={'piano':'piano','clarinet':'clarinet','cello':'pizz'})
