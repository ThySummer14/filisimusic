#!/usr/bin/env python3
"""Work 64: original score-only composition. Pure Python; no audio/rendering tools."""
from pathlib import Path
from copy import deepcopy
import json, math, hashlib
ROOT = Path(__file__).resolve().parent

# Each row is independently selected for the dramatic and harmonic route.
# Chord pitch classes determine both accompaniment and the melodic spelling.
H = {
 'Ebm': ('降E小调：i', [39,54,58,63,66],39,[54,58],[63,66]),
 'Ebm9': ('降E小调：i(add9)', [39,53,54,58,63,65],39,[53,58],[63,65]),
 'Cb': ('旧星色：降VI / C♭大三和弦', [47,54,59,63,66],47,[54,59],[63,66]),
 'Abm': ('iv / A♭小三和弦', [44,56,59,63,68],44,[56,59],[63,68]),
 'Gb': ('III / G♭大三和弦', [42,54,58,61,66],42,[54,58],[61,66]),
 'Db': ('降VII / D♭大三和弦', [49,53,56,61,65],49,[53,56],[61,65]),
 'Bbsus': ('V7(sus4)：暂不露出导音', [46,53,56,63,65],46,[53,56],[63,65]),
 'Bb7': ('V7 / B♭属七和弦', [46,56,62,65,68],46,[56,62],[65,68]),
 'Ab': ('路灯色：Dorian IV / A♭大三和弦', [44,56,60,63,68],44,[56,60],[63,68]),
 'Fm': ('路灯色：Dorian ii / F小三和弦', [41,56,60,65,68],41,[56,60],[65,68]),
 'Ebm6': ('i(add6)：C自然音短暂照入井口', [39,54,58,60,63,66],39,[54,60],[60,66]),
 'Ebopen': ('i：末尾开放五度，旋律给出小三度后归根', [39,51,58,63,66],39,[51,58],[63,66]),
}
FOUR = {4,8,12,16,20,28,32,36,40,44,48}
SECTION = [
 ('I 井沿：辨认缺口',54),('II 水下：井口问句变成呼吸',52),
 ('III 路上：灯下归人',56),('IV 提桶：星图只能停留一息',58),
 ('V 松手：把星图还给水',52),('VI 两种夜色：记住而不占有',48)]
KEYS = [
 'Ebm','Cb','Abm','Bbsus','Gb','Db','Abm','Ebm',
 'Ebm','Cb','Abm','Gb','Db','Abm','Bbsus','Ebm',
 'Fm','Ab','Ebm6','Bbsus','Ebm','Cb','Abm','Ebm',
 'Cb','Abm','Gb','Db','Ebm','Cb','Bb7','Ebm',
 'Abm','Ebm','Cb','Bbsus','Abm','Gb','Db','Ebm',
 'Ab','Cb','Ebm6','Abm','Ebm','Cb','Bbsus','Ebopen']
PIANO_LEAD = set(range(1,9)) | set(range(17,21)) | set(range(33,37)) | set(range(41,45)) | {47,48}
# bar -> local quarterbeat, sounding duration in quarterbeats, pitch, velocity.
# The main question is E♭-G♭-F-D♭, then E♭-B♭-A♭-G♭; its cadence is F-E♭-D♭-E♭.
P = {
 1:[(.25,.72,63,52),(1.18,.66,66,56),(2.06,.70,65,51)],
 2:[(.12,1.02,61,48),(1.55,1.10,63,50)],
 3:[(.22,.77,63,49),(1.25,.65,70,54),(2.14,.60,68,50)],
 4:[(.10,1.15,66,49),(1.70,.80,65,46),(2.83,.80,63,45)],
 5:[(.24,.76,65,49),(1.24,.72,63,47),(2.18,.57,61,44)],
 6:[(.12,1.20,63,46),(1.74,.84,65,47)],
 7:[(.23,.68,66,49),(1.15,.64,65,47),(2.05,.63,63,45)],
 8:[(.08,1.22,61,43),(1.70,1.03,63,42)],
 17:[(.25,.75,65,53),(1.23,.67,68,55),(2.15,.65,71,57)],
 18:[(.10,.89,70,52),(1.30,.72,68,51),(2.20,.57,66,48)],
 19:[(.25,.73,65,49),(1.22,.68,66,52),(2.16,.65,68,54)],
 20:[(.12,1.16,65,50),(1.76,1.07,63,48)],
 33:[(.24,.75,68,47),(1.22,.69,66,45),(2.16,.61,63,44)],
 34:[(.12,1.13,65,46),(1.66,.99,63,43)],
 35:[(.22,.74,66,45),(1.23,.68,65,43),(2.18,.56,63,41)],
 36:[(.10,1.10,61,41),(1.68,1.00,63,39)],
 41:[(.24,.76,63,43),(1.26,.69,66,46),(2.20,.59,65,42)],
 42:[(.10,1.09,61,40),(1.65,1.00,63,41)],
 43:[(.24,.75,63,42),(1.25,.70,70,47),(2.18,.57,68,43)],
 44:[(.12,1.13,66,42),(1.73,1.03,65,40)],
 47:[(.25,.75,65,39),(1.24,.72,63,37),(2.20,.58,61,35)],
 48:[(.14,2.00,63,38)]}
# One phrase spans exactly two bars. Same pp or mf layer throughout a phrase.
PHRASES = [
 (9,[75,78,77,73],'pp','第一次从水面认出四颗星'),
 (11,[75,82,80,78],'pp','视线顺着星座边缘上行，再回落'),
 (13,[77,75,73,75],'pp','井口问句第一次得到不完整的答复'),
 (15,[78,77,75,75],'pp','水面合拢；最后同音是克制的停留'),
 (21,[75,78,80,78],'mf','手触到桶沿，井声短暂有了重量'),
 (23,[77,75,73,75],'mf','熟悉答句托住第一次提起'),
 (25,[75,78,77,73],'mf','星图升起，尚未意识到倒置'),
 (27,[75,82,80,78],'mf','又一次向高处寻找星星'),
 (29,[77,75,73,75],'mf','问句继续向岸上走'),
 (31,[78,77,75,75],'mf','接近桶沿时收束'),
 (37,[80,78,75,73],'pp','水桶回落；星星并非可以带走的物件'),
 (39,[77,75,73,75],'pp','把最后一颗星放回原处'),
 (45,[75,78,77,73],'pp','记忆中的问句仍留着缺口')]


def make_bars(version):
    out=[]; start=0.0
    keys=KEYS[:]
    if version==0:
        keys[16:20]=['Abm','Gb','Ebm','Bbsus']
        keys[40:44]=['Ebm','Cb','Abm','Bbsus']
    if version==1:
        keys[40:44]=['Ebm','Cb','Abm','Bbsus']
    for n,key in enumerate(keys,1):
        sec,bpm=SECTION[(n-1)//8]; beats=4 if n in FOUR else 3
        lead='piano' if n in PIANO_LEAD else 'flute'
        role=('钢琴右手叙述；左手低音与短和弦接续；长笛休息' if lead=='piano' else '长笛唯一前景；钢琴左手低音后接同和声双音，右手仅在句内到达点放置静态双音')
        out.append(dict(bar=n,start=start,beats=beats,bpm=bpm,section=sec,meter_numerator=beats,meter_denominator=4,harmony_name=H[key][0],harmony=H[key][1][:],role_plan=role,lead_instrument=lead))
        start+=beats
    return out,keys,start


def build(version):
    bars,keys,total=make_bars(version); events=[]; pedals=[]; entry=[]
    def add(bar,loc,dur,pitch,vel,voice,inst='piano'):
        events.append(dict(bar=bar,onset=round(bars[bar-1]['start']+loc,6),duration=dur,pitch=pitch,velocity=vel,voice=voice,instrument=inst))
    p=deepcopy(P)
    if version>=1:
        # Substantive revision 1: a human street-level viewpoint, not another echo.
        p[17]=[(.25,.75,65,53),(1.28,.70,68,56),(2.22,.53,72,57)]
        p[18]=[(.10,1.00,70,53),(1.45,.62,68,51),(2.32,.48,67,49)]
        p[19]=[(.22,.78,66,50),(1.28,.67,65,49),(2.20,.57,63,47)]
        p[20]=[(.12,1.05,65,48),(1.65,1.12,63,45)]
    if version>=2:
        # Substantive revision 2: the two skies coexist, separated by real silence.
        p[41]=[(.24,.76,63,43),(1.26,.69,68,46),(2.20,.59,72,45)]
        p[42]=[(.10,.96,71,43),(1.45,1.08,66,40)]
        p[43]=[(.24,.92,65,42),(1.64,1.08,63,39)]
        p[44]=[(.12,1.11,63,39),(1.68,.88,61,37)]
        p[47]=[(.60,.79,65,38),(1.85,.92,63,36)]
        p[48]=[(.14,2.65,63,34)]
    for bar,seq in p.items():
        for loc,dur,pitch,vel in seq: add(bar,loc,dur,pitch,vel,'melody')
    ph=deepcopy(PHRASES)
    if version>=1:
        for i,row in enumerate(ph):
            if row[0]==25: ph[i]=(25,[83,82,80,78],'mf','星图刚离水就倒转；由唯一最高音逐步下落')
            if row[0]==27: ph[i]=(27,[77,78,75,73],'mf','不再复述井口问句，开始寻找桶里的星位')
            if row[0]==29: ph[i]=(29,[75,77,78,80],'mf','短暂上提，最后一次想留住它')
            if row[0]==31: ph[i]=(31,[78,77,75,73],'mf','重力把音形带回井口；句末停在降七级')
    if version>=2:
        for i,row in enumerate(ph):
            if row[0]==37: ph[i]=(37,[80,78,77,75],'pp','沿同一条下行线松开绳，避免跳散')
            if row[0]==39: ph[i]=(39,[77,75,73,73],'pp','不提前给出主音，留给结尾的选择')
            if row[0]==45: ph[i]=(45,[75,78,73,75],'pp','记得问句，却把旧来的末端F-D♭改为D♭-E♭，第一次主动归根')
    phrase_records=[]
    for idx,(first,pitches,layer,intent) in enumerate(ph,1):
        locs=[(first,.65,.80),(first,1.95,.65),(first+1,.20,.75),(first+1,1.50,.80)]
        if version>=2 and first in (37,39):
            locs=[(first,.65,.78),(first,1.95,.66),(first+1,.20,.72),(first+1,1.45,.78)]
        if version>=2 and first==45:
            locs=[(first,.65,.78),(first,1.95,.66),(first+1,.20,.72),(first+1,1.55,1.08)]
        velocities=([40,43,41,37] if layer=='pp' else [65,69,66,61])
        if first==25 and version>=1: velocities=[72,70,66,63]
        if first==45 and version>=2: velocities=[36,39,35,33]
        ids=[]
        for j,((bar,loc,dur),pitch,vel) in enumerate(zip(locs,pitches,velocities)):
            add(bar,loc,dur,pitch,vel,'flute','flute')
            ids.append((bar,bars[bar-1]['start']+loc,pitch))
            entry.append(dict(phrase_id=f'F{idx:02d}',bar=bar,pitch=pitch,layer=layer,target_pitched_arrival=round(bars[bar-1]['start']+loc,6),alignment=('first note: coincide with piano upper_support arrival' if j==0 else 'third note: coincide with piano upper_support arrival' if j==2 else 'continue the same breathing line; no new piano foreground'),advance_policy='Score onset is the intended voiced arrival. Integrator must measure this exact Iowa pitch and layer, then advance MIDI by that latency; do not use a fixed global offset.',intent=intent))
        phrase_records.append(dict(id=f'F{idx:02d}',bars=[first,first+1],layer=layer,pitches=pitches,intent=intent,entries=[list(x) for x in ids]))
    # Low note and dyad are deliberately separated so the left hand can reposition.
    # Static right-hand support never accompanies a separate piano melody.
    for b,key in zip(bars,keys):
        n=b['bar']; h=H[key]; bass,chord,rh=h[2:]
        end_section=n in {8,16,24,32,40,48}
        sparse=n in {8,16,20,24,36,40,44,48}
        base=40 if n<=16 else 45 if n<=32 else 36
        if b['lead_instrument']=='flute': base-=4
        bassdur=.45
        if not (version>=2 and n in {34,36,38,40,43}):
            add(n,0,bassdur,bass,base,'bass')
        # v1 removes a second unnecessary chord attack in the lifting section;
        # v2 thins the lower register on release, while retaining common tones.
        chordloc=1.10 if n%2 else 1.00
        chorddur=1.12 if not sparse else 1.45
        chosen=chord[:]
        if version>=2 and n in {34,36,40,44}: chosen=chosen[-1:]
        for q in chosen: add(n,chordloc,chorddur,q,base-3,'accompaniment')
        if version==0 and 25<=n<=32 and not sparse:
            for q in chord: add(n,2.45,.40,q,base-7,'accompaniment')
        if b['lead_instrument']=='flute':
            loc=.65 if n%2 else .20
            # A sustained dyad under a breath, not an independent arpeggio.
            support=rh[:]
            if version>=2 and n in {38,40,46}: support=support[:1]
            for q in support: add(n,loc,.58 if n%2 else .72,q,base-8,'upper_support')
        pedal=34 if n<=16 else 29 if n<=32 else 31
        if n in {41,42}: pedal=22 # no C/C-flat harmonic smear across the two skies.
        pedals.extend([dict(onset=b['start'],value=0),dict(onset=b['start']+.07,value=pedal),dict(onset=b['start']+b['beats']-.18,value=0)])
    if version>=2:
        # Final fifth is a quiet left-hand interval after the bass has released.
        events=[e for e in events if not(e['bar']==48 and e['voice']=='accompaniment')]
        add(48,.80,2.35,51,28,'accompaniment'); add(48,.80,2.35,58,27,'accompaniment')
    events.sort(key=lambda e:(e['onset'],e['instrument'],e['voice'],e['pitch']))
    score=dict(id=64,title='The Well That Remembers Stars',title_zh='记得星星的井',bars=bars,events=events,pedals=sorted(pedals,key=lambda x:x['onset']),total_beats=total,tail_seconds=4)
    return score,phrase_records,entry


def to_seconds(score,beat):
    t=0.0
    for b in score['bars']:
        if beat>=b['start']+b['beats']: t+=b['beats']*60/b['bpm']
        elif beat>b['start']: return t+(beat-b['start'])*60/b['bpm']
        else: return t
    if beat>score['total_beats']: t+=(beat-score['total_beats'])*60/score['bars'][-1]['bpm']
    return t


def audit(score,phrases):
    issues=[]; flute=[e for e in score['events'] if e['instrument']=='flute']; piano=[e for e in score['events'] if e['instrument']=='piano']
    for e in score['events']:
        b=score['bars'][e['bar']-1]
        if not (b['start']<=e['onset'] and e['onset']+e['duration']<=b['start']+b['beats']+1e-7): issues.append(['bar_bounds',e])
        if e['duration']<=0 or not 1<=e['velocity']<=127: issues.append(['invalid_event',e])
        if e['voice'] in ('melody','upper_support') and e['instrument']!='piano': issues.append(['voice_mismatch',e])
        if e['instrument']=='flute' and b['lead_instrument']!='flute': issues.append(['foreground_conflict',e])
        if e['voice']=='melody' and b['lead_instrument']!='piano': issues.append(['foreground_conflict',e])
    max_duration=0
    for e in flute:
        seconds=to_seconds(score,e['onset']+e['duration'])-to_seconds(score,e['onset'])
        max_duration=max(max_duration,seconds)
        if not 72<=e['pitch']<=83: issues.append(['flute_range',e])
        if seconds>1.60+1e-7: issues.append(['flute_gate_seconds',e,seconds])
    phrase_checks=[]; gaps=[]
    for i,p in enumerate(phrases):
        ev=[e for e in flute if e['bar'] in p['bars']]
        layers={'pp' if 21<=e['velocity']<=55 else 'mf' if 56<=e['velocity']<=95 else 'bad' for e in ev}
        if layers!={p['layer']}: issues.append(['mixed_or_invalid_layer',p['id'],list(layers)])
        # Intended pitched arrivals are separated from MIDI gates in the entry map.
        start=min(e['onset'] for e in ev); end=max(e['onset']+e['duration'] for e in ev)
        if i+1<len(phrases):
            ne=[e for e in flute if e['bar'] in phrases[i+1]['bars']]
            gap=to_seconds(score,min(e['onset'] for e in ne))-to_seconds(score,end)
            gaps.append(gap)
            if gap<.60: issues.append(['phrase_breath',p['id'],gap])
        else: gap=None
        same_note_overlap=any(a['pitch']==b['pitch'] and b['onset']<a['onset']+a['duration'] for a,b in zip(ev,ev[1:]))
        if same_note_overlap: issues.append(['flute_overlap',p['id']])
        phrase_checks.append(dict(id=p['id'],bars=p['bars'],layer=p['layer'],velocities=[e['velocity'] for e in ev],pitches=[e['pitch'] for e in ev],span_seconds=round(to_seconds(score,end)-to_seconds(score,start),4),next_phrase_gate_rest_seconds=None if gap is None else round(gap,4),max_adjacent_interval_semitones=max(abs(a['pitch']-b['pitch']) for a,b in zip(ev,ev[1:]))))
    hand_stats={}
    for hand,voices in [('left',{'bass','accompaniment'}),('right',{'melody','upper_support'})]:
        ev=[e for e in piano if e['voice'] in voices]; maxspan=0; maxnotes=0; state=[]
        points=sorted({e['onset'] for e in ev}|{e['onset']+e['duration'] for e in ev})
        for t in points:
            active=[e for e in ev if e['onset']<=t+1e-8 and e['onset']+e['duration']>t+1e-8]
            pitches=[e['pitch'] for e in active]
            span=max(pitches)-min(pitches) if pitches else 0
            maxspan=max(maxspan,span);maxnotes=max(maxnotes,len(active))
            if span>12 or len(active)>4: issues.append(['hand_reach',hand,t,pitches])
        # Adjacent attack groups after previous release; not merely simultaneous span.
        groups=[]
        for onset in sorted({e['onset'] for e in ev}):
            ge=[e for e in ev if e['onset']==onset];groups.append((onset,ge))
        min_large_jump_gap=None; largest_jump=0
        for (ta,a),(tb,b) in zip(groups,groups[1:]):
            ae=max(x['onset']+x['duration'] for x in a)
            dist=max(abs(sum(x['pitch'] for x in a)/len(a)-sum(x['pitch'] for x in b)/len(b)),0)
            largest_jump=max(largest_jump,dist)
            if dist>=12 and tb>=ae:
                gap=to_seconds(score,tb)-to_seconds(score,ae)
                min_large_jump_gap=gap if min_large_jump_gap is None else min(min_large_jump_gap,gap)
                if gap<.35: issues.append(['large_hand_reposition_too_short',hand,ta,tb,dist,gap])
        hand_stats[hand]=dict(voices=sorted(voices),pitch_range=[min(e['pitch'] for e in ev),max(e['pitch'] for e in ev)],max_simultaneous_notes=maxnotes,max_simultaneous_span_semitones=maxspan,largest_attack_group_centroid_shift_semitones=round(largest_jump,3),min_release_gap_before_12plus_semitone_shift_seconds=None if min_large_jump_gap is None else round(min_large_jump_gap,4))
    # Melody and flute never overlap as competing foregrounds, including bar boundaries.
    leads=sorted([e for e in score['events'] if e['voice'] in ('melody','flute')],key=lambda e:e['onset'])
    for i,a in enumerate(leads):
        for b in leads[i+1:]:
            if b['onset']>=a['onset']+a['duration']-1e-7:break
            if a['instrument']!=b['instrument']: issues.append(['cross_foreground_overlap',a,b])
    secs=to_seconds(score,score['total_beats'])
    return dict(status='PASS' if not issues else 'FAIL',issues=issues,bars=len(score['bars']),total_quarterbeats=score['total_beats'],duration_seconds_without_tail=round(secs,6),duration_seconds_with_tail=round(secs+score['tail_seconds'],6),events=len(score['events']),flute_events=len(flute),piano_events=len(piano),flute_range=[min(e['pitch'] for e in flute),max(e['pitch'] for e in flute)],flute_max_notated_gate_seconds=round(max_duration,6),minimum_interphrase_gate_rest_seconds=round(min(gaps),6),minimum_interphrase_rest_after_conservative_209ms_early_next_trigger_seconds=round(min(gaps)-.209,6),phrase_checks=phrase_checks,piano_hands=hand_stats,limitations=['No audio, REAPER, sfizz, FFmpeg, sample download, installation, or listening used.','Gate/rest values are score-derived; sample release tails and measured pitched-onset compensation still need integration checks.','For true audible silence of 0.60 s the integrator must measure release and use the printed timing reserve; no score-only check proves the acoustic gap.','Checks catch bounds and coordination defects; they do not prove musical quality or replace human listening.'])


def main():
    audits=[];scores=[]
    for version in range(3):
        score,phrases,entries=build(version);a=audit(score,phrases)
        scores.append(score);audits.append(a)
        for name,obj in [(f'score_v{version}.json',score),(f'audit_v{version}.json',a),(f'phrases_v{version}.json',phrases)]:
            (ROOT/name).write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
        if version==2:
            (ROOT/'flute_entry_intentions.json').write_text(json.dumps(entries,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
            (ROOT/'score.json').write_text(json.dumps(score,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    revisions=[]
    for v in (1,2):
        before=scores[v-1];after=scores[v]
        def canon(e):return json.dumps(e,sort_keys=True)
        bs={canon(e) for e in before['events']};ass={canon(e) for e in after['events']}
        revisions.append(dict(from_version=v-1,to_version=v,removed_events=len(bs-ass),added_events=len(ass-bs),changed_bars=[n for n in range(1,49) if [e for e in before['events'] if e['bar']==n]!=[e for e in after['events'] if e['bar']==n]],harmony_changed_bars=[x['bar'] for x,y in zip(before['bars'],after['bars']) if x['harmony']!=y['harmony']]))
    (ROOT/'revision_diff.json').write_text(json.dumps(revisions,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    digest=hashlib.sha256((ROOT/'score_v2.json').read_bytes()).hexdigest()
    (ROOT/'manifest.json').write_text(json.dumps(dict(id=64,status='NON_RENDERED_DRAFT',canonical_score='score_v2.json',canonical_sha256=digest,versions=['score_v0.json','score_v1.json','score_v2.json'],audit_files=['audit_v0.json','audit_v1.json','audit_v2.json'],no_audio_created=True,source='Original hand-authored pitch and rhythm arrays in build_score.py; no existing piece or theme was read or imported.'),ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(dict(final_audit=audits[-1],revision_diff=revisions),ensure_ascii=False,indent=2))
    if audits[-1]['status']!='PASS': raise SystemExit('Final score audit failed.')
if __name__=='__main__': main()
