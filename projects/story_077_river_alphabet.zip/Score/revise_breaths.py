from pathlib import Path
import json,bisect
P=Path(__file__).parent;d=json.loads((P/'revisions/ensemble_v2.json').read_text());starts=[b['start'] for b in d['bars']];times=[];t=0
for b in d['bars']:times.append(t);t+=b['beats']*60/b['bpm']
def sec(x):
 i=max(0,bisect.bisect_right(starts,x)-1);return times[i]+(x-starts[i])*60/d['bars'][i]['bpm']
changes=[]
for ph in d['phrases']:
 ev=sorted([e for e in d['events'] if e.get('phrase_id')==ph['phrase_id']],key=lambda e:e['onset']);unit=int(ph['phrase_id'][1:]);start=(unit-1)*6;section=d['bars'][bisect.bisect_right(starts,ev[0]['onset'])-1]['section']
 if len(ev)==4:
  last=ev[-1];old=[last['onset'],last['duration']]
  off,dur=(4.5,.5) if section in ['The opposite bank','Two-sided signs'] else (3.9,.65) if section=='A beautiful wrong welcome' else (4.15,.7)
  last['onset']=start+off;last['duration']=dur;last['bar']=d['bars'][bisect.bisect_right(starts,last['onset'])-1]['bar'];changes.append({'phrase':ph['phrase_id'],'old':old,'new':[last['onset'],last['duration']]})
 ph['actual_trigger_start_seconds']=sec(ev[0]['onset']);ph['actual_noteoff_end_seconds']=sec(ev[-1]['onset']+ev[-1]['duration']);ph['target_off_beats']=ev[-1]['onset']+ev[-1]['duration']
# Answer the last wind D with one quiet complete piano D-minor arrival.
d['events']=[e for e in d['events'] if not(e['instrument']=='piano' and e['onset']>=285.5)]
for pitch,voice,vel in [(38,'bass',36),(45,'accompaniment',33),(50,'accompaniment',34),(62,'piano_answer',47),(65,'piano_answer',40)]:d['events'].append({'onset':285.5,'duration':2.1,'pitch':pitch,'velocity':vel,'voice':voice,'instrument':'piano','bar':64})
d['events'].sort(key=lambda e:(e['onset'],e['instrument'],e['pitch']));d['stage']='v3_shared_breaths_and_piano_final_answer'
for bar in d['bars']:
 if bar['beats']==6:bar['meter_numerator']=3;bar['meter_denominator']=2
ph=sorted(d['phrases'],key=lambda p:p['actual_trigger_start_seconds'])
for a,b in zip(ph,ph[1:]):
 if b['actual_trigger_start_seconds']-a['actual_noteoff_end_seconds']<.82:
  ev=sorted([e for e in d['events'] if e.get('phrase_id')==a['phrase_id']],key=lambda e:e['onset']);last=ev[-1];limit=b['actual_trigger_start_seconds']-.82;idx=max(0,bisect.bisect_right(times,limit)-1);newend=starts[idx]+(limit-times[idx])*d['bars'][idx]['bpm']/60;
  if sec(newend)-sec(last['onset'])<.2:
   last['onset']-=.25;previous=ev[-2];previous['duration']=min(previous['duration'],last['onset']-.1-previous['onset']);changes.append({'phrase':a['phrase_id'],'kind':'move_last_arrival_earlier_instead_of_clipping_to_very_short_note','advance_beats':.25})
  assert sec(newend)-sec(last['onset'])>.2
  changes.append({'phrase':a['phrase_id'],'kind':'section_boundary_breath','old_duration':last['duration'],'new_duration':newend-last['onset']});last['duration']=newend-last['onset'];a['actual_noteoff_end_seconds']=limit;a['target_off_beats']=newend
gaps=[b['actual_trigger_start_seconds']-a['actual_noteoff_end_seconds'] for a,b in zip(ph,ph[1:])];assert min(gaps)>.8
for f in ['ensemble_score.json','revisions/ensemble_v3.json']:(P/f).write_text(json.dumps(d,ensure_ascii=False,indent=2))
for inst in ['piano','clarinet']:(P/f'{inst}_score.json').write_text(json.dumps({**d,'events':[e for e in d['events'] if e['instrument']==inst],'pedals':d['pedals'] if inst=='piano' else []},ensure_ascii=False,indent=2))
(P/'revisions/pass3.json').write_text(json.dumps({'kind':'substantive_articulation_and_final_answer_revision','changes':changes,'minimum_written_clarinet_phrase_gap_seconds':min(gaps),'final_answer':'Quiet piano D-minor chord replies after last clarinet D; compactLH38,45,50 andRH62,65','human_listening_review':False},indent=2));print('minphrasegap',min(gaps))
