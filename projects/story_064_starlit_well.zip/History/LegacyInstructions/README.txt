记得星星的井 / The Well That Remembered Stars — v4
原创虚构故事，自然长笛与钢琴二重奏，2分57.1秒。

打开064_starlit_well_v4.rpp。完整包包含两条float32音轨，可在REAPER中播放和混音；另外提供三轨MIDI与JSON谱面。它是独立音频轨工程，不是自包含虚拟乐器MIDI工程。轻房间是REAPER自带ReaVerbate，本Linux7.82工程已实际回开导出；其他平台可能需重新匹配插件，不承诺跨平台PCM相同。输出在Renders/。

再生成：Score/build_score.py产生原始v0/v1/v2谱面，Score/prepare_performance.py从v2和外部长笛mapping_manifest.json产生最终v3演奏时序，Score/export_midi.py导出包含3/4与4/4变化的MIDI。原v2长笛onset代表有音高的目标到达点；最终ensemble_score.json、flute_score.json及MIDI已按每个音、每层的实测气头提前触发，并保留原目标note-off。不要再次重复补偿。最终最长门控1.4994秒，所有门控间隔大于0.12秒释放设置。实际孤立长笛总线包含房间尾响，句间低于−80dBFS的连续10ms-RMS区间最短约1.10秒；这是技术阈值，不是人耳听感结论。

Tools/render_score_sfizz.py分别读取piano_score.json（Moonlight推荐SFZ，加--enable-details）与flute_score.json（Iowa_flute_vibrato_C5_B5_two_layers.sfz）。外部SFZ须能找到各自Samples目录；输出Media/piano_float32.wav和Media/flute_float32.wav。变化曲式长度需同时更新母带范围。旧README和故事设计文档保存未渲染草稿阶段的原始说明，最终状态以本说明及metadata为准。

钢琴：Moonlight-SalamanderV6.2，Alexander Holm录音，Chisato Yamauchi/Accurate-Salamander重制，Hiroharu Narikawa等调律；CC BY3.0 https://creativecommons.org/licenses/by/3.0/ 。官方来源 https://www.ir.isas.jaxa.jp/~cyamauch/AccurateSalamander/ 。原README与版本hash随包。
长笛：University of Iowa MIS，Lawrence Fritts主持；Sonja Feig于2000年4月演奏，John Ritz与Michael Cash录音。来源 https://theremin.music.uiowa.edu/MISflute.html ，官方许可 https://theremin.music.uiowa.edu/MIS.html 允许用于任何项目，无使用限制，不另称CC0。原始16bit44.1kHzmono，24个切片为逐字节保真的pp/mf录音，保留自然颤音和气头，细小音高校准只调整播放。此曲使用C5–B5范围内的分句，没有真实连奏过渡、循环延音或ff录音层。float32源轨和24bit母带没有增加原始录音精度。气头补偿是据测量安排触发，不保证每个音的主观到达完全相同。

两轮实质谱面改写：独立发展提桶段的倒影下行；用C自然音和C降音交替体现两种夜色共存，最后改写主句归根。第三轮做逐音采样入口与门限修订；第四轮核对真实总线、呼吸和尾响，缩短冗余尾静默。没有声称人工听审、现场真人演奏或真实生活经历。
