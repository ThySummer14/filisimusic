"""Original nominal composition, 125. Every melodic bar is explicitly authored here.
No source score, sample, audio renderer, external dependency, or stochastic generator.
Units are concert MIDI pitches and quarter-note beats. 3/4 is literal throughout.
"""
from copy import deepcopy
ID=125
TITLE="The Old Shoes' Last Dance"
TITLE_ZH='旧鞋的最后一支舞'
SECTIONS=[
 ('A_the_door_without_a_name',1,4,84,'piano summons; clarinet answers', [4]),
 ('B_the_soles_remember',5,19,88,'clarinet leads a fifteen-bar polonaise', [5,4,6]),
 ('C_the_absent_mirror',20,31,76,'piano sings into widely spaced clarinet replies', [5,7]),
 ('D_a_step_never_performed',32,45,90,'piano invents the younger dancers impossible step', [6,8]),
 ('E_the_lace_on_the_chair',46,56,72,'clarinet minor-mode soliloquy; piano leaves air', [4,7]),
 ('F_one_dance_without_an_audience',57,72,88,'clarinet return with independently moving piano', [7,9]),
 ('G_the_feet_go_on',73,84,94,'piano takes the new route; clarinet gives short answers', [5,7]),
 ('H_the_shoes_stay',85,92,74,'separated memories, then piano leaves alone', [3,5]),
]
# Harmonic labels describe audible sonorities, not a post-hoc pitch whitelist.
HARMONIES={
 'A':[45,61,64,69], 'A/E':[40,61,64,69], 'A/C#':[37,61,64,69],
 'Aadd9':[45,61,64,69,71], 'A6':[45,61,64,66,69], 'A7':[45,61,64,67,69],
 'D':[38,62,66,69], 'D/F#':[42,62,66,69], 'Dmaj7':[38,61,62,66,69],
 'Dm':[38,62,65,69], 'Dm6':[38,59,62,65,69],
 'E':[40,59,64,68], 'E7':[40,59,62,64,68], 'E9':[40,59,62,64,66,68],
 'Esus4':[40,59,64,69], 'F#m':[42,61,66,69], 'F#m7':[42,61,64,66,69],
 'Bm':[47,62,66,71], 'Bm7':[47,62,66,69,71],
 'B7':[47,63,66,69,71], 'C#7':[37,59,61,65,68],
 'Am':[45,60,64,69], 'Am/G':[43,60,64,69], 'Fmaj7':[41,60,64,65,69],
 'G':[43,59,62,67], 'C':[36,60,64,67],
}
# Articulation is part of the writing: fast soles, a held upper line, and genuine rests.
RHYTHMS={
 'p5':[(0,.42),(.5,.20),(.75,.20),(1.5,.40),(2,.83)],
 'p6':[(0,.64),(.75,.20),(1,.40),(1.5,.40),(2,.40),(2.5,.38)],
 'p7':[(0,.40),(.5,.20),(.75,.20),(1,.40),(1.5,.40),(2,.40),(2.5,.38)],
 'q3':[(0,.80),(1,.80),(2,.80)],
 'hold2':[(0,1.65),(2,.80)],
 'answer3':[(1,.40),(1.5,.40),(2,.80)],
 'answer2':[(1.5,.38),(2,.80)],
 'run8':[(0,.40),(.5,.20),(.75,.20),(1,.20),(1.25,.20),(1.5,.40),(2,.40),(2.5,.38)],
 'run10':[(0,.20),(.25,.20),(.5,.20),(.75,.20),(1,.40),(1.5,.20),(1.75,.20),(2,.20),(2.25,.20),(2.5,.38)],
 'e6':[(0,.40),(.5,.40),(1,.40),(1.5,.40),(2,.40),(2.5,.38)],
 'cad2':[(0,1.35),(1.75,1.05)],
 'sil':[], 'one':[(2,.80)],
 'pulse4':[(0,.65),(1,.40),(1.5,.40),(2,.82)],
 'off3':[(.5,.38),(1.5,.38),(2.5,.38)],
 'song2':[(.5,1.10),(2,.78)],
 'long1':[(0,2.45)],
 'end1':[(0,2.85)],
}
WIND_RHYTHMS={
 'three':[(0,.65),(1,.65),(2,.65)],
 'open':[(.5,.75),(1.75,.90)],
 'two':[(0,1.35),(1.75,.90)],
 'early':[(0,.70),(1,.95)],
 'late':[(1,.70),(2,.65)],
 'one':[(.5,1.35)],
 'last':[(1.5,1.15)],
 'head':[(0,1.35)],
 'sil':[],
}
# Each row: chord | RH rhythm | explicit RH pitches | wind rhythm | explicit wind pitches | LH texture.
# LH texture options: polonaise, clipped, walking, broad, open, spare, none.
DATA='''
A|p5|76 73 71 73 76|one|64|clipped
E7|answer3|74 73 71|open|68 62|polonaise
A/C#|pulse4|73 76 78 81|late|61 64|walking
E7|cad2|80 76|last|68|open
A|p6|76 78 81 80 76 73|open|64 69|polonaise
A/C#|answer3|76 78 81|three|61 64 69|walking
D|pulse4|78 81 80 78|two|66 69|clipped
E7|p5|80 78 76 74 71|early|68 64|polonaise
A|cad2|73 76|late|61 69|open
F#m|p7|78 76 73 69 71 73 76|two|66 61|polonaise
Bm7|answer3|74 78 81|three|62 66 69|walking
E9|p6|80 78 76 74 78 80|early|68 66|clipped
Aadd9|hold2|81 76|last|71|broad
D/F#|p5|78 76 74 73 69|two|69 66|polonaise
Dm|pulse4|77 81 79 77|late|65 62|spare
A/E|p7|76 73 71 69 71 73 76|three|64 61 69|walking
Bm7|answer3|78 76 74|early|66 62|clipped
E7|p6|80 81 80 78 76 74|two|68 62|polonaise
A|cad2|73 69|head|69|broad
F#m7|song2|78 76|head|61|broad
Dmaj7|hold2|81 78|sil||spare
A/C#|long1|76|last|69|open
E|song2|80 76|sil||spare
F#m|cad2|78 73|one|66|broad
Bm7|song2|74 78|head|69|spare
E7|hold2|80 74|last|64|open
Aadd9|long1|83|sil||broad
D|song2|81 78|head|62|spare
Dm6|hold2|77 74|last|65|open
A/E|song2|76 73|sil||spare
E7|cad2|74 80|late|62 68|clipped
A|run8|81 80 78 76 78 80 81 85|head|64|walking
A/C#|run10|85 83 81 80 76 78 80 81 80 78|sil||polonaise
D|e6|78 76 74 73 69 71|late|66 69|walking
B7|run8|75 76 78 81 80 78 75 78|head|63|clipped
E|p7|80 78 76 71 73 76 80|last|68|polonaise
E7|p5|74 76 78 80 76|two|62 68|open
Aadd9|run10|81 83 85 83 81 80 78 76 78 80|sil||walking
D/F#|e6|81 80 78 76 74 73|one|69|polonaise
C#7|run8|80 78 77 73 75 77 80 83|head|65|clipped
F#m|run10|81 80 78 76 73 74 76 78 80 81|sil||walking
Bm|run8|83 81 78 74 76 78 83 81|late|71 66|polonaise
E9|e6|80 78 76 74 78 80|head|68|walking
A/E|p5|81 80 78 76 73|last|64|clipped
E7|cad2|80 74|early|68 62|open
Am|song2|72 76|two|64 60|spare
Am/G|hold2|81 76|one|60|broad
Fmaj7|long1|77|late|65 64|spare
E7|cad2|80 74|head|68|open
Am|song2|76 72|two|69 64|broad
Dm|hold2|77 74|one|65|spare
G|song2|79 74|late|67 62|open
C|long1|76|head|60|broad
Fmaj7|hold2|81 77|last|64|spare
B7|song2|78 75|two|63 66|open
E7|cad2|80 76|early|68 62|clipped
A|p6|76 78 81 80 76 73|open|64 69|polonaise
A/C#|answer3|76 78 81|three|61 64 69|walking
D|pulse4|78 81 80 78|two|66 69|clipped
E7|p5|80 78 76 74 71|early|68 64|polonaise
A6|cad2|73 78|late|61 66|open
F#m7|p7|78 76 73 69 71 73 76|two|66 61|polonaise
Bm7|answer3|74 78 81|three|62 66 69|walking
E9|p6|80 78 76 74 78 80|early|68 66|clipped
Aadd9|hold2|81 83|last|71|broad
D/F#|p5|78 76 74 73 69|two|69 66|polonaise
Dm6|pulse4|77 81 79 77|late|65 62|spare
A/E|p7|76 73 71 69 71 73 76|three|64 61 69|walking
A7|answer3|79 76 73|early|67 64|clipped
D|p6|78 81 78 76 74 73|two|66 62|polonaise
E7|p5|80 78 76 74 71|early|68 62|walking
A|cad2|81 76|head|69|broad
F#m|run10|78 80 81 80 78 76 73 69 71 73|head|66|walking
Bm7|run8|78 76 74 71 73 74 78 81|sil||polonaise
E9|e6|80 78 76 74 78 80|late|68 66|walking
A/C#|run10|85 83 81 80 76 78 80 81 83 85|sil||clipped
Dmaj7|p7|81 80 78 74 76 78 81|one|61|polonaise
B7|run8|83 81 78 75 76 78 81 83|head|63|walking
E|run10|80 81 83 81 80 78 76 71 73 76|sil||polonaise
A/E|e6|81 80 76 73 69 71|last|64|walking
Dm6|p5|77 76 74 71 69|head|65|clipped
A/E|run8|76 78 80 81 80 78 76 73|sil||polonaise
E7|p7|80 78 76 74 73 71 68|late|68 62|walking
A|pulse4|81 76 73 69|head|69|broad
Dmaj7|song2|78 73|head|61|spare
Dm6|hold2|77 74|last|65|open
A/E|cad2|76 73|two|64 61|broad
E7|song2|74 80|head|68|spare
Aadd9|hold2|81 76|last|71|open
Dm6|song2|77 74|head|65|spare
A/E|cad2|76 73|last|64|open
A|end1|69|sil||broad
'''
def parse(text):
 rows=[]
 for line in text.strip().splitlines():
  h,r,ps,w,ws,left=line.split('|')
  rows.append(dict(harmony=h,rhythm=r,pitches=[int(x) for x in ps.split()],wind_rhythm=w,wind_pitches=[int(x) for x in ws.split()],left=left))
 return rows
BASE=parse(DATA)
# Revision 1 changes the dramatic function of the empty-mirror episode.
# These are the fully composed v0 bars, retained rather than fabricated ID diffs.
V0_MIRROR=parse('''
F#m7|p6|78 76 73 71 69 73|three|66 64 61|polonaise
Dmaj7|p5|81 80 78 76 74|two|69 66|clipped
A/C#|answer3|76 78 81|three|61 64 69|walking
E|p6|80 78 76 73 71 76|early|68 64|polonaise
F#m|p7|78 76 73 69 71 73 76|two|66 61|clipped
Bm7|p5|83 81 78 76 74|three|71 69 66|walking
E7|p6|80 78 76 74 71 74|two|68 62|polonaise
Aadd9|pulse4|81 76 78 83|early|69 71|clipped
D|p5|78 76 74 73 69|three|66 62 69|polonaise
Dm6|p6|77 76 74 71 69 74|two|65 62|walking
A/E|p7|76 73 71 69 71 73 76|three|64 61 69|clipped
E7|p5|80 78 76 74 71|two|68 62|polonaise
''')
# Revision 2: genuinely new inner argument in the reprise and an altered farewell.
V2_RETURN=parse('''
A|off3|85 83 81|open|64 69|polonaise
A/C#|p5|76 74 73 71 69|two|61 64|walking
D|answer2|74 78|three|69 66 62|clipped
E7|p7|71 73 74 76 78 80 81|early|68 64|polonaise
A6|song2|78 76|last|66|spare
F#m7|pulse4|73 69 71 76|three|66 64 61|walking
Bm7|off3|83 81 78|two|62 69|polonaise
E9|p5|76 74 73 71 68|late|66 68|clipped
Aadd9|song2|83 81|one|64|broad
D/F#|answer3|74 76 78|three|69 66 62|walking
Dm6|p6|77 76 74 72 71 69|two|65 62|spare
A/E|pulse4|73 76 78 81|open|61 64|polonaise
A7|p5|79 78 76 74 73|three|67 64 61|walking
D|song2|78 74|two|66 69|open
E7|p7|80 81 80 76 74 71 68|late|62 68|polonaise
A|cad2|76 81|head|69|broad
''')
V2_CODA=parse('''
Dmaj7|song2|78 73|one|62|spare
Dm6|answer2|77 74|head|65|open
A/E|long1|76|last|61|spare
E7|song2|74 80|head|68|open
Aadd9|off3|83 81 76|last|71|spare
Dm6|song2|77 74|head|65|open
A/E|answer3|73 71 69|one|64|spare
A|end1|81|sil||broad
''')
RENDERER_NOTES={
 'clarinet':'Concert MIDI 60–71, velocities 48–70; genuine sampled acoustic clarinet. No onset advance. Initial rest >=0.5 quarter; gates 0.40–1.20 seconds; nominal release-to-next-onset gaps >=0.18 seconds. Do not shorten gates mechanically.',
 'piano':'Two acoustic piano hands; dry separated polonaise pulses and occasional half-pedal-free longer tones. The slow sections need real rests. No synthetic substitute. Final release is in bar 92; allow the four-second tail.',
 'timeline':'All onsets are original nominal score times. No sample compensation in these source files.',
}

def build(version):
 assert len(BASE)==92
 rows=deepcopy(BASE)
 if version==0: rows[19:31]=deepcopy(V0_MIRROR)
 if version>=2:
  rows[56:72]=deepcopy(V2_RETURN)
  rows[84:92]=deepcopy(V2_CODA)
 bars=[];events=[]
 def add(b,off,dur,pitch,vel,inst,voice,hand,art):
  events.append(dict(bar=b,onset=round((b-1)*3+off,6),duration=round(dur,6),pitch=int(pitch),velocity=int(vel),instrument=inst,voice=voice,hand=hand,articulation=art))
 for b,row in enumerate(rows,1):
  sec=next(x for x in SECTIONS if x[1]<=b<=x[2]);name,first,last,bpm,lead,phrases=sec
  h=HARMONIES[row['harmony']];bars.append(dict(bar=b,start=(b-1)*3,beats=3,bpm=bpm,meter_numerator=3,meter_denominator=4,section=name,harmony_name=row['harmony'],harmony=h,phrase_leader=lead))
  r=RHYTHMS[row['rhythm']];assert len(r)==len(row['pitches']),(b,row)
  base=60 if first in (20,46,85) else (76 if first==73 else 69)
  for i,((off,dur),pitch) in enumerate(zip(r,row['pitches'])):
   vel=base+(4 if off==0 else 0)-(3 if i==len(r)-1 else 0)
   add(b,off,dur,pitch,vel,'piano','shoe_memory','right','singing_detached' if dur>.6 else 'light_nonlegato')
  wr=WIND_RHYTHMS[row['wind_rhythm']];assert len(wr)==len(row['wind_pitches']),(b,row)
  for i,((off,dur),pitch) in enumerate(zip(wr,row['wind_pitches'])):
   vel=(50 if first in (1,20,46,85) else 68)+(2 if i==0 else -2)
   add(b,off,dur,pitch,vel,'clarinet','the_dancer','none','separated_breath')
  # Explicit harmonic bass with a moving line, always physically below the RH.
  bass=h[0]; pcs={n%12 for n in h};upper=sorted(p for p in range(45,58) if p%12 in pcs)
  rootup=next(p for p in range(45,57) if p%12==bass%12)
  fifth=next((p for p in upper if p%12==(bass+7)%12),upper[-1])
  third=next((p for p in upper if p%12 in ((bass+3)%12,(bass+4)%12)),upper[0])
  mode=row['left']
  patterns={
   'polonaise':[(0,.38,bass),(.5,.19,fifth),(.75,.19,third),(1,.38,rootup),(1.5,.38,third),(2,.38,fifth),(2.5,.35,rootup)],
   'clipped':[(0,.60,bass),(1,.35,third),(1.5,.35,fifth),(2,.67,rootup)],
   'walking':[(0,.68,bass),(1,.38,third),(1.5,.35,fifth),(2,.72,rootup)],
   'broad':[(0,1.68,bass),(2,.80,fifth)],
   'open':[(0,.74,bass),(1.5,1.20,third)],
   'spare':[(0,1.10,bass)], 'none':[],
  }
  for i,(off,dur,pitch) in enumerate(patterns[mode]):
   vel=base-13+(3 if off==0 else 0)-(i%2)*2
   add(b,off,dur,pitch,vel,'piano','the_floor','left','detached_dance' if dur<.8 else 'quiet_tenuto')
 # Deliberate expressive dissonance: D over A, resolves to C# on the next beat.
 # This genuine alteration survives every version and is not corrected to a chord tone.
 for e in events:
  if e['bar']==16 and e['instrument']=='clarinet' and e['onset']==45: e['pitch']=62
 # Reprise inversion: piano upper neighbor F# over A resolves down to E.
 if version>=2:
  for e in events:
   if e['bar']==68 and e['instrument']=='piano' and e['hand']=='right' and e['onset']==201: e['pitch']=78
 annotations=[dict(bar=16,instrument='clarinet',voice='the_dancer',source_onset=45,source_pitch=62,target_onset=46,target_pitch=61,kind='accented_appoggiatura',explanation='D4 leans over A/E; the next clarinet C#4 is the chord third, one semitone lower, one quarter later.')]
 if version>=2:annotations.append(dict(bar=68,instrument='piano',voice='shoe_memory',source_onset=201,source_pitch=78,target_onset=202,target_pitch=76,kind='accented_upper_neighbor',explanation='F#5 above A/E resolves to E5 one quarter later; the following F# is an unaccented echo.'))
 return dict(id=ID,title=TITLE,title_zh=TITLE_ZH,version=f'v{version}',bars=bars,events=events,pedals=[dict(bar=1,onset=0,controller=64,value=0,instrument='piano'),dict(bar=92,onset=275.99,controller=64,value=0,instrument='piano')],total_beats=276,tail_seconds=4.0,instrument_map={'piano':'piano','clarinet':'clarinet'},phrase_map=[dict(first_bar=x[1],last_bar=x[2],design=x[0],leader=x[4],phrase_lengths_bars=x[5]) for x in SECTIONS],dissonance_annotations=annotations,nominal_onsets_no_sample_compensation=True,performance_contract='Original nominal acoustic score. No audio rendered or listening approval claimed. Clarinet is not onset-advanced. Renderer owns acoustic sample realization.')
