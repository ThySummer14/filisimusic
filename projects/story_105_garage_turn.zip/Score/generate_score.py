"""Work105: asymmetric five-beat passacaglia-like narrative with changing bass leadership."""
from pathlib import Path
import json,difflib,sys
P=Path(__file__).resolve().parent;sys.path.insert(0,str(P));from composition_data import *
def pitch(s):return 12*(int(s[-1])+1)+{'C':0,'D':2,'E':4,'F':5,'G':7,'A':9,'B':11}[s[0]]+s[1:-1].count('#')-s[1:-1].count('b')
def section(n):
 if n<=8:return 'A0','尚未挪动的车',108,60,5
 if n<=24:return 'A','指挥与方向盘',116,76,5
 if n<=36:return 'B','错过转弯角度',122,91,5
 if n<=44:return 'C','先停下测量',84,43,3
 if n<=64:return 'D','一次完整的转弯',120,89,5
 if n<=72:return 'Release','慢慢推出车库',100,62,5
 return 'Coda','松开握住的手',84,44,3

def build(level):
 hs=[];lines=[]
 for h,s in ROWS:hs+=h.split();lines+=s.split('|')
 assert len(lines)==len(hs)==80
 for lv,rd,hd in [(1,REV1,HREV1),(2,REV2,HREV2)]:
  if level>=lv:
   for n,s in rd.items():lines[n-1]=s
   for n,h in hd.items():hs[n-1]=h
 bars=[];events=[];pedals=[];start=0.
 for n,(line,h) in enumerate(zip(lines,hs),1):
  sec,label,bpm,dyn,beats=section(n);ch=H[h];low=n<=16 or sec in ['C','Coda'] or n in [64,68,69,70,71,72]
  if n in [8,24,36,44,64,72]:bpm-=6
  if n>=77:bpm-=2*(n-76)
  bars.append(dict(bar=n,start=start,beats=beats,bpm=bpm,meter=f'{beats}/4',meter_numerator=beats,meter_denominator=4,section=sec,section_title_zh=label,harmony_name=h,harmony=ch,key_region='Gb major' if sec=='C' else 'Eb minor',metrical_grouping='3+2 quarter groups' if beats==5 else 'quiet three quarters',texture='low_theme_with_high_punctuation' if low else 'upper_theme_with_low_counterline'))
  def add(p,t,d,v,inst,voice,hand='none'):
   assert 0<=t<t+d<=beats+.00001,(n,t,d,beats)
   events.append(dict(bar=n,onset=round(start+t,6),duration=round(d,6),pitch=p,velocity=int(v),instrument=inst,voice=voice,hand=hand,harmony_name=h,phrase_id=f'{sec}_{(n-1)//4}',role='lead' if voice=='melody' else 'support',articulation='five_beat_phrase_with_deliberate_spaces',written_value_beats=d))
  at=0.;written=[]
  for tok in line.split():
   name,u=tok.split(':');dur=int(u)/2
   if name!='R':
    p=pitch(name);written.append(p);add(p,at,dur-.08,dyn+(4 if at==3 and beats==5 else 0),'piano','melody','left' if low else 'right')
   at+=dur
  assert at==beats,(n,at,beats)
  if low:
   minimum=max(68,max(written)+3);voicing=sorted({minimum+(p-minimum)%12 for p in ch[:3]})
   positions=[(3,.45)] if beats==5 else [(1.5,.55)]
   if n%4==0:positions=[]
   if n in [1,9,13]:positions=[(2,.40),(4,.45)]
   for t,d in positions:
    for p in voicing[-2:]:add(p,t,d,dyn-27,'piano','high_clearance_response','right')
  else:
   pat=[(0,ch[0],.5),(3,ch[1],.45)]
   if n%4==2:pat=[(1,ch[1],.38),(3.5,ch[2],.40)]
   if level>=1 and 25<=n<=36:pat=[(.5,ch[0],.35),(2.5,ch[1],.35),(4,ch[2],.42)]
   if level>=2 and 45<=n<=64:pat=[(0,ch[0],.38),(2,ch[2],.35),(4,ch[1],.42)] if n%2 else [(1,ch[1],.38),(3.5,ch[0],.42)]
   if n in [32,36,60,64,72]:pat=[(0,ch[0],.6)]
   for t,p,d in pat:add(p,t,d,dyn-27,'piano','changing_low_route','left')
  root=36+ch[0]%12
  entries=[]
  if sec=='A0' and n%2==0:entries=[(2,.38)]
  elif sec=='A':entries=[(0,.42),(3,.40)] if n%4!=0 else [(0,.42)]
  elif sec=='B' and n%2:entries=[(1,.38),(3.5,.4)]
  elif sec=='C' and n==40:entries=[(.5,.42)]
  elif sec=='D':entries=[(0,.40),(3,.4)] if n%2 else [(1.5,.38)]
  elif sec=='Release' and n%2:entries=[(1,.4)]
  elif n in [76,80]:entries=[(0,.5)]
  if level>=1 and 25<=n<=36:entries=[(.5,.35),(3.5,.35)] if n%4==1 else [(2,.35)] if n%4==3 else []
  if level>=2 and 53<=n<=64:entries=[(.5,.38),(3,.40)] if n%4 in [1,2] else [(0,.4)] if n==64 else []
  for t,d in entries:add(root,t,d,dyn+3,'cello','pizzicato_turn_marker')
  pedals.append(dict(bar=n,onset=start,controller=64,value=0,instrument='piano'))
  if low:
   pedals +=[dict(bar=n,onset=start+.08,controller=64,value=30,instrument='piano'),dict(bar=n,onset=start+1.7,controller=64,value=0,instrument='piano')]
   if beats==5:pedals +=[dict(bar=n,onset=start+3.1,controller=64,value=22,instrument='piano'),dict(bar=n,onset=start+4.8,controller=64,value=0,instrument='piano')]
  start+=beats
 events.sort(key=lambda e:(e['onset'],e['instrument'],e['pitch']))
 for i,e in enumerate(events):e['event_id']=f'w105-v{level}-{i:04d}'
 return dict(id=105,title='The Turn Inside the Garage',title_zh='车库里的转弯',version=f'v{level}',bars=bars,events=events,pedals=pedals,total_beats=start,tail_seconds=5,instrumentation=['piano','cello_pizzicato'],performance_contract='Original acoustic sample performance; low and high leadership exchange, no reused earlier composition.')
for v in range(3):
 d=build(v);(P/f'score_v{v}.json').write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n');report=dict(version=f'v{v}',bars=80,notes=len(d['events']),duration_seconds=sum(b['beats']*60/b['bpm'] for b in d['bars'])+5,human_listening_review=False);(P/f'audit_v{v}.json').write_text(json.dumps(report,indent=2))
 if v:
  old=build(v-1);changed=[]
  for n in range(1,81):
   clean=lambda e:{k:x for k,x in e.items() if k!='event_id'}
   if [clean(e) for e in old['events'] if e['bar']==n]!=[clean(e) for e in d['events'] if e['bar']==n]:changed.append(n)
  a=(P/f'score_v{v-1}.json').read_text();b=(P/f'score_v{v}.json').read_text();(P/f'exact_diff_v{v-1}_to_v{v}.patch').write_text(''.join(difflib.unified_diff(a.splitlines(True),b.splitlines(True),f'score_v{v-1}.json',f'score_v{v}.json')));(P/f'exact_diff_v{v-1}_to_v{v}.json').write_text(json.dumps({'changed_bars':changed,'count':len(changed)},indent=2))
for f in ['score.json','ensemble_score.json']:(P/f).write_text((P/'score_v2.json').read_text())
for inst in ['piano','cello']:
 x={**d,'events':[e for e in d['events'] if e['instrument']==inst],'pedals':d['pedals'] if inst=='piano' else []};(P/f'{inst}_score.json').write_text(json.dumps(x,ensure_ascii=False,indent=2))
print(json.dumps(report));print([json.loads((P/f'exact_diff_v{i}_to_v{i+1}.json').read_text())['count'] for i in range(2)])
