#!/usr/bin/env python3
"""Independent lightweight JSON-only validator. Does not import the generator."""
import json
from pathlib import Path
ROOT=Path(__file__).resolve().parent
reports=[]
for version in range(3):
    data=json.loads((ROOT/f'score_v{version}.json').read_text())
    failures=[]
    def test(value, label):
        if not value: failures.append(label)
    starts=[]; t=0.
    for b in data['bars']:
        starts.append(t)
        t+=b['beats']*60/b['bpm']
    def sec(e, off=False):
        b=data['bars'][e['bar']-1]
        offset=e['onset']-b['start']+(e['duration'] if off else 0)
        return starts[e['bar']-1]+offset*60/b['bpm']
    test(data['id']==72 and len(data['bars'])==96,'Identity/form')
    test(len(data['pedals'])==0,'No pedals')
    test(data['performance_contract']['recommended_render_pre_roll_seconds']>=.209,'Required opening flute pre-roll')
    test(data['total_beats']==288,'Total beats')
    test(abs(t-172.95913978494623)<1e-7,'Independent tempo integration')
    for inst,lo,hi,gate,breath in [('flute',72,83,1.35,.85),('clarinet',60,71,1.50,.6)]:
        notes=sorted([e for e in data['events'] if e['instrument']==inst],key=lambda e:e['onset'])
        test(all(lo<=e['pitch']<=hi for e in notes),inst+' range')
        test(all(sec(e,True)-sec(e)<=gate+1e-8 for e in notes),inst+' nominal gate')
        test(all(e['voice']==inst for e in notes),inst+' voice tag')
        test(all(abs(e['target_on_seconds']-sec(e))<1e-8 and abs(e['target_off_seconds']-sec(e,True))<1e-8 for e in notes),inst+' second annotations')
        test(all(sec(a,True)<=sec(b)+1e-8 for a,b in zip(notes,notes[1:])),inst+' monophony')
        if inst=='flute':
            test(all(sec(a,True)<=sec(b)-.209+1e-8 for a,b in zip(notes,notes[1:])),inst+' max advance safe gaps')
            test(all(sec(e,True)-(sec(e)-.209)<=gate+1e-8 for e in notes),inst+' max advance safe gates')
        previous=None
        for phrase in sorted({e['phrase_id'] for e in notes}):
            ee=[e for e in notes if e['phrase_id']==phrase]
            layers={e['layer'] for e in ee}
            test(len(layers)==1,phrase+' single layer')
            test(all((21<=e['velocity']<=55) if e['layer']=='pp' else (56<=e['velocity']<=95) if e['layer']=='mf' else False for e in ee),phrase+' velocity layer')
            if previous is not None:
                test(sec(ee[0])-previous>=breath-1e-8,phrase+' breath')
            previous=max(sec(e,True) for e in ee)
    for b in data['bars']:
        lead=[e for e in data['events'] if e['bar']==b['bar'] and e['role']=='lead']
        test(len({e['instrument'] for e in lead})==1,'One foreground '+str(b['bar']))
        test(all(e['instrument']==b['lead_instrument'] for e in lead),'Declared foreground '+str(b['bar']))
    for e in data['events']:
        if e['role']!='support':continue
        voices=[l for l in data['events'] if l['role']=='lead' and max(e['onset'],l['onset'])<min(e['onset']+e['duration'],l['onset']+l['duration'])-1e-9]
        test(len(voices)==1,'One lead under support '+e['event_id'])
        test(all(abs(l['pitch']-e['pitch'])%12 in (0,3,4,7,8,9) for l in voices),'Consonance '+e['event_id'])
    if version==2:
        test(not [e for e in data['events'] if e['bar'] in [67,68] and e['instrument']=='flute'],'Solo handover preview')
        test(all(b['lead_instrument']=='clarinet' for b in data['bars'][68:76]),'Final A has new owner')
        test(all(e['pitch']==(60 if e['instrument']=='clarinet' else 72) for e in data['events'] if e['bar']==96),'Final C octave')
    reports.append({'version':version,'pass':not failures,'failures':failures,'event_count':len(data['events']),'seconds_including_tail':round(t+data['tail_seconds'],9)})
assert all(r['pass'] for r in reports),reports
(ROOT/'independent_validation.json').write_text(json.dumps({'pass':True,'method':'Independent JSON-only validator, without generator import','scores':reports},ensure_ascii=False,indent=2)+'\n')
print('Independent validation: PASS for v0, v1 and v2.')
