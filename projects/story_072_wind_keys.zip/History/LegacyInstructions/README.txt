风换了主人 / The Wind Changed Hands — v4
原创虚构故事与原创双木管回旋曲。长笛与单簧管真实采样演奏，不是现场真人合奏。
96小节3/4的A–B–A–C–A–尾声；最终长174.6秒，包含0.5秒技术前置呼吸。两轮完整谱面重写后，按长笛逐音气头进行一次补偿，再依据实际隔离总线调整真实pp单簧管层电平与尾静默。

完整包：打开072_wind_keys_v4.rpp即可使用Media中的两条float32源轨播放/重新导出，使用REAPER内置ReaVerbate。它是音频轨工程，MIDI与机器乐谱另附。精简包省略源轨与聆听音频。
修改音符后重新生成需要外部University of Iowa MIS音源银行、官方sfizz1.2.3、Python3和NumPy。源包含映射、原始来源与许可，不含采样录音或工具二进制。最终ensemble_score与MIDI已包含0.5秒前置和逐音触发补偿；不可再次提前。score_v2保留未补偿的原始目标谱。
单簧管最终SFZ为Iowa_clarinet_C4_B4_wind_balance.sfz，保持原pp/mf录音层，仅真实pp层加7dB，释放0.04秒；长笛使用真实pp/mf颤音层，释放0.12秒。没有真连奏、循环延音或假造的动态采样层。原始录音均16bit单声道；float32处理及24bit母带不增加录音原始精度。

University of Iowa MIS官方许可：https://theremin.music.uiowa.edu/MIS.html ，允许下载并用于任何项目，不称CC0。单簧管Christine Bellomy演奏，Lawrence Fritts主持，John Ritz和Eric Durian录音，https://theremin.music.uiowa.edu/MISBbclarinet.html 。长笛Sonja Feig于2000年4月演奏，Lawrence Fritts主持，John Ritz和Michael Cash录音，https://theremin.music.uiowa.edu/MISflute.html 。

所有数值审查、实际REAPER孤立总线与便携回开验证均在Revisions中；未声称人工听审。最短低电平换气区间为长笛0.66秒、单簧管0.85秒，条件是10ms RMS低于−80dBFS，不等于主观静默保证。初次诊断分轨脚本没有匹配原生GUID轨道行，相关无效诊断已明确记录并以验证后结果替代，不用于判断。
