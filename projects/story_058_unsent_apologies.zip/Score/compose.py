"""Original clarinet+piano chamber piece, constrained to verifiedC4–B4 samples and short articulated notes."""
import pathlib,json,copy
P=pathlib.Path(__file__).parent;(P/'revisions').mkdir(exist_ok=True)
A=[[(67,1),(70,.5),(68,.5),(67,1),(65,.5),(63,.5)],[(67,.5),(63,.5),(62,1),(63,1),(65,.5),(-1,.5)],[(68,1),(67,.5),(65,.5),(63,1),(60,.5),(63,.5)],[(62,.5),(65,.5),(68,1),(67,.5),(65,.5),(62,.5),(-1,.5)],[(67,1),(65,.5),(63,.5),(70,1),(68,.5),(67,.5)],[(65,1),(68,.5),(67,.5),(65,1),(63,.5),(60,.5)],[(65,.5),(68,.5),(70,1),(68,.5),(65,.5),(62,.5),(-1,.5)],[(67,1),(65,.5),(63,.5),(62,1),(65,.5),(-1,.5)]]
B=[[(70,.5),(68,.5),(67,1),(65,1),(63,.5),(-1,.5)],[(67,1),(68,.5),(70,.5),(68,1),(65,.5),(-1,.5)],[(68,.5),(67,.5),(65,1),(63,1),(60,.5),(-1,.5)],[(65,1),(62,.5),(65,.5),(68,1),(67,.5),(-1,.5)],[(63,.5),(65,.5),(67,1),(70,1),(68,.5),(67,.5)],[(65,.5),(67,.5),(68,1),(67,.5),(65,.5),(63,.5),(-1,.5)],[(62,.5),(65,.5),(68,.5),(70,.5),(68,1),(65,.5),(-1,.5)],[(67,1),(65,.5),(63,.5),(65,1),(-1,1)]]
C=[[(63,.5),(65,.5),(67,1),(68,.5),(70,.5),(67,1)],[(67,1),(63,.5),(62,.5),(60,1),(63,.5),(67,.5)],[(68,.5),(67,.5),(65,.5),(63,.5),(60,1),(63,.5),(68,.5)],[(70,1),(68,.5),(65,.5),(62,1),(65,.5),(-1,.5)],[(67,.5),(70,.5),(68,1),(67,.5),(65,.5),(63,1)],[(68,1),(65,.5),(63,.5),(60,1),(65,.5),(68,.5)],[(70,.5),(68,.5),(65,1),(62,.5),(65,.5),(68,.5),(-1,.5)],[(67,1),(65,.5),(63,.5),(63,1.5),(-1,.5)]]
H={'Eb':[39,51,55,58],'Cm':[48,51,55,58],'Ab':[44,51,56,60],'Bb7':[46,53,56,62],'EbG':[43,51,55,58],'Fm':[41,53,56,60],'Eb9':[39,51,55,65]};home=['Eb','Cm','Ab','Bb7','EbG','Fm','Bb7','Eb9']
sections=[('Paper without a letter',2,76,'intro'),('Drawers of unfinished sentences',12,82,'museum'),('The blue scarf returns',8,84,'scarf'),('Only a new stamp',10,78,'stamp'),('The narrow letterbox',8,88,'post'),('A room with no drawers',12,84,'room'),('The keeper opens her own drawer',6,74,'drawer'),('An empty catalog number',4,68,'coda')]
notes=[];pedals=[];bars=[];beat=0;barno=0
for sec,count,tempo,kind in sections:
 for j in range(count):
  barno+=1;k=j%8;h=home[k];ch=H[h];line=[]
  if kind=='museum':line=copy.deepcopy(A[k])
  elif kind=='scarf':line=copy.deepcopy(B[k])
  elif kind=='stamp':line=copy.deepcopy(B[k]if j<8 else [ [(65,1),(63,.5),(60,.5),(65,1),(-1,1)],[(62,1),(65,.5),(68,.5),(70,1),(-1,1)] ][j-8]);h=home[k]if j<8 else ['Fm','Bb7'][j-8];ch=H[h]
  elif kind=='post':line=copy.deepcopy(C[k])
  elif kind=='room':line=copy.deepcopy(A[k]if j<8 else C[k]);h=home[k];ch=H[h]
  elif kind=='drawer':line=copy.deepcopy(B[j+2]);h=home[j+2];ch=H[h]
  elif kind=='coda':
   h=['Ab','Bb7','Eb','Eb9'][j];ch=H[h];line=copy.deepcopy([[(68,1),(67,.5),(65,.5),(63,1),(-1,1)],[(65,.5),(62,.5),(65,1),(68,1),(-1,1)],[(67,1),(65,.5),(63,.5),(63,1.5),(-1,.5)],[(-1,4)]][j])
  else:h=['Eb','Bb7'][j];ch=H[h]
  bars.append(dict(bar=barno,start=beat,beats=4,bpm=tempo,meter_numerator=4,meter_denominator=4,section=sec,harmony_name=h,harmony=ch,role_plan=kind))
  lv={'intro':0,'museum':47,'scarf':67,'stamp':55,'post':83,'room':76,'drawer':49,'coda':44}[kind]
  off=0
  for n,l in line:
   if n>=0:
    dur=l*.93;assert dur*60/tempo<=1.55,(barno,n,dur);notes.append(dict(bar=barno,onset=beat+off,duration=dur,pitch=n,velocity=lv+(2 if off==0 else 0),voice='clarinet_melody',instrument='clarinet'))
   off+=l
  if line:assert off==4
  pv={'intro':42,'museum':31,'scarf':35,'stamp':30,'post':41,'room':38,'drawer':29,'coda':28}[kind]
  notes.append(dict(bar=barno,onset=beat,duration=.42,pitch=ch[0],velocity=pv,voice='bass',instrument='piano'))
  for t in [.5,2.5]:
   if kind=='coda'and j==3 and t==2.5:continue
   for n in ch[1:3]:notes.append(dict(bar=barno,onset=beat+t,duration=.68,pitch=n,velocity=pv-5,voice='accompaniment',instrument='piano'))
  # Piano finishes the same harmonic sentence only inside a written clarinet rest.
  if line and line[-1][0]<0 and line[-1][1]>=.5:
   start=4-line[-1][1]
   for t,n in[(start,ch[2]),(start+.25,ch[3])]:notes.append(dict(bar=barno,onset=beat+t,duration=.20,pitch=n,velocity=pv+1,voice='reply',instrument='piano'))
  if kind=='intro':
   il=[[(67,1),(70,.5),(68,.5),(67,1),(65,1)],[(62,1),(65,.5),(68,.5),(65,1),(-1,1)]][j];t=0
   for n,l in il:
    if n>=0:notes.append(dict(bar=barno,onset=beat+t,duration=l*.97,pitch=n,velocity=52,voice='piano_melody',instrument='piano'))
    t+=l
  if kind=='coda'and j==3:notes.append(dict(bar=barno,onset=beat,duration=3,pitch=65,velocity=36,voice='piano_melody',instrument='piano'))
  for t,v in[(0,0),(.12,48),(1.92,0),(2.12,44),(3.85,0)]:pedals.append(dict(onset=beat+t,value=v))
  beat+=4
pedals=[e for e in pedals if e['onset']<beat-4]+[dict(onset=beat-4,value=0),dict(onset=beat-3.9,value=58),dict(onset=beat+2,value=0)]
d=dict(id=58,title='The Museum of Unsent Apologies',title_zh='没有寄出的道歉博物馆',stage='v0_original_clarinet_piano_duet',bars=bars,events=notes,pedals=pedals,total_beats=beat,tail_seconds=4.5,story_relationship='Unfinished clarinet questions acquire piano answers in the same harmony. Posting the letter is a shared decision; the ending settles without claiming forgiveness or a reply.',orchestration='ClarinetC4–B4 and acoustic piano; revised honestly from early unavailable reed-quintet proposal',clarinet_limit='Actualpp/mf/ffsamples, mono16bitrecordings; short articulated notes<=1.55sec, no true legato or loops.')
(P/'revisions/ensemble_v0.json').write_text(json.dumps(d,indent=2));(P/'ensemble_score.json').write_text(json.dumps(d,indent=2));(P/'thematic_material.json').write_text(json.dumps(dict(A=A,B=B,C=C),indent=2));print(len(bars),'bars',sum(b['beats']*60/b['bpm']for b in bars)+4.5,'seconds',len(notes),'notes')
