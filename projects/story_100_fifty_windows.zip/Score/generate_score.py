"""Original work100: two-theme acoustic-piano finale. Shared construction utilities; new bar-by-bar score data."""
from pathlib import Path
import argparse, copy, difflib, hashlib, json
from composition_data import LINES,HARM_ROWS,H,V1,V1_H,V2,V2_H,LABELS,SECTIONS,section,bpm
ROOT=Path(__file__).resolve().parent
PC={'C':0,'D':2,'E':4,'F':5,'G':7,'A':9,'B':11}
def midi(s):return 12*(int(s[-1])+1)+PC[s[0]]+s[1:-1].count('#')-s[1:-1].count('b')
def durations(count,beats,n,level):
 if beats==3:return {3:[1,1,1],4:[.5,1,.5,1],5:[.5,.5,.5,.5,1],6:[.5]*6}[count]
 d={3:[1,1,2],4:[1,.5,1,1.5],5:[.5,.5,1,1,1],6:[.5,.5,.5,.5,1,1],7:[.5,.5,.5,.5,.5,.5,1],8:[.5]*8}[count]
 if level==2 and count==5:d=[1,.5,.5,1,1]
 return d
def seconds(bars,t):return sum(min(max(t-b['start'],0),b['beats'])*60/b['bpm'] for b in bars)
def fingermap(keys,hand):
 fs={1:[3],2:[1,5],3:[1,3,5],4:[1,2,4,5],5:[1,2,3,4,5]}[len(keys)]
 if len(keys)==4:
  widest=max(range(3),key=lambda i:keys[i+1]-keys[i]);fs=([1,3,4,5],[1,2,4,5],[1,2,3,5])[widest]
 return dict(zip(keys,fs if hand=='right' else [6-f for f in fs]))
def build(version):
 level=int(version[1:]);lines=[x.strip() for row in LINES for x in row.split('|')];harm=[x for row in HARM_ROWS for x in row.split()]
 assert len(lines)==len(harm)==120
 for lv,changes,chords in [(1,V1,V1_H),(2,V2,V2_H)]:
  if level>=lv:
   for n,line in changes.items():lines[n-1]=line
   for n,h in chords.items():harm[n-1]=h
 bars=[];events=[];pedals=[];plans=[];start=0.
 for n in range(1,121):
  _,_,sect,title,key=section(n);beats=3. if 41<=n<=56 else 4.;meter=(4,4) if beats==4 else (6,8);h=harm[n-1];ch=H[h];pid=f'P{(n-1)//8+1:02d}_piano'
  texture='driving_eight_note_pulse' if beats==4 else 'compound_middle_reply'
  if level>=1 and (33<=n<=56):texture='moving_inner_response'
  if level>=2 and 73<=n<=104:texture='reordered_return_support'
  if n>=105:texture='settling_cadence'
  b={'bar':n,'start':start,'beats':beats,'bpm':bpm(n),'meter':f'{meter[0]}/{meter[1]}','meter_numerator':meter[0],'meter_denominator':meter[1],'section':sect,'section_title_zh':title,'key_region':key,'harmony_name':h,'harmony':ch,'lead_instrument':'piano','lead_hand':'right','phrase_id':pid,'phrase_position':(n-1)%8+1,'texture':texture,'metrical_grouping':'3+3 eighths' if beats==3 else 'four quarter beats','role_plan':'One singing right-hand melody; left-hand chord tones reinforce the same phrase and harmony.'};bars.append(b)
  def add(p,t,d,v,voice,hand,role,written):
   e={'bar':n,'onset':round(start+t,6),'duration':round(d,6),'pitch':p,'velocity':v,'instrument':'piano','voice':voice,'hand':hand,'role':role,'phrase_id':pid,'phrase_label':LABELS[(n-1)//8],'harmony_name':h,'harmonic_function':'chord_tone' if p%12 in {x%12 for x in ch} else 'melodic_nonchord_tone','written_value_beats':written};events.append(e);return e
  ps=[midi(x) for x in lines[n-1].split()];ds=durations(len(ps),beats,n,2 if level>=2 and n in V2 else 1 if level>=1 and n in V1 else 0);assert sum(ds)==beats
  energy=78 if n<=24 else 71 if n<=40 else 64 if n<=56 else 89 if n<=72 else 94 if n<=80 else 84 if n<=104 else 72 if n<=112 else 62
  t=0
  for i,(pitch,w) in enumerate(zip(ps,ds)):
   gap=.10 if i<len(ps)-1 else .28
   if n==120 and i==len(ps)-1:gap=0
   e=add(pitch,t,w-gap,energy+[2,-1,1,0,-2,1,-1][i%7],'melody','right','lead',w);e['articulation']='flowing_piano_line_with_real_key_release';t+=w
  quiet=energy-26;shell=[ch[0],ch[-1]];inner=ch[1:-1] or [ch[1]]
  if texture=='compound_middle_reply':gestures=[(0,1.05,shell),(1.5,1.0,ch)]
  elif texture=='moving_inner_response':gestures=[(0,.70,shell),(1,.40,inner),(2,.60,ch)] if beats==3 else [(0,.72,[ch[0]]),(1.25,.4,inner),(2.25,.5,shell),(3.25,.4,ch)]
  elif texture=='reordered_return_support':gestures=[(0,.72,shell),(1.25,.40,inner),(2,.50,[ch[0]]),(3,.55,ch)]
  elif texture=='settling_cadence':gestures=[(0,1.35,shell),(2,.95,ch)]
  else:gestures=[(0,.62,[ch[0]]),(1,.42,inner),(2,.52,shell),(3,.55,ch[1:])]
  if n==120:gestures=[(0,beats,ch)]
  for at,dur,keys in gestures:
   for pitch in keys:
    e=add(pitch,at,dur,quiet+(1 if len(keys)==1 else 0),'harmonic_support','left','support',min(dur+.1,beats-at));e['articulation']='shared_harmonic_pulse'
  for hand in ['left','right']:
   ns=[e for e in events if e['bar']==n and e['hand']==hand];keys=sorted({e['pitch'] for e in ns});assert len(keys)<=5 and keys[-1]-keys[0]<=12,(version,n,hand,keys)
   fm=fingermap(keys,hand);pos={'bar':n,'hand':hand,'active':True,'position_id':f'b{n:03d}_{hand}','range':[keys[0],keys[-1]],'pitch_finger_map':{str(k):v for k,v in fm.items()}};plans.append(pos)
   for e in ns:e.update(finger=fm[e['pitch']],hand_position_id=pos['position_id'],hand_position_range=pos['range'],position_keys=keys)
  pedals.extend([{'bar':n,'onset':start,'controller':64,'value':0,'instrument':'piano'},{'bar':n,'onset':start+.08,'controller':64,'value':28 if beats==4 else 30,'instrument':'piano'},{'bar':n,'onset':start+beats-.32,'controller':64,'value':0,'instrument':'piano'}]);start+=beats
 pedals.append({'bar':120,'onset':start,'controller':64,'value':0,'instrument':'piano'})
 hp={(p['bar'],p['hand']):p for p in plans}
 for hand in ['left','right']:
  times=sorted({e['onset'] for e in events if e['hand']==hand})
  for a,z in zip(times,times[1:]):
   old=[e for e in events if e['hand']==hand and e['onset']==a];new=[e for e in events if e['hand']==hand and e['onset']==z];ok=[e['pitch'] for e in old];nk=[e['pitch'] for e in new];op=hp[(old[0]['bar'],hand)];np=hp[(new[0]['bar'],hand)]
   travel=max(abs(min(ok)-min(nk)),abs(max(ok)-max(nk)),max(abs(x-y) for x in ok for y in nk),max(abs(x-y) for x,y in zip(op['range'],np['range'])) if op['position_id']!=np['position_id'] else 0);required=.075+.012*max(0,travel-4)+.014;limit=seconds(bars,z)-required
   for e in old:
    if seconds(bars,e['onset']+e['duration'])>limit:
     e['duration']=round((limit-seconds(bars,e['onset']))*bars[e['bar']-1]['bpm']/60,6);e['release_adjustment']='Whole-grip and actual held-key travel, with14ms extra release margin.'
    assert e['duration']*60/bars[e['bar']-1]['bpm']>=.06,(version,'short gate',e)
 events.sort(key=lambda e:(e['onset'],e['instrument'],e['hand'],e['pitch'],e['voice']));counter={}
 for e in events:
  k=(e['bar'],e['voice']);counter[k]=counter.get(k,0)+1;e['event_id']=f'w100-b{e["bar"]:03d}-{e["voice"]}-{counter[k]:02d}';e.update(target_on_beats=e['onset'],target_off_beats=round(e['onset']+e['duration'],6),target_on_seconds=round(seconds(bars,e['onset']),9),target_off_seconds=round(seconds(bars,e['onset']+e['duration']),9))
 phrases=[]
 for i in range(15):
  pid=f'P{i+1:02d}_piano';ns=[e for e in events if e['phrase_id']==pid];a=min(e['onset'] for e in ns);z=max(e['onset']+e['duration'] for e in ns);phrases.append({'phrase_id':pid,'instrument':'piano','first_bar':i*8+1,'last_bar':i*8+8,'phrase_label':LABELS[i],'target_on_beats':a,'target_off_beats':round(z,6),'target_on_seconds':round(seconds(bars,a),9),'target_off_seconds':round(seconds(bars,z),9)})
 return {'id':100,'title':'Fifty Windows Before Dawn','title_zh':'天亮前的五十扇窗','version':version,'instrumentation':['natural_acoustic_piano'],'bars':bars,'events':events,'phrases':phrases,'pedals':pedals,'total_beats':start,'tail_seconds':6,'hand_position_plan':plans,'performance_contract':{'beat_unit':'quarter-note beats;4/4=4,6/8=3','source_status':'Original symbolic piano score; audio separately validated','pedal':'Low CC64 resonance intent; no assertion of a particular acoustic half-pedal depth','hand_geometry':'Every actual held-key/grip transition audited; pedal does not release a finger','limits':'Symbolic checks are not listening or performer-comfort approval'}}
def dumps(x):return json.dumps(x,ensure_ascii=False,indent=2)+'\n'
def patch(a,b,path=''):
 if a==b:return []
 if isinstance(a,dict) and isinstance(b,dict):
  out=[]
  for k in sorted(set(a)|set(b)):
   p=path+'/'+k.replace('~','~0').replace('/','~1')
   if k not in b:out.append({'op':'remove','path':p})
   elif k not in a:out.append({'op':'add','path':p,'value':b[k]})
   else:out+=patch(a[k],b[k],p)
  return out
 return [{'op':'replace','path':path,'value':b}]
def emit_diff(root,a,b):
 before=dumps(a);after=dumps(b);changes=[]
 for n in range(1,121):
  row={'bar':n,'before_bar':a['bars'][n-1],'after_bar':b['bars'][n-1],'before_events':[e for e in a['events'] if e['bar']==n],'after_events':[e for e in b['events'] if e['bar']==n],'before_pedals':[e for e in a['pedals'] if e['bar']==n],'after_pedals':[e for e in b['pedals'] if e['bar']==n]}
  if any(row['before_'+k]!=row['after_'+k] for k in ['bar','events','pedals']):changes.append(row)
 av,bv=a['version'],b['version'];d={'from_version':av,'to_version':bv,'before_sha256':hashlib.sha256(before.encode()).hexdigest(),'after_sha256':hashlib.sha256(after.encode()).hexdigest(),'changed_bars':[x['bar'] for x in changes],'changes':changes,'phrase_metadata_before':a['phrases'],'phrase_metadata_after':b['phrases'],'position_plan_before':a['hand_position_plan'],'position_plan_after':b['hand_position_plan'],'json_patch':patch(a,b)};(root/f'exact_diff_{av}_to_{bv}.json').write_text(dumps(d));(root/f'exact_diff_{av}_to_{bv}.patch').write_text(''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile=f'score_{av}.json',tofile=f'score_{bv}.json')))
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--outdir',default=str(ROOT));root=Path(ap.parse_args().outdir);root.mkdir(parents=True,exist_ok=True);scores=[build(v) for v in ['v0','v1','v2']]
 for s in scores:(root/f'score_{s["version"]}.json').write_text(dumps(s))
 (root/'score.json').write_text(dumps(scores[-1]));emit_diff(root,scores[0],scores[1]);emit_diff(root,scores[1],scores[2])
if __name__=='__main__':main()
