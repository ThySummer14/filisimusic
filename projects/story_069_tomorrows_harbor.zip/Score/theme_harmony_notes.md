# Work 69 — theme, form, harmony, and performance intent

Title: 来自明日港口的明信片 / Postcard from Tomorrow’s Harbor
Final draft: score_v2.json
Medium: solo acoustic piano throughout. Every event has instrument="piano".
Tempo/meter: 4/4, 88 BPM through bar 61; bars 62–64 at 86, 84, 76 BPM.
Length: 64 bars / 256 quarter beats; 175.169 seconds of metered music plus 4 seconds of requested tail = 179.169 seconds, approximately 2:59.
Feel: contemporary light Latin-influenced piano groove, straight eighth/sixteenth subdivision. No claim of an authentic named traditional style. No swing ratio or long-short timing overlay.

## Original thematic material

The principal postcard idea first appears as fragments in bars 1–4 and becomes an eight-bar sentence at 5–12. Its core is F♯4–A4–B4–A4–F♯4 (D-major degrees 3–5–6–5–3). In bar 5, attacks occur at local quarter beats 0.5, 1, 1.75, 3, and 3.5. The B at 1.75 lasts a full beat, carrying the phrase across beat 2. This is written syncopation, not a playback swing setting. The next bar responds lower, ending on D4. Bars 7–12 answer, rise to C♯5, and breathe rather than copying the first four bars.

The opening idea is singable pentatonic material, but later phrases admit C♯, G, A♯, B♭, D♯, and G♯ only as their local harmony and melodic continuation call for them. The A♯ in F♯7 moves toward B minor; B♭ in Gm6 warms and darkens the subdominant before returning to D; D♯ in B7(b9) points toward E minor.

The contrasting B section starts with D5–B4–A4–B4 and longer tones. Its phrase lengths feel less busy even while the left hand retains the same straight pulse. It explores G-major space, turns through F♯m7–B7(b9)–Em9, and uses D9 to recover G. Bars 29–32 do not simply repeat that route: Gmaj9–Gm6–D/F♯–A13 changes the emotional direction and prepares the choice.

The decision section, bars 33–40, grows upward from F♯4–B4–C♯5–D5. Bm9–F♯7/A♯–Bm7/A–E9/G♯ gives the bass a deliberate descending B–A♯–A–G♯ line. This is a local harmonic voice-leading event; it is not an independent left-hand song. The theme expands to B4–D5–F♯5 at bar 37, the first register peak. The answer descends again. The piece's emotional high point is the decision to accept responsibility for a small change, rather than the arrival of a magical object.

## Developed form and narrative pacing

- Bars 1–4, introduction: the future image is incomplete; a few melody fragments and thin left-hand shells establish its color.
- Bars 5–12, A1: a full, buoyant sentence for the unbuilt pier. Bass and chord answers share that sentence’s harmonic rhythm.
- Bars 13–20, A2: a new continuation passes through F♯7/B minor, then borrowed Gm6; the treasured old seat complicates the easy first idea.
- Bars 21–28, B1: longer melody values and a new upper-register opening accompany attention shifting from the view to the water below it.
- Bars 29–32, B2: a shortened, redirected continuation focuses that observation into a practical problem.
- Bars 33–40, decision: chromatic bass descent, a less settled phrase, a single clear expansion to F♯5, and withdrawal before the return.
- Bars 41–48, A′1: the theme is recognizable but altered. Bar 41 starts on the downbeat instead of withholding the opening F♯; 43 and 45 extend the line upward. Cadence 48 has room to settle.
- Bars 49–56, A′2: the new continuation remembers the decision’s wider intervals and E9/G♯ harmony. It does not erase the minor-subdominant shade at 54.
- Bars 57–64, coda: the motive shortens, the left hand progressively stops answering every opening, and the last two bars move F♯4–A4–E5 to a sustained D5. The retained ninth/sixth chord color lets the harbor remain open, while the melody clearly reaches home.

## Same phrase, two hands

The right hand owns the melody and occasional attached harmonic support. Upper support never has its own independently moving countermelody. It occurs on a selected long melody note, shares that attack, and releases slightly earlier. In bar 64 the right hand settles into F♯4–A4–D5, an eight-semitone span.

The left hand uses written root or fifth/bass-inversion notes followed by compact two/three-note shells. Its musical job is pulse, chord color, and breath. Its attacks alternate between several patterns, change in the contrasting section, contract at important cadences, and become sparse in the coda. There are five bass attack-pattern signatures and additional distinct chord-placement patterns. It is not a perpetual four-beat bass ostinato. Lowest pitches can shift between root, fifth, and a specified inversion, always belonging to the current harmony.

The left-hand chord voicing is thinned when the melody descends close to it. This avoids muddy neighboring attacks as well as exact shared-key conflicts. Bass and comping generally alternate; the final root can be held under the last chord because the combined left-hand span remains modest.

## Interpretation and integration notes

Keep the subdivision straight and lightly buoyant. Do not add a swung quantization template. Melody should remain clearly in front of the shells; the encoded velocities already give it that priority, but the actual piano response still needs an audio check. Phrase breaths are intentional. The short bass and comping durations are articulation, not missing ties.

Pedal values are deliberately partial (0–34), with release at every harmonic boundary and additional internal clears. The center is drier. Final release is at beat 255.9, before the four-second tail. Different piano instruments can interpret these values differently; check damper behavior when integrating.

No sound was rendered or auditioned for this draft. A real REAPER/piano listening pass remains necessary for balance, pedaling, articulation, and overall musical effectiveness. Symbolic audits establish data properties only.

All pitches and rhythms were composed in this deliverable. No previous collection theme, source score, recording, or melody library was opened or reused.
