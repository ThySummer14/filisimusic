"""Restricted SFZ planning and independent emitted-file verification. No engine load."""
from pathlib import Path
import bisect
import hashlib
import json
import math
import os
import re
import wave

HEADER = re.compile(r'<([A-Za-z_][A-Za-z_0-9]*)>')
OPCODE = re.compile(r'([A-Za-z_][A-Za-z_0-9]*)\s*=\s*(.*?)(?=\s+[A-Za-z_][A-Za-z_0-9]*\s*=|\Z)', re.S)
ALLOWED_HEADERS = {'control', 'global', 'master', 'group', 'region', 'curve'}


def require(ok, message):
    if not ok:
        raise ValueError(message)


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for b in iter(lambda: f.read(1024 * 1024), b''):
            h.update(b)
    return h.hexdigest()


def read_text(path):
    return Path(path).read_text(encoding='utf-8-sig')


def mask_comments(text):
    return re.sub(r'/\*.*?\*/|//[^\r\n]*', lambda m: re.sub(r'[^\r\n]', ' ', m.group()), text, flags=re.S)


def parse(text):
    masked = mask_comments(text)
    require(not re.search(r'^\s*#', masked, re.M), 'SFZ includes/macros are unsupported; refusing to guess.')
    headers = list(HEADER.finditer(masked))
    require(headers, 'No SFZ headers found.')
    require(not masked[:headers[0].start()].strip(), 'Unparsed SFZ preamble.')
    state = {'global': {}, 'master': {}, 'group': {}}
    rows = []
    for n, h in enumerate(headers):
        end = headers[n+1].start() if n+1 < len(headers) else len(text)
        typ = h.group(1)
        require(typ in ALLOWED_HEADERS, 'Unreviewed SFZ header: ' + typ)
        body = masked[h.end():end]
        hits = list(OPCODE.finditer(body))
        require(not body[:hits[0].start()].strip() if hits else not body.strip(), 'Unparsed SFZ body.')
        ops = {}
        for m in hits:
            require(m.group(1) != 'sample' or 'sample' not in ops, 'Repeated sample opcode requires manual path review.')
            ops[m.group(1)] = m.group(2).strip()
            require(ops[m.group(1)] and '<' not in ops[m.group(1)] and '>' not in ops[m.group(1)], 'Invalid opcode value.')
        if typ == 'global':
            state = {'global': dict(ops), 'master': dict(ops), 'group': dict(ops)}
        elif typ == 'master':
            state['master'] = state['global'] | ops
            state['group'] = dict(state['master'])
        elif typ == 'group':
            state['group'] = state['master'] | ops
        effective = state['group'] | ops if typ == 'region' else ops
        rows.append({'type': typ, 'start': h.start(), 'end': end, 'raw': text[h.start():end],
                     'ops': ops, 'effective': effective, 'ordered_ops': [(m.group(1), m.group(2).strip()) for m in hits]})
    return rows


def integer(ops, key, default):
    value = ops.get(key, str(default))
    require(bool(re.fullmatch(r'-?\d+', value)), f'Non-numeric {key}={value!r}; unsupported.')
    return int(value)


def key_range(ops):
    key = integer(ops, 'key', 0)
    return [integer(ops, 'lokey', key if 'key' in ops else 0), integer(ops, 'hikey', key if 'key' in ops else 127)]


def is_cc(ops):
    return any(re.fullmatch(r'on_(lo|hi)(hd)?cc\d+', k) for k in ops)


def sample_path(sfz, ops):
    require('sample' in ops and not ops['sample'].startswith('*'), 'Missing/generated samples are unsupported.')
    require(not any(c in ops['sample'] for c in ['\n', '\r', '"']), 'Unsupported sample filename.')
    path = (Path(sfz).parent / ops['sample'].replace('\\', '/')).resolve()
    require(path.is_file(), 'Missing original sample: ' + str(path))
    return path


def score_info(score, max_seconds=None):
    d = json.loads(read_text(score))
    bars, events = d['bars'], d['events']
    require(isinstance(bars, list) and bars and isinstance(events, list) and events, 'Score needs nonempty bars and events.')
    starts, times, total = [], [], 0.0
    def number(x):
        return isinstance(x, (int, float)) and not isinstance(x, bool) and math.isfinite(x)
    for b in bars:
        require(all(number(b[k]) for k in ('start', 'beats', 'bpm')), 'Non-finite bar timing.')
        require(b['beats'] > 0 and b['bpm'] > 0, 'Bar beats and bpm must be positive.')
        require(math.isclose(b['start'], starts[-1] + bars[len(starts)-1]['beats'], abs_tol=1e-8) if starts else b['start'] == 0,
                'Bar starts must be contiguous and start at zero.')
        starts.append(b['start']); times.append(total); total += b['beats'] * 60 / b['bpm']
    tail = d.get('tail_seconds', 8)
    require(number(tail) and tail >= 0, 'tail_seconds must be finite and nonnegative.')
    full_duration = total + tail
    require(max_seconds is None or number(max_seconds) and max_seconds > 0, 'max_seconds must be finite and positive.')
    duration = min(full_duration, max_seconds) if max_seconds is not None else full_duration
    frames = round(duration * 44100)
    require(frames > 0 and frames*8 + 36 < 2**32, 'Output exceeds original RIFF renderer limits.')
    def seconds(beat):
        i = max(0, bisect.bisect_right(starts, beat)-1)
        return times[i] + (beat-starts[i])*60/bars[i]['bpm']
    pairs = set(); selected_events = 0
    for e in events:
        require(type(e['pitch']) is int and 0 <= e['pitch'] <= 127 and type(e['velocity']) is int and 1 <= e['velocity'] <= 127,
                'Score must contain integer MIDI pitches 0–127 and positive velocities 1–127.')
        require(number(e['onset']) and number(e['duration']) and e['onset'] >= 0 and e['duration'] > 0, 'Invalid note timing.')
        # The existing renderer truncates at bars + tail; silently pruning notes outside that window is unsafe.
        require(0 <= round(seconds(e['onset'])*44100) < round(full_duration*44100), 'Note onset lies outside the original render window.')
        if round(seconds(e['onset'])*44100) < frames:
            pairs.add((e['pitch'], e['velocity'])); selected_events += 1
    for e in d.get('pedals', []):
        require(number(e['onset']) and e['onset'] >= 0 and type(e['value']) is int and 0 <= e['value'] <= 127, 'Invalid pedal event.')
    require(pairs, 'No note-ons occur in the requested render window.')
    return {'pairs': sorted(pairs), 'events': selected_events, 'full_score_events': len(events), 'max_seconds': max_seconds, 'frames': frames, 'duration_seconds': duration,
            'sample_rate': 44100, 'bar_count': len(bars)}


def inspect(sfz, score, mode, max_seconds=None):
    text = read_text(sfz)
    rows = parse(text)
    all_ops = {k for r in rows for k in r['ops']}
    forbidden = {k for k in all_ops if k.startswith(('sw_', 'seq_', 'note_offset', 'octave_offset', 'lohdvel', 'hihdvel'))}
    forbidden |= all_ops & {'default_path', 'hint_ram_based', 'direction', 'reverse'}
    forbidden |= {k for k in all_ops if k.startswith('offset') and k != 'offset'}
    require(not forbidden, 'Unreviewed selection/path/RAM opcodes: ' + ', '.join(sorted(forbidden)))
    controls = sum(r['type'] == 'control' for r in rows)
    require(controls <= 1, 'Multiple control sections need review.')
    info = score_info(score, max_seconds)
    pairs, keys = info['pairs'], {p[0] for p in info['pairs']}
    selected, removed, paths, offsets = [], [], set(), {}
    for index, r in enumerate(x for x in rows if x['type'] == 'region'):
        o = r['effective']
        require('sample' in r['ops'], 'Inherited samples need manual path review.')
        path = sample_path(sfz, o); paths.add(path)
        offset = integer(o, 'offset', 0)
        require(offset >= 0, 'Negative sample offset needs review.')
        offsets[path] = max(offsets.get(path, 0), offset)
        lo, hi = key_range(o)
        vl, vh = integer(o, 'lovel', 0), integer(o, 'hivel', 127)
        require((0 <= lo <= hi <= 127 or is_cc(o) and lo == hi == -1) and 0 <= vl <= vh <= 127, 'Invalid region key/velocity range.')
        trigger = o.get('trigger', 'attack')
        require(trigger in {'attack', 'first', 'legato', 'release', 'release_key'}, 'Unknown trigger: ' + trigger)
        if mode == 'complete-bank' or is_cc(o):
            keep = True
        elif trigger in {'release', 'release_key'}:
            keep = any(lo <= k <= hi for k in keys)
        else:
            keep = any(lo <= k <= hi and any(vl <= vv <= vh for vv in {max(0, v-1), v, min(127, v+1)}) for k, v in pairs)
        rec = {'source_region_index': index, 'sample': str(path), 'key_range': [lo, hi],
               'velocity_range': [vl, vh], 'trigger': trigger, 'cc_triggered': is_cc(o)}
        (selected if keep else removed).append(rec)
    require(selected, 'No regions selected.')
    require(mode != 'moonlight-subset' or removed, 'Refusing a complete-bank RAM load in Moonlight mode; narrow the score or review a new strategy.')
    samples = []
    for path in sorted(paths):
        with wave.open(str(path), 'rb') as w:
            require(w.getcomptype() == 'NONE' and w.getnchannels() in (1, 2), 'Only reviewed mono/stereo PCM WAVE samples are supported.')
            frames, channels = w.getnframes(), w.getnchannels()
            require(frames > 0, 'Empty sample: ' + str(path))
            samples.append({'sample': str(path), 'frames': frames, 'channels': channels,
                            'sample_rate': w.getframerate(), 'maximum_source_offset': offsets[path], 'decoded_float32_bytes': frames*channels*4})
    require(samples, 'No sample files.')
    retained = {r['sample'] for r in selected}
    needed = [s for s in samples if s['sample'] in retained]
    return {'mode': mode, 'source_sfz': str(Path(sfz).resolve()), 'source_sha256': sha(sfz),
            'score': str(Path(score).resolve()), 'score_sha256': sha(score), 'score_info': info,
            'original_regions': len(selected) + len(removed), 'selected': selected, 'removed': removed,
            'samples': needed, 'all_sample_count': len(samples),
            'decoded_sample_bytes': sum(s['decoded_float32_bytes'] for s in needed),
            'largest_read_temporary_bytes': max(s['decoded_float32_bytes'] for s in needed),
            'query_preload_bytes': sum(min(s['frames'], 256+s['maximum_source_offset'])*s['channels']*4 for s in samples),
            'query_largest_read_temporary_bytes': max(s['decoded_float32_bytes'] for s in samples)}


def emit(plan, destination):
    source = Path(plan['source_sfz']); text = read_text(source); rows = parse(text)
    chosen = {x['source_region_index']: x for x in plan['selected']}
    output, index = [text[:rows[0]['start']]], 0
    if not any(r['type'] == 'control' for r in rows):
        output.append('<control> hint_ram_based=1\n')
    for r in rows:
        raw = r['raw']
        if r['type'] == 'control':
            raw = raw.replace('<control>', '<control> hint_ram_based=1', 1)
        elif r['type'] == 'region':
            if index not in chosen:
                raw = f'// Nonmatching source region {index} omitted; original inputs unchanged.\n'
            else:
                path = Path(chosen[index]['sample'])
                try:
                    replacement = os.path.relpath(path, Path(destination).parent).replace(os.sep, '/')
                except ValueError:  # Different Windows drives cannot have a relative path.
                    replacement = path.as_posix()
                require('//' not in replacement and not any(c in replacement for c in ['\r', '\n', '<', '>']), 'Unsupported relocated sample path.')
                pattern = r'(?<![A-Za-z_0-9])sample\s*=\s*' + re.escape(r['ops']['sample'])
                raw, changed = re.subn(pattern, lambda m: 'sample=' + replacement, raw, count=1)
                require(changed == 1, 'Sample rewrite failed.')
            index += 1
        output.append(raw)
    Path(destination).write_text(''.join(output), encoding='utf-8')


def independent_parse(path):
    """Separate line-oriented parser, adapted from the independent native verifier."""
    text = re.sub(r'/\*.*?\*/', '', read_text(path), flags=re.S)
    text = '\n'.join(l.split('//', 1)[0] for l in text.splitlines())
    require(not re.search(r'^\s*#', text, re.M), 'Independent parser found a preprocessor directive.')
    blocks = []
    for line in text.splitlines():
        line = line.strip()
        if not line:
            continue
        if line.startswith('<'):
            h = re.fullmatch(r'<([a-z]+)>\s*(.*)', line)
            require(h is not None, 'Independent parser requires one header per line.')
            blocks.append([h[1], h[2]])
        else:
            require(blocks, 'Unparsed preamble.'); blocks[-1][1] += '\n' + line
    g, master, group, regions, headers = {}, {}, {}, [], []
    for typ, body in blocks:
        require(typ in ALLOWED_HEADERS, 'Unsupported independent header.')
        hits = list(re.finditer(r'(?<!\S)([A-Za-z_][\w]*)\s*=', body))
        o = {h[1]: body[h.end():hits[i+1].start() if i+1 < len(hits) else len(body)].strip() for i, h in enumerate(hits)}
        if typ == 'global': g = o.copy(); master = o.copy(); group = o.copy()
        elif typ == 'master': master = g | o; group = master.copy()
        elif typ == 'group': group = master | o
        if typ == 'region':
            x = group | o; x['sample'] = str(sample_path(path, x)); regions.append(x)
        else:
            headers.append([typ, o])
    return regions, headers


def verify_emitted(plan, subset):
    require(sha(plan['source_sfz']) == plan['source_sha256'], 'Source SFZ changed.')
    require(sha(plan['score']) == plan['score_sha256'], 'Score changed.')
    original, headers = independent_parse(plan['source_sfz'])
    small, emitted_headers = independent_parse(subset)
    expected = [[t, o | {'hint_ram_based': '1'} if t == 'control' else o] for t, o in headers]
    if not any(t == 'control' for t, _ in headers):
        expected.insert(0, ['control', {'hint_ram_based': '1'}])
    require(expected == emitted_headers, 'Header/curve/opcode order or values changed.')
    ids = [r['source_region_index'] for r in plan['selected']]
    require(ids == sorted(set(ids)) and len(ids) == len(small), 'Selected region IDs are not unique and ordered.')
    require(len(original) == plan['original_regions'], 'Original region count changed.')
    for idx, emitted in zip(ids, small):
        require(emitted == original[idx], f'Effective parameters changed in source region {idx}.')
    source_rows, small_rows = parse(read_text(plan['source_sfz'])), parse(read_text(subset))
    # Preserve repeated source opcodes as well as effective last-value dictionaries.
    ordered_headers = [(r['type'], ([('hint_ram_based', '1')] if r['type'] == 'control' else []) + r['ordered_ops']) for r in source_rows if r['type'] != 'region']
    if not any(r['type'] == 'control' for r in source_rows):
        ordered_headers.insert(0, ('control', [('hint_ram_based', '1')]))
    require(ordered_headers == [(r['type'], r['ordered_ops']) for r in small_rows if r['type'] != 'region'], 'Ordered header opcodes changed, including duplicate declarations.')
    require([r['raw'] for r in source_rows if r['type'] == 'curve'] == [r['raw'] for r in small_rows if r['type'] == 'curve'], 'Raw curve text changed.')
    return original


def verify_native(plan, subset, native, library):
    original = verify_emitted(plan, subset)
    require(native['sfz_sha256'] == plan['source_sha256'], 'Native SFZ hash mismatch.')
    require(native['library_sha256'] == sha(library), 'Native library hash mismatch.')
    regions = native['regions']
    require(len(regions) == len(original), 'Native/parsed region count mismatch.')
    cc = {i for i, o in enumerate(original) if is_cc(o)}
    keep = {r['source_region_index'] for r in plan['selected']}
    require(cc <= keep, 'A CC-triggered branch was removed.')
    for i, (o, n) in enumerate(zip(original, regions)):
        require(n['index'] == i, 'Native region order mismatch.')
        require(str((Path(plan['source_sfz']).parent / n['sample'][0].replace('\\', '/')).resolve()) == o['sample'], f'Native sample mismatch in region {i}.')
        require(n['trigger'] == [o.get('trigger', 'attack')], f'Native trigger mismatch in region {i}.')
        require(i in cc or n['key_range'] == key_range(o), f'Native key range disagrees with restricted parser in region {i}.')
        require(len(n['vel_range']) == 2 and all(math.isfinite(v) for v in n['vel_range']), 'Invalid native velocity range.')
    table = native['integer_velocity_to_actual_trigger_value']
    require(set(table) == {str(v) for v in range(1, 128)}, 'Incomplete native velocity table.')
    proof = []
    for key, velocity in plan['score_info']['pairs']:
        value = table[str(velocity)]['value']
        require(math.isfinite(value) and 0 <= value <= 1, 'Invalid actual MIDI trigger value.')
        notes = [n['index'] for n in regions if n['index'] not in cc and n['trigger'][0] in {'attack', 'first', 'legato'} and n['key_range'][0] <= key <= n['key_range'][1] and n['vel_range'][0] <= value <= n['vel_range'][1]]
        releases = [n['index'] for n in regions if n['index'] not in cc and n['trigger'][0] in {'release', 'release_key'} and n['key_range'][0] <= key <= n['key_range'][1]]
        require(set(notes + releases) <= keep, f'Missing native candidate for key={key}, velocity={velocity}.')
        require(notes, f'No native attack candidates for key={key}, velocity={velocity}.')
        proof.append({'key': key, 'velocity': velocity, 'actual_value': value, 'ordered_note_candidates': notes, 'release_candidates': releases})
    if plan['mode'] == 'complete-bank':
        require(len(keep) == len(original), 'Complete-bank mode pruned regions.')
    return {'status': 'PASS', 'claim': 'Native candidate coverage and emitted parameter preservation; not an audio-equivalence certificate.',
            'all_cc_region_ids': sorted(cc), 'proof': proof, 'subset_sha256': sha(subset), 'library_sha256': sha(library)}
