-- Generated pre-render checkpoint; run only in a dedicated -newinst.
local project = [=[PROJECT/revisions/089_stairs_v3.rpp]=]
local readback_path = [=[PROJECT/revisions/089_stairs_v3.native_readback.tsv]=]
local verified_path = [=[PROJECT/revisions/089_stairs_v3.native_verified.json]=]
local failure_path = [=[PROJECT/revisions/089_stairs_v3.native_failure.txt]=]
local intended = { I_PANMODE = 5, D_VOL = 3.8, D_PAN = 0.0, D_WIDTH = 0.88, D_PANLAW = 1 }
local fields = { "I_PANMODE", "D_VOL", "D_PAN", "D_WIDTH", "D_PANLAW" }
local report, sentinel_pending
local function require_project()
  local _, filename = reaper.EnumProjects(-1, "")
  assert(filename == project, "Unexpected active project: " .. filename)
  assert(reaper.CountTracks(0) == 1, "Expected exactly one piano track")
  local track = assert(reaper.GetTrack(0, 0), "Missing piano track")
  local _, name = reaper.GetTrackName(track)
  assert(name == [=[Original acoustic piano | coordinated lead and support]=], "Unexpected piano track name: " .. name)
  return track
end
local function read_values(track, stage, require_match)
  for _, key in ipairs(fields) do
    local actual = reaper.GetMediaTrackInfo_Value(track, key)
    local difference = math.abs(actual - intended[key])
    report:write(string.format("%s\t%s\t%.17g\t%.17g\t%.17g\n",
      stage, key, intended[key], actual, difference))
    report:flush()
    if require_match then
      assert(difference <= 1e-8, stage .. " " .. key .. " mismatch: " .. actual)
    end
  end
end
-- Invalidate stale evidence before attempting a new checkpoint.
os.remove(verified_path)
os.remove(failure_path)
local ok, message = xpcall(function()
  reaper.Main_openProject(project)
  local track = require_project()
  report = assert(io.open(readback_path, "w"))
  report:write("stage\tparameter\texpected\tactual\tabsolute_error\n")
  read_values(track, "before", false)
  for _, key in ipairs(fields) do
    assert(reaper.SetMediaTrackInfo_Value(track, key, intended[key]),
      "Native API rejected " .. key)
  end
  read_values(track, "applied", true)
  reaper.Main_SaveProject(0, false)
  assert(reaper.IsProjectDirty(0) == 0, "Project save left unsaved changes")
  -- A changed in-memory sentinel makes this a real disk reload test.
  local sentinel = intended.D_WIDTH == 0 and 1 or 0
  assert(reaper.SetMediaTrackInfo_Value(track, "D_WIDTH", sentinel))
  sentinel_pending = true
  assert(math.abs(reaper.GetMediaTrackInfo_Value(track, "D_WIDTH") - sentinel) <= 1e-8)
  reaper.Main_openProject("noprompt:" .. project)
  sentinel_pending = false
  track = require_project()
  read_values(track, "reopened", true)
  report:close()
  report = nil
  local proof = assert(io.open(verified_path, "w"))
  proof:write([=[{
  "status": "PASS",
  "project": "PROJECT/revisions/089_stairs_v3.rpp",
  "track_index": 0,
  "native_api_set_and_read": true,
  "saved_and_reopened": true,
  "unsaved_width_sentinel_discarded": true,
  "absolute_tolerance": 1e-08,
  "expected": {
    "I_PANMODE": 5,
    "D_VOL": 3.8,
    "D_PAN": 0.0,
    "D_WIDTH": 0.88,
    "D_PANLAW": 1
  },
  "actual_readback": "PROJECT/revisions/089_stairs_v3.native_readback.tsv",
  "audio_rendered": false
}
]=])
  proof:close()
end, debug.traceback)
if report then report:close() end
if not ok then
  if sentinel_pending then reaper.Main_openProject("noprompt:" .. project) end
  local failure = io.open(failure_path, "w")
  if failure then failure:write(message .. "\n"); failure:close() end
end
-- A native process exit is not proof of success: require the PASS JSON above.
reaper.Main_OnCommand(40004, 0)
