068《缝起日食的人》 / The Seamstress of the Eclipse
ORIGINAL NON-RENDERED STORY + SCORE HANDOFF

Use score_v2.json, which is byte-identical to score.json.
This is an explicit acoustic-piano + flute revision of the unavailable violin concept. It is not a violin recording, and this folder contains no audio or REAPER project.

Story: During the only short interval when eclipse-cloth can be sewn, a seamstress must choose between finishing the ceremonial emblem and using that material to cover the workers holding up the canopy. She cuts the emblem, loses the promised silver scissors, and changes how future festivals seat people. The opening at the canopy’s centre remains.

Music: 80 bars of 4/4; an energetic 112/120/116 BPM piano spine, with two breathing flute passages and a brief 100 BPM decision. The main phrase first folds inward; after the decision its ending reaches upward and outward. The home-key return is delayed and rewritten rather than copied as a loop.
Duration: 172.811384784 seconds before tail, 176.811384784 seconds including the requested 4-second tail.

Essential files
- story_zh.txt: full original Chinese story and a short musical explanation
- composition_notes_zh.txt: theme, harmony, role allocation, narrative/form rationale
- score_v0.json / score_v1.json / score_v2.json: preserved compositional versions
- compose.py: reproducible, standard-library-only generator
- revision_log.md / revision_changes.json: two substantive revisions, with event differences
- flute_entry_intentions.json: all 30 intended pitched arrivals, phrase/layer labels and original note-offs
- phrases_v2.json: 10 phrase boundaries and breath gaps
- integration_notes.txt: exact instructions and caveats for measured onset compensation
- verify_score.py: independent JSON read-back and deterministic-rebuild check
- audit_v0.json / audit_v1.json / audit_v2.json / validation_readback.json: technical results
- reproducibility_check.json / build_manifest.json / form_design.json / thematic_material.json: provenance of this score package

Run locally with Python standard library:
python 3 compose.py
python 3 verify_score.py

Final technical figures
876 events: 846 piano, 30 flute.
Flute MIDI range 74–83; genuine pp and mf layers, one layer per phrase.
Nominal flute gate 0.694444–1.194444 seconds.
Conservative longest gate after 0.209-second advance:1.403444 seconds.
Minimum nominal phrase gap 1.027778 seconds; after worst advance 0.818778 seconds.
Minimum nominal intra-phrase gap 0.277778 seconds; after worst advance 0.068778 seconds.
Largest simultaneous key-held span:12 semitones in either piano hand.
No piano melody under a flute foreground; no flute under piano foreground.
Two revisions change 40 and 27 bars respectively. Rebuilding produces identical files.

Remaining integration work
All flute timings are UNCOMPENSATED target pitched arrivals. The parent must apply each measured pitch/layer attack delay, preserve note-offs, and perform the actual audio integration, rendering and listening. These numerical checks establish structural feasibility only. They do not certify musical quality, sample balance, audible release overlap or complete listening approval.
