import pathlib,json,aifc,wave,hashlib
P=pathlib.Path(__file__).parent;(P/'Samples').mkdir(exist_ok=True);d=json.loads((P/'scale_analysis.json').read_text())[0];ind=json.loads((P/'independent_pitch_review.json').read_text())['notes']
provenance=json.loads((P/'provenance.json').read_text());assert hashlib.sha256((P/d['source_file']).read_bytes()).hexdigest()==provenance['sha256'],'Original source checksum mismatch'
with aifc.open(str(P/d['source_file']),'rb')as f:sr=f.getframerate();sw=f.getsampwidth();ch=f.getnchannels();raw=f.readframes(f.getnframes());frames=len(raw)//2
assert sw==2 and ch==1
sfz='<global> ampeg_attack=0.002 ampeg_release=0.10 loop_mode=no_loop amp_veltrack=70\n';rows=[]
for j,note in enumerate(d['notes']):
 start=max(0,note['active_start_frame']-round(.04*sr));end=min(frames,start+round(3.2*sr));b=raw[start*2:end*2];little=bytearray(len(b));little[0::2]=b[1::2];little[1::2]=b[0::2];name=f"cello_pizz_mf_{note['midi']}.wav";dest=P/'Samples'/name
 with wave.open(str(dest),'wb')as w:w.setnchannels(1);w.setsampwidth(2);w.setframerate(sr);w.writeframes(little)
 # The independent stable-window fundamental estimate, not the failed generic40-cent gate.
 cents=ind[j]['independent_fundamental_windows'][1]['cents'];assert abs(cents)<65;early=ind[j]['independent_fundamental_windows'][0]['cents'];assert abs(cents-early)<12,'Unstable initial pitch';tune=round(-cents,2);sfz+=f"<region> key={note['midi']} pitch_keycenter={note['midi']} tune={tune} sample=Samples/{name}\n";rows.append(dict(midi=note['midi'],source=d['source_file'],source_start_frame=start,source_end_frame=end,source_original_bits=16,source_original_channels=1,derived_file='Samples/'+name,duration=(end-start)/sr,tune_cents=tune,sha256=hashlib.sha256(dest.read_bytes()).hexdigest()))
(P/'Iowa_cello_pizz_C2_B2_mf.sfz').write_text(sfz);(P/'mapping_manifest.json').write_text(json.dumps({'operation':'Lossless original mono16bitPCM crop into WAV, preserving3.2sec including natural decay; no resampling or normalization of stored samples.','pitch_handling':'Original stopped-string pitches were measurably flat, up toabout59cents. SFZplaybacktuning corrects the independent central-window estimate. Natural decay pitch drift remains; this is not perfect live intonation.','limits':'One recordedmflayer. Velocity changes playback gain, not recorded playing intensity. Pizzicato, no truelegato, no sustainloop.','files':rows},indent=2))
test={'title':'Retuned natural cello pizzicato technical proof','bars':[{'bar':1,'start':0,'beats':6,'bpm':60,'section':'C2,D2,E2'},{'bar':2,'start':6,'beats':6,'bpm':60,'section':'Ab2,Bb2,B2'}],'events':[dict(bar=1 if j<3 else 2,onset=j*2,duration=1.5,pitch=[36,38,40,44,46,47][j],velocity=90,voice='cello')for j in range(6)],'pedals':[],'total_beats':12,'tail_seconds':2.5};(P/'test_score.json').write_text(json.dumps(test,indent=2))
(P/'test.rpp').write_text(f'''<REAPER_PROJECT 0.1 7.82 1
  SAMPLERATE 44100 0 0
  TEMPO 60 4 4 0
  MASTER_VOLUME 1
  RENDER_FILE "{P}/cello_pizz_proof.wav"
  RENDER_FMT 0 2 44100
  RENDER_1X 0
  RENDER_RANGE 0 0 14.5 0 1000
  RENDER_STEMS 0
  RENDER_DITHER 0
  <RENDER_CFG
    ZXZhdxgAAA==
  >
  <TRACK
    NAME "Natural pizzicato | one mf layer | documented tuning"
    VOLPAN 3 0 1 -1
    MAINSEND 1
    <ITEM
      POSITION 0
      LENGTH 14.5
      VOLPAN 1 0 1 -1
      <SOURCE WAVE
        FILE "cello_float32.wav"
      >
    >
  >
>
''');print(len(rows),'pizzicato notes mapped')
