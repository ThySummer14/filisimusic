from copy import deepcopy

def pitch(s):
 return 12*(int(s[-1])+1)+{'C':0,'D':2,'E':4,'F':5,'G':7,'A':9,'B':11}[s[0]]+s[1:-1].count('#')-s[1:-1].count('b')
def decode(line):
 result=[];t=0
 for token in line.split():
  name,units=token.split(':');dur=float(units)/2
  if name!='R':result.append((pitch(name),t,dur))
  t+=dur
 return result,t
class Writer:
 def __init__(self):self.bars=[];self.events=[];self.pedals=[];self.start=0;self.n=0
 def bar(self,name,bpm,beats,h,ch):
  self.n+=1;self.beats=beats;self.bpm=bpm;self.ch=ch
  numerator,denominator=(int(beats*2),8) if beats in (2.5,3.5) else ((6,8) if METER=='6/8' else (int(beats),4))
  self.bars.append(dict(bar=self.n,start=self.start,beats=beats,bpm=bpm,meter_numerator=numerator,meter_denominator=denominator,section=name,harmony_name=h,harmony=ch))
 def add(self,p,t,d,v=72,inst='piano',voice='theme',hand='right',art='detached'):
  if d>0 and t<self.beats:
   self.events.append(dict(bar=self.n,onset=round(self.start+t,6),duration=round(min(d,self.beats-t),6),pitch=int(p),velocity=max(1,min(127,int(v))),instrument=inst,voice=voice,hand=hand if inst=='piano' else 'none',articulation=art))
 def line(self,line,v=80,hand='right',transpose=0):
  notes,total=decode(line);assert abs(total-self.beats)<1e-7,(self.n,total,self.beats,line)
  for p,t,d in notes:self.add(p+transpose,t,max(.11,d-.09),v+(3 if t==0 else 0),hand=hand)
  return notes
 def release(self,amount=0,length=.7):
  self.pedals.append(dict(bar=self.n,onset=self.start,controller=64,value=0,instrument='piano'))
  if amount:
   self.pedals.extend([dict(bar=self.n,onset=self.start+.05,controller=64,value=amount,instrument='piano'),dict(bar=self.n,onset=self.start+length,controller=64,value=0,instrument='piano')])
  self.start+=self.beats
 def result(self,level):
  self.pedals.append(dict(bar=self.n,onset=self.start-.01,controller=64,value=0,instrument='piano'))
  return dict(id=ID,title=TITLE,title_zh=TITLE_ZH,version=f'v{level}',bars=self.bars,events=self.events,pedals=self.pedals,total_beats=self.start,tail_seconds=5,instrument_map=INSTRUMENT_MAP)
def material(level):
 n=0
 for section,bpm,beats,texture,hs,phrase_names in BLOCKS:
  lines=[]
  for pn in phrase_names.split():lines+=P[pn].split('|')
  harmonies=hs.split();assert len(lines)==len(harmonies),(section,len(lines),len(harmonies))
  for h,line in zip(harmonies,lines):
   n+=1
   for lv,rev in [(1,REV1),(2,REV2)]:
    if level>=lv and n in rev:h,line=rev[n]
   yield n,section,bpm,beats,texture,h,line
ID=129;TITLE='Kitchen Timer Relay';TITLE_ZH='转盘上的秒针';METER='4/4';INSTRUMENT_MAP={'piano':'piano','cello':'arco'}
RENDERER_NOTES='Cello short-bow D3–B3 only. Every bowed gesture is 0.38–0.58 seconds with >=0.2-second inter-bow space. No pizzicato. Piano carries all rapid kitchen activity.'
H={'Gm':[43,50,58],'Eb':[39,55,58],'Bb':[46,53,62],'F':[41,53,57],'D7':[38,54,60],'Cm':[36,55,63],'Gm/D':[38,55,58],'A7':[45,55,61],'C':[36,52,55],'Dsus':[38,55,60],'G':[43,50,59]}
CEL={'Gm':[55,58],'Eb':[51,58],'Bb':[58,53],'F':[53,57],'D7':[54,57],'Cm':[55,51],'Gm/D':[50,58],'A7':[57,55],'C':[52,55],'Dsus':[50,55],'G':[55,59]}
P={
'a':'G5:1 D5:1 Bb4:1 D5:1 G5:2 R:2|Eb5:1 G5:1 Bb5:2 G5:1 Eb5:1 D5:2|F5:1 D5:1 Bb4:2 D5:1 F5:1 Bb5:2|A5:1 F5:1 E5:1 F5:1 C5:2 R:2',
'b':'Bb5:1 G5:1 D5:1 Bb4:1 D5:2 G5:2|G5:1 Eb5:1 C5:2 D5:1 Eb5:1 G5:2|A5:1 F#5:1 D5:2 C5:1 D5:1 F#5:2|G5:2 D5:1 Bb4:1 G4:2 R:2',
'prep':'D5:1 G5:1 Bb5:1 A5:1 G5:1 F5:1 D5:2|Eb5:1 Bb5:1 G5:1 Eb5:1 D5:1 C5:1 Bb4:2|F5:1 Bb5:1 D6:1 C6:1 Bb5:1 A5:1 F5:2|F#5:1 A5:1 D6:1 C6:1 A5:1 F#5:1 D5:2',
'count':'G4:2 Bb4:2 D5:2 R:2|G4:2 C5:2 Eb5:2 R:2|A4:2 D5:2 F#5:2 R:2|Bb4:2 G4:2 R:4',
'count2':'Bb4:2 D5:2 F5:2 R:2|A4:2 C5:2 F5:2 R:2|G4:2 C5:2 Eb5:2 R:2|F#4:2 A4:2 D5:2 R:2',
'half':'G5:1 D5:1 Bb4:2|Eb5:1 G5:1 Bb5:2|A5:1 F#5:1 D5:2|G5:1 D5:1 R:2',
'oven':'Bb5:2 D6:1 C6:1 Bb5:1 A5:1 F5:2|A5:2 C6:1 Bb5:1 A5:1 G5:1 F5:2|G5:1 C6:1 Eb6:2 D6:1 C6:1 G5:2|F#5:1 A5:1 D6:2 C6:1 A5:1 F#5:2',
'heat':'G5:1 Bb5:1 D6:1 F6:1 Eb6:1 D6:1 Bb5:2|Eb6:1 Bb5:1 G5:1 Eb5:1 G5:1 Bb5:1 D6:2|F5:1 A5:1 C6:1 Eb6:1 D6:1 C6:1 A5:2|D6:1 C6:1 A5:1 F#5:1 D5:2 R:2',
'wait':'R:2 D5:2 G5:2 R:2|R:4 Eb5:2 G5:2|F#5:2 R:2 D5:2 R:2|G5:2 R:6',
'plate':'G5:1 D6:1 Bb5:2 A5:1 G5:1 D5:2|Eb5:1 G5:1 C6:2 Bb5:1 G5:1 Eb5:2|F5:1 Bb5:1 D6:2 C6:1 Bb5:1 A5:2|F#5:1 A5:1 D6:1 C6:1 A5:2 R:2',
'done':'B5:2 G5:1 D5:1 B4:2 D5:2|G5:2 E5:1 C5:1 G4:2 C5:2|A5:1 F#5:1 D5:2 C5:1 A4:1 F#4:2|G5:1 D5:1 B4:2 G4:2 R:2'
}
BLOCKS=[
('Already_late',118,4,'chop','Gm Eb Bb F Gm Cm D7 Gm','a b'),
('Cut_and_count',122,4,'chop','Gm Eb Bb D7 Gm Eb Bb D7','prep prep'),
('Someone_at_door',108,4,'offbeat','Gm Eb Bb F Gm Cm D7 Gm','a b'),
('Timer_speaks',96,4,'bowlead','Gm Cm D7 Gm Bb F Cm D7','count count2'),
('Half_measures',116,2,'halftime','Gm Eb D7 Gm Gm Eb D7 Gm','half half'),
('Oven_window',110,4,'circles','Bb F Cm D7 Bb F Cm D7','oven oven'),
('Too_hot',132,4,'heat','Gm Eb F D7 Gm Eb F D7','heat heat'),
('Take_the_pan',118,4,'relay','Gm Cm Bb D7 Gm Eb Bb D7','plate prep'),
('Eight_breaths',82,4,'wait','Gm Eb D7 Gm Gm Eb D7 Gm','wait wait'),
('Plate_by_plate',114,4,'relay','Gm Cm Bb D7 Gm Cm D7 Gm','plate b'),
('Carry_together',124,4,'carry','Gm Eb F D7 Gm Cm Bb D7','heat plate'),
('Sit_while_warm',108,4,'done','Gm Eb Bb F G C D7 G','a done')]
REV1={41:('Bb','D6:1 Bb5:1 F5:2 A5:1 Bb5:1 D6:2'),42:('F','C6:2 A5:1 F5:1 G5:1 A5:1 C6:2'),43:('Cm','Eb6:1 D6:1 C6:1 G5:1 Bb5:2 G5:2'),44:('Dsus','A5:1 D6:1 G6:2 F6:1 D6:1 C6:2'),45:('Gm/D','D6:1 Bb5:1 G5:2 F5:1 G5:1 Bb5:2'),46:('Eb','G5:1 Bb5:1 Eb6:2 D6:1 Bb5:1 G5:2'),47:('A7','G5:2 E5:1 C#5:1 E5:1 G5:1 A5:2'),48:('D7','F#5:1 D5:1 C5:2 A4:2 R:2')}
REV2={81:('Gm','G5:1 Bb5:1 D6:2 R:2 Bb5:2'),82:('Eb','G5:1 Eb5:1 Bb4:2 R:2 G5:2'),83:('C','G5:1 E5:1 C5:1 E5:1 G5:2 C6:2'),84:('D7','A5:1 F#5:1 D5:2 R:4'),85:('Gm','D5:1 G5:1 Bb5:2 A5:1 G5:1 F5:2'),86:('Cm','Eb5:1 G5:1 C6:2 Bb5:1 G5:1 Eb5:2'),87:('Bb','D6:1 C6:1 Bb5:1 F5:1 D5:2 F5:2'),88:('D7','F#5:1 A5:1 D6:2 R:4')}
def build(level):
 w=Writer()
 for n,section,bpm,beats,style,h,line in material(level):
  ch=H[h];w.bar(section,bpm,beats,h,ch);v={'chop':91,'offbeat':80,'bowlead':62,'halftime':87,'circles':78,'heat':103,'relay':84,'wait':50,'carry':94,'done':83}[style]
  if style=='bowlead':
   for q,t in zip(CEL[h],[.25,2.25]):w.add(q,t,.84,68,inst='cello',voice='timer_two_notes',art='short_bow')
   for t,p in [(0,ch[0]),(1.5,ch[2]+12),(3.25,ch[1]+12)]:w.add(p,t,.42,54,voice='around_timer',hand='left' if t==0 else 'right')
  else:w.line(line,v)
  if style not in ('bowlead','wait'):
   ts=[0,2] if style in ('circles','done') else ([0,1] if style=='halftime' else [.5,1.5,3])
   if style=='relay':ts=[0,2.5]
   if level>=1 and 41<=n<=48:ts=[0,1.5,3]
   if level>=2 and 81<=n<=88:ts=[0,2.5] if n%2 else [.75,2]
   for j,t in enumerate(ts):w.add(ch[0] if j%2==0 else ch[1],t,.32,v-24,voice='kitchen_footwork',hand='left')
  if style in ('relay','carry') and n%2==0:
   for q,t in zip(CEL[h],[.25,2.25]):w.add(q,t,.84,75,inst='cello',voice='passed_pan',art='short_bow')
  if style=='wait':
   if n%4 in (1,3):w.add(CEL[h][0],.25,.8,43,inst='cello',voice='waiting_bow',art='short_bow')
   if n%4==0:w.add(ch[0],0,.7,40,voice='last_tick',hand='left')
  if level>=2 and 81<=n<=88 and n%2:
   w.add(CEL[h][1],2.65,.84,75,inst='cello',voice='carry_reply',art='short_bow')
  w.release(28 if style in ('circles','done') else 0,.65)
 return w.result(level)
