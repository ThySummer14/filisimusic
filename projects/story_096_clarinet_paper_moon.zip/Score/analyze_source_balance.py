from pathlib import Path
import struct,json,numpy as np
P=Path(__file__).parent;score=json.loads((P/'ensemble_score.json').read_text());data={};sr=44100
for inst in ['piano','clarinet']:
 f=P/'revisions'/f'{inst}_v2.wav'
 with f.open('rb') as h:
  h.seek(12)
  while True:
   k,n=struct.unpack('<4sI',h.read(8))
   if k==b'data':offset=h.tell();break
   h.seek(n+n%2,1)
 data[inst]=np.memmap(f,dtype='<f4',mode='r',offset=offset,shape=(n//8,2))
rows=[];t=0
for b in score['bars']:
 end=t+b['beats']*60/b['bpm'];row={'bar':b['bar'],'lead':b['lead_instrument'],'section':b['section'],'start':t,'end':end}
 for inst,a in data.items():
  x=a[round(t*sr):round(end*sr)].astype('float64');row[inst+'_rms']=float(np.sqrt(np.mean(x*x)))
 rows.append(row);t=end
for lead in ['piano','clarinet']:
 selected=[x for x in rows if x['lead']==lead];print(lead,{i:float(np.mean([x[i+'_rms'] for x in selected])) for i in data})
last=0
for a in data.values():
 start=max(0,len(a)-8*sr);ind=np.flatnonzero(np.max(np.abs(a[start:]),axis=1)>1e-6)
 if len(ind):last=max(last,(start+int(ind[-1]))/sr)
out={'per_bar':rows,'last_activity_seconds':last,'render_end':round(last+.7,2),'method':'Numerical role-level RMS and tail inspection, not a listening assessment'};(P/'source_role_balance.json').write_text(json.dumps(out,indent=2));print(last,out['render_end'])
