from copy import deepcopy

def pitch(s):
 return 12*(int(s[-1])+1)+{'C':0,'D':2,'E':4,'F':5,'G':7,'A':9,'B':11}[s[0]]+s[1:-1].count('#')-s[1:-1].count('b')
def decode(line):
 result=[];t=0
 for token in line.split():
  name,units=token.split(':');dur=float(units)/2
  if name!='R':result.append((pitch(name),t,dur))
  t+=dur
 return result,t
class Writer:
 def __init__(self):self.bars=[];self.events=[];self.pedals=[];self.start=0;self.n=0
 def bar(self,name,bpm,beats,h,ch):
  self.n+=1;self.beats=beats;self.bpm=bpm;self.ch=ch
  numerator,denominator=(int(beats*2),8) if beats in (2.5,3.5) else ((6,8) if METER=='6/8' else (int(beats),4))
  self.bars.append(dict(bar=self.n,start=self.start,beats=beats,bpm=bpm,meter_numerator=numerator,meter_denominator=denominator,section=name,harmony_name=h,harmony=ch))
 def add(self,p,t,d,v=72,inst='piano',voice='theme',hand='right',art='detached'):
  if d>0 and t<self.beats:
   self.events.append(dict(bar=self.n,onset=round(self.start+t,6),duration=round(min(d,self.beats-t),6),pitch=int(p),velocity=max(1,min(127,int(v))),instrument=inst,voice=voice,hand=hand if inst=='piano' else 'none',articulation=art))
 def line(self,line,v=80,hand='right',transpose=0):
  notes,total=decode(line);assert abs(total-self.beats)<1e-7,(self.n,total,self.beats,line)
  for p,t,d in notes:self.add(p+transpose,t,max(.11,d-.09),v+(3 if t==0 else 0),hand=hand)
  return notes
 def release(self,amount=0,length=.7):
  self.pedals.append(dict(bar=self.n,onset=self.start,controller=64,value=0,instrument='piano'))
  if amount:
   self.pedals.extend([dict(bar=self.n,onset=self.start+.05,controller=64,value=amount,instrument='piano'),dict(bar=self.n,onset=self.start+length,controller=64,value=0,instrument='piano')])
  self.start+=self.beats
 def result(self,level):
  self.pedals.append(dict(bar=self.n,onset=self.start-.01,controller=64,value=0,instrument='piano'))
  return dict(id=ID,title=TITLE,title_zh=TITLE_ZH,version=f'v{level}',bars=self.bars,events=self.events,pedals=self.pedals,total_beats=self.start,tail_seconds=5,instrument_map=INSTRUMENT_MAP)
def material(level):
 n=0
 for section,bpm,beats,texture,hs,phrase_names in BLOCKS:
  lines=[]
  for pn in phrase_names.split():lines+=P[pn].split('|')
  harmonies=hs.split();assert len(lines)==len(harmonies),(section,len(lines),len(harmonies))
  for h,line in zip(harmonies,lines):
   n+=1
   for lv,rev in [(1,REV1),(2,REV2)]:
    if level>=lv and n in rev:h,line=rev[n]
   yield n,section,bpm,beats,texture,h,line
ID=128;TITLE='Return the Kite';TITLE_ZH='逆风还风筝';METER='6/8';INSTRUMENT_MAP={'piano':'piano','flute':'flute'}
RENDERER_NOTES='Flute C5–B5 with separated 0.5–0.8-second breath gestures; all fast running motion belongs to piano. Opening suspended, first peak before midpoint, renewed last dance.'
H={'D':[38,54,57],'A':[45,52,61],'Bm':[47,54,62],'G':[43,55,59],'Em':[40,55,59],'F#7':[42,52,58],'D/F#':[42,57,62],'A7':[45,55,61],'C':[36,52,55],'G6':[43,52,59],'Dsus':[38,55,57],'B7':[47,57,63]}
P={
'air':'D5:2 R:2 A5:2|F#5:3 E5:1 R:2|B5:2 A5:1 F#5:1 R:2|G5:2 D5:2 R:2',
'seed':'D5:1 F#5:1 A5:2 F#5:1 E5:1|C#5:1 E5:1 A5:2 G5:1 E5:1|F#5:1 B5:1 A5:1 F#5:1 E5:2|D5:2 B4:1 G4:1 A4:2',
'answer':'F#5:1 A5:1 D6:2 C#6:1 A5:1|G5:1 F#5:1 E5:2 B4:1 E5:1|C#5:1 E5:1 G5:2 A5:1 G5:1|F#5:2 D5:1 A4:1 R:2',
'gust':'B5:1 A5:1 F#5:1 E5:1 D5:1 B4:1|G5:1 B5:1 A5:1 G5:1 E5:1 D5:1|C#5:1 E5:1 A5:1 G5:1 E5:1 C#5:1|D5:1 F#5:1 A5:1 D6:1 C#6:2',
'cross':'E5:1 G5:1 B5:2 A5:1 G5:1|A#5:1 F#5:1 E5:2 C#5:1 A#4:1|F#5:1 B5:1 D6:2 C#6:1 B5:1|A5:1 G5:1 E5:2 C#5:1 R:1',
'flight':'D6:1 A5:1 F#5:1 A5:1 D6:1 E6:1|F#6:1 E6:1 D6:1 A5:1 F#5:2|E6:1 D6:1 B5:1 G5:1 E5:2|C#6:1 A5:1 G5:1 E5:1 C#5:2',
'fall':'B5:1 A5:1 F#5:2 D5:1 B4:1|G5:1 E5:1 B4:2 G4:1 E4:1|C#5:2 E5:1 G5:1 R:2|D5:2 R:4',
'string':'B4:2 D5:1 F#5:1 R:2|C5:2 E5:1 G5:1 R:2|B4:1 E5:1 G5:2 F#5:1 E5:1|A#4:2 C#5:2 R:2',
'walk':'D5:2 A4:1 F#4:1 A4:2|B4:1 D5:1 G5:2 F#5:1 D5:1|C#5:1 E5:1 A5:2 G5:1 E5:1|F#5:2 D5:1 A4:1 D5:2',
'together':'G5:1 B5:1 D6:2 B5:1 A5:1|F#5:1 A5:1 D6:2 C#6:1 A5:1|E5:1 G5:1 B5:2 A5:1 G5:1|A5:2 G5:1 E5:1 R:2',
'dance':'D5:1 F#5:1 A5:1 B5:1 A5:1 F#5:1|G5:1 B5:1 D6:1 C#6:1 B5:1 G5:1|A5:1 C#6:1 E6:1 D6:1 C#6:1 A5:1|F#5:1 A5:1 D6:2 A5:1 F#5:1',
'end':'B5:2 A5:1 F#5:1 D5:2|G5:2 D5:1 B4:1 G4:2|E5:1 C#5:1 A4:2 G4:1 E4:1|D5:1 A4:1 F#4:2 R:2'
}
BLOCKS=[
('String_in_air',76,3,'air','D A Bm G D A Bm G','air air'),
('First_steps',102,3,'hop','D A Bm G D Em A7 D','seed answer'),
('Line_tightens',108,3,'hop','D A Bm G D Em A7 D','seed answer'),
('Crosswind',116,3,'gust','Bm G A D Em F#7 Bm A7','gust cross'),
('Lift',126,3,'flight','D D Em A7 D D Em A7','flight flight'),
('Too_much_sky',116,3,'gust','Bm G A D Bm Em A7 D','gust fall'),
('String_on_grass',86,3,'string','Bm C Em F#7 Bm C Em F#7','string string'),
('Back_along_path',98,3,'walk','D G A D D G A D','walk walk'),
('Two_hands',106,3,'relay','G D/F# Em A7 D Em A7 D','together answer'),
('Find_the_wind',110,3,'relay','G D/F# Em A7 D A Bm G','together seed'),
('Second_launch',120,3,'dance','D G A D D G A D','dance dance'),
('Shared_height',122,3,'flight','D D Em A7 G D/F# Em A7','flight together'),
('Turn_home',116,3,'dance','D G A D D Em A7 D','dance answer'),
('Kite_returned',104,3,'end','D G A D Bm G A7 D','walk end')]
REV1={33:('Dsus','A5:1 D6:1 E6:1 D6:1 A5:2'),34:('D','F#6:2 E6:1 D6:1 A5:2'),35:('G6','B5:1 G5:1 E5:1 G5:1 B5:2'),36:('A7','C#6:1 A5:1 G5:1 E5:1 R:2'),37:('D/F#','A5:1 D6:1 F#6:2 E6:1 D6:1'),38:('Bm','F#6:1 D6:1 B5:1 A5:1 F#5:2'),39:('Em','B5:2 G5:1 E5:1 F#5:1 G5:1'),40:('A7','A5:1 G5:1 E5:1 C#5:1 R:2')}
REV2={81:('D','R:1 D5:1 F#5:1 A5:1 B5:1 A5:1'),82:('G6','B5:1 A5:1 G5:1 E5:1 D5:2'),83:('A7','C#6:1 E6:1 D6:1 C#6:1 A5:2'),84:('D','F#5:1 A5:1 D6:1 C#6:1 A5:2'),85:('Bm','F#5:1 B5:1 D6:1 C#6:1 B5:1 A5:1'),86:('G','G5:1 D6:1 B5:1 A5:1 G5:2'),87:('A7','E5:1 G5:1 A5:1 C#6:1 B5:1 A5:1'),88:('D','F#5:2 D5:1 A4:1 R:2')}
def build(level):
 w=Writer()
 for n,section,bpm,beats,style,h,line in material(level):
  ch=H[h];w.bar(section,bpm,beats,h,ch);v={'air':48,'hop':73,'gust':86,'flight':97,'string':58,'walk':64,'relay':76,'dance':90,'end':79}[style]
  notes,total=decode(line);wind=style=='air' or style=='relay' and n%2==1 or style=='string' and n%4==1
  if wind:
   assert total==beats
   for q,t,d in [(notes[0][0],0,1.08),(notes[-1][0],1.7,.92)]:
    # The next inhalation becomes a small written lift; duration and pitch remain intact.
    if n in (4,8,49) and t==0:t=.125
    w.add(72+q%12,t,d,v,inst='flute',voice='kite_phrase')
  else:w.line(line,v)
  if style=='air':
   if n%2:w.add(ch[0]+12,.75,1.1,42,voice='held_spool',hand='left')
  elif style=='string':
   if n%2: w.add(ch[0],0,.5,48,voice='walk_to_string',hand='left')
   if n%4==0: w.add(ch[1],1.5,.7,45,voice='loosening',hand='left')
  elif style=='walk':
   for t,p in [(0,ch[0]),(2,ch[1])]:w.add(p,t,.5,v-18,voice='walking_pair',hand='left')
  else:
   times=[0,1.5] if style in ('hop','relay','end') else [0,1,2]
   if level>=1 and 33<=n<=40:times=[.5,1.5,2.5]
   if level>=2 and 81<=n<=88:times=[0,1.5] if n%2 else [.5,2]
   for j,t in enumerate(times):w.add(ch[j%3],t,.3,v-25,voice='pull_and_release',hand='left')
   if style in ('gust','dance') and n%4==0:
    w.add(72+ch[2]%12,1.8,.88,73,inst='flute',voice='turn_above_run')
  if level>=2 and 81<=n<=88 and n%2==1:
   w.add(72+ch[2]%12,.4,.82,77,inst='flute',voice='shared_lift');w.add(72+ch[1]%12,1.8,.85,71,inst='flute',voice='shared_release')
  w.release(32 if style in ('air','walk') else 0,.8)
 return w.result(level)
