"""Original folk-waltz narrative. Handwritten themes; seven-plus-five-bar phrases."""
from pathlib import Path
import json,copy
P=Path(__file__).parent;(P/'revisions').mkdir(exist_ok=True)
A=[[(74,1),(69,.5),(65,.5),(64,.5),(65,.5)],[(71,.5),(69,.5),(67,1),(74,.5),(71,.5)],[(69,1.5),(67,.5),(65,.5),(64,.5)],[(67,1),(72,.5),(71,.5),(69,1)],[(74,.5),(76,.5),(77,1),(76,.5),(74,.5)],[(71,1),(74,.5),(72,.5),(71,.5),(69,.5)],[(73,1),(71,.5),(69,1),(-1,.5)],[(74,.5),(69,.5),(65,1),(67,.5),(69,.5)],[(72,1),(69,.5),(65,.5),(64,.5),(65,.5)],[(67,.5),(71,.5),(74,1),(72,.5),(71,.5)],[(73,1),(76,.5),(74,.5),(73,.5),(69,.5)],[(74,2.25),(-1,.75)]]
B=[[(69,1.5),(65,.5),(62,1)],[(67,1),(65,.5),(64,.5),(62,1)],[(65,.5),(69,.5),(72,1),(71,1)],[(68,1),(64,1),(61,.5),(-1,.5)],[(62,1),(64,.5),(65,.5),(69,1)],[(70,1.5),(69,.5),(67,1)],[(68,.5),(69,.5),(73,1),(71,.5),(69,.5)],[(74,2),(-1,1)]]
C=[[(77,1),(76,.5),(72,.5),(69,1)],[(74,.5),(77,.5),(79,1),(77,.5),(74,.5)],[(76,1),(72,1),(67,.5),(69,.5)],[(70,1.5),(69,.5),(65,1)],[(69,.5),(72,.5),(77,1),(79,.5),(81,.5)],[(79,1),(77,.5),(76,.5),(72,1)],[(76,1.5),(74,.5),(72,.5),(-1,.5)],[(77,.5),(76,.5),(74,1),(72,.5),(69,.5)],[(74,1),(77,.5),(76,.5),(74,1)],[(79,.5),(77,.5),(74,1),(71,.5),(67,.5)],[(73,1),(76,.5),(74,.5),(73,1)],[(74,1.5),(69,.5),(65,.5),(-1,.5)]]
D=[[(74,.5),(76,.5),(78,1),(76,.5),(74,.5)],[(71,1),(74,.5),(78,.5),(79,1)],[(78,1.5),(76,.5),(74,.5),(73,.5)],[(76,1),(81,.5),(79,.5),(78,1)],[(74,.5),(78,.5),(81,1),(83,.5),(81,.5)],[(79,1),(78,.5),(76,.5),(74,1)],[(73,1),(76,.5),(73,1),(-1,.5)],[(74,1),(69,.5),(66,.5),(69,1)],[(71,.5),(74,.5),(78,1),(76,.5),(74,.5)],[(79,1),(78,.5),(74,.5),(71,1)],[(73,.5),(76,.5),(81,1),(79,.5),(76,.5)],[(78,1),(76,.5),(74,1),(-1,.5)]]
H={'Dm':[38,53,57],'G':[43,55,59],'C':[36,52,55],'A7':[45,55,61],'F':[41,53,57],'Bb':[46,53,58],'E7':[40,56,59],'D':[38,54,57],'Bm':[47,54,59],'Em':[40,55,59]}
pa=['Dm','G','Dm','C','Dm','G','A7','Dm','F','G','A7','Dm'];pb=['Dm','G','F','E7','Dm','Bb','A7','Dm'];pc=['F','Bb','C','Bb','F','C','C','F','Bb','G','A7','Dm'];pd=['D','G','D','A7','D','G','A7','D','Bm','G','A7','D']
sections=[('Frost in the mixing bowl',4,104,'intro'),('Seven turns of the dough',12,108,'knead'),('The bowl stays cold',16,96,'cold'),('Three imperfect flowers',12,110,'flower'),('Light returns to the oven',16,116,'oven'),('Small loaves around one table',24,112,'share'),('Tomorrow only needs tomorrow',12,108,'tomorrow'),('The empty bowl on the sill',8,96,'coda')]
events=[];bars=[];pedals=[];beat=0;bar=0
for title,count,bpm,kind in sections:
 for j in range(count):
  bar+=1
  if kind in ['intro','knead']:k=j%12;line=copy.deepcopy(A[k]);h=pa[k]
  elif kind=='cold':k=j%8;line=copy.deepcopy(B[k]);h=pb[k]
  elif kind in ['flower','share']:k=j%12;line=copy.deepcopy(C[k]);h=pc[k]
  elif kind=='oven':k=j%12;line=copy.deepcopy(A[k]);h=pa[k]
  elif kind=='tomorrow':k=j%12;line=copy.deepcopy(D[k]);h=pd[k]
  else:
   k=j;line=copy.deepcopy([[(71,1),(74,.5),(79,.5),(78,1)],[(78,1),(74,1),(69,1)],[(76,.5),(79,.5),(83,1),(81,1)],[(73,1),(76,1),(69,.5),(-1,.5)],[(74,.5),(76,.5),(78,1),(74,1)],[(71,1),(69,.5),(67,.5),(66,1)],[(73,.5),(76,.5),(81,1),(76,1)],[(74,2.4),(-1,.6)]][j]);h=['G','D','Em','A7','D','G','A7','D'][j]
  assert sum(l for n,l in line)==3
  tempo=bpm if kind!='coda' else [96,96,94,94,92,88,82,72][j]
  vel={'intro':64,'knead':76,'cold':62,'flower':78,'oven':84,'share':81,'tomorrow':80,'coda':64}[kind]
  ch=H[h];bars.append(dict(bar=bar,start=beat,beats=3,bpm=tempo,meter_numerator=3,meter_denominator=4,section=title,harmony_name=h,harmony=ch,phrase_position=k,role_plan=kind))
  off=0
  for n,l in line:
   if n>=0:events.append(dict(bar=bar,onset=beat+off,duration=l*.94,pitch=n,velocity=vel+(2 if off==0 else 0),voice='melody'))
   off+=l
  # Bass anchors the same harmony; light middle-register dyads support beats2 and3.
  events.append(dict(bar=bar,onset=beat,duration=.48,pitch=ch[0],velocity=vel-25,voice='bass'))
  for t in [1,2]:
   if kind=='coda' and j==7:continue
   for n in ch[1:]:events.append(dict(bar=bar,onset=beat+t,duration=.43,pitch=n,velocity=vel-36+(2 if t==1 else 0),voice='accompaniment'))
  for t,v in [(0,0),(.10,42 if kind!='cold' else 30),(2.82,0)]:pedals.append(dict(onset=beat+t,value=v))
  beat+=3
pedals=[e for e in pedals if e['onset']<beat-3]+[dict(onset=beat-3,value=0),dict(onset=beat-2.9,value=52),dict(onset=beat+1,value=0)]
d=dict(id=60,title='The Baker Who Kept Winter',title_zh='保存冬天的面包师',stage='v0_original_folk_waltz',bars=bars,events=events,pedals=pedals,total_beats=beat,tail_seconds=4.0)
for f in ['score.json','revisions/score_v0.json']:(P/f).write_text(json.dumps(d,indent=2))
(P/'thematic_material.json').write_text(json.dumps(dict(A=A,B=B,C=C,D=D),indent=2));print(bar,sum(b['beats']*60/b['bpm'] for b in bars)+4)
