"""Original bourree-inspired piano, clear turn-taking thematic roles."""
from pathlib import Path
import json,copy
P=Path(__file__).parent
A=[[(67,.5),(70,.5),(74,1),(72,.5),(70,.5),(69,1)],[(70,.5),(74,.5),(79,1),(77,.5),(74,.5),(72,1)],[(72,.5),(75,.5),(79,1),(77,.5),(75,.5),(74,1)],[(78,1),(76,.5),(74,.5),(72,1),(-1,1)],[(79,1),(74,.5),(70,.5),(67,.5),(69,.5),(70,1)],[(72,.5),(74,.5),(75,1),(74,.5),(72,.5),(70,1)],[(69,.5),(72,.5),(74,1),(78,1),(76,.5),(74,.5)],[(79,2),(74,1),(-1,1)],[(74,.5),(79,.5),(82,1),(81,.5),(79,.5),(77,1)],[(77,.5),(75,.5),(74,1),(72,.5),(70,.5),(69,1)],[(75,1),(79,.5),(82,.5),(81,1),(79,1)],[(78,.5),(74,.5),(69,1),(72,.5),(74,.5),(78,1)],[(79,.5),(77,.5),(74,1),(70,.5),(72,.5),(74,1)],[(75,1),(74,.5),(72,.5),(70,1),(69,1)],[(78,.5),(76,.5),(74,1),(72,.5),(69,.5),(66,1)],[(67,2.5),(-1,1.5)]]
B=[[(74,1),(77,.5),(82,.5),(81,1),(79,1)],[(77,.5),(74,.5),(70,1),(72,.5),(74,.5),(77,1)],[(79,1),(77,.5),(75,.5),(74,.5),(72,.5),(70,1)],[(72,.5),(69,.5),(65,1),(69,1),(-1,1)],[(70,.5),(74,.5),(77,1),(82,.5),(81,.5),(79,1)],[(79,.5),(75,.5),(72,1),(74,.5),(75,.5),(79,1)],[(77,1),(81,.5),(84,.5),(82,1),(81,1)],[(82,2),(77,1),(-1,1)],[(79,.5),(82,.5),(87,1),(86,.5),(82,.5),(79,1)],[(81,1),(77,.5),(74,.5),(72,1),(69,1)],[(79,.5),(75,.5),(72,1),(70,.5),(67,.5),(63,1)],[(66,1),(69,.5),(72,.5),(74,1),(-1,1)],[(67,.5),(70,.5),(74,1),(79,.5),(77,.5),(74,1)],[(75,.5),(72,.5),(67,1),(69,.5),(70,.5),(72,1)],[(74,1),(78,.5),(81,.5),(78,1),(74,1)],[(79,2.5),(-1,1.5)]]
C=[[(79,.5),(82,.5),(86,1),(84,.5),(82,.5),(81,1)],[(82,.5),(79,.5),(75,1),(74,.5),(72,.5),(70,1)],[(79,1),(75,.5),(72,.5),(67,1),(72,1)],[(78,1),(74,.5),(69,.5),(66,1),(-1,1)],[(79,.5),(74,.5),(70,1),(67,.5),(69,.5),(71,1)],[(72,1),(75,.5),(79,.5),(77,1),(75,1)],[(78,.5),(81,.5),(86,1),(84,.5),(81,.5),(78,1)],[(79,1.5),(74,.5),(71,1),(67,1)]]
H={'Gm':[43,58,62],'Cm':[48,60,63],'D7':[38,60,66],'Eb':[39,58,63],'Bb':[46,58,62],'F':[41,57,60],'G':[43,59,62]}
pa=['Gm','Gm','Cm','D7','Gm','Eb','D7','Gm','Gm','Bb','Cm','D7','Gm','Cm','D7','Gm'];pb=['Bb','Bb','Eb','F','Bb','Cm','F','Bb','Eb','F','Cm','D7','Gm','Cm','D7','Gm'];pc=['Gm','Eb','Cm','D7','G','Cm','D7','G']
sections=[('The busiest little door',4,140,'intro'),('A question in an empty book',16,144,'question'),('The streets gain more names',16,148,'streets'),('Someone else holds the pencil',16,140,'lower'),('The broken spring',12,120,'broken'),('Many hands repair the opening',24,148,'repair'),('One more late book returns',8,132,'coda')]
events=[];bars=[];pedals=[];beat=0;bar=0
for title,count,bpm,kind in sections:
 for j in range(count):
  bar+=1
  if kind=='streets':line=copy.deepcopy(B[j]);h=pb[j]
  elif kind=='coda':line=copy.deepcopy(C[j]);h=pc[j]
  elif kind=='repair' and j>=16:line=copy.deepcopy(C[j-16]);h=pc[j-16]
  else:line=copy.deepcopy(A[j%16]);h=pa[j%16]
  lower=kind=='lower';broken=kind=='broken';vel={'intro':71,'question':80,'streets':82,'lower':79,'broken':67,'repair':87,'coda':72}[kind];tempo=bpm
  if kind=='coda':tempo=[132,132,128,128,124,120,112,96][j]
  bars.append(dict(bar=bar,start=beat,beats=4,bpm=tempo,meter_numerator=2,meter_denominator=2,section=title,harmony_name=h,harmony=H[h],role_plan=kind,phrase_position=j%16,lead_instrument='piano'))
  off=0
  for n,l in line:
   if n>=0 and not(broken and off>=2):events.append(dict(bar=bar,onset=beat+off,duration=l*.90,pitch=n-12 if lower else n,velocity=vel+(2 if off==0 else 0),voice='lower_melody' if lower else 'melody'))
   off+=l
  assert off==4
  ch=H[h]
  if lower:
   for t in [0,2]:
    for n in [ch[1]+24,ch[2]+24]:events.append(dict(bar=bar,onset=beat+t,duration=.65,pitch=n,velocity=40 if t==0 else 36,voice='upper_support'))
  else:
   for t in [0,2]:
    if broken and t==2:continue
    events.append(dict(bar=bar,onset=beat+t,duration=.48,pitch=ch[0]+(12 if t==2 else 0),velocity=vel-29,voice='bass'))
   for t in [1,3]:
    if broken and t==3:continue
    for n in ch[1:]:events.append(dict(bar=bar,onset=beat+t,duration=.42,pitch=n,velocity=vel-39,voice='accompaniment'))
  # Dry articulation, a short half-pedal only around the first shared support point.
  for t,v in [(0,0),(.12,26),(1.75,0)]:pedals.append(dict(onset=beat+t,value=v))
  beat+=4
d=dict(id=62,title='The Smallest Door in the Library',title_zh='图书馆里最小的门',stage='v0_original_bourree_narrative',bars=bars,events=events,pedals=pedals,total_beats=beat,tail_seconds=4)
for f in ['score.json','revisions/score_v0.json']:(P/f).write_text(json.dumps(d,indent=2))
(P/'thematic_material.json').write_text(json.dumps(dict(A=A,B=B,C=C),indent=2));print(bar,sum(b['beats']*60/b['bpm'] for b in bars)+4)
