# 091 — The Photographer of Empty Windows / 空窗摄影师

Original complete symbolic solo acoustic-piano chamber study. 64 bars of 4/4 in B minor, with a D-major contrasting region. Selected version v2: 573 note events, 256 absolute quarter-note beats, 202.985676 seconds of score plus 6 seconds of tail, 208.985676 seconds total (about 3:29).

The mid-register song develops through mirrored pitch-order answers, an eight-bar LH/RH lead exchange, a four-bar dry single-line exposure, and a fully scored B-minor close. Sustained harmonic shells and quiet inner entries support the song.

## Files

- score_v0.json, score_v1.json, score_v2.json: three complete versions.
- score.json: selected score, byte-identical to score_v2.json.
- generate_score.py: deterministic standard-library Python generator; no external packages.
- verify_symbolic.py: separate disk-based checker; does not import generator logic.
- audit_v0.json, audit_v1.json, audit_v2.json: complete physical-key checks, actual grip-edge transfer histories and documented within-position melodic moves.
- independent_verification.json: compact independent results for all versions and substantive revisions.
- reproducibility_check.json: fresh-process, byte-for-byte regeneration results.
- exact_diff_v0_to_v1.json, exact_diff_v1_to_v2.json: full per-bar before/after data, metadata, SHA-256 identities and whole-document reconstructive JSON patches.
- Corresponding .patch files: readable exact text diffs.
- story_zh.txt: original contemporary Chinese fiction.
- music_notes_zh.md, revision_notes.md: musical plan, symbolic evidence, performance limits and both revisions.
- hash_manifest.json: SHA-256 and byte count for every other regular deliverable file in this folder.

## Rebuild

Run `python generate_score.py`, then `python verify_symbolic.py` from this folder. A `--outdir` argument permits reproduction only within a child directory of this isolated work folder. Verification automatically regenerates in a temporary child directory and compares bytes before deleting the temporary reproduction.

## Integration contract

All note onsets, durations, bar starts, pedal onsets and target beat aliases are absolute quarter-note beats. Four quarters make one bar of 4/4. Each bar supplies its own quarter-note BPM. Read total_beats and tail_seconds separately. Notes explicitly identify instrument, hand, voice, phrase, finger, physical duration, written duration and position. Phrase timing includes the same exact tempo integral.

The hand-position table includes inactive plans for the silent hand during exposed monody. Those plans have active=false, range=null and an empty pitch_finger_map. Active note events always have concrete position ranges and fingers. Bars 33–40 use LH melody and RH support; do not hard-code melody to the right hand. Monody occupies bars 49–50 in v0/v1 and 49–52 in v2.

Pedal resonance is distinct from held-key time. Actual whole-hand travel uses the greater of held-grip edge and declared-position edge movement; >4 semitones requires 75 ms plus 12 ms per additional semitone, after the latest earlier physical key release. Both hands' within-position melodic movement has explicit ordered finger maps. Non-melodic support grip changes are also stress-tested.

No audio, DSP, soundfont references, MIDI realization, downloads, installs or changes outside this draft folder are included. Symbolic checks do not constitute listening approval, performer comfort approval or source-quality acceptance.
