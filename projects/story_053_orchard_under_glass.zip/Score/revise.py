import pathlib,json,copy,collections,math
P=pathlib.Path(__file__).parent;d=json.loads((P/'revisions/score_v0.json').read_text());v1=copy.deepcopy(d);v1['stage']='v1_form_harmony_and_role_cooperation';changes=[]
# Resolve B7 through E minor before returning to the G-major garden theme.
b=next(b for b in v1['bars'] if b['section']=='Many cups on the table');bn=b['bar'];old=list(b['harmony']);b['harmony_name']='Em7';b['harmony']=[40,55,59,62]
for e in v1['events']:
 if e['bar']==bn:
  if e['voice']=='bass':e['pitch']=40
  elif e['voice']=='accompaniment':e['pitch']={59:55,62:59,67:62}.get(e['pitch'],e['pitch'])
changes.append('The first sharing bar now resolves the precedingB7 intoE minor; the subsequent phrase leads naturally back toG, rather than jump toG immediately.')
# Melody/cadence remains the lead; remove accompaniment retriggers under held octave reinforcement.
by=collections.defaultdict(list);skip=set();coll=[]
for i,e in enumerate(v1['events']):by[e['pitch']].append((i,e))
for pitch,seq in by.items():
 seq.sort(key=lambda t:t[1]['onset'])
 for (ia,a),(ib,b) in zip(seq,seq[1:]):
  if ia in skip or ib in skip:continue
  if a['onset']+a['duration']>b['onset']+.001:
   if a['voice'].startswith('melody') and b['voice']=='accompaniment':skip.add(ib);coll.append({'bar':b['bar'],'pitch':pitch,'action':'omit accompaniment key already carried by melodic octave'})
   else:a['duration']=max(.04,b['onset']-a['onset']-.025);coll.append({'bar':b['bar'],'pitch':pitch,'action':'release before next articulation'})
v1['events']=[e for i,e in enumerate(v1['events']) if i not in skip]
# Shape the crisis as a harmonic turn, not a permanently louder pile of chords.
for e in v1['events']:
 b=v1['bars'][e['bar']-1]
 if b['role_plan']=='crisis' and e['bar'] in (45,46,47,48) and e['voice']!='melody':e['velocity']-=4
 if b['role_plan']=='share' and e['voice']=='accompaniment' and (e['bar']-61)%8==7:e['velocity']-=3
(P/'revisions/score_v1.json').write_text(json.dumps(v1,indent=2));(P/'revisions/pass1.json').write_text(json.dumps({'pass':1,'changes':changes+['Thin the beginning of the dark section beneath the lead and soften supporting cadences during the exchange of cuttings.'],'key_conflict_corrections':coll,'formal_structure':'NewA/A2/C/C2/B/B2 themes and new coda; harmonic detour and developed returns, no reused catalog material.'},indent=2))
v2=copy.deepcopy(v1);v2['stage']='v2_lyrical_swing_and_piano_touch'
def warp(t,kind):
 if kind=='crisis':return t
 whole=math.floor(t);f=t-whole
 return whole+(f*1.25 if f<.5 else .625+(f-.5)*.75)
for e in v2['events']:
 b=v2['bars'][e['bar']-1];start=e['onset'];end=start+e['duration'];e['onset']=round(warp(start,b['role_plan']),6);e['duration']=round(warp(end,b['role_plan'])-e['onset'],6)
 if e['voice']=='melody':
  # Sustain the sung line; phrase dynamics have a goal, not arbitrary jitter.
  phase=(e['bar']-1)%8;arc=[0,1,3,0,2,4,2,-4][phase];e['velocity']+=arc
  if b['role_plan']=='coda':e['velocity']-=max(0,e['bar']-111)
 elif e['voice']=='accompaniment':e['velocity']-=1 if e['onset']-b['start']>2 else 0
 e['velocity']=max(24,min(98,e['velocity']))
for e in v2['pedals']:
 b=next((b for b in reversed(v2['bars']) if e['onset']>=b['start']),v2['bars'][0]);e['onset']=round(warp(e['onset'],b['role_plan']),6)
(P/'revisions/score_v2.json').write_text(json.dumps(v2,indent=2));(P/'score.json').write_text(json.dumps(v2,indent=2));(P/'revisions/pass2.json').write_text(json.dumps({'pass':2,'changes':['Apply gentle5:3 eighth-note lilt to warm sections while the crisis remains straighter; bar boundaries and joint harmonic changes stay aligned.','Shape each eight-bar melodic phrase with an intentional dynamic arch and a softer ending.','Keep the left-hand chords behind the lead; bass key-holds remain brief, with pedal providing resonance.','Coda touch gradually softens without inserting large gaps between every note.'],'review_limit':'These are compositional/performance choices and technical checks; no human listening review is claimed.'},indent=2));print('Two substantive score passes saved. Key fixes',len(coll))
