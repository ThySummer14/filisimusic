"""113: long asymmetrical phrases, delayed motivic echoes and a single complete pause."""
from pathlib import Path
import json,sys,bisect
P=Path(__file__).resolve().parent;sys.path.insert(0,str(P));from composition_data import *
PARAM={'intro':('亭顶先落下的影子',100,49),'interlace':('两条路交错',112,70),'converge':('影子追上脚步',124,91),'still':('车来之前的一格',88,40),'return':('地图添上一条线',116,79),'coda':('带着新路线登车',100,46)}
def write(p,x):p.write_text(json.dumps(x,ensure_ascii=False,separators=(',',':'))+'\n')
def pitch(s):return 12*(int(s[-1])+1)+{'C':0,'D':2,'E':4,'F':5,'G':7,'A':9,'B':11}[s[0]]+s[1:-1].count('#')-s[1:-1].count('b')
def build(level):
 rows=[]
 for sec,hs,ls in GROUPS:assert len(hs.split())==len(ls);rows.extend((sec,h,l) for h,l in zip(hs.split(),ls))
 assert len(rows)==88
 bars=[];events=[];pedals=[]
 for n,(sec,h,line) in enumerate(rows,1):
  for lv,rd,hd in [(1,REV1,HREV1),(2,REV2,HREV2)]:
   if level>=lv:line=rd.get(n,line);h=hd.get(n,h)
  label,bpm,dyn=PARAM[sec];ch=H[h];start=(n-1)*4
  if n in [12,31,54,61,81]:bpm-=4
  if n>=86:bpm-=2*(n-85)
  phrase_dyn=[-2,0,2,0][(n-1)%4] if sec in ['interlace','return'] else 0;dyn+=phrase_dyn
  bars.append(dict(bar=n,start=start,beats=4,bpm=bpm,meter='4/4',meter_numerator=4,meter_denominator=4,section=sec,section_title_zh=label,harmony_name=h,harmony=ch,key_region='E major with directed secondary dominants'))
  def add(p,t,d,v,inst,voice,hand='none'):
   assert 0<=t<t+d<=4.00001,(n,t,d)
   events.append(dict(bar=n,onset=round(start+t,6),duration=round(d,6),pitch=p,velocity=int(v),instrument=inst,voice=voice,hand=hand))
  at=0;mel=[]
  for i,tok in enumerate(line.split()):
   name,u=tok.split(':');dur=float(u)/2
   if name!='R':
    p=pitch(name);mel.append(p);add(p,at,dur-.075,dyn+(4 if at==0 and sec=='converge' else 0)-(4 if i==len(line.split())-1 else 0),'piano','theme','left' if sec=='still' else 'right')
   at+=dur
  assert at==4
  if not mel:assert n==57
  elif sec=='still':
   if n in [55,59]:add(76,2.5,.70,27,'piano','high_reflection','right')
  else:
   pat=[(0,ch[0],.60),(2,ch[1],.50)]
   if sec=='intro':pat=[(0,ch[0],1.25)] if n%2 else [(1.5,ch[1],.80)]
   if sec=='interlace':pat=[(.5,ch[0],.45),(2.5,ch[2],.45)] if n%2 else [(0,ch[0],.6),(2,ch[1],.5)]
   if sec=='converge':pat=[(0,ch[0],.4),(1.5,ch[1],.35),(3,ch[2],.50)]
   if level>=1 and 32<=n<=45:pat=[(.5,ch[2],.35),(2,ch[1],.40)] if n%2 else [(0,ch[0],.42),(2.5,ch[2],.35)]
   if level>=2 and sec=='return':pat=[(0,ch[2],.5),(2,ch[1],.5)] if n%2 else [(1,ch[0],.6),(3,ch[1],.45)]
   if sec=='coda':pat=[(0,ch[0],.85)] if n%2 else [(2,ch[1],.70)]
   if n in [12,31,54,61,81]:pat=[(0,ch[0],.7)]
   for t,p,dur in pat:
    while p>=min(mel):p-=12
    add(p,t,dur,dyn-24,'piano','moving_lower_line','left')
  avail=[p for p in range(72,84) if p%12 in {x%12 for x in ch}];assert avail
  wind=[]
  explicit={5:[76,80],6:[83,81],7:[78,76],8:[73,75],9:[76,80],10:[81,78],11:[78,75],12:[76,83]}
  if n in explicit:wind=explicit[n]
  elif sec=='interlace' and n%4!=0:wind=[avail[-1],avail[0]] if n%2 else [avail[0],avail[-1]]
  elif sec=='converge' and n%4 in [1,3]:wind=[avail[0],avail[-1]]
  elif sec=='still' and n in [55,59,61]:wind=[avail[0]]
  elif sec=='return' and n%4 in [1,2,3]:wind=[avail[-1],avail[0]]
  elif sec=='coda' and n in [82,84,86]:wind=[avail[0]]
  if level>=1 and 32<=n<=45:wind=[avail[0]] if n in [33,35,37,39,41,43,45] else []
  if level>=2 and 63<=n<=78:wind=[avail[0],avail[-1]] if n%4 in [1,2] else [avail[-1]] if n%4==3 else []
  body=.56 if bpm>=120 else .63 if bpm>=112 else .70
  for t,p in zip([.5,2.5],wind):add(p,t,body*bpm/60,48 if sec in ['intro','still','coda'] else 68 if sec=='converge' else 62,'flute','delayed_motivic_echo')
  pedals.append(dict(bar=n,onset=start,controller=64,value=0,instrument='piano'))
  if sec in ['intro','still','coda']:
   pedals.extend([dict(bar=n,onset=start+.08,controller=64,value=26,instrument='piano'),dict(bar=n,onset=start+1.75,controller=64,value=0,instrument='piano'),dict(bar=n,onset=start+2.08,controller=64,value=22,instrument='piano'),dict(bar=n,onset=start+3.82,controller=64,value=0,instrument='piano')])
 events.sort(key=lambda e:(e['onset'],e['instrument'],e['pitch']))
 for i,e in enumerate(events):e['event_id']=f'113-v{level}-{i}'
 return dict(id=113,title='Long Shadows at the Bus Shelter',title_zh='候车亭的长影',version=f'v{level}',bars=bars,events=events,pedals=pedals,total_beats=352,tail_seconds=5,instrument_map={'piano':'piano','flute':'flute'},performance_contract='Original asymmetric chamber phrases with motivic imitation; not a strict full canon, live-performance claim or human listening claim.')
def proj(d,n):return {'bar':d['bars'][n-1],'events':[{k:v for k,v in e.items() if k!='event_id'} for e in d['events'] if e['bar']==n],'pedals':[e for e in d['pedals'] if e['bar']==n]}
for v in range(3):
 d=build(v);write(P/f'score_v{v}.json',d);report={'version':f'v{v}','bars':88,'events':len(d['events']),'duration_seconds':sum(b['beats']*60/b['bpm'] for b in d['bars'])+5,'human_listening_review':False};write(P/f'audit_v{v}.json',report)
 if v:
  a=build(v-1);changes=[{'bar':n,'before':proj(a,n),'after':proj(d,n)} for n in range(1,89) if proj(a,n)!=proj(d,n)];write(P/f'exact_diff_v{v-1}_to_v{v}.json',{'count':len(changes),'changed_bars':[x['bar'] for x in changes],'comparison_excludes':['version','event_id'],'changes':changes});lines=[]
  for x in changes:
   lines.append(f"BAR {x['bar']}\n")
   for side in ['before','after']:
    q=x[side];lines.append(side+' '+q['bar']['harmony_name']+' '+str([(e['instrument'],e['voice'],e['onset'],e['pitch'],e['duration'],e['velocity']) for e in q['events']])+'\n')
  (P/f'exact_diff_v{v-1}_to_v{v}.patch').write_text(''.join(lines))
write(P/'score.json',d);starts=[b['start'] for b in d['bars']];times=[];t=0
for b in d['bars']:times.append(t);t+=b['beats']*60/b['bpm']
def sec(t):
 i=max(0,bisect.bisect_right(starts,t)-1);return times[i]+(t-starts[i])*60/d['bars'][i]['bpm']
def beat(t):
 i=max(0,bisect.bisect_right(times,t)-1);return starts[i]+(t-times[i])*d['bars'][i]['bpm']/60
mp=P.parent/'assets/iowa_flute_C5_B5/mapping_manifest.json';lat={(x['layer'],x['midi']):x['voiced_onset_delay_after_tuning_seconds'] for x in json.loads(mp.read_text())['files']};alignment=[]
for e in d['events']:
 if e['instrument']!='flute':continue
 layer='pp' if e['velocity']<=55 else 'mf';target=sec(e['onset']);end=sec(e['onset']+e['duration']);delay=lat[layer,e['pitch']];trigger=target-delay;assert trigger>=0;e['nominal_onset']=e['onset'];e['onset']=beat(trigger);e['duration']=beat(end)-e['onset'];e['layer']=layer;e['attack_compensated_once']=True;assert .30<=end-target and end-trigger<=1.60;alignment.append(dict(event_id=e['event_id'],target_seconds=target,trigger_seconds=trigger,delay_seconds=delay,gate_seconds=end-trigger,layer=layer))
w=sorted([e for e in d['events'] if e['instrument']=='flute'],key=lambda e:e['onset']);gaps=[sec(b['onset'])-sec(a['onset']+a['duration']) for a,b in zip(w,w[1:])];assert min(gaps)>=.14,min(gaps)
write(P/'ensemble_score.json',d)
for inst in ['piano','flute']:write(P/f'{inst}_score.json',{**d,'events':[e for e in d['events'] if e['instrument']==inst],'pedals':d['pedals'] if inst=='piano' else []})
write(P/'revisions/flute_attack_alignment.json',{'method':'Once-only recorded voiced-onset timing compensation; real pp/mf separated vibrato notes','events':alignment,'minimum_after_compensation_gap_seconds':min(gaps)});print(json.dumps({**report,'flute_min_gap_seconds':min(gaps)}))
