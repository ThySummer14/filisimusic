"""Newly authored melodic/harmonic data for work099; shared construction utilities are separate."""
LINES=[
 'D4 F4 A4 G4 F4 E4 | F4 G4 Bb4 A4 F4 D4 | G4 Bb4 D5 C5 Bb4 A4 | E4 G4 A4 C#5 B4 A4 | F4 A4 D5 C5 A4 F4 | A4 G4 F4 C4 F4 G4 | C#5 E5 D5 C#5 A4 G4 | F4 E4 D4 A3 D4 F4',
 'D3 F3 | A3 G3 | F3 E3 | G3 E3 | A4 F4 E4 D4 F4 A4 | E4 G4 C5 B4 G4 E4 | D5 C5 Bb4 F4 Bb4 C5 | C#5 B4 A4 E4 G4 A4',
 'Bb4 D5 C5 Bb4 A4 G4 | A4 D5 F5 E5 D5 A4 | G4 Bb4 D5 C5 Bb4 G4 | E4 G4 A4 C#5 A4 E4 | F3 A3 | G3 F3 | E3 G3 | F3 D3',
 'A4 C5 F5 E5 C5 A4 | G4 C5 E5 D5 C5 G4 | F4 Bb4 D5 C5 Bb4 F4 | G4 C5 E5 D5 C5 G4 | A4 C5 F5 G5 F5 C5 | Bb4 D5 F5 E5 D5 Bb4 | G4 Bb4 C5 E5 D5 C5 | A4 G4 F4 C4 F4 A4',
 'A3 F3 | G3 E3 | F3 D3 | E3 G3 | C5 F5 E5 C5 A4 | Bb4 D5 F5 D5 C5 Bb4 | G4 C5 E5 D5 C5 G4 | C#5 E5 D5 C#5 A4',
 'D5 F5 E5 D5 A4 | C5 Bb4 A4 F4 A4 C5 | Bb4 D5 F5 E5 D5 Bb4 | C#5 E5 G5 F5 E5 C#5 | G3 Bb3 | A3 F3 | G3 E3 | F3 D3',
 'A4 D5 F5 E5 D5 A4 | C5 F5 E5 C5 A4 G4 | Bb4 D5 G5 F5 D5 Bb4 | C#5 E5 A5 G5 E5 C#5 | F5 E5 D5 A4 D5 F5 | D5 C5 Bb4 F4 Bb4 D5 | E5 D5 C#5 A4 G4 | F4 A4 D5 C5 A4 F4',
 'A3 F3 | G3 F3 | E3 G3 | F3 D3 | D5 F5 A5 G5 F5 E5 | C5 E5 G5 F5 E5 C5 | Bb4 D5 F5 E5 D5 Bb4 | C#5 E5 G5 F5 E5 C#5',
 'F5 D5 A4 F4 A4 D5 | E5 C5 G4 E4 G4 C5 | D5 Bb4 G4 D4 G4 Bb4 | C#5 A4 G4 E4 G4 A4 | D3 F3 | G3 F3 | E3 G3 | F3 D3',
 'A4 F4 E4 D4 F4 A4 | G4 Bb4 D5 C5 Bb4 G4 | F4 A4 D5 C5 A4 F4 | E4 G4 A4 C#5 A4 E4 | F3 D3 | G3 F3 | E3 G3 | F3 D3',
]
HARM_ROWS=[
 'Dm Bb Gm A7 Dm/A F/A A7 Dm',
 'Dm Gm Dm A7 Dm C Bb A7',
 'Gm Dm Gm A7 Dm Bb A7 Dm',
 'F C Bb C7 F Bb C7 F',
 'F C7 Bb C7 F Bb C7 A7',
 'Dm Bb Gm A7 Gm Dm/F A7 Dm',
 'Dm F/A Gm A7 Dm Bb A7 Dm',
 'Dm/A Bb A7 Dm Dm C Bb A7',
 'Dm C Gm A7 Dm Gm7 A7 Dm',
 'Dm Gm Dm/A A7 Dm Gm A7 Dm',
]
H={'Dm':[38,41,45],'Dm/F':[29,33,38],'Dm/A':[33,38,41],'Dm(add9)':[38,40,41,45],'F':[41,45,48],'F/A':[33,36,41],'Bb':[34,38,41],'Bb/D':[38,41,46],'Bbmaj7':[34,38,41,45],'Gm':[31,34,38],'Gm/Bb':[34,38,43],'Gm7':[31,34,38,41],'A7':[33,37,40,43],'A7/C#':[37,40,43,45],'C':[36,40,43],'C7':[36,40,43,46],'C/E':[40,43,48]}
WIND=set(list(range(9,13))+list(range(21,25))+list(range(33,37))+list(range(45,49))+list(range(57,61))+list(range(69,73))+list(range(77,81)))
V1={25:'C5 F5 E5 C5 A4',26:'E5 D5 C5 G4 C5 E5',27:'Bb4 D5 F5 E5 D5 Bb4',28:'C5 E5 G5 E5 D5 C5',29:'F5 G5 A5 G5 F5 C5',30:'D5 F5 G5 F5 D5 Bb4',31:'E5 D5 C5 Bb4 G4',32:'C5 A4 G4 F4 A4 C5',33:'F3 A3',34:'E3 G3',35:'D3 F3',36:'G3 E3',37:'A4 C5 F5 E5 C5 A4',38:'D5 F5 E5 D5 Bb4',39:'E5 G5 F5 E5 C5',40:'E5 D5 C#5 A4 G4'}
V1_H={25:'F/A',26:'C/E',27:'Bb/D',28:'C7',29:'F/A',30:'Bbmaj7',31:'C/E',33:'F/A',35:'Bb/D',37:'F/A',38:'Bbmaj7',39:'C/E',40:'A7/C#'}
V2={49:'F4 A4 D5 E5 D5 A4',50:'A4 C5 F5 E5 C5 A4',51:'D5 G5 F5 D5 Bb4',52:'E5 A5 G5 E5 C#5',53:'A5 G5 F5 E5 D5',54:'F5 D5 C5 Bb4 F4',55:'G5 E5 D5 C#5 A4',56:'A4 D5 F5 E5 D5 A4',57:'D3 A3',58:'Bb3 G3',59:'G3 E3',60:'F3 D3',61:'F5 A5 G5 F5 E5 D5',62:'E5 G5 F5 E5 D5 C5',63:'D5 F5 E5 D5 Bb4',64:'E5 G5 F5 E5 C#5',65:'D5 A4 F4 D4 F4 A4',66:'C5 G4 E4 G4 C5',67:'Bb4 G4 D4 G4 Bb4',68:'A4 G4 E4 C#4 E4 A4',69:'F3 D3',70:'Bb3 G3',71:'G3 E3',72:'F3 D3',77:'D3 F3',78:'Bb3 G3',79:'G3 E3',80:'F3 D3'}
V2_H={49:'Dm(add9)',50:'F/A',51:'Gm/Bb',52:'A7/C#',53:'Dm/A',54:'Bb/D',55:'A7/C#',56:'Dm/F',57:'Dm/A',58:'Gm/Bb',61:'Dm/A',62:'C/E',63:'Bbmaj7',64:'A7/C#',65:'Dm/F',66:'C/E',67:'Gm/Bb',68:'A7/C#',70:'Gm/Bb',74:'Gm/Bb',77:'Dm/F',78:'Gm/Bb'}
LABELS=['把船翻到侧面','先量空下来的位置','再找一块同纹的木料','车已开到门口','重新说明展台尺寸','桌上留下的座板','在包装边缘作记号','把尚未安装的地方写清楚','试一试提起的方向','随船带走的小纸袋']
SECTIONS=[(1,24,'A','还空着的座板','D minor'),(25,40,'B','女儿带来的包装','F major'),(41,48,'C','改变试装的次序','D minor'),(49,64,'A2','重新试一次转身','D minor'),(65,80,'Coda','未安装的木条也上车','D minor')]
def section(n):return next(x for x in SECTIONS if x[0]<=n<=x[1])
def bpm(n):
 if n<=24:return 72 if n%8 else 68
 if n<=40:return 76 if n%8 else 72
 if n<=48:return 74 if n%4 else 70
 if n<=64:return 76 if n%8 else 72
 return 72 if n<77 else 68
