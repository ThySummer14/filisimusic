from pathlib import Path
import json,bisect,copy
P=Path(__file__).parent;R=P.parent;(P/'revisions').mkdir(exist_ok=True);d=json.loads((P/'score_v2.json').read_text())
mp=R/'assets/iowa_cello_arco_D3_B3/mapping_manifest.json'
if not mp.exists():mp=R/'InstrumentMapping/cello/mapping_manifest.json'
lat={(x['layer'],x['midi']):x['coarse_voiced_delay_after_tuning_seconds'] for x in json.loads(mp.read_text())['files']}
# One silent technical quarter at120BPM provides0.5sec before the first pitched arrival.
for b in d['bars']:b['start']+=1
for e in d['events']:e['onset']+=1
for e in d['pedals']:e['onset']+=1
d['bars'].insert(0,{'bar':0,'start':0,'beats':1,'bpm':120,'meter_numerator':1,'meter_denominator':4,'section':'Technical breath pre-roll (0.5sec)','harmony':[],'lead_instrument':None,'role_plan':'No musical bar; permits genuine recorded cello breath before the first intended pitched arrival.'})
d['total_beats']+=1;d['technical_preroll_seconds']=.5;d['musical_bar_count']=80
starts=[b['start'] for b in d['bars']];times=[];t=0
for b in d['bars']:times.append(t);t+=b['beats']*60/b['bpm']
def sec(x):
 i=max(0,bisect.bisect_right(starts,x)-1);return times[i]+(x-starts[i])*60/d['bars'][i]['bpm']
def beat(x):
 i=max(0,bisect.bisect_right(times,x)-1);return starts[i]+(x-times[i])*d['bars'][i]['bpm']/60
rows=[]
for e in d['events']:
 e['nominal_target_seconds_with_preroll']=sec(e['onset'])
 if e['instrument']!='cello':continue
 target=sec(e['onset']);end=sec(e['onset']+e['duration']);delay=lat[e['layer'],e['pitch']];trigger=target-delay;assert trigger>=0
 e['onset']=beat(trigger);e['duration']=beat(end)-e['onset'];e['onset_reference']='sample_trigger_after_single_measured_attack_compensation'
 rows.append({'event_id':e['event_id'],'phrase_id':e['phrase_id'],'pitch':e['pitch'],'layer':e['layer'],'target_voiced_arrival_seconds':target,'sample_trigger_seconds':trigger,'measured_advance_seconds':delay,'intended_note_off_seconds':end})
cello=sorted([e for e in d['events'] if e['instrument']=='cello'],key=lambda e:e['onset']);shorten=[]
for a,b in zip(cello,cello[1:]):
 end=sec(a['onset']+a['duration']);limit=sec(b['onset'])-.14
 if end>limit:
  assert limit-sec(a['onset'])>.10
  shorten.append({'event_id':a['event_id'],'original_end':end,'actual_end':limit,'shortening_seconds':end-limit});a['duration']=beat(limit)-a['onset']
lookup={e['event_id']:e for e in cello}
for row in rows:
 e=lookup[row['event_id']];row['actual_note_off_seconds']=sec(e['onset']+e['duration']);row['actual_gate_seconds']=row['actual_note_off_seconds']-sec(e['onset']);row['estimated_voiced_body_seconds']=row['actual_note_off_seconds']-row['target_voiced_arrival_seconds'];assert row['estimated_voiced_body_seconds']>=.30;assert row['actual_gate_seconds']<=1.15
for a,b in zip(cello,cello[1:]):assert sec(b['onset'])-sec(a['onset']+a['duration'])>=.14-1e-8
for phrase in d['phrases']:
 phrase['nominal_target_on_seconds_with_preroll']=phrase['target_on_seconds']+.5;phrase['nominal_target_off_seconds_with_preroll']=phrase['target_off_seconds']+.5
 ev=[e for e in d['events'] if e['phrase_id']==phrase['phrase_id']];phrase['actual_trigger_start_seconds']=min(sec(e['onset']) for e in ev);phrase['actual_noteoff_end_seconds']=max(sec(e['onset']+e['duration']) for e in ev)
d['events'].sort(key=lambda e:(e['onset'],e['instrument'],e['pitch']));d['version']='v3_per_sample_attack_with_half_second_preroll'
for f in ['ensemble_score.json','revisions/ensemble_v3.json']:(P/f).write_text(json.dumps(d,ensure_ascii=False,indent=2))
for inst in ['cello','piano']:
 x={**d,'events':[e for e in d['events'] if e['instrument']==inst],'pedals':d['pedals'] if inst=='piano' else []}
 for f in [f'{inst}_score.json',f'revisions/{inst}_v3.json']:(P/f).write_text(json.dumps(x,ensure_ascii=False,indent=2))
(P/'revisions/cello_attack_alignment_v3.json').write_text(json.dumps({'method':'0.5sec common preroll, then advance each cello trigger by coarse measured pitch/layer bowed onset once; preserve desired offs unless explicit release-clearance shortening. Piano remains ordinary trigger. Not human listening or perfect perceptual alignment.','rows':rows,'shortenings':shorten,'max_gate':max(x['actual_gate_seconds'] for x in rows)},indent=2));print('notes',len(rows),'shortenings',len(shorten),'maxgate',max(x['actual_gate_seconds'] for x in rows))
