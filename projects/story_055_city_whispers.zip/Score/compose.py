"""Original processional piano piece. One shared rhythmic idea becomes a quiet bell."""
import pathlib,json,copy
P=pathlib.Path(__file__).parent;(P/'revisions').mkdir(exist_ok=True)
# Quarter-beat durations. Each eight-bar sentence is newly written.
A=[[(65,.5),(69,.5),(72,1),(74,1),(72,.5),(69,.5)],[(70,1.5),(69,.5),(67,1),(65,1)],[(69,.5),(72,.5),(77,1.5),(76,.5),(74,1)],[(72,1),(71,.5),(67,.5),(72,1.5),(-1,.5)],[(74,.75),(72,.25),(70,1),(69,.5),(67,.5),(65,1)],[(69,1),(67,.5),(65,.5),(62,1),(65,1)],[(67,.5),(70,.5),(72,1),(76,.5),(74,.5),(72,.5),(70,.5)],[(69,1),(67,1),(65,1.5),(-1,.5)]]
A2=[[(72,.5),(74,.5),(77,1),(76,.5),(74,.5),(72,1)],[(74,1.5),(72,.5),(70,.5),(69,.5),(67,1)],[(77,1),(79,.5),(81,.5),(79,1),(77,1)],[(76,.5),(74,.5),(72,1),(67,1.5),(-1,.5)],[(77,.5),(74,.5),(70,1),(72,.5),(74,.5),(77,1)],[(76,1),(72,.5),(69,.5),(65,1),(69,1)],[(74,.5),(72,.5),(70,.5),(67,.5),(64,1),(67,.5),(70,.5)],[(72,1),(69,1),(65,1.5),(-1,.5)]]
B=[[(69,1.5),(65,.5),(62,1),(65,1)],[(70,1),(74,1),(72,.5),(70,.5),(69,1)],[(72,1),(69,.5),(65,.5),(64,1),(62,1)],[(67,1.5),(64,.5),(61,1.5),(-1,.5)],[(62,.5),(65,.5),(69,1),(72,1),(69,1)],[(70,.75),(69,.25),(67,1),(65,1),(62,1)],[(64,.5),(67,.5),(70,1),(72,.5),(74,.5),(76,1)],[(72,1),(70,.5),(67,.5),(65,1.5),(-1,.5)]]
B2=[[(77,1.5),(74,.5),(72,1),(69,1)],[(74,.5),(77,.5),(79,1),(77,1),(74,1)],[(76,1),(72,1),(69,.5),(67,.5),(65,1)],[(73,1),(76,.5),(79,.5),(76,1.5),(-1,.5)],[(74,.5),(77,.5),(81,1),(79,.5),(77,.5),(74,1)],[(77,1),(74,1),(70,1),(69,.5),(67,.5)],[(72,.5),(74,.5),(76,1),(79,1),(77,.5),(74,.5)],[(72,1),(69,1),(65,1.5),(-1,.5)]]
BELL=[[(77,1.5),(76,.5),(74,1),(72,1)],[(74,2),(70,1.5),(-1,.5)],[(72,1.5),(69,.5),(67,1),(65,1)],[(67,2),(64,1.5),(-1,.5)],[(69,1),(72,1),(77,1.5),(76,.5)],[(74,1.5),(70,.5),(69,1),(67,1)],[(72,1),(70,1),(67,1),(64,1)],[(65,3),(-1,1)]]
CODA=[[(74,1),(72,1),(70,1),(69,1)],[(72,1.5),(69,.5),(65,2)],[(67,1),(70,1),(72,1),(76,1)],[(77,3),(-1,1)],[(77,1.5),(74,.5),(72,1),(69,1)],[(70,1),(69,1),(67,1),(65,1)],[(64,1),(67,1),(70,1),(72,1)],[(69,1),(67,1),(65,2)]]
H={'F':[41,53,57,60],'Bb':[46,53,58,62],'FC':[48,53,57,60],'C':[48,55,60,64],'Gm':[43,55,58,62],'Dm':[38,53,57,62],'A7':[45,55,61,64],'Am':[45,52,57,60],'Fopen':[41,53,57,60,67]}
home=['F','Bb','FC','C','Gm','Dm','C','F'];minor=['Dm','Bb','Am','A7','Dm','Gm','C','F'];bell=['Bb','Gm','F','C','Dm','Bb','C','F'];coda=['Bb','F','C','F','Dm','Bb','C','Fopen']
sections=[('One crooked bell',4,102,'intro'),('A square full of voices',16,108,'march'),('Three unsuccessful repairs',16,112,'repair'),('A thin piece of copper',16,94,'copper'),('Wait, says the child',8,82,'bell'),('The city hears one phrase',16,106,'return'),('Room for the small bell',8,90,'coda')]
notes=[];bars=[];pedals=[];beat=0;barno=0
for sec,count,tempo,kind in sections:
 for j in range(count):
  barno+=1;k=j%8
  if kind=='intro':line=copy.deepcopy(A[k]);prog=home
  elif kind=='march':line=copy.deepcopy(A[k] if j<8 else A2[k]);prog=home
  elif kind=='repair':line=copy.deepcopy(A2[k] if j<8 else B2[k]);prog=home if j<8 else minor
  elif kind=='copper':line=copy.deepcopy(B[k] if j<8 else B2[k]);prog=minor
  elif kind=='bell':line=copy.deepcopy(BELL[k]);prog=bell
  elif kind=='return':line=copy.deepcopy(A2[k] if j<8 else A[k]);prog=home
  else:line=copy.deepcopy(CODA[k]);prog=coda
  assert sum(l for n,l in line)==4
  ch=H[prog[k]];bpm=tempo
  if kind=='coda' and j>=5:bpm=[84,76,68][j-5]
  if kind=='bell' and j==0:bpm=76
  bars.append(dict(bar=barno,start=beat,beats=4,bpm=bpm,meter_numerator=4,meter_denominator=4,section=sec,harmony_name=prog[k],harmony=ch,role_plan=kind))
  lv={'intro':72,'march':83,'repair':86,'copper':70,'bell':61,'return':90,'coda':68}[kind]
  off=0
  for n,l in line:
   if n>=0:notes.append(dict(bar=barno,onset=beat+off,duration=l*.97,pitch=n,velocity=lv+(2 if off==0 else 0),voice='melody'))
   off+=l
  bv=lv-29
  # The left hand articulates a shared processional pulse, not an independent melody.
  sparse=kind=='bell';quiet=kind in ('bell','copper','coda')
  for t,n in [(0,ch[0]),(2,ch[0]+12)]:
   if sparse and t==2:continue
   notes.append(dict(bar=barno,onset=beat+t,duration=.4,pitch=n,velocity=bv,voice='bass'))
  points=[1,3] if not quiet else [.5,2.5]
  if sparse:points=[.5]
  for t in points:
   for n in ch[1:4]:notes.append(dict(bar=barno,onset=beat+t,duration=.50 if not quiet else 1.2,pitch=n,velocity=bv-6,voice='accompaniment'))
  if kind=='return' and j in (0,4,8,12):
   e=next(e for e in notes if e['bar']==barno and e['voice']=='melody');q=copy.deepcopy(e);q.update(pitch=e['pitch']-12,velocity=e['velocity']-20,voice='melody_octave');notes.append(q)
  for t,v in [(0,0),(.12,42 if not quiet else 56),(1.9,0),(2.15,40 if not quiet else 52),(3.82,0)]:pedals.append(dict(onset=beat+t,value=v))
  beat+=4
pedals=[e for e in pedals if e['onset']<beat-4]+[dict(onset=beat-4,value=0),dict(onset=beat-3.88,value=63),dict(onset=beat+2,value=0)]
d=dict(id=55,title='The City That Learned to Whisper',title_zh='学会低声说话的城',stage='v0_original_processional',bars=bars,events=notes,pedals=pedals,total_beats=beat,tail_seconds=4.3,story_relationship='A public processional motif becomes a quiet sustained bell phrase, then returns with shared rhythm and a new gentle ending.')
(P/'revisions/score_v0.json').write_text(json.dumps(d,indent=2));(P/'score.json').write_text(json.dumps(d,indent=2));(P/'thematic_material.json').write_text(json.dumps(dict(A=A,A2=A2,B=B,B2=B2,BELL=BELL,CODA=CODA),indent=2));print(len(bars),'bars',sum(b['beats']*60/b['bpm'] for b in bars)+4.3,'seconds')
