# Technical audit — work 69

Final draft: score_v2.json. Audit type: symbolic data inspection only.

- 64 consecutive bars, 4/4; starts 0, 4, …, 252; total 256 quarter beats.
- 800 note events; all voice labels and piano instrument labels are within the requested schema.
- Metered duration: 175.169372 seconds. With requested tail: 179.169372 seconds.
- Melody MIDI range: 61–78 (C♯4–F♯5).
- Upper-support range: 62–71; bass: 42–54; accompaniment: 49–61.
- Maximum simultaneous right-hand reach: 8 semitones; left hand: 11 semitones. Neither exceeds an octave.
- Maximum simultaneous hand polyphony: right 3, left 3. Global note polyphony maximum: 6.
- Same-key active-note overlaps across all voices: 0.
- Melody is monophonic except separately labeled attached harmonic support; no conflicting lead-note overlaps.
- Out-of-bar note endings, invalid durations, pitches, velocities, and off-grid note attacks: zero.
- Every note attack lies on the straight quarter-beat (sixteenth-note) grid. Articulated note-off times may be shorter than written grid values; no swing offsets are introduced.
- 87 offbeat melody notes sustain over the next quarter-note boundary. This is a descriptive rhythm count, not a quality score.
- Five distinct bass attack-pattern signatures. Full left-hand patterns also vary their chord attacks, lengths, and cadential omissions.
- Bass, accompaniment, and upper-support notes outside their current harmonic pitch collection: 0.
- Pedal range 0–34, always within the requested 0–63. Every harmonic/bar boundary explicitly clears the pedal. Last clear occurs at beat 255.9.
- All three complete versions pass the same event, hand-span, collision, harmony-support and pedal checks.

## Reproduction

The generator was run twice in immediate succession. The SHA-256 hashes of all three score JSON files and technical_audit.json were byte-identical. Only the Python standard library is used; no external package or sound process is required.

Final score SHA-256: cfe511e5b7a94e1e504df48ea2b6fc7628e10cb604cddd30d779877655da6954

## Practical interpretation and limits

The hands are assigned explicitly and the maximum simultaneous spans remain under an octave. Some ordinary sequential left-hand position shifts exceed an octave between attacks; these are not held stretches. The largest checked chord-center shift is approximately 15.3 semitones with half a quarter beat between attacks at 88 BPM. The score leaves short key-release gaps rather than requiring a tied stretch. A pianist can redistribute timing slightly if preferred, without adding swing.

These checks do not judge tone, beauty, groove, actual damper resonance, perceived balance, or instrument-specific velocity response. No audio was rendered or heard. Later REAPER integration should confirm audible phrase balance and pedal clearing with the selected acoustic-piano instrument. The written-score audits do not guarantee musical quality.
