from copy import deepcopy

def pitch(s):
 return 12*(int(s[-1])+1)+{'C':0,'D':2,'E':4,'F':5,'G':7,'A':9,'B':11}[s[0]]+s[1:-1].count('#')-s[1:-1].count('b')
def decode(line):
 result=[];t=0
 for token in line.split():
  name,units=token.split(':');dur=float(units)/2
  if name!='R':result.append((pitch(name),t,dur))
  t+=dur
 return result,t
class Writer:
 def __init__(self):self.bars=[];self.events=[];self.pedals=[];self.start=0;self.n=0
 def bar(self,name,bpm,beats,h,ch):
  self.n+=1;self.beats=beats;self.bpm=bpm;self.ch=ch
  numerator,denominator=(int(beats*2),8) if beats in (2.5,3.5) else ((6,8) if METER=='6/8' else (int(beats),4))
  self.bars.append(dict(bar=self.n,start=self.start,beats=beats,bpm=bpm,meter_numerator=numerator,meter_denominator=denominator,section=name,harmony_name=h,harmony=ch))
 def add(self,p,t,d,v=72,inst='piano',voice='theme',hand='right',art='detached'):
  if d>0 and t<self.beats:
   self.events.append(dict(bar=self.n,onset=round(self.start+t,6),duration=round(min(d,self.beats-t),6),pitch=int(p),velocity=max(1,min(127,int(v))),instrument=inst,voice=voice,hand=hand if inst=='piano' else 'none',articulation=art))
 def line(self,line,v=80,hand='right',transpose=0):
  notes,total=decode(line);assert abs(total-self.beats)<1e-7,(self.n,total,self.beats,line)
  for p,t,d in notes:self.add(p+transpose,t,max(.11,d-.09),v+(3 if t==0 else 0),hand=hand)
  return notes
 def release(self,amount=0,length=.7):
  self.pedals.append(dict(bar=self.n,onset=self.start,controller=64,value=0,instrument='piano'))
  if amount:
   self.pedals.extend([dict(bar=self.n,onset=self.start+.05,controller=64,value=amount,instrument='piano'),dict(bar=self.n,onset=self.start+length,controller=64,value=0,instrument='piano')])
  self.start+=self.beats
 def result(self,level):
  self.pedals.append(dict(bar=self.n,onset=self.start-.01,controller=64,value=0,instrument='piano'))
  return dict(id=ID,title=TITLE,title_zh=TITLE_ZH,version=f'v{level}',bars=self.bars,events=self.events,pedals=self.pedals,total_beats=self.start,tail_seconds=5,instrument_map=INSTRUMENT_MAP)
def material(level):
 n=0
 for section,bpm,beats,texture,hs,phrase_names in BLOCKS:
  lines=[]
  for pn in phrase_names.split():lines+=P[pn].split('|')
  harmonies=hs.split();assert len(lines)==len(harmonies),(section,len(lines),len(harmonies))
  for h,line in zip(harmonies,lines):
   n+=1
   for lv,rev in [(1,REV1),(2,REV2)]:
    if level>=lv and n in rev:h,line=rev[n]
   yield n,section,bpm,beats,texture,h,line
ID=134;TITLE='The Archive Elevator';TITLE_ZH='档案室的升降梯';METER='3/4';INSTRUMENT_MAP={'piano':'piano'}
RENDERER_NOTES='Solo piano two-voice writing in 3/4. Left countersubjects are explicitly authored; no generic broken-chord accompaniment. Pedal normally off to keep entries legible.'
H={'F#m':[42,57,61],'C#7':[37,53,59],'D':[38,54,57],'E':[40,56,59],'A':[45,57,61],'Bm':[47,54,62],'G#7':[44,54,60],'F#7':[42,58,61],'C#m':[37,56,61],'B7':[47,57,63],'Dmaj7':[38,54,61],'F#sus':[42,59,61]}
P={
'a':'C#5:1 F#5:1 A5:1 G#5:1 F#5:2|E#5:1 G#5:1 C#6:1 B5:1 G#5:2|F#5:1 A5:1 D6:1 C#6:1 A5:2|G#5:1 B5:1 E6:1 D6:1 B5:2',
'b':'C#6:1 A5:1 E5:1 F#5:1 A5:2|B5:1 F#5:1 D5:1 E5:1 F#5:2|G#5:1 E#5:1 C#5:1 B4:1 G#4:2|F#5:2 C#5:1 A4:1 R:2',
'up':'A5:1 C#6:1 F#6:1 E6:1 C#6:2|B5:1 D6:1 F#6:1 E6:1 D6:2|C#6:1 E6:1 A6:1 G#6:1 E6:2|D6:1 B5:1 G#5:1 E5:1 R:2',
'down':'A5:1 F#5:1 C#5:2 R:2|G#5:1 E#5:1 B4:2 R:2|F#5:1 D5:1 A4:2 R:2|G#5:1 E5:1 B4:2 R:2',
'shelf':'E5:2 A5:1 C#6:1 B5:2|F#5:2 D5:1 A4:1 F#4:2|G#4:2 C#5:1 E5:1 G#5:2|E#5:2 C#5:2 R:2',
'list':'F#5:2 E5:1 C#5:1 A4:2|F#5:1 D5:1 B4:2 D5:2|E#5:1 G#5:1 C#6:2 B5:2|A5:1 F#5:1 C#5:2 R:2',
'cross':'A5:1 F#5:1 C#6:1 A5:1 E6:2|G#5:1 E5:1 B5:1 G#5:1 D6:2|F#5:1 D5:1 A5:1 F#5:1 C#6:2|E#5:1 C#5:1 G#5:1 E#5:1 B5:2',
'answer':'F#5:1 G#5:1 A5:1 C#6:1 E6:2|D6:1 C#6:1 B5:1 A5:1 F#5:2|E5:1 F#5:1 G#5:1 B5:1 D6:2|C#6:1 B5:1 G#5:1 E#5:1 C#5:2',
'open':'A5:2 E5:1 C#5:1 E5:2|F#5:2 A5:1 D6:1 C#6:2|B5:2 G#5:1 E5:1 D5:2|C#5:2 E5:1 A5:1 R:2',
'blank':'R:2 C#5:2 F#5:2|R:4 E#5:2|R:2 D5:2 A5:2|G#5:2 R:4',
'final':'C#6:1 A5:1 F#5:1 A5:1 C#6:2|D6:1 B5:1 F#5:1 A5:1 B5:2|C#6:1 G#5:1 E#5:1 G#5:1 B5:2|A5:1 F#5:1 C#5:1 A4:1 F#4:2'
}
L={
'a':'F#3:2 R:1 A3:1 C#4:2|C#3:2 R:1 E#3:1 G#3:2|D3:2 R:1 F#3:1 A3:2|E3:2 R:1 G#3:1 B3:2',
'b':'A3:1 E3:1 C#3:2 E3:2|B3:1 F#3:1 D3:2 F#3:2|C#4:1 G#3:1 E#3:2 C#3:2|F#3:1 A3:1 C#4:1 B3:1 A3:2',
'up':'F#3:1 A3:1 C#4:2 A3:2|B2:1 D3:1 F#3:2 A3:2|A2:1 C#3:1 E3:2 G#3:2|E3:1 G#3:1 B3:2 R:2',
'down':'F#3:1 A3:1 C#4:1 B3:1 A3:2|C#3:1 E#3:1 G#3:1 B3:1 C#4:2|D3:1 F#3:1 A3:1 B3:1 A3:2|E3:1 G#3:1 B3:1 D4:1 B3:2',
'shelf':'A3:1 E3:1 C#3:2 R:2|D3:1 A3:1 F#3:2 R:2|C#3:1 E3:1 G#3:2 R:2|C#3:2 G#3:2 E#3:2',
'list':'F#3:2 A3:1 C#4:1 B3:2|B2:2 D3:1 F#3:1 A3:2|C#3:2 E#3:1 G#3:1 B3:2|F#3:2 C#3:2 R:2',
'cross':'F#3:2 C#4:1 A3:1 F#3:2|E3:2 B3:1 G#3:1 E3:2|D3:2 A3:1 F#3:1 D3:2|C#3:2 G#3:1 E#3:1 C#3:2',
'answer':'F#3:1 C#3:1 R:2 A3:2|B2:1 F#3:1 R:2 D4:2|E3:1 B2:1 R:2 G#3:2|C#3:1 G#3:1 B3:1 G#3:1 E#3:2',
'open':'A3:2 E3:1 C#3:1 A2:2|D3:2 F#3:1 A3:1 C#4:2|E3:2 B3:1 G#3:1 E3:2|A2:2 C#3:1 E3:1 A3:2',
'blank':'F#3:2 R:4|C#3:2 R:4|D3:2 R:4|E3:2 R:4',
'final':'F#3:2 C#3:1 A2:1 C#3:2|B2:2 F#3:1 D3:1 B2:2|C#3:1 E#3:1 G#3:2 C#4:2|F#3:2 C#3:2 F#2:2'
}
BLOCKS=[
('Doors_in_motion',106,3,'a','F#m C#7 D E A Bm C#7 F#m','a b'),
('First_floor',112,3,'a','F#m C#7 D E A Bm C#7 F#m','a b'),
('Up_to_records',118,3,'up','F#m Bm A E F#m Bm A E','up up'),
('Returning_boxes',102,3,'down','F#m C#7 D E F#m C#7 D E','down down'),
('Shelf_numbers',90,3,'shelf','A D C#m C#7 F#m Bm C#7 F#m','shelf list'),
('Two_catalogues',106,3,'cross','F#m E D C#7 F#m Bm E C#7','cross answer'),
('Cross_reference',112,3,'cross','F#m E D C#7 F#m Bm E C#7','cross answer'),
('Afternoon_light',98,3,'open','A D E A A D E A','open open'),
('Another_stack',112,3,'a','F#m C#7 D E A Bm C#7 F#m','a b'),
('Lift_is_full',120,3,'up','F#m Bm A E F#m Bm A E','up up'),
('Wrong_label',110,3,'cross','F#m E D C#7 F#m Bm E C#7','cross answer'),
('Unmarked_floor',80,3,'blank','F#m C#7 D E F#m C#7 D E','blank blank'),
('Bring_it_back',124,3,'final','F#m Bm C#7 F#m F#m Bm C#7 F#m','final final'),
('Doors_on_one',110,3,'final','F#m C#7 D E F#m Bm C#7 F#m','a final')]
REV1={41:('F#m','C#6:1 A5:1 F#5:2 E5:1 C#5:1'),42:('B7','D#6:1 B5:1 A5:2 F#5:1 D#5:1'),43:('E','B5:1 G#5:1 E5:2 D5:1 B4:1'),44:('A','C#6:1 A5:1 E5:2 C#5:1 A4:1'),45:('Dmaj7','C#6:2 A5:1 F#5:1 D5:2'),46:('G#7','B#5:1 G#5:1 D#5:2 F#5:2'),47:('C#7','G#5:1 E#5:1 C#5:2 B4:1 G#4:1'),48:('F#m','A5:1 F#5:1 C#5:2 R:2')}
LREV1={41:'F#3:1 A3:1 C#4:2 A3:1 F#3:1',42:'B2:1 D#3:1 F#3:2 A3:1 F#3:1',43:'E3:1 G#3:1 B3:2 G#3:1 E3:1',44:'A2:1 C#3:1 E3:2 A3:1 E3:1',45:'D3:1 F#3:1 A3:2 C#4:2',46:'G#2:1 B#2:1 D#3:2 F#3:2',47:'C#3:1 E#3:1 G#3:2 B3:2',48:'F#3:2 C#3:2 R:2'}
REV2={89:('F#sus','R:4 C#5:1 F#5:1'),90:('C#7','R:2 E#5:2 G#5:2'),91:('Dmaj7','R:2 C#5:1 D5:1 F#5:2'),92:('E','B4:2 R:4'),93:('F#m','C#5:2 F#5:1 A5:1 R:2'),94:('Bm','F#5:2 D5:1 B4:1 R:2'),95:('C#7','E#5:1 G#5:1 C#6:2 R:2'),96:('C#7','G#5:2 E#5:1 C#5:1 R:2')}
LREV2={89:'F#3:2 R:4',90:'R:2 C#3:2 R:2',91:'D3:2 R:4',92:'R:4 E3:2',93:'F#3:1 A3:1 C#4:2 R:2',94:'B2:1 D3:1 F#3:2 R:2',95:'C#3:1 E#3:1 G#3:2 R:2',96:'C#3:2 R:4'}
def build(level):
 w=Writer();leftlines=[]
 for block in BLOCKS:
  for name in block[-1].split():leftlines+=L[name].split('|')
 for n,section,bpm,beats,style,h,line in material(level):
  w.bar(section,bpm,beats,h,H[h]);v={'a':83,'up':96,'down':77,'shelf':62,'cross':86,'open':71,'blank':50,'final':101}[style]
  ll=leftlines[n-1]
  if level>=1 and n in LREV1:ll=LREV1[n]
  if level>=2 and n in LREV2:ll=LREV2[n]
  # The two written lines borrow and invert the same ascent. Neither is a generated chord loop.
  w.line(line,v,'right');w.line(ll,v-15,'left')
  w.release(28 if style=='open' else 0,.72)
 return w.result(level)
