import pathlib,json,struct
p=pathlib.Path(__file__).parent;d=json.loads((p/'score.json').read_text());ppq=960

def vlq(v):
 b=[v&127];v>>=7
 while v:b.insert(0,128|(v&127));v>>=7
 return bytes(b)
def track(events):
 out=bytearray();last=0
 for tick,order,data in sorted(events,key=lambda x:(x[0],x[1])):
  out+=vlq(tick-last)+data;last=tick
 return b'MTrk'+struct.pack('>I',len(out))+out
meta=[]; previous_section=None; previous_meter=None
for b in d['bars']:
 t=round(b['start']*ppq);tempo=round(60000000/b['bpm']);meta.append((t,0,b'\xff\x51\x03'+tempo.to_bytes(3,'big')))
 if b['section']!=previous_section:
  txt=b['section'].encode();meta.append((t,1,b'\xff\x06'+vlq(len(txt))+txt))
 meter=(b.get('meter_numerator',b['beats']),b.get('meter_denominator',4))
 if meter!=previous_meter:meta.append((t,2,b'\xff\x58\x04'+bytes([meter[0],meter[1].bit_length()-1,36 if meter==(6,8) else 24,8])))
 previous_section=b['section'];previous_meter=meter
end=round((d['total_beats']+d.get('tail_seconds',8)*d['bars'][-1]['bpm']/60)*ppq);meta.append((end,9,b'\xff\x2f\x00'))
notes=[(0,0,b'\xc0\x00')]+[(0,1,bytes([0xb0,k,v])) for k,v in [(20,62),(21,20),(22,18),(23,50)]]
for e in d['events']:
 notes.extend([(round(e['onset']*ppq),3,bytes([0x90,e['pitch'],e['velocity']])),(round((e['onset']+e['duration'])*ppq),1,bytes([0x80,e['pitch'],0]))])
for e in d['pedals']:notes.append((round(e['onset']*ppq),2,bytes([0xb0,64,e['value']])))
notes.extend([(end-1,8,bytes([0xb0,64,0])),(end,9,b'\xff\x2f\x00')])
(p/'055_city_whispers.mid').write_bytes(b'MThd'+struct.pack('>IHHH',6,1,2,ppq)+track(meta)+track(notes))
print('MIDI saved',len(d['events']),'notes',len(d['pedals']),'pedal points; bytes',(p/'055_city_whispers.mid').stat().st_size)
