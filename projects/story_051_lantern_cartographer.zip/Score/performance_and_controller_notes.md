# Performance and renderer contract

## Roles and pacing

Use one piano and one MIDI channel (zero-based channel 0), with program 0. Bars 1–56 are 5/4 grouped 3+2; bars 57–64 are 4/4 grouped 2+2. Tempo is piecewise constant at each bar as in the source renderer. Do not interpret a bar's beat count as seconds or use one global BPM.

The right hand leads except in bars 25–32, where the left hand sings the entire tenor phrase. The other hand supports that phrase with compact, quiet chords. In the opening, reflected-lane, development, return and culmination sections, the left hand's quavers trace the current harmony. They do not form a competing tune. Phrase endings remove support attacks with the melody's rest. The courtyard uses a different block-chord texture, and the coda lengthens the melodic target notes.

v6c has 915 note attacks, with 36–54 lead notes per eight-bar section. The most intense passage is a brief rise in bars 17–24, not a permanently elevated velocity floor. The return's high point revisits the earlier D6 in a gentler harmonic context. Lead velocity means range roughly 61–82 by section; support means roughly 32–51. These are MIDI velocities, not dB or a promise of perceived balance.

No hand needs to hold more than an octave (LH) or a major sixth (RH). The octave occurs only in the final D2–A2–D3 arrival. The fast-relocation check records nearest key-to-key distances between adjacent attacks; it is a useful screen, not a proof of a particular player's fingering. The final score needs no automatic omission of colliding support notes; the ownership guard remains in the generator as a check.

## Actual CC64 semantics and clearances

This score is designed for the existing corrected Accurate/Moonlight-Salamander piano SFZ, inspected locally without modification. Its global settings include:

- sustain_cc=90, resetting the default CC64 sustain switch
- ampeg_dynamic=1
- ampeg_release=0.5 and ampeg_releasecc64=100
- ampeg_release_curvecc64=11
- curve 11 points: v000=0, v032=0, v042=.1, v054=.3, v062=.4, v064=1, v127=1
- resonance curve 12: v000=0, v022=0, v032=.3, v062=.8, v064=1, v127=1
- sampled-release regions are bounded by hicc64=32; relevant resonance groups start at locc64=22

The v6 scores use only CC64 values **0, 36, 38, 40, 42, 44, 46, 48, 50, 52**. Values 36–52 are within the bank's partial release-shaping region. They are deliberately not interpreted using a generic GM threshold of 64. The score contains no CC64 value of 64 or higher, and does not call 70–80 values “half-pedal.” A different sampler may treat these values differently and will not reproduce this contract merely because it accepts MIDI.

Each bar begins with CC64=0, then catches at +0.10 quarter-note beat. Most 5/4 bars clear at +2.92, catch again at +3.10 and clear before the next harmony. Shorter melodic phrase endings clear at the corresponding earlier exit. The courtyard clears at +2.85 before its +3.10 catch. The 4/4 coda normally clears at +2.12 before a +2.30 catch. In bar 63, the suspension clears at +1.43 and the resolved chord catches at +1.57. Bar 64 catches at +0.10 with value 52 and clears at +3.00, leaving the fourth beat without a new attack.

Because this bank shapes release continuously, a positive value may retain a note after key-off. Simultaneous-key ownership checks therefore concern MIDI key-down intervals; they do not assert that all acoustic release tails disappear. Harmonic clearing is explicit. The existing bank's note_polyphony=1 additionally governs repeated-key voice behavior; the score never relies on stacked same-key MIDI notes.

## Source JSON renderer and MIDI agree

The source renderer reads `bars`, `events`, `pedals`, and `tail_seconds`. `pedals` is a list of absolute quarter-note `onset` and raw 0–127 `value`; the renderer sends those values to CC64 unchanged. Extra `voice`, `hand`, `role`, `harmony_name`, and `controller_contract` fields document intent and are not separately sounded.

At a common sample time, its order is note-off, CC, then note-on. The MIDI exporter uses the same order at a common tick. MIDI PPQ is 960. Note durations crossing a tempo boundary are interpreted through the piecewise tempo map, rather than converted with only the note's starting BPM.

For eventual use with the existing source renderer, its `--enable-details` setting is required for the intended detail state: CC20=62 (sampled release), CC21=20 (hammer noise), CC22=18 (pedal noise), CC23=50 (resonance). This document does not authorize rendering. The JSON `controller_contract` field is explanatory; the existing renderer does not consume arbitrary initial-CC arrays.

The MIDI includes those four initial values explicitly, plus the bank's retained defaults CC7=100, CC10=64, CC24=0, CC72=0, CC90=0 and CC99=0. Initial CC64=0 is in the score's pedal stream. There is no expression, volume, pan, soft-pedal or sostenuto automation. No independent per-voice channels or gains secretly alter the lead/support relationship.

All key-off events precede the end of the 312 notated beats; the final pedal release is beat 311. The whole 312-beat form is followed by a 4.8-second allocated tail. No release event lies outside that output window. Actual tail sufficiency, noise, stereo image, piano balance and musical success remain untested until a separately authorized audio render and listening review.
