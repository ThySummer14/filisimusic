# 086 — A Caravan of Broken Compasses / 坏罗盘车队

Self-contained symbolic solo-piano composition. Selected version: **v3**. No audio was generated.

- Selected score: `score.json`, byte-identical to `score_v3.json`
- Current generation: `generate_v3.py`, deriving the playability revision from the SHA-pinned `score_v2.json`
- Original composition source: `generate_score.py`, retained unchanged for historical v0/v1/v2
- Story: `story_zh.txt`
- Musical form, story causality, performance intent, and current limitations: `music_notes_zh.md`
- Revision history: `revision_notes.md`
- Current audit: `audit_v3.json`
- Independent file-based verification: `verify_v3.py`, `independent_verification_v3.json`
- Exact current changes: `exact_diff_v2_to_v3.json`
- Explicit unchanged-RH position plan: `right_hand_position_plan_v3.json`
- Current SHA-256 manifests: `hash_manifest.json`, identical to `hash_manifest_v3.json`
- Historical manifest: `hash_manifest_v2.json`
- Complete preserved v2 package: `historical_v2/`; its original manifest verifies its files

Regenerate the current selected version:

```sh
python generate_v3.py
python verify_v3.py
python refresh_manifest_v3.py
```

The original `generate_score.py` and `verify_symbolic.py` are historical v0/v1/v2 entry points; the current entry point is `generate_v3.py`. The root `score_v0.json`, `score_v1.json`, and `score_v2.json` retain their original bytes.

All starts, onsets, durations, `beats`, and `total_beats` are quarter-note beats. 9/8 means 4.5 beats per bar. Tempo is quarter notes per minute and may change once per bar. `tail_seconds` is wall-clock tail time. The score schema follows works 084 and 082.

Duration: 190.698319 seconds plus 7 seconds of tail = 197.698319 seconds. v3 preserves every right-hand event and the complete bar/form/harmony/tempo/pedal maps from v2. It changes only LH support pitches, selected answer onsets, and required releases.

The strict LH travel criterion measures actual grip edges and includes releases of every earlier key: 75ms + 12ms per semitone beyond four, for translations over four semitones. v3 checks 132 transfers, with zero failures and a minimum 30ms margin. RH notes have a separately verified octave-width position plan, with actual position shifts no larger than four semitones. This is a feasible symbolic arrangement, not a listening review or human performance validation.

Only this dedicated draft directory is authored. The owner's separate frozen work-086 copy and all other collection files remain untouched.
