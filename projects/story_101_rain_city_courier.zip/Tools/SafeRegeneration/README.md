# Safe source regeneration

This isolated command-line wrapper prepares a score-specific original-region subset for Moonlight, or the complete small Iowa bank, verifies native sfizz candidate coverage, then uses the included **unchanged production float32 renderer** with the official `hint_ram_based=1` load mode. It never edits the original score, MIDI, SFZ or sample files. It never downloads or installs software.

**Use `regenerate.py` as the only recommended entry point** (in the delivered collection: `Tools/SafeRegeneration/regenerate.py`). `render_score_sfizz.py` is an internal, byte-identical historical component. **Direct execution uses unsafe streaming defaults** and bypasses the RAM hint, pruning, native verification, input hashes and resource safeguards. Do not invoke it directly.

## Replay versus editing

- **Fixed-score replay:** play the already-rendered WAV files or the delivered REAPER project with its included media. This does not require rebuilding or decoding the original sample bank. A supplied render remains tied to the score that produced it.
- **Newly edited score:** this wrapper needs the edited JSON score in the original renderer schema, the **original full SFZ mapping**, its unchanged external sample bank and an explicitly selected sfizz shared library. It regenerates a new subset and queries that actual engine again. A previous subset or old hash certificate does not authorize an edited score or a changed bank/library. MIDI is neither rewritten nor imported by this wrapper; MIDI edits must first be represented in the JSON score.
- This produces a source stem, **not a finished REAPER master**. Reopen the versioned project, use the new source deliberately, and perform the actual REAPER export and sound checks separately.

## Existing dependencies, supplied by you

Python 3.9+; NumPy already available in that Python environment; the original sample bank and SFZ; a compatible native sfizz library and its existing system dependencies. Native execution supports Linux/macOS with `ps`; static dry-run is standard-library-only. The production baseline uses official sfizz 1.2.3. Other builds must support the required public C API, OSC queries and RAM hint; a load/query/opcode/coverage failure stops the run. No shared library, original sample bank, Python package or full-bank RAM image is bundled here.

Moonlight recordings and remaster/SFZ retain their original attribution/licensing obligations. Keep the bank's original license and attribution files when obtaining or moving it. This wrapper does not supply or modify those assets.

## Commands

Use actual paths for every input. These are examples, not machine-specific defaults:

```sh
python regenerate.py --score /path/to/score.json \
  --sfz /path/to/original/Moonlight.sfz --library /path/to/libsfizz.so.1 \
  --out /path/to/new/piano.wav --mode moonlight-subset \
  --ram-cap-mib 700 --enable-details --dry-run
```

First inspect the printed plan. Remove `--dry-run` only when ready for native verification and rendering. `--verify-only` runs the native metadata/probe stage and writes verification artifacts but does not render audio. All output and audit paths must be new. On macOS, supply your existing `.dylib` path explicitly.

For the controlled 8-second diagnostic/replay comparison:

```sh
python regenerate.py --score /path/to/score.json \
  --sfz /path/to/original/Moonlight.sfz --library /path/to/libsfizz.so.1 \
  --out /path/to/new/piano_first8s.wav --mode moonlight-subset \
  --ram-cap-mib 450 --max-seconds 8 --enable-details
```

`--max-seconds` is passed unchanged to the original renderer and bound into the plan's note selection, frame count and native coverage proof. Without it, rendering covers bars plus the original tail. `--enable-details` must match the original render: it sends the original CC20/21/22/23 values; omitting it preserves the original renderer's disabled-details mode. No scheduler, notes, velocity values, expression values, sample precision, voice count, sample rate, block size or DSP parameters are changed.

For a small Iowa bank:

```sh
python regenerate.py --score /path/to/clarinet_score.json \
  --sfz /path/to/original/Iowa_clarinet.sfz --library /path/to/libsfizz.so.1 \
  --out /path/to/new/clarinet.wav --mode complete-bank --ram-cap-mib 256
```

Complete-bank mode keeps every region and is limited to **256 MiB of decoded samples**. It cannot be used to fully decode the large Moonlight bank. Moonlight mode must actually remove some sample files, and every mode must pass the total RAM estimate. `--reserve-mib` can increase the default/minimum 128 MiB process reserve. `--timeout-seconds` sets a per-stage timeout (default 600). `--work-dir` chooses a new audit directory; otherwise it is the output stem plus `.regeneration`.

## What is checked

1. Restricted SFZ parsing fails on includes/macros, unsupported selection/path constructs, inherited sample paths, unsupported WAV formats and invalid score timing. Repeated source declarations remain in their original order. All non-region headers and curves remain; only the RAM hint is added and retained sample paths are relocated.
2. Piano selection keeps original note/resonance regions matching keys and integer velocity neighbors **V−1, V, V+1**, all releases for used keys at every velocity and every CC/random alternative. Actual velocities and original velocity boundaries are unchanged. This avoids the observed float32 boundary error where velocity 72 can select a written `hivel=71` region.
3. Before engine loading, sample headers estimate decoded float32 storage, the largest decode/read temporary and the process reserve. The separate original-bank query estimate includes 256-frame preloads plus original sample offsets. Over-budget plans stop immediately.
4. The original SFZ is queried with a 256-frame streaming preload through public C API/OSC calls, **without audio rendering**. No full-bank RAM hint is added to this query. A tiny generated oscillator probe measures all 127 actual MIDI velocity values and checks RAM-hint recognition.
5. Independent parsing verifies every emitted retained effective region, ordered headers, duplicate opcodes and curves. Native key/velocity/trigger/sample records must prove the emitted subset contains every original candidate for the selected score window, preserving order. All CC/release branches are checked conservatively.
6. Score, original SFZ, selected original samples, explicit engine and bundled renderer/support files are SHA-256-bound. They are checked again before and after rendering. The renderer receives the supplied library through `SFIZZ_LIBRARY`; it is never chosen from a workspace path.
7. Linux/macOS child-process-tree RSS is polled during query/render and over-limit processes are terminated. Polling and the estimate are **not a kernel-enforced peak-RAM guarantee**. Each stage has a timeout. SIGTERM, SIGINT and KeyboardInterrupt clean up the owned stage process group, including descendants; a 0.5-second grace is followed by SIGKILL when needed. This also covers stages that started their own session relative to an outer watchdog. Uncatchable SIGKILL or machine failure cannot run application cleanup. A Linux no-audio fixture compares `/proc` task/children traversal with `ps` ancestry enumeration. In this execution environment, `/proc` traversal missed known fixture descendants while `ps` found them; `tests/PROCESS_ENUMERATION_REPORT.json` records the actual evidence. This does not establish why the historical outer watchdog read low or attribute the difference to session creation. Use the inner stage logs for this wrapper's observed RSS. A failed run leaves diagnostic files and no verified success report.
8. The returned WAV must have the original 44.1 kHz stereo IEEE-float32 header, exact frame count, finite payload and matching copy hash. Existing output files are never overwritten. The temporary render is retained in the audit directory, so allow disk space for two copies.

An unsupported bank or future engine behavior fails closed. Native candidate coverage is **not an audio-equivalence certificate**: compare to a valid reference and listen before replacing a source or delivering a master. The owner separately accepted the initial wrapper on #055 (8-second Moonlight) and #063 (3-second complete-bank clarinet): both outputs were PCM-exact to their independent full-RAM references. That evidence is in the surrounding audit's `portable_regenerator_live_acceptance.json`. Subsequent termination/provenance hardening uses no-audio tests and leaves the renderer and musical parameters unchanged. These two prefix checks do not certify every new score or a full collection render.

## Artifacts and portability

A successful run writes the requested WAV and the original `.render.json` sidecar. The audit directory contains `plan.json`, the derived `verified_ram.sfz`, actual `native_bounds.json`, `native_validation.json`, stage logs/RSS results and `result.json`. Successful manifests include the score, original-bank SFZ, library, renderer and rendered-sample-set SHA-256 values, per-used-sample hashes, and the complete queried native bounds and velocity table. The sample-set hash explicitly covers rendered samples, not unrendered files in the external bank. Failure writes `failure.json` and must not be presented as a successful render. Verification-only has its own explicit non-rendered status.

Generated SFZ sample paths are relative to the new audit directory where possible. Move that directory together with its external bank layout, or rerun using explicit paths at the new location. Per-run manifests record actual local paths and freshly measured hashes; they are provenance for that run, not portable machine authorization. The bundle integrity manifest only hashes the distributed code. There are no hardcoded library or bank hashes and no copied runtime-native certificate used as approval.

## Static test suite

```sh
python -m unittest discover -s tests -v
```

Tests create short synthetic PCM fixtures under `tests/`, use fabricated native responses and dry runs, and start ordinary sleeping Python subprocesses to verify SIGTERM/SIGINT/KeyboardInterrupt cleanup, including TERM-ignoring descendants. They never load sfizz, decode the live bank or render audio. An additional read-only/static comparison against the already-existing #055 native manifest confirmed the same 135 retained regions, 102 samples and 272.143 MiB decoded estimate for the 8-second reference. This is a regression check, not a newly executed audio test.
