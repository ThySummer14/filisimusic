from pathlib import Path
import json,copy
P=Path(__file__).parent;d=json.loads((P/'score_v2.json').read_text());bars={b['bar']:b for b in d['bars']};cello=sorted([e for e in d['events'] if e['instrument']=='cello'],key=lambda e:e['onset']);changes=[]
for i,e in enumerate(cello):
 b=bars[e['bar']];sec_per_beat=60/b['bpm'];old=e['duration'];to_bar=b['start']+b['beats']-e['onset'];to_next=(cello[i+1]['onset']-e['onset']) if i+1<len(cello) else 4
 # Retain damped pizzicato, but leave enough of the recorded body to breathe.
 target=.48 if b['role_plan'].lower().find('intro')>=0 else .55
 e['duration']=min(max(old,target/sec_per_beat),to_bar-.06,to_next-.14/sec_per_beat)
 if e['duration']!=old:changes.append({'bar':e['bar'],'onset':e['onset'],'before_beats':old,'after_beats':e['duration']})
d['events'].sort(key=lambda e:(e['onset'],e['pitch']));d['stage']='v3_damped_pizzicato_body_and_phrase_clearance'
for f in ['ensemble_score.json','revisions/ensemble_v3.json']:(P/f).write_text(json.dumps(d,ensure_ascii=False,indent=2))
for instrument in ['clarinet','cello']:
 x={**d,'events':[e for e in d['events'] if e['instrument']==instrument],'pedals':[]}
 for f in [f'{instrument}_score.json',f'revisions/{instrument}_v3.json']:(P/f).write_text(json.dumps(x,ensure_ascii=False,indent=2))
(P/'revisions/pass3.json').write_text(json.dumps({'round':3,'kind':'substantive_articulation_revision','changes':['Lengthen cello note gates toward0.55sec while preserving at least0.14sec separation from the next pluck and staying within the bar. Retain all pitches and rhythmic onsets.','Use a existing mf SFZ0.10sec release mapping rather than the trio0.06sec release, preserving more of each recorded pizzicato body without claiming bowed sustain or a new dynamic layer.'],'changed_gates':changes,'real_recorded_cello_layers':['mf'],'velocity_is_amplitude_only':True,'human_listening_review':False},indent=2));print('changed cello gates',len(changes))
