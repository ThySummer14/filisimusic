#!/usr/bin/env python3
"""Independent disk reader for work 091. Does not import generator functions.
Checks physical key histories, finger maps, phrase/role constraints, all exact
diffs, and a fresh subprocess reproduction. Python standard library; no audio.
"""
import copy
import hashlib
import json
import math
import subprocess
import sys
import tempfile
from collections import defaultdict
from pathlib import Path
ROOT=Path(__file__).resolve().parent

def load(name):return json.loads((ROOT/name).read_text(encoding='utf-8'))
def save(name,x):(ROOT/name).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def sha(name):return hashlib.sha256((ROOT/name).read_bytes()).hexdigest()
def end(e):return round(e['onset']+e['duration'],6)

def inspect(s):
    errors=[];bars=s['bars'];notes=s['events']
    def check(ok,msg):
        if not ok:errors.append(msg)
    def sec(t):return sum(min(max(t-b['start'],0),b['beats'])*60/b['bpm'] for b in bars)
    check(s['id']==91 and s['total_beats']==256 and s['tail_seconds']==6,'work and endpoint')
    check(s['instrumentation']==['natural_acoustic_piano'],'solo acoustic piano')
    check(len(bars)==64 and 195<=sec(256)+6<=220,'full form and duration')
    for i,b in enumerate(bars):
        check((b['bar'],b['start'],b['beats'],b['meter_numerator'],b['meter_denominator'])==(i+1,i*4,4,4,4),f'bar grid {i+1}')
        check(60<=b['bpm']<=100,f'tempo {i+1}')
        check(b['lead_hand']==('left' if 33<=i+1<=40 else 'right'),f'lead plan {i+1}')
        check(b['phrase_id']==f'P{i//4+1:02d}',f'bar phrase plan {i+1}')
    check(len({e['event_id'] for e in notes})==len(notes),'unique event IDs')
    check(notes==sorted(notes,key=lambda e:(e['onset'],e['hand'],e['pitch'],e['voice'])),'chronological event order')
    plans={(p['bar'],p['hand']):p for p in s['hand_position_plan']}
    check(len(plans)==len(s['hand_position_plan'])==128,'all bar-hand plans')
    for e in notes:
        check(e['instrument']=='piano' and e['hand'] in ('left','right'),'event instrument and hand')
        check(all(math.isfinite(e[k]) for k in ('onset','duration','pitch','velocity')),'finite event')
        check(isinstance(e['pitch'],int) and 21<=e['pitch']<=108 and 1<=e['velocity']<=127,'MIDI bounds')
        check(0<=e['onset']<end(e)<=256,'physical duration bounds')
        b=bars[e['bar']-1];p=plans[(e['bar'],e['hand'])]
        check(b['start']<=e['onset']<end(e)<=b['start']+4,'event/bar membership')
        check(abs(e['target_on_seconds']-sec(e['onset']))<1.1e-6 and abs(e['target_off_seconds']-sec(end(e)))<1.1e-6,'time integration')
        check(e['target_on_beats']==e['onset'] and abs(e['target_off_beats']-end(e))<1.1e-6,'beat aliases')
        check(e['hand_position_id']==p['position_id'] and e['hand_position_range']==p['range'],'position identity')
        check(e['position_keys']==sorted(int(k) for k in p['pitch_finger_map']),'explicit position keys')
        check(p['pitch_finger_map'].get(str(e['pitch']))==e['finger'] and 1<=e['finger']<=5,'finger identity')
        chord=e['pitch']%12 in {q%12 for q in b['harmony']}
        check(e['harmonic_function']==('chord_tone' if chord else 'melodic_nonchord_tone'),'harmonic label')
        if e['voice']!='melody':
            check(chord,f'support chord membership {e["event_id"]}')
            check(e['role']=='support','support ownership')
        else:check(e['hand']==b['lead_hand'] and e['role']=='lead','single foreground ownership')
        check(e['written_value_beats']>=e['duration']>0,'written/physical duration')
    for key,p in plans.items():
        ns=[e for e in notes if (e['bar'],e['hand'])==key];ps=sorted({e['pitch'] for e in ns})
        if not ns:
            check(p['active'] is False and p['range'] is None and not p['pitch_finger_map'],'honest inactive plan')
            continue
        fs=[p['pitch_finger_map'][str(k)] for k in ps]
        check(p['active'] and p['range']==[min(ps),max(ps)] and max(ps)-min(ps)<=12,f'real position {key}')
        check(len(ps)<=5 and len(fs)==len(set(fs)),'distinct pitch/finger map')
        check(fs==sorted(fs,reverse=p['hand']=='left'),'uncrossed finger ordering')
        check(all(b-a<=7 for a,b in zip(ps,ps[1:])),'adjacent assigned key spacing')
    changes=defaultdict(list);attacks={h:defaultdict(list) for h in ('left','right')}
    for i,e in enumerate(notes):
        changes[e['onset']].append((1,i));changes[end(e)].append((0,i));attacks[e['hand']][e['onset']].append(e)
    held={};maxspan={h:0 for h in attacks};maxkeys={h:0 for h in attacks};physical={h:{} for h in attacks}
    overlap=[];cross=[];fingers=[];silent=[];lastoff=None;maxlead=0;exposedmax=0
    for t in sorted(changes):
        was=bool(held)
        for kind,i in sorted(changes[t]):
            if kind==0:held.pop(i,None)
            else:
                e=notes[i]
                for old in held.values():
                    if old['pitch']==e['pitch']:overlap.append([old['event_id'],e['event_id']])
                    if old['hand']==e['hand'] and old['finger']==e['finger']:fingers.append([old['event_id'],e['event_id']])
                held[i]=e
        if was and not held:lastoff=t
        if held and lastoff is not None:
            if t>lastoff:silent.append(sec(t)-sec(lastoff))
            lastoff=None
        maxlead=max(maxlead,sum(e['voice']=='melody' for e in held.values()))
        if 192<=t<(208 if s['version']=='v2' else 200):exposedmax=max(exposedmax,len(held))
        hands={h:[e for e in held.values() if e['hand']==h] for h in attacks}
        for h,ns in hands.items():
            if ns:
                ps=[e['pitch'] for e in ns];maxspan[h]=max(maxspan[h],max(ps)-min(ps));maxkeys[h]=max(maxkeys[h],len(ps))
                if t in attacks[h]:physical[h][t]=[min(ps),max(ps)]
        if all(hands.values()) and max(e['pitch'] for e in hands['left'])>=min(e['pitch'] for e in hands['right']):cross.append(t)
    check(not overlap and not cross and not fingers,'same-key, hand crossing or finger collision')
    check(max(maxspan.values())<=12 and max(maxkeys.values())<=5,'held geometry')
    check(maxlead==1,'one nonoverlapping foreground')
    check(exposedmax==1,'truly exposed physical monody')
    check(max(silent,default=0)<.4,'no silence padding')
    transfers=[];within=[]
    for hand in attacks:
        groups=sorted(attacks[hand].items());latest=0
        for i,(t,group) in enumerate(groups):
            if i:
                prev_t,prev=groups[i-1];old=physical[hand][prev_t];new=physical[hand][t]
                edge=max(abs(a-b) for a,b in zip(old,new))
                oldp=plans[(prev[0]['bar'],hand)];newp=plans[(group[0]['bar'],hand)]
                position_edge=max(abs(a-b) for a,b in zip(oldp['range'],newp['range']))
                changing=oldp['position_id']!=newp['position_id']
                # Both hands can sing. An unchanged explicit ordered finger map
                # justifies within-position melodic movement in either hand.
                # Accompaniment grip-edge changes receive the same stress test
                # even if the declaration happens to call them one position.
                melodic=all(e['voice']=='melody' for e in prev+group)
                needed=changing or (edge>4 and not melodic)
                if needed:
                    travel=max(edge,position_edge) if changing else edge
                    required=.075+.012*max(0,travel-4);available=sec(t)-sec(latest)
                    row={'hand':hand,'from_beat':prev_t,'to_beat':t,'old_grip':old,'new_grip':new,
                        'old_position':oldp['range'],'new_position':newp['range'],'whole_position_changed':changing,
                        'grip_edge_semitones':edge,'position_edge_semitones':position_edge,'checked_travel_semitones':travel,
                        'last_prior_key_release_beat':latest,'available_seconds':round(available,9),
                        'required_seconds':round(required,9),'margin_seconds':round(available-required,9),'passed':available+1e-7>=required}
                    transfers.append(row);check(row['passed'],f'transfer {hand} at {t}')
                elif edge>4:
                    within.append({'hand':hand,'from_beat':prev_t,'to_beat':t,'position_id':newp['position_id'],
                      'edge_semitones':edge,'from_pitches':[e['pitch'] for e in prev],'to_pitches':[e['pitch'] for e in group],
                      'from_fingers':[e['finger'] for e in prev],'to_fingers':[e['finger'] for e in group],
                      'method':'One melodic line using distinct fingers of the same independently checked octave-contained grip.'})
            latest=max(latest,*(end(e) for e in group))
    lead=sorted([e for e in notes if e['voice']=='melody'],key=lambda e:e['onset'])
    check({e['bar'] for e in lead}==set(range(1,65)),'lead in every bar')
    for n in range(1,65):
        es=[e for e in lead if e['bar']==n];cursor=(n-1)*4
        for e in es:check(abs(e['onset']-cursor)<1e-6,'unbroken written melody rhythm');cursor+=e['written_value_beats']
        check(abs(cursor-n*4)<1e-6,'complete four-beat melody bar')
        supports=[e for e in notes if e['bar']==n and e['role']=='support']
        if supports:check(max(e['velocity'] for e in supports)<=min(e['velocity'] for e in es)-14,'support dynamic hierarchy')
    maximum_leap=max(abs(a['pitch']-b['pitch']) for a,b in zip(lead,lead[1:]))
    check(maximum_leap<=12,'no isolated register jumps beyond octave')
    check({e['bar'] for e in lead if e['hand']=='left'}==set(range(33,41)),'one eight-bar LH lead exchange')
    check(all(bars[n-1]['key_region']=='D major' for n in range(25,33)),'contrasting D-major region')
    exposed_bars=list(range(49,53 if s['version']=='v2' else 51))
    check(all(e['role']=='lead' for e in notes if e['bar'] in exposed_bars),'exposed phrase has no support')
    check(bars[-2]['harmony_name']=='F#7' and bars[-1]['harmony_name']=='Bm','earned dominant-tonic close')
    check(lead[-1]['pitch']==59 and end(lead[-1])==256,'final B3 completed to final boundary')
    phrases={p['phrase_id']:p for p in s['phrases']}
    check(len(phrases)==len(s['phrases'])==16,'sixteen distinct phrase IDs')
    for pid,p in phrases.items():
        ns=[e for e in notes if e['phrase_id']==pid]
        check(ns and all(p['first_bar']<=e['bar']<=p['last_bar'] for e in ns),'phrase membership')
        check(abs(p['target_on_beats']-min(e['onset'] for e in ns))<1e-6 and abs(p['target_off_beats']-max(end(e) for e in ns))<1e-6,'phrase endpoints')
        check(abs(sec(p['target_on_beats'])-p['target_on_seconds'])<1.1e-6 and abs(sec(p['target_off_beats'])-p['target_off_seconds'])<1.1e-6,'phrase seconds')
    signatures=[tuple((e['onset']-i*16,e['pitch'],e['duration']) for e in lead if i*4<e['bar']<=i*4+4) for i in range(16)]
    check(len(set(signatures))==16,'distinct four-bar phrase developments')
    ped=s['pedals'];check(ped==sorted(ped,key=lambda p:p['onset']),'pedal chronology')
    check(all(p['instrument']=='piano' and p['controller']==64 and 0<=p['onset']<=256 and 0<=p['value']<=127 for p in ped),'pedal bounds')
    check(ped[-1]['onset']==256 and ped[-1]['value']==0,'terminal pedal release')
    check(all(p['value']==0 for p in ped if p['bar'] in exposed_bars),'dry exposed line')
    return {'passed':not errors,'errors':errors,'event_count':len(notes),'bars':64,'total_quarter_beats':256,
      'duration_with_tail_seconds':round(sec(256)+6,6),'maximum_held_span_semitones':maxspan,'maximum_simultaneous_keys':maxkeys,
      'same_key_overlap_count':len(overlap),'hand_crossing_count':len(cross),'finger_collision_count':len(fingers),
      'maximum_simultaneous_melody_notes':maxlead,'maximum_exposed_simultaneous_keys':exposedmax,
      'pitch_range':[min(e['pitch'] for e in notes),max(e['pitch'] for e in notes)],
      'maximum_physical_key_silence_seconds':round(max(silent,default=0),9),'unique_four_bar_phrases':len(set(signatures)),
      'maximum_successive_melody_leap_semitones':maximum_leap,'left_hand_lead_bars':list(range(33,41)),
      'dry_exposed_bars':exposed_bars,'distinct_harmonies':len({b['harmony_name'] for b in bars}),
      'strict_transfer_count':len(transfers),'minimum_transfer_margin_seconds':min(r['margin_seconds'] for r in transfers),
      'strict_transfers':transfers,'within_position_large_melodic_moves':within,
      'limits':'Symbolic physical-key geometry, authored gates and ordered fingers only. These checks are not listening approval and do not establish human comfort or actual piano-source quality.'}

def patch_apply(original,patch):
    target=copy.deepcopy(original)
    for p in patch:
        keys=[x.replace('~1','/').replace('~0','~') for x in p['path'].split('/')[1:]]
        if not keys:target=p['value'];continue
        obj=target
        for k in keys[:-1]:obj=obj[int(k)] if isinstance(obj,list) else obj[k]
        key=int(keys[-1]) if isinstance(obj,list) else keys[-1]
        if p['op']=='remove':del obj[key]
        else:obj[key]=copy.deepcopy(p['value'])
    return target

def verify_diff(a,b,d):
    errors=[];expected=[];musical=[]
    core=lambda ns:[{k:e[k] for k in ('onset','duration','pitch','instrument','voice','hand')} for e in ns]
    for n in range(1,65):
        row={'bar':n,'before_bar':a['bars'][n-1],'after_bar':b['bars'][n-1],
             'before_events':[e for e in a['events'] if e['bar']==n],'after_events':[e for e in b['events'] if e['bar']==n],
             'before_pedals':[e for e in a['pedals'] if e['bar']==n],'after_pedals':[e for e in b['pedals'] if e['bar']==n]}
        if any(row['before_'+k]!=row['after_'+k] for k in ('bar','events','pedals')):expected.append(row)
        if core(row['before_events'])!=core(row['after_events']) or row['before_bar']['harmony']!=row['after_bar']['harmony']:musical.append(n)
    if expected!=d['changes'] or [x['bar'] for x in expected]!=d['changed_bars']:errors.append('literal per-bar diff')
    if len(musical)<8:errors.append('fewer than eight substantive musical bars')
    for label,s in [('before',a),('after',b)]:
        if d[label+'_sha256']!=sha(f'score_{s["version"]}.json'):errors.append('diff hash')
        if d['phrase_metadata_'+label]!=s['phrases'] or d['position_plan_'+label]!=s['hand_position_plan']:errors.append('metadata diff')
    if patch_apply(a,d['json_patch'])!=b:errors.append('full-document JSON patch reconstruction')
    return {'passed':not errors,'errors':errors,'changed_bars':d['changed_bars'],'strict_musical_changed_bars':musical,
            'strict_musical_changed_bar_count':len(musical),'full_document_patch_reconstructs_next_version':patch_apply(a,d['json_patch'])==b}

def main():
    scores={v:load(f'score_{v}.json') for v in ('v0','v1','v2')};audits={v:inspect(s) for v,s in scores.items()}
    for v,r in audits.items():save(f'audit_{v}.json',r)
    diffs={f'{a}_to_{b}':verify_diff(scores[a],scores[b],load(f'exact_diff_{a}_to_{b}.json')) for a,b in [('v0','v1'),('v1','v2')]}
    same=(ROOT/'score.json').read_bytes()==(ROOT/'score_v2.json').read_bytes()
    with tempfile.TemporaryDirectory(prefix='.reproduction_',dir=ROOT) as tmp:
        subprocess.run([sys.executable,str(ROOT/'generate_score.py'),'--outdir',tmp],check=True,capture_output=True)
        reproduction={p.name:(ROOT/p.name).read_bytes()==p.read_bytes() for p in sorted(Path(tmp).iterdir()) if p.is_file()}
    save('reproducibility_check.json',{'passed':all(reproduction.values()),'byte_identical_files':reproduction,
      'method':'Fresh standard-library Python process generated all score/diff artifacts in a temporary subdirectory, followed by byte-for-byte comparisons.'})
    keys=('passed','errors','event_count','duration_with_tail_seconds','maximum_held_span_semitones','maximum_simultaneous_keys','same_key_overlap_count','hand_crossing_count','finger_collision_count','strict_transfer_count','minimum_transfer_margin_seconds','unique_four_bar_phrases','maximum_physical_key_silence_seconds','maximum_successive_melody_leap_semitones','dry_exposed_bars')
    result={'passed':same and all(r['passed'] for r in audits.values()) and all(r['passed'] for r in diffs.values()) and all(reproduction.values()),
      'selected_equals_v2_byte_for_byte':same,'selected_score_sha256':sha('score.json'),
      'version_summaries':{v:{k:r[k] for k in keys} for v,r in audits.items()},'revision_checks':diffs,
      'reproducibility_passed':all(reproduction.values()),'scope':'Independent saved-file symbolic checks plus fresh-process byte reproducibility. No audio rendering, DSP or listening.'}
    save('independent_verification.json',result)
    files={p.name:{'bytes':p.stat().st_size,'sha256':sha(p.name)} for p in sorted(ROOT.iterdir()) if p.is_file() and p.name!='hash_manifest.json'}
    save('hash_manifest.json',{'algorithm':'SHA-256','files':files,'excludes_self':True,'scope':'Every regular deliverable file in this isolated draft folder.'})
    print(json.dumps(result,ensure_ascii=False,indent=2))
    if not result['passed']:raise SystemExit(1)
if __name__=='__main__':main()
