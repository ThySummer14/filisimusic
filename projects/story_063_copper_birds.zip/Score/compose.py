#!/usr/bin/env python3
"""Original, explicitly authored concert-pitch duet. Non-rendering score builder.
No MIDI/audio engine, samples, network, installation, or random composition.
Run: python3 compose.py .  Produces all three score stages and structural audits.
"""
import copy, json, math, pathlib, sys
ROOT = pathlib.Path(sys.argv[1]) if len(sys.argv) > 1 else pathlib.Path(__file__).resolve().parent
ROOT.mkdir(parents=True, exist_ok=True)
PC = {'C':0,'C#':1,'D':2,'D#':3,'E':4,'F':5,'F#':6,'G':7,'G#':8,'A':9,'A#':10,'B':11}
def pitch(n): return 12*(int(n[-1])+1)+PC[n[:-1]]
def notes(s):
    return [(float(a),pitch(n),float(d)) for a,n,d in (x.split(':') for x in s.split())]
# All pitches and rhythms below are authored here, without a quoted tune/reference.
# Each string is onset-within-bar : concert note : written duration in quarterbeats.
BASE = {
1:'1:E4:.42 2.5:G4:.38',
2:'0:A4:.50 1.5:G4:.42 3:E4:.42',
3:'0:C4:.60 1:E4:.35 2:D4:.55',
4:'.5:D#4:.40 1.5:F#4:.42 3:D#4:.38',
5:'.5:E4:.32 1:G4:.32 1.5:A4:.68 2.5:G4:.32 3:E4:.56',
6:'0:G4:.68 1:E4:.32 1.5:D4:.32 2:C4:.68 3:E4:.42',
7:'.5:F#4:.32 1:A4:.32 1.5:F#4:.68 2.5:E4:.32 3:D4:.56',
8:'0:D#4:.68 1:F#4:.32 1.5:A4:.32 2:F#4:.68 3:D#4:.40',
9:'.5:E4:.32 1:G4:.32 1.5:B4:.70 2.5:A4:.32 3:G4:.55',
10:'0:A4:.68 1:G4:.32 1.5:E4:.32 2:C4:.68 3:E4:.42',
11:'.5:F#4:.32 1:A4:.32 1.5:B4:.65 2.5:F#4:.32 3:D#4:.44',
12:'0:E4:1.15 2:G4:.36 2.5:E4:.65',
13:'0:G4:.65 1:B4:.34 1.5:A4:.34 2:G4:.62 3:D4:.42',
14:'.5:F#4:.34 1:A4:.34 1.5:F#4:.68 2.5:E4:.34 3:D4:.54',
15:'0:E4:.70 1.5:G4:.33 2:B4:.66 3:G4:.40',
16:'.5:A4:.32 1:F#4:.32 1.5:D#4:.66 2.5:F#4:.35 3:B4:.45',
17:'0:G4:.60 1:E4:.32 1.5:D4:.32 2:C4:.65 3:D4:.38',
18:'.5:E4:.32 1:A4:.68 2:G4:.32 2.5:E4:.64',
19:'0:F#4:.62 1.5:D#4:.34 2:F#4:.34 2.5:A4:.65',
20:'0:G4:.62 1:E4:1.05 3:E4:.35',
21:'.5:E4:.30 1.5:G4:.30 2:A4:.55 3:G4:.38',
22:'0:B4:.55 1:G4:.30 2:D4:.55 3.5:G4:.27',
23:'.5:E4:.34 1:G4:.34 2:A4:.55 3:E4:.42',
24:'0:F#4:.58 1.5:A4:.34 2:F#4:.58 3:D4:.38',
25:'.5:C4:.34 1:E4:.34 1.5:A4:.66 3:G4:.38',
26:'0:G4:.55 1:E4:.34 2:B4:.60 3:G4:.38',
27:'.5:F#4:.34 1.5:A4:.34 2.5:F#4:.38',
28:'0:D#4:.64 1.5:F#4:.38 2.5:D#4:.45',
29:'0:E4:.66 1:G4:.34 1.5:E4:.34 2:D4:.62 3:C4:.42',
30:'0:F4:.66 1:A4:.34 1.5:G4:.34 2:F4:.62 3:E4:.42',
31:'0:D4:.66 1:F4:.34 1.5:A4:.34 2:G4:.62 3:F4:.42',
32:'0:G4:.66 1:B4:.34 1.5:A4:.34 2:G4:.62 3:D4:.42',
33:'0:E4:.66 1:G4:.34 1.5:A4:.34 2:G4:.62 3:E4:.42',
34:'0:C4:.66 1:E4:.34 1.5:A4:.34 2:G4:.62 3:E4:.42',
35:'0:F4:.66 1:A4:.34 1.5:G4:.34 2:F4:.62 3:C4:.42',
36:'0:D4:.66 1:F4:.34 1.5:G4:.34 2:A4:.62 3:B4:.42',
37:'0:G4:.66 1:E4:.34 1.5:D4:.34 2:C4:.62 3:E4:.42',
38:'0:A4:.66 1:G4:.34 1.5:E4:.34 2:C4:.62 3:E4:.42',
39:'0:F#4:.66 1:A4:.34 1.5:F#4:.34 2:D#4:.62 3:F#4:.42',
40:'0:E4:1.20 2:G4:.38 2.5:E4:.68',
41:'.5:C4:.34 1:E4:.34 1.5:A4:.66 2.5:G4:.34 3:E4:.44',
42:'0:D4:.66 1:F#4:.34 1.5:A4:.66 2.5:F#4:.34 3:E4:.42',
43:'.5:D4:.34 1:G4:.34 1.5:B4:.66 2.5:A4:.34 3:G4:.44',
44:'0:E4:.66 1:G4:.34 1.5:A4:.34 2:G4:.66 3:E4:.38',
45:'.5:A4:.62 1.5:G4:.34 2:E4:.62 3:C4:.40',
46:'0:C4:.62 1:F#4:.34 1.5:A4:.62 2.5:F#4:.34 3:E4:.40',
47:'.5:D#4:.34 1:F#4:.34 1.5:A4:.66 2.5:B4:.34 3:A4:.40',
48:'0:F#4:.64 1:D#4:.64 2.5:B4:.45',
49:'.5:E4:.32 1:G4:.32 1.5:A4:.68 2.5:G4:.32 3:E4:.56',
50:'0:G4:.68 1:E4:.32 1.5:D4:.32 2:C4:.68 3:E4:.42',
51:'.5:F#4:.32 1:A4:.32 1.5:F#4:.68 2.5:E4:.32 3:D4:.56',
52:'0:D#4:.68 1:F#4:.32 1.5:A4:.32 2:F#4:.68 3:D#4:.40',
53:'.5:E4:.32 1:G4:.32 1.5:B4:.70 2.5:A4:.32 3:G4:.55',
54:'0:A4:.68 1:G4:.32 1.5:E4:.32 2:C4:.68 3:E4:.42',
55:'0:G4:.65 1:B4:.34 1.5:A4:.34 2:G4:.62 3:D4:.42',
56:'.5:F#4:.34 1:A4:.34 1.5:F#4:.68 2.5:E4:.34 3:D4:.54',
57:'0:G4:.60 1:E4:.32 1.5:D4:.32 2:C4:.65 3:D4:.38',
58:'.5:E4:.32 1:A4:.68 2:G4:.32 2.5:E4:.64',
59:'0:F#4:.62 1.5:D#4:.34 2:F#4:.34 2.5:A4:.65',
60:'0:G4:.62 1:E4:1.05 3:E4:.35',
61:'0:G4:.68 1:E4:.36 2:C4:.70 3:E4:.38',
62:'.5:D4:.36 1:G4:.68 2:B4:.68 3:G4:.38',
63:'0:A4:.68 1:G4:.36 2:E4:.68 3:C4:.38',
64:'.5:D#4:.36 1:F#4:.68 2:A4:.68 3:F#4:.38',
65:'0:G4:.68 1:E4:.68 2:G4:.68 3:B4:.38',
66:'0:A4:.68 1:G4:.36 2:E4:.68 3:C4:.38',
67:'.5:C4:.36 1:E4:.68 2:A4:.68 3:G4:.38',
68:'0:F#4:.68 1:D#4:.36 2:F#4:.68 3:A4:.38',
69:'.5:E4:.34 1:G4:.34 1.5:A4:.66 2.5:G4:.34 3:E4:.42',
70:'0:C4:.66 1:E4:.34 2:A4:.66 3:G4:.42',
71:'0:F#4:.66 1:D#4:.66 2:F#4:.66 3:D#4:.42',
72:'0:E4:1.60 2:E4:1.25',
}
# First substantive revision: make the middle a genuine change of syntax.
# The major-mode route contains unequal calls and whole-beat rests, not an
# unchanged dance with softer velocities. F-natural is intentional, never F#.
MID_V1 = {
29:'1:E4:.52 2:G4:.52 3:C4:.42',
30:'.5:F4:1.02 2.5:A4:.52',
31:'0:A4:.52 1.5:F4:.52 2.5:D4:.65',
32:'1:D4:.52 2:F4:.52 3:B4:.40',
33:'.5:C4:.52 1.5:E4:.52 3:G4:.42',
34:'0:A4:1.10 2.5:E4:.52',
35:'.5:F4:.52 1.5:A4:.52 2.5:G4:.42',
36:'0:F4:.52 1:D4:.52 2.5:B4:.72',
37:'1:G4:.52 2:E4:.52 3:C4:.42',
38:'.5:C4:.52 1.5:E4:.52 2.5:A4:.65',
39:'0:A4:.52 1:F#4:.52 2:D#4:.82',
40:'.5:E4:1.25 2.5:G4:.42',
}
# Second substantive revision: earned arrival instead of literal A reprise.
# Rhythm of the opening remains identifiable, but the top, bass placement,
# phrase lengths, harmonic resolution and final answer change.
RETURN_V2 = {
49:'.5:E4:.32 1:G4:.32 1.5:A4:.68 2.5:G4:.32 3:E4:.52',
50:'0:G4:.62 1:E4:.32 1.5:C4:.62 2.5:D4:.32 3:E4:.42',
51:'.5:F#4:.32 1:A4:.32 1.5:B4:.62 2.5:A4:.32 3:F#4:.50',
52:'0:A4:.60 1:F#4:.32 1.5:D#4:.32 2:B4:.72',
53:'0:B4:.58 1:G4:.32 1.5:E4:.62 2.5:G4:.32 3:A4:.42',
54:'.5:A4:.32 1:G4:.32 1.5:E4:.62 2.5:C4:.32 3:E4:.50',
55:'0:D4:.62 1:G4:.32 1.5:B4:.62 2.5:A4:.32 3:G4:.42',
56:'.5:A4:.32 1:F#4:.32 1.5:E4:.62 2.5:D4:.62',
57:'0:E4:.62 1:G4:.32 1.5:A4:.32 2:G4:.62 3:E4:.42',
58:'.5:C4:.32 1:E4:.32 1.5:A4:.62 2.5:G4:.32 3:E4:.48',
59:'0:F#4:.62 1:A4:.32 1.5:B4:.32 2:A4:.62 3:D#4:.42',
60:'.5:E4:.62 1.5:G4:.32 2:E4:.86',
61:'1:E4:.48 2:G4:.48 3:A4:.42',
62:'.5:B4:.80 2:G4:.54 3:D4:.42',
63:'0:C4:.52 1:E4:.52 2.5:A4:.74',
64:'.5:A4:.42 1.5:F#4:.42 2.5:D#4:.70',
65:'0:E4:.34 .5:G4:.34 1:A4:.58 2:G4:.34 2.5:E4:.74',
66:'.5:G4:.52 1.5:E4:.52 2.5:C4:.62',
67:'0:C4:.52 1:E4:.52 2:A4:.70',
68:'.5:F#4:.52 1.5:A4:.52 2.5:D#4:.62',
69:'.5:E4:.34 1:G4:.34 1.5:A4:.62 2.5:G4:.34 3:E4:.40',
70:'0:G4:.56 1:E4:.56 2:C4:.80',
71:'.5:F#4:.44 1.5:A4:.44 2.5:D#4:.70',
72:'0:G4:.42 1:E4:.80 2.5:E4:.95',
}
CHORDS = {
'Em':([52,55,59],40,47), 'C6':([48,52,55,57],36,43),
'Am':([45,48,52],45,40), 'B7':([47,51,54,57],47,42),
'D':([50,54,57],38,45), 'G':([43,47,50],43,38),
'D/F#':([42,45,50],42,38), 'Em/G':([43,47,52],43,40),
'Cmaj7':([48,52,55,59],36,43), 'Fmaj7':([41,45,48,52],41,36),
'Dm7':([50,53,57,60],38,45), 'G7':([43,47,50,53],43,38),
'Am7':([45,48,52,55],45,40), 'F#dim':([42,45,48],42,45),
}
CHORD_LIST = '''Em C6 Am B7
Em C6 D B7 Em Am B7 Em
G D/F# Em B7 C6 Am B7 Em
Em G C6 D Am Em/G B7 B7
Cmaj7 Fmaj7 Dm7 G7 C6 Am7 Fmaj7 G7 Cmaj7 Am B7 Em
Am D G C6 Am F#dim B7 B7
Em C6 D B7 Em Am G D/F# C6 Am B7 Em
C6 G Am B7 Em C6 Am B7
C6 Am B7 Em'''.split()
assert len(CHORD_LIST)==72
SECTIONS = [
(1,4,'A0 广场尚未开门',96,'主题轮廓分散出现；大提琴拨弦给出地面上的两步，不模仿鸟鸣。'),
(5,12,'A1 第一次出发',104,'四小节问句与四小节答句；单簧管领旋律，大提琴落根音和五度。'),
(13,20,'A2 翅膀记得的路',104,'转向G大调的上行答案，随后收回E小调；低音跟随同一和声。'),
(21,28,'B 石阶的绕行',108,'重音偏移到弱拍，旋律短句之间留出落脚处；低音不另唱。'),
(29,40,'C 留出另一条路',88,'C大调区域及F自然音；短问句、长空隙、稀疏拨弦仍保留四拍感。'),
(41,48,'D 看见共同的水面',100,'和声由Am经D、G向B7汇聚；句子逐渐接长，预备主主题归来。'),
(49,60,'A3 各自的步子',108,'主题归来后向高点续写，并用不同起拍联结三组四小节，不是原句复印。'),
(61,68,'E 等最后一只',100,'中段留白进入主部和声；旋律不再催促，低音在句尾撤出。'),
(69,72,'尾声 同一束光',96,'主题缩为四小节回答；主和弦低音与最终E音错开到达，留下自然衰减。')]

def sec(bar): return next(x for x in SECTIONS if x[0]<=bar<=x[1])
def bar_tempo(bar, version):
    t=sec(bar)[3]
    if bar>=69: t={69:96,70:88,71:80,72:72}[bar]
    # v2 lets the final invitation breathe, without changing its 4/4 meter.
    if version==2 and bar in (63,64,67,68): t=96
    return t

def cello_plan(bar,version):
    """Manual phrase-sensitive bass anchors, not arpeggios or an ostinato track.
    r/f are chord root/bass and an occasional supporting fifth; no scale runs.
    Durations are note gates; existing pizzicato samples must decay naturally.
    """
    if bar<=4:
        return [(0,'r',.40),(2,'f',.34)] if bar!=4 else [(0,'r',.48),(2.5,'f',.30)]
    if 29<=bar<=40 and version>=1:
        return {
          29:[(0,'r',.50),(2.5,'f',.32)],30:[(0,'r',.55),(3,'r',.30)],
          31:[(.75,'r',.34),(2,'f',.36)],32:[(0,'r',.48),(2.5,'f',.32)],
          33:[(0,'r',.48),(2,'f',.36)],34:[(1.5,'r',.45),(3.25,'f',.28)],
          35:[(0,'r',.50),(2,'f',.34)],36:[(.75,'r',.36),(2,'r',.40)],
          37:[(0,'r',.48),(2.5,'f',.34)],38:[(0,'r',.48),(2,'f',.36)],
          39:[(.75,'r',.34),(3,'r',.35)],40:[(0,'r',.50),(2,'f',.34)]}[bar]
    if version>=2 and 49<=bar<=60:
        return {
          49:[(0,'r',.42),(2,'f',.35)],50:[(.5,'r',.34),(2,'r',.40)],
          51:[(0,'r',.40),(2.25,'f',.32),(3.5,'r',.25)],52:[(.5,'r',.36),(2.75,'r',.35)],
          53:[(.5,'r',.36),(2,'f',.35)],54:[(0,'r',.40),(2,'r',.36),(3.5,'f',.24)],
          55:[(.5,'r',.34),(2,'f',.35)],56:[(0,'r',.42),(2.5,'r',.32)],
          57:[(.5,'r',.34),(2,'f',.36)],58:[(0,'r',.42),(2,'f',.35)],
          59:[(.5,'r',.34),(2.75,'r',.38)],60:[(0,'r',.45),(3,'r',.35)]}[bar]
    if version>=2 and bar>=61:
        return {
          61:[(0,'r',.44),(2.5,'f',.32)],62:[(0,'r',.44),(2,'r',.36)],
          63:[(.5,'r',.38),(2,'f',.34)],64:[(0,'r',.42),(2,'r',.35)],
          65:[(.5,'r',.34),(2,'f',.35)],66:[(0,'r',.44),(2,'r',.36)],
          67:[(.5,'r',.38),(2.75,'f',.32)],68:[(0,'r',.44),(2,'r',.35)],
          69:[(0,'r',.40),(2,'f',.34)],70:[(.5,'r',.40),(2.75,'r',.34)],
          71:[(0,'r',.44),(2,'r',.34)],72:[(.5,'r',.50),(2,'r',.60)]}[bar]
    if 21<=bar<=28:
        return [(0,'r',.40),(2.5,'f',.30)] if bar%2 else [(.5,'r',.34),(2,'r',.40)]
    # Phrase ends thin out; the bass does not fill every clarinet breath.
    if bar in (8,12,16,20,28,36,40,44,48,52,56,60,64,68,72):
        return [(0,'r',.44),(2,'r',.34)]
    if bar in (7,15,19,43,47,51,59,67):
        return [(0,'r',.40),(2,'f',.34),(3.5,'r',.24)]
    if bar in (10,18,26,34,42,46,54,62,70):
        return [(.5,'r',.34),(2,'f',.34)]
    return [(0,'r',.40),(2,'f',.34)]

def build(version):
    melody=dict(BASE)
    if version>=1: melody.update(MID_V1)
    if version>=2: melody.update(RETURN_V2)
    score={'id':63,'title':'Copper Birds at Dawn','title_zh':'黎明时的铜鸟','bars':[],'events':[],'pedals':[],'total_beats':288,'tail_seconds':4}
    for b in range(1,73):
        start=(b-1)*4; section=sec(b); chord=CHORD_LIST[b-1]; h,r,f=CHORDS[chord]
        role=section[4]
        if version==0 and 29<=b<=40: role='初稿：C大调区域整齐四小节乐句，低音保持双步。'
        if version<2 and 49<=b<=60: role='初稿/第一稿：主部近似原样返回，待续写。'
        score['bars'].append({'bar':b,'start':start,'beats':4,'bpm':bar_tempo(b,version),'section':section[2],'meter_numerator':4,'meter_denominator':4,'harmony_name':chord,'harmony':h,'role_plan':role,'lead_instrument':'clarinet'})
        # One mf dynamic family throughout. Phrase shape does not cross layers.
        basevel=68 if b<=4 else 76 if b<=20 else 79 if b<=28 else 65 if b<=40 else 76 if b<=48 else 83 if b<=60 else 69 if b<=68 else 64
        line=notes(melody[b])
        for i,(off,p,d) in enumerate(line):
            shaping = 2 if i==0 else 3 if p==max(n[1] for n in line) else -3 if i==len(line)-1 else 0
            v=max(56,min(95,basevel+shaping))
            score['events'].append({'bar':b,'onset':start+off,'duration':d,'pitch':p,'velocity':v,'voice':'clarinet','instrument':'clarinet'})
        for i,(off,label,d) in enumerate(cello_plan(b,version)):
            v=64 if b<=4 else 70 if b<=28 else 59 if b<=40 else 69 if b<=48 else 74 if b<=60 else 62 if b<=68 else 58
            if i: v-=2
            score['events'].append({'bar':b,'onset':start+off,'duration':d,'pitch':r if label=='r' else f,'velocity':v,'voice':'cello_bass','instrument':'cello'})
    score['events'].sort(key=lambda e:(e['onset'],e['voice']))
    return score

def integrated_seconds(score,start,end):
    return sum(max(0,min(end,b['start']+b['beats'])-max(start,b['start']))*60/b['bpm'] for b in score['bars'])

def audit(score):
    errors=[]; ordered={}; stats={}
    for voice,instr,lo,hi in [('clarinet','clarinet',60,71),('cello_bass','cello',36,47)]:
        ev=sorted([e for e in score['events'] if e['voice']==voice],key=lambda e:e['onset']);ordered[voice]=ev
        for i,e in enumerate(ev):
            if e['instrument']!=instr: errors.append(f'{voice}: instrument mismatch')
            if not lo<=e['pitch']<=hi:errors.append(f'{voice}: range at bar {e["bar"]}')
            if not 56<=e['velocity']<=95:errors.append(f'{voice}: mf velocity boundary at bar {e["bar"]}')
            if not e['duration']>0: errors.append(f'{voice}: nonpositive duration')
            if not (e['bar']-1)*4<=e['onset']<e['bar']*4:errors.append(f'{voice}: wrong event bar')
            if e['onset']+e['duration']>e['bar']*4+1e-8:errors.append(f'{voice}: crosses bar')
            if i and ev[i-1]['onset']+ev[i-1]['duration']>e['onset']-1e-8:errors.append(f'{voice}: overlap at bar {e["bar"]}')
            dur=integrated_seconds(score,e['onset'],e['onset']+e['duration'])
            if voice=='clarinet' and dur>1.5+1e-8:errors.append(f'clarinet exceeds 1.5 seconds at bar {e["bar"]}: {dur}')
        gaps=[integrated_seconds(score,a['onset']+a['duration'],b['onset']) for a,b in zip(ev,ev[1:])]
        stats[voice]={'events':len(ev),'pitch_range':[min(e['pitch'] for e in ev),max(e['pitch'] for e in ev)],'velocity_range':[min(e['velocity'] for e in ev),max(e['velocity'] for e in ev)],'maximum_note_seconds':round(max(integrated_seconds(score,e['onset'],e['onset']+e['duration']) for e in ev),6),'minimum_release_gap_seconds':round(min(gaps),6),'overlaps':0 if not any(voice in er and 'overlap' in er for er in errors) else 'ERROR'}
    # Breath test: every four-bar block must contain at least one actual
    # clarinet silence >=0.30 seconds, including its closing breath.
    breaths=[]; ev=ordered['clarinet']
    for first in range(1,73,4):
        left=(first-1)*4; right=(first+3)*4
        gaplist=[]
        for a,b in zip(ev,ev[1:]):
            ga=a['onset']+a['duration']; gb=b['onset']
            if left<=ga<right:gaplist.append(integrated_seconds(score,ga,min(gb,288)))
        if right==288:gaplist.append(integrated_seconds(score,ev[-1]['onset']+ev[-1]['duration'],288))
        largest=max(gaplist,default=0)
        if largest<.30: errors.append(f'No 0.30s breath in bars {first}-{first+3}')
        breaths.append({'bars':f'{first}-{first+3}','longest_actual_silence_seconds':round(largest,4)})
    # Harmony validation applies to every cello note, not ornamental lead tones.
    for e in ordered['cello_bass']:
        pcs={p%12 for p in score['bars'][e['bar']-1]['harmony']}
        if e['pitch']%12 not in pcs:errors.append(f'Nonchordal cello at {e["bar"]}')
    return {'ok':not errors,'errors':errors,'total_bars':72,'score_seconds':round(integrated_seconds(score,0,288),6),'with_tail_seconds':round(integrated_seconds(score,0,288)+4,6),'voice_checks':stats,'four_bar_breath_checks':breaths,'verification_scope':'Event-data inspection only. No audio rendered, played, or judged. Note statistics are technical constraints, not musical-quality evidence.'}

def change_bars(a,b):
    return [n for n in range(1,73) if [e for e in a['events'] if e['bar']==n]!=[e for e in b['events'] if e['bar']==n] or a['bars'][n-1]!=b['bars'][n-1]]

def write(name,obj): (ROOT/name).write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')

scores=[]; audits=[]
for v in range(3):
    s=build(v); a=audit(s)
    if not a['ok']: raise RuntimeError(a['errors'])
    write(f'score_v{v}.json',s);write(f'audit_v{v}.json',a);scores.append(s);audits.append(a)
write('revision_changes.json',{'v0_to_v1':{'changed_bars':change_bars(scores[0],scores[1]),'musical_change':'Recomposed bars29–40: unequal major-mode calls, longer structural rests, and cello placements responsive to those calls.'},'v1_to_v2':{'changed_bars':change_bars(scores[1],scores[2]),'musical_change':'Recomposed return and coda49–72: new summit/cadential continuation, interleaved bass entrances, middle-section breathing retained at the end, phrase-level tempo easing.'}})
write('form_design.json',{'id':63,'title_zh':'黎明时的铜鸟','tonal_center':'E minor; contrasting C-major region, with F-natural in bars30–36','meter':'4/4 throughout','source_policy':'Original pitches/rhythms authored in compose.py; existing sampled clarinet and existing single-mf-layer pizzicato cello only','sections':[{'bars':f'{a}-{b}','section':c,'main_bpm':t,'function':d} for a,b,c,t,d in SECTIONS],'final_version':'score_v2.json','predicted_total_seconds':audits[2]['with_tail_seconds'],'audio_status':'NOT RENDERED / NOT AUDITIONED'})
print(json.dumps({'scores':['score_v0.json','score_v1.json','score_v2.json'],'final_audit':audits[2],'revision_bars':json.loads((ROOT/'revision_changes.json').read_text())},ensure_ascii=False,indent=2))
