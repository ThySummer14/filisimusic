"""Original12/8 piano narrative, long four-pulse bars and folded melodic intervals."""
import pathlib,json,copy
P=pathlib.Path(__file__).parent;(P/'revisions').mkdir(exist_ok=True)
A=[[(66,.5),(73,.5),(81,1),(80,.5),(78,.5),(76,1),(73,1),(74,.5),(73,.5)],[(78,.5),(76,.5),(74,1),(69,.5),(71,.5),(78,1),(76,1),(74,1)],[(73,1),(76,.5),(81,.5),(80,1),(78,1),(76,.5),(73,.5),(69,1)],[(80,1.5),(78,.5),(76,1),(73,1),(71,1),(-1,1)],[(81,1),(80,.5),(78,.5),(76,1),(73,1),(66,1.5),(-1,.5)],[(74,.5),(78,.5),(81,1),(83,1),(81,.5),(78,.5),(76,1),(74,1)],[(78,1),(74,.5),(71,.5),(73,1),(74,1),(78,1),(76,1)],[(77,.5),(80,.5),(83,1),(80,1),(77,1),(73,1.5),(-1,.5)]]
F=[[(78,.5),(80,.5),(81,1),(80,.5),(78,.5),(76,1),(73,1),(74,.5),(73,.5)],[(74,1),(76,.5),(78,.5),(81,1),(78,1),(76,1),(74,1)],[(76,1),(78,.5),(81,.5),(83,1),(81,1),(80,.5),(78,.5),(76,1)],[(80,1),(78,.5),(76,.5),(73,1),(71,1),(68,1),(-1,1)],[(78,1),(76,.5),(73,.5),(69,1),(73,1),(78,1.5),(-1,.5)],[(81,.5),(83,.5),(86,1),(83,1),(81,.5),(78,.5),(76,1),(74,1)],[(83,1),(81,.5),(78,.5),(74,1),(71,1),(73,1),(74,1)],[(80,.5),(77,.5),(73,1),(68,1),(73,1),(77,1.5),(-1,.5)]]
R=[[(73,1),(69,1),(66,.5),(69,.5),(73,1),(76,1),(78,1)],[(74,1.5),(73,.5),(71,1),(69,1),(66,1),(-1,1)],[(69,.5),(73,.5),(76,1),(81,1.5),(80,.5),(78,1),(76,1)],[(76,1),(73,1),(71,.5),(68,.5),(73,1),(76,1),(80,1)],[(81,1.5),(78,.5),(76,1),(73,1),(69,1),(-1,1)],[(78,1),(81,.5),(83,.5),(86,1),(83,1),(81,1),(78,1)],[(74,.5),(73,.5),(71,1),(66,1),(71,1),(74,1),(78,1)],[(77,1),(80,.5),(83,.5),(85,1),(83,1),(80,1),(77,.5),(-1,.5)]]
H={'Fsm':[42,54,57,61],'D':[38,54,57,62],'AE':[40,52,57,61],'E':[40,56,59,64],'Bm':[47,54,59,62],'Cs7':[49,56,59,65],'Fs':[42,54,58,61],'Dsm':[39,54,58,63],'B':[47,54,59,63],'Cs':[49,56,61,65],'Gsm':[44,56,59,63]};home=['Fsm','D','AE','E','Fsm','D','Bm','Cs7'];bright=['Fs','Dsm','B','Cs','Fs','B','Gsm','Cs7']
sections=[('Rejected charts at the window',4,96,'intro'),('The first boat leaves',8,102,'boat'),('Folds between distant stars',10,106,'fold'),('People wait beside the river',8,98,'river'),('Perfect boats do not move',6,94,'still'),('Two uneven gunwales',8,104,'uneven'),('A bend across the sky',8,102,'sky'),('Following downstream',4,90,'coda')]
notes=[];bars=[];pedals=[];beat=0;barno=0
for sec,count,tempo,kind in sections:
 for j in range(count):
  barno+=1;k=j%8
  if kind=='intro':line=copy.deepcopy(R[k]);prog=home
  elif kind=='boat':line=copy.deepcopy(A[k]);prog=home
  elif kind=='fold':line=copy.deepcopy(F[k]);prog=home
  elif kind=='river':line=copy.deepcopy(R[k]);prog=home
  elif kind=='still':line=copy.deepcopy(A[k]);prog=home
  elif kind=='uneven':line=copy.deepcopy(F[k]);prog=home
  elif kind=='sky':line=[(n+(1 if n%12 in(2,4,9)else 0)if n>=0 else n,l)for n,l in A[k]];prog=bright
  else:
   line=copy.deepcopy([[(75,1),(73,1),(71,1),(70,1),(68,1),(66,1)],[(70,1),(73,1),(78,2),(77,1),(75,1)],[(77,1),(80,1),(85,1),(83,1),(80,1),(77,1)],[(78,1.5),(73,.5),(70,1),(66,2),(-1,1)]][j]);prog=['B','Fs','Cs7','Fs'];k=j
  assert abs(sum(l for n,l in line)-6)<1e-8,(kind,j)
  h=prog[k];ch=H[h];bpm=tempo
  if kind=='coda':bpm=[90,88,82,74][j]
  lv={'intro':61,'boat':71,'fold':80,'river':68,'still':63,'uneven':79,'sky':85,'coda':65}[kind]
  bars.append(dict(bar=barno,start=beat,beats=6,bpm=bpm,meter_numerator=12,meter_denominator=8,section=sec,harmony_name=h,harmony=ch,role_plan=kind))
  off=0
  for n,l in line:
   if n>=0:notes.append(dict(bar=barno,onset=beat+off,duration=l*.985,pitch=n,velocity=lv+(2 if off in(0,3)else 0),voice='melody'))
   off+=l
  # Four dotted-quarter pulses, two bass anchors, continuous inner arpeggio.
  for t,n in [(0,ch[0]),(3,ch[0]+12)]:notes.append(dict(bar=barno,onset=beat+t,duration=.32,pitch=n,velocity=lv-29,voice='bass'))
  pattern=[(.5,ch[1]),(1,ch[2]),(1.5,ch[3]),(2,ch[2]),(2.5,ch[1]),(3.5,ch[2]),(4,ch[3]),(4.5,ch[2]),(5,ch[1]),(5.5,ch[2])]
  for t,n in pattern:
   if kind=='still'and t not in(1.5,4.5):continue
   if kind=='coda'and j==3 and t>=3:continue
   notes.append(dict(bar=barno,onset=beat+t,duration=.43,pitch=n,velocity=lv-41+(3 if t in(1.5,4.5)else 0),voice='accompaniment'))
  for t,v in [(0,0),(.12,48),(2.91,0),(3.12,43),(5.86,0)]:pedals.append(dict(onset=beat+t,value=v))
  beat+=6
pedals=[e for e in pedals if e['onset']<beat-6]+[dict(onset=beat-6,value=0),dict(onset=beat-5.9,value=60),dict(onset=beat+2,value=0)]
d=dict(id=56,title='Paper Boats in the Observatory',title_zh='天文台里的纸船',stage='v0_original_compound_narrative',bars=bars,events=notes,pedals=pedals,total_beats=beat,tail_seconds=4.4,story_relationship='A wide-spaced melodic chart folds into close stepwise answers. Four compound pulses maintain a continuous river; rigid stillness contrasts with an uneven five-plus-three-bar sentence and a brighter sky return.')
(P/'revisions/score_v0.json').write_text(json.dumps(d,indent=2));(P/'score.json').write_text(json.dumps(d,indent=2));(P/'thematic_material.json').write_text(json.dumps(dict(A=A,F=F,R=R),indent=2));print(len(bars),'bars',sum(b['beats']*60/b['bpm']for b in bars)+4.4,'seconds')
