from pathlib import Path
import json
P=Path(__file__).parent;d=json.loads((P/'revisions/score_v2.json').read_text());b=d['bars'][-1];d['events']=[e for e in d['events'] if e['bar']!=b['bar']]
# A shared close, followed by the story's last late book: a deliberately soft afterthought.
for pitch,voice,vel in [(55,'bass',45),(59,'accompaniment',39),(62,'accompaniment',39),(67,'melody',65)]:
 d['events'].append(dict(bar=b['bar'],onset=b['start'],duration=2.35,pitch=pitch,velocity=vel,voice=voice))
for pitch,voice,vel in [(55,'bass',30),(59,'accompaniment',29),(62,'accompaniment',29),(67,'melody',43)]:
 d['events'].append(dict(bar=b['bar'],onset=b['start']+3.25,duration=.19,pitch=pitch,velocity=vel,voice=voice))
d['pedals']=[e for e in d['pedals'] if e['onset']<b['start']]+[dict(onset=b['start'],value=0)];d['events'].sort(key=lambda e:(e['onset'],e['pitch']));d['stage']='v3_shared_picardy_close_and_late_book_afterthought'
for f in ['score.json','revisions/score_v3.json']:(P/f).write_text(json.dumps(d,indent=2))
(P/'revisions/pass3.json').write_text(json.dumps({'round':3,'kind':'substantive_ending_revision','changes':['Replace generic final accompaniment pulses with one compact sharedG-major close (left55/59/62, right67), giving the final third an explicit common onset.','After its release, add a very soft short chord at beat3.25: the one last book entering the repaired return slot. Keep pedal off so this late afterthought stays distinct.'],'human_listening_review':False},indent=2))
