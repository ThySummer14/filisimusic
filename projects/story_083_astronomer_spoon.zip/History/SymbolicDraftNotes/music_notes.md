# Work 083 · The Astronomer’s Wooden Spoon / 天文学家的木勺

Original chamber divertimento for natural piano and concert-pitch clarinet. This delivery is symbolic source only. No recording has been loaded, auditioned, processed or rendered; no new instrument has been obtained. All three complete versions are composed specifically for this work.

## Final form and narrative

The final score contains 80 bars of 7/8. Every bar occupies 3.5 absolute quarter-note beats. Tempo indications refer to quarter notes. Score duration is 199.406318 seconds; the specified six-second tail gives 205.406318 seconds, or 3:25.406.

| Bars | Quarter tempo | Grouping | Dramatic and musical purpose |
|---|---:|---|---|
| 1–16, A | 84 | 2+2+3 | E-major calibration theme: E–G♯–A–G♯ curls around the eventual E–G♯–F♯ answer. A# neighbors B, and the piano's polished inventory interrupts a much longer clarinet sentence. A-major to A-minor changes the color before the screw jams. |
| 17–28, B | 94 | 2+3+2 | Dominants, diminished harmony and broken piano figures bring the failed apparatus into focus. The clarinet takes over after the keyboard mechanism stalls. Two genuine ff attacks, G♯4 then B4 in bar 23, are the astronomer's two calls, not a general crescendo or an invented sample layer. |
| 29–44, C | 78 | 3+2+2 | Cmaj7–Am6–F# half-diminished gives the kitchen object a separate, warm but puzzled space. The broad E–G–A–G sentence is a new theme. Piano presents it in its middle register at 33–34; the clarinet answers. G becomes G♯ at 37 and brings the spoon back toward E. |
| 45–56, D | 88 | 2+3+2 | C# minor and the descending chromatic piano line follow the moving crescent. The Dmaj7/F# half-diminished detour delays the dominant return. The clarinet reaches B4 but must come down through A#–F#–E–D#; the eclipse's maximum is a measured arch, not a sustained fortissimo. |
| 57–72, R | 88 | 2+2+3, then 3+2+2 | Recognizable return of the opening, now without the repeated chromatic B ornament. Piano retells the inventory in 61–62 and yields in 63. The spoon theme's longer groupings infiltrate the return. Bars 71–72 finally say E–G♯–F♯ without adding an explanatory flourish. |
| 73–80, K | 74 | 3+2+2 | The cook takes the spoon back. Three-note clarinet statement in 73–75; three-note piano answer in 76; one distributed statement in 77–79. The last bar is quiet E-add9 harmonic punctuation. Its support does not restart a tune or supply a fourth answer-note. |

The final K section has five clarinet notes across eight bars, compared with nineteen or more in each earlier section. Its musical emptiness is earned through thinning of a specific theme, with continuing harmonic punctuation. The three-note answer is E4–G♯4–F♯4. In the final distributed statement the piano plays E4 at bar 77, the clarinet G♯4 at 78 and F♯4 at 79. E's ninth remains in the listener's memory when the last chord is struck; the final chord itself is B3–E4–G♯4 over E2, deliberately avoiding another melody attack.

## Cooperation and foreground

Each bar names one lead instrument. The final count is 56 clarinet bars and 24 piano bars. Piano foreground occurs at 5–7, 13–14, 17–18, 25–27, 33–34, 41–43, 49–50, 61–62, 69–70, 76–77 and 80. These are composed melodies and responses, with different lengths and registers. During those bars the clarinet waits; at the handoff it resumes the same harmonic sentence. The closing chord in bar 80 is the sole foreground punctuation rather than a new tune.

The piano's bass, quiet two-note harmony and late group pulse articulate the same changing 7/8 groupings the melody traverses. The bass line follows the written harmony, including its inversions and borrowed chords. The late left-hand tones are selected from that harmony, not mechanically parallel fifths. No four-bar unit is an identical event sequence to another. Thematic return is intentional and transformed; the score does not tile a short audio or MIDI pattern.

## Clarinet performance contract

- Concert pitches C4–B4, MIDI 60–71; do not transpose the symbolic source when mapping recordings.
- Only the owner's existing genuine Iowa pp, mf and ff recordings. Final velocity ranges actually used are pp 46–50, mf 67–71 and ff 100–102. The ff layer appears on exactly two notes. Velocity within a layer may change gain; that does not create another recorded dynamic layer.
- Ordinary triggers, no sample pre-shift, no true-legato claim and no looping or artificial sustain. A connected musical sentence consists of distinct attacks. Written 0.13-beat inter-note releases make tonguing available; longer rests mark the sentence breath.
- Principal clarinet sentences are roughly 8.3–10 seconds. Short responses at piano handoffs are deliberately shorter. The minimum nominal note gate is over 0.33 seconds, and the shortest nominal breath between labeled sentences is over 0.65 seconds. Exact values are in audit_v2.json. The longest gate is about 1.66 seconds and must still be checked against each actual sample's natural release.
- Actual samples and sounding overlap are not certified here. The owner must validate range coverage, recorded-layer selection, attack/release behavior, sufficiency of breaths and audible balance. A nominal MIDI rest is not proof that a recording has finished sounding.

## Piano performance contract

Use the already approved natural piano. Foreground figures are clear and light, never a glossy synthetic overlay. Clarinet pp gets especially quiet piano support. Chords contain at most three simultaneously held right-hand notes, within nine semitones in v2; the left hand is monophonic. There are no same-key gate overlaps across the two hands.

The widest right-hand relocation is between a low supporting dyad and a high B5 foreground entry. It occurs between figures, with over a second available after release. The audit checks released travel time, not merely onset spacing: larger-than-octave moves need at least 0.18 seconds; larger-than-nineteen-semitone moves need at least 0.50 seconds. Held spans stay within twelve semitones. These symbolic checks assess basic feasibility; they cannot certify recorded musical balance.

Piano CC64 uses only 0, 42 and 76. Every harmony is cleared before the next bar; 76 appears sparingly in the spoon scene and coda. The final release is at beat 279.8, before the 280-beat notated boundary. Retain six additional seconds for natural decay. Do not add hidden pedal, quantization, phrase looping or attack offsets.

## Reproduction and evidence

Run `python generate_score.py` in this folder. It uses only Python's standard library and writes full v0, v1, v2 scores, audits, machine-readable exact musical differences, unified score patches, hashes and a delivery manifest. It has no audio, network, rendering or installation step. The scores and audit outputs are deterministic; file hashes must agree across repeat runs. The authored story and notes are included in the manifest. See revisions.md for the two substantive compositional revisions.
