from pathlib import Path
import json,copy
P=Path(__file__).parent;d=json.loads((P/'revisions/score_v0.json').read_text())
def rewrite(bar,line,h=None,ch=None):
 b=d['bars'][bar-1];d['events']=[e for e in d['events'] if not(e['bar']==bar and (e['voice']=='melody' or h))]
 off=0
 for n,l in line:
  if n>=0:d['events'].append(dict(bar=bar,onset=b['start']+off,duration=l*.94,pitch=n,velocity=78,voice='melody'))
  off+=l
 assert off==3
 if h:
  b.update(harmony_name=h,harmony=ch)
  d['events'].append(dict(bar=bar,onset=b['start'],duration=.48,pitch=ch[0],velocity=53,voice='bass'))
  for t in [1,2]:
   for n in ch[1:]:d['events'].append(dict(bar=bar,onset=b['start']+t,duration=.43,pitch=n,velocity=42,voice='accompaniment'))
Q=[[(65,1),(69,.5),(74,.5),(72,1)],[(71,.5),(69,.5),(67,1),(65,.5),(64,.5)],[(69,1),(72,.5),(77,.5),(76,1)],[(71,1),(68,.5),(64,.5),(61,.5),(-1,.5)],[(62,.5),(65,.5),(69,1),(74,1)],[(77,1),(74,.5),(70,.5),(69,1)],[(73,.5),(76,.5),(79,1),(76,.5),(73,.5)],[(74,1.5),(69,.5),(65,.5),(-1,.5)]]
for j,line in enumerate(Q):rewrite(25+j,line)
for n,line,h,ch in [(57,[(74,.5),(77,.5),(82,1),(81,.5),(77,.5)],'Bb',[46,53,58]),(58,[(79,1),(76,.5),(72,.5),(76,1)],'C',[36,52,55]),(59,[(73,.5),(76,.5),(79,1),(76,.5),(73,.5)],'A7',[45,55,61]),(60,[(74,1),(69,.5),(65,.5),(69,.5),(-1,.5)],'Dm',[38,53,57])]:rewrite(n,line,h,ch)
S=[[(69,.5),(72,.5),(77,1),(76,.5),(74,.5)],[(77,1),(74,.5),(70,.5),(69,1)],[(72,1),(76,.5),(79,.5),(77,1)],[(77,.5),(74,.5),(70,1),(65,.5),(-1,.5)],[(72,.5),(77,.5),(81,1),(79,.5),(77,.5)],[(76,1),(79,.5),(76,.5),(72,1)],[(74,.5),(76,.5),(79,1),(76,.5),(-1,.5)],[(77,1.5),(72,.5),(69,1)],[(70,.5),(74,.5),(77,1),(74,.5),(70,.5)],[(71,1),(74,.5),(79,.5),(77,.5),(74,.5)],[(76,.5),(73,.5),(69,1),(71,.5),(73,.5)],[(74,2),(-1,1)]]
for j,line in enumerate(S):rewrite(73+j,line)
d['stage']='v1_new_cold_continuation_oven_bridge_and_shared_bread_answer';(P/'revisions/score_v1.json').write_text(json.dumps(d,indent=2));(P/'revisions/pass1.json').write_text(json.dumps({'round':1,'kind':'substantive_composition_revision','changes':['Replace the second cold8-bar stanza with a new rising question and altered closing descent, rather than literal repetition.','Write a four-bar oven climax overBb→C→A7→Dm to join the newF-major sharing theme through a sharedDminor arrival.','Write an entirely new12-bar answer in the second sharing stanza, retaining common harmonic support and seven-plus-five breathing.']},indent=2))
# Articulation/phrasing revision: breath and low support react to the same melody.
arc=[-3,-1,1,0,3,2,-4,-2,0,2,1,-6]
removed=0
for b in d['bars']:
 kind=b['role_plan'];base={'intro':63,'knead':75,'cold':61,'flower':77,'oven':82,'share':79,'tomorrow':79,'coda':65}[kind];k=b['phrase_position'];climax=(kind=='oven'and b['bar']>=57)
 ending=any(e['bar']==b['bar'] and e['voice']=='melody' and e['onset']+e['duration']<b['start']+2.65 for e in d['events'])
 # Phrase endings are composer-specified, not inferred from every short note.
 close=(kind in ['knead','flower','share','tomorrow']and k in [6,11])or(kind=='cold'and k==7)or b['bar']in[60,104]
 for e in [x for x in d['events'] if x['bar']==b['bar']]:
  off=e['onset']-b['start']
  if e['voice']=='melody':
   e['velocity']=base+arc[k%12]+(3 if climax else 0)+(2 if off==0 else 0)
   e['duration']*=1.025 if kind in ['cold','share','tomorrow'] else .98
  elif e['voice']=='bass':e['velocity']=base-27+arc[k%12]//2;e['duration']=.40
  else:
   e['velocity']=base-35+arc[k%12]//2+(2 if off==1 else 0)
   e['duration']=.50 if kind in ['share','tomorrow'] else .35
   if close and off>=2:e['remove']=True;removed+=1
  if close and off>=1:e['velocity']-=3
 d['pedals']=[x for x in d['pedals'] if not(b['start']<=x['onset']<b['start']+3)]
 for off,val in [(0,0),(.12,37 if kind=='cold' else 48),(2.6 if close else 2.86,0)]:d['pedals'].append(dict(onset=b['start']+off,value=val))
d['events']=[e for e in d['events'] if not e.pop('remove',False)];last=d['bars'][-1]['start'];d['pedals']=[x for x in d['pedals'] if x['onset']<last]+[dict(onset=last,value=0),dict(onset=last+.1,value=55),dict(onset=d['total_beats']+1,value=0)];d['pedals'].sort(key=lambda x:x['onset']);d['events'].sort(key=lambda e:(e['onset'],e['pitch']));d['stage']='v2_shared_phrase_arcs_and_support_release'
(P/'revisions/score_v2.json').write_text(json.dumps(d,indent=2));(P/'score.json').write_text(json.dumps(d,indent=2));(P/'revisions/pass2.json').write_text(json.dumps({'round':2,'kind':'substantive_performance_revision','changes':['Give12-bar phrases explicit question/answer dynamic arcs; cold stanza stays restrained and the oven has a localized peak.','Bass and middle dyads follow the same phrase arc, rather than independently accenting every bar.','Remove final accompaniment pulses at explicit melody breath points and lift half-pedal with the shared phrase; sharing/ending lines use longer connected touches.'],'removed_accompaniment_events':removed,'no_human_listening_claim':True},indent=2));print('v2',len(d['events']),'notes; removed',removed,'late support events')
