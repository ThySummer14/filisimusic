"""Original cumulative flight in unequal 7/8 and 9/8 sentences. Nominal score only."""
from copy import deepcopy
ID=145;TITLE='The Bees Cross the White Line';TITLE_ZH='蜂群越过那条白线'
INSTRUMENT_MAP={'piano':'piano','flute':'flute','cello':'arco'}
RENDERER_NOTES='Piano measured-line subject and flute swarm-curve subject are independent. Cello short-bow D3–B3 recalls the old hive entrance, with whole 0.50-second strokes and actual gaps >=0.20 seconds. Flute C5–B5 has >=0.14-second breathing gaps, retaining gate lengths. Fast inner subdivisions belong to piano only. Nominal starts are not sample compensated. Unrendered score.'
RENDERER_NOTES += ' The nominal rest layout now reserves at least the next pitch/layer sample delay plus 0.14 seconds before each flute/arco attack. The renderer must still apply recording compensation exactly once.'
H={'Em9':[40,55,59,62,66],'B7':[47,63,66,69],'Cmaj7':[36,52,55,59],'D9':[38,54,57,60,64],'Gmaj7':[43,59,62,66],'Am6':[45,60,64,66],'Fshalf':[42,57,60,64],'A7':[45,61,64,67],'C7':[36,52,55,58],'Fmaj7':[41,57,60,64],'Gsharpdim':[44,59,62,65],'Esus':[40,57,59,62],'Fsharp7':[42,58,61,64],'B7b9':[47,63,66,69,72],'Dsharpdim':[39,54,57,60],'Aminor':[45,60,64],'Eopen':[40,59,66],'Cminor':[36,51,55],'G7':[43,59,62,65]}
STREAMS={'A':('piano','right',60,96,'measured_white_line_subject'),'L':('piano','left',31,59,'cart_path_counterline'),'B':('flute','none',72,83,'swarm_curve_subject'),'C':('cello','none',50,59,'old_entrance_memory')}
R={
'a':[(0,.35),(.5,.35),(1,.35),(1.75,.35),(2.5,.65)],
'b':[(.25,.35),(.75,.35),(1.5,.5),(2.25,.35),(3,.35)],
'c':[(0,.2),(.25,.2),(.75,.2),(1,.2),(1.5,.2),(1.75,.2),(2.25,.2),(2.5,.2),(3,.2)],
'd':[(.25,.6),(1.25,.6),(2.5,.7)],
'e':[(0,.85),(1.25,.4),(2,.4),(2.75,.5)],
'f':[(.5,.35),(1,.35),(1.75,.35),(2.25,.35),(3,.35)],
'l':[(.25,.65),(1.5,.6),(2.75,.5)],
'm':[(0,.65),(1,.5),(2.25,.65)],
'n':[(.5,.5),(1.25,.6),(2.5,.65)],
'o':[(0,.8),(1.5,.65),(2.75,.5)],
'u':[(.25,.75),(1.75,.8)],
'v':[(.75,.8),(2.5,.7)],
'w':[(0,.85),(1.5,.85)],
'x':[(.5,.75),(2,.8)],
'q':[(1,.9)],
'b1':[(.2,'bow'),(1.7,'bow')],
'b2':[(.7,'bow'),(2.2,'bow')],
'b3':[(1.15,'bow')],
'rest':[]}
def section(name,count,bpm,meters,hs,A,L,B,C,ar,lr,br,cr,dyn,phrase):
 return dict(name=name,count=count,bpm=bpm,meters=meters,harmonies=hs.split(),pitches={k:v.split() for k,v in [('A',A),('L',L),('B',B),('C',C)]},rhythms={k:v.split() for k,v in [('A',ar),('L',lr),('B',br),('C',cr)]},dyn=dyn,phrase=phrase)
SECTIONS=[
section('The_mark_on_the_orchard_road',14,88,[3.5,3.5,4.5,3.5,2.5,4.5],
'Em9 Am6 B7 Em9 Cmaj7 D9 Gmaj7 Fshalf B7 Em9 A7 D9 B7 Em9',
'E5 B5 G5 F#5 A5 G5 E5 D5 F#5 A5 C6 B5 G5 F#5 D#5 E5 G5 B5 A5 F#5 E5 C5 D5 G5 B5 A5 F#5 D5 C5 E5 G5 F#5 D#5 E5',
'E3 G3 B3 A3 F#3 D3 B2 D#3 F#3 A3 G3 E3 C3 G3 E3 D3 F#3 A3 G3 D3 B2 F#3 A3 E3 G3',
'E5 G5 A5 F#5 B5 G5 E5 D5 G5 C5 E5 G5 B5 A5 F#5 D#5 E5 F#5 A5 G5',
'E3 G3 F#3 B3 A3 G3 E3 D3 F#3 A3 G3 E3 F#3',
'a e b d f a','l m n o','u v w q x','b3 b1 rest b2 b3',76,'5+9: the marked straight path is answered by a continuously curving flight'),
section('The_first_hive_turns_the_corner',21,98,[3.5,4.5,3.5,3.5,4.5,2.5,3.5],
'Gmaj7 D9 Em9 Cmaj7 Fshalf B7 Em9 A7 D9 Gmaj7 C7 Fmaj7 Cmaj7 Aminor Fsharp7 B7 Em9 Cminor G7 Cmaj7 B7',
'B5 G5 F#5 A5 C6 B5 G5 E5 F#5 A5 C6 D6 B5 G5 E5 C5 D5 F#5 A5 C6 B5 A5 F#5 D#5 E5 G5 B5 D6 C6 A5 F#5 D5 E5 G5 Bb5 A5 F5 E5 C5 D5 F#5 A#5 C#6 B5 G5 E5 Eb5 G5 Bb5 C6 B5 G5 E5 D#5',
'G3 D3 B2 D3 F#3 A3 G3 E3 B2 C3 E3 G3 F#3 A3 C4 B3 F#3 D#3 E3 G3 B3 A3 E3 C#3 D3 F#3 A3 G3 E3 C3 F3 A3 C4 B3 E3 F#3 A#3 B3 G3 E3 C3 Eb3 G3',
'G5 B5 A5 F#5 E5 G5 C5 E5 G5 A5 F#5 D#5 E5 G5 B5 A5 E5 C#5 D5 F#5 A5 G5 E5 C5 F5 A5 G5 E5 D5 F#5 Bb5 A5 F#5 D#5 E5 G5 Eb5 C5 D5 F#5',
'G3 B3 A3 F#3 E3 G3 A3 F#3 D3 E3 G3 B3 A3 E3 F#3 A3 G3 E3 D3 F#3 G3 B3 A3 F#3',
'b c f a c e d','n l m n o','v u x w q u','b1 b3 b2 rest b1 b3',92,'6+7+8: flight paths accumulate; every return lands further from the first mark'),
section('The_white_line_has_no_power_in_the_air',9,110,[4.5,3.5,2.5,3.5,4.5],
'Em9 Cmaj7 Fshalf B7b9 Em9 A7 Dsharpdim B7 Esus',
'E6 D6 B5 A5 G5 E5 C6 B5 G5 E5 F#5 A5 C6 B5 A5 F#5 D#5 C5 E5 G5 B5 A5 F#5 D#5 E5 A5 G5 F#5 E5',
'E3 B3 G3 F#3 C3 E3 G3 B3 A3 F#3 E3 C3 D#3 F#3 A3 B3 G3 E3 A3 E3 C#3 D#3 F#3 A3 B3',
'B5 A5 G5 E5 F#5 G5 B5 A5 F#5 D#5 C5 E5 G5 A5 F#5 D#5 E5 G5 A5 B5',
'B3 A3 G3 E3 F#3 A3 G3 E3 D3 F#3 A3 B3 A3 G3 E3',
'c f c b a','m n l','w u v x','b2 b1 b3 rest',106,'9-bar pivot, the short central section is the first peak rather than a repose'),
section('A_thousand_small_detours',24,104,[3.5,4.5,3.5,4.5,2.5,3.5,4.5],
'Em9 A7 D9 Gmaj7 Cmaj7 Fshalf B7 Em9 C7 Fmaj7 Gsharpdim Aminor D9 Gmaj7 Cminor G7 Cmaj7 Fsharp7 B7b9 Em9 A7 D9 Fshalf B7',
'G5 B5 E6 D6 B5 A5 F#5 E5 C#5 E5 G5 B5 A5 F#5 D5 G5 B5 D6 C6 A5 G5 E5 C5 E5 G5 B5 A5 F#5 D#5 E5 G5 B5 D6 C6 Bb5 G5 E5 F5 A5 C6 B5 G#5 F5 D5 E5 A5 C6 B5 G5 F#5 D5 G5 B5 A5 G5 Eb5 C5 E5 G5 B5 A5 F#5 D#5 E5 G5 A5 C6 B5 F#5 D#5',
'E3 G3 B3 A3 E3 C#3 D3 F#3 A3 G3 B3 D4 C4 G3 E3 F#3 A3 C4 B3 F#3 D#3 E3 G3 B3 C4 G3 E3 F3 A3 C4 B3 F3 D3 G#3 B3 D4 C4 A3 E3 C3 D3 F#3 A3 G3 B3 C4 Eb3 G3 B3 C4 F#3 A#3 B3 G3 E3 C#3',
'E5 G5 B5 A5 F#5 E5 C#5 D5 F#5 A5 G5 B5 A5 F#5 E5 C5 E5 G5 B5 A5 F#5 D#5 E5 G5 Bb5 A5 F5 E5 C5 E5 G#5 B5 A5 G5 E5 D5 F#5 A5 B5 G5 Eb5 C5 E5 G5 B5 A5 F#5 D#5 E5',
'E3 G3 B3 A3 F#3 E3 D3 F#3 A3 G3 B3 A3 G3 E3 F#3 A3 G3 E3 D3 F#3 B3 A3 G3 E3 F3 A3 G3 F3 D3 E3 G#3 B3 A3 G3 E3 D3 F#3 A3 B3 G3 E3',
'c a f c b e c d','n m l n o','u x v w q u x','b1 b2 b3 rest b1 b3 b2',109,'7+8+9: the largest continuous flight, with no repeated eight-bar block'),
section('Leave_one_empty_box_by_the_old_gate',16,92,[3.5,4.5,3.5,2.5,4.5,3.5],
'Em9 Cmaj7 Am6 D9 Gmaj7 Fshalf B7 Em9 Cminor G7 Cmaj7 A7 Dsharpdim B7b9 B7 Eopen',
'B5 G5 E5 F#5 A5 G5 E5 C5 G5 B5 A5 F#5 D5 F#5 A5 C6 B5 G5 F#5 E5 C5 D#5 F#5 A5 B5 G5 E5 G5 Eb5 C5 E5 G5 B5 A5 F#5 E5 C#5 D#5 F#5 A5 C6 B5 G5 F#5 E5 D#5 B4 E5 B5',
'E3 B3 G3 C3 E3 G3 A3 E3 C3 D3 F#3 A3 G3 B3 D4 C4 A3 F#3 E3 C3 B2 D#3 F#3 A3 G3 E3 C3 Eb3 G3 C4 B3 G3 E3 A3 E3 C#3 D#3 F#3 A3 B3 F#3 D#3 E3 B2',
'A5 G5 E5 F#5 B5 G5 E5 C5 D5 F#5 A5 G5 B5 A5 F#5 E5 D#5 F#5 A5 B5 G5 E5 Eb5 C5 D5 G5 B5 A5 E5 C#5 D#5 F#5 A5 E5 D#5 B5 E5',
'E3 G3 B3 A3 G3 E3 F#3 A3 G3 E3 D3 F#3 B3 A3 G3 E3 F#3 A3 G3 E3 D3 F#3 A3 B3 E3',
'e b f c d a','o n m l','x u q v w','b3 rest b1 b2 b3',91,'5+11: old and new entrances coexist; one line finishes while the other is still airborne')]
REV1=set(range(15,28))|set(range(37,45));REV2=set(range(51,66))|set(range(76,85))
H1={17:'A7',21:'C7',26:'Gsharpdim',39:'Dsharpdim',43:'B7b9'};H2={53:'Cminor',57:'Fsharp7',61:'C7',64:'Esus',78:'Gsharpdim',82:'Fshalf'}
def midi(s):return 12*(int(s[-1])+1)+{'C':0,'D':2,'E':4,'F':5,'G':7,'A':9,'B':11}[s[0]]+s[1:-1].count('#')-s[1:-1].count('b')
def fit(p,lo,hi):
 while p<lo:p+=12
 while p>hi:p-=12
 return max(lo,min(hi,p))

def woodwind_breathing(s):
 # Schedule real breathing space in seconds; preserve the existing gate length.
 # If a whole note cannot fit after a breath, omit that attack as a written rest.
 bars={b['bar']:b for b in s['bars']};elapsed={};t=0
 for b in s['bars']:elapsed[b['bar']]=t;t+=b['beats']*60/b['bpm']
 changes=[];removed=set()
 for inst in ('clarinet','flute'):
  last_end=-100
  for e in sorted((x for x in s['events'] if x['instrument']==inst),key=lambda x:x['onset']):
   b=bars[e['bar']];scale=60/b['bpm'];gate=e['duration']*scale
   start_sec=elapsed[e['bar']]+(e['onset']-b['start'])*scale
   if gate<.24:
    removed.add(id(e));changes.append(dict(bar=e['bar'],instrument=inst,action='write_rest_instead_of_truncated_short_attack',old_onset=e['onset'],duration_seconds=gate));continue
   need=max(0,last_end+.145-start_sec)
   if need>1e-7:
    new=e['onset']+need/scale
    if new+e['duration']>b['start']+b['beats']-.001:
     removed.add(id(e));changes.append(dict(bar=e['bar'],instrument=inst,action='write_rest_to_preserve_gate_and_breath',old_onset=e['onset'],duration_seconds=gate));continue
    changes.append(dict(bar=e['bar'],instrument=inst,action='delay_entire_note_for_breath',old_onset=e['onset'],new_onset=round(new,6),unchanged_duration=e['duration']))
    e['onset']=round(new,6);start_sec+=need
   last_end=start_sec+gate
 s['events']=[e for e in s['events'] if id(e) not in removed]
 s['woodwind_breathing_edits']=changes
 return s


# Verified sample metadata is used only by the symbolic checker.
SAMPLE_ONSET_DELAY_SECONDS={'flute': {('pp', 72): 0.08001201545335887, ('pp', 73): 0.0898971264827533, ('pp', 74): 0.07983842903523583, ('pp', 75): 0.1493489920217505, ('pp', 76): 0.20904149215655404, ('pp', 77): 0.14934985469784817, ('pp', 78): 0.11997712832295855, ('pp', 79): 0.16949112668248204, ('pp', 80): 0.09911726838782998, ('pp', 81): 0.07989101914124709, ('pp', 82): 0.08930452854032835, ('pp', 83): 0.07969237353709822, ('mf', 72): 0.060406515461735574, ('mf', 73): 0.07052517082997613, ('mf', 74): 0.11057205801867949, ('mf', 75): 0.10008089987737774, ('mf', 76): 0.10027069311440293, ('mf', 77): 0.09023997500344833, ('mf', 78): 0.11085664032736406, ('mf', 79): 0.08014430460612983, ('mf', 80): 0.09986319709244704, ('mf', 81): 0.08019292717345358, ('mf', 82): 0.05048814813842415, ('mf', 83): 0.050517319660623915}, 'cello': {('pp', 50): 0.10430518803605385, ('pp', 51): 0.10280911869175927, ('pp', 52): 0.10107662039108264, ('pp', 53): 0.10095623968778887, ('pp', 54): 0.1001470130812132, ('pp', 55): 0.09929602634988755, ('pp', 56): 0.10059127916195107, ('pp', 57): 0.10322761451400336, ('pp', 58): 0.10446920374237796, ('pp', 59): 0.10385513320742007, ('mf', 50): 0.10469473964787179, ('mf', 51): 0.10344570956415314, ('mf', 52): 0.10309932466853362, ('mf', 53): 0.10185307413906473, ('mf', 54): 0.10093829174587371, ('mf', 55): 0.1009149971460755, ('mf', 56): 0.10303760532574009, ('mf', 57): 0.10505530283181855, ('mf', 58): 0.10504705203028203, ('mf', 59): 0.10491690185566772}}
SAMPLE_DELAY_PROVENANCE={'flute': {'path': 'assets/iowa_flute_C5_B5/mapping_manifest.json', 'sha256': '716574ead3c7cb0da47d0a4f537e358b24f322f91546396c9a12969d9cb47e52', 'field': 'voiced_onset_delay_after_tuning_seconds'}, 'cello': {'path': 'assets/iowa_cello_arco_D3_B3/mapping_manifest.json', 'sha256': '70053fff468d349619e1e1c00c262fe75098d35f95be6fad7a9d8ef8a69f1d49', 'field': 'coarse_voiced_delay_after_tuning_seconds'}}
# Local beat positions chosen for clearer phrase rests, not recording offsets.
NOMINAL_REST_LAYOUT={0: {('flute', 6): {0: 0.375}, ('flute', 8): {0: 0.125}, ('flute', 44): {0: 0.5, 1: 1.875}, ('flute', 48): {0: 0.25, 1: 1.625}, ('flute', 55): {0: 0.25, 1: 1.625}, ('flute', 62): {0: 0.125}, ('flute', 78): {0: 0.125}}, 1: {('flute', 6): {0: 0.375}, ('flute', 8): {0: 0.125}, ('flute', 21): {0: 0.375}, ('flute', 28): {0: 0.375}, ('flute', 39): {0: 0.5, 1: 1.875}, ('flute', 44): {0: 0.375}, ('flute', 48): {0: 0.25, 1: 1.625}, ('flute', 55): {0: 0.25, 1: 1.625}, ('flute', 62): {0: 0.125}, ('flute', 78): {0: 0.125}}, 2: {('flute', 6): {0: 0.375}, ('flute', 8): {0: 0.125}, ('flute', 21): {0: 0.375}, ('flute', 28): {0: 0.375}, ('flute', 39): {0: 0.5, 1: 1.875}, ('flute', 44): {0: 0.375}, ('flute', 48): {0: 0.25, 1: 1.625}, ('flute', 55): {0: 0.25, 1: 1.625}, ('flute', 62): {0: 0.125}, ('flute', 78): {0: 0.125}}}

def nominal_rest_layout(s, level):
 # Authored rests on explicit fractional-beat positions. These are musical
 # nominal onsets, never sample-trigger advances. Retain all pitches, velocities,
 # gates and event identities within each line; only the listed attacks move.
 bars={b['bar']:b for b in s['bars']};changes=[]
 for (instrument,bn),positions in NOMINAL_REST_LAYOUT[level].items():
  ee=sorted((e for e in s['events'] if e['instrument']==instrument and e['bar']==bn),key=lambda e:e['onset'])
  for index,local_onset in positions.items():
   e=ee[index];old=e['onset'];new=round(bars[bn]['start']+local_onset,6)
   assert old<=new and new+e['duration']<=bars[bn]['start']+bars[bn]['beats']
   e['onset']=new
   changes.append(dict(bar=bn,instrument=instrument,line_note_index=index,old_nominal_onset=old,new_nominal_onset=new,unchanged_pitch=e['pitch'],unchanged_velocity=e['velocity'],unchanged_duration=e['duration'],reason='Written phrase rest or following attack repositioned; no sample compensation.'))
 s['nominal_rest_layout_edits']=changes
 return s

def harmonic_finish(s):
 # A melodic dissonance is retained only when the next note of that same
 # line resolves by one or two semitones to the actual current harmony.
 # Otherwise correct the local landing, never relabel a collision as style.
 from collections import defaultdict
 groups=defaultdict(list);bars={b['bar']:b for b in s['bars']}
 for e in s['events']:groups[(e['bar'],e['instrument'],e['voice'],e['hand'])].append(e)
 evidence=[]
 for (bn,inst,voice,hand),ee in groups.items():
  ee.sort(key=lambda x:x['onset']);pcs={p%12 for p in bars[bn]['harmony']}
  lo,hi=(60,96) if inst=='piano' and hand=='right' else (31,59) if inst=='piano' else (60,71) if inst=='clarinet' else (72,83) if inst=='flute' else (36,47) if s['instrument_map'].get('cello')=='pizz' else (50,59)
  for i in range(len(ee)-1,-1,-1):
   e=ee[i];p=e['pitch']
   if p%12 in pcs:continue
   nx=ee[i+1] if i+1<len(ee) else None
   resolved=nx and nx['pitch']%12 in pcs and 1<=abs(nx['pitch']-p)<=2
   if resolved:
    evidence.append(dict(bar=bn,instrument=inst,voice=voice,harmony=bars[bn]['harmony_name'],pitch=p,onset=e['onset'],resolution_pitch=nx['pitch'],resolution_onset=nx['onset'],classification='explicit stepwise appoggiatura, neighbor or passing tone; not a chord member'))
   else:
    cc=[q for q in range(lo,hi+1) if q%12 in pcs]
    e['pitch']=min(cc,key=lambda q:(abs(q-p),q))
 s['intentional_nonchord_tones']=sorted(evidence,key=lambda x:(x['bar'],x['onset'],x['instrument']))
 s['harmonic_review_scope']='Each remaining non-chord event resolves by step to a chord member in its own line within the same bar. This is symbolic voice-leading evidence, not an audio quality claim.'
 return s


def build(level):
 bars=[];events=[];pedals=[];start=0;n=0;phrase_map=[]
 for si,s in enumerate(SECTIONS):
  cur={k:0 for k in STREAMS};first=n+1
  for j in range(s['count']):
   n+=1;beats=s['meters'][j%len(s['meters'])];bpm=s['bpm'];h=s['harmonies'][j%len(s['harmonies'])];r1=level>=1 and n in REV1;r2=level>=2 and n in REV2
   if r1:h=H1.get(n,h)
   if r2:h=H2.get(n,h)
   bars.append(dict(bar=n,start=start,beats=beats,bpm=bpm,meter_numerator=int(beats*2),meter_denominator=8,section=s['name'],harmony_name=h,harmony=H[h]))
   for key,(inst,hand,lo,hi,voice) in STREAMS.items():
    cells=deepcopy(R[s['rhythms'][key][j%len(s['rhythms'][key])]])
    if r1 and key=='A':cells=deepcopy(R['b' if j%3 else 'e'])
    if r1 and key=='B':cells=[(.1,.8),(1.65,.8)]
    if r2 and key=='A':cells=deepcopy(R['c' if n<66 else 'f'])
    if r2 and key=='C':cells=[(.2,'bow'),(1.7,'bow')]
    if n in (37,69,83) and key=='B':cells=[(.25,.75),(1.75,.8)]
    if n in (15,50) and key=='C':cells=[(.2,'bow'),(1.7,'bow')]
    if beats==4.5 and key in ('A','L'):cells.append((3.75,.6 if key=='L' else .4))
    if si==4 and j>=14 and key=='C':cells=[]
    for k,(t,dur) in enumerate(cells):
     if t>=beats-.05:continue
     if dur=='bow':
      dur=.5*bpm/60
      # A whole stroke plus a written release margin; never trim the bow to pass.
      if beats-t<dur+.15*bpm/60:continue
     dur=min(dur,beats-t-.025);p=midi(s['pitches'][key][cur[key]%len(s['pitches'][key])]);cur[key]+=1
     if r1 and key=='A':p+=(-2 if k%3==0 else 1)
     if r1 and key=='B':p=[76,79,81,78,83,79,76,74,79,72,76,79][(cur[key]+j)%12]
     if r2 and key=='A':p+=(12 if n<66 and k%4==0 else -12 if n>=76 and k==0 else 0)
     if r2 and key=='C':p=[52,55,59,57,54,52,50,54,57,55][(cur[key]+j)%10]
     p=fit(p,lo,hi)
     if k==0 or k==len(cells)-1:
      cc=[q for q in range(lo,hi+1) if q%12 in {z%12 for z in H[h]}];p=min(cc,key=lambda q:(abs(q-p),q))
     if key=='C' and n==15:p=[57,55][min(k,1)]
     if key=='C' and n==50:p=[55,54][min(k,1)]
     if key=='B' and n==37:p=[78,79][min(k,1)]
     if key=='B' and n==69:p=[81,79][min(k,1)]
     if key=='B' and n==83:p=[76,75][min(k,1)]
     vv=s['dyn']+([3,-3,1,-1][k%4])-(17 if key=='L' else 13 if key=='C' else 4 if key=='B' else 0)
     if inst=='cello':vv=min(84,max(58,vv))
     events.append(dict(bar=n,onset=round(start+t,6),duration=round(dur,6),pitch=int(p),velocity=int(max(1,min(127,vv))),instrument=inst,voice=voice,hand=hand,articulation='short_bow' if inst=='cello' else 'detached'))
   pedals.append(dict(bar=n,onset=start,controller=64,value=0,instrument='piano'))
   if si==4 and j in (0,5,11):pedals.extend([dict(bar=n,onset=start+.08,controller=64,value=27,instrument='piano'),dict(bar=n,onset=start+.75,controller=64,value=0,instrument='piano')])
   start+=beats
  phrase_map.append(dict(first_bar=first,last_bar=n,design=s['phrase'],independent_subjects=['measured_white_line_subject','swarm_curve_subject'],cello_role='separate old entrance memory'))
 pedals.append(dict(bar=n,onset=start-.01,controller=64,value=0,instrument='piano'))
 return harmonic_finish(nominal_rest_layout(woodwind_breathing(dict(id=ID,title=TITLE,title_zh=TITLE_ZH,version=f'v{level}',bars=bars,events=events,pedals=pedals,total_beats=start,tail_seconds=5,instrument_map=INSTRUMENT_MAP,phrase_map=phrase_map)),level))
