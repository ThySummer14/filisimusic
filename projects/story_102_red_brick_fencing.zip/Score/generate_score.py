"""Original102: syncopated chamber dialogue. Literal new notes and distinct formal plan."""
from pathlib import Path
import json,copy,difflib,bisect
P=Path(__file__).resolve().parent
ROWS=[
('Cm G7 Cm Ab Fm Cm/G G7 Cm','''G3:1 C4:3 Eb4:1 D4:1 Ab3:2|G3:1 B3:1 C4:4 R:2|G3:1 C4:1 Eb4:2 D4:1 C4:1 G3:2|Ab3:3 C4:1 Eb4:2 D4:2|C5:1 F5:3 Eb5:1 C5:1 Ab4:2|G4:2 C5:1 Eb5:1 D5:2 G4:2|B4:1 D5:1 F5:2 Eb5:1 D5:1 B4:2|C5:3 G4:1 R:4'''),
('Cm Ab Fm G7 Cm Bb Ab G7','''G4:1 C5:3 Eb5:1 D5:1 Ab4:2|G4:1 B4:1 C5:4 R:2|C5:1 F5:3 Eb5:1 D5:1 C5:2|B4:1 D5:1 G5:3 F5:1 Eb5:1 D5:1|C5:2 Eb5:1 G5:1 F5:1 Eb5:1 D5:2|F5:3 D5:1 Bb4:2 C5:2|Eb5:1 C5:1 Ab4:2 C5:1 Eb5:1 F5:2|D5:1 B4:1 G4:2 B4:1 D5:1 G5:2'''),
('Cm Eb Ab Fm Ddim G7 Ab G7','''G5:1 Eb5:1 C5:3 D5:1 Eb5:2|G5:2 Bb5:1 G5:1 F5:2 Eb5:2|Eb5:1 Ab5:1 G5:2 Eb5:1 C5:1 Ab4:2|C5:3 Ab4:1 G4:2 F4:2|F4:1 Ab4:1 B4:2 D5:1 F5:1 Ab5:2|G5:1 F5:1 D5:2 B4:1 D5:1 G5:2|Eb5:2 C5:1 Ab4:1 R:2 C5:2|B4:1 D5:1 G5:2 R:4'''),
('Eb Bb/D Ab Fm Eb/G Ab Ddim G7','''Eb5:2 F5:1 G5:1 Bb5:4|Ab5:2 G5:2 F5:4|Eb5:3 C5:1 Ab4:2 C5:2|F5:2 Eb5:1 C5:1 Ab4:4|G4:1 Bb4:1 Eb5:3 F5:1 G5:2|Ab5:3 G5:1 Eb5:2 C5:2|D5:1 F5:1 Ab5:2 F5:1 D5:1 B4:2|G4:2 B4:1 D5:1 F5:2 D5:2'''),
('Cm Eb/Bb Ab Fm Bb Eb/G Ddim G7','''G5:2 Eb5:1 D5:1 C5:3 R:1|Bb4:1 Eb5:1 G5:2 F5:2 Eb5:2|C5:3 Eb5:1 Ab5:2 G5:2|F5:1 Eb5:1 C5:2 Ab4:2 F4:2|F4:1 Bb4:3 D5:1 C5:1 Bb4:2|G4:2 Bb4:1 Eb5:1 G5:2 F5:2|F5:1 D5:1 B4:2 R:2 D5:2|B4:2 G4:2 R:4'''),
('E B/D# C#m A F#m E/G# B E C#m A F#m B','''G#4:2 B4:1 E5:3 D#5:2|F#4:3 B4:1 D#5:2 C#5:2|E5:2 C#5:3 B4:1 G#4:2|C#5:2 B4:2 A4:3 R:1|A4:2 G#4:1 F#4:3 C#5:2|B4:3 G#4:1 F#4:2 E4:2|F#4:2 A4:2 B4:3 R:1|G#4:2 B4:2 E5:4|E5:3 C#5:1 G#4:2 B4:2|C#5:2 B4:1 A4:1 E4:3 R:1|F#4:2 A4:2 C#5:3 R:1|D#5:2 B4:2 R:4'''),
('Am D7 G7 Cm Ab Fm Ddim G7','''E5:1 A4:3 C5:1 B4:1 F4:2|F#4:1 A4:1 D5:3 C5:1 B4:2|D5:2 F5:1 G5:1 F5:2 B4:2|C5:1 Eb5:1 G5:3 F5:1 Eb5:2|Ab5:2 G5:1 Eb5:1 C5:2 Ab4:2|F5:1 C5:3 Ab4:1 G4:1 F4:2|D5:1 F5:1 Ab5:2 F5:1 D5:1 B4:2|D5:1 B4:1 G4:2 B4:1 D5:1 F5:2'''),
('Cm Bb Ab G7 Cm Eb Fm G7','''G4:1 C5:3 Eb5:1 D5:1 Ab4:2|F5:1 D5:1 Bb4:2 D5:1 F5:1 Ab5:2|G5:2 Eb5:1 C5:1 Ab4:2 C5:2|B4:1 D5:1 G5:2 F5:1 D5:1 B4:2|C5:1 Eb5:1 G5:2 C6:1 Bb5:1 G5:2|Bb5:1 G5:1 Eb5:2 F5:1 G5:1 Bb5:2|Ab5:2 F5:1 Eb5:1 C5:2 Ab4:2|B4:1 D5:1 F5:2 G5:2 R:2'''),
('Cm Ab Fm G7 Eb Bb/D Ab G7','''C6:1 G5:1 Eb5:3 D5:1 C5:2|Ab5:2 G5:1 Eb5:1 C5:1 Eb5:1 Ab5:2|F5:1 Ab5:1 C6:2 Bb5:1 Ab5:1 G5:2|G5:1 F5:1 D5:1 B4:1 D5:1 F5:1 G5:2|Eb5:1 F5:1 G5:2 Bb5:1 G5:1 Eb5:2|F5:1 Bb5:1 Ab5:2 F5:1 D5:1 Bb4:2|Eb5:1 C5:1 Ab4:2 C5:1 Eb5:1 F5:2|D5:1 B4:1 G4:2 B4:1 D5:1 F5:2'''),
('Cm Ab Fm G7 Cm Eb Ab G7','''G5:1 C6:3 Eb6:1 D6:1 Ab5:2|G5:1 B5:1 C6:3 Bb5:1 Ab5:2|C6:1 Ab5:1 F5:2 G5:1 Ab5:1 C6:2|B5:1 G5:1 F5:2 D5:1 F5:1 G5:2|G5:1 Eb5:1 C5:3 D5:1 Eb5:2|Bb5:1 G5:1 Eb5:2 F5:1 G5:1 Bb5:2|Ab5:3 G5:1 Eb5:2 C5:2|B4:1 D5:1 G5:3 R:3'''),
('Fm Cm/G G7 Cm','''C5:1 F5:3 Eb5:1 D5:1 C5:2|G4:2 C5:1 Eb5:1 G5:2 Eb5:2|D5:1 B4:1 G4:2 R:2 B4:2|C5:3 G4:1 Eb4:2 R:2'''),
('Ab Fm G7 Cm6','''C5:3 Ab4:1 Eb4:2 C4:2|Ab4:2 G4:1 F4:1 C4:3 R:1|B4:1 G4:1 F4:2 D4:2 R:2|C5:1 G4:1 Eb4:2 C4:2 R:2''')]
H={'Cm':[48,51,55],'Cm/G':[43,48,51],'Cm6':[48,51,57],'Ab':[44,48,51],'Fm':[41,44,48],'G7':[43,47,50,53],'Bb':[46,50,53],'Bb/D':[50,53,58],'Eb':[51,55,58],'Eb/G':[43,46,51],'Eb/Bb':[46,51,55],'Ddim':[50,53,56],'E':[52,56,59],'B':[47,51,54],'B/D#':[51,54,59],'C#m':[49,52,56],'A':[45,49,52],'F#m':[42,45,49],'E/G#':[44,47,52],'Am':[45,48,52],'D7':[50,54,57],'Abmaj7':[44,48,51,55],'Fm6':[41,44,50],'Cm/Eb':[51,55,60]}
R1={25:'Eb5:3 F5:1 G5:2 Bb5:2',26:'Ab5:2 G5:1 F5:1 R:2 D5:2',27:'Eb5:2 C5:1 Ab4:1 C5:2 Eb5:2',28:'F5:3 Eb5:1 C5:1 Ab4:1 R:2',29:'G4:1 Bb4:1 Eb5:2 G5:1 F5:1 Eb5:2',30:'C5:2 Eb5:1 Ab5:1 G5:2 F5:2',31:'D5:1 F5:1 Ab5:3 F5:1 D5:2',32:'B4:1 D5:1 F5:2 R:2 G4:2',33:'G5:2 Eb5:2 D5:1 C5:1 R:2',34:'Bb4:2 Eb5:1 G5:1 F5:2 D5:2',35:'C5:1 Eb5:1 Ab5:3 G5:1 Eb5:2',36:'F5:2 C5:1 Ab4:1 G4:1 F4:1 R:2',37:'F4:1 Bb4:1 D5:2 F5:1 Eb5:1 D5:2',38:'Eb5:3 Bb4:1 G4:2 Bb4:2',39:'D5:1 F5:1 Ab5:2 R:2 F5:2',40:'B4:2 G4:1 R:5'}
H1={25:'Eb/G',27:'Abmaj7',28:'Fm6',30:'Abmaj7',33:'Cm/Eb',34:'Eb/Bb',35:'Abmaj7',36:'Fm6'}
R2={69:'G5:1 C6:3 Eb6:1 D6:1 Ab5:2',70:'G5:1 Eb5:1 C5:2 Eb5:1 G5:1 Ab5:2',71:'C6:1 Ab5:1 F5:2 G5:1 Ab5:1 C6:2',72:'B5:1 G5:1 F5:1 D5:1 R:2 G5:2',73:'Eb5:2 F5:1 G5:1 Bb5:3 R:1',74:'Ab5:1 F5:1 D5:2 F5:1 Ab5:1 Bb5:2',75:'Ab5:2 G5:1 Eb5:1 C5:2 Ab4:2',76:'B4:1 D5:1 F5:1 G5:1 R:4',77:'G5:1 C6:2 Eb6:1 D6:1 C6:1 Ab5:2',78:'G5:1 B5:1 C6:2 R:1 Bb5:1 Ab5:2',79:'C6:2 Ab5:1 F5:1 C5:2 F5:2',80:'G5:1 F5:1 D5:2 B4:1 D5:1 G5:2',81:'Eb5:1 G5:1 C6:2 Bb5:1 G5:1 Eb5:2',82:'F5:1 G5:1 Bb5:2 G5:1 F5:1 Eb5:2',83:'Eb5:1 C5:1 Ab4:2 C5:1 Eb5:1 F5:2',84:'D5:1 B4:1 G4:2 R:4',85:'C5:2 F5:1 Eb5:1 C5:2 Ab4:2',86:'G4:1 C5:1 Eb5:2 D5:1 C5:1 G4:2',87:'B4:1 D5:1 G5:1 F5:1 D5:1 B4:1 R:2',88:'C5:2 G4:1 Eb4:1 C4:2 R:2',91:'B4:1 G4:1 D4:2 F4:1 R:3',92:'C5:1 G4:1 Eb4:1 A3:1 C4:2 R:2'}
H2={69:'Cm/Eb',70:'Abmaj7',71:'Fm6',73:'Eb/G',75:'Abmaj7',77:'Cm/G',79:'Fm6',81:'Cm/Eb',83:'Abmaj7',85:'Fm6',88:'Cm6'}
def midi(s):return 12*(int(s[-1])+1)+{'C':0,'D':2,'E':4,'F':5,'G':7,'A':9,'B':11}[s[0]]+s[1:-1].count('#')-s[1:-1].count('b')
def section(n):
 if n<=8:return 'Intro','鞋尖试探',104,61
 if n<=24:return 'A','第一次对攻',112,83
 if n<=40:return 'B','退步后进',108,73
 if n<=52:return 'C','只练一式',80,46
 if n<=68:return 'Ainv','倒影回合',116,80
 if n<=88:return 'AB','双人长回合',116,91
 return 'Coda','礼与收剑',76,50

def build(level):
 lines=[];hs=[]
 for h,row in ROWS:hs+=h.split();lines +=[s.strip() for s in row.split('|')]
 assert len(lines)==len(hs)==92
 for lv,changes,hchanges in [(1,R1,H1),(2,R2,H2)]:
  if level>=lv:
   for n,s in changes.items():lines[n-1]=s
   for n,s in hchanges.items():hs[n-1]=s
 bars=[];ev=[];ped=[]
 for n,(line,h) in enumerate(zip(lines,hs),1):
  sect,label,bpm,dyn=section(n);start=4*(n-1);ch=H[h]
  if n in [8,24,40,52,68,88]:bpm-=6
  if n>=89:bpm-=2*(n-89)
  bars.append(dict(bar=n,start=start,beats=4,bpm=bpm,meter='4/4',meter_numerator=4,meter_denominator=4,section=sect,section_title_zh=label,harmony_name=h,harmony=ch,key_region='E major' if sect=='C' else 'C minor',metrical_grouping='3+3+2 syncopations over four steady quarters',texture='short_bowed_responses_and_piano_dialogue'))
  def add(p,t,d,v,inst,voice,hand='none'):
   assert 0<=t<t+d<=4.000001,(n,t,d)
   ev.append(dict(bar=n,onset=round(start+t,6),duration=round(d,6),pitch=p,velocity=int(v),instrument=inst,voice=voice,hand=hand,harmony_name=h,phrase_id=f'{sect}_{(n-1)//4}',role='lead' if voice=='melody' else 'support',written_value_beats=d,articulation='syncopated_attack_with_phrase_release'))
  at=0.
  for i,tok in enumerate(line.split()):
   note,units=tok.split(':');duration=int(units)/2
   if note!='R':
    add(midi(note),at,duration-(.09 if sect!='C' else .05),dyn+(7 if at in [1.5,3] else 0)-(4 if i==len(line.split())-1 else 0),'piano','melody','left' if n<=4 else 'right')
   at+=duration
  assert at==4,(n,at)
  if n<=4:
   # Intro states the hook in the left hand; upper punctuation waits its turn.
   for t,p in [(1.5,67),(3.5,63 if h!='G7' else 62)]:add(p,t,.30,dyn-20,'piano','upper_answer','right')
  elif sect=='C':
   # Quiet study: two inner tones only; a changing bass and incomplete answer.
   for t,p,d in [(0,ch[0],1.3),(2,ch[1],1.4)]:add(p,t,d,dyn-12,'piano','two_part_study','left')
  else:
   # Habanera/tango family, not101's asymmetric step pattern.
   pat=[(0,ch[0],.44),(1.5,ch[1],.34),(3,ch[2],.42)]
   if n%4==0:pat=[(0,ch[0],.48),(2,ch[1],.45)]
   if level>=1 and 25<=n<=40:pat=[(0,ch[0],.55),(2.5,ch[1],.38),(3.5,ch[2],.3)]
   if level>=2 and 69<=n<=88:pat=[(.5,ch[1],.35),(2,ch[0],.4),(3.5,ch[2],.3)]
   if n in [40,52,76,84,88,92]:pat=[(0,ch[0],.65)]
   for t,p,d in pat:add(p,t,d,dyn-25,'piano','tango_counterstep','left')
   if n%8==1 and n<89:add(ch[1],0,.4,dyn-30,'piano','inner_chord','left')
  if n>=3 and n%4 in [2,3] and n not in [42,43,50,51,91]:
   pcs={p%12 for p in ch};cp=[p for p in range(50,60) if p%12 in pcs]
   assert cp,h
   entries=[(1.5,cp[-1])] if n%4==2 else [(.5,cp[0]),(2.5,cp[-1])]
   if level>=1 and 25<=n<=40:entries=[(2,cp[0])]
   if level>=2 and 69<=n<=88:entries=[(.5,cp[-1]),(2.5,cp[0])] if n%4==3 else [(1,cp[0])]
   for t,p in entries:
    gate=.60*bpm/60;add(p,t,min(gate,4-t-.1),48 if sect=='C' else (76 if sect=='AB' else 65),'cello','separate_bow_answer')
  ped.append(dict(bar=n,onset=start,controller=64,value=0,instrument='piano'))
  if sect=='C':ped +=[dict(bar=n,onset=start+.08,controller=64,value=36,instrument='piano'),dict(bar=n,onset=start+1.65,controller=64,value=0,instrument='piano'),dict(bar=n,onset=start+2.08,controller=64,value=32,instrument='piano'),dict(bar=n,onset=start+3.8,controller=64,value=0,instrument='piano')]
  elif n%4==1:ped +=[dict(bar=n,onset=start+.04,controller=64,value=23,instrument='piano'),dict(bar=n,onset=start+.55,controller=64,value=0,instrument='piano')]
 ev.sort(key=lambda e:(e['onset'],e['instrument'],e['pitch']))
 for i,e in enumerate(ev):e['event_id']=f'w102-v{level}-{i:04d}'
 return dict(id=102,title='Red Brick Fencing Lesson',title_zh='红砖击剑课',version=f'v{level}',bars=bars,events=ev,pedals=ped,total_beats=368,tail_seconds=5,instrumentation=['piano','cello_short_bowed'],performance_contract='Original sample-based acoustic chamber music; no live performance or human listening claim.')
for v in range(3):
 d=build(v);(P/f'score_v{v}.json').write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
 report=dict(version=f'v{v}',bars=92,notes=len(d['events']),duration_seconds=sum(b['beats']*60/b['bpm'] for b in d['bars'])+5,human_listening_review=False)
 (P/f'audit_v{v}.json').write_text(json.dumps(report,indent=2))
 if v:
  old=build(v-1);changed=[]
  for n in range(1,93):
   clean=lambda e:{k:x for k,x in e.items() if k!='event_id'}
   if [clean(e) for e in old['events'] if e['bar']==n]!=[clean(e) for e in d['events'] if e['bar']==n]:changed.append(n)
  a=(P/f'score_v{v-1}.json').read_text();b=(P/f'score_v{v}.json').read_text()
  (P/f'exact_diff_v{v-1}_to_v{v}.patch').write_text(''.join(difflib.unified_diff(a.splitlines(True),b.splitlines(True),f'score_v{v-1}.json',f'score_v{v}.json')))
  (P/f'exact_diff_v{v-1}_to_v{v}.json').write_text(json.dumps({'changed_bars':changed,'count':len(changed)},indent=2))
(P/'score.json').write_text((P/'score_v2.json').read_text())
# Advance short-bow sample triggers exactly once; musical bars and piano retain nominal timing.
d=build(2);starts=[b['start'] for b in d['bars']];times=[];s=0
for b in d['bars']:times.append(s);s+=b['beats']*60/b['bpm']
def seconds(t):
 i=max(0,bisect.bisect_right(starts,t)-1);return times[i]+(t-starts[i])*60/d['bars'][i]['bpm']
def beat(t):
 i=max(0,bisect.bisect_right(times,t)-1);return starts[i]+(t-times[i])*d['bars'][i]['bpm']/60
mapping=P.parent/'assets/iowa_cello_arco_D3_B3/mapping_manifest.json'
lat={(x['layer'],x['midi']):x['coarse_voiced_delay_after_tuning_seconds'] for x in json.loads(mapping.read_text())['files']};align=[]
for e in d['events']:
 if e['instrument']!='cello':continue
 target=seconds(e['onset']);end=seconds(e['onset']+e['duration']);layer='pp' if e['velocity']<=55 else 'mf';delay=lat[layer,e['pitch']];trigger=target-delay;assert trigger>=0
 e['nominal_onset']=e['onset'];e['onset']=beat(trigger);e['duration']=beat(end)-e['onset'];e['layer']=layer;e['attack_compensated_once']=True
 align.append(dict(event_id=e['event_id'],target_seconds=target,trigger_seconds=trigger,delay_seconds=delay,gate_seconds=end-trigger,layer=layer))
d['events'].sort(key=lambda e:(e['onset'],e['instrument'],e['pitch']))
(P/'ensemble_score.json').write_text(json.dumps(d,ensure_ascii=False,indent=2))
for inst in ['piano','cello']:
 x={**d,'events':[e for e in d['events'] if e['instrument']==inst],'pedals':d['pedals'] if inst=='piano' else []};(P/f'{inst}_score.json').write_text(json.dumps(x,ensure_ascii=False,indent=2))
(P/'revisions/cello_attack_alignment.json').write_text(json.dumps({'method':'Once-only pitch/layer coarse recorded-attack alignment. Not perceptual listening approval.','events':align},indent=2))
print(json.dumps(report));print([json.loads((P/f'exact_diff_v{i}_to_v{i+1}.json').read_text())['count'] for i in range(2)])
