"""Full original development of the approved52 theme. Reuses only this work's own approved excerpt, never old catalog audio."""
import pathlib,json,ast,copy,collections,math
P=pathlib.Path(__file__).parent
# Read literal thematic material without executing or overwriting the preserved excerpt script.
asttree=ast.parse((P.parent/'compose_direction.py').read_text());bank={}
for n in asttree.body:
 if isinstance(n,ast.Assign) and len(n.targets)==1 and isinstance(n.targets[0],ast.Name) and n.targets[0].id in ('A','D','BR','H'):bank[n.targets[0].id]=ast.literal_eval(n.value)
A,D,BR,H=[bank[k] for k in ('A','D','BR','H')]
H.update({'FA':[45,53,57,60],'DmF':[53,57,62,65],'CE':[52,55,60,64],'Gm7':[43,50,58,65],'Dmajor':[50,57,62,66]})
B=[[(77,1.5),(74,.5),(70,1),(72,1)],[(77,2),(76,.5),(74,.5),(72,1)],[(74,1.5),(77,.5),(79,1),(77,.5),(74,.5)],[(77,1.5),(76,.5),(74,1.5),(-1,.5)],[(82,1),(81,.5),(77,.5),(74,1),(77,1)],[(79,1.5),(76,.5),(72,1),(74,.5),(76,.5)],[(73,1),(76,1),(81,1.5),(-1,.5)],[(77,1),(76,.5),(74,2),(-1,.5)]]
B2=[[(74,.5),(77,.5),(82,2),(81,.5),(77,.5)],[(81,1.5),(79,.5),(77,1),(72,1)],[(79,1),(77,.5),(74,.5),(70,1),(74,1)],[(77,2),(76,.5),(74,.5),(69,1)],[(74,1),(77,.5),(82,.5),(86,1),(84,.5),(82,.5)],[(84,1.5),(79,.5),(76,1),(72,1)],[(73,.5),(76,.5),(81,1),(80,.5),(81,.5),(85,1)],[(86,1),(81,.5),(77,.5),(74,1.5),(-1,.5)]]
C=[[(69,1),(73,.5),(76,.5),(74,1),(73,.5),(-1,.5)],[(74,1.5),(77,.5),(81,1),(79,.5),(77,.5)],[(70,1),(74,1),(77,1.5),(-1,.5)],[(72,1.5),(76,.5),(79,1),(77,.5),(76,.5)],[(74,1),(77,1),(79,1),(77,1)],[(77,1.5),(74,.5),(70,1),(74,.5),(77,.5)],[(76,1),(73,1),(69,1),(73,.5),(-1,.5)],[(74,2),(77,1),(81,.5),(-1,.5)]]
CODA=[[(77,1),(74,.5),(70,.5),(74,1),(77,1)],[(79,1),(76,1),(72,1),(76,1)],[(81,1.5),(77,.5),(74,1),(76,.5),(77,.5)],[(79,1),(76,.5),(73,.5),(69,1.5),(-1,.5)],[(74,.5),(78,.5),(81,1),(83,.5),(81,.5),(78,.5),(74,.5)],[(77,1),(74,1),(70,1),(74,1)],[(73,.5),(76,.5),(81,1),(85,1),(81,.5),(-1,.5)],[(86,.75),(81,.25),(78,1),(74,2)]]
prog=['Dm','Bb','F','C','Gm','Bb','A','Dm'];bp=['Bb','FA','Gm7','DmF','Bb','CE','A','Dm'];brprog=['Gm','Eb','Bb','C','Gm','Bb','A','A'];cp=['A','Dm','Bb','C','Gm7','Bb','A','Dm'];codap=['Bb','CE','Dm','A','Dmajor','Bb','A','Dmajor']
sections=[('Clock waiting for the water',8,132,'intro'),('Both boats depart',16,144,'theme'),('Beyond the breakwater',16,148,'develop'),('Borrowing one tide',16,96,'lyric'),('The tide asks to return',8,138,'bridge'),('The clocks disagree',8,80,'cadenza'),('Today, watch the boats',16,144,'return'),('Looking at the water first',16,128,'combine'),('Harbor morning',8,112,'coda')]
notes=[];bars=[];pedals=[];beat=0;barno=0
for section,count,tempo,kind in sections:
 for j in range(count):
  barno+=1;k=j%8;chordname=prog[k]
  if kind=='intro':
   line=copy.deepcopy(A[k]);line=[(n-12 if n>=0 else n,d) for n,d in line]
   if j<2:line=line[:3]+[(-1,sum(d for n,d in line[3:]))]
  elif kind=='theme':line=copy.deepcopy(A[k] if j<8 else D[k])
  elif kind=='develop':
   line=copy.deepcopy(D[k] if j<8 else BR[k]);chordname=(prog if j<8 else brprog)[k]
   if j in (1,5,9,13):
    # Fresh sequential answers maintain the harmony's pitch classes.
    line=[(n-12 if n>=86 else n,d) for n,d in line]
  elif kind=='lyric':line=copy.deepcopy(B[k] if j<8 else B2[k]);chordname=bp[k]
  elif kind=='bridge':line=copy.deepcopy(BR[k]);chordname=brprog[k]
  elif kind=='cadenza':line=copy.deepcopy(C[k]);chordname=cp[k]
  elif kind=='return':
   line=copy.deepcopy(A[k] if j<8 else D[k])
   if j in (9,11,13):line={9:[(82,1),(81,.5),(77,.5),(74,.5),(77,.5),(82,1)],11:[(84,1),(79,.5),(76,.5),(79,1),(83,.5),(84,.5)],13:[(86,1),(89,.5),(86,.5),(84,.5),(82,.5),(81,.5),(82,.5)]}[j]
  elif kind=='combine':line=copy.deepcopy(B2[k] if j<8 else A[k]);chordname=(bp if j<8 else prog)[k]
  else:line=copy.deepcopy(CODA[k]);chordname=codap[k]
  assert abs(sum(d for _,d in line)-4)<1e-6,(kind,j)
  ch=H[chordname];bpm=tempo
  if kind=='coda' and j>=5:bpm=[106,98,86][j-5]
  if kind=='lyric' and j in (7,15):bpm=90
  bars.append(dict(bar=barno,start=beat,beats=4,bpm=bpm,section=section,harmony_name=chordname,harmony=ch,role_plan=kind))
  leadvel={'intro':65,'theme':85,'develop':91,'lyric':66,'bridge':82,'cadenza':62,'return':96,'combine':84,'coda':73}[kind]
  if kind=='intro':leadvel+=j*2
  if kind=='bridge':leadvel+=j
  if kind=='coda':leadvel-=j*2
  off=0
  for i,(pitch,length) in enumerate(line):
   if pitch>=0:
    vel=leadvel+(3 if off in (0,2) else -2)
    notes.append(dict(bar=barno,onset=beat+off,duration=length*.965,pitch=pitch,velocity=max(30,min(106,vel)),voice='melody'))
   off+=length
  bassvel={'intro':42,'theme':53,'develop':57,'lyric':43,'bridge':51,'cadenza':37,'return':63,'combine':52,'coda':43}[kind]
  notes.append(dict(bar=barno,onset=beat,duration=.43,pitch=ch[0],velocity=bassvel,voice='bass'))
  if kind in ('lyric','cadenza'):
   # Less subdivision but no disconnected competing theme: one quiet chord and a linked response.
   for idx,n in enumerate(ch[1:]):notes.append(dict(bar=barno,onset=beat+.72+idx*.045,duration=.72,pitch=n,velocity=bassvel-7+idx,voice='accompaniment'))
   for t,n in [(2.15,ch[2]),(2.8,ch[3]),(3.4,ch[2])]:
    if k!=7 or t<3:notes.append(dict(bar=barno,onset=beat+t,duration=.45,pitch=n,velocity=bassvel-9,voice='accompaniment'))
  else:
   arp=[ch[1],ch[2],ch[3],ch[2],ch[1],ch[2],ch[3]]
   if kind=='combine' and j<8:arp=[ch[2],ch[3],ch[2],ch[1],ch[2],ch[3],ch[2]]
   for z,n in enumerate(arp):
    offset=.5+z*.5
    if k==7 and offset>=3.5:continue
    if kind=='coda' and j==7 and offset>1.5:continue
    notes.append(dict(bar=barno,onset=beat+offset,duration=.43,pitch=n,velocity=bassvel-8+(2 if z%2==0 else 0),voice='accompaniment'))
  # Melodic octaves reinforce a few shared return arrivals; never an independent competing line.
  if kind=='return' and j in (0,2,4,6,8,12,14):
   lead=next(e for e in notes if e['bar']==barno and e['voice']=='melody');q=copy.deepcopy(lead);q.update(pitch=lead['pitch']-12,velocity=lead['velocity']-17,voice='melody_octave');notes.append(q)
  if kind=='coda' and j==7:
   lead=next(e for e in reversed(notes) if e['bar']==barno and e['voice']=='melody');q=copy.deepcopy(lead);q.update(pitch=lead['pitch']-12,velocity=lead['velocity']-17,voice='melody_octave');notes.append(q)
  ped=56 if kind not in ('lyric','cadenza') else 51
  pedals += [dict(onset=beat,value=0),dict(onset=beat+.12,value=ped),dict(onset=beat+1.95,value=0),dict(onset=beat+2.08,value=48),dict(onset=beat+3.85,value=0)]
  beat+=4
pedals=[e for e in pedals if e['onset']<beat-4]+[dict(onset=beat-4,value=0),dict(onset=beat-3.88,value=65),dict(onset=beat+3,value=0)]
score=dict(id=52,title='The Clockmaker’s Borrowed Tide',title_zh='向潮水借来的钟',stage='full_v0_development_draft',bars=bars,events=notes,pedals=pedals,total_beats=beat,tail_seconds=5.5,origin='Development of the user-approved original63-second52 theme; one composition, not another catalog count.')
(P/'revisions/score_full_v0.json').write_text(json.dumps(score,indent=2));(P/'score.json').write_text(json.dumps(score,indent=2))
(P/'thematic_material.json').write_text(json.dumps({'approved52_A':A,'approved52_D':D,'new_lyrical_B':B,'new_lyrical_B_answer':B2,'new_cadenza':C,'new_coda':CODA},indent=2))
print('Full score draft',len(bars),'bars',len(notes),'notes','duration',sum(b['beats']*60/b['bpm'] for b in bars)+5.5)
