from pathlib import Path
import json

P=Path(__file__).parent
c=json.loads((P/'native_mix_plan.json').read_text())
d=json.loads((P/'ensemble_score.json').read_text())
project=Path(c['project']); master=Path(c['master'])
assert not project.exists() and not master.exists()
parts=['<REAPER_PROJECT 0.1 7.82 1','  SAMPLERATE 44100 0 0',
 '  TEMPO 120 1 4 0','  MASTER_VOLUME 1',f'  RENDER_FILE "{master}"',
 '  RENDER_FMT 0 2 44100','  RENDER_1X 0',f'  RENDER_RANGE 0 0 {c["end"]} 0 1000',
 '  RENDER_RESAMPLE 3 0 1','  RENDER_STEMS 0','  RENDER_DITHER 0',
 '  <RENDER_CFG','    ZXZhdxgAAA==','  >']
t=0;last=None;number=0
for b in d['bars']:
 if b['section']!=last:
  number+=1;label=b.get('section_title_zh',b['section']).replace('"',"'")
  parts.append(f'  MARKER {number} {t:.10f} "{label}" 0');last=b['section']
 t+=b['beats']*60/b['bpm']
for tr in c['tracks']:
 assert (project.parent/tr['source']).is_file()
 parts += ['  <TRACK',f'    NAME "{tr["name"]}"',f'    PANMODE {tr["I_PANMODE"]}',
  f'    WIDTH {tr["D_WIDTH"]}',f'    VOLPAN {tr["D_VOL"]} {tr["D_PAN"]} {tr["D_PANLAW"]} -1 1',
  '    MAINSEND 1','    <ITEM','      POSITION 0',f'      LENGTH {c["end"]}',
  f'      NAME "{tr["instrument"]} verified RAM performance"','      VOLPAN 1 0 1 -1',
  '      FADEIN 1 0.005','      FADEOUT 1 0.6','      <SOURCE WAVE',
  f'        FILE "{tr["source"]}"','      >','    >','  >']
parts.append('>');project.write_text('\n'.join(parts)+'\n')
fields=['D_VOL','D_PAN','D_WIDTH','D_PANLAW','I_PANMODE']
expected='{'+','.join('{'+','.join(f'{k}={tr[k]}' for k in fields)+'}' for tr in c['tracks'])+'}'
names='{'+','.join(json.dumps(tr['name']) for tr in c['tracks'])+'}'
out=project.parent/'verified_final_native.tsv'
lua=f'''os.remove({json.dumps(str(out))})
local project={json.dumps(str(project))}
local expected={expected}
local names={names}
local function check_project()
 local _,file=reaper.EnumProjects(-1,"");assert(file==project)
 assert(reaper.CountTracks(0)==#expected)
 for i,name in ipairs(names) do local _,actual=reaper.GetTrackName(reaper.GetTrack(0,i-1));assert(actual==name) end
end
check_project()
for i,e in ipairs(expected) do local t=reaper.GetTrack(0,i-1);for k,val in pairs(e) do assert(reaper.SetMediaTrackInfo_Value(t,k,val)) end end
reaper.Main_SaveProject(0,false)
assert(reaper.IsProjectDirty(0)==0)
assert(reaper.SetMediaTrackInfo_Value(reaper.GetTrack(0,0),'D_WIDTH',0.123))
reaper.Main_openProject('noprompt:'..project)
check_project()
local f=assert(io.open({json.dumps(str(out))},'w'))
for i,e in ipairs(expected) do local t=reaper.GetTrack(0,i-1);for k,val in pairs(e) do local a=reaper.GetMediaTrackInfo_Value(t,k);assert(math.abs(a-val)<1e-8,k);f:write(i,'\\t',k,'\\t',a,'\\n') end end
f:close();reaper.Main_OnCommand(40004,0)
'''
(P/'configure_duet_native.lua').write_text(lua)
print(project)
