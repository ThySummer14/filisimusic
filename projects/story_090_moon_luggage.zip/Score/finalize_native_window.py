from pathlib import Path
import json,subprocess,re,os,hashlib,wave
P=Path(__file__).parent;R=P.parent;V=P/'revisions';O=Path('DELIVERABLES')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def run(cmd,log):
 import time
 start=time.monotonic()
 with open(log,'w') as f:subprocess.run(list(map(str,cmd)),stdout=f,stderr=f,check=True,timeout=30)
 Path(str(log)+'.window_step.json').write_text(json.dumps({'command':list(map(str,cmd)),'elapsed_seconds':round(time.monotonic()-start,3),'exit_code':0,'resource_guard':'Outer shared-lock native finishing window'},indent=2))
def native(p,log):run([R/'tools/reaper_linux_x86_64/REAPER/reaper','-cfgfile',R/'runtime_test/reaper.ini','-nosplash','-renderproject',p],log)
run([R/'tools/reaper_linux_x86_64/REAPER/reaper','-cfgfile',R/'runtime_test/reaper.ini','-nosplash','-newinst',V/'090_luggage_v3.rpp',P/'configure_duet_native.lua'],V/'window_native_configure.log')
expected=[{k:t[k] for k in ['D_VOL','D_PAN','D_WIDTH','D_PANLAW','I_PANMODE']} for t in json.loads((P/'native_mix_plan.json').read_text())['tracks']];got={}
for l in (V/'verified_final_native.tsv').read_text().splitlines():
 i,k,val=l.split('\t');got[(int(i),k)]=float(val)
for i,e in enumerate(expected,1):
 for k,v in e.items():assert abs(got[(i,k)]-v)<1e-8
(V/'verified_final_native.json').write_text(json.dumps({'actual_API_readback':True,'save_and_reopen_verified':True,'intent':expected},indent=2));proof=json.loads((V/'source_completeness_final.json').read_text());assert all(x['full_file_and_PCM_exact'] for x in proof.values())
project=V/'090_luggage_v3.rpp';master=V/'090_luggage_v3.wav';assert not master.exists();native(project,V/'native_master_render.log');run(['python',R/'tools/qa_pcm.py',master,'--score',P/'ensemble_score.json'],V/'native_master_qa.log');qa=json.loads(master.with_suffix('.qa.json').read_text());assert qa['clipped_samples']==0
stage=P/'standalone_v3';(stage/'Media').mkdir(parents=True,exist_ok=True);text=project.read_text();stems={};base='090_moon_luggage_v3'
for instrument in ['piano','clarinet']:
 source=V/(instrument+'_v2.wav');assert 'FILE "'+source.name+'"' in text;stems[instrument]=str(source);os.link(source,stage/'Media'/(instrument+'_float32.wav'));text=text.replace('FILE "'+instrument+'_v2.wav"','FILE "Media/'+instrument+'_float32.wav"')
text=re.sub(r'(?m)^\s*RENDER_FILE .*$', '  RENDER_FILE "Renders"',text);text=re.sub(r'(?m)^\s*RENDER_PATTERN .*\n','',text);text=text.replace('  RENDER_FMT','  RENDER_PATTERN "$project"\n  RENDER_FMT',1);portable=stage/(base+'.rpp');portable.write_text(text);native(portable,V/'portable_reopen_render.log')
with wave.open(str(master),'rb') as w:x=w.readframes(w.getnframes());params=w.getparams()
with wave.open(str(stage/'Renders'/(base+'.wav')),'rb') as w:y=w.readframes(w.getnframes());assert params==w.getparams() and x==y
(V/'portable_project_verification.json').write_text(json.dumps({'actual_reaper_reopen_and_export':True,'all_media_paths_relative':True,'pcm_identical_to_canonical':True,'pcm_sha256':hashlib.sha256(x).hexdigest(),'separate_source_completeness':'source_completeness_final.json'},indent=2));del x,y
mp3=O/'090_月亮遗失的行李_v3.mp3';assert not mp3.exists();run(['ffmpeg','-hide_banner','-loglevel','error','-threads','1','-i',master,'-codec:a','libmp3lame','-b:a','192k',mp3],V/'mp3_encode.log');run(['ffmpeg','-hide_banner','-loglevel','error','-threads','1','-i',mp3,'-f','null','-'],V/'mp3_decode.log')
j={'work_id':90,'piece_dir':str(P),'title_zh':'月亮遗失的行李','version':'v3','master':str(master),'project':str(project),'portable_project':str(portable),'stage':str(stage),'stems':stems,'mp3':str(mp3),'artifact_base':base,'master_sha256':sha(master),'mp3_sha256':sha(mp3),'source_completeness':str(V/'source_completeness_final.json'),'portable_verification':str(V/'portable_project_verification.json'),'native_settings':str(V/'verified_final_native.json'),'full_human_listening_pending':True,'packaging_pending':True};(P/'verified_final_job.json').write_text(json.dumps(j,ensure_ascii=False,indent=2));print('Verified90',qa['duration'],qa['peak_dbfs'])
