#!/usr/bin/env python3
"""Original symbolic work 085. Standard library only; no media or sample access."""
import collections
import copy
import difflib
import hashlib
import json
import math
from pathlib import Path

OUT = Path(__file__).resolve().parent
TITLE = 'The Keeper of the Spare Horizon'
H = {
    'E': ([40, 47], [56, 59, 64]),
    'E6': ([40, 47], [56, 61, 64]),
    'Emaj7': ([40, 47], [59, 63, 68]),
    'F#/E': ([40, 49], [58, 61, 66]),
    'F#': ([42, 49], [58, 61, 66]),
    'B': ([47, 54], [59, 63, 66]),
    'B/D#': ([39, 47], [59, 63, 66]),
    'C#m': ([37, 44], [56, 61, 64]),
    'G#m': ([44, 51], [56, 59, 63]),
    'A#dim': ([46, 52], [58, 61, 64]),
}
# Each pitch row was composed for this work. These are not generated scale runs
# or quotations. The program only realizes explicit musical choices.
SECTIONS = {
 'A': [
  ('E','piano',[64,66,68,66]), ('E6','piano',[64,66,68]),
  ('Emaj7','piano',[66,68,66,64]), ('E','piano',[63,64,66,64]),
  ('F#/E','piano',[66,68,70,68]), ('Emaj7','piano',[68,71,68,66]),
  ('B/D#','piano',[66,63,66,68]), ('E','piano',[66,68,64]),
 ],
 'A2': [
  ('E','flute',[76,78,80]), ('F#/E','flute',[78,82,80]),
  ('Emaj7','flute',[78,76]), ('B/D#','flute',[75,78,76]),
  ('C#m','piano',[73,71,68,66]), ('F#','piano',[66,68,70,73]),
  ('F#/E','flute',[78,80,82]), ('E','flute',[80,78,76]),
 ],
 'B': [
  ('E','piano',[68,71,73,75]), ('E6','piano',[76,75,73]),
  ('C#m','piano',[73,71,68,66]), ('F#','piano',[66,70,73,78]),
  ('F#/E','flute',[78,82,80]), ('E','flute',[80,78,76]),
  ('Emaj7','piano',[71,73,75,76]), ('B/D#','piano',[78,75,71]),
  ('C#m','flute',[80,78,76]), ('F#','flute',[78,82,83]),
  ('B','flute',[83,78,75]), ('E','flute',[80,78,76]),
 ],
 'C': [
  ('C#m','piano',[73,71,70,68]), ('A#dim','piano',[70,73,76,73]),
  ('F#','piano',[73,70,66,68]), ('F#/E','piano',[70,71,73,70]),
  ('G#m','flute',[80,78,75]), ('F#','flute',[78,82,78]),
  ('B/D#','piano',[75,73,71,66]), ('E','piano',[68,66,64]),
 ],
 'D': [
  ('E6','piano',[76,78,80,78]), ('Emaj7','piano',[76,75,73,71]),
  ('F#/E','piano',[78,80,82]), ('E','flute',[80,78,76]),
  ('F#/E','flute',[78,82,83]), ('E','flute',[80,78,76]),
  ('Emaj7','piano',[80,83,82,80]), ('G#m','piano',[78,75,71,75]),
  ('C#m','piano',[76,80,78,76]), ('F#','piano',[78,82,80,78]),
  ('B','piano',[75,78,83,78]), ('E','flute',[80,78,76]),
 ],
 'E': [
  ('E','piano',[76,73,71,68]), ('C#m','flute',[76,80,78]),
  ('F#/E','flute',[78,82,80]), ('E','piano',[76,75,73,71]),
  ('B/D#','piano',[75,73,71]), ('E','flute',[80,78,76]),
  ('F#','piano',[78,80,82,78]), ('E6','piano',[76,73,71,68]),
  ('C#m','flute',[76,80,78]), ('F#/E','flute',[78,82,80]),
  ('E','piano',[76,75,71,68]), ('E','piano',[66,68,64]),
 ],
 'Z': [
  ('E6','piano',[68,71,73,71]), ('F#/E','flute',[78,82,78]),
  ('E','flute',[80,78,76]), ('E','piano',[68,66,64]),
 ],
}
LABELS = {'A':'卷筒上的旧标签','A2':'试一个较低的位置','B':'把相机推到门口',
          'C':'轮廓还在画面外','D':'选定横幅构图','E':'再拍一组不看镜头的','Z':'第十七张'}
TEMPI = {'A':72,'A2':74,'B':76,'C':74,'D':76,'E':74,'Z':68}
E_LYDIAN = {4,6,8,10,11,1,3}

def dump(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2)+'\n', encoding='utf8')

def structure(version):
    result=[]
    for section, source in SECTIONS.items():
        rows=copy.deepcopy(source)
        if version == 0 and section == 'B':
            rows=rows[:4]+rows[8:]
        if version <= 1 and section == 'D':
            rows=[(h,'piano',[p-12 for p in pitches]) for h,lead,pitches in rows]
        if version == 0 and section == 'C':
            rows=[('E','piano',[68,66,64]),('B','piano',[66,68,71]),
                  ('C#m','piano',[68,71,73]),('F#','piano',[70,68,66])]*2
        if version <= 1 and section == 'E':
            # Earlier version leaves the entire second six-bar sentence to flute.
            replacement=[('C#m','flute',[76,80,78]),('F#','flute',[78,82,80]),
                         ('B','flute',[83,78,75]),('E','flute',[80,78,76]),
                         ('B','flute',[78,75,78]),('E','flute',[80,78,76])]
            rows=rows[:6]+replacement
        if version <= 1 and section == 'Z':
            rows=[('E6','piano',[68,71,73,71]),('B','piano',[71,75,78]),
                  ('B','flute',[83,78,75]),('E','piano',[68,66,64])]
        for local,(h,lead,pitches) in enumerate(rows):
            result.append({'section':section,'local':local,'h':h,'lead':lead,'pitches':pitches})
    return result

def make_score(version):
    rows=structure(version)
    bars=[]
    elapsed=0.0
    for i,row in enumerate(rows):
        section=row['section']
        bpm=TEMPI[section] - (3 if version == 0 else 0)
        if section=='Z': bpm=[70,68,66,62][row['local']] - (1 if version==0 else 0)
        lh,rh=H[row['h']]
        macro_len=6 if section in ('B','D','E') and version>=1 else 4
        macro=f"{section}.{row['local']//macro_len+1:02d}"
        bars.append({'bar':i+1,'start':float(i*4),'beats':4.0,'bpm':bpm,
          'meter':'4/4','meter_numerator':4,'meter_denominator':4,
          'section':section,'section_title_zh':LABELS[section],
          'harmony_name':row['h'],'harmony':lh+rh,'lead_instrument':row['lead'],
          'macro_phrase_id':macro,'macro_phrase_length_bars':macro_len,
          'time_start_seconds':round(elapsed,9),
          'role_plan': 'Piano sings the foreground with harmonic left hand.' if row['lead']=='piano' else
                       'Flute sings; piano unfolds one shared harmony below it.'})
        elapsed+=240/bpm

    def sec(beat):
        if beat>=len(bars)*4: return elapsed+(beat-len(bars)*4)*60/bars[-1]['bpm']
        bar=bars[int(beat//4)]
        return bar['time_start_seconds']+(beat-bar['start'])*60/bar['bpm']

    events=[]
    flute_phrase_count=0
    flute_previous=False
    flute_span=0
    flute_pid=None
    piano_pid=None
    def add(b, offset, dur, pitch, velocity, inst, hand, voice, role, pid, layer):
        on=b['start']+offset
        events.append({'event_id':f'w85-{version}-b{b["bar"]:03d}-{len(events)+1:04d}',
            'bar':b['bar'],'onset':round(on,6),'duration':round(dur,6),'pitch':pitch,
            'velocity':velocity,'instrument':inst,'voice':voice,'hand':hand,
            'phrase_id':pid,'layer':layer,'role':role,
            'onset_reference':'ordinary_trigger','target_on_beats':round(on,6),
            'target_off_beats':round(on+dur,6),'target_on_seconds':round(sec(on),9),
            'target_off_seconds':round(sec(on+dur),9),
            'articulation':'separate_breathed_tone' if inst=='flute' else 'connected_finger_release',
            'sample_layer':layer if inst=='flute' else 'approved_natural_piano',
            'timing_intent':'No attack pre-shift. Owner applies measured sample compensation once.'})

    for i,(row,b) in enumerate(zip(rows,bars)):
        section=row['section']; local=row['local']; flute=row['lead']=='flute'
        piano_pid=b['macro_phrase_id']+'_piano'
        if flute:
            if not flute_previous or flute_span>=2 or (i>0 and bars[i-1]['section']!=section):
                flute_phrase_count+=1; flute_span=0
                flute_pid=f'F{flute_phrase_count:02d}'
            flute_span+=1
        else:
            flute_span=0
        flute_previous=flute
        layer='mf' if section in ('B','D') else 'pp'
        energy={'A':0,'A2':3,'B':7,'C':3,'D':12,'E':5,'Z':-3}[section]
        lh,rh=H[row['h']]
        # Released chord-tone motion shares the melody's harmony. No bass countermelody.
        if section=='A' and local<4:
            bass=[(0,lh[0],1.64),(2,lh[1],1.56)]
        elif section=='Z' and local==3:
            bass=[(0,lh[0],3.55),(0,lh[1],3.55),(0,lh[0]+12,3.55)]
        elif local%3==1:
            bass=[(0,lh[0],1.18),(1.5,lh[1],.92),(3,lh[0]+12,.58)]
        elif section in ('D','E'):
            bass=[(0,lh[0],1.68),(0,lh[1],1.68),(2.25,lh[0]+12,1.30)]
        else:
            bass=[(0,lh[0],1.52),(2,lh[1],1.48)]
        for j,(on,pitch,dur) in enumerate(bass):
            add(b,on,dur,pitch,43+energy+(j%2),'piano','left','harmonic_foundation','support',piano_pid,'natural')

        if flute:
            # A close upper pair answers the second attack. It remains harmonic,
            # beneath the flute and never becomes a separate moving lead line.
            first=[rh[0],rh[1]] if local%2==0 else rh[:]
            second=[rh[1],rh[2]]
            for on,chord,dur in [(0.18,first,1.38),(2.02,second,1.32)]:
                for pitch in chord:
                    add(b,on,dur,pitch,42+energy,'piano','right','shared_harmony','support',piano_pid,'natural')
            pitches=row['pitches']
            if len(pitches)==2:
                ons=[0,2]; durs=[1.42,1.38]
            else:
                ons=[0,1.25,2.5]; durs=[.88,.88,.92]
            base=66 if layer=='mf' else 46
            for j,(pitch,on,dur) in enumerate(zip(pitches,ons,durs)):
                vel=base+[0,2,-1][j%3]
                add(b,on,dur,pitch,vel,'flute',None,'foreground_melody','lead',flute_pid,layer)
        else:
            pitches=row['pitches']
            if len(pitches)==3:
                ons=[0,1.5,2.5]; spaces=[1.5,1,1.5]
            elif section=='C' and version>=1:
                ons=[0,.75,2,3]; spaces=[.75,1.25,1,1]
            elif local%4==3:
                ons=[0,.5,1.5,2.5]; spaces=[.5,1,1,1.5]
            else:
                ons=[0,1,2,3]; spaces=[1,1,1,1]
            if section=='Z' and local==3:
                ons=[0,1,2]; spaces=[1,1,1.80]
            for j,(pitch,on,space) in enumerate(zip(pitches,ons,spaces)):
                # Release time also prepares the next bar's right-hand grip.
                if j+1<len(pitches): nxt=pitches[j+1]
                elif i+1<len(rows):
                    nxt=rows[i+1]['pitches'][0] if rows[i+1]['lead']=='piano' else max(H[rows[i+1]['h']][1])
                else: nxt=pitch
                leap=abs(nxt-pitch)
                release_seconds=.075+max(0,leap-4)*.012
                gap=max(.10,release_seconds*b['bpm']/60)
                dur=max(.22,space-gap)
                add(b,on,dur,pitch,59+energy+[0,2,0,-2][j%4],'piano','right',
                    'foreground_melody','lead',piano_pid,'natural')

    events.sort(key=lambda e:(e['onset'],e['instrument'],e['pitch']))
    pedals=[]
    for b in bars:
        ending=b['bar']==len(bars)
        full=b['section']=='D' and b['bar']%3==1
        for offset,value in [(0,0),(.12,76 if full or ending else 42),(3.80 if ending else 3.63,0)]:
            pedals.append({'onset':round(b['start']+offset,6),'value':value,'instrument':'piano',
              'controller':64,'bar':b['bar'],'target_on_seconds':round(sec(b['start']+offset),9)})
    groups=collections.defaultdict(list)
    for e in events:groups[e['phrase_id']].append(e)
    phrases=[]
    for pid,es in groups.items():
        start=min(e['onset'] for e in es); end=max(e['onset']+e['duration'] for e in es)
        phrases.append({'phrase_id':pid,'instrument':es[0]['instrument'],
          'phrase_label':LABELS[bars[es[0]['bar']-1]['section']],
          'first_bar':min(e['bar'] for e in es),'last_bar':max(e['bar'] for e in es),
          'section':bars[es[0]['bar']-1]['section'],
          'layer':es[0]['layer'],'layers_used':sorted({e['layer'] for e in es}),
          'roles_used':sorted({e['role'] for e in es}),
          'voices_used':sorted({e['voice'] for e in es}),
          'target_on_beats':round(start,6),'target_off_beats':round(end,6),
          'target_on_seconds':round(sec(start),9),'target_off_seconds':round(sec(end),9),
          'breath_to_next_phrase_seconds':None,
          'timing_intent':'Nominal ordinary triggers, before owner-only measured attack compensation.'})
    phrases.sort(key=lambda p:(p['target_on_beats'],p['instrument']))
    fps=[p for p in phrases if p['instrument']=='flute']
    for j,p in enumerate(fps):
        next_on=fps[j+1]['target_on_seconds'] if j+1<len(fps) else elapsed
        p['breath_to_next_phrase_seconds']=round(next_on-p['target_off_seconds'],9)
    cadences=[]
    for i,b in enumerate(bars):
        if i==len(bars)-1 or bars[i+1]['macro_phrase_id']!=b['macro_phrase_id']:
            leads=[e for e in events if e['bar']==b['bar'] and e['role']=='lead']
            last=max(leads,key=lambda e:e['onset'])
            cadences.append({'bar':b['bar'],'harmony':b['harmony_name'],
              'melody_pitch':last['pitch'],'lead_instrument':b['lead_instrument'],
              'target_beat':last['onset'],'structural':i==len(bars)-1 or bars[i+1]['section']!=b['section']})
    return {'id':85,'title':TITLE,'title_zh':'备用地平线','version':f'v{version}',
      'instrumentation':['piano','flute'],'bars':bars,'events':events,'phrases':phrases,
      'pedals':pedals,'cadences':cadences,'total_beats':float(len(bars)*4),
      'tail_seconds':5.0,'music_seconds':round(elapsed,9),'total_seconds_with_tail':round(elapsed+5,9),
      'performance_contract':{
        'audio_status':'Symbolic source only. No audio, samples, renders, downloads, installations or publication.',
        'beat_unit':'Absolute quarter-note beats. Every bar is 4/4, exactly four quarter beats.',
        'key':'E Lydian: E F# G# A# B C# D#. E pedal and F#/E-to-E arrivals define the center.',
        'piano_instrument':'Owner-approved natural piano. No sample processing in this deliverable.',
        'flute_instrument':'Existing Iowa C5-B5 single-note recordings only; no new assets.',
        'flute_register':[72,83],'flute_layers':'pp 44-50, mf 64-70; no synthesized intermediate layer.',
        'flute_nominal_gate_seconds':[0.6,1.6],
        'flute_articulation':'Ordinary separated triggers only, no sampled legato, loops or artificial sustain.',
        'attack_compensation':'None in source. Owner measures and applies it exactly once, then rechecks sample tails.',
        'piano_pedal':'CC64 0 / 42 / 76, only piano, released at every bar and explicitly at the end.',
        'piano_hand_span_semitones':12,
        'piano_same_key_overlap':'Forbidden across hands and voices.',
        'balance':'One foreground at a time. Left hand supplies chord tones of the shared harmony; no independent bass tune.',
        'nominal_vs_sample':'Timing and ergonomic audits are symbolic only. Actual onset, release, balance and listening remain owner checks.'}}

def union_gaps(intervals,end):
    current=0; gaps=[]
    for a,b in sorted(intervals):
        if a>current:gaps.append((current,a))
        current=max(current,b)
    if current<end:gaps.append((current,end))
    return gaps

def audit(score):
    ev=score['events']; bars=score['bars']; issues=[]
    flute=[e for e in ev if e['instrument']=='flute']
    piano=[e for e in ev if e['instrument']=='piano']
    gates=[e['target_off_seconds']-e['target_on_seconds'] for e in flute]
    breaths=[p['breath_to_next_phrase_seconds'] for p in score['phrases'] if p['instrument']=='flute']
    for e in flute:
        if not 72<=e['pitch']<=83:issues.append(['flute_range',e['event_id']])
        lo,hi=(44,50) if e['layer']=='pp' else (64,70)
        if e['layer'] not in ('pp','mf') or not lo<=e['velocity']<=hi:issues.append(['flute_layer',e['event_id']])
        gate=e['target_off_seconds']-e['target_on_seconds']
        if not .6-1e-8<=gate<=1.6+1e-8:issues.append(['flute_gate',e['event_id'],gate])
    if min(breaths)<.4:issues.append(['flute_breath',min(breaths)])
    fgaps=[b['target_on_seconds']-a['target_off_seconds'] for a,b in zip(flute,flute[1:])]
    if min(fgaps)<0:issues.append(['flute_overlap',min(fgaps)])
    for e in ev:
        if e['pitch']%12 not in E_LYDIAN:issues.append(['outside_E_lydian',e['event_id']])
        if e['duration']<=0 or e['onset']<0 or e['onset']+e['duration']>score['total_beats']+1e-6:
            issues.append(['timeline',e['event_id']])
    for pitch,es in itertools_group(piano,lambda e:e['pitch']).items():
        for a,b in zip(es,es[1:]):
            if a['onset']+a['duration']>b['onset']+1e-7:issues.append(['piano_same_key_overlap',pitch,a['event_id'],b['event_id']])
    hand_stats={}
    for hand in ('left','right'):
        es=[e for e in piano if e['hand']==hand]
        maxspan=0; heldviolations=[]
        for t in sorted({e['onset'] for e in es}):
            active=[e for e in es if e['onset']<=t+1e-8 and e['onset']+e['duration']>t+1e-8]
            span=max(e['pitch'] for e in active)-min(e['pitch'] for e in active)
            maxspan=max(maxspan,span)
            if span>12:heldviolations.append([t,span])
        issues.extend(['hand_span',hand,v] for v in heldviolations)
        attacks=itertools_group(es,lambda e:e['onset'])
        attacklist=sorted(attacks.items()); shifts=[]
        for (ta,ea),(tb,eb) in zip(attacklist,attacklist[1:]):
            # Physical translation of the whole grip, not intervals between fingers.
            a0,a1=min(e['pitch'] for e in ea),max(e['pitch'] for e in ea)
            b0,b1=min(e['pitch'] for e in eb),max(e['pitch'] for e in eb)
            move=max(abs(b0-a0),abs(b1-a1))
            released=max(e['target_off_seconds'] for e in ea)
            on=min(e['target_on_seconds'] for e in eb)
            gap=on-released
            required=.075+max(0,move-4)*.012 if move>4 else 0.0
            if move>4:
                shifts.append({'from_beat':ta,'to_beat':tb,'movement_semitones':move,
                  'released_seconds':round(gap,6),'required_seconds':round(required,6)})
                if gap+1e-6<required:issues.append(['released_hand_travel',hand,shifts[-1]])
        hand_stats[hand]={'maximum_held_span_semitones':maxspan,
          'travel_check':'Conservative whole-grip edge movement: 75ms + 12ms per semitone beyond four, for moves over four semitones.',
          'checked_large_translations':len(shifts),'minimum_translation_margin_seconds':round(min((s['released_seconds']-s['required_seconds'] for s in shifts),default=0),6),
          'largest_translations':sorted(shifts,key=lambda s:s['movement_semitones'],reverse=True)[:6]}
    bybar=[]
    for b in bars:
        es=[e for e in ev if e['bar']==b['bar']]
        leads=[e for e in es if e['role']=='lead']
        if {e['instrument'] for e in leads}!={b['lead_instrument']}:issues.append(['foreground_conflict',b['bar']])
        harmony_pcs={p%12 for p in b['harmony']}
        for e in es:
            if e['role']=='support' and e['pitch']%12 not in harmony_pcs:issues.append(['unshared_support_harmony',e['event_id']])
        bybar.append({'bar':b['bar'],'lead_notes':len(leads),'harmony':b['harmony_name'],'lead':b['lead_instrument']})
    coverage=union_gaps([(e['target_on_seconds'],e['target_off_seconds']) for e in ev],score['music_seconds'])
    leadcoverage=union_gaps([(e['target_on_seconds'],e['target_off_seconds']) for e in ev if e['role']=='lead'],score['music_seconds'])
    if max((b-a for a,b in coverage),default=0)>1.0:issues.append(['large_empty_gap',coverage])
    if any(p['instrument']!='piano' or p['value'] not in (0,42,76) for p in score['pedals']):issues.append(['pedal_contract'])
    if score['pedals'][-1]['value']!=0:issues.append(['final_pedal_release'])
    if not 200<=score['total_seconds_with_tail']<=225:issues.append(['duration',score['total_seconds_with_tail']])
    sectionstats=[]
    for section in SECTIONS:
        bes=[b for b in bars if b['section']==section]
        es=[e for e in ev if e['bar'] in {b['bar'] for b in bes} and e['role']=='lead']
        sectionstats.append({'section':section,'bars':[bes[0]['bar'],bes[-1]['bar']],
          'lead_register':[min(e['pitch'] for e in es),max(e['pitch'] for e in es)],
          'lead_note_count':len(es),'lead_instruments':dict(collections.Counter(b['lead_instrument'] for b in bes)),
          'macro_phrase_lengths_bars':sorted({b['macro_phrase_length_bars'] for b in bes})})
    return {'version':score['version'],'status':'PASS' if not issues else 'FAIL','issues':issues,
      'bars':len(bars),'total_beats':score['total_beats'],'events':len(ev),'music_seconds':score['music_seconds'],
      'total_seconds_with_tail':score['total_seconds_with_tail'],
      'flute':{'notes':len(flute),'pitch_range':[min(e['pitch'] for e in flute),max(e['pitch'] for e in flute)],
        'gate_seconds_range':[round(min(gates),6),round(max(gates),6)],
        'minimum_interphrase_breath_seconds':round(min(breaths),6),
        'minimum_inter_note_release_seconds':round(min(fgaps),6),
        'velocity_layers':{l:sorted({e['velocity'] for e in flute if e['layer']==l}) for l in ('pp','mf')},
        'ordinary_trigger_only':all(e['onset_reference']=='ordinary_trigger' for e in flute)},
      'piano_hands':hand_stats,'shared_harmony_support_pass':not any(x[0]=='unshared_support_harmony' for x in issues),
      'one_foreground_instrument_per_bar':not any(x[0]=='foreground_conflict' for x in issues),
      'maximum_all_instrument_silence_seconds':round(max((b-a for a,b in coverage),default=0),6),
      'maximum_foreground_silence_seconds':round(max((b-a for a,b in leadcoverage),default=0),6),
      'section_development':sectionstats,'bar_foreground_summary':bybar,
      'all_pitches_in_E_lydian':not any(x[0]=='outside_E_lydian' for x in issues),
      'final_pedal':score['pedals'][-1],
      'limits':['Symbolic audits do not establish sample attack/release quality or rendered audibility.',
                'No claim of listening, audio rendering, universal originality search, or measured instrument performance.']}

def itertools_group(values,key):
    out=collections.defaultdict(list)
    for v in values:out[key(v)].append(v)
    for vals in out.values():vals.sort(key=lambda e:e['onset'])
    return out

def compare(a,b):
    # Stable location by section/local-bar identifies changes despite v1 insertion.
    def signature(score):
        local=collections.Counter(); result={}
        for bar in score['bars']:
            local[bar['section']]+=1
            key=f"{bar['section']}:{local[bar['section']]:02d}"
            es=[e for e in score['events'] if e['bar']==bar['bar']]
            result[key]={'harmony':bar['harmony_name'],'lead':bar['lead_instrument'],'bpm':bar['bpm'],
              'macro_phrase_length_bars':bar['macro_phrase_length_bars'],
              'notes':[[round(e['onset']-bar['start'],6),e['duration'],e['pitch'],e['velocity'],e['instrument'],e['voice']] for e in es]}
        return result
    sa,sb=signature(a),signature(b)
    changes=[]
    for k in sorted(set(sa)|set(sb)):
        if sa.get(k)!=sb.get(k):changes.append({'location':k,'before':sa.get(k),'after':sb.get(k)})
    return {'from':a['version'],'to':b['version'],'bar_count_before':len(a['bars']),
      'bar_count_after':len(b['bars']),'changed_section_bars':len(changes),
      'note':'Exact normalized event records plus structural fields; unified JSON patch accompanies this file.',
      'changes':changes}

def main():
    scores=[]; audits=[]
    for version in range(3):
        score=make_score(version); report=audit(score)
        dump(OUT/f'score_v{version}.json',score); dump(OUT/f'audit_v{version}.json',report)
        scores.append(score); audits.append(report)
    for i in (0,1):
        dump(OUT/f'diff_v{i}_v{i+1}.json',compare(scores[i],scores[i+1]))
        old=(OUT/f'score_v{i}.json').read_text().splitlines(True)
        new=(OUT/f'score_v{i+1}.json').read_text().splitlines(True)
        (OUT/f'diff_v{i}_v{i+1}.patch').write_text(''.join(difflib.unified_diff(old,new,fromfile=f'score_v{i}.json',tofile=f'score_v{i+1}.json')),encoding='utf8')
    dump(OUT/'audit_summary.json',{'work_id':85,'all_versions_pass':all(a['status']=='PASS' for a in audits),
       'versions':[{'version':a['version'],'status':a['status'],'bars':a['bars'],
                    'duration_seconds':a['total_seconds_with_tail'],'issues':a['issues']} for a in audits]})
    files=sorted(p for p in OUT.iterdir() if p.is_file() and p.name not in ('sha256.json','delivery_manifest.json'))
    hashes={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
    dump(OUT/'sha256.json',hashes)
    dump(OUT/'delivery_manifest.json',{'id':85,'title':TITLE,'title_zh':'备用地平线',
      'status':'symbolic_only','final_score':'score_v2.json','final_score_sha256':hashes['score_v2.json'],
      'versions':['score_v0.json','score_v1.json','score_v2.json'],
      'audit_summary':'audit_summary.json','generator':'generate_score.py','deterministic':True,
      'forbidden_work_performed':[],'all_audits_pass':all(a['status']=='PASS' for a in audits)})
    print(json.dumps({'summary':[{'version':a['version'],'status':a['status'],'seconds':a['total_seconds_with_tail'],
      'events':a['events'],'issues':a['issues']} for a in audits],'final_sha256':hashes['score_v2.json']},ensure_ascii=False,indent=2))
    if any(a['status']!='PASS' for a in audits):raise SystemExit(1)

if __name__=='__main__':main()
