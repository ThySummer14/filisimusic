import pathlib,json,copy,collections,math
P=pathlib.Path(__file__).parent;original=json.loads((P/'revisions/score_full_v0.json').read_text());v=copy.deepcopy(original);v['stage']='full_v1_form_register_and_performance_review';changes=[]
bybar=collections.defaultdict(list)
for e in v['events']:bybar[e['bar']].append(e)
# Keep accompaniment below the intro melody; close wide lyrical chord voicings.
for b in v['bars']:
 es=bybar[b['bar']];mel=[e for e in es if e['voice']=='melody'];floor=min(e['pitch'] for e in mel)
 if b['role_plan']=='intro':
  for e in es:
   if e['voice']=='accompaniment':
    old=e['pitch']
    while e['pitch']>floor-3:e['pitch']-=12
    if old!=e['pitch']:changes.append({'bar':b['bar'],'voice':e['voice'],'from':old,'to':e['pitch'],'reason':'intro accompaniment stays beneath the sung lead instead of retriggering its keys'})
 if b['role_plan'] in ('lyric','cadenza'):
  group=[e for e in es if e['voice']=='accompaniment' and e['onset']-b['start']<1.1]
  if group:
   while max(e['pitch'] for e in group)-min(e['pitch'] for e in group)>12:
    low=min(group,key=lambda e:e['pitch']);old=low['pitch'];low['pitch']+=12;changes.append({'bar':b['bar'],'from':old,'to':low['pitch'],'reason':'close the rolled left-hand voicing; do not require a held tenth'})
 # Melody phrase arcs, not random note velocities.
 for i,e in enumerate(mel):
  ratio=i/max(1,len(mel)-1);arc=round(3*math.sin(math.pi*ratio))
  e['velocity']=min(109,e['velocity']+arc)
  if b['bar']%8==0 and i==len(mel)-1:e['velocity']-=5;e['duration']*=.97
 # Melody is nearly connected within phrases; the written rests remain intentional.
 for i,e in enumerate(mel[:-1]):
  next_on=mel[i+1]['onset'];nominal=e['duration']/.965
  if next_on-e['onset']-nominal<.05:e['duration']=(next_on-e['onset'])*.982
# Explicit physical-key cooperation. Prefer the principal melody to accompaniment overlap.
priority={'melody':4,'melody_octave':3,'bass':2,'accompaniment':1};by=collections.defaultdict(list)
for i,e in enumerate(v['events']):by[e['pitch']].append((i,e))
skip=set();fixes=[]
for pitch,seq in by.items():
 seq.sort(key=lambda a:a[1]['onset'])
 for (ia,a),(ib,b) in zip(seq,seq[1:]):
  if ia in skip or ib in skip:continue
  if a['onset']+a['duration']>b['onset']+.001:
   if priority[a['voice']]>priority[b['voice']]:skip.add(ib);fixes.append({'bar':b['bar'],'pitch':pitch,'action':'remove lower-priority retrigger','voice':b['voice']})
   else:
    old=a['duration'];a['duration']=max(.03,b['onset']-a['onset']-.025);fixes.append({'bar':b['bar'],'pitch':pitch,'action':'release physical key before new musical articulation','old_duration':old,'new_duration':a['duration']})
v['events']=[e for i,e in enumerate(v['events']) if i not in skip]
# Relation review logs the composer intent, not an aesthetic pass.
relations=[]
for b in v['bars']:
 es=[e for e in v['events'] if e['bar']==b['bar'] and e['voice']=='melody'];down=min(es,key=lambda e:e['onset']);pc={n%12 for n in b['harmony']};relations.append({'bar':b['bar'],'section':b['section'],'harmony':b['harmony_name'],'lead_downbeat':down['pitch'],'bass':b['harmony'][0],'lead_downbeat_chord_tone':down['pitch']%12 in pc})
(P/'revisions/score_full_v1.json').write_text(json.dumps(v,indent=2));(P/'score.json').write_text(json.dumps(v,indent=2));(P/'revisions/full_pass1.json').write_text(json.dumps({'scope':'Substantive full-form expansion and accompaniment/performance review','new_material':['16-bar contrasting lyrical theme and answering phrase, independently authored.','8-bar restitution/cadenza and8-bar newly composed coda.','Return and combined-theme section use new continuation/harmonic destination rather than tiling the63-second excerpt.'],'register_and_voicing_changes':changes,'physical_key_changes':fixes,'performance_changes':['Phrase-shaped dynamic arcs and deliberate phrase-end softening.','Connected note lengths inside the lead line; common breaths retained.','Root finger releases support playable hand movement; pedal retains resonance.'],'duration_seconds':sum(b['beats']*60/b['bpm'] for b in v['bars'])+v['tail_seconds']},indent=2));(P/'full_harmonic_relationship.json').write_text(json.dumps(relations,indent=2));print('Changes',len(changes),'physical-key fixes',len(fixes),'nonchord downbeats',sum(not r['lead_downbeat_chord_tone'] for r in relations))
