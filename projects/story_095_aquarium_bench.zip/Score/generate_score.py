#!/usr/bin/env python3
"""Work 095: deterministic original symbolic composition. No audio or imports of other scores."""
import argparse, copy, difflib, hashlib, json
from pathlib import Path
ROOT=Path(__file__).resolve().parent
PC={'C':0,'D':2,'E':4,'F':5,'G':7,'A':9,'B':11}
def midi(s):return 12*(int(s[-1])+1)+PC[s[0]]+s[1:-1].count('#')-s[1:-1].count('b')
def parse(s):
    seq=[(midi(t.split(':')[0]),float(t.split(':')[1])) for t in s.split()]
    assert abs(sum(w for p,w in seq)-4)<1e-8,s
    return seq

# All eighty bars are individually authored. Vertical bars delimit 4/4 bars.
# Four short cells recur as memories, with new continuations, not copied blocks.
LINES=[
 'G4:1 C5:1.5 Eb5:.5 D5:1 | C5:1 G4:1 Bb4:.5 A4:.5 G4:1 | Ab4:1 C5:1 F5:1 Eb5:1 | D5:1 B4:.5 C5:.5 D5:1 G4:1 | C5:1.5 Eb5:.5 G5:1 F5:1 | Eb5:1 D5:.5 C5:.5 Ab4:1 C5:1 | D5:1.5 F5:.5 Ab5:1 F5:1 | G5:1 F5:.5 D5:.5 B4:1 D5:1',
 'G4:.5 C5:1 Eb5:.5 D5:1 C5:1 | Bb4:1 G4:.5 Eb5:.5 D5:1 C5:1 | C5:.5 F5:1 Ab5:.5 G5:1 F5:1 | Eb5:1 C5:.5 Ab4:.5 C5:1 Eb5:1 | D5:1 F5:.5 Ab5:.5 G5:1 F5:1 | D5:1.5 B4:.5 G4:1 B4:1 | C5:1 G5:.5 Eb5:.5 D5:1 C5:1 | B4:1 D5:1 G5:1 D5:1',
 'Eb5:1 G5:.5 F5:.5 Eb5:1 D5:1 | C5:1.5 Bb4:.5 G4:1 C5:1 | F5:1 Ab5:.5 G5:.5 F5:1 C5:1 | Eb5:1.5 C5:.5 Ab4:1 C5:1 | Ab4:.5 C5:1 Eb5:.5 D5:1 C5:1 | D5:1 F5:1 Ab5:1 F5:1 | G5:1 D5:.5 B4:.5 C5:1 D5:1 | Eb5:1 D5:1 C5:2',
 'C5:1 Eb5:.5 G5:.5 F5:1 Eb5:1 | D5:1.5 F5:.5 Bb5:1 Ab5:1 | G5:1 Eb5:1 D5:.5 C5:.5 Bb4:1 | C5:1.5 Eb5:.5 Ab5:1 G5:1 | F5:1 Ab5:1 C6:1 Ab5:1 | F5:.5 D5:1 B4:.5 D5:1 G5:1 | G5:1 E5:1 D5:1 C5:1 | B4:1 D5:.5 F5:.5 E5:1 D5:1',
 'E5:1.5 G5:.5 D5:1 C5:1 | D5:1 B4:1 G4:1 D5:1 | C5:1 E5:.5 A5:.5 G5:1 E5:1 | F5:1.5 A5:.5 G5:1 F5:1 | E5:1 C5:.5 G4:.5 C5:1 E5:1 | F5:1 D5:1 A4:1 D5:1 | B4:1 D5:.5 G5:.5 F5:1 D5:1 | E5:1 G5:1 C6:1 G5:1',
 'A5:1 G5:.5 E5:.5 C5:1 E5:1 | F5:1 A5:1 C6:1 A5:1 | G5:1 E5:.5 C5:.5 D5:1 E5:1 | D5:1.5 F5:.5 A5:1 G5:1 | C5:1 E5:1 G5:1 E5:1 | E5:1 G#5:.5 B5:.5 A5:1 G#5:1 | A5:1 E5:1 C5:1 E5:1 | D5:1 B4:1 G4:2',
 'C5:.5 Eb5:1 G5:.5 F5:1 Eb5:1 | D5:1 F5:.5 Ab5:.5 G5:1 F5:1 | Eb5:1 C5:1 Ab4:.5 C5:.5 Eb5:1 | D5:1.5 B4:.5 G4:1 D5:1 | C5:1 Eb5:1 F5:.5 Eb5:.5 D5:1 | C5:1 Ab4:1 F4:1 Ab4:1 | G4:1 B4:.5 D5:.5 F5:1 D5:1 | G5:1 F5:1 D5:1 B4:1',
 'G4:.5 C5:1 Eb5:.5 F5:1 G5:1 | Ab5:1 G5:.5 Eb5:.5 C5:1 Eb5:1 | F5:1 C5:.5 Ab4:.5 C5:1 F5:1 | Eb5:1 C5:1 Ab4:1 Eb5:1 | D5:.5 F5:1 Ab5:.5 F5:1 D5:1 | B4:1 D5:.5 G5:.5 F5:1 D5:1 | Eb5:1 G5:1 C6:1 G5:1 | F5:1 D5:1 B4:1 D5:1',
 'G5:1 Eb5:.5 C5:.5 D5:1 Eb5:1 | F5:1 Ab5:.5 G5:.5 Eb5:1 C5:1 | D5:1 F5:1 Bb5:1 F5:1 | G5:1 Eb5:.5 D5:.5 C5:1 Bb4:1 | Ab4:1 C5:.5 Eb5:.5 F5:1 Eb5:1 | D5:1.5 F5:.5 Ab5:1 F5:1 | G5:1 F5:.5 D5:.5 B4:1 D5:1 | Eb5:1 D5:1 C5:2',
 'G4:1 C5:1.5 Eb5:.5 D5:1 | C5:1 G4:1 Bb4:1 C5:1 | Ab4:1 C5:1 F5:1 Eb5:1 | D5:1 B4:1 G4:1 D5:1 | Eb5:1 C5:1 Ab4:1 C5:1 | F5:1 D5:1 Ab4:1 D5:1 | B4:1 D5:1 G4:2 | C5:4',
]
HARM_ROWS=[
 'Cm Cm/Eb Fm G7 Cm Ab/C Dm7b5 G7',
 'Cm Cm/Eb Fm Ab/C Dm7b5 G7 Cm G7',
 'Eb Cm Fm Ab/C Ab/C Dm7b5 G7 Cm',
 'Cm Bb/D Eb Ab/C Fm G7 C G7',
 'C G7 Am/C F/C C Dm G7 C',
 'Am/C F/C C Dm C/E E7 Am/C G7',
 'Cm Dm7b5 Ab/C G7 Cm Fm G7 G7',
 'Cm Ab/C Fm Ab/C Dm7b5 G7 Cm G7',
 'Cm Fm Bb/D Eb Ab/C Dm7b5 G7 Cm',
 'Cm Cm/Eb Fm G7 Ab/C Dm7b5 G7 Cm',
]
HARM={
 'Cm':[48,51,55], 'Cm/Eb':[51,55,60], 'Fm':[53,56,60], 'Fm/C':[48,53,56],
 'Ab/C':[48,51,56], 'Ab/Eb':[51,56,60], 'Dm7b5':[50,53,56,60],
 'G7':[50,53,55,59], 'G7/F':[53,55,59,62], 'G7/D':[50,53,55,59],
 'Eb':[51,55,58], 'Eb/G':[55,58,63], 'Bb/D':[50,53,58],
 'C':[48,52,55], 'C/E':[52,55,60], 'C/G':[55,60,64],
 'Am/C':[48,52,57], 'Am/E':[52,57,60], 'F/C':[48,53,57],
 'F':[53,57,60], 'Dm':[50,53,57], 'Dm/F':[53,57,62],
 'E7':[52,56,59,62], 'E7/B':[47+12,52+12,56+12,62+12],
}
LABELS=['蓝光下先空出半个座位','试着把日期说完整','不是商量能否留下','闭馆广播盖住后半句','门外长椅的日光','他们谈搬走以后的星期二','口袋里还多一把钥匙','沿同一条走廊快步折返','取出的盒子换了携带方式','关上的门和没有改签的车票']
SECTIONS=[(1,8,'Prelude','蓝光下的见面','C minor'),(9,24,'A','离城日期','C minor'),
 (25,32,'Bridge','广播与门口','C minor to C major'),(33,48,'B','门外长椅','C major'),
 (49,56,'Retrace','那把柜门钥匙','C minor'),(57,72,'A2','带着盒子折返','C minor'),(73,80,'Coda','门外继续','C minor')]

# Pass one replaces the transitional conversation and the entire major answer.
# Pitch, written rhythm, inversions and accompaniment attacks all change.
V1_LINES={
25:'Eb5:1.5 G5:.5 F5:1 C5:1',26:'F5:1 D5:.5 Bb4:.5 D5:1 F5:1',
27:'G5:1.5 F5:.5 Eb5:1 Bb4:1',28:'Eb5:1 C5:1 Ab4:.5 C5:.5 Eb5:1',
29:'Ab5:1 F5:.5 C5:.5 F5:1 Ab5:1',30:'F5:1.5 D5:.5 B4:1 G4:1',
31:'E5:1 C5:.5 D5:.5 E5:1 G5:1',32:'F5:1 D5:1 B4:.5 D5:.5 G5:1',
33:'E5:1.5 G5:.5 A5:1 G5:1',34:'F5:1 D5:1 B4:1 G4:1',
35:'E5:.5 A5:1 G5:.5 E5:1 C5:1',36:'A5:1 G5:.5 F5:.5 E5:1 F5:1',
37:'G5:1.5 E5:.5 D5:1 C5:1',38:'A4:1 D5:.5 F5:.5 E5:1 D5:1',
39:'D5:1.5 G5:.5 F5:1 B4:1',40:'E5:1 D5:.5 C5:.5 G4:1 C5:1',
41:'E5:1.5 A5:.5 G5:1 E5:1',42:'A5:1 F5:1 C5:.5 F5:.5 A5:1',
43:'G5:.5 E5:1 D5:.5 C5:1 E5:1',44:'A5:1 F5:.5 D5:.5 E5:1 F5:1',
45:'G5:1.5 E5:.5 C5:1 E5:1',46:'B5:1 G#5:.5 E5:.5 G#5:1 A5:1',
47:'A5:1 G5:.5 E5:.5 C5:1 E5:1',48:'F5:1 D5:1 B4:1 G4:1',
}
V1_HARM={25:'Cm/Eb',27:'Eb/G',28:'Ab/Eb',29:'Fm/C',30:'G7/F',
33:'C/E',35:'Am/E',36:'F',37:'C/G',38:'Dm/F',40:'C/E',41:'Am/E',43:'C/E',44:'Dm/F',45:'C/G',47:'Am/E'}

# Pass two develops the key-return music: changed phrase ends, registers,
# displaced habanera accompaniment and a final low-register answer.
V2_LINES={
49:'Eb5:1 C5:.5 G4:.5 C5:1 D5:1',50:'F5:1.5 Ab5:.5 G5:1 D5:1',
51:'C5:1 Eb5:1 Ab5:.5 G5:.5 Eb5:1',52:'B4:1 D5:.5 F5:.5 G5:1 F5:1',
53:'Eb5:1.5 G5:.5 F5:1 Eb5:1',54:'C5:1 Ab4:.5 F4:.5 Ab4:1 C5:1',
55:'B4:.5 D5:1 F5:.5 D5:1 G4:1',56:'D5:1 B4:1 G4:1 D5:1',
57:'G4:.5 C5:1 Eb5:.5 D5:.5 Eb5:.5 G5:1',58:'Ab5:1.5 G5:.5 Eb5:1 C5:1',
59:'C5:1 F5:.5 Ab5:.5 G5:1 F5:1',60:'Eb5:1.5 C5:.5 Ab4:1 Eb5:1',
61:'Ab5:1 F5:.5 D5:.5 C5:1 D5:1',62:'D5:.5 G5:1 F5:.5 D5:1 B4:1',
63:'G5:1.5 C6:.5 Bb5:1 G5:1',64:'F5:1 D5:.5 B4:.5 D5:1 G5:1',
65:'Eb5:1 G5:.5 C6:.5 Bb5:1 G5:1',66:'Ab5:1 F5:1 C5:.5 Eb5:.5 F5:1',
67:'F5:.5 Bb5:1 Ab5:.5 F5:1 D5:1',68:'G5:1.5 Eb5:.5 D5:1 Bb4:1',
69:'C5:1.5 Eb5:.5 Ab5:1 G5:1',70:'F5:1 D5:.5 C5:.5 Ab4:1 D5:1',
71:'B4:1 D5:1 F5:.5 D5:.5 G4:1',72:'C5:1 G4:.5 Eb4:.5 G4:1 C5:1',
73:'Eb5:1.5 D5:.5 C5:1 G4:1',74:'G4:1 Bb4:.5 C5:.5 Eb5:1 C5:1',
75:'C5:1.5 Ab4:.5 F4:1 Ab4:1',76:'B4:1 D5:.5 F5:.5 D5:1 G4:1',
77:'C5:1 Eb5:1 Ab4:1 C5:1',78:'D5:1.5 F5:.5 Ab4:1 D5:1',
79:'D5:1 B4:1 G4:2',80:'C5:4',
}
V2_HARM={49:'Cm/Eb',51:'Ab/Eb',53:'Cm/Eb',54:'Fm/C',55:'G7/F',
57:'Cm/Eb',58:'Ab/Eb',59:'Fm/C',60:'Ab/Eb',62:'G7/F',63:'Cm/Eb',
65:'Cm/Eb',66:'Fm/C',67:'Bb/D',68:'Eb/G',69:'Ab/Eb',72:'Cm',74:'Cm/Eb',75:'Fm/C',77:'Ab/Eb'}

def dumps(x):return json.dumps(x,ensure_ascii=False,indent=2)+'\n'
def save(root,n,x):(root/n).write_text(dumps(x),encoding='utf-8')
def sec(bars,t):return sum(min(max(t-b['start'],0),b['beats'])*60/b['bpm'] for b in bars)
def section(n):return next(x for x in SECTIONS if x[0]<=n<=x[1])
def bpm(n):
    if n<=8:return [90,92,94,92,94,96,94,90][n-1]
    if n<=24:return 98 if n%8 not in (0,7) else 94
    if n<=32:return [98,100,100,98,96,92,94,92][n-25]
    if n<=48:return 96 if n%8 not in (0,7) else 92
    if n<=56:return 100 if n%4 not in (0,) else 96
    if n<=72:return 98 if n%8 not in (0,7) else 94
    return [94,94,92,92,90,88,84,80][n-73]
def fingermap(keys,hand):
    fs={1:[3],2:[1,5],3:[1,3,5],4:[1,2,4,5],5:[1,2,3,4,5]}[len(keys)]
    if len(keys)==4:
        widest=max(range(3),key=lambda i:keys[i+1]-keys[i])
        fs=([1,3,4,5],[1,2,4,5],[1,2,3,5])[widest]
    return dict(zip(keys,fs if hand=='right' else [6-f for f in fs]))
def build(version):
    lv=int(version[1:]);mel=[s.strip() for row in LINES for s in row.split('|')];harm=[h for row in HARM_ROWS for h in row.split()]
    assert len(mel)==len(harm)==80
    for level,mm,hh in [(1,V1_LINES,V1_HARM),(2,V2_LINES,V2_HARM)]:
        if lv>=level:
            for n,v in mm.items():mel[n-1]=v
            for n,v in hh.items():harm[n-1]=v
    bars=[];events=[];plans=[];ped=[]
    for n in range(1,81):
        _,_,sect,stitle,key=section(n);start=(n-1)*4;pid=f'P{(n-1)//8+1:02d}';label=LABELS[(n-1)//8];h=harm[n-1];ch=HARM[h]
        texture='habanera_shared_pulse'
        if 33<=n<=48:texture='major_open_two_gestures'
        if lv>=1 and 25<=n<=32:texture='broadcast_interrupted_support'
        if lv>=1 and 33<=n<=48:texture='major_crossbeat_answer'
        if 49<=n<=56:texture='key_search_fragments'
        if lv>=2 and 57<=n<=72:texture='developed_habanera_reply'
        if n>=73:texture='spare_cadential_shell'
        if lv>=2 and n>=73:texture='lowered_coda_exchange'
        cello_active=(n%4 in (1,2) if n<33 or 49<=n<=72 else n%4==1)
        if lv>=1 and 25<=n<=32:cello_active=n in (25,28,31)
        if lv>=2 and 49<=n<=56:cello_active=n in (49,52,55)
        if lv>=2 and 57<=n<=72:cello_active=n in (57,59,62,65,68,71)
        if n==80:cello_active=True
        b={'bar':n,'start':float(start),'beats':4.0,'bpm':bpm(n),'meter':'4/4','meter_numerator':4,'meter_denominator':4,
           'section':sect,'section_title_zh':stitle,'harmony_name':h,'harmony':ch,'lead_instrument':'piano','lead_hand':'right',
           'key_region':key,'phrase_id':pid,'phrase_position':(n-1)%8+1,'metrical_grouping':'3+1+2+2 eighths, relaxed within 4/4',
           'texture':texture,'cello_active':cello_active,
           'role_plan':'Singing piano right hand; low cello gives sparse chord-bound anchors, while the higher piano left hand supplies the displaced dance steps.'}
        bars.append(b)
        def add(p,at,dur,vel,inst,voice,hand,role,written=None):
            e={'bar':n,'onset':round(start+at,6),'duration':round(dur,6),'pitch':p,'velocity':vel,'instrument':inst,'voice':voice,'hand':hand,'role':role,
               'phrase_id':pid+'_'+inst,'phrase_label':label,'harmony_name':h,'harmonic_function':'chord_tone' if p%12 in {q%12 for q in ch} else 'melodic_nonchord_tone',
               'written_value_beats':written if written is not None else dur}
            events.append(e);return e
        energy=67 if n<=8 else 74 if n<=24 else 72 if n<=32 else 72 if n<=48 else 71 if n<=56 else 79 if n<=72 else 66
        quiet=40 if n<33 else 38 if n<=48 else 39 if n<=56 else 43 if n<=72 else 34
        t=0;seq=parse(mel[n-1])
        for j,(p,w) in enumerate(seq):
            gap=.42 if j==len(seq)-1 else .24
            if n==80:gap=0
            e=add(p,t,w-gap,energy+[2,-1,1,-2,0,-3][j%6],'piano','melody','right','lead',w)
            e['articulation']='singing_portato_with_real_key_release';e['melody_cell']='rising_4th_then_minor3rd' if n in (1,9,57,73) else 'authored_sentence_continuation';t+=w
        # Cello is always one authentic mf sample layer; velocity means gain.
        if cello_active:
            rootpc={'Cm':0,'Fm':5,'Ab':8,'Dm7b5':2,'G7':7,'Eb':3,'Bb':10,'C':0,'Am':9,'F':5,'Dm':2,'E7':4}[h.split('/')[0]]
            if '/' in h:rootpc={'C':0,'D':2,'Eb':3,'E':4,'F':5,'G':7,'B':11}[h.split('/')[1]]
            pitch=36+rootpc
            at=0 if n%4!=0 else 2.5
            if n==80:at=0
            ce=add(pitch,at,.34,48+(n%3)*3,'cello','cello_pizzicato','not_applicable','harmonic_support',.5)
            ce.update({'layer':'mf','sample_layer':'mf','source_family':'University of Iowa cello pizzicato','source_pitch_midi':pitch,
              'velocity_controls':'amplitude_variation_within_one_recorded_mf_layer','articulation':'pizzicato_short_separate',
              'onset_reference':'ordinary_trigger','timing_correction_applied_seconds':0.0,'nominal_gate_seconds':round(.34*60/bpm(n),9),
              'phrase_breath':'Unplayed bars and long physical gaps belong to the phrase; no bowed legato, artificial layer or repeated filler bass.'})
        # Every piano support pitch is physically above MIDI47 and within the named chord.
        low=ch[0];upper=ch[1:];shell=[ch[0],ch[-1]]
        gestures=[]
        if texture=='habanera_shared_pulse':
            if not cello_active:gestures.append((0,.65,[low]))
            gestures += [(1.5,.26,[upper[0]]),(2,.64,[low,upper[-1]]),(3,.54,upper)]
        elif texture=='broadcast_interrupted_support':
            if not cello_active:gestures.append((0,.56,[low]))
            gestures += [(1.5,.24,upper),(2.5,.42,[low]),(3.25,.30,[upper[-1]])]
        elif texture=='major_open_two_gestures':gestures=[(.5,1.1,shell),(2.5,.8,upper)]
        elif texture=='major_crossbeat_answer':
            gestures=[(.75,.86,shell),(2.25,.40,[upper[0]]),(3,.48,upper)]
        elif texture=='key_search_fragments':
            if not cello_active:gestures.append((0,.4,[low]))
            gestures += [(1.5,.26,[upper[-1]]),(2.5,.44,shell)]
        elif texture=='developed_habanera_reply':
            if not cello_active:gestures.append((0,.54,[low]))
            gestures += [(1.5,.24,[upper[-1]]),(2,.50,shell),(3.25,.30,upper)]
        elif texture=='lowered_coda_exchange':gestures=[(.75,.80,shell),(2.5,.60,upper)]
        else:gestures=[(.5,1.25,shell),(2.5,.80,upper)]
        if n==80:gestures=[(.5,2.95,ch)]
        for at,dur,keys in gestures:
            # Leave at least .45 beats either side of any active cello attack.
            if cello_active and abs(at-(0 if n%4 else 2.5))<.45 and n!=80:continue
            for p in keys:
                e=add(p,at,dur,quiet+(1 if len(keys)==1 else 0),'piano','harmonic_support','left','support',dur+.2)
                e['articulation']='short_dance_support' if n<73 else 'released_cadential_chord'
        for hand in ('left','right'):
            ns=[e for e in events if e['bar']==n and e['hand']==hand];keys=sorted({e['pitch'] for e in ns});fmap=fingermap(keys,hand)
            assert len(keys)<=5 and keys[-1]-keys[0]<=12,(version,n,hand,keys)
            pos={'bar':n,'hand':hand,'position_id':f'b{n:03d}_{hand}','active':True,'range':[keys[0],keys[-1]],
                 'pitch_finger_map':{str(p):f for p,f in fmap.items()},'grip_strategy':'One ordered physical grip per bar; complete release before each subsequent attack, measured from actual held keys.'}
            plans.append(pos)
            for e in ns:e.update({'finger':fmap[e['pitch']],'hand_position_id':pos['position_id'],'hand_position_range':pos['range'],'position_keys':keys})
        ped += [{'bar':n,'onset':float(start),'controller':64,'value':0,'instrument':'piano'},
                {'bar':n,'onset':start+.08,'controller':64,'value':24 if n<33 or n>48 else 30,'instrument':'piano'},
                {'bar':n,'onset':start+3.40,'controller':64,'value':0,'instrument':'piano'}]
    ped.append({'bar':80,'onset':320.0,'controller':64,'value':0,'instrument':'piano'})
    # Reserve real transfer time at EVERY attack, including unchanged grips.
    # Travel is the max of grip edges, all actually held-to-new key movements,
    # and declared whole-position edges when the declared position changes.
    hp={(p['bar'],p['hand']):p for p in plans}
    for hand in ('left','right'):
        times=sorted({e['onset'] for e in events if e['hand']==hand})
        for a,z in zip(times,times[1:]):
            old=[e for e in events if e['hand']==hand and e['onset']==a];new=[e for e in events if e['hand']==hand and e['onset']==z]
            oldkeys=[e['pitch'] for e in old];newkeys=[e['pitch'] for e in new]
            op=hp[(old[0]['bar'],hand)];np=hp[(new[0]['bar'],hand)]
            edge=max(abs(min(oldkeys)-min(newkeys)),abs(max(oldkeys)-max(newkeys)))
            # Conservatively cover every old-to-new physical key path, even
            # when different fingers play it. A convenient grip center or
            # relabelled finger cannot make a wide transfer disappear.
            movement=max(abs(p-q) for p in oldkeys for q in newkeys)
            position=max(abs(x-y) for x,y in zip(op['range'],np['range'])) if op['position_id']!=np['position_id'] else 0
            travel=max(edge,movement,position);required=.075+.012*max(0,travel-4)+.012
            limit_seconds=sec(bars,z)-required
            # Convert once with the old event's local tempo; no bar-crossing notes.
            for e in old:
                if sec(bars,e['onset']+e['duration'])>limit_seconds:
                    e['duration']=round((limit_seconds-sec(bars,e['onset']))*bars[e['bar']-1]['bpm']/60,6)
                    assert e['duration']>.07,(version,e)
                    e['release_adjustment']='Real key gate shortened for whole-grip/held-key travel plus 12 ms margin; pedal never participates.'
    events.sort(key=lambda e:(e['onset'],e['instrument'],e['hand'],e['pitch'],e['voice']))
    counter={}
    for e in events:
        k=(e['bar'],e['instrument'],e['voice']);counter[k]=counter.get(k,0)+1;e['event_id']=f'w95-b{e["bar"]:03d}-{e["instrument"]}-{e["voice"]}-{counter[k]:02d}'
        e.update({'target_on_beats':e['onset'],'target_off_beats':round(e['onset']+e['duration'],6),'target_on_seconds':round(sec(bars,e['onset']),9),'target_off_seconds':round(sec(bars,e['onset']+e['duration']),9)})
    phrases=[]
    for k in range(10):
        for inst in ('piano','cello'):
            pid=f'P{k+1:02d}_{inst}';ns=[e for e in events if e['phrase_id']==pid]
            if not ns:continue
            a=min(e['onset'] for e in ns);z=max(e['onset']+e['duration'] for e in ns)
            phrases.append({'phrase_id':pid,'instrument':inst,'phrase_label':LABELS[k],'first_bar':k*8+1,'last_bar':k*8+8,'section':bars[k*8]['section'],
              'role':'harmonic_support' if inst=='cello' else 'lead_and_support','layer':'mf' if inst=='cello' else 'not_applicable',
              'layers_used':['mf'] if inst=='cello' else [],'roles_used':sorted({e['role'] for e in ns}),'voices_used':sorted({e['voice'] for e in ns}),
              'target_on_beats':a,'target_off_beats':round(z,6),'target_on_seconds':round(sec(bars,a),9),'target_off_seconds':round(sec(bars,z),9),
              'timing_intent':'Eight independently composed 4/4 bars; piano owns the foreground. Cello punctuation leaves several bars or beats to breathe.'})
    return {'id':95,'title':'The Blue Bench After Closing','title_zh':'闭馆后的蓝色长椅','version':version,
      'instrumentation':['natural_acoustic_piano','short_pizzicato_cello_single_mf_layer'],'bars':bars,'events':events,'phrases':phrases,'pedals':ped,
      'total_beats':320.0,'tail_seconds':4.0,'hand_position_plan':plans,
      'performance_contract':{'audio_status':'Symbolic only. No audio, DSP, sample acquisition, downloads, installation or listening performed.',
       'beat_unit':'Absolute quarter-note beats; every 4/4 bar contains four; all BPM refer to quarters.',
       'foreground':'One nonoverlapping right-hand piano melody; cello and left hand are chord-bound sparse support.',
       'maximum_held_span_semitones':12,'left_hand_minimum_midi':48,
       'position_transfer_rule':'At every hand attack: max(actual grip-edge displacement, maximum old-to-new held-key displacement, whole-position-edge displacement when changed). Minimum 75 ms of full real release plus 12 ms per semitone above four. No melodic exemption or center-distance shortcut.',
       'same_key_overlaps':'Forbidden across all piano voices and hands; no crossings or finger collisions.',
       'pedal':'Resonance only. Physical key releases and complete transfer windows are audited independently of CC64.',
       'cello':'Only existing authentic MIDI36–47 pizzicato mf recordings. Exactly one recorded mf layer. Velocity is amplitude variation, never pp/ff source invention. Short individual triggers, no bowed or fake legato claim.',
       'musical_limits':'Saved-file symbolic audit is not listening acceptance, acoustic balance proof or performer comfort certification. Owner must verify actual sample attack/release and later audio integration.'}}

def patch(a,b,path=''):
    if a==b:return []
    if isinstance(a,dict) and isinstance(b,dict):
        out=[]
        for k in sorted(set(a)|set(b)):
            p=path+'/'+k.replace('~','~0').replace('/','~1')
            if k not in b:out.append({'op':'remove','path':p})
            elif k not in a:out.append({'op':'add','path':p,'value':b[k]})
            else:out+=patch(a[k],b[k],p)
        return out
    return [{'op':'replace','path':path,'value':b}]
def emit_diff(root,a,b):
    before=dumps(a);after=dumps(b);av=a['version'];bv=b['version'];changes=[]
    for n in range(1,81):
        row={'bar':n,'before_bar':a['bars'][n-1],'after_bar':b['bars'][n-1],
             'before_events':[e for e in a['events'] if e['bar']==n],'after_events':[e for e in b['events'] if e['bar']==n],
             'before_pedals':[e for e in a['pedals'] if e['bar']==n],'after_pedals':[e for e in b['pedals'] if e['bar']==n]}
        if any(row['before_'+k]!=row['after_'+k] for k in ('bar','events','pedals')):changes.append(row)
    save(root,f'exact_diff_{av}_to_{bv}.json',{'from_version':av,'to_version':bv,'before_sha256':hashlib.sha256(before.encode()).hexdigest(),'after_sha256':hashlib.sha256(after.encode()).hexdigest(),
      'changed_bars':[r['bar'] for r in changes],'changes':changes,'phrase_metadata_before':a['phrases'],'phrase_metadata_after':b['phrases'],
      'position_plan_before':a['hand_position_plan'],'position_plan_after':b['hand_position_plan'],'json_patch':patch(a,b)})
    (root/f'exact_diff_{av}_to_{bv}.patch').write_text(''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile=f'score_{av}.json',tofile=f'score_{bv}.json')),encoding='utf-8')
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--outdir',default=str(ROOT));args=ap.parse_args();root=Path(args.outdir);root.mkdir(parents=True,exist_ok=True)
    ss=[build(v) for v in ('v0','v1','v2')]
    for s in ss:save(root,f'score_{s["version"]}.json',s)
    save(root,'score.json',ss[-1]);emit_diff(root,ss[0],ss[1]);emit_diff(root,ss[1],ss[2])
if __name__=='__main__':main()
