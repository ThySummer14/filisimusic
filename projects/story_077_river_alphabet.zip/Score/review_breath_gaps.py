from pathlib import Path
import json,wave,numpy as np
P=Path(__file__).parent;d=json.loads((P/'ensemble_score.json').read_text());result={}
for inst in ['clarinet']:
 phrases=sorted([p for p in d['phrases'] if p['instrument']==inst],key=lambda p:p['actual_trigger_start_seconds']);rows=[]
 with wave.open(str(P/f'revisions/diagnostic_{inst}_v3.wav'),'rb') as w:
  sr=w.getframerate()
  for a,b in zip(phrases,phrases[1:]):
   begin=a['actual_noteoff_end_seconds'];end=b['actual_trigger_start_seconds'];assert end>begin
   w.setpos(round(begin*sr));raw=w.readframes(round((end-begin)*sr));q=np.frombuffer(raw,dtype=np.uint8).reshape(-1,3);v=q[:,0].astype(np.int32)|(q[:,1].astype(np.int32)<<8)|(q[:,2].astype(np.int32)<<16);x=np.where(v&0x800000,v-0x1000000,v).reshape(-1,2).astype(float)/8388608;n=len(x)//441;rms=np.sqrt(np.mean(x[:n*441].reshape(n,441,2)**2,axis=(1,2)));run=best=0
   for quiet in rms<1e-4:run=run+1 if quiet else 0;best=max(best,run)
   rows.append({'after':a['phrase_id'],'before':b['phrase_id'],'actual_gate_gap_seconds':end-begin,'longest_post_room_rms_below_minus80_dbfs_seconds':best*.01})
 result[inst]={'gaps':rows,'minimum_low_level_interval_seconds':min(x['longest_post_room_rms_below_minus80_dbfs_seconds'] for x in rows)}
result['method']='Actual isolated native buses including room;10ms RMS below-80dBFS between phrase gate windows. Objective low-level interval only, not perceived silence or human listening.'
(P/'revisions/native_breath_gaps_v3.json').write_text(json.dumps(result,indent=2));print({i:result[i]['minimum_low_level_interval_seconds'] for i in ['clarinet']})
