from pathlib import Path
import json,struct,numpy as np,math
p=Path(__file__).parent;s=json.loads((p/'ensemble_score.json').read_text());data={};sr=44100
for instrument in ['piano','cello']:
 b=(p/f'revisions/{instrument}_v2.wav').read_bytes();i=12
 while i<len(b):
  name=b[i:i+4];n=struct.unpack_from('<I',b,i+4)[0]
  if name==b'data':a=np.frombuffer(b[i+8:i+8+n],dtype='<f4').reshape(-1,2).copy()
  i+=8+n+(n%2)
 data[instrument]=a
rows=[];t=0
for bar in s['bars']:
 end=t+bar['beats']*60/bar['bpm'];row={'bar':bar['bar'],'lead':bar['lead_instrument'],'section':bar['section'],'start':t,'end':end}
 for instrument,a in data.items():
  x=a[round(t*sr):round(end*sr)];row[instrument+'_rms']=float(np.sqrt(np.mean(x.astype('float64')**2)))
 rows.append(row);t=end
for leader in ['piano','cello']:
 rs=[x for x in rows if x['lead']==leader];print(leader,{i:float(np.mean([x[i+'_rms'] for x in rs])) for i in data})
last=max(float(np.flatnonzero(np.max(np.abs(a),axis=1)>2e-6)[-1]/sr) for a in data.values());out={'per_bar':rows,'last_activity_seconds':last,'render_end':round(min(len(a)/sr,last+.7),2),'method':'Numerical source RMS and cadence/tail checks; not auditory quality approval'};(p/'source_role_balance.json').write_text(json.dumps(out,indent=2));print(last,out['render_end'])
