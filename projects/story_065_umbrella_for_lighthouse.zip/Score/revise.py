from pathlib import Path
import json
P=Path(__file__).parent;d=json.loads((P/'revisions/score_v0.json').read_text())
def line_at(bar,line):
 b=d['bars'][bar-1];d['events']=[e for e in d['events'] if not(e['bar']==bar and e['voice']=='melody')];off=0
 for n,l in line:
  if n>=0:d['events'].append(dict(bar=bar,onset=b['start']+off,duration=l*.95,pitch=n,velocity=86,voice='melody'))
  off+=l
 assert off==4
S=[[(83,1),(81,.5),(79,.5),(76,1),(79,.5),(83,.5)],[(86,.5),(83,.5),(79,1),(78,.5),(79,.5),(83,1)],[(81,1.5),(85,.5),(88,1),(85,.5),(81,.5)],[(82,.5),(85,.5),(88,.5),(90,.5),(88,1),(85,1)],[(86,1),(83,.5),(78,.5),(74,.5),(78,.5),(83,1)],[(81,.5),(78,.5),(74,1),(78,.5),(81,.5),(86,1)],[(83,1),(79,.5),(76,.5),(74,.5),(76,.5),(79,1)],[(82,.5),(78,.5),(73,1),(70,1),(-1,1)]]
L=[[(74,.5),(76,.5),(78,2),(76,.5),(74,.5)],[(73,1),(74,.5),(78,.5),(81,1),(78,1)],[(79,1.5),(74,.5),(71,1),(67,1)],[(76,.5),(79,.5),(83,1),(81,1),(79,1)],[(78,.5),(74,.5),(71,1),(73,.5),(74,.5),(78,1)],[(79,1),(78,.5),(76,.5),(74,1),(-1,1)],[(76,.5),(73,.5),(70,1),(73,.5),(76,.5),(82,1)],[(83,1.5),(78,.5),(74,1),(-1,1)]]
K=[[(79,.5),(78,.5),(76,1),(83,1),(79,1)],[(74,.5),(79,.5),(83,1.5),(81,.5),(79,1)],[(81,.5),(78,.5),(76,1),(73,.5),(76,.5),(81,1)],[(82,.5),(85,.5),(88,2),(85,1)],[(83,1),(86,.5),(88,.5),(86,1),(83,1)],[(81,.5),(78,.5),(74,.5),(78,.5),(81,1),(86,1)],[(83,1.5),(79,.5),(76,1),(74,1)],[(82,1),(78,.5),(73,.5),(70,1),(-1,1)]]
for j,x in enumerate(S):line_at(29+j,x)
for j,x in enumerate(L):line_at(45+j,x)
for j,x in enumerate(K):line_at(61+j,x)
# Three lights receive three different four-bar answers, rather than another literal loop.
for bar,line in [(101,[(83,1),(78,.5),(75,.5),(71,1),(75,1)]),(102,[(80,.5),(83,.5),(87,1),(85,.5),(83,.5),(80,1)]),(103,[(82,1),(78,.5),(73,.5),(70,.5),(73,.5),(78,1)]),(104,[(83,2),(78,1),(-1,1)])]:line_at(bar,line)
d['stage']='v1_new_storm_listening_and_light_continuations';(P/'revisions/score_v1.json').write_text(json.dumps(d,indent=2));(P/'revisions/pass1.json').write_text(json.dumps({'round':1,'kind':'substantive_composition_revision','changes':['Replace the second storm8-bar phrase with a different ascent and a withdrawing dominant answer.','Write a new second listening stanza, making the signal recognizable through calmer note ordering rather than repeating the same8bars.','Give the decoding section a new final8-bar route and the third light a distinct four-bar answer.']},indent=2))
# Performance revision: let sustained melody carry the energy, and place accompaniment below it.
arc=[-2,0,2,-1,1,3,1,-4];removed=0
for b in d['bars']:
 k=b['role_plan'];j=b['phrase_position'];base={'intro':75,'signal':85,'storm':91,'listen':69,'decode':83,'break':94,'lights':88,'coda':73}[k]
 notes=[e for e in d['events'] if e['bar']==b['bar'] and e['voice']=='melody'];last=max(e['onset']+e['duration'] for e in notes);breath=last<b['start']+3.3
 for e in [e for e in d['events'] if e['bar']==b['bar']]:
  off=e['onset']-b['start']
  if e['voice']=='melody':e['velocity']=base+arc[j%8]+(2 if e['duration']>1.3 else 0);e['duration']*=1.025 if e['duration']>1.3 else .97
  else:
   e['velocity']=base-(25 if e['voice']=='bass' else 37)+arc[j%8]//2
   if off==2:e['velocity']+=2
   if breath and off>=3:e['remove']=True;removed+=1
   if k=='listen':e['duration']=.80
  e['velocity']=max(25,min(99,e['velocity']))
 # Don't restart a pedal at a melody's final silence.
 if breath:d['pedals']=[x for x in d['pedals'] if not(b['start']+3<=x['onset']<b['start']+4 and x['value']>0)]
d['events']=[e for e in d['events'] if not e.pop('remove',False)];d['events'].sort(key=lambda e:(e['onset'],e['pitch']));d['stage']='v2_phrase_energy_and_coordinated_support'
for f in ['score.json','revisions/score_v2.json']:(P/f).write_text(json.dumps(d,indent=2))
(P/'revisions/pass2.json').write_text(json.dumps({'round':2,'kind':'substantive_performance_revision','changes':['Shape eight-bar intensity arcs, accent the long melodic answer rather than every eighth note, and keep inner arpeggios distinctly subordinate.','Withdraw the final supporting eighths at explicit melodic breaths; keep the listening section connected instead of abandoning motion.','Limit extreme velocity while retaining a clear storm-to-listening contrast.'],'support_notes_removed_at_breaths':removed,'human_listening_review':False},indent=2))
