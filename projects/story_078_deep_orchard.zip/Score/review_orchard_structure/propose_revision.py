#!/usr/bin/env python3
"""Isolated score review proposal; reads v2, writes only this review directory.

No imports from the canonical generator, rendering, dependencies or audio.
All onset/duration units are quarter-note beats (each 9/8 bar = 4.5).
"""
from pathlib import Path
from collections import defaultdict
import copy, difflib, hashlib, json

OUT = Path(__file__).resolve().parent
SOURCE = OUT.parent
SOURCE_FILES = sorted(p for p in SOURCE.iterdir() if p.is_file())

def hashes():
    return {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in SOURCE_FILES}

before = hashes()
old = json.loads((SOURCE / 'score_v2.json').read_text())
new = copy.deepcopy(old)
changes = []

# One third-group thinning, followed by a two-eighth-note space under held F5.
# Keep the complete C diminished harmony before the thinning; it includes A3.
removed = []
kept = []
for e in new['events']:
    t = round(e['onset'] - (e['bar'] - 1) * 4.5, 4)
    drop = e['voice'] == 'accompaniment' and (
        (e['bar'] == 31 and t in (3.0, 3.5, 4.0)) or
        (e['bar'] == 32 and t in (0.5, 1.0)))
    (removed if drop else kept).append(e)
new['events'] = kept
new['pedals'].append({'onset': 30 * 4.5 + 3.0, 'value': 0})
changes.append({'purpose': 'Light interrupted, then restored',
                'bars': [31, 32], 'removed_accompaniment_events': removed,
                'added_pedal_off': 138.0,
                'melody_unchanged': True, 'harmony_pitches_before_thinning_unchanged': True})

# The virtual sustain carries these released keys while the hand returns.
# A 0.18-beat gate frees 0.32 beat before the next downbeat. This is a practical
# indication, not a claim that a numerical gap proves pianistic execution.
relocations = []
for b in old['bars'][:-1]:
    n = b['bar']
    left = [e for e in old['events'] if e['bar'] == n and e['voice'] in ('bass', 'accompaniment')]
    last = max(left, key=lambda e: e['onset'])
    first = next(e for e in old['events'] if e['bar'] == n + 1 and
                 e['voice'] == 'bass' and e['onset'] == n * 4.5)
    interval = abs(first['pitch'] - last['pitch'])
    if interval < 20:
        continue
    match = next((e for e in new['events'] if e['bar'] == n and
                  e['onset'] == last['onset'] and e['pitch'] == last['pitch'] and
                  e['voice'] == last['voice']), None)
    if match is None:
        continue
    match['duration'] = 0.18
    relocations.append({'bar': n, 'following_bar': n + 1,
        'last_pitch': last['pitch'], 'next_bass_pitch': first['pitch'],
        'interval_semitones': interval, 'old_duration_beats': last['duration'],
        'proposed_duration_beats': 0.18,
        'old_release_to_arrival_seconds': round((0.5-last['duration'])*60/b['bpm'], 4),
        'proposed_release_to_arrival_seconds': round(0.32*60/b['bpm'], 4)})
changes.append({'purpose': 'Free the left hand for large returning leaps', 'relocations': relocations})

# Keep the intended anticipated tonic in the melody and the later bass landing.
# Db4 remains finger-held during this change; previous F4/Eb4/Bb3 are released.
new['pedals'] += [
    {'onset': 63 * 4.5 + 2.90, 'value': 0},
    {'onset': 63 * 4.5 + 3.08, 'value': 78},
]
changes.append({'purpose': 'Clear the final delayed bass arrival', 'bar': 64,
                'pedal_off_position': 2.90, 'pedal_on_position': 3.08,
                'all_note_attacks_pitches_and_durations_unchanged_in_bar': True})
new['pedals'].sort(key=lambda e: e['onset'])

def examine(score):
    errors = []
    sweep = []
    for i, e in enumerate(score['events']):
        b = score['bars'][e['bar']-1]
        if not (b['start'] <= e['onset'] < b['start']+4.5 and
                e['duration'] > 0 and e['onset']+e['duration'] <= 288):
            errors.append(['bad_note_bounds', i])
        sweep += [(round(e['onset'], 6), 1, i),
                  (round(e['onset']+e['duration'], 6), 0, i)]
    held = {}
    spans = {'left': 0, 'right': 0}
    max_polyphony = 0
    for t, kind, i in sorted(sweep):
        e = score['events'][i]
        if kind == 0:
            held.pop(i, None)
        else:
            if any(n['pitch'] == e['pitch'] for n in held.values()):
                errors.append(['same_key_overlap', t, e['pitch']])
            held[i] = e
        max_polyphony = max(max_polyphony, len(held))
        for hand, voices in [('left', ('bass','accompaniment')), ('right', ('melody','upper_support'))]:
            keys = [n['pitch'] for n in held.values() if n['voice'] in voices]
            span = max(keys)-min(keys) if keys else 0
            spans[hand] = max(spans[hand], span)
            if span > 12:
                errors.append(['hand_span_over_octave', t, hand, keys])
    if score['pedals'] != sorted(score['pedals'], key=lambda e:e['onset']):
        errors.append('unsorted_pedals')
    if score['pedals'][-1]['value'] != 0:
        errors.append('final_pedal_not_off')
    return {'errors': errors, 'static_checks_passed': not errors,
            'note_count': len(score['events']), 'max_simultaneous_finger_span_semitones': spans,
            'max_polyphony_excluding_pedal': max_polyphony,
            'seconds_including_tail': round(sum(b['beats']*60/b['bpm'] for b in score['bars'])+score['tail_seconds'],4)}

NAMES = ['C','Db','D','Eb','E','F','Gb','G','Ab','A','Bb','B']
def note(p):
    return NAMES[p%12] + str(p//12-1)

def readable(score):
    out = []
    for b in score['bars']:
        out.append(f"BAR {b['bar']:02d} | {b['harmony_name']} | quarter={b['bpm']} | {b['section']}\n")
        entries = []
        for e in score['events']:
            if e['bar'] == b['bar']:
                t = e['onset']-b['start']
                entries.append((t, 1, f"  {e['voice']:13} pos={t:4.2f} dur={e['duration']:5.3f} {note(e['pitch']):4} vel={e['velocity']:2d}\n"))
        for p in score['pedals']:
            if b['start'] <= p['onset'] < b['start']+4.5:
                t = p['onset']-b['start']
                entries.append((t, 0, f"  pedal         pos={t:4.2f} value={p['value']}\n"))
        out.extend(x[2] for x in sorted(entries))
    return out

new_text = json.dumps(new, ensure_ascii=False, indent=2)+'\n'
(OUT/'score_v3_proposed.json').write_text(new_text)
(OUT/'score_v3_proposed_events.txt').write_text(''.join(readable(new)))
(OUT/'exact_diff_v2_proposed.patch').write_text(''.join(difflib.unified_diff(
    (SOURCE/'score_v2.json').read_text().splitlines(True), new_text.splitlines(True),
    fromfile='score_v2.json (unchanged original)', tofile='review_orchard_structure/score_v3_proposed.json')))
(OUT/'musical_diff_v2_proposed.patch').write_text(''.join(difflib.unified_diff(
    readable(old), readable(new), fromfile='v2 notes and pedal', tofile='proposal notes and pedal')))

def selected(score, voices):
    return [e for e in score['events'] if e['voice'] in voices]

report = {'source_sha256': before['score_v2.json'], 'source_files_unchanged': before == hashes(),
          'canonical_score_equals_original_v2': (SOURCE/'score.json').read_bytes() == (SOURCE/'score_v2.json').read_bytes(),
          'original': examine(old), 'proposed': examine(new),
          'melody_and_upper_support_unchanged': selected(old, ['melody','upper_support']) == selected(new, ['melody','upper_support']),
          'bar_metadata_and_tempos_unchanged': old['bars'] == new['bars'],
          'all_final_bar_notes_unchanged': [e for e in old['events'] if e['bar']==64] == [e for e in new['events'] if e['bar']==64],
          'changes': changes,
          'audio_rendered': False, 'audio_listened': False,
          'limits': 'Static score review. Hand spans exclude pedal-held resonance. Timing and pitch checks do not establish musical sound or instrument-specific pedal behavior.'}
assert report['source_files_unchanged'] and not report['proposed']['errors']
(OUT/'proposal_audit.json').write_text(json.dumps(report, ensure_ascii=False, indent=2)+'\n')
(OUT/'original_file_hashes.json').write_text(json.dumps(before, indent=2)+'\n')
print(json.dumps({k: report[k] for k in ['source_files_unchanged','original','proposed','melody_and_upper_support_unchanged','all_final_bar_notes_unchanged']}, indent=2))
