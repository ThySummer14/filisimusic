#!/usr/bin/env python3
"""Read-only verification of the local delivery manifest, standard library only."""
from pathlib import Path
import json,hashlib
root=Path(__file__).resolve().parent
manifest=json.loads((root/'hash_manifest.json').read_text(encoding='utf-8'))
issues=[]
for entry in manifest['files']:
 p=root/entry['path']
 if not p.is_file():issues.append('missing '+entry['path']);continue
 data=p.read_bytes()
 if len(data)!=entry['bytes'] or hashlib.sha256(data).hexdigest()!=entry['sha256']:issues.append('mismatch '+entry['path'])
print(json.dumps({'passed':not issues,'files_checked':len(manifest['files']),'issues':issues},indent=2))
raise SystemExit(bool(issues))
