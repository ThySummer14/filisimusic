# A Door Painted on the Rain / 画在雨上的门

Original solo-piano ballad, work082. Final version: v2.

## Form and timeline

60 bars; 240 absolute quarter-note beats. Sounded score lasts 200.545 seconds; five-second tail gives 205.545 seconds (3:25.5). Nominal tempos are 58–76 BPM. All bars are 4/4 except the 3/4 and 5/4 speech bars identified below. No swing quantization is encoded: play the eighths nearly straight, with flexible ballad phrasing.

| Bars | Score time | Action and musical job |
|---|---:|---|
| 1–4 | 0:00–0:13.77 | Rain and drawn threshold; quiet motif outline |
| 5–12 | 0:13.77–0:40.62 | Main eight-bar sung statement; first stable tonic cadence |
| 13–20 | 0:40.62–1:07.07 | Varied statement; extension of the upper line |
| 21–28 | 1:07.07–1:32.59 | Chromatic descending bass; the workbench and wet pages |
| 29–36 | 1:32.59–2:00.37 | Free central monologue; 3,5,4,4,3,5,4,4 quarter-note beats |
| 37–52 | 2:00.37–2:52.32 | Reharmonized return; dismantle, carry, stretch, divert water |
| 53–60 | 2:52.32–3:20.54 | Paint the real door sign; measured tonic close |
| Tail | 3:20.54–3:25.54 | Natural decay, with CC64 already released |

## Piano, touch, and hierarchy

Use only the already approved Moonlight acoustic-piano instrument. This package does not select, install, sample, render, or audition an instrument. The owner handles native API, sampling and REAPER. No audio file is included.

The right hand sings one continuous line. Do not make the short neighbor notes into separate glittering gestures, and do not detach low and high notes into alternating answers. Four-bar breaths are tiny releases within the final written value. Eight-bar thoughts join the smaller breaths. The highest melody note is Eb5, and the lowest is C4; this stays close to a singing register.

The left hand gives a low root followed by compact shells. Let the bass hand travel after release and let the pedal support resonance. The widest simultaneously held left-hand grip is eleven semitones; the right hand is monophonic. Before a left-hand move wider than an octave, the score explicitly releases fingers at least 0.34 beats before the next grip, or 0.44 beats before moves over nineteen semitones. The audit uses actual release time rather than falsely treating the whole interval between attacks as travel time.

The chromatic bridge is a little more forward (mostly 76 BPM) and its left-hand shells arrive at 0.875 and 2.875 beats. This is a gentle push, not a second fast piece. The central monologue uses quieter paired notes at uneven offsets; it retains a pulse that can stretch with the sentence. Its half-pedal avoids accumulating the changing thirds and leading tones. The return has fuller three-note shells at selected second beats, while melody remains the foreground.

Written velocities place the melody roughly twenty units above accompaniment. They are a balance plan, not evidence of an already auditioned sound. A human or downstream renderer can adjust overall gain without rewriting the composition.

## Harmonic reading

The first statement uses Eb major as home, with Cm9, Fm9, Bb13, Eb/G and Abmaj9. E-natural in bar10 is a brief lower neighbor to F, and A-natural in bar8 approaches Bb. The half-step colors have destinations.

Bars21–28 put a descending chromatic bass under explicit chord tones. D7(b13) contains F# and C; C9 contains E and Bb; B7 contains D# and A; A7(b9) contains C# and Bb. The tune changes with the harmony instead of laying the same diatonic phrase across unrelated chords.

Bars37–40 keep the recognizable opening line but move the first three harmonies to Cm9, Fm9/Ab and Dbmaj9, then rewrite the fourth melody for Gbmaj9. The melody is not forced through the old dominant shape. Abmaj9 to Abm6 at45–46 changes C to Cb/B; the line articulates that change. E diminished in48 connects Eb/G to F minor, with a new descent through G, E and Db before the C4 pickup in49.

Bar44 is a half cadence on Bb13. Its final melody F is the chord’s fifth, deliberately absent from the left-hand shell; a set-membership audit therefore reports “not in voiced harmony” without treating it as a wrong note. Bar52, Bbm9/Eb, functions as a suspended Eb dominant toward Ab in53. The final progression moves Fm9–Bb13–Eb6/9–Eb(add9), with D5→Eb5 preparing the arrival and G4→F4→Eb4 completing the line. The final F4 is a soft left-hand ninth above the Eb melody and bass.

## Pedal and event interpretation

Event onset and duration are absolute quarter-note beats, independent of denominator. Every event has bar, onset, duration, MIDI pitch, velocity, voice, instrument="piano", and hand="left" or "right". Bars include absolute start, beats, BPM, section, meter numerator/denominator, harmony and lead instrument.

CC64 uses exactly 0,42,76. Each bar releases at the boundary, takes full pedal at +0.055 beats (partial only in the monologue), moves to partial at 51% of the bar, and releases 0.045 beats before the next bar. A redundant explicit final release is at beat240. Pedal resonance is excluded from the finger-span audit, as it must be. Tempo belongs to its whole bar; there are no hidden tempo ramps or undocumented event nudges.

## Review scope

All three scores pass symbolic span, same-key, phrase continuity, release-time and bounds checks. These checks establish mechanical consistency and inspectable phrase/cadence intentions. They do not certify auditory quality; no playback, render, download or publication occurred.
