#!/usr/bin/env python3
"""Independent score-format, reproducibility, performance-bound audit. No rendering."""
from pathlib import Path
import hashlib,json,subprocess,sys
P=Path(__file__).resolve().parent
files=[f'score_v{i}.json' for i in range(3)]+['score.json']
before={x:hashlib.sha256((P/x).read_bytes()).hexdigest() for x in files}
subprocess.run([sys.executable,str(P/'generate_score.py')],check=True,stdout=subprocess.DEVNULL)
after={x:hashlib.sha256((P/x).read_bytes()).hexdigest() for x in files}
assert before==after
results={}
for f in files:
 d=json.loads((P/f).read_text());bar_by_id={b['bar']:b for b in d['bars']}
 assert len(bar_by_id)==64 and d['total_beats']==288
 assert all(b['beats']==4.5 and b['start']==(b['bar']-1)*4.5 and b['meter_numerator']==9 and b['meter_denominator']==8 for b in d['bars'])
 assert all(20<b['bpm']<200 for b in d['bars'])
 assert all(e['voice'] in ['melody','upper_support','bass','accompaniment'] and e['instrument']=='piano' for e in d['events'])
 for e in d['events']:
  b=bar_by_id[e['bar']]
  assert b['start']<=e['onset']<b['start']+4.5
  assert 0<e['duration'] and e['onset']+e['duration']<=288
  assert isinstance(e['pitch'],int) and 0<=e['pitch']<=127 and 0<e['velocity']<128
 # Sweep noteoffs before noteons; simultaneously sounding keys must be distinct.
 sweep=[]
 for i,e in enumerate(d['events']):
  sweep += [(round(e['onset'],6),1,i),(round(e['onset']+e['duration'],6),0,i)]
 held={}; spans={'left':0,'right':0}; max_poly=0
 for t,kind,i in sorted(sweep):
  e=d['events'][i]
  if kind==0:held.pop(i,None)
  else:
   assert not any(x['pitch']==e['pitch'] for x in held.values()),(f,t,e)
   held[i]=e
  max_poly=max(max_poly,len(held))
  for hand,voices in [('left',{'bass','accompaniment'}),('right',{'melody','upper_support'})]:
   keys=[x['pitch'] for x in held.values() if x['voice'] in voices]
   span=max(keys)-min(keys) if keys else 0
   spans[hand]=max(spans[hand],span)
   assert span<=12,(f,t,hand,keys)
 assert d['pedals'][0]['value']==d['pedals'][-1]['value']==0
 assert all(x['value'] in [0,55,78] for x in d['pedals'])
 assert d['pedals']==sorted(d['pedals'],key=lambda x:x['onset'])
 total=sum(b['beats']*60/b['bpm'] for b in d['bars'])+d['tail_seconds']
 assert 190<=total<=215
 results[f]={'passed':True,'max_polyphony_excluding_pedal':max_poly,'hand_spans':spans,'total_seconds_with_tail':round(total,4),'sha256':after[f]}
assert (P/'score.json').read_bytes()==(P/'score_v2.json').read_bytes()
out={'deterministic_regeneration':True,'score_equals_v2':True,'results':results,'audio_rendered':False,'audio_listened':False,'note':'Independent sweep-line audit; pedal sustain is resonance, not held-finger span.'}
(P/'independent_audit.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(out,ensure_ascii=False,indent=2))
