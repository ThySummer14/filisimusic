from copy import deepcopy

def pitch(s):
 return 12*(int(s[-1])+1)+{'C':0,'D':2,'E':4,'F':5,'G':7,'A':9,'B':11}[s[0]]+s[1:-1].count('#')-s[1:-1].count('b')
def decode(line):
 result=[];t=0
 for token in line.split():
  name,units=token.split(':');dur=float(units)/2
  if name!='R':result.append((pitch(name),t,dur))
  t+=dur
 return result,t
class Writer:
 def __init__(self):self.bars=[];self.events=[];self.pedals=[];self.start=0;self.n=0
 def bar(self,name,bpm,beats,h,ch):
  self.n+=1;self.beats=beats;self.bpm=bpm;self.ch=ch
  numerator,denominator=(int(beats*2),8) if beats in (2.5,3.5) else ((6,8) if METER=='6/8' else (int(beats),4))
  self.bars.append(dict(bar=self.n,start=self.start,beats=beats,bpm=bpm,meter_numerator=numerator,meter_denominator=denominator,section=name,harmony_name=h,harmony=ch))
 def add(self,p,t,d,v=72,inst='piano',voice='theme',hand='right',art='detached'):
  if d>0 and t<self.beats:
   self.events.append(dict(bar=self.n,onset=round(self.start+t,6),duration=round(min(d,self.beats-t),6),pitch=int(p),velocity=max(1,min(127,int(v))),instrument=inst,voice=voice,hand=hand if inst=='piano' else 'none',articulation=art))
 def line(self,line,v=80,hand='right',transpose=0):
  notes,total=decode(line);assert abs(total-self.beats)<1e-7,(self.n,total,self.beats,line)
  for p,t,d in notes:self.add(p+transpose,t,max(.11,d-.09),v+(3 if t==0 else 0),hand=hand)
  return notes
 def release(self,amount=0,length=.7):
  self.pedals.append(dict(bar=self.n,onset=self.start,controller=64,value=0,instrument='piano'))
  if amount:
   self.pedals.extend([dict(bar=self.n,onset=self.start+.05,controller=64,value=amount,instrument='piano'),dict(bar=self.n,onset=self.start+length,controller=64,value=0,instrument='piano')])
  self.start+=self.beats
 def result(self,level):
  self.pedals.append(dict(bar=self.n,onset=self.start-.01,controller=64,value=0,instrument='piano'))
  return dict(id=ID,title=TITLE,title_zh=TITLE_ZH,version=f'v{level}',bars=self.bars,events=self.events,pedals=self.pedals,total_beats=self.start,tail_seconds=5,instrument_map=INSTRUMENT_MAP)
def material(level):
 n=0
 for section,bpm,beats,texture,hs,phrase_names in BLOCKS:
  lines=[]
  for pn in phrase_names.split():lines+=P[pn].split('|')
  harmonies=hs.split();assert len(lines)==len(harmonies),(section,len(lines),len(harmonies))
  for h,line in zip(harmonies,lines):
   n+=1
   for lv,rev in [(1,REV1),(2,REV2)]:
    if level>=lv and n in rev:h,line=rev[n]
   yield n,section,bpm,beats,texture,h,line
ID=132;TITLE='Paper Bridge Load Test';TITLE_ZH='纸桥承重';METER='5/8';INSTRUMENT_MAP={'piano':'piano','cello':'pizz'}
RENDERER_NOTES='Mostly 5/8 with bars41–56 and81–88 in 3/4. Cello pizzicato only, C2–B2 single mf layer, sparse test weights. Piano interlocking hands carry rapid texture.'
H={'C':[36,52,55],'G':[43,55,59],'Am':[45,52,60],'F':[41,53,57],'Dm':[38,53,57],'E7':[40,56,62],'C/E':[40,55,60],'Bb':[46,53,62],'G7':[43,53,59],'Fm':[41,53,56],'D7':[38,54,60],'Cadd9':[36,50,55]}
P={
'fold':'C5:1 E5:1 G5:1 D5:2|B4:1 D5:1 G5:2 F5:1|E5:1 A5:1 G5:1 E5:2|F5:1 C5:1 A4:2 R:1',
'crease':'E5:2 G5:1 C6:1 B5:1|A5:1 G5:1 E5:2 C5:1|D5:2 G5:1 F5:1 D5:1|C5:2 G4:1 R:2',
'span':'G5:1 C6:1 E6:1 D6:1 C6:1|F5:1 A5:1 C6:1 B5:1 A5:1|G5:1 B5:1 D6:1 C6:1 B5:1|E5:1 A5:1 C6:1 B5:1 A5:1',
'weight':'G5:2 E5:1 C5:2|A5:2 F5:1 C5:2|B5:2 G5:1 D5:2|C6:2 G5:1 E5:2',
'bend':'A5:1 E5:1 C5:1 B4:2|G#4:1 B4:1 E5:2 D5:1|F5:1 A5:1 D6:1 C6:2|B5:1 G5:1 D5:2 R:1',
'spread':'C5:2 E5:1 G5:1 C6:2|A5:2 F5:1 C5:1 A4:2|D5:1 F5:1 A5:2 G5:2|B4:2 D5:1 G5:1 R:2',
'spread2':'E5:2 G5:1 C6:1 B5:2|A5:1 F5:1 D5:2 F5:2|G#5:2 E5:1 B4:1 G#4:2|A4:2 E5:1 A5:1 R:2',
'arch':'C6:1 G5:1 E5:1 C5:2|A5:1 F5:1 C5:1 A4:2|D5:1 G5:1 B5:1 A5:2|E5:1 G5:1 C6:2 R:1',
'load':'E6:1 C6:1 G5:1 E5:1 C5:1|F6:1 C6:1 A5:1 F5:1 C5:1|D6:1 B5:1 G5:1 D5:1 B4:1|C6:1 G5:1 E5:1 G5:1 C6:1',
'still':'R:2 E5:1 C5:1 R:2|R:1 F5:2 A5:1 R:2|R:2 B4:1 D5:1 R:2|G5:2 R:4',
'limit':'G5:1 C6:1 E6:1 G6:2|A5:1 C6:1 F6:1 E6:2|B5:1 D6:1 G6:1 F6:2|E6:1 C6:1 G5:1 E5:2',
'edge':'C6:1 Ab5:1 F5:1 C5:2|Bb5:1 G5:1 E5:1 C5:2|A5:1 F#5:1 D5:1 C5:2|B5:1 G5:1 F5:1 D5:2',
'hold':'G5:2 E5:1 C5:1 R:1|A5:2 F5:1 C5:1 R:1|B5:1 D6:1 G5:1 F5:2|E5:1 G5:1 C6:2 R:1'
}
BLOCKS=[
('First_fold',96,2.5,'fold','C G Am F C Am G7 C','fold crease'),
('Make_the_span',104,2.5,'span','C F G Am C F G Am','span span'),
('One_weight',94,2.5,'weight','C F G C C F G C','weight weight'),
('Bridge_bends',102,2.5,'bend','Am E7 Dm G7 Am E7 Dm G7','bend bend'),
('Fold_the_edges',102,2.5,'fold','C G Am F C Am G7 C','fold crease'),
('Spread_the_load',86,3,'spread','C F Dm G7 C Dm E7 Am','spread spread2'),
('Look_underneath',86,3,'spread','C F Dm G7 C Dm E7 Am','spread spread2'),
('New_arch',104,2.5,'arch','C F G C C F G C','arch arch'),
('Three_weights',108,2.5,'load','C F G C C F G C','load load'),
('Four_weights',112,2.5,'load','C F G C C F G C','load load'),
('Hold_breath',80,3,'still','C F G C C F G C','still still'),
('One_more',104,2.5,'limit','C F G C C F G C','limit limit'),
('At_the_edge',108,2.5,'edge','Fm C D7 G7 Fm C D7 G7','edge edge'),
('It_is_holding',110,2.5,'limit','C F G C C F G C','limit hold'),
('Write_the_number',92,2.5,'record','C G Am F C F G7 Cadd9','fold hold')]
REV1={57:('C/E','G5:1 E5:1 C5:2 G4:1'),58:('F','C6:1 A5:1 F5:2 C5:1'),59:('Dm','A5:1 F5:1 D5:1 E5:2'),60:('G7','B5:1 G5:1 F5:1 D5:2'),61:('C','E5:1 G5:1 C6:1 B5:2'),62:('Am','C6:1 A5:1 E5:2 C5:1'),63:('D7','F#5:1 A5:1 C6:1 B5:2'),64:('G7','G5:1 F5:1 D5:2 R:1')}
REV2={97:('Fm','Ab5:1 C6:1 F6:1 Eb6:2'),98:('C/E','G5:1 C6:1 E6:1 D6:2'),99:('D7','F#5:1 A5:1 D6:1 C6:2'),100:('G7','B5:1 G5:1 F5:1 R:2'),101:('Fm','C6:2 Ab5:1 F5:1 R:1'),102:('Bb','D6:1 Bb5:1 F5:1 D5:2'),103:('G7','B5:1 D6:1 F6:1 E6:2'),104:('G7','D6:1 B5:1 G5:2 R:1')}
def build(level):
 w=Writer()
 for n,section,bpm,beats,style,h,line in material(level):
  ch=H[h];w.bar(section,bpm,beats,h,ch);v={'fold':71,'span':80,'weight':76,'bend':87,'spread':65,'arch':78,'load':91,'still':45,'limit':99,'edge':95,'record':77}[style];notes=w.line(line,v)
  if style in ('fold','span','arch'):
   # The hinge falls between right-hand attacks, and the other hand completes the last short step.
   ts=[0,1.5] if style!='arch' else [.5,2]
   if level>=1 and 57<=n<=64:ts=[0,1.25]
   for j,t in enumerate(ts):w.add(ch[0] if j==0 else ch[1],t,.28,v-21,voice='fold_joint',hand='left')
  elif style in ('weight','load','limit','edge'):
   # A cello weight replaces the low piano beat; no three-layer constant accompaniment.
   if n%2==1:w.add(36+ch[0]%12,0,.78,72,inst='cello',voice='test_weight',art='pizzicato')
   else:w.add(ch[0],0,.4,v-20,voice='weight_memory',hand='left')
   w.add(ch[1],1.25,.32,v-24,voice='bridge_response',hand='left')
   if style in ('load','edge'):w.add(ch[2],2,.28,v-22,voice='strain',hand='left')
   if level>=2 and 97<=n<=104 and n%2==0:
    w.add(36+ch[0]%12,1.25,.78,72,inst='cello',voice='second_test_weight',art='pizzicato')
  elif style=='spread':
   w.add(ch[0],0,.8,v-16,voice='wide_support',hand='left');w.add(ch[1],1.5,.72,v-20,voice='load_distribution',hand='left')
  elif style=='bend':
   for t,p in [(.5,ch[0]),(1.5,ch[1])]:w.add(p,t,.34,v-24,voice='bending_edge',hand='left')
  elif style=='still':
   if n in (81,85):w.add(36+ch[0]%12,0,.8,72,inst='cello',voice='weight_remains',art='pizzicato')
  else:
   w.add(ch[0],0,.5,v-18,voice='recorded_number',hand='left')
   if n%2==0:w.add(ch[1],1.5,.42,v-20,voice='pencil_mark',hand='left')
  w.release(28 if style=='spread' else 0,.9)
 return w.result(level)
