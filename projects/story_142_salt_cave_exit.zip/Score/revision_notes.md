# 142 盐洞的另一个出口

独立名义谱；没有音频渲染、听审或外部发布。运行本目录 `python generate_score.py` 可从零重建。

## 音乐构造
80小节，四个连续大段17/19/23/21，以6/8为轴穿入7/8、5/8、4/4。钢琴绳索主题与大提琴粉笔主题分开写谱、独立移动；左手与长笛各有自己的材料。句子边界不统一落在8小节或段末。第三大段持续23小节累积，不用中部安静后全体回归的结构。

## v0 → v1
第18–28、38–44小节（18小节）：重写大提琴的音程与起音，右手改为另一套弱起/延长句；第20、24、28、39、43小节改和声。目的：让粉笔主题真正在与钢琴争辩，而不是点缀重拍。

## v1 → v2
第53–60、68–80小节（21小节）：高峰右手加密并选择性上移；后段改成更长的步点，长笛以完整独立空气动机占据另一个时值层。第54、58、70、75、79小节调整和声。两个精确diff记录逐小节完整前后事件，排除event_id/version。

## 演奏与校验
大提琴仅短弓D3–B3，通常0.48/0.51秒，短小节边缘仍不低于0.35秒，逐事件积分验证换弓空隙≥0.2秒。长笛C5–B5且留换气。快密材料仅给钢琴。两手持音跨度、跨声部同键、独奏乐器单音、拍号单位、三版时长、踏板归零均做真实符号验证；实际音色和混音由主owner另审。

交审前补做和声落点校订：各声部句首/句尾对齐当前和声，保留中间经过音；第18、41、54小节显式标记有解决的倚音。该步骤对三版一致实施，重建精确diff及hash，不视为新的独立编曲轮次。

最终交审前和声勘误：逐声部、逐小节检查非和弦音的实际去向。保留仅限同线下一音以半音/全音进入当前和声者；无此解决的非必要音改回和声落点。所有保留实例在 score.json 的 intentional_nonchord_tones 有起音、音高与解决音证据。对三版一致校订并重建全部差异、校验及hash；未把此勘误冒充第三轮编曲。

最终逐小节实际差异（含独立旋律游标造成的后续发展，不以计划修改范围代替）：v0→v1 41小节 [18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59]；v1→v2 28小节 [53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80]。以此及exact_diff JSON为准。
木管逐事件按节奏图积分检查跨小节呼吸间隙，所有版本≥0.14秒；不足时整体推迟下一音，门长保持；容纳不下整音者写成休止，不靠缩短门长通过。


## 2026-10-07 nominal sample-trigger rest-layout correction

Only listed musical onsets move later to explicit fractional-beat positions. No event is removed or added; every pitch, velocity and effective gate is retained. The existing nominal score remains free of recording onset compensation. The full tempo map and the next note’s actual pitch/velocity layer are used in the separate sample-trigger-gap checker. All flute/arco adjacent pairs must retain at least 0.14 seconds after the renderer’s one-time compensation. Full before files, hashes and exact event/source differences are retained under nominal_trigger_gap_repair. This is symbolic checking only, without rendering or listening review.

- v0: reposition 3 events in bars 65, 71, 77.
- v1: reposition 3 events in bars 65, 71, 77.
- v2: reposition 4 events in bars 56, 65, 71, 77.
