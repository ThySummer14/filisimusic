#!/usr/bin/env python3
"""Independent saved-score audit. Never imports the composition generator.
Reads every gate, integrates variable tempi and sweeps physical held keys.
"""
import copy, difflib, hashlib, json, math, subprocess, sys, tempfile
from collections import defaultdict, Counter
from pathlib import Path
ROOT=Path(__file__).resolve().parent
def load(n):return json.loads((ROOT/n).read_text(encoding='utf-8'))
def save(n,x):(ROOT/n).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def sha(n):return hashlib.sha256((ROOT/n).read_bytes()).hexdigest()
def end(e):return round(e['onset']+e['duration'],6)

def inspect(s):
    errors=[];bars=s['bars'];notes=s['events'];pn=[e for e in notes if e['instrument']=='piano'];cs=[e for e in notes if e['instrument']=='clarinet']
    def ck(ok,label):
        if not ok:errors.append(label)
    def seconds(t):return sum(min(max(t-b['start'],0),b['beats'])*60/b['bpm'] for b in bars)
    ck(s['id']==96 and s['total_beats']==288 and s['tail_seconds']==4,'identity / total')
    ck(len(bars)==72 and 200<=seconds(288)+4<=230,'72-bar 3:20–3:50 extent')
    ck(s['instrumentation']==['natural_acoustic_piano','University_of_Iowa_clarinet_C4_B4'],'actual instruments')
    ck(abs(s['music_seconds']-seconds(288))<1e-7 and abs(s['total_seconds_with_tail']-seconds(288)-4)<1e-7,'integrated total seconds')
    chords={'Am':{9,0,4},'Am(add9)':{9,0,4,11},'E7':{4,8,11,2},'Dm':{2,5,9},'F':{5,9,0},'C':{0,4,7},'G':{7,11,2},'G7':{7,11,2,5},'Em':{4,7,11},'Bdim':{11,2,5}}
    bass={'C':0,'E':4,'G#':8,'B':11}
    for i,b in enumerate(bars):
        ck((b['bar'],b['start'],b['beats'],b['meter_numerator'],b['meter_denominator'])==(i+1,i*4,4,4,4),'quarter-beat bar grid')
        ck(b['meter']=='4/4' and 70<=b['bpm']<=89,'4/4 / quarter BPM')
        ck(b['phrase_id']==f'P{i//8+1:02d}' and b['phrase_position']==i%8+1 and b['macro_phrase_length_bars']==8,'phrase grid')
        ck(abs(b['time_start_seconds']-seconds(b['start']))<1e-7,'bar seconds')
        hn=b['harmony_name'].split('/');ck({p%12 for p in b['harmony']}==chords[hn[0]],'actual named harmony '+str(i+1))
        if len(hn)>1:ck(min(b['harmony'])%12==bass[hn[1]],'actual inversion bass')
        ck(sum(e['value_beats'] for e in b['written_melody'])==4,'complete authored rhythm including rests')
    ck(len({e['event_id'] for e in notes})==len(notes),'unique IDs')
    ck(notes==sorted(notes,key=lambda e:(e['onset'],e['instrument'],e['hand'],e['pitch'],e['voice'])),'stable event order')
    plans={(p['bar'],p['hand']):p for p in s['hand_position_plan']};ck(len(plans)==len(s['hand_position_plan'])==144,'both hand plans per bar')
    for e in notes:
        tag=e['event_id'];b=bars[e['bar']-1]
        ck(all(math.isfinite(e[k]) for k in ('onset','duration','pitch','velocity')),'finite numbers')
        ck(isinstance(e['pitch'],int) and 21<=e['pitch']<=108 and isinstance(e['velocity'],int) and 1<=e['velocity']<=127,'MIDI bounds')
        ck(b['start']<=e['onset']<end(e)<=b['start']+4,'real note boundaries '+tag)
        ck(e['written_value_beats']>=e['duration']>0,'positive gates / written value')
        ck(e['target_on_beats']==e['onset'] and abs(e['target_off_beats']-end(e))<1e-6,'beat aliases')
        ck(abs(e['target_on_seconds']-seconds(e['onset']))<1.1e-6 and abs(e['target_off_seconds']-seconds(end(e)))<1.1e-6,'independent seconds')
        member=e['pitch']%12 in {p%12 for p in b['harmony']}
        ck(e['harmonic_function']==('chord_tone' if member else 'melodic_nonchord_tone'),'harmonic classification')
        ck(e['harmony_name']==b['harmony_name'],'event harmony label')
        ck(e['onset_reference']=='ordinary_trigger' and e['timing_correction_applied_seconds']==0,'ordinary trigger; no compensation')
        if e['role']=='support':ck(member and e['instrument']=='piano','coherent harmonic support')
        if e['instrument']=='piano':
            ck(e['layer']=='natural' and e['sample_layer']=='approved_natural_piano','actual piano intent')
            ck(e['hand'] in ('left','right') and seconds(end(e))-seconds(e['onset'])>=.06,'physical piano gate')
            p=plans[(e['bar'],e['hand'])]
            ck(e['hand_position_id']==p['position_id'] and e['hand_position_range']==p['range'],'named plan')
            ck(e['position_keys']==e['hand_position_keys']==sorted(map(int,p['pitch_finger_map'])),'complete named keys')
            ck(e['finger']==p['pitch_finger_map'].get(str(e['pitch'])) and 1<=e['finger']<=5,'finger')
            if e['role']=='lead':ck(e['hand']=='right' and e['voice']=='melody','piano foreground')
        else:
            ck(e['instrument']=='clarinet' and e['hand']=='not_applicable' and e['role']=='lead' and e['voice']=='cantabile_melody','clarinet role')
            ck(60<=e['pitch']<=71 and e['source_pitch_midi']==e['pitch'],'real clarinet sample range; no transposition')
            layer='pp' if e['velocity']<=55 else 'mf' if e['velocity']<=95 else 'ff'
            ck(e['layer']==e['sample_layer']==layer,'genuine pp/mf/ff velocity boundary')
            ck(e['source_family']=='University of Iowa clarinet' and e['sample_transition']=='none' and e['articulation']=='naturally_separated_breathed_tone','source / no sampled legato')
            gate=seconds(end(e))-seconds(e['onset']);ck(.35-1e-7<=gate<=1.45+1e-7 and abs(gate-e['nominal_gate_seconds'])<1e-6,'clarinet gate envelope')
    allowance={1:5,2:9,3:11,4:12}
    for key,p in plans.items():
        es=[e for e in pn if (e['bar'],e['hand'])==key];ps=sorted({e['pitch'] for e in es});fs=[p['pitch_finger_map'].get(str(x),0) for x in ps]
        ck(p['active'] and p['range']==[min(ps),max(ps)] and max(ps)-min(ps)<=12,'real full named position')
        ck(len(ps)<=5 and len(fs)==len(set(fs)),'distinct named fingers')
        ck(fs==sorted(fs,reverse=p['hand']=='left'),'ordered fingers')
        ck(all(b-a<=allowance.get(abs(g-f),0) for a,b,f,g in zip(ps,ps[1:],fs,fs[1:])),'finger interval reach')
    changes=defaultdict(list);attacks={h:defaultdict(list) for h in ('left','right')}
    for i,e in enumerate(notes):
        changes[e['onset']].append((1,i));changes[end(e)].append((0,i))
        if e['instrument']=='piano':attacks[e['hand']][e['onset']].append(e)
    active={};snap={h:{} for h in attacks};maxspan={h:0 for h in attacks};maxkeys={h:0 for h in attacks}
    overlaps=[];collisions=[];crossings=[];position_collisions=[];foreground=[];silent_from=None;silences=[]
    for t,cc in sorted(changes.items()):
        had=bool(active)
        for kind,i in sorted(cc):
            if kind==0:active.pop(i,None)
            else:
                e=notes[i]
                for old in active.values():
                    if e['instrument']==old['instrument'] and e['pitch']==old['pitch']:overlaps.append([old['event_id'],e['event_id']])
                    if e['instrument']==old['instrument']=='piano' and e['hand']==old['hand'] and e['finger']==old['finger']:collisions.append([old['event_id'],e['event_id']])
                active[i]=e
        if had and not active:silent_from=t
        if active and silent_from is not None:
            if t>silent_from:silences.append(seconds(t)-seconds(silent_from))
            silent_from=None
        foreground.append(sum(e['role']=='lead' for e in active.values()))
        hands={h:[e for e in active.values() if e['instrument']=='piano' and e['hand']==h] for h in attacks}
        for h,es in hands.items():
            if es:
                ps=[e['pitch'] for e in es];maxspan[h]=max(maxspan[h],max(ps)-min(ps));maxkeys[h]=max(maxkeys[h],len(ps))
                if len({e['hand_position_id'] for e in es})>1:position_collisions.append(t)
                if t in attacks[h]:snap[h][t]=es.copy()
        if all(hands.values()) and max(e['pitch'] for e in hands['left'])>=min(e['pitch'] for e in hands['right']):crossings.append(t)
    ck(not overlaps,'no same-key overlaps');ck(not collisions,'no finger collisions');ck(not crossings,'no hand crossings');ck(not position_collisions,'no holding across position changes')
    ck(max(maxspan.values())<=12 and max(maxkeys.values())<=5,'actual held geometry')
    ck(max(foreground)==1,'one monophonic foreground only')
    ck(max(silences,default=0)<=max(60/b['bpm'] for b in bars),'no multi-beat gap padding; complete score remains within one slow quarter beat')
    transfers=[]
    for hand,bytime in attacks.items():
        groups=sorted(bytime.items());latest_release=0
        for index,(t,new) in enumerate(groups):
            if index:
                oldt,previous=groups[index-1];old=snap[hand][oldt];oldkeys=[e['pitch'] for e in old];newkeys=[e['pitch'] for e in snap[hand][t]]
                og=[min(oldkeys),max(oldkeys)];ng=[min(newkeys),max(newkeys)];op=plans[(previous[0]['bar'],hand)];np=plans[(new[0]['bar'],hand)]
                changed=op['position_id']!=np['position_id'];edge=max(abs(a-b) for a,b in zip(og,ng));held=max(abs(a-b) for a in oldkeys for b in newkeys)
                pe=max(abs(a-b) for a,b in zip(op['range'],np['range'])) if changed else 0;travel=max(edge,held,pe)
                required=.075+.012*max(0,travel-4);available=seconds(t)-seconds(latest_release)
                row={'hand':hand,'from_beat':oldt,'to_beat':t,'old_grip':og,'new_grip':ng,'old_position':op['range'],'new_position':np['range'],
                  'whole_position_changed':changed,'grip_edge_semitones':edge,'actual_held_key_movement_semitones':held,'position_edge_semitones':pe,
                  'checked_travel_semitones':travel,'last_prior_key_release_beat':latest_release,'available_seconds':round(available,9),
                  'required_seconds':round(required,9),'margin_seconds':round(available-required,9),'passed':available+1e-7>=required}
                transfers.append(row);ck(row['passed'],f'strict released transfer {hand} at beat {t}')
            latest_release=max(latest_release,*(end(e) for e in new))
    cs.sort(key=lambda e:e['onset']);gates=[seconds(end(e))-seconds(e['onset']) for e in cs];gaps=[seconds(b['onset'])-seconds(end(a)) for a,b in zip(cs,cs[1:])]
    breaths=[{'from_bar':a['bar'],'to_bar':b['bar'],'gap_seconds':round(seconds(b['onset'])-seconds(end(a)),9)} for a,b in zip(cs,cs[1:]) if a['phrase_id']!=b['phrase_id']]
    ck(min(gaps)>=.08-1e-7,'every clarinet inter-note gap at least80ms')
    ck(min(x['gap_seconds'] for x in breaths)>=.35-1e-7,'real breath at each clarinet phrase boundary')
    cpp=defaultdict(list)
    for e in cs:cpp[e['phrase_id']].append(e)
    ck(all(max(e['bar'] for e in es)-min(e['bar'] for e in es)+1<=4 for es in cpp.values()),'breath spans no longer than four bars')
    ck([e['bar'] for e in cs if e['layer']=='ff']==[45,46],'only two earned ff arrivals')
    ck({e['layer'] for e in cs}=={'pp','mf','ff'} and sum(e['layer']=='ff' for e in cs)<=2,'mostly genuine pp/mf')
    lead=[e for e in notes if e['role']=='lead']
    for b in bars:
        es=[e for e in lead if e['bar']==b['bar']];ss=[e for e in notes if e['bar']==b['bar'] and e['role']=='support']
        ck(es and {e['instrument'] for e in es}=={b['lead_instrument']},'single named foreground per bar')
        ck(max(e['velocity'] for e in ss)<=min(e['velocity'] for e in es)-8,'foreground velocity intention')
        if b['lead_instrument']=='piano':ck(not any(e['instrument']=='clarinet' for e in notes if e['bar']==b['bar']),'clarinet real rest at piano solo')
        expected=[];t=b['start']
        for x in b['written_melody']:
            if x['pitch'] is not None:expected.append((t,x['pitch'],x['value_beats']))
            t+=x['value_beats']
        ck([(e['onset'],e['pitch'],e['written_value_beats']) for e in es]==expected,'actual authored melody/rest grid')
    phr={p['phrase_id']:p for p in s['phrases']};ck(set(phr)=={e['phrase_id'] for e in notes} and len(phr)==len(s['phrases']),'complete phrase coverage')
    for pid,p in phr.items():
        es=[e for e in notes if e['phrase_id']==pid];a=min(e['onset'] for e in es);z=max(end(e) for e in es)
        ck(all(e['instrument']==p['instrument'] for e in es) and (p['first_bar'],p['last_bar'])==(min(e['bar'] for e in es),max(e['bar'] for e in es)),'phrase membership')
        ck(abs(p['target_on_beats']-a)<1e-6 and abs(p['target_off_beats']-z)<1e-6,'phrase endpoints')
        ck(abs(p['target_on_seconds']-seconds(a))<1e-6 and abs(p['target_off_seconds']-seconds(z))<1e-6,'phrase seconds')
        ck(p['layers_used']==sorted({e['layer'] for e in es}) and p['roles_used']==sorted({e['role'] for e in es}) and p['voices_used']==sorted({e['voice'] for e in es}),'phrase role/layer metadata')
    sig=[tuple((round(e['onset']-i*32,6),e['pitch'],e['written_value_beats'],e['instrument']) for e in lead if i*8<e['bar']<=i*8+8) for i in range(9)]
    if s['version']=='v2':ck(len(set(sig))==9,'nine distinct final eight-bar sentences')
    if s['version']!='v0':ck([bars[i]['harmony_name'] for i in range(24,32)]==['C','G/B','Am','F','Dm','G7','C','C/E'],'warm middle harmonic route')
    ck(bars[-2]['harmony_name']=='E7' and bars[-1]['harmony_name']=='Am','earned dominant / tonic close')
    ck(lead[-1]['pitch']==69 and end(lead[-1])==288,'final piano A4 at form boundary')
    pedals=s['pedals'];ck(pedals==sorted(pedals,key=lambda p:p['onset']),'pedal order');state=0
    for p in pedals:
        ck(p['controller']==64 and p['instrument']=='piano' and 0<=p['value']<=30 and 0<=p['onset']<=288,'light pedal bound')
        ck(p['value']==0 if state else p['value']>0,'pedal down / up pair');state=p['value']
        ck(abs(p['target_on_seconds']-seconds(p['onset']))<1e-6,'pedal seconds')
    ck(state==0 and pedals[-1]['onset']==288,'final pedal release')
    return {'passed':not errors,'errors':sorted(set(errors)),'event_count':len(notes),'bars':72,'total_quarter_beats':288,'duration_with_tail_seconds':round(seconds(288)+4,6),
      'maximum_held_span_semitones':maxspan,'maximum_simultaneous_keys':maxkeys,'same_key_overlap_count':len(overlaps),'finger_collision_count':len(collisions),'hand_crossing_count':len(crossings),'held_position_collision_count':len(position_collisions),
      'maximum_simultaneous_foreground_notes':max(foreground),'piano_pitch_range':[min(e['pitch'] for e in pn),max(e['pitch'] for e in pn)],
      'clarinet_event_count':len(cs),'clarinet_pitch_range':[min(e['pitch'] for e in cs),max(e['pitch'] for e in cs)],'clarinet_recorded_layers':dict(Counter(e['layer'] for e in cs)),
      'clarinet_gate_seconds_range':[round(min(gates),9),round(max(gates),9)],'minimum_clarinet_release_gap_seconds':round(min(gaps),9),
      'minimum_clarinet_phrase_breath_seconds':min(x['gap_seconds'] for x in breaths),'clarinet_breaths':breaths,
      'maximum_all_note_gate_gap_seconds':round(max(silences,default=0),9),'minimum_piano_key_gate_seconds':round(min(seconds(end(e))-seconds(e['onset']) for e in pn),9),
      'unique_eight_bar_phrases':len(set(sig)),'lead_bar_counts':dict(Counter(b['lead_instrument'] for b in bars)),
      'strict_transfer_count':len(transfers),'minimum_transfer_margin_seconds':min(r['margin_seconds'] for r in transfers),'strict_transfers':transfers,
      'gate_gap_interpretation':'All-note gates can be released while piano pedal and natural sample tails remain audible. This is physical/key-gate timing, not measured audio silence. Cadential E7 rests before the final tonic are composed pauses.',
      'limits':'Independent symbolic timing, source intent and physical release tests. No audio or sample-envelope listening certification.'}

def patch_apply(original,ops):
    result=copy.deepcopy(original)
    for op in ops:
        keys=[s.replace('~1','/').replace('~0','~') for s in op['path'].split('/')[1:]]
        if not keys:result=copy.deepcopy(op['value']);continue
        dest=result
        for k in keys[:-1]:dest=dest[int(k)] if isinstance(dest,list) else dest[k]
        key=int(keys[-1]) if isinstance(dest,list) else keys[-1]
        if op['op']=='remove':del dest[key]
        else:dest[key]=copy.deepcopy(op['value'])
    return result
def verify_diff(a,b,d):
    errors=[];expected=[];musical=[];dimensions={'foreground_pitch':[],'written_rhythm':[],'actual_harmony_pitches':[],'actual_accompaniment_pattern':[]}
    core=lambda es:[{k:e[k] for k in ('onset','duration','pitch','instrument','voice','hand')} for e in es]
    for n in range(1,73):
        row={'bar':n,'before_bar':a['bars'][n-1],'after_bar':b['bars'][n-1],
          'before_events':[e for e in a['events'] if e['bar']==n],'after_events':[e for e in b['events'] if e['bar']==n],
          'before_pedals':[e for e in a['pedals'] if e['bar']==n],'after_pedals':[e for e in b['pedals'] if e['bar']==n]}
        if any(row['before_'+k]!=row['after_'+k] for k in ('bar','events','pedals')):expected.append(row)
        if core(row['before_events'])!=core(row['after_events']) or row['before_bar']['harmony']!=row['after_bar']['harmony']:musical.append(n)
        for dimension,keys in [('foreground_pitch',('pitch',)),('written_rhythm',('onset','written_value_beats'))]:
            if [tuple(e[k] for k in keys) for e in row['before_events'] if e['role']=='lead']!=[tuple(e[k] for k in keys) for e in row['after_events'] if e['role']=='lead']:dimensions[dimension].append(n)
        if row['before_bar']['harmony']!=row['after_bar']['harmony']:dimensions['actual_harmony_pitches'].append(n)
        pattern=lambda es:[(round(e['onset']-(n-1)*4,6),e['duration'],e['instrument'],e['hand'],e['voice']) for e in es if e['role']!='lead']
        if pattern(row['before_events'])!=pattern(row['after_events']):dimensions['actual_accompaniment_pattern'].append(n)
    if expected!=d['changes'] or [r['bar'] for r in expected]!=d['changed_bars']:errors.append('exact per-bar changes')
    if len(musical)<8 or any(len(rows)<4 for rows in dimensions.values()):errors.append('substantive revision dimensions')
    for label,s in [('before',a),('after',b)]:
        if d[label+'_sha256']!=sha(f'score_{s["version"]}.json'):errors.append('version file hash')
        if d['phrase_metadata_'+label]!=s['phrases'] or d['position_plan_'+label]!=s['hand_position_plan']:errors.append('exact metadata')
    reconstructed=patch_apply(a,d['json_patch'])==b
    if not reconstructed:errors.append('JSON patch reproduction')
    before=(ROOT/f'score_{a["version"]}.json').read_text();after=(ROOT/f'score_{b["version"]}.json').read_text()
    exact=''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile=f'score_{a["version"]}.json',tofile=f'score_{b["version"]}.json'))
    text_ok=(ROOT/f'exact_diff_{a["version"]}_to_{b["version"]}.patch').read_text()==exact
    if not text_ok:errors.append('literal unified text patch')
    return {'passed':not errors,'errors':errors,'changed_bars':d['changed_bars'],'strict_musical_changed_bars':musical,'strict_musical_changed_bar_count':len(musical),
      'changed_bars_by_musical_dimension':dimensions,'full_document_patch_reconstructs_next_version':reconstructed,'exact_text_patch_matches':text_ok}

def mutation_tests(final):
    cases={}
    bad=copy.deepcopy(final);e=next(x for x in bad['events'] if x['instrument']=='clarinet');e['pitch']=59;cases['unrecorded_clarinet_pitch_rejected']=not inspect(bad)['passed']
    bad=copy.deepcopy(final);e=next(x for x in bad['events'] if x['instrument']=='clarinet');e['sample_layer']='ff';cases['false_clarinet_layer_rejected']=not inspect(bad)['passed']
    bad=copy.deepcopy(final);e=next(x for x in bad['events'] if x['instrument']=='clarinet');e['duration']=4;cases['overlong_clarinet_gate_rejected']=not inspect(bad)['passed']
    bad=copy.deepcopy(final);e=next(x for x in bad['events'] if x['instrument']=='piano' and x['hand']=='right' and x['role']=='lead');e['duration']=2.0;cases['retained_physical_key_rejected']=not inspect(bad)['passed']
    # Consistently update the timing metadata to ensure geometry, rather than
    # stale aliases alone, detects a 10 ms gate extension into transfer space.
    bad=copy.deepcopy(final);report=inspect(final);row=min(report['strict_transfers'],key=lambda x:x['margin_seconds']);hand=row['hand'];t=row['to_beat']
    prior=[e for e in bad['events'] if e['instrument']=='piano' and e['hand']==hand and e['onset']<t];e=max(prior,key=end)
    e['duration']+=.06*bad['bars'][e['bar']-1]['bpm']/60;e['target_off_beats']=end(e)
    e['target_off_seconds']=sum(min(max(end(e)-b['start'],0),b['beats'])*60/b['bpm'] for b in bad['bars'])
    cases['strict_transfer_shortfall_rejected']=any('strict released transfer' in x for x in inspect(bad)['errors'])
    return cases

def main():
    scores={v:load(f'score_{v}.json') for v in ('v0','v1','v2')};audits={v:inspect(s) for v,s in scores.items()}
    for v,a in audits.items():save(f'audit_{v}.json',a)
    diffs={f'{a}_to_{b}':verify_diff(scores[a],scores[b],load(f'exact_diff_{a}_to_{b}.json')) for a,b in [('v0','v1'),('v1','v2')]}
    with tempfile.TemporaryDirectory(prefix='.reproduction_',dir=ROOT) as temp:
        subprocess.run([sys.executable,str(ROOT/'generate_score.py'),'--outdir',temp],check=True,capture_output=True)
        reproduction={p.name:(ROOT/p.name).read_bytes()==p.read_bytes() for p in sorted(Path(temp).iterdir()) if p.is_file()}
    save('reproducibility_check.json',{'passed':all(reproduction.values()),'byte_identical_files':reproduction,'method':'Fresh Python process, new directory; generator never imported by disk checker; byte comparisons of all generated documents and exact patches.'})
    selected=(ROOT/'score.json').read_bytes()==(ROOT/'score_v2.json').read_bytes();mutations=mutation_tests(scores['v2'])
    fields=('passed','errors','event_count','duration_with_tail_seconds','maximum_held_span_semitones','maximum_simultaneous_keys','same_key_overlap_count','finger_collision_count','hand_crossing_count','clarinet_event_count','clarinet_pitch_range','clarinet_recorded_layers','clarinet_gate_seconds_range','minimum_clarinet_release_gap_seconds','minimum_clarinet_phrase_breath_seconds','strict_transfer_count','minimum_transfer_margin_seconds','unique_eight_bar_phrases','maximum_all_note_gate_gap_seconds')
    report={'passed':selected and all(a['passed'] for a in audits.values()) and all(d['passed'] for d in diffs.values()) and all(reproduction.values()) and all(mutations.values()),
      'selected_equals_v2_byte_for_byte':selected,'selected_score_sha256':sha('score.json'),'version_summaries':{v:{k:a[k] for k in fields} for v,a in audits.items()},
      'revision_checks':diffs,'mutation_rejections':mutations,'reproducibility_passed':all(reproduction.values()),'scope':'Independent disk-based symbolic constraints; complete version patches; fresh-process reproducibility. No audio or listening performed.'}
    save('independent_verification.json',report)
    files={p.name:{'bytes':p.stat().st_size,'sha256':sha(p.name)} for p in sorted(ROOT.iterdir()) if p.is_file() and p.name!='hash_manifest.json'}
    save('hash_manifest.json',{'algorithm':'SHA-256','files':files,'excludes_self':True,'scope':'Every regular file in this isolated symbolic draft directory.'})
    print(json.dumps(report,ensure_ascii=False,indent=2))
    if not report['passed']:raise SystemExit(1)
if __name__=='__main__':main()
