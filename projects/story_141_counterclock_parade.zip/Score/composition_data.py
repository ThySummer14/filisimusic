"""Original nominal chamber score. The three melodic tapes are separately authored.
The local engine only places, articulates and checks notes; it invents no chord pattern.
All coordinates are quarter-note beats, before sampled-onset compensation.
"""
from copy import deepcopy
ID=141
TITLE='The Counterclock Parade'
TITLE_ZH='折页街的逆行钟'
INSTRUMENT_MAP={'piano':'piano','clarinet':'clarinet','cello':'pizz'}
RENDERER_NOTES='Piano and clarinet carry independent themes, with a moving left-hand third strand. Cello is pizzicato only, C2–B2, single mf layer. Preserve nominal attacks; apply recording latency compensation in the main renderer. No audio or listening approval is part of this package.'
# A five-note angular clock figure and a separate descending walking tune are
# extended through sentences of 11, 9, 13, 7, 15, 12 and 11 bars.
H={
'Ebadd9':[39,55,58,65],'Cm7':[36,51,55,58],'Abmaj7':[44,55,60,63],
'Bb7':[46,50,56,62],'Fm9':[41,56,60,67],'G7b9':[43,53,59,68],
'Abm6':[44,54,59,65],'Dbmaj7':[37,53,56,60],'EbG':[43,51,58,65],
'Bbpedal':[46,51,56,60],'Ddim':[38,53,56,59],'Copen':[36,55,62],
'Ebopen':[39,58,65],'F7':[41,57,60,63]}
# Rhythm banks are explicit local shapes, selected in unequal groups. Every wind
# cell has a breath; piano density is never transferred to a sample-limited wind.
RHYTHMS={
'p1':[(0,.5),(.75,.45),(1.5,.9),(2.75,.45),(3.5,.4)],
'p2':[(.25,.4),(.75,.4),(1.25,.65),(2.25,.4),(2.75,.4),(3.5,.4)],
'p3':[(0,.3),(.5,.3),(1,.3),(1.75,.3),(2.25,.3),(2.75,.3),(3.25,.3),(3.75,.2)],
'p4':[(0,.9),(1.5,.4),(2,.4),(2.75,.65),(3.75,.2)],
'p5':[(.5,.65),(1.5,.65),(2.5,.4),(3.25,.4)],
'p6':[(0,.4),(.5,.4),(1.25,.4),(1.75,.4),(2.5,.4),(3,.4),(3.75,.2)],
'l1':[(0,.7),(1.25,.6),(2.5,.55),(3.25,.55)],
'l2':[(.5,.55),(1.5,.55),(2.75,.7)],
'l3':[(0,.42),(.75,.42),(1.75,.65),(3,.75)],
'l4':[(.25,.8),(1.75,.6),(3,.6)],
'w1':[(.25,.65),(1.5,.8),(3,.6)],
'w2':[(.75,.8),(2.5,.7)],
'w3':[(0,.7),(1.25,.7),(2.75,.55)],
'w4':[(.5,.85),(2,.9)],
'w5':[(1.25,.9),(3,.65)],
'z':[]}

def sec(name,count,bpm,meters,hs,A,L,B,ar,lr,br,dyn,phrase):
 return dict(name=name,count=count,bpm=bpm,meters=meters,harmonies=hs.split(),A=A.split(),L=L.split(),B=B.split(),ar=ar.split(),lr=lr.split(),br=br.split(),dyn=dyn,phrase=phrase)
SECTIONS=[
sec('The_second_hand_steps_out',11,90,[4,4,5,4],
'Ebadd9 Cm7 Abmaj7 Bb7 EbG Fm9 G7b9 Cm7 Abmaj7 Bbpedal Ebopen',
'Eb5 G5 D5 F5 Bb4 D5 Eb5 Ab5 G5 F5 D5 Bb4 C5 Eb5 G5 F5 Bb5 Ab5 G5 Eb5 D5 F5 C5 Bb4 Eb5 G5 Bb5 A5 Ab5 F5 D5 Eb5',
'Eb3 Bb3 G3 F3 Ab3 C4 Bb3 G3 D3 F3 Ab3 G3 C3 G3 Bb3 Ab3 F3 Eb3 D3 Bb2 F3 Ab3 G3 Eb3',
'G4 F4 Eb4 C4 D4 F4 G4 Bb4 Ab4 F4 Eb4 D4 C4 Eb4 F4 Ab4 G4 F4 D4 Eb4',
'p1 p4 p2 p1 p5 p2 p4','l2 l1 l4 l3 l2','w1 w2 w4 z w3 w5',66,'5+6-bar sentence; piano asks on the weak beat, clarinet ends a different thought'),
sec('The_paper_street_turns',9,98,[4,5,4],
'Abmaj7 Dbmaj7 Abm6 EbG Fm9 Bb7 Cm7 F7 Bb7',
'G5 Ab5 C6 Bb5 F5 Eb5 G5 Bb5 Db6 C6 Ab5 F5 Eb5 Gb5 Ab5 C6 Bb5 G5 F5 D5 Eb5 C5 F5 A5 Bb5 Ab5 F5 D5',
'Ab3 Eb3 C3 Db3 Ab3 F3 Gb3 Eb3 C3 Bb2 G3 Eb3 F3 C4 Ab3 Bb3 D3 F3 Eb3 A3 F3 Bb2',
'Eb4 F4 Ab4 G4 C4 Db4 F4 Ab4 Bb4 G4 Gb4 Eb4 F4 Ab4 C4 Eb4 G4 A4 Bb4 F4',
'p2 p4 p6 p1 p3','l3 l2 l4 l1','w2 w3 z w1 w4',78,'3+6; expansion is interrupted by a chromatic side street'),
sec('A_parade_walks_backwards',13,112,[4,4,3.5,4,5],
'Cm7 G7b9 Cm7 Fm9 Abmaj7 Ddim G7b9 Cm7 F7 Bb7 Abm6 Dbmaj7 Bbpedal',
'G5 Eb5 D5 Bb4 C5 Eb5 G5 Ab5 Bb5 G5 F5 D5 Eb5 G5 C6 Bb5 G5 F5 Ab5 B5 D6 C6 Ab5 G5 F5 D5 C5 Eb5 G5 Bb5 A5 F5 Eb5 Gb5 Bb5 Ab5 F5 Db5 C5 Bb4',
'C3 Eb3 G3 Bb3 Ab3 F3 D3 B2 D3 F3 Ab3 C4 Bb3 G3 Eb3 C3 F3 A3 C4 Bb3 F3 D3 Db3 Ab3 F3 Eb3',
'Bb4 Ab4 F4 G4 Eb4 D4 C4 Eb4 G4 F4 D4 C4 Ab4 G4 F4 Eb4 Db4 C4 Eb4 F4 Gb4 Ab4 Bb4 F4 Eb4 D4',
'p3 p6 p2 p3 p1 p6 p4','l1 l3 l2 l4 l3','w3 w2 w1 z w5 w4 w2',93,'6+7; ascending piano sequences cross a descending clarinet sentence'),
sec('One_hand_is_missing',7,104,[5,4,4,3.5],
'Bbpedal EbG Abm6 Ddim G7b9 Cm7 Fm9',
'F5 Bb5 A5 Ab5 G5 D5 Eb5 Gb5 C6 B5 Ab5 F5 D5 Ab5 G5 F5 Eb5 D5 C5 G5 F5 Eb5',
'Bb2 F3 Ab3 G3 Eb3 Bb2 C3 Gb3 A3 F3 D3 B2 G3 Ab3 C4 Bb3 F3 Ab3 C4',
'D4 F4 Bb4 Ab4 G4 Eb4 Gb4 A4 C4 D4 F4 Ab4 G4 F4 Eb4 C4',
'p5 p2 p4 p6','l1 l4 l3 l2','w1 w4 w2 z w3',84,'7-bar hinge, with no central lyrical reset'),
sec('The_square_rotates',15,108,[4,5,4,3.5,4],
'Fm9 Abmaj7 Ddim G7b9 Cm7 F7 Bb7 EbG Abm6 Dbmaj7 Fm9 Bb7 G7b9 Cm7 Bbpedal',
'C6 Ab5 F5 G5 Bb5 D6 C6 A5 F5 Eb5 G5 B5 D6 C6 Bb5 G5 Eb5 F5 A5 C6 Bb5 Ab5 F5 D5 Eb5 G5 Bb5 Db6 C6 Ab5 Gb5 F5 Ab5 C6 Eb6 D6 Bb5 Ab5 G5 F5 D5 B4 C5 Eb5 G5 Bb5 Ab5 F5 D5',
'F3 Ab3 C4 Bb3 G3 Eb3 D3 Ab3 F3 G3 B3 D3 C3 G3 Bb3 A3 F3 C3 Bb2 D3 F3 Ab3 G3 Eb3 Db3 Ab3 F3 C3 G3 B3 C4 Bb3 F3 D3',
'F4 Ab4 G4 Eb4 C4 D4 F4 G4 B4 A4 G4 Eb4 C4 F4 A4 G4 F4 D4 C4 Eb4 Gb4 Ab4 Bb4 C4 Eb4 F4 Ab4 G4 F4 D4 B4 G4 Eb4 C4',
'p3 p6 p3 p2 p4 p6 p1','l3 l1 l2 l3 l4','w3 w1 z w2 w4 w3 w5',102,'4+5+6; three growing waves, clarinet cadence deliberately arrives one bar late'),
sec('Tomorrow_is_on_the_wrong_side',12,88,[4,4,5,4],
'Abm6 Dbmaj7 EbG Fm9 Bbpedal Ebadd9 Cm7 G7b9 Abmaj7 F7 Bb7 Ebopen',
'Gb5 Bb5 Ab5 Eb5 F5 Ab5 Db6 C6 Ab5 G5 Eb5 F5 Bb5 A5 Ab5 G5 F5 Eb5 D5 G5 B5 C6 Bb5 Ab5 G5 F5 A5 Bb5 D6 C6 G5 F5 Eb5',
'Ab3 Gb3 Eb3 Db3 F3 Ab3 C4 Bb3 G3 Eb3 C3 F3 Ab3 C4 Bb3 F3 D3 Eb3 G3 B3 C4 Ab3 F3 A3 Bb3 G3 Eb3',
'Eb4 Gb4 Ab4 Bb4 F4 Db4 Eb4 G4 Bb4 Ab4 F4 C4 D4 Eb4 F4 G4 B4 Ab4 G4 F4 D4 Eb4 C4',
'p2 p5 p6 p4 p2','l4 l3 l1 l2','w4 w1 w5 z w2 w3',86,'5+7; weighted syncopation stretches time without stopping the dance'),
sec('Let_the_procession_pass',11,96,[4,5,4,4],
'Cm7 Fm9 Bb7 Ebadd9 Abmaj7 Abm6 EbG F7 Bbpedal Copen Ebopen',
'G5 Eb5 D5 F5 Bb4 D5 Eb5 G5 Bb5 Ab5 F5 D5 C5 Eb5 Ab5 G5 F5 Eb5 Gb5 Bb5 Ab5 G5 Eb5 D5 F5 A5 C6 Bb5 F5 D5 C5 G5 D5 Eb5 Bb4',
'C3 G3 Bb3 Ab3 F3 C3 Bb2 F3 D3 Eb3 G3 Bb3 Ab3 C4 Bb3 Gb3 Eb3 G3 Bb3 A3 F3 Eb3 C3 G3 D3 Eb3 Bb2',
'G4 F4 Eb4 C4 D4 F4 Bb4 Ab4 F4 Eb4 D4 C4 Eb4 Gb4 Ab4 G4 F4 Eb4 D4 C4 G4 F4 D4 Eb4',
'p1 p6 p4 p2 p5','l2 l1 l3 l4','w1 w2 w4 z w3 w5',76,'6+5; the clock continues its contrary walk instead of joining a unison finale')]
REV1_BARS=set(range(12,21))|set(range(35,42))
REV2_BARS=set(range(49,59))|set(range(72,79))

def note(s):
 return 12*(int(s[-1])+1)+{'C':0,'D':2,'E':4,'F':5,'G':7,'A':9,'B':11}[s[0]]+s[1:-1].count('#')-s[1:-1].count('b')
def bounded(p,lo,hi):
 while p<lo:p+=12
 while p>hi:p-=12
 assert lo<=p<=hi
 return p

def woodwind_breathing(s):
 # Schedule real breathing space in seconds; preserve the existing gate length.
 # If a whole note cannot fit after a breath, omit that attack as a written rest.
 bars={b['bar']:b for b in s['bars']};elapsed={};t=0
 for b in s['bars']:elapsed[b['bar']]=t;t+=b['beats']*60/b['bpm']
 changes=[];removed=set()
 for inst in ('clarinet','flute'):
  last_end=-100
  for e in sorted((x for x in s['events'] if x['instrument']==inst),key=lambda x:x['onset']):
   b=bars[e['bar']];scale=60/b['bpm'];gate=e['duration']*scale
   start_sec=elapsed[e['bar']]+(e['onset']-b['start'])*scale
   if gate<.24:
    removed.add(id(e));changes.append(dict(bar=e['bar'],instrument=inst,action='write_rest_instead_of_truncated_short_attack',old_onset=e['onset'],duration_seconds=gate));continue
   need=max(0,last_end+.145-start_sec)
   if need>1e-7:
    new=e['onset']+need/scale
    if new+e['duration']>b['start']+b['beats']-.001:
     removed.add(id(e));changes.append(dict(bar=e['bar'],instrument=inst,action='write_rest_to_preserve_gate_and_breath',old_onset=e['onset'],duration_seconds=gate));continue
    changes.append(dict(bar=e['bar'],instrument=inst,action='delay_entire_note_for_breath',old_onset=e['onset'],new_onset=round(new,6),unchanged_duration=e['duration']))
    e['onset']=round(new,6);start_sec+=need
   last_end=start_sec+gate
 s['events']=[e for e in s['events'] if id(e) not in removed]
 s['woodwind_breathing_edits']=changes
 return s

def harmonic_finish(s):
 # A melodic dissonance is retained only when the next note of that same
 # line resolves by one or two semitones to the actual current harmony.
 # Otherwise correct the local landing, never relabel a collision as style.
 from collections import defaultdict
 groups=defaultdict(list);bars={b['bar']:b for b in s['bars']}
 for e in s['events']:groups[(e['bar'],e['instrument'],e['voice'],e['hand'])].append(e)
 evidence=[]
 for (bn,inst,voice,hand),ee in groups.items():
  ee.sort(key=lambda x:x['onset']);pcs={p%12 for p in bars[bn]['harmony']}
  lo,hi=(60,96) if inst=='piano' and hand=='right' else (31,59) if inst=='piano' else (60,71) if inst=='clarinet' else (72,83) if inst=='flute' else (36,47) if s['instrument_map'].get('cello')=='pizz' else (50,59)
  for i in range(len(ee)-1,-1,-1):
   e=ee[i];p=e['pitch']
   if p%12 in pcs:continue
   nx=ee[i+1] if i+1<len(ee) else None
   resolved=nx and nx['pitch']%12 in pcs and 1<=abs(nx['pitch']-p)<=2
   if resolved:
    evidence.append(dict(bar=bn,instrument=inst,voice=voice,harmony=bars[bn]['harmony_name'],pitch=p,onset=e['onset'],resolution_pitch=nx['pitch'],resolution_onset=nx['onset'],classification='explicit stepwise appoggiatura, neighbor or passing tone; not a chord member'))
   else:
    cc=[q for q in range(lo,hi+1) if q%12 in pcs]
    e['pitch']=min(cc,key=lambda q:(abs(q-p),q))
 s['intentional_nonchord_tones']=sorted(evidence,key=lambda x:(x['bar'],x['onset'],x['instrument']))
 s['harmonic_review_scope']='Each remaining non-chord event resolves by step to a chord member in its own line within the same bar. This is symbolic voice-leading evidence, not an audio quality claim.'
 return s

def build(level):
 bars=[];events=[];pedals=[];start=0;n=0;phrase_map=[]
 def add(p,t,d,v,inst,voice,hand='none',art='detached'):
  if t>=beats-.025 or d<=.025:return
  events.append(dict(bar=n,onset=round(start+t,6),duration=round(min(d,beats-t-.025),6),pitch=int(p),velocity=int(max(1,min(127,v))),instrument=inst,voice=voice,hand=hand,articulation=art))
 for si,s in enumerate(SECTIONS):
  cur={'A':0,'L':0,'B':0};first=n+1
  for j in range(s['count']):
   n+=1;beats=s['meters'][j%len(s['meters'])];bpm=s['bpm'];h=s['harmonies'][j%len(s['harmonies'])];d=s['dyn']
   rev1=level>=1 and n in REV1_BARS;rev2=level>=2 and n in REV2_BARS
   if rev1 and n in (14,18,37,40):h={14:'Abm6',18:'Ddim',37:'F7',40:'Abmaj7'}[n]
   if rev2 and n in (51,55,74,77):h={51:'Dbmaj7',55:'F7',74:'Abm6',77:'Copen'}[n]
   numerator,denominator=(int(beats*2),8) if beats%1 else (int(beats),4)
   bars.append(dict(bar=n,start=start,beats=beats,bpm=bpm,meter_numerator=numerator,meter_denominator=denominator,section=s['name'],harmony_name=h,harmony=H[h]))
   for voice,bank,inst,hand,lo,hi in [('A','ar','piano','right',60,95),('L','lr','piano','left',33,59),('B','br','clarinet','none',60,71)]:
    rk=s[bank][j%len(s[bank])];cells=deepcopy(RHYTHMS[rk])
    # Revision one expands the answer instead of copying the clock motive.
    if rev1 and voice=='B':cells=[(.15,.7),(1.4,.75),(2.8,.65)]
    if rev1 and voice=='L':cells=[(.25,.5),(1.25,.6),(2.25,.5),(3.5,.4)]
    # Revision two truncates the upper line while the walking tune keeps going.
    if rev2 and voice=='A':cells=[(.25,.4),(.75,.6),(1.75,.4),(2.5,.65),(3.5,.35)]
    if rev2 and voice=='B':cells=[(0,.7),(1.5,.75),(3,.55)] if n<72 else [(.5,.75),(2.25,.85)]
    if beats==5 and voice=='A':cells.append((4.25,.45))
    if beats==5 and voice=='L':cells.append((4,.7))
    for k,(t,dur) in enumerate(cells):
     if t>=beats-.05:continue
     p=note(s[voice][cur[voice]%len(s[voice])]);cur[voice]+=1
     if rev1 and voice=='B':p=bounded(131-p+(1 if n in (14,18,37,40) else 0),lo,hi)
     if rev1 and voice=='L':p=bounded(p+(2 if k%2==0 else -1),lo,hi)
     if rev2 and voice=='A':p=bounded(p-12 if k in (0,3) else p+(1 if n in (51,55,74,77) else 0),lo,hi)
     if rev2 and voice=='B':p=bounded(p+(-2 if k==0 else 1),lo,hi)
     p=bounded(p,lo,hi)
     if k==0 or k==len(cells)-1:
      candidates=[x for x in range(lo,hi+1) if x%12 in {z%12 for z in H[h]}]
      p=min(candidates,key=lambda x:(abs(x-p),x))
     if rev1 and voice=='B' and n==14:p=[67,66,65][min(k,2)]
     if rev1 and voice=='B' and n==37:p=[70,69,65][min(k,2)]
     if rev2 and voice=='B' and n==51:p=[66,65,68][min(k,2)]
     if rev2 and voice=='B' and n==55:p=[64,65,60][min(k,2)]
     if rev2 and voice=='B' and n==74:p=[70,68][min(k,1)]
     if rev2 and voice=='B' and n==77:p=[65,67][min(k,1)]
     vv=d+([4,-3,0,2,-2][k%5])-(16 if voice=='L' else 10 if voice=='B' else 0)
     add(p,t,dur,vv,inst,{'A':'clock_angular_subject','L':'turning_street_counterline','B':'walking_descending_subject'}[voice],hand)
   # Sparse pizzicato echoes fragments of the walking subject, never a bass ostinato.
   if (j+2*si)%5 in (0,2) and not (si==6 and j>6):
    pp=bounded(note(s['B'][(j*3+si)%len(s['B'])])-24,36,47)
    t=.5 if j%3 else 2.25;dur=.52*bpm/60
    add(pp,t,dur,72,'cello','footstep_fragment',art='pizzicato')
   pedals.append(dict(bar=n,onset=start,controller=64,value=0,instrument='piano'))
   if si==5 and j in (1,4,8):
    pedals.extend([dict(bar=n,onset=start+.12,controller=64,value=30,instrument='piano'),dict(bar=n,onset=start+.8,controller=64,value=0,instrument='piano')])
   start+=beats
  phrase_map.append(dict(first_bar=first,last_bar=n,design=s['phrase'],themes=['clock_angular_subject','walking_descending_subject'],independent_left_hand=True))
 pedals.append(dict(bar=n,onset=start-.01,controller=64,value=0,instrument='piano'))
 return harmonic_finish(woodwind_breathing(dict(id=ID,title=TITLE,title_zh=TITLE_ZH,version=f'v{level}',bars=bars,events=events,pedals=pedals,total_beats=start,tail_seconds=5,instrument_map=INSTRUMENT_MAP,phrase_map=phrase_map,composition_method='Separately authored melodic tapes with unequal phrase lengths; no harmonic arpeggiator or sampled-onset precompensation.')))
