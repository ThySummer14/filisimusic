# 143 温室里相反的春天

72小节，7/13/9/17/11/15的争辩式双主题形式，以5/4、3/4、6/4组织不同长度的生长。两支木管分别写有明确主题，钢琴也是第三参与者，绝非持续循环的琶音底层。所有音符是名义时间；未渲染、未试听。

## 两轮实质修改
- v0→v1：第8–20、30–35小节，共19小节。单簧管重新安排起音并写入新的完整北床句；左手步点和音程同时改写。第10、14、18、32、35小节改变和声方向。
- v1→v2：第42–48、60–72小节，共20小节。长笛把南床题作新的错位进入，右手让出重拍后切分推进并下移局部音区；第43、46、62、68、71小节换和声。终末长笛先停，单簧管和钢琴仍完成自己的生长句。

精确diff逐小节保留前后事件及和声，排除纯event_id/version差异。三版校验钢琴全部声部同键互斥、两手实际持音跨度、木管单音和换气单元、实际总时长、范围及显式踏板释放。木管仅使用C4–B4和C5–B5；快密音全部由钢琴承担。

本目录 `python generate_score.py` 可独立从零重建，不依赖其他曲目源文件或外部音源。实际采样混音和听感仍待主音乐owner渲染审核。

交审前补做和声落点校订：各声部句首/句尾锚定当前和声，保留中间经过音；第8、31、61小节另明确写入有解决的倚音。并改用与140不同的温室情境，音乐角色与元数据同步更新。

最终交审前和声勘误：逐声部、逐小节检查非和弦音的实际去向。保留仅限同线下一音以半音/全音进入当前和声者；无此解决的非必要音改回和声落点。所有保留实例在 score.json 的 intentional_nonchord_tones 有起音、音高与解决音证据。对三版一致校订并重建全部差异、校验及hash；未把此勘误冒充第三轮编曲。

最终逐小节实际差异（含独立旋律游标造成的后续发展，不以计划修改范围代替）：v0→v1 30小节 [8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46]；v1→v2 29小节 [42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72]。以此及exact_diff JSON为准。
木管逐事件按节奏图积分检查跨小节呼吸间隙，所有版本≥0.14秒；不足时整体推迟下一音，门长保持；容纳不下整音者写成休止，不靠缩短门长通过。


## 2026-10-07 nominal sample-trigger rest-layout correction

Only listed musical onsets move later to explicit fractional-beat positions. No event is removed or added; every pitch, velocity and effective gate is retained. The existing nominal score remains free of recording onset compensation. The full tempo map and the next note’s actual pitch/velocity layer are used in the separate sample-trigger-gap checker. All flute/arco adjacent pairs must retain at least 0.14 seconds after the renderer’s one-time compensation. Full before files, hashes and exact event/source differences are retained under nominal_trigger_gap_repair. This is symbolic checking only, without rendering or listening review.

- v0: reposition 10 events in bars 15, 23, 27, 36, 43, 60, 66.
- v1: reposition 10 events in bars 15, 23, 27, 36, 43, 60, 66.
- v2: reposition 11 events in bars 15, 23, 27, 36, 42, 48, 60, 62, 68.
