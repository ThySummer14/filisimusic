# 090 — The Moon’s Lost Luggage / 月亮遗失的行李

Original symbolic piano-and-clarinet work. Selected version: v2.

144 bars: 112 bars of 2/4 and a 32-bar 3/4 trio. D-flat major with an expansive G-flat region. 320 absolute quarter-note beats. Music: 196.428784135 s; tail: 5 s; total: 201.428784135 s (3:21.43).

The directory contains three complete versions, exact musical changes, Chinese fiction and composition/revision notes, a deterministic Python generator, an independently authored disk-based verifier, and SHA-256 hashes. Only this draft directory was changed. No audio, samples, DSP, downloads, installations, renders, or live-project changes were made.

## Files

- score_v0.json, score_v1.json, score_v2.json: full scores.
- score.json: exact bytes of score_v2.json.
- generate_score.py: standard-library generator; explicit authored phrase data, deterministic realization.
- verify_symbolic.py: independent disk-based audit; does not import or execute the generator.
- exact_diff_v0_to_v1.json/.patch: all 16 altered bars and complete next-version reconstruction information.
- exact_diff_v1_to_v2.json/.patch: all 38 altered bars and complete next-version reconstruction information.
- audit_v0.json, audit_v1.json, audit_v2.json, independent_verification.json: detailed actual-key, timing, source, phrase and revision evidence.
- story_zh.txt, music_notes_zh.md, revision_notes.md: fiction and score-grounded notes.
- metadata.json, reproducibility_report.json, verifier_regression_report.json, hash_manifest.json: handoff and validation records.
- verify_hashes.py: read-only hash verification.

## Reproduce

Run from this directory with Python 3:

    python generate_score.py
    python verify_symbolic.py
    python verify_hashes.py

No package installation is needed. The generator does not read another work or any sample bank. The final score was authored from the work-specific musical sentences in its source.

## Integration contract

Use the approved natural piano and Iowa clarinet recordings C4–B4, MIDI 60–71. This score uses clarinet MIDI 60–70, genuine pp/mf/ff layers and ordinary unshifted triggers. The owner handles any measured sample compensation once. Preserve explicit note gates and piano CC64; pedal resonance must not be interpreted as fingers holding keys. Do not add sampled legato transitions.

All bar starts and event onsets/durations are absolute quarter-note beats, including the meter changes. Every bar has its tempo. Every event has instrument, voice, hand, role, layer and phrase ID. The additional seconds fields are independently verified piecewise tempo integrals. Clarinet breath groups are at most four bars. Piano uses exact position keys and fingers.

Audit passes establish symbolic contracts and playability geometry. They do not establish actual sampled timbre, attack/release envelopes, balance or final audio quality; those require the owner's later source and listening checks.
