"""Original high-energy piano narrative; three short signals and one sustained answer."""
from pathlib import Path
import copy,json
P=Path(__file__).parent
A=[[(71,.5),(73,.5),(74,.5),(78,2.5)],[(79,1),(78,.5),(76,.5),(74,1),(71,1)],[(78,.5),(76,.5),(74,1),(81,1),(78,1)],[(76,.5),(78,.5),(81,.5),(85,1.5),(83,.5),(81,.5)],[(83,1),(81,.5),(78,.5),(74,.5),(73,.5),(71,1)],[(74,.5),(78,.5),(79,1),(78,.5),(76,.5),(74,1)],[(76,.5),(79,.5),(83,1.5),(81,.5),(79,1)],[(82,1),(80,.5),(78,.5),(76,1),(-1,1)],[(78,.5),(81,.5),(83,.5),(86,2.5)],[(86,1),(83,.5),(81,.5),(79,1),(78,1)],[(81,.5),(78,.5),(74,1),(73,.5),(74,.5),(78,1)],[(85,1),(83,.5),(81,.5),(78,.5),(76,.5),(73,1)],[(83,.5),(81,.5),(78,1),(76,.5),(74,.5),(71,1)],[(79,1),(83,.5),(81,.5),(79,.5),(78,.5),(76,1)],[(82,.5),(85,.5),(88,1),(85,.5),(82,.5),(78,1)],[(83,2.5),(-1,1.5)]]
B=[[(76,.5),(78,.5),(79,.5),(83,2.5)],[(86,1),(83,.5),(79,.5),(78,1),(74,1)],[(85,.5),(83,.5),(81,1),(78,.5),(76,.5),(73,1)],[(82,1),(85,.5),(88,.5),(85,1),(82,1)],[(83,.5),(86,.5),(90,1),(88,.5),(86,.5),(83,1)],[(86,1),(81,.5),(78,.5),(74,1),(78,1)],[(79,.5),(83,.5),(86,1),(83,.5),(79,.5),(76,1)],[(85,.5),(82,.5),(78,1),(76,.5),(73,.5),(70,1)]]
M=[[(78,1.5),(76,.5),(74,1),(73,1)],[(74,.5),(78,.5),(81,2),(78,1)],[(79,1),(78,.5),(76,.5),(74,1),(71,1)],[(76,.5),(79,.5),(83,1.5),(81,.5),(79,1)],[(78,1),(74,1),(71,.5),(73,.5),(74,1)],[(79,.5),(78,.5),(76,1),(74,.5),(71,.5),(67,1)],[(70,.5),(73,.5),(76,1),(78,1),(82,1)],[(83,2),(-1,2)]]
D=[[(71,.5),(73,.5),(75,.5),(78,2.5)],[(80,1),(78,.5),(76,.5),(75,1),(71,1)],[(78,.5),(80,.5),(83,1),(85,1),(83,1)],[(82,1),(85,.5),(88,.5),(85,1),(82,1)],[(83,.5),(85,.5),(87,1),(85,.5),(83,.5),(78,1)],[(80,1),(83,.5),(87,.5),(85,1),(83,1)],[(82,.5),(85,.5),(88,1),(87,.5),(85,.5),(82,1)],[(83,2),(78,1),(75,1)]]
H={'Bm':[47,54,59,62],'G':[43,55,59,62],'D':[38,54,57,62],'A':[45,52,57,61],'Em':[40,55,59,64],'Fs7':[42,54,58,64],'B':[47,54,59,63],'E':[40,56,59,64],'GsM':[44,56,59,63],'CsM':[49,56,61,64]}
pa=['Bm','G','D','A','Bm','G','Em','Fs7','Bm','G','D','A','Bm','Em','Fs7','Bm'];pb=['Em','G','A','Fs7','Bm','D','G','Fs7'];pm=['D','D','G','Em','Bm','G','Fs7','Bm'];pd=['B','E','B','Fs7','GsM','E','Fs7','B']
sections=[('Canvas rises over the flame',4,148,'intro'),('Three taps and one answer',16,164,'signal'),('Wind strains every iron rib',16,172,'storm'),('Listening beneath the cloth',16,108,'listen'),('The hidden channel answers',16,156,'decode'),('Cutting open the shelter',24,172,'break'),('Three lights beyond the reef',12,160,'lights'),('One edge left open',8,132,'coda')]
events=[];bars=[];pedals=[];beat=0;bar=0
for title,count,bpm,kind in sections:
 for j in range(count):
  bar+=1
  if kind in ['intro','signal']:line=copy.deepcopy(A[j%16]);h=pa[j%16]
  elif kind in ['storm','decode']:line=copy.deepcopy(B[j%8]);h=pb[j%8]
  elif kind=='listen':line=copy.deepcopy(M[j%8]);h=pm[j%8]
  elif kind=='break':
   if j<16:line=copy.deepcopy(A[j]);h=pa[j]
   else:line=copy.deepcopy(D[j-16]);h=pd[j-16]
  elif kind=='lights':line=copy.deepcopy(D[j%8]);h=pd[j%8]
  else:
   line=copy.deepcopy([[(80,1),(78,.5),(75,.5),(71,1),(68,1)],[(75,.5),(78,.5),(83,1.5),(82,.5),(80,1)],[(76,1),(80,.5),(83,.5),(80,1),(76,1)],[(82,.5),(78,.5),(73,1),(70,1),(-1,1)],[(71,.5),(73,.5),(75,.5),(78,2.5)],[(80,1),(78,.5),(76,.5),(75,1),(71,1)],[(82,.5),(85,.5),(88,1),(85,.5),(82,.5),(78,1)],[(83,2),(78,.5),(75,.5),(71,1)]][j]);h=['E','B','CsM','Fs7','B','E','Fs7','B'][j]
  assert sum(l for n,l in line)==4
  tempo=bpm if kind!='coda' else [132,132,128,124,120,112,104,88][j]
  ch=H[h];vel={'intro':76,'signal':86,'storm':91,'listen':70,'decode':84,'break':94,'lights':89,'coda':74}[kind]
  bars.append(dict(bar=bar,start=beat,beats=4,bpm=tempo,meter_numerator=4,meter_denominator=4,section=title,harmony_name=h,harmony=ch,role_plan=kind,phrase_position=j))
  off=0
  for n,l in line:
   if n>=0:events.append(dict(bar=bar,onset=beat+off,duration=l*.95,pitch=n,velocity=vel+(2 if off==1.5 else 0),voice='melody'))
   off+=l
  # Continuous support belongs to the same chord; it carries no independent theme.
  pattern=[(0,ch[0]),(.5,ch[1]),(1,ch[2]),(1.5,ch[3]),(2,ch[1]),(2.5,ch[2]),(3,ch[3]),(3.5,ch[2])]
  if kind=='listen':pattern=[(0,ch[0]),(1,ch[1]),(2,ch[2]),(3,ch[3])]
  for t,n in pattern:
   if kind=='coda' and j==7 and t>0:continue
   events.append(dict(bar=bar,onset=beat+t,duration=.36 if kind!='listen' else .72,pitch=n,velocity=vel-(24 if t==0 else 36)+(2 if t==2 else 0),voice='bass' if t==0 else 'accompaniment'))
  for t,v in [(0,0),(.12,44),(1.88,0),(2.08,40),(3.88,0)]:pedals.append(dict(onset=beat+t,value=v))
  beat+=4
d=dict(id=65,title='An Umbrella for the Lighthouse',title_zh='给灯塔撑一把伞',stage='v0_original_signal_and_storm_narrative',bars=bars,events=events,pedals=pedals,total_beats=beat,tail_seconds=4)
for f in ['score.json','revisions/score_v0.json']:(P/f).write_text(json.dumps(d,indent=2))
(P/'thematic_material.json').write_text(json.dumps(dict(A=A,B=B,M=M,D=D),indent=2));print(bar,sum(b['beats']*60/b['bpm'] for b in bars)+4)
