# Work 083 · Two substantive revisions

All versions are complete 80-bar scores with the same 7/8 duration map. Version labels do not describe audio passes: no audio was created or reviewed. The changes below were made in the composed melodies, form, harmony, meter grouping and instrumental roles. Dynamics were not used as a substitute for those changes.

## v0: complete initial argument

The first version establishes the E-major calibration material, piano inventory, jammed apparatus, spoon episode, eclipse development, transformed return and a fully decorated tonic ending. The spoon episode initially remains in E major with 2+2+3 grouping and clarinet foreground throughout bars 29–40. It has a lyrical melody, but the image-making discovery has too little harmonic independence from the astronomer's earlier confidence. The last eight bars still contain a conventional flourish-and-cadence response. This version is retained as a complete source, not a sketch excerpt.

## v0 → v1: replace the discovery scene and recompose the development

1. Bars 29–32 acquire Cmaj7–Am6–F# half-diminished–B7 and 3+2+2 grouping. The former E–G♯–A figure is replaced by E–G–A–G–E–D–E–F♯–D♯ with longer, unequal phrase steps. The borrowed G and D give the projected image its own sound.
2. Bars 33–36 change from an all-clarinet extension to a middle-register piano presentation and clarinet reply. Their harmony becomes Cmaj7(#11)–Am7–F# half-diminished–B7. The clarinet's C4 at bar 35 is a new low-register hinge, not a transposed copy of the opening.
3. Bars 37–40 develop E–G♯–F♯ across 3+2+2, with Eadd9–A6–F#m7–Emaj9/D♯. Bars 41–44 assign three piano foreground bars followed by a brief clarinet dominant response. The keyboard can now test the spoon's image while the clarinet leaves room.
4. Bars 49–52 receive a new descending chromatic piano line and C#m7–Dmaj7–F# half-diminished–B7 harmony. The clarinet continuation is recomposed to match that detour rather than its former familiar dominant chain.
5. Bars 57–60 remove the repeated A#–B calibration turn from the returning clarinet theme. Bars 65–68 import the discovery scene's 3+2+2 rhythm and a longer E–G♯–B–A–G♯–F♯–E–F♯ line.

Exact changed bars: 29–44, 49–52, 57–60, 65–68: 28 bars. The exact event removals, additions and metadata changes are in diff_v0_v1.json. diff_v0_v1.patch also preserves the literal full-score difference, including derived phrase data and versioned identifiers.

## v1 → v2: let the failed tools and the honest ending change the form

1. Bars 1–4 are recomposed from thirteen clarinet attacks to eleven, redistributing the opening's rhythm so the main sentence breathes across four bars. E–G♯ is still recognizably the starting gesture, and A# remains a single neighbor to B.
2. Bars 13–16 shorten the clarinet answer from five notes to four, simplify the piano's damaged minor-color turn and soften B7 to Badd9. Bars 25–28 remove a repeated keyboard fragment and leave more space before the clarinet's two-note admission.
3. In bar 23 only, the G♯4 and B4 attacks select genuine ff recordings. The surrounding material remains mf. Those two calls belong to the moment of the fallen spring; they do not manufacture a continuous fourth dynamic layer.
4. Bars 61–64 are reassigned from a clarinet continuation to two bars of piano inventory and two bars of clarinet response. This is a real foreground transfer during the return, not accompaniment made louder.
5. Bars 69–72 move to 3+2+2 and A6–Am6–Eadd9–Badd9. After the piano's six-note abbreviated question, the clarinet gives the unornamented E–G♯–F♯ answer.
6. Bars 73–80 are replaced wholesale. Eleven clarinet attacks in 73–76 become three, then the piano answers with exactly that three-note idea. In 77–79 the piano supplies E4 and the clarinet supplies G♯4–F♯4. The old decorated dominant-tonic cadence is removed in favor of a quiet E-add9 context and final E harmony. The last bar contains no new melodic fourth note. The original ending would have restored the astronomer's elaborate claim; the final ending accepts the honest estimate and gives the spoon back.

Exact changed bars: 1–4, 13–16, 23, 26–28, 61–64, 69–80: 28 bars. Bar 25 retains its opening events while the rest of that four-bar sentence changes. The machine-readable exact list is in diff_v1_v2.json. Dynamic-only changes in bar 23 are counted honestly alongside, not confused with, the substantial phrase and formal changes elsewhere.

## Audit and limits

Every version is checked for exact bar continuity, absolute beat units, duration target, clarinet register and real-layer velocity bands, minimum nominal gates and phrase breaths, distinct nonoverlapping clarinet gates, held piano hand spans, released time for larger leaps, same-key piano overlaps, explicit foreground presence, allowed piano pedals and final release, and twenty nonidentical four-bar event sequences.

These checks cannot verify the Iowa files, their actual release or the audible result. No claim of audition, true legato, physical instrument modeling or sampled sustain is made. Owner integration remains a separate step after this source delivery.
