#!/usr/bin/env python3
"""Work 087: deterministic symbolic composition; Python standard library only.

No audio, sample access, network, MIDI rendering, DSP, or external dependencies.
The complete melodic sentences below are authored bar by bar. Accompaniment
realizes a declared harmony/texture plan; it does not generate melodic loops.
"""
from __future__ import annotations
import copy
import difflib
import hashlib
import json
import math
import statistics
from bisect import bisect_right
from collections import Counter, defaultdict
from pathlib import Path

BASE = Path(__file__).resolve().parent

PC = {'C': 0, 'C#': 1, 'D': 2, 'D#': 3, 'E': 4, 'F': 5,
      'F#': 6, 'G': 7, 'G#': 8, 'A': 9, 'A#': 10, 'B': 11}
def pitch(s):
    return PC[s[:-1]] + 12 * (int(s[-1]) + 1)

# Each entry gives pitches at chord roots/inversions, not a synthesized sound.
# Left hand remains in C#3--C#4; the separate cello occupies C#2--B2.
H = {
    'C#m(add9)': ([49, 52, 56, 63], [49, 52, 56], 37),
    'C#m7':      ([49, 52, 56, 59], [49, 56, 59], 37),
    'C#m/E':     ([52, 56, 61], [52, 56, 61], 40),
    'C#m(add6)': ([49, 52, 56, 58], [49, 52, 58], 37),
    'B6':        ([47, 51, 54, 56], [51, 54, 59], 47),
    'B/D#':      ([51, 54, 59], [51, 54, 59], 39),
    'F#6':       ([42, 46, 49, 51], [49, 54, 58], 42),
    'F#7':       ([42, 46, 49, 52], [49, 52, 58], 42),
    'A#m7b5':    ([46, 49, 52, 56], [49, 52, 58], 46),
    'G#m7':      ([44, 47, 51, 54], [51, 54, 56], 44),
    'D#m7':      ([39, 42, 46, 49], [49, 51, 58], 39),
    'Emaj7':     ([40, 44, 47, 51], [51, 56, 59], 40),
    'E6':        ([40, 44, 47, 49], [49, 52, 56], 40),
    'G#sus4':    ([44, 49, 51, 54], [49, 51, 56], 44),
}

# Notes are written pitch:written-value, with values measured in quarter beats.
# Every bar sums to 3. '_' is a composed rest, not a lost event.
V0 = [
    ('C#m(add9)', 'C#5:.5 E5:.5 D#5:.5 G#5:1.5'),
    ('B6',        'F#5:1 E5:.5 D#5:1 B4:.5'),
    ('F#6',       'F#5:1 G#5:.5 A#5:1 F#5:.5'),
    ('C#m/E',     'G#5:.5 E5:.5 D#5:.5 C#5:1.25 _:.25'),
    ('A#m7b5',    'E5:.75 C#5:.75 G#4:1 A#4:.5'),
    ('G#m7',      'B4:1 C#5:.5 D#5:1 F#5:.5'),
    ('F#6',       'F#5:.5 D#5:.5 C#5:.5 A#4:1 C#5:.5'),
    ('C#m(add9)', 'E5:.5 D#5:.5 C#5:1.5 _:.5'),
    ('Emaj7',     'G#4:.5 B4:.5 C#5:.5 D#5:1 E5:.5'),
    ('B/D#',      'F#5:1 E5:.5 D#5:.5 B4:1'),
    ('F#6',       'A#4:.5 C#5:.5 D#5:.5 F#5:1.5'),
    ('G#m7',      'D#5:.75 B4:.75 G#4:1.25 _:.25'),
    ('C#m7',      'C#5:.5 E5:.5 F#5:.5 G#5:1 B5:.5'),
    ('E6',        'G#5:1 F#5:.5 E5:1 C#5:.5'),
    ('F#6',       'D#5:.5 C#5:.5 A#4:.5 F#5:1 D#5:.5'),
    ('G#sus4',    'C#5:1 D#5:.5 G#4:1.25 _:.25'),
    ('C#m7',      'E5:.5 G#5:.5 F#5:.5 E5:.75 C#5:.75'),
    ('F#7',       'A#4:.5 C#5:.5 D#5:.5 E5:1 F#5:.5'),
    ('B6',        'F#5:.75 G#5:.75 B5:.5 A#5:.5 G#5:.5'),
    ('Emaj7',     'G#5:1 F#5:.5 E5:1.25 _:.25'),
    ('A#m7b5',    'E5:.5 C#5:.5 A#4:.5 G#4:.75 C#5:.75'),
    ('D#m7',      'F#5:.75 D#5:.75 C#5:1 A#4:.5'),
    ('G#m7',      'B4:.5 D#5:.5 F#5:.5 G#5:1 F#5:.5'),
    ('G#sus4',    'D#5:1 C#5:.5 G#4:1.25 _:.25'),
    ('C#m7',      'C#5:1 E5:.5 G#5:1.5'),
    ('E6',        'E5:1 F#5:.5 G#5:1.5'),
    ('A#m7b5',    'A#5:1 G#5:.5 E5:1.5'),
    ('F#7',       'F#5:1 E5:.5 C#5:1.25 _:.25'),
    ('B6',        'D#5:1 F#5:.5 G#5:1.5'),
    ('D#m7',      'F#5:1 E5:.5 D#5:1.5'),
    ('G#m7',      'B4:1 C#5:.5 D#5:1.5'),
    ('C#m7',      'E5:1 D#5:.5 C#5:1.25 _:.25'),
    ('A#m7b5',    'E5:1 G#5:.5 A#5:1.5'),
    ('F#7',       'A#5:1 G#5:.5 F#5:1.5'),
    ('D#m7',      'F#5:1 E5:.5 D#5:1.5'),
    ('G#sus4',    'C#5:1 D#5:.5 G#5:1.25 _:.25'),
    ('C#m7',      'G#5:1 F#5:.5 E5:1.5'),
    ('B6',        'D#5:1 E5:.5 F#5:1.5'),
    ('F#7',       'A#4:1 C#5:.5 E5:1.5'),
    ('G#sus4',    'D#5:1 C#5:.5 G#4:1.25 _:.25'),
    ('Emaj7',     'E4:1.5 G#4:1.5'),
    ('B/D#',      'F#4:1 B4:.5 D#5:1.5'),
    ('C#m7',      'E5:1.5 C#5:1 G#4:.5'),
    ('A#m7b5',    'A#4:1.5 C#5:1 _:.5'),
    ('F#6',       'D#5:1 F#5:.5 C#5:1.5'),
    ('E6',        'B4:.5 C#5:1 E5:1.5'),
    ('D#m7',      'F#5:1.5 D#5:.5 C#5:.5 A#4:.5'),
    ('G#sus4',    'G#4:.5 C#5:.5 D#5:1.5 _:.5'),
    ('C#m7',      'E5:.5 D#5:.5 C#5:.5 G#4:1 C#5:.5'),
    ('F#6',       'A#4:.5 C#5:1 D#5:.5 F#5:1'),
    ('B6',        'G#5:1 F#5:.5 D#5:.75 B4:.75'),
    ('Emaj7',     'G#4:.5 B4:.5 D#5:.5 E5:1.25 _:.25'),
    ('A#m7b5',    'E5:.5 G#5:.5 A#5:.5 G#5:1 E5:.5'),
    ('F#7',       'F#5:.5 E5:.5 C#5:.5 A#4:1 C#5:.5'),
    ('G#m7',      'D#5:.75 F#5:.75 G#5:.5 F#5:.5 D#5:.5'),
    ('G#sus4',    'C#5:.5 D#5:1 G#5:1.25 _:.25'),
    ('C#m(add9)', 'C#5:.5 E5:.5 D#5:.5 G#5:1.5'),
    ('B6',        'F#5:1 E5:.5 D#5:1 B4:.5'),
    ('F#6',       'A#4:.5 C#5:.5 D#5:.5 F#5:1.5'),
    ('C#m/E',     'G#5:1 E5:.5 C#5:1.25 _:.25'),
    ('A#m7b5',    'C#5:.5 E5:.5 G#5:.5 A#5:1 G#5:.5'),
    ('Emaj7',     'G#5:1 F#5:.5 E5:1 B4:.5'),
    ('F#7',       'C#5:.5 E5:.5 F#5:.5 A#5:1 F#5:.5'),
    ('G#m7',      'D#5:1 B4:.5 G#4:1.25 _:.25'),
    ('C#m7',      'E5:.5 G#5:.5 B5:.5 G#5:1 E5:.5'),
    ('E6',        'C#5:.5 E5:.5 F#5:.5 G#5:1 B5:.5'),
    ('B/D#',      'B5:1 A#5:.5 F#5:.5 D#5:1'),
    ('F#6',       'F#5:.5 D#5:.5 C#5:.5 A#4:1.25 _:.25'),
    ('A#m7b5',    'C#5:.5 E5:.5 D#5:.5 G#5:1 A#5:.5'),
    ('D#m7',      'F#5:.75 D#5:.75 C#5:.5 D#5:.5 F#5:.5'),
    ('G#sus4',    'G#5:.5 F#5:.5 D#5:.5 C#5:1 D#5:.5'),
    ('C#m7',      'E5:1 D#5:.5 C#5:1.25 _:.25'),
    ('F#6',       'A#4:1 C#5:.5 F#5:1.5'),
    ('Emaj7',     'G#5:1 F#5:.5 E5:1.5'),
    ('C#m/E',     'E5:.5 D#5:.5 C#5:.5 G#4:1.5'),
    ('G#sus4',    'C#5:1 D#5:.5 G#4:1.25 _:.25'),
    ('C#m7',      'C#5:1 E5:.5 G#5:1.5'),
    ('F#6',       'F#5:1 D#5:.5 C#5:1.5'),
    ('C#m(add9)', 'E5:1 D#5:.5 C#5:1.5'),
    ('C#m(add6)', 'C#5:3'),
]

# First revision: sixteen newly voiced/phrased development bars, including
# six reharmonizations. The initial even quarters become interrupted work.
V1_REWRITE = {
    25: ('C#m7',   'E5:.5 G#5:.5 B5:.5 G#5:.75 F#5:.75'),
    26: ('F#7',    'F#5:.5 E5:.5 C#5:.5 A#4:.5 C#5:.5 E5:.5'),
    27: ('A#m7b5', 'G#5:.75 A#5:.25 G#5:.5 E5:.5 C#5:.5 E5:.5'),
    28: ('D#m7',   'F#5:.5 D#5:.5 C#5:.5 A#4:1 _:.5'),
    29: ('B6',     'B4:.5 D#5:.5 F#5:.5 G#5:.75 F#5:.75'),
    30: ('F#7',    'A#5:.5 G#5:.5 F#5:.5 E5:.5 C#5:.5 E5:.5'),
    31: ('G#m7',   'D#5:.5 B4:.5 C#5:.5 D#5:1 G#5:.5'),
    32: ('C#m7',   'B5:.5 G#5:.5 E5:.5 C#5:1 _:.5'),
    33: ('A#m7b5', 'E5:.5 G#5:.5 A#5:.5 C#6:.75 B5:.75'),
    34: ('F#6',    'A#5:.75 G#5:.25 F#5:.5 D#5:1 F#5:.5'),
    35: ('D#m7',   'F#5:.5 D#5:.5 C#5:.5 A#4:.75 C#5:.75'),
    36: ('G#sus4', 'D#5:.5 F#5:.5 G#5:.5 C#5:1 _:.5'),
    37: ('C#m/E',  'E5:.75 G#5:.75 C#6:.5 B5:.5 G#5:.5'),
    38: ('Emaj7',  'B5:.5 G#5:.5 F#5:.5 E5:1 D#5:.5'),
    39: ('F#7',    'C#5:.5 A#4:.5 C#5:.5 E5:.75 F#5:.75'),
    40: ('G#sus4', 'D#5:.75 C#5:.75 G#4:1 _:.5'),
}

# Second revision: the return is recognized by the original interval cell,
# then continued instead of replayed. Four last phrases have new endings.
V2_REWRITE = {
    57: ('C#m(add9)', 'C#5:.5 E5:.5 D#5:.5 G#5:1 F#5:.5'),
    58: ('B6',        'D#5:.75 F#5:.75 G#5:.5 F#5:.5 D#5:.5'),
    59: ('F#6',       'C#5:.5 D#5:.5 F#5:.5 A#5:1 G#5:.5'),
    60: ('C#m/E',     'G#5:.5 E5:1 C#5:1 _:.5'),
    61: ('A#m7b5',    'E5:.5 G#5:.5 A#5:.5 C#6:1 A#5:.5'),
    62: ('Emaj7',     'B5:.75 G#5:.75 D#5:.5 E5:.5 G#5:.5'),
    63: ('F#7',       'A#5:1 G#5:.5 F#5:.5 E5:.5 C#5:.5'),
    64: ('G#m7',      'D#5:.5 F#5:.5 D#5:.5 B4:1 _:.5'),
    65: ('C#m7',      'C#5:.5 E5:.5 D#5:.5 G#5:.75 B5:.75'),
    66: ('E6',        'C#6:1 B5:.5 G#5:.5 F#5:.5 E5:.5'),
    67: ('B/D#',      'F#5:.5 G#5:1 B5:.75 A#5:.75'),
    68: ('F#6',       'A#5:.75 F#5:.75 D#5:1 _:.5'),
    69: ('A#m7b5',    'C#5:.5 E5:.5 D#5:.5 G#5:1 E5:.5'),
    70: ('D#m7',      'F#5:.75 D#5:.75 A#4:.5 C#5:.5 D#5:.5'),
    71: ('G#sus4',    'C#5:1 D#5:.5 F#5:.5 G#5:1'),
    72: ('C#m7',      'G#5:.5 E5:.5 D#5:.5 C#5:1 _:.5'),
    73: ('F#6',       'A#4:1.5 C#5:.5 D#5:.5 F#5:.5'),
    74: ('Emaj7',     'G#5:1 D#5:.5 E5:1 B4:.5'),
    75: ('C#m/E',     'C#5:.5 E5:1 G#5:.5 E5:1'),
    76: ('G#sus4',    'D#5:.5 C#5:1 G#4:1 _:.5'),
    77: ('C#m7',      'C#5:1 E5:.5 G#5:.75 B5:.25 G#5:.5'),
    78: ('F#6',       'A#5:.5 F#5:1 D#5:.5 C#5:1'),
    79: ('C#m(add9)', 'E5:.75 D#5:.75 G#4:.5 C#5:1'),
    80: ('C#m(add6)', 'C#5:3'),
}

PHRASE_NAMES = [
    '白盐线', '两只水桶', '六层楼梯', '水压变细',
    '松开的夹子', '再等一班车', '抬盆留出的空位', '遮阴网低一格',
    '桶底最后一圈水', '停下来数一遍', '旋紧盐水瓶盖', '水面下的楼影',
    '重新排开的花盆', '临时支架', '低一格的回光', '盆与盆之间',
    '写下更换清单', '收回软管', '晚班车经过街口', '留在原处的刻线',
]
SECTIONS = [
    (1, 16, 'A', '上楼与量水'), (17, 24, 'B', '风掀起遮阴网'),
    (25, 40, 'C', '重排花盆'), (41, 48, 'D', '浅盘旁的停顿'),
    (49, 56, 'E', '重新拉紧'), (57, 72, 'A_return', '降低后的回光'),
    (73, 80, 'Coda', '留待明早'),
]
PHRASE_TEMPOS = [74, 74, 76, 75, 77, 74, 78, 79, 77, 74,
                68, 69, 73, 75, 74, 75, 76, 73, 69, 64]
PHRASE_DYNAMICS = [63, 61, 66, 64, 68, 65, 71, 72, 74, 68,
                   56, 58, 65, 69, 66, 70, 72, 66, 61, 56]

# Every cello note is explicitly placed. Some bars intentionally have no cello.
# Entries use only the one recorded mf pizzicato layer. No sample synthesis.
CELLO = {
    2: [(1.5, 'B2')], 4: [(0, 'E2')],
    5: [(1.5, 'A#2')], 7: [(0, 'F#2')], 8: [(1.5, 'C#2')],
    10: [(0, 'D#2')], 12: [(1.5, 'G#2')], 13: [(0, 'C#2')],
    15: [(1.5, 'F#2')], 16: [(0, 'G#2')],
    17: [(1.5, 'C#2')], 19: [(0, 'B2')], 20: [(1.5, 'E2')],
    22: [(0, 'D#2')], 24: [(1.5, 'G#2')],
    25: [(0, 'C#2')], 27: [(1.5, 'A#2')], 28: [(0, 'F#2')],
    29: [(1.5, 'B2')], 31: [(0, 'G#2')], 32: [(1.5, 'C#2')],
    33: [(0, 'A#2')], 35: [(1.5, 'D#2')], 36: [(0, 'G#2')],
    37: [(1.5, 'C#2')], 39: [(0, 'F#2')], 40: [(1.5, 'G#2')],
    42: [(1.5, 'D#2')], 44: [(0, 'A#2')],
    46: [(1.5, 'E2')], 48: [(0, 'G#2')],
    49: [(0, 'C#2')], 51: [(1.5, 'B2')], 52: [(0, 'E2')],
    53: [(1.5, 'A#2')], 55: [(0, 'G#2')], 56: [(1.5, 'G#2')],
    58: [(1.5, 'B2')], 60: [(0, 'E2')],
    61: [(1.5, 'A#2')], 63: [(0, 'F#2')], 64: [(1.5, 'G#2')],
    65: [(0, 'C#2')], 67: [(1.5, 'D#2')], 68: [(0, 'F#2')],
    69: [(1.5, 'A#2')], 71: [(0, 'G#2')], 72: [(1.5, 'C#2')],
    74: [(1.5, 'E2')], 76: [(0, 'G#2')],
    77: [(1.5, 'C#2')], 78: [(0, 'F#2')], 80: [(0, 'C#2')],
}

V1_CELLO = {26: [(1.5, 'F#2')], 28: [(0, 'D#2')],
            30: [(0, 'F#2')], 34: [(1.5, 'F#2')],
            37: [(1.5, 'E2')], 38: [(0, 'E2')]}
V2_CELLO = {9: [(1.5, 'E2')], 10: [], 12: [(2.25, 'B2')],
            13: [], 14: [(1.5, 'E2')], 16: [(2.25, 'G#2')],
            49: [], 50: [(0, 'F#2')], 51: [(2.25, 'B2')],
            52: [], 54: [(0, 'F#2')], 55: [(1.5, 'D#2')],
            56: [], 59: [(0, 'F#2')], 60: [(2.25, 'E2')],
            62: [(1.5, 'B2')], 64: [(2.25, 'G#2')],
            65: [(1.5, 'C#2')], 66: [(0, 'E2')], 67: [], 68: [(2.25, 'F#2')],
            70: [(0, 'D#2')], 72: [(2.25, 'C#2')],
            73: [(1.5, 'A#2')], 74: [], 75: [(1.5, 'E2')],
            77: [], 78: [(1.5, 'F#2')], 79: [], 80: [(0, 'C#2')]}

PERFORMANCE = {
    'audio_status': 'Symbolic composition only. No audio, DSP, rendering, downloads, installations, or listening performed.',
    'beat_unit': 'Absolute quarter-note beats: 6/8 = three quarter beats per bar; bpm refers to the quarter note.',
    'piano_instrument': 'Natural acoustic piano, existing approved source to be integrated by parent.',
    'piano_hand_span_semitones': 12,
    'piano_same_key_overlap': 'Forbidden across both hands; pedal resonance is excluded from finger span.',
    'piano_position_plan': 'RH five consecutive C#-Dorian scale notes mapped in order to fingers 1--5. LH explicit fingering within C#3--C#4. Every piano event declares position bounds and finger.',
    'piano_large_transfers': 'For every actual position change, release the full prior grip for 75 ms + 12 ms per semitone beyond four. Travel is the larger of actual grip-edge movement and declared position-edge movement. Same-position melodic movement is covered by the explicit finger plan.',
    'piano_pedal': 'CC64 only on piano. Explicit zero releases; numeric depth is an intent, not a promise of sampled half-pedal behavior.',
    'cello_instrument': 'Existing approved short pizzicato cello bank, actual recorded pitch coverage MIDI 36--47.',
    'cello_register': [36, 47],
    'cello_layers': 'Exactly one recorded layer: mf. Every event declares mf. Velocity changes amplitude intent only; no velocity-layer switching is claimed.',
    'cello_articulation': 'Short separate pizzicato triggers with scored releases; no bowed, legato, looped, or sustained articulation.',
    'cello_max_nominal_gate_seconds': 0.5,
    'cello_min_nominal_inter_note_gate_gap_seconds': 0.6,
    'cello_left_hand_clearance_seconds': 0.18,
    'piano_pedal_clearance_before_cello_seconds': 0.24,
    'balance': 'Piano right hand owns the singing line throughout. Cello supplies sparse roots, thirds, or fifths from the same harmony; piano left hand rests around every cello note.',
    'nominal_vs_sample': 'Audits cover score gates and explicit rests. Actual sample onset, release tails, level, timbre, and piano/cello balance require later source and audio checks.',
}

def section_for(bar):
    return next((s, title) for lo, hi, s, title in SECTIONS if lo <= bar <= hi)

def write_json(name, obj):
    (BASE / name).write_text(json.dumps(obj, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')

def time_function(bars):
    starts, seconds, running = [], [], 0.0
    for b in bars:
        starts.append(b['start']); seconds.append(running)
        running += b['beats'] * 60 / b['bpm']
    def at(beat):
        i = min(len(bars) - 1, max(0, bisect_right(starts, beat) - 1))
        return seconds[i] + (beat - starts[i]) * 60 / bars[i]['bpm']
    return at, running

def apply_finger_positions(events, bars, at):
    """Explicit fixed positions, followed by conservative released transfers.

    RH positions contain five consecutive modal notes; no silent thumb-under or
    cross-over maneuver is assumed. A move changes the named position and gets
    measurable release time. LH's modest grips all fit one octave position.
    """
    left_fingers = {49:5, 51:4, 52:4, 54:3, 56:2, 58:2, 59:1, 61:1}
    for e in events:
        if e['instrument'] == 'piano' and e['hand'] == 'left':
            e.update(hand_position_id='L49_61', hand_position_range=[49,61],
                     finger=left_fingers[e['pitch']],
                     fingering_intent='Stable octave position; adjacent alternative keys for a finger never sound together.')
    right = sorted([e for e in events if e['instrument']=='piano' and e['hand']=='right'], key=lambda e:e['onset'])
    scale = [p for p in range(21,109) if p%12 in {1,3,4,6,8,10,11}]
    positions = [scale[i:i+5] for i in range(len(scale)-4)]
    old_pos = None
    for phrase in range(1,21):
        ns = [e for e in right if e['phrase_id']==f'P{phrase:02}_piano']
        j = 0
        while j < len(ns):
            options = []
            for pos in positions:
                if ns[j]['pitch'] not in pos: continue
                count = 0
                for e in ns[j:]:
                    if e['pitch'] not in pos: break
                    count += 1
                movement = 0 if old_pos is None else max(abs(pos[0]-old_pos[0]),abs(pos[-1]-old_pos[-1]))
                options.append((count,-movement,-abs(ns[j]['pitch']-pos[2]),pos))
            count, _, _, chosen = max(options)
            for e in ns[j:j+count]:
                e.update(hand_position_id=f'R{chosen[0]}_{chosen[-1]}',
                         hand_position_range=[chosen[0],chosen[-1]],
                         finger=chosen.index(e['pitch'])+1,
                         fingering_intent='Five consecutive modal notes, low to high = fingers 1--5; released repositioning when the position ID changes.')
            old_pos = chosen
            j += count
    for a,b in zip(right,right[1:]):
        if a['hand_position_id'] == b['hand_position_id']: continue
        pos_move = max(abs(a['hand_position_range'][i]-b['hand_position_range'][i]) for i in (0,1))
        grip_move = abs(a['pitch']-b['pitch'])
        travel = max(pos_move,grip_move)
        need = .075 + .012*max(0,travel-4)
        available = at(b['onset'])-at(a['onset']+a['duration'])
        if available < need + .003:
            # A three-millisecond margin avoids floating-point threshold ties.
            target_seconds = at(b['onset'])-need-.003
            ab = bars[a['bar']-1]
            end_beat = ab['start']+(target_seconds-at(ab['start']))*ab['bpm']/60
            new_duration = end_beat-a['onset']
            assert at(a['onset']+new_duration)-at(a['onset']) >= .055, 'unplayably shortened note'
            a['duration'] = round(min(a['duration'],new_duration),6)
            a['release_reason'] = 'Explicit hand-position change: full grip released before moving.'
        b['hand_shift_before'] = {'from_position':a['hand_position_id'],
                                   'position_edge_travel_semitones':pos_move,
                                   'actual_grip_edge_travel_semitones':grip_move,
                                   'conservative_travel_semitones':travel,
                                   'required_release_seconds':round(need,6)}

def make_score(version):
    sheet = copy.deepcopy(V0)
    cello = copy.deepcopy(CELLO)
    if version >= 1:
        for n, entry in V1_REWRITE.items(): sheet[n-1] = entry
        cello.update(V1_CELLO)
    if version >= 2:
        for n, entry in V2_REWRITE.items(): sheet[n-1] = entry
        cello.update(V2_CELLO)
    bars, events, pedals = [], [], []
    for n, (hn, line) in enumerate(sheet, 1):
        phrase, position = (n-1)//4, (n-1)%4
        section, section_title = section_for(n)
        bpm = PHRASE_TEMPOS[phrase] + [0, 1, 0, -1][position]
        if n >= 77: bpm = [66, 64, 62, 58][n-77]
        start = float((n-1)*3)
        harmony, grip, root = H[hn]
        bars.append({
            'bar': n, 'start': start, 'beats': 3.0, 'bpm': bpm,
            'meter': '6/8', 'meter_numerator': 6, 'meter_denominator': 8,
            'section': section, 'section_title_zh': section_title,
            'harmony_name': hn, 'harmony': harmony,
            'lead_instrument': 'piano',
            'role_plan': '右手歌唱；大提琴短拨弦在共同和声内作稀疏支撑；左手在每个拨弦前后留白。',
            'key_region': 'C# Dorian', 'phrase_id': f'P{phrase+1:02}',
            'phrase_position': position+1,
        })
        local_counts = Counter()
        def add(local, duration, p, vel, instrument, voice, hand, role, **extra):
            local_counts[(instrument, voice)] += 1
            event = {
                'bar': n, 'onset': round(start+local, 6),
                'duration': round(duration, 6), 'pitch': int(p), 'velocity': int(vel),
                'instrument': instrument, 'voice': voice, 'hand': hand, 'role': role,
                'phrase_id': f'P{phrase+1:02}_{instrument}',
                'phrase_label': PHRASE_NAMES[phrase],
                'event_id': f'w87-b{n:02}-{instrument}-{voice}-{local_counts[(instrument, voice)]:02}',
            }
            event.update(extra); events.append(event)

        # Right hand: explicit melody, tiny release gaps, larger phrase breaths.
        tokens = [(t.split(':')[0], float(t.split(':')[1])) for t in line.split()]
        assert abs(sum(d for _, d in tokens)-3) < 1e-8, (n, line)
        local = 0.0
        for j, (note, value) in enumerate(tokens):
            if note != '_':
                gate = value - (0.075 if position == 3 else 0.045)
                if n == 80: gate = 2.88
                vel = PHRASE_DYNAMICS[phrase] + [0, 2, -1, 3, -2, 0][j % 6]
                # Long first notes and approaching cadences carry the phrase.
                if j == 0 and phrase in (8, 16): vel += 2
                pcs = {p % 12 for p in harmony}
                function = 'chord_tone' if pitch(note) % 12 in pcs else 'diatonic_melodic_tension'
                add(local, gate, pitch(note), vel, 'piano', 'melody', 'right', 'lead',
                    harmonic_function=function, written_value_beats=value,
                    articulation='cantabile_finger_release',
                    timing_intent='Authored phrase rhythm; separate key release before the next attack.')
            local += value

        # Pizzicato: constant recorded layer, explicit short gates and rests.
        cello_entries = cello.get(n, [])
        for k, (on, name) in enumerate(cello_entries):
            gate = 0.34 if 25 <= n <= 40 else 0.38
            if n >= 73: gate = 0.32
            add(on, gate, pitch(name), 62 + (1 if 25 <= n <= 40 else 0),
                'cello', 'cello_pizzicato', 'not_applicable', 'harmonic_support',
                layer='mf', sample_layer='mf',
                articulation='pizzicato_short_separate',
                onset_reference='ordinary_trigger',
                velocity_controls='amplitude_only_single_recorded_mf_layer',
                timing_intent='Short nominal key gate with explicit release and rest; sample release remains to be measured.',
                harmonic_function='chord_tone')

        # Accompaniment is deliberately absent around the cello's entire gate.
        # All possible attacks are filtered before note creation, in seconds.
        sparse = 41 <= n <= 48 or n >= 73
        energetic = 25 <= n <= 40 and version >= 1
        texture = position
        if sparse:
            plans = [(0.0, 0.82, 'dyad'), (1.5, 0.75, 'single')]
        elif energetic:
            plans = [(0.0, 0.58, 'dyad'), (0.75, 0.35, 'single'),
                     (1.5, 0.6, 'dyad'), (2.25, 0.34, 'single')]
        elif texture == 0:
            plans = [(0.0, 0.86, 'dyad'), (1.5, 0.84, 'single')]
        elif texture == 1:
            plans = [(0.0, 0.78, 'single'), (1.5, 0.76, 'dyad')]
        elif texture == 2:
            plans = [(0.0, 0.65, 'single'), (0.75, 0.43, 'single'), (1.5, 0.84, 'dyad')]
        else:
            plans = [(0.0, 0.9, 'dyad'), (1.5, 0.7, 'single')]
        if version >= 2 and 57 <= n <= 72:
            # Broken dyads replace the original unchanging two-pulse supports.
            plans = [(0.0, 0.66, 'single'), (0.75, 0.4, 'single'),
                     (1.5, 0.78, 'dyad')]
        if n == 80:
            plans = [(1.0, 1.7, 'final')]
        seconds_per_beat = 60 / bpm
        support_vel = PHRASE_DYNAMICS[phrase] - 23
        for j, (on, dur, kind) in enumerate(plans):
            if any((on < co + (0.32 if n >= 73 else 0.34 if 25 <= n <= 40 else 0.38) + 0.18 / seconds_per_beat and
                    on + dur > co - 0.18 / seconds_per_beat) for co, _ in cello_entries):
                continue
            if kind == 'single':
                ps = [grip[(j + position) % len(grip)]]
            elif kind == 'final':
                ps = [49, 52, 58]
            elif position in (0, 2):
                ps = [grip[0], grip[2]]
            else:
                ps = [grip[0], grip[1]]
            for p in ps:
                add(on, dur, p, support_vel + (2 if j == 0 else 0),
                    'piano', 'accompaniment', 'left', 'support',
                    harmonic_function='chord_tone', articulation='lightly_detached_support')

        # Pedal changes twice a bar, clearing harmony and cello-sensitive bass.
        # No sustain CC is ever assigned to cello.
        for on, off in ((0.07, 1.39), (1.57, 2.88)):
            if n == 80: break
            depth = 42 if sparse else 54
            if 25 <= n <= 40 and version >= 1: depth = 36
            pedals.append({'bar': n, 'onset': round(start+on, 6), 'value': depth,
                           'instrument': 'piano', 'controller': 64,
                           'phrase_id': f'P{phrase+1:02}_piano', 'kind': 'partial_intent'})
            pedals.append({'bar': n, 'onset': round(start+off, 6), 'value': 0,
                           'instrument': 'piano', 'controller': 64,
                           'phrase_id': f'P{phrase+1:02}_piano', 'kind': 'release'})
        if n == 80:
            pedals.extend([
                {'bar': n, 'onset': start+1.06, 'value': 48, 'instrument': 'piano', 'controller': 64,
                 'phrase_id': 'P20_piano', 'kind': 'partial_intent'},
                {'bar': n, 'onset': start+2.95, 'value': 0, 'instrument': 'piano', 'controller': 64,
                 'phrase_id': 'P20_piano', 'kind': 'release'},
            ])

    events.sort(key=lambda e: (e['onset'], e['instrument'], e['pitch'], e['event_id']))
    at, _ = time_function(bars)
    # Clear pedal-resonating low piano notes as well as finger-held notes before
    # each pluck. RH fingering carries the melody across these pedal clearances.
    cello_onsets = sorted(e['onset'] for e in events if e['instrument'] == 'cello')
    for k in range(0, len(pedals), 2):
        down, up = pedals[k], pedals[k+1]
        upcoming = [co for co in cello_onsets if co > down['onset'] and at(co)-at(up['onset']) < .24]
        if upcoming:
            target = at(upcoming[0]) - .24
            pb = bars[up['bar']-1]
            up['onset'] = round(pb['start'] + (target-at(pb['start']))*pb['bpm']/60, 6)
            assert up['onset'] > down['onset'], 'pedal window inversion'
    apply_finger_positions(events, bars, at)
    for e in events:
        e['target_on_beats'] = e['onset']
        e['target_off_beats'] = round(e['onset']+e['duration'], 6)
        e['target_on_seconds'] = round(at(e['onset']), 6)
        e['target_off_seconds'] = round(at(e['onset']+e['duration']), 6)
    phrases = []
    for i, name in enumerate(PHRASE_NAMES, 1):
        for instrument in ('piano', 'cello'):
            ns = [e for e in events if e['phrase_id'] == f'P{i:02}_{instrument}']
            if not ns: continue
            lo = min(e['onset'] for e in ns)
            hi = max(e['onset']+e['duration'] for e in ns)
            phrases.append({
                'phrase_id': f'P{i:02}_{instrument}', 'instrument': instrument,
                'phrase_label': name, 'first_bar': (i-1)*4+1, 'last_bar': i*4,
                'section': section_for((i-1)*4+1)[0],
                'role': 'lead_and_support' if instrument == 'piano' else 'harmonic_support',
                'layer': 'not_applicable' if instrument == 'piano' else 'mf',
                'layers_used': [] if instrument == 'piano' else ['mf'],
                'roles_used': sorted({e['role'] for e in ns}),
                'voices_used': sorted({e['voice'] for e in ns}),
                'target_on_beats': round(lo, 6), 'target_off_beats': round(hi, 6),
                'target_on_seconds': round(at(lo), 6), 'target_off_seconds': round(at(hi), 6),
                'timing_intent': 'Four-bar breathing unit with explicitly scored note gates and rests.',
            })
    return {
        'id': 87, 'title': 'The Rooftop Tide Pool', 'title_zh': '屋顶的潮池',
        'version': f'v{version}',
        'instrumentation': ['natural_acoustic_piano', 'short_pizzicato_cello_single_mf_layer'],
        'bars': bars, 'events': events, 'phrases': phrases, 'pedals': pedals,
        'total_beats': 240.0, 'tail_seconds': 7.0,
        'performance_contract': copy.deepcopy(PERFORMANCE),
    }

def audit(score):
    errors = []
    bars, ev = score['bars'], score['events']
    at, total = time_function(bars)
    cello = sorted([e for e in ev if e['instrument'] == 'cello'], key=lambda e:e['onset'])
    piano = [e for e in ev if e['instrument'] == 'piano']
    melody = sorted([e for e in piano if e['voice'] == 'melody'], key=lambda e:e['onset'])
    for i, b in enumerate(bars):
        if (b['bar'], b['start'], b['beats'], b['meter_numerator'], b['meter_denominator']) != (i+1, i*3, 3, 6, 8): errors.append(f'bar grid {i+1}')
    if len(bars) != 80 or score['total_beats'] != 240: errors.append('total grid')
    if not 195 <= total + score['tail_seconds'] <= 220: errors.append('duration')
    ids = [e['event_id'] for e in ev]
    if len(set(ids)) != len(ids): errors.append('duplicate event id')
    for e in ev:
        if not all(math.isfinite(e[k]) for k in ('onset', 'duration', 'pitch', 'velocity')): errors.append('nonfinite')
        if e['duration'] <= 0 or e['onset'] < 0 or e['onset'] + e['duration'] > 240: errors.append('event bounds')
        b = bars[e['bar']-1]
        if not b['start'] <= e['onset'] < b['start'] + b['beats']: errors.append('event/bar association')
        if not (1 <= e['velocity'] <= 127 and 0 <= e['pitch'] <= 127): errors.append('MIDI bound')
        if e['instrument'] == 'cello':
            if not 36 <= e['pitch'] <= 47: errors.append('cello source range')
            if e.get('layer') != 'mf' or e.get('sample_layer') != 'mf': errors.append('cello layer')
            if e.get('articulation') != 'pizzicato_short_separate': errors.append('cello articulation')
        elif e['hand'] not in ('left', 'right'): errors.append('piano hand')
        if e['voice'] != 'melody' and e['pitch'] % 12 not in {p % 12 for p in b['harmony']}:
            errors.append(f'nonchord support bar {e["bar"]} pitch {e["pitch"]}')

    endpoints = defaultdict(list)
    for i, e in enumerate(piano):
        endpoints[round(e['onset'], 6)].append((1, i))
        endpoints[round(e['onset']+e['duration'], 6)].append((0, i))
    active, maxspan, maxkeys = {}, {'left': 0, 'right': 0}, {'left': 0, 'right': 0}
    same_keys, crossings = [], []
    for t, changes in sorted(endpoints.items()):
        for kind, i in sorted(changes):
            if kind == 0: active.pop(i, None)
            else:
                e = piano[i]
                if any(a['pitch'] == e['pitch'] for a in active.values()): same_keys.append([t, e['pitch']])
                active[i] = e
        hands = {h:[e['pitch'] for e in active.values() if e['hand'] == h] for h in ('left', 'right')}
        for h, ps in hands.items():
            if ps:
                maxspan[h] = max(maxspan[h], max(ps)-min(ps))
                maxkeys[h] = max(maxkeys[h], len(ps))
        if hands['left'] and hands['right'] and max(hands['left']) >= min(hands['right']): crossings.append(t)
    if same_keys or crossings or max(maxspan.values()) > 12: errors.append('piano geometry')
    wide = []
    for hand in ('left', 'right'):
        groups = defaultdict(list)
        for e in piano:
            if e['hand'] == hand: groups[e['onset']].append(e)
        prior, all_release = None, 0
        for on, ns in sorted(groups.items()):
            center = (max(e['pitch'] for e in ns)+min(e['pitch'] for e in ns))/2
            if prior is not None and abs(center-prior)>12:
                gap = at(on)-at(all_release)
                dist = abs(center-prior)
                required = .22 if dist > 21 else .18 if dist > 17 else .12
                wide.append({'hand':hand, 'onset':on, 'distance':dist,
                             'released_seconds':round(gap, 6), 'required_seconds':required})
                if gap+1e-8 < required: errors.append('unreleased large hand transfer')
            prior = center
            all_release = max(all_release, *(e['onset']+e['duration'] for e in ns))

    position_checks = []
    for hand in ('left','right'):
        groups = defaultdict(list)
        for e in piano:
            if e['hand'] == hand: groups[e['onset']].append(e)
            if not (1 <= e['finger'] <= 5 and e['hand_position_range'][0] <= e['pitch'] <= e['hand_position_range'][1]): errors.append('finger/position declaration')
        previous, last_release = None, 0
        for on, ns in sorted(groups.items()):
            if len({e['finger'] for e in ns}) != len(ns): errors.append('same finger two simultaneous keys')
            if previous and previous[0]['hand_position_id'] != ns[0]['hand_position_id']:
                old_bounds = [min(e['pitch'] for e in previous),max(e['pitch'] for e in previous)]
                new_bounds = [min(e['pitch'] for e in ns),max(e['pitch'] for e in ns)]
                grip = max(abs(a-b) for a,b in zip(old_bounds,new_bounds))
                pos = max(abs(a-b) for a,b in zip(previous[0]['hand_position_range'],ns[0]['hand_position_range']))
                travel = max(grip,pos)
                need = .075 + .012*max(0,travel-4)
                available = at(on)-at(last_release)
                position_checks.append({'hand':hand, 'onset':on,
                                        'actual_grip_edge_travel_semitones':grip,
                                        'position_edge_travel_semitones':pos,
                                        'required_release_seconds':round(need,6),
                                        'available_release_seconds':round(available,6)})
                if available + 1e-6 < need: errors.append('insufficient released position travel')
            previous = ns
            last_release = max(last_release,*(e['onset']+e['duration'] for e in ns))

    cello_gates = [at(e['onset']+e['duration'])-at(e['onset']) for e in cello]
    cello_gaps = [at(b['onset'])-at(a['onset']+a['duration']) for a,b in zip(cello,cello[1:])]
    if max(cello_gates) > .5 or min(cello_gaps) < .6: errors.append('cello gate/rest')
    left = [e for e in piano if e['hand'] == 'left']
    clearance, infringements = [], []
    for c in cello:
        c_on, c_off = at(c['onset']), at(c['onset']+c['duration'])
        before = [c_on-at(e['onset']+e['duration']) for e in left if e['onset']+e['duration'] <= c['onset']+1e-8]
        after = [at(e['onset'])-c_off for e in left if e['onset'] >= c['onset']+c['duration']-1e-8]
        overlap = [e['event_id'] for e in left if e['onset'] < c['onset']+c['duration'] and e['onset']+e['duration'] > c['onset']]
        gap = min(before+after) if before+after else 999
        clearance.append(gap)
        if overlap or gap < .18-1e-8: infringements.append({'cello_event':c['event_id'], 'overlap':overlap, 'gap':gap})
    if infringements: errors.append('left hand/cello clearance')
    effective_clearances = []
    pedal_pairs = list(zip(score['pedals'][::2], score['pedals'][1::2]))
    effective_left = []
    for e in left:
        end = e['onset']+e['duration']
        for down, up in pedal_pairs:
            if down['onset'] <= end < up['onset']:
                end = up['onset']; break
        effective_left.append((e['onset'], end))
    for c in cello:
        on, off = c['onset'], c['onset']+c['duration']
        preceding = [at(on)-at(end) for st,end in effective_left if end <= on+1e-8]
        following = [at(st)-at(off) for st,end in effective_left if st >= off-1e-8]
        overlap = any(st < off and end > on for st,end in effective_left)
        smallest = min(preceding+following)
        effective_clearances.append(smallest)
        if overlap or smallest < .18-1e-6: errors.append('pedal-extended left hand/cello clearance')
    if {p['instrument'] for p in score['pedals']} != {'piano'} or score['pedals'][-1]['value'] != 0: errors.append('pedal ownership/release')

    ph_results = []
    signatures = []
    for i in range(20):
        ns = [e for e in melody if i*4 < e['bar'] <= (i+1)*4]
        signatures.append(tuple((e['onset']-12*i, e['pitch'], e['duration']) for e in ns))
        ph_results.append({'phrase_id':f'P{i+1:02}_piano', 'bars':[4*i+1, 4*i+4],
                           'melody_range':[min(e['pitch'] for e in ns), max(e['pitch'] for e in ns)],
                           'melody_note_count':len(ns),
                           'start_seconds':round(at(i*12), 6), 'end_seconds':round(at((i+1)*12), 6)})
    duplicate_phrases = [[a+1,b+1] for a in range(20) for b in range(a+1,20) if signatures[a] == signatures[b]]
    if duplicate_phrases: errors.append('copied entire four-bar phrase')
    maximum_leap = max(abs(a['pitch']-b['pitch']) for a,b in zip(melody,melody[1:]))
    if maximum_leap > 12: errors.append('melody leap over octave')
    return {
        'version':score['version'], 'status':'PASS' if not errors else 'FAIL',
        'passed':not errors, 'errors':errors, 'bars':len(bars), 'events':len(ev),
        'event_counts':dict(Counter(e['instrument'] for e in ev)),
        'voice_counts':dict(Counter(e['voice'] for e in ev)),
        'total_beats':score['total_beats'], 'tempo_duration_seconds':round(total,6),
        'tail_seconds':score['tail_seconds'], 'with_tail_seconds':round(total+score['tail_seconds'],6),
        'piano_pitch_range':[min(e['pitch'] for e in piano),max(e['pitch'] for e in piano)],
        'piano_handspans':maxspan, 'maximum_simultaneous_keys':maxkeys,
        'piano_same_key_overlaps':same_keys, 'piano_hand_crossings':crossings,
        'large_transfer_checks':wide,
        'finger_position_transfer_checks':position_checks,
        'finger_position_transfer_count':len(position_checks),
        'finger_position_release_rule':'75 ms + 12 ms per semitone beyond four, using maximum of actual grip-edge and declared position-edge travel.',
        'melody_bars':sorted({e['bar'] for e in melody}),
        'maximum_successive_melody_leap_semitones':maximum_leap,
        'melody_median_velocity':statistics.median(e['velocity'] for e in melody),
        'piano_support_median_velocity':statistics.median(e['velocity'] for e in left),
        'cello_pitch_range':[min(e['pitch'] for e in cello),max(e['pitch'] for e in cello)],
        'cello_layers_used':sorted({e['sample_layer'] for e in cello}),
        'cello_velocity_range':[min(e['velocity'] for e in cello),max(e['velocity'] for e in cello)],
        'cello_min_nominal_gate_seconds':round(min(cello_gates),6),
        'cello_max_nominal_gate_seconds':round(max(cello_gates),6),
        'cello_min_nominal_inter_note_release_gap_seconds':round(min(cello_gaps),6),
        'cello_monophonic':min(cello_gaps)>=0,
        'cello_bars':sorted({e['bar'] for e in cello}),
        'minimum_left_hand_clearance_from_cello_gate_seconds':round(min(clearance),6),
        'left_hand_cello_clearance_infringements':infringements,
        'minimum_pedal_extended_left_hand_clearance_seconds':round(min(effective_clearances),6),
        'support_harmony_mismatches':0 if not any('nonchord support' in x for x in errors) else sum('nonchord support' in x for x in errors),
        'unique_four_bar_melody_sentences':len(set(signatures)),
        'duplicate_full_phrase_pairs':duplicate_phrases,
        'phrase_analysis':ph_results,
        'pedal_count':len(score['pedals']), 'pedal_values':sorted({p['value'] for p in score['pedals']}),
        'source_or_audio_verification_performed':False,
        'limitations':'Symbolic feasibility only. Finger gates, nominal rests, sample-range contract and harmony were checked. No audio was generated or heard; numerical PASS is not an aesthetic or sampled-performance approval.',
    }

def revision_diff(a, b):
    changed, substantial, entries = [], [], []
    ignored = {'velocity','target_on_seconds','target_off_seconds','event_id','timing_intent'}
    def structure(ns):
        return [{k:v for k,v in e.items() if k not in ignored} for e in ns]
    for n in range(1,81):
        ae = [e for e in a['events'] if e['bar'] == n]
        be = [e for e in b['events'] if e['bar'] == n]
        ab, bb = a['bars'][n-1], b['bars'][n-1]
        ap = [p for p in a['pedals'] if p['bar'] == n]
        bp = [p for p in b['pedals'] if p['bar'] == n]
        if ae != be or ab != bb or ap != bp:
            changed.append(n)
            if structure(ae) != structure(be) or ab != bb: substantial.append(n)
            entries.append({'bar':n, 'before_bar':ab, 'after_bar':bb,
                            'before_events':ae, 'after_events':be,
                            'before_pedals':ap, 'after_pedals':bp})
    return {'from_version':a['version'], 'to_version':b['version'],
            'changed_bars':changed, 'structural_harmonic_or_note_changed_bars':substantial,
            'substantive_bar_count':len(substantial),
            'before_sha256':hashlib.sha256((BASE/f'score_{a["version"]}.json').read_bytes()).hexdigest(),
            'after_sha256':hashlib.sha256((BASE/f'score_{b["version"]}.json').read_bytes()).hexdigest(),
            'changes':entries,
            'phrase_metadata_before':a['phrases'], 'phrase_metadata_after':b['phrases']}

def hash_manifest():
    files = {}
    for p in sorted(BASE.iterdir()):
        if p.is_file() and p.name != 'hash_manifest.json':
            files[p.name] = {'bytes':p.stat().st_size, 'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
    write_json('hash_manifest.json', {'algorithm':'SHA-256', 'files':files,
                                    'excludes_self':True, 'scope':'Every regular file in this draft folder.'})

def main():
    scores = [make_score(i) for i in range(3)]
    audits = []
    for i, s in enumerate(scores):
        write_json(f'score_v{i}.json', s)
        a = audit(s); audits.append(a); write_json(f'audit_v{i}.json', a)
    (BASE/'score.json').write_bytes((BASE/'score_v2.json').read_bytes())
    for ai, bi in ((0,1),(1,2)):
        write_json(f'exact_diff_v{ai}_to_v{bi}.json', revision_diff(scores[ai],scores[bi]))
        pa,pb = BASE/f'score_v{ai}.json', BASE/f'score_v{bi}.json'
        diff = difflib.unified_diff(pa.read_text().splitlines(True), pb.read_text().splitlines(True),
                                    fromfile=pa.name, tofile=pb.name)
        (BASE/f'exact_diff_v{ai}_to_v{bi}.patch').write_text(''.join(diff), encoding='utf-8')
    hash_manifest()
    print(json.dumps([{k:a[k] for k in ('version','status','events','with_tail_seconds','errors')} for a in audits], ensure_ascii=False, indent=2))
    if not all(a['passed'] for a in audits): raise SystemExit(1)

if __name__ == '__main__': main()
