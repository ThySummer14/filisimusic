from pathlib import Path
import json
P=Path(__file__).parent;d=json.loads((P/'revisions/score_v2.json').read_text());changed=[]
# On selected signal statements the low hand reaches the same long answer, rather than continuing its usual eighths.
for bar in [5,13,69,77,85,93,109]:
 b=d['bars'][bar-1];ch=b['harmony'];d['events']=[e for e in d['events'] if not(e['bar']==bar and e['voice'] in ['bass','accompaniment'])]
 for t,n,l,v in [(0,ch[0],.32,62),(.5,ch[1],.32,52),(1,ch[2],.32,54),(1.5,ch[1],2.3,52),(1.5,ch[3],2.3,52)]:d['events'].append(dict(bar=bar,onset=b['start']+t,duration=l,pitch=n,velocity=v,voice='bass' if t==0 else 'accompaniment'))
 changed.append(bar)
# Final chord has a close-position left hand and a shared last arrival.
b=d['bars'][-1];d['events']=[e for e in d['events'] if not(e['bar']==b['bar'] and e['voice'] in ['bass','accompaniment'])]
for t,n,l,v in [(0,47,.35,49),(.5,59,2.25,40),(.5,63,2.25,40),(.5,66,2.25,40),(3,59,.88,38),(3,63,.88,38),(3,66,.88,38)]:d['events'].append(dict(bar=b['bar'],onset=b['start']+t,duration=l,pitch=n,velocity=v,voice='bass' if t==0 else 'accompaniment'))
for b in d['bars']:
 if b['harmony_name']=='GsM':b['harmony_name']='Gsm'
 if b['harmony_name']=='CsM':b['harmony_name']='Csm'
last=d['bars'][-1]['start'];d['pedals']=[e for e in d['pedals'] if e['onset']<last]+[dict(onset=last,value=0),dict(onset=last+.15,value=50),dict(onset=d['total_beats']+1,value=0)];d['events'].sort(key=lambda e:(e['onset'],e['pitch']));d['stage']='v3_joint_signal_landings_and_compact_final_answer'
for f in ['score.json','revisions/score_v3.json']:(P/f).write_text(json.dumps(d,indent=2))
(P/'revisions/pass3.json').write_text(json.dumps({'round':3,'kind':'substantive_coordination_revision','changes':['At seven important signal statements, replace the usual left-hand eighth pattern with three short steps and a held dyad arriving with the long melodic answer. The story signal is now shared across the hands.','Give the finalB-major line a close-position left-hand chord and a shared last arrival, with a deliberate pedal release after the final note.','Clarify internal minor-chord labelsGsm/Csm; this label correction alone is not counted as a musical change.'],'signal_bars':changed,'human_listening_review':False},indent=2))
