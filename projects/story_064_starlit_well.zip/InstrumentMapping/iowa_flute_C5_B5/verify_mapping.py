#!/usr/bin/env python3
"""Read-only deterministic verification of sources, crops, SFZ and bounds."""
import os, resource
resource.setrlimit(resource.RLIMIT_AS,(150*1024**2,150*1024**2))
resource.setrlimit(resource.RLIMIT_CPU,(90,90))
if hasattr(os,'sched_getaffinity'):
    os.sched_setaffinity(0,{min(os.sched_getaffinity(0))})
import aifc, hashlib, io, json, math, pathlib, re, statistics, wave
P=pathlib.Path(__file__).resolve().parent
manifest=json.loads((P/'mapping_manifest.json').read_text())
analysis=json.loads((P/'scale_analysis.json').read_text())
download=json.loads((P/'download_report.json').read_text())
assert download['complete']
assert sum((P/f['filename']).stat().st_size for f in download['files'])==6_719_662<=7_000_000
assert len(download['files'])==2 and len(manifest['files'])==24
verified=[]
for layer in analysis['layers']:
    file=P/layer['source_file']
    assert hashlib.sha256(file.read_bytes()).hexdigest()==layer['sha256']
    with aifc.open(str(file),'rb') as a:
        raw=a.readframes(a.getnframes());sr=a.getframerate()
    assert [n['midi'] for n in layer['notes']]==list(range(72,84))
    previous_end=0
    for n in layer['notes']:
        assert n['crop_start_frame']>=previous_end
        previous_end=n['crop_end_frame']
        expected=-statistics.median(w['median_deviation_cents'] for w in n['windows'])
        assert round(expected,2)==n['tune_cents']
        assert len(n['windows'])==3
        assert all(len(w['frames'])==17 for w in n['windows'])
        assert all(f['nearest_midi']==n['midi'] and f['periodicity']>.9 for w in n['windows'] for f in w['frames'])
        row=next(r for r in manifest['files'] if r['midi']==n['midi'] and r['layer']==layer['layer'])
        source=raw[n['crop_start_frame']*2:n['crop_end_frame']*2]
        assert hashlib.sha256(source).hexdigest()==row['source_pcm_sha256']
        little=bytearray(len(source));little[0::2]=source[1::2];little[1::2]=source[0::2]
        out=io.BytesIO()
        with wave.open(out,'wb') as w:
            w.setnchannels(1);w.setsampwidth(2);w.setframerate(sr);w.writeframes(little)
        actual=(P/row['derived_file']).read_bytes()
        assert out.getvalue()==actual,'Deterministic rebuilt WAV differs'
        assert hashlib.sha256(actual).hexdigest()==row['sha256']
        verified.append(row['derived_file'])
sfz=(P/manifest['sfz']).read_text()
regions=[line for line in sfz.splitlines() if line.startswith('<region>')]
groups=[line for line in sfz.splitlines() if line.startswith('<group>')]
assert groups==['<group> lovel=1 hivel=55','<group> lovel=56 hivel=127']
assert len(regions)==24 and 'loop_mode=no_loop' in sfz
assert 'loop_start=' not in sfz and 'loop_end=' not in sfz
for line,row in zip(regions,manifest['files']):
    assert f"key={row['midi']} " in line
    assert f"pitch_keycenter={row['midi']} " in line
    assert f"tune={row['tune_cents']:.2f} " in line
    assert line.endswith('sample='+row['derived_file'])
    assert (P/row['derived_file']).is_file()
limit=math.floor((min(r['active_body_after_tuning_seconds'] for r in manifest['files'])-.2)*20)/20
assert manifest['recommended_max_note_seconds']==limit==1.6
size=sum(p.stat().st_size for p in P.rglob('*') if p.is_file())
assert size<20_000_000
print(json.dumps({'verified_lossless_wavs':len(verified),'verified_short_time_pitch_frames':24*3*17,
                  'source_bytes':6_719_662,'total_directory_bytes':size,
                  'max_written_note_seconds':limit,'sfz':'valid static mapping; parent render still required',
                  'deterministic_wav_rebuild_matches':True,'source_sha256_matches':True},indent=2))
