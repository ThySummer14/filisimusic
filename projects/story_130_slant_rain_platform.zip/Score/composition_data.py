from copy import deepcopy

def pitch(s):
 return 12*(int(s[-1])+1)+{'C':0,'D':2,'E':4,'F':5,'G':7,'A':9,'B':11}[s[0]]+s[1:-1].count('#')-s[1:-1].count('b')
def decode(line):
 result=[];t=0
 for token in line.split():
  name,units=token.split(':');dur=float(units)/2
  if name!='R':result.append((pitch(name),t,dur))
  t+=dur
 return result,t
class Writer:
 def __init__(self):self.bars=[];self.events=[];self.pedals=[];self.start=0;self.n=0
 def bar(self,name,bpm,beats,h,ch):
  self.n+=1;self.beats=beats;self.bpm=bpm;self.ch=ch
  numerator,denominator=(int(beats*2),8) if beats in (2.5,3.5) else ((12,8) if METER=='12/8' else (6,8) if METER=='6/8' else (int(beats),4))
  self.bars.append(dict(bar=self.n,start=self.start,beats=beats,bpm=bpm,meter_numerator=numerator,meter_denominator=denominator,section=name,harmony_name=h,harmony=ch))
 def add(self,p,t,d,v=72,inst='piano',voice='theme',hand='right',art='detached'):
  if d>0 and t<self.beats:
   self.events.append(dict(bar=self.n,onset=round(self.start+t,6),duration=round(min(d,self.beats-t),6),pitch=int(p),velocity=max(1,min(127,int(v))),instrument=inst,voice=voice,hand=hand if inst=='piano' else 'none',articulation=art))
 def line(self,line,v=80,hand='right',transpose=0):
  notes,total=decode(line);assert abs(total-self.beats)<1e-7,(self.n,total,self.beats,line)
  for p,t,d in notes:self.add(p+transpose,t,max(.11,d-.09),v+(3 if t==0 else 0),hand=hand)
  return notes
 def release(self,amount=0,length=.7):
  self.pedals.append(dict(bar=self.n,onset=self.start,controller=64,value=0,instrument='piano'))
  if amount:
   self.pedals.extend([dict(bar=self.n,onset=self.start+.05,controller=64,value=amount,instrument='piano'),dict(bar=self.n,onset=self.start+length,controller=64,value=0,instrument='piano')])
  self.start+=self.beats
 def result(self,level):
  self.pedals.append(dict(bar=self.n,onset=self.start-.01,controller=64,value=0,instrument='piano'))
  return dict(id=ID,title=TITLE,title_zh=TITLE_ZH,version=f'v{level}',bars=self.bars,events=self.events,pedals=self.pedals,total_beats=self.start,tail_seconds=5,instrument_map=INSTRUMENT_MAP)
def material(level):
 n=0
 for section,bpm,beats,texture,hs,phrase_names in BLOCKS:
  lines=[]
  for pn in phrase_names.split():lines+=P[pn].split('|')
  harmonies=hs.split();assert len(lines)==len(harmonies),(section,len(lines),len(harmonies))
  for h,line in zip(harmonies,lines):
   n+=1
   for lv,rev in [(1,REV1),(2,REV2)]:
    if level>=lv and n in rev:h,line=rev[n]
   yield n,section,bpm,beats,texture,h,line
ID=130;TITLE='Slant Rain on the Platform';TITLE_ZH='月台上的斜雨';METER='12/8';INSTRUMENT_MAP={'piano':'piano','clarinet':'clarinet'}
RENDERER_NOTES='64 bars of 12/8, six quarter-note beats per bar. Four dotted-quarter pulses. Clarinet C4–B4; piano rapid figures and broad leaps separate from sustained hand positions.'
H={'Am':[45,52,60],'F':[41,53,57],'C':[36,52,55],'G':[43,55,59],'Dm':[38,53,57],'E7':[40,56,62],'Am/E':[40,57,60],'Bb':[46,53,62],'Fmaj7':[41,52,57],'G6':[43,52,59],'Am9':[45,59,60]}
P={
'a':'E5:1 A5:2 G5:1 E5:2 C5:1 D5:1 E5:1 A5:1 G5:2|F5:1 A5:2 C6:1 A5:2 G5:1 F5:1 E5:1 C5:1 F5:2|E5:1 G5:1 C6:1 B5:1 G5:2 E5:1 D5:1 C5:1 E5:1 G5:2|D5:1 G5:2 B5:1 A5:2 G5:1 D5:1 B4:2 R:2',
'b':'A5:2 E5:1 C5:1 E5:2 A5:1 B5:1 C6:1 B5:1 A5:2|F5:2 D5:1 A4:1 D5:2 F5:1 A5:1 C6:1 A5:1 F5:2|G#5:1 B5:1 E6:2 D6:1 B5:1 G#5:2 E5:2 R:2|A5:2 E5:1 C5:1 A4:2 C5:1 E5:1 A5:2 R:2',
'glass':'C5:3 E5:1 A5:2 G5:2 E5:2 R:2|C5:2 F5:1 A5:1 C6:2 A5:2 F5:2 R:2|B4:2 D5:1 G5:1 B5:2 A5:2 G5:2 R:2|G#4:2 B4:1 E5:1 G#5:2 F5:2 E5:2 R:2',
'glass2':'E5:2 A5:1 C6:1 B5:2 A5:1 G5:1 E5:2 R:2|D5:2 F5:1 A5:1 C6:2 A5:2 F5:2 R:2|D5:2 Bb5:1 A5:1 F5:2 D5:2 Bb4:2 R:2|B4:2 E5:1 G#5:1 B5:2 A5:2 E5:2 R:2',
'rails':'A5:1 E5:1 C5:1 E5:1 A5:1 C6:1 B5:1 A5:1 G5:1 E5:1 D5:2|A5:1 F5:1 C5:1 F5:1 A5:1 C6:1 D6:1 C6:1 A5:1 G5:1 F5:2|G5:1 E5:1 C5:1 E5:1 G5:1 C6:1 E6:1 D6:1 C6:1 B5:1 G5:2|B5:1 G5:1 D5:1 G5:1 B5:1 D6:1 F6:1 E6:1 D6:1 B5:1 G5:2',
'pass':'E6:1 C6:1 A5:1 C6:1 E6:1 G6:1 F6:1 E6:1 C6:1 A5:1 E5:2|F6:1 C6:1 A5:1 F5:1 A5:1 C6:1 F6:1 E6:1 C6:1 A5:1 F5:2|D6:1 A5:1 F5:1 D5:1 F5:1 A5:1 D6:1 C6:1 A5:1 F5:1 D5:2|B5:1 G#5:1 E5:1 G#5:1 B5:1 E6:1 D6:1 B5:1 G#5:1 E5:1 R:2',
'after':'R:4 E5:2 A5:2 R:4|R:2 C5:2 F5:2 E5:2 R:4|D5:2 G5:2 R:2 B5:2 R:4|G#5:2 E5:2 R:8',
'shoes':'A4:2 C5:1 E5:1 G5:2 E5:1 C5:1 B4:2 A4:2|A4:2 D5:1 F5:1 A5:2 F5:1 D5:1 C5:2 A4:2|B4:2 D5:1 G5:1 B5:2 A5:1 G5:1 D5:2 B4:2|G#4:2 B4:1 E5:1 G#5:2 E5:1 B4:1 G#4:2 R:2',
'return':'E5:1 A5:2 C6:1 B5:2 A5:1 G5:1 E5:1 C5:1 A4:2|E5:1 F5:2 A5:1 G5:2 F5:1 E5:1 C5:1 A4:1 F4:2|D5:1 G5:2 B5:1 A5:2 G5:1 F5:1 D5:1 B4:1 G4:2|B4:1 E5:2 G#5:1 F5:2 E5:1 D5:1 B4:2 R:2',
'end':'A5:2 G5:1 E5:1 C5:2 B4:1 A4:1 E4:2 A4:2|F5:2 E5:1 C5:1 A4:2 G4:1 F4:1 C4:2 F4:2|B4:1 E5:1 G#5:2 F5:1 E5:1 D5:2 B4:2 R:2|A4:2 B4:1 C5:1 E5:2 B4:2 A4:2 R:2'
}
BLOCKS=[
('Rain_already_running',116,6,'rain','Am F C G Am Dm E7 Am','a b'),
('Ticket_in_pocket',110,6,'walk','Am F C G Am Dm E7 Am','a b'),
('Window_reflections',94,6,'windlead','Am F G E7 Am Dm Bb E7','glass glass2'),
('Light_on_the_rails',124,6,'rails','Am F C G Am F C G','rails rails'),
('Train_does_not_stop',136,6,'passing','Am F Dm E7 Am F Dm E7','pass pass'),
('Air_after_carriages',88,6,'after','Am F G E7 Am F G E7','after after'),
('Wet_shoes',110,6,'walk','Am Dm G E7 Am F G E7','shoes return'),
('Wait_for_the_next',108,6,'end','Am F G E7 Am F E7 Am9','return end')]
REV1={25:('Am/E','C6:1 A5:1 E5:1 A5:1 C6:1 E6:1 D6:1 C6:1 B5:1 A5:1 E5:2'),26:('Fmaj7','A5:1 E5:1 C5:1 F5:1 A5:1 C6:1 E6:1 D6:1 C6:1 A5:1 F5:2'),27:('C','G5:1 C6:1 E6:1 D6:1 C6:1 B5:1 G5:1 E5:1 D5:1 C5:1 E5:2'),28:('G6','B5:1 E6:1 D6:1 B5:1 A5:1 G5:1 E5:1 D5:1 B4:1 D5:1 G5:2'),29:('Am','C6:2 E6:1 G6:1 E6:2 C6:1 B5:1 A5:1 G5:1 E5:2'),30:('F','A5:2 C6:1 F6:1 E6:2 C6:1 A5:1 G5:1 F5:1 C5:2'),31:('Dm','F5:1 A5:1 D6:2 C6:1 A5:1 F5:1 E5:1 D5:2 R:2'),32:('E7','G#5:1 B5:1 E6:2 D6:1 B5:1 G#5:2 E5:2 R:2')}
REV2={41:('Am','R:6 E5:2 A5:2 R:2'),42:('Fmaj7','R:8 E5:2 F5:2'),43:('G6','R:4 B4:2 E5:2 G5:2 R:2'),44:('E7','R:2 G#4:2 B4:2 E5:2 R:4'),45:('Am/E','E4:2 A4:2 C5:2 R:6'),46:('F','C5:1 A4:1 F4:2 R:2 C5:2 R:4'),47:('Dm','A4:2 D5:2 F5:2 E5:2 D5:2 R:2'),48:('E7','B4:1 E5:1 G#5:2 E5:2 R:6')}
def build(level):
 w=Writer()
 for n,section,bpm,beats,style,h,line in material(level):
  ch=H[h];w.bar(section,bpm,beats,h,ch);v={'rain':80,'walk':72,'windlead':64,'rails':88,'passing':101,'after':49,'end':76}[style]
  notes,total=decode(line)
  if style=='windlead':
   assert total==6
   for q,t in zip([notes[0][0],notes[len(notes)//2][0],notes[-1][0]],[.25,2.25,4.25]):w.add(60+q%12,t,1.3,68,inst='clarinet',voice='reflection_phrase')
   for t,p in [(0,ch[0]),(1.5,ch[1]+12),(3,ch[0]+12),(4.5,ch[2]+12)]:w.add(p,t,.52,51,hand='left' if t in (0,3) else 'right',voice='glass_drops')
  else:w.line(line,v)
  if style in ('rain','rails','passing','walk','end'):
   times=[0,1.5,3,4.5] if style!='walk' else [0,2.5,4.5]
   if level>=1 and 25<=n<=32:times=[.5,2,3.5,5]
   for j,t in enumerate(times):w.add(ch[0] if j%2==0 else ch[1],t,.4,v-24,voice='four_rain_pulses',hand='left')
   if style in ('rain','end') and n%4==0:w.add(60+ch[2]%12,4.25,1.2,64,inst='clarinet',voice='unasked_question')
  if style=='after':
   if n%4==1:w.add(ch[0],0,1.0,40,voice='platform_weight',hand='left')
   if level>=2 and n in (43,47):w.add(60+ch[2]%12,4.5,.95,50,inst='clarinet',voice='next_train_question')
  w.release(34 if style in ('windlead','after') else 0,1.2)
 return w.result(level)
