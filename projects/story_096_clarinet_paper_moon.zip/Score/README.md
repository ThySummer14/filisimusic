# 096 纸月亮下的单簧管 / Clarinet Under the Paper Moon

全新原创虚构故事及钢琴＋Iowa单簧管的完整原创符号曲。人物、对话与事件均为虚构；并未声称是作者的亲历。A小调，C/F大调暖段，4/4，72小节，288四分音符拍；含4秒尾响预算总长约3:32.40。

本目录另行创作，旧096_paper_moon小提琴草稿保持原样。没有重试小提琴素材，没有读取旧小提琴旋律来移调，也没有复用090或095的主题。只参考其数据字段与独立核验方法。

最终采用score.json，与score_v2.json逐字节相同。hash_manifest.json记录所有正式文件SHA-256；最终谱SHA同时写入independent_verification.json。

- story_zh.txt：独立中文小说，故事本身没有技术或虚构说明尾注
- music_notes_zh.md：音乐、曲式、真实乐器层与演奏意图
- revision_notes.md：两轮改写的音乐理由和范围
- score_v0.json、score_v1.json、score_v2.json：三个完整可读版本
- exact_diff_*.json及.patch：完整下一版重建材料
- generate_score.py：仅Python标准库的确定性建谱器
- verify_symbolic.py：独立落盘检查、故意坏例拒绝、真实新进程再生成
- audit_v*.json：全谱移手、持键、手指、呼吸与乐器层审计
- independent_verification.json、reproducibility_check.json：审计和逐文件重建摘要
- hash_manifest.json：本目录正式文件的字节数与SHA，清单本身除外

重建：python generate_score.py。验证：python verify_symbolic.py。后者会刷新审计与完整哈希清单。所有节拍和BPM以四分音符为单位。

单簧管只使用MIDI60–71真实pp/mf/ff音层；门长0.35–1.45秒内，音间真实释放至少0.08秒，每不超过4小节有至少0.35秒呼吸。ordinary trigger，无额外攻击补偿、采样连奏、循环持续或音频拉伸。钢琴按完整握形及真实持键最大移动计算移手，不豁免旋律，也不把踏板当松键；无同键重叠、手部交叉、同指冲突，持键跨度不超过12半音。

交付范围仅为符号、故事与可重建证据，没有音频、DSP、样本下载、安装、试听或成品声音验收。后续集成应另行核对实际样本起音/尾音和自然声部平衡。
