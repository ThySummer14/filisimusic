#!/usr/bin/env python3
"""Original work 72. Deterministic, standard-library-only score construction.
No audio, sample loading, renderer, network, installation or subprocess is used.
All quarter-beat onsets for flute mean intended pitched arrivals, NOT triggers.
"""
import csv
import hashlib
import json
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parent
HARMONIES = {
    'C': [60,64,67], 'C6': [60,64,67,69], 'Am': [60,64,69],
    'Am7': [60,64,67,69], 'F': [60,65,69], 'Dm': [62,65,69],
    'G': [62,67,71], 'G7': [62,65,67,71], 'E': [64,68,71],
    'E7': [62,64,68,71], 'Bb': [62,65,70], 'Gm': [62,67,70],
    'A7': [61,64,67,69], 'C7': [60,64,67,70],
}
# (relative onset, nominal voiced/trigger-to-off duration), in quarter beats.
# The 0.40-beat shortest inter-note gap is >209 ms at the fastest tempo.
RHYTHMS = {
    'q3': [(0,.60),(1,.60),(2,.60)],
    'turn': [(0,.34),(.75,.34),(1.5,.94)],
    'q4': [(0,.34),(.75,.34),(1.5,.34),(2.25,.34)],
    'two': [(0,1.0),(1.5,.60)],
    'end2': [(0,.34),(.75,.39)],
    'end1': [(0,1.10)],
    'answer': [(0,.60),(1.5,.60)],
    'final': [(0,1.60)],
}

def bar(harmony, pitches, rhythm='q3'):
    assert len(pitches) == len(RHYTHMS[rhythm])
    return {'harmony':harmony, 'notes':[(o,p,d) for p,(o,d) in zip(pitches,RHYTHMS[rhythm])], 'rhythm':rhythm}

def phrase(tag, lead, layer, purpose, *bars):
    assert len(bars)==4
    return {'tag':tag,'lead':lead,'layer':layer,'purpose':purpose,'music':list(bars)}

def transpose_phrase(p, semitones, lead=None, tag=None, layer=None, purpose=None):
    q=json.loads(json.dumps(p))
    for b in q['music']:
        b['notes']=[(o,n+semitones,d) for o,n,d in b['notes']]
    if lead: q['lead']=lead
    if tag: q['tag']=tag
    if layer: q['layer']=layer
    if purpose: q['purpose']=purpose
    return q

A=[
 phrase('A_keys','flute','mf','The keeper makes three distinct key strikes: an arpeggio, a turn, a clipped answer.',
   bar('C',[72,76,79]), bar('C6',[81,79,76],'turn'), bar('G7',[79,77,74]), bar('C',[76,72],'end2')),
 phrase('A_question','flute','mf','An eight-bar antecedent opens the weather cupboard and stops on its dominant.',
   bar('Am7',[76,79,81]), bar('C',[79,76,72]), bar('Dm',[74,77,81]), bar('G',[79],'end1')),
 phrase('A_reply','flute','mf','A higher exchange opens the second half without copying the entire first phrase.',
   bar('C',[79,76,79]), bar('F',[81,77,81]), bar('G',[83,79,74]), bar('C',[76,72],'end2')),
 phrase('A_seal','flute','mf','A plain tonic close: this is how the old keeper usually locks the cabinet.',
   bar('C',[76,77,79]), bar('F',[81,79,76],'turn'), bar('G7',[74,77,74]), bar('C',[72],'end1')),
]

# V0 is a complete, viable first conception: the minor episode has a simple
# stepwise line and C is a regular F-major conversation. Later passes really
# replace their melodic/harmonic content, rather than only renaming sections.
B0=[
 phrase('B0_unlock','clarinet','pp','The apprentice tries the unfamiliar key.',
   bar('Am',[64,69,64]),bar('Am',[69,67,64]),bar('Dm',[65,62,65]),bar('E',[64],'end1')),
 phrase('B0_leaves','clarinet','pp','A descending breeze quietly changes the square.',
   bar('F',[69,67,65]),bar('Dm',[65,64,62]),bar('E7',[64,68,71]),bar('Am',[69],'end1')),
 phrase('B0_explain','flute','pp','The old keeper tests the draft herself.',
   bar('Am',[76,81,76]),bar('F',[81,79,77]),bar('Dm',[77,74,77]),bar('E',[76],'end1')),
 phrase('B0_return','clarinet','mf','The student finds the familiar dominant keyhole.',
   bar('Am',[69,67,64]),bar('F',[65,69,65]),bar('G7',[62,65,71]),bar('G',[67],'end1')),
]
B1=[
 phrase('B_wrong_season','clarinet','pp','Four evenly spaced key clicks reveal the E-major side of A minor: the autumn key.',
   bar('E7',[64,64,68,71],'q4'),bar('Am',[69,64],'two'),bar('Dm',[65,62,65]),bar('E',[64],'end1')),
 phrase('B_leaf_rain','clarinet','pp','Falling paper leaves interrupt the official outdoor summer tea.',
   bar('F',[65,64,65]),bar('Dm',[62,64,65]),bar('E7',[68,71,68]),bar('Am',[69],'end1')),
 phrase('B_shared_mistake','flute','pp','The keeper repeats the mistaken four-click gesture rather than scolding.',
   bar('E7',[76,76,80,83],'q4'),bar('Am',[81,79,76],'turn'),bar('Dm',[77,74,77]),bar('E',[76],'end1')),
 phrase('B_choose_again','clarinet','mf','An active dominant pivot restores the main door without erasing the incident.',
   bar('Am',[69,71,69]),bar('F',[67,65,64]),bar('G',[62,67,71]),bar('G',[67],'end1')),
]

C0=[
 phrase('C0_baskets','clarinet','mf','Breezes are sorted into baskets in an orderly F-major dance.',
   bar('F',[65,69,65]),bar('Bb',[70,69,65]),bar('C7',[64,67,70]),bar('F',[65],'end1')),
 phrase('C0_answer','flute','mf','The keeper answers the sorting pattern.',
   bar('F',[77,81,77]),bar('Bb',[82,81,77]),bar('C7',[76,79,82]),bar('F',[77],'end1')),
 phrase('C0_label','clarinet','pp','Quietly checking the weather labels.',
   bar('Dm',[62,65,69]),bar('F',[69,65,60]),bar('C',[64,67,64]),bar('F',[65],'end1')),
 phrase('C0_tie','flute','mf','Tying the weather bags in a calm sequence.',
   bar('F',[77,81,79]),bar('Dm',[77,74,77]),bar('C',[76,79,76]),bar('F',[77],'end1')),
 phrase('C0_door','clarinet','mf','Dominant transition to the cupboard.',
   bar('C',[64,67,64]),bar('G7',[65,64,62]),bar('G',[62,67,71]),bar('G',[67],'end1')),
]
C1=[
 phrase('C_basket_game','clarinet','mf','A new four-click sorting dance turns the mistake into a usable skill.',
   bar('F',[65,69,67,65],'q4'),bar('Bb',[70,69,67],'turn'),bar('C7',[64,67,70]),bar('F',[69,65],'end2')),
 phrase('C_keeper_learns','flute','mf','The keeper accepts the apprentice\'s new sorting gesture verbatim.',
   bar('F',[77,81,79,77],'q4'),bar('Bb',[82,81,79],'turn'),bar('C7',[76,79,82]),bar('F',[81,77],'end2')),
 phrase('C_labels_reversed','clarinet','pp','A mislabelled bag briefly leads through G minor to A7; nobody panics.',
   bar('Dm',[62,65,69]),bar('Bb',[65,62,65]),bar('Gm',[67,70,67]),bar('A7',[69],'end1')),
 phrase('C_test_the_knot','flute','mf','C-sharp tests the knot twice; the result is an answered question, not a crisis.',
   bar('Dm',[74,77,81]),bar('A7',[76,73,76]),bar('Dm',[77,74,77]),bar('A7',[76],'end1')),
 phrase('C_open_correct_door','clarinet','mf','A dominant transition yields to an unaccompanied C-E-G preview: the apprentice rehearses the opening before inheriting it.',
   bar('G',[67,69,67]),bar('G7',[65,64,62]),bar('C',[60,64,67]),bar('G',[67],'end1')),
]

CODA0=[
 phrase('K0_recount','flute','pp','A quiet remembrance of the side episode.',
   bar('Am',[76,81,76]),bar('F',[81,79,77]),bar('Dm',[77,74,77]),bar('G',[79],'end1')),
 phrase('K0_agree','clarinet','pp','A conventional subdominant answer.',
   bar('F',[65,69,65]),bar('C',[67,64,60]),bar('G7',[62,65,71]),bar('C',[60],'end1')),
 phrase('K0_sign','flute','mf','The keeper gives a last formal tonic signature.',
   bar('C',[72,76,79]),bar('C6',[81,79,76],'turn'),bar('G7',[79,77,74]),bar('C',[72],'final')),
]
CODA2=[
 phrase('K_remember_wrong_key','flute','pp','The mistaken repeated E returns with G-natural: it now belongs inside the shared weather.',
   bar('C',[76,76,79,83],'q4'),bar('Am',[81,79,76],'turn'),bar('Dm',[77,74,77]),bar('G',[79],'end1')),
 phrase('K_spoon_of_autumn','clarinet','pp','The sorting dance returns in F: one little spoon of autumn is intentionally permitted.',
   bar('F',[65,69,67,65],'q4'),bar('Bb',[70,69,67],'turn'),bar('C7',[64,67,70]),bar('F',[69,65],'end2')),
 phrase('K_new_signature','clarinet','mf','The successor signs the opening figure; the final cadence is newly led from below.',
   bar('C',[60,64,67]),bar('C6',[69,67,64],'turn'),bar('G7',[62,65,67]),bar('C',[60],'final')),
]

SECTIONS=[('A',1,16,100),('B',17,32,96),('A_return',33,48,100),
          ('C',49,68,108),('A_changed_return',69,84,100),('Coda',85,96,93)]
CONSONANT={0,3,4,7,8,9}

def section_for(b):
    return next((name,bpm) for name,start,end,bpm in SECTIONS if start<=b<=end)

def serialize(obj):
    return json.dumps(obj,ensure_ascii=False,sort_keys=True,indent=2)+'\n'

def time_map(bars, beat):
    elapsed=0.0
    for b in bars:
        used=max(0,min(b['beats'],beat-b['start']))
        elapsed+=used*60.0/b['bpm']
        if beat<=b['start']+b['beats']: break
    return elapsed

def assemble_phrases(version):
    returns=[transpose_phrase(p,0,tag='AR_'+p['tag']) for p in A]
    returns[2]=transpose_phrase(A[2],-12,lead='clarinet',tag='AR_exchange',
       purpose='The apprentice answers the keeper with the established reply, an early rehearsal of inheritance.')
    returns[3]['layer']='pp'
    final=[transpose_phrase(p,0,tag='AF_'+p['tag']) for p in A]
    if version>=2:
        final=[transpose_phrase(A[0],-12,lead='clarinet',tag='AF_inherit_keys'),
               transpose_phrase(A[1],-12,lead='clarinet',tag='AF_inherit_question'),
               phrase('AF_new_permission','flute','pp','The former keeper offers a new, open-ended continuation rather than taking back the keys.',
                  bar('Am7',[76,79,81]),bar('Dm',[81,77,74]),bar('G7',[79,83,81]),bar('G',[79],'end1')),
               phrase('AF_successor_answers','clarinet','mf','The successor supplies the tonic answer in her own register.',
                  bar('C',[64,65,67]),bar('Am',[69,67,64],'turn'),bar('G7',[65,64,62]),bar('C',[60],'end1'))]
    return A+(B1 if version>=1 else B0)+returns+(C1 if version>=1 else C0)+final+(CODA2 if version>=2 else CODA0)

def make_score(version):
    phrases=assemble_phrases(version)
    bars=[]
    for ix,p in enumerate(phrases):
        for local,b in enumerate(p['music']):
            n=ix*4+local+1
            section,bpm=section_for(n)
            bars.append({'bar':n,'start':(n-1)*3,'beats':3,'bpm':bpm,'section':section,
                'meter_numerator':3,'meter_denominator':4,'harmony_name':b['harmony'],
                'harmony':HARMONIES[b['harmony']], 'lead_instrument':p['lead'],
                'role_plan':p['lead']+' leads; '+('clarinet' if p['lead']=='flute' else 'flute')+
                    ' gives sparse pp consonant chord tones or rests; '+p['purpose']})
    events=[]
    for ix,p in enumerate(phrases):
        lead=p['lead']; support='clarinet' if lead=='flute' else 'flute'
        layer=p['layer']
        last_support=65 if support=='clarinet' else 77
        for local,b in enumerate(p['music']):
            n=ix*4+local+1; beat=(n-1)*3; bpm=bars[n-1]['bpm']
            for j,(o,pitch,d) in enumerate(b['notes']):
                base=75 if layer=='mf' else 49
                vel=base+([3,-2,0,-3][j%4]) + (1 if local==0 else -1 if local==3 else 0)
                events.append({'bar':n,'onset':round(beat+o,6),'duration':d,'pitch':pitch,
                  'velocity':vel,'voice':lead,'instrument':lead,'role':'lead','layer':layer,
                  'phrase_id':f'P{ix+1:02d}_{lead}','phrase_label':p['tag']})
            # Upper support is especially sparse; it is never a second tune.
            # The lower instrument supplies two short harmonic anchors in a
            # flowing bar, but only one in the breathing bar.
            support_indices=[] if version>=1 and n in (67,68) else [0]
            if support=='clarinet' and local!=3 and len(b['notes'])>=3:
                support_indices.append(2)
            for j in support_indices:
                o,lead_pitch,lead_d=b['notes'][j]
                low,high=(60,71) if support=='clarinet' else (72,83)
                chord_pcs={v%12 for v in HARMONIES[b['harmony']]}
                possible=[k for k in range(low,high+1) if k%12 in chord_pcs and
                    abs(k-lead_pitch)%12 in CONSONANT]
                if not possible:
                    continue # A real rest is preferable to an unrelated note.
                # Stable support, mild preference for the stored harmony anchor, no independent contour.
                root=HARMONIES[b['harmony']][0]%12
                pitch=min(possible,key=lambda k:(abs(k-last_support)+(.8 if k%12!=root else 0),k))
                last_support=pitch
                # Clearer final cadence in v2: quiet unison-class tonic above C4.
                if version>=2 and n==96: pitch=72
                dur=min(lead_d,.46 if support=='clarinet' else .36)
                if n==96: dur=min(lead_d,1.0)
                events.append({'bar':n,'onset':round(beat+o,6),'duration':dur,'pitch':pitch,
                  'velocity':31+(2 if local==0 else 0)+(1 if j==0 else -1),
                  'voice':support,'instrument':support,'role':'support','layer':'pp',
                  'phrase_id':f'P{ix+1:02d}_{support}','phrase_label':p['tag']})
    events.sort(key=lambda e:(e['onset'],e['instrument'],e['pitch']))
    for i,e in enumerate(events):
        e['event_id']=f'w72-v{version}-{i+1:04d}'
        e['target_on_beats']=e['onset']
        e['target_off_beats']=round(e['onset']+e['duration'],6)
        e['target_on_seconds']=round(time_map(bars,e['onset']),9)
        e['target_off_seconds']=round(time_map(bars,e['onset']+e['duration']),9)
        e['onset_reference']='pitched_arrival' if e['instrument']=='flute' else 'ordinary_trigger'
    phrase_plan=[]
    for ix,p in enumerate(phrases):
        for instrument in ('flute','clarinet'):
            ident=f'P{ix+1:02d}_{instrument}'
            ee=[e for e in events if e['phrase_id']==ident]
            assert ee
            phrase_plan.append({'phrase_id':ident,'phrase_label':p['tag'],
                'first_bar':ix*4+1,'last_bar':ix*4+4,'instrument':instrument,
                'role':'lead' if instrument==p['lead'] else 'support',
                'layer':p['layer'] if instrument==p['lead'] else 'pp',
                'target_on_beats':min(e['onset'] for e in ee),
                'target_off_beats':max(e['target_off_beats'] for e in ee),
                'target_on_seconds':min(e['target_on_seconds'] for e in ee),
                'target_off_seconds':max(e['target_off_seconds'] for e in ee),
                'breath_to_next_phrase_seconds':None})
    for instrument in ('flute','clarinet'):
        pp=[p for p in phrase_plan if p['instrument']==instrument]
        for p,q in zip(pp,pp[1:]):
            p['breath_to_next_phrase_seconds']=round(q['target_on_seconds']-p['target_off_seconds'],9)
    return {'id':72,'title':'The Wind Changed Hands','title_zh':'风换了主人',
      'version':f'v{version}','bars':bars,'events':events,'pedals':[],
      'total_beats':288,'tail_seconds':4,'phrases':phrase_plan,
      'instrumentation':['flute','clarinet'],
      'performance_contract':{
       'flute_onset':'Target pitched arrival. Apply the existing pitch/layer-specific 50–209 ms advance in the parent rendering pipeline, once only.',
       'clarinet_onset':'Ordinary MIDI trigger; no flute compensation.',
       'flute_compensation_applied_here':False,
       'minimum_render_pre_roll_seconds':0.209,
       'recommended_render_pre_roll_seconds':0.5,
       'first_flute_trigger':'Its target arrival is zero. Apply the global pre-roll to both instruments before scheduling the negative compensated flute trigger; do not clamp to zero.',
       'note_off':'Target note-off in the written score. Parent must respect its existing sample-duration and release handling.',
       'layers':'pp=21–55, mf=56–95. One sampled layer per instrument phrase; no ff.',
       'sustain':'No pedals, loops or true legato. Each voice is monophonic.',
       'breaths':'Four-bar phrases. At least 0.85 s flute before compensation; 0.60 s clarinet.',
       'audio_status':'No audio was generated or listened to for this draft.'}}

def note_sig(e):
    return (e['onset'],e['duration'],e['pitch'],e['velocity'],e['instrument'],e['role'])

def melody_sig(score,first,last,normalized=False):
    result=[]
    for e in score['events']:
        if first<=e['bar']<=last and e['role']=='lead':
            p=e['pitch']+ (12 if normalized and e['instrument']=='clarinet' else 0)
            result.append((round(e['onset']-(first-1)*3,6),e['duration'],p))
    return sorted(result)

def audit(score):
    bars=score['bars']; events=score['events']; errors=[]
    def check(ok,msg):
        if not ok: errors.append(msg)
    check(len(bars)==96,'Expected 96 complete bars.')
    check([b['bar'] for b in bars]==list(range(1,97)),'Bar ordering.')
    check(all(b['start']==(b['bar']-1)*3 for b in bars),'Continuous beat grid.')
    check(score['total_beats']==288,'Total quarter-beat count.')
    check(score['pedals']==[],'No pedal.')
    check(score['performance_contract']['recommended_render_pre_roll_seconds']>=.209,'Pre-roll must accommodate opening flute advance.')
    check({e['instrument'] for e in events}=={'flute','clarinet'},'Instrument-only contract.')
    instrument_report={}
    for instrument,lo,hi,max_gate,min_breath in [('flute',72,83,1.35,.85),('clarinet',60,71,1.50,.60)]:
        ee=[e for e in events if e['instrument']==instrument]
        gates=[e['target_off_seconds']-e['target_on_seconds'] for e in ee]
        gaps=[b['target_on_seconds']-a['target_off_seconds'] for a,b in zip(ee,ee[1:])]
        breaths=[p['breath_to_next_phrase_seconds'] for p in score['phrases'] if p['instrument']==instrument and p['breath_to_next_phrase_seconds'] is not None]
        check(all(lo<=e['pitch']<=hi for e in ee),instrument+' range')
        check(max(gates)<=max_gate+1e-8,instrument+' nominal gate')
        check(min(gaps)>=-1e-8,instrument+' monophony')
        check(min(breaths)>=min_breath-1e-8,instrument+' phrase breath')
        if instrument=='flute':
            check(min(gaps)>=.209-1e-8,'Flute 209-ms worst-case pretrigger clearance')
            check(max(gates)+.209<=1.35+1e-8,'Flute gate including conservative advance exceeds 1.35 s')
        layers=Counter(e['layer'] for e in ee)
        for e in ee:
            check(e['voice']==instrument,'Voice must equal instrument')
            v=e['velocity']; layer=e['layer']
            check((21<=v<=55 if layer=='pp' else 56<=v<=95 if layer=='mf' else False),'Velocity/layer')
            check(e['onset']>=bars[e['bar']-1]['start'],'Event starts outside stated bar')
            check(e['onset']+e['duration']<=bars[e['bar']-1]['start']+3+1e-9,'Cross-bar gate')
            check(e['duration']>0,'Nonpositive gate')
        for p in score['phrases']:
            if p['instrument']==instrument:
                q=[e for e in ee if e['phrase_id']==p['phrase_id']]
                check(len({e['layer'] for e in q})==1,'Mixed sample layers within phrase')
        instrument_report[instrument]={'event_count':len(ee),'pitch_min':min(e['pitch'] for e in ee),'pitch_max':max(e['pitch'] for e in ee),
             'velocity_min':min(e['velocity'] for e in ee),'velocity_max':max(e['velocity'] for e in ee),
             'max_nominal_gate_seconds':round(max(gates),9),'min_nominal_inter_note_gap_seconds':round(min(gaps),9),
             'min_phrase_breath_seconds':round(min(breaths),9),'layer_event_counts':dict(layers)}
        if instrument=='flute':
            instrument_report[instrument]['max_gate_plus_209ms_seconds']=round(max(gates)+.209,9)
            instrument_report[instrument]['min_phrase_breath_after_209ms_advance_seconds']=round(min(breaths)-.209,9)
    # Every support event lives inside exactly one foreground note and is consonant.
    dissonances=[]; orphan_support=[]
    leads=[e for e in events if e['role']=='lead']; support=[e for e in events if e['role']=='support']
    for s in support:
        overlaps=[e for e in leads if max(e['onset'],s['onset']) < min(e['target_off_beats'],s['target_off_beats'])-1e-8]
        if len(overlaps)!=1: orphan_support.append(s['event_id'])
        for e in overlaps:
            if abs(e['pitch']-s['pitch'])%12 not in CONSONANT:
                dissonances.append([s['event_id'],e['event_id']])
        check(s['layer']=='pp','Support must remain pp')
    check(not dissonances,'Overlapping contrapuntal dissonance')
    check(not orphan_support,'Support without one foreground note')
    for b in bars:
        ee=[e for e in leads if e['bar']==b['bar']]
        check({e['instrument'] for e in ee}=={b['lead_instrument']},'Two foreground voices in one bar')
    returns={
       'bars_1_8_vs_33_40_exact_melody':melody_sig(score,1,8)==melody_sig(score,33,40),
       'bars_1_8_vs_69_76_octave_normalized':melody_sig(score,1,8,True)==melody_sig(score,69,76,True)}
    check(all(returns.values()),'A recurrence not preserved')
    end_seconds=time_map(bars,score['total_beats'])
    check(170<=end_seconds+4<=190,'About-three-minute duration')
    lead_leaps={}
    for instrument in ('flute','clarinet'):
        leaps=[]
        for p in score['phrases']:
            q=[e for e in leads if e['phrase_id']==p['phrase_id'] and e['instrument']==instrument]
            leaps.extend(abs(b['pitch']-a['pitch']) for a,b in zip(q,q[1:]))
        lead_leaps[instrument]=max(leaps,default=0)
    return {'version':score['version'],'pass':not errors,'errors':errors,'bars':96,'quarter_beats':288,
      'event_count':len(events),'formal_duration_seconds':round(end_seconds,9),
      'first_flute_target_seconds':min(e['target_on_seconds'] for e in events if e['instrument']=='flute'),
      'first_flute_trigger_before_pre_roll_at_max_advance_seconds':-.209,
      'recommended_pre_roll_seconds':.5,
      'first_flute_trigger_after_recommended_pre_roll_at_max_advance_seconds':.291,
      'duration_including_tail_seconds':round(end_seconds+4,9),
      'last_event_off_seconds':max(e['target_off_seconds'] for e in events),
      'instrument_audits':instrument_report,'return_checks':returns,
      'support_count':len(support),'lead_count':len(leads),
      'overlap_dissonance_count':len(dissonances),'support_without_foreground_count':len(orphan_support),
      'max_intraphrase_lead_leap_semitones':lead_leaps,
      'limitations':['Written-score and deterministic structural checks only; no subjective listening assessment.',
       'This audit does not inspect or certify the parent\'s sample files, release envelopes, audio balance or final render.',
       'Consonance uses pitch-class intervals {0,3,4,7,8,9}; it does not replace musical judgment.']}

def diff(a,b):
    changed=[]; changed_lead=[]
    for n in range(1,97):
        aa=sorted(note_sig(e) for e in a['events'] if e['bar']==n)
        bb=sorted(note_sig(e) for e in b['events'] if e['bar']==n)
        if aa!=bb or a['bars'][n-1]['harmony_name']!=b['bars'][n-1]['harmony_name']:changed.append(n)
        aa=sorted(note_sig(e) for e in a['events'] if e['bar']==n and e['role']=='lead')
        bb=sorted(note_sig(e) for e in b['events'] if e['bar']==n and e['role']=='lead')
        if aa!=bb:changed_lead.append(n)
    return {'from':a['version'],'to':b['version'],'changed_bars':changed,'changed_bar_count':len(changed),
            'changed_lead_bars':changed_lead,'changed_lead_bar_count':len(changed_lead)}

NOTE_NAMES=['C','C#','D','Eb','E','F','F#','G','G#','A','Bb','B']
def note_name(p): return NOTE_NAMES[p%12]+str(p//12-1)

def write_outputs():
    scores=[make_score(v) for v in range(3)]
    audits=[audit(s) for s in scores]
    for s,a in zip(scores,audits):
        assert a['pass'],json.dumps(a['errors'])
        v=s['version']
        (ROOT/f'score_{v}.json').write_text(serialize(s),encoding='utf-8')
        (ROOT/f'audit_{v}.json').write_text(serialize(a),encoding='utf-8')
        (ROOT/f'phrase_plan_{v}.json').write_text(serialize(s['phrases']),encoding='utf-8')
    differences=[diff(scores[0],scores[1]),diff(scores[1],scores[2])]
    (ROOT/'revision_diff.json').write_text(serialize(differences),encoding='utf-8')
    (ROOT/'technical_audit.json').write_text(serialize({'versions':audits,'substantive_revisions':differences}),encoding='utf-8')
    s=scores[-1]
    with (ROOT/'score_v2_events.csv').open('w',encoding='utf-8',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(s['events'][0])); w.writeheader(); w.writerows(s['events'])
    lines=['72 风换了主人 / The Wind Changed Hands — v2 full written score',
       'All onsets are displayed relative to their bar; duration is in quarter beats. Chromatic tones use G#, C# and Bb.',
       'F = flute intended pitched arrival. C = clarinet ordinary trigger. No audio rendered.','']
    for b in s['bars']:
        lines.append(f"{b['bar']:02d} | {b['section']} | 3/4 q={b['bpm']} | {b['harmony_name']} | foreground {b['lead_instrument']}")
        for instrument in ('flute','clarinet'):
            ee=[e for e in s['events'] if e['bar']==b['bar'] and e['instrument']==instrument]
            lines.append('  '+instrument+': '+ ('; '.join(
              f"{note_name(e['pitch'])} @{e['onset']-b['start']:g}+{e['duration']:g} {e['layer']}/v{e['velocity']} {e['role']}" for e in ee) or 'rest'))
    (ROOT/'score_v2_full.txt').write_text('\n'.join(lines)+'\n',encoding='utf-8')
    # Rebuild independently and compare serialization: no RNG, timestamps, paths
    # or process state are allowed to alter generated score content.
    reproducible=all(serialize(make_score(v))==serialize(scores[v]) for v in range(3))
    assert reproducible
    hashes={f'score_v{v}.json':hashlib.sha256((ROOT/f'score_v{v}.json').read_bytes()).hexdigest() for v in range(3)}
    (ROOT/'reproducibility_check.json').write_text(serialize({'standard_library_only':True,
       'independent_rebuild_identical':reproducible,'score_sha256':hashes}),encoding='utf-8')
    (ROOT/'generated_sha256.json').write_text(serialize(hashes),encoding='utf-8')
    print(json.dumps({'status':'PASS','duration_with_tail':audits[-1]['duration_including_tail_seconds'],
       'events':audits[-1]['event_count'],'changes':differences,'reproducible':reproducible},ensure_ascii=False))

if __name__=='__main__': write_outputs()
