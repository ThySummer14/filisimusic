from copy import deepcopy

def pitch(s):
 return 12*(int(s[-1])+1)+{'C':0,'D':2,'E':4,'F':5,'G':7,'A':9,'B':11}[s[0]]+s[1:-1].count('#')-s[1:-1].count('b')
def decode(line):
 result=[];t=0
 for token in line.split():
  name,units=token.split(':');dur=float(units)/2
  if name!='R':result.append((pitch(name),t,dur))
  t+=dur
 return result,t
class Writer:
 def __init__(self):self.bars=[];self.events=[];self.pedals=[];self.start=0;self.n=0
 def bar(self,name,bpm,beats,h,ch):
  self.n+=1;self.beats=beats;self.bpm=bpm;self.ch=ch
  numerator,denominator=(int(beats*2),8) if beats in (2.5,3.5) else ((6,8) if METER=='6/8' else (int(beats),4))
  self.bars.append(dict(bar=self.n,start=self.start,beats=beats,bpm=bpm,meter_numerator=numerator,meter_denominator=denominator,section=name,harmony_name=h,harmony=ch))
 def add(self,p,t,d,v=72,inst='piano',voice='theme',hand='right',art='detached'):
  if d>0 and t<self.beats:
   self.events.append(dict(bar=self.n,onset=round(self.start+t,6),duration=round(min(d,self.beats-t),6),pitch=int(p),velocity=max(1,min(127,int(v))),instrument=inst,voice=voice,hand=hand if inst=='piano' else 'none',articulation=art))
 def line(self,line,v=80,hand='right',transpose=0):
  notes,total=decode(line);assert abs(total-self.beats)<1e-7,(self.n,total,self.beats,line)
  for p,t,d in notes:self.add(p+transpose,t,max(.11,d-.09),v+(3 if t==0 else 0),hand=hand)
  return notes
 def release(self,amount=0,length=.7):
  self.pedals.append(dict(bar=self.n,onset=self.start,controller=64,value=0,instrument='piano'))
  if amount:
   self.pedals.extend([dict(bar=self.n,onset=self.start+.05,controller=64,value=amount,instrument='piano'),dict(bar=self.n,onset=self.start+length,controller=64,value=0,instrument='piano')])
  self.start+=self.beats
 def result(self,level):
  self.pedals.append(dict(bar=self.n,onset=self.start-.01,controller=64,value=0,instrument='piano'))
  return dict(id=ID,title=TITLE,title_zh=TITLE_ZH,version=f'v{level}',bars=self.bars,events=self.events,pedals=self.pedals,total_beats=self.start,tail_seconds=5,instrument_map=INSTRUMENT_MAP)
def material(level):
 n=0
 for section,bpm,beats,texture,hs,phrase_names in BLOCKS:
  lines=[]
  for pn in phrase_names.split():lines+=P[pn].split('|')
  harmonies=hs.split();assert len(lines)==len(harmonies),(section,len(lines),len(harmonies))
  for h,line in zip(harmonies,lines):
   n+=1
   for lv,rev in [(1,REV1),(2,REV2)]:
    if level>=lv and n in rev:h,line=rev[n]
   yield n,section,bpm,beats,texture,h,line
ID=140;TITLE='A Wordless Curtain Call';TITLE_ZH='没有台词的谢幕';METER='4/4';INSTRUMENT_MAP={'piano':'piano','flute':'flute','cello':'arco'}
RENDERER_NOTES='Piano, flute C5–B5, short-bow cello D3–B3. Each foreground line separately authored. Bow gates .86 quarter beats, large breaks; phrase rests for flute. Do not substitute sustained string legato.'
H={'F':[41,57,60],'C':[36,52,55],'Dm':[38,53,57],'Bb':[46,53,62],'Gm':[43,58,62],'A7':[45,55,61],'C7':[36,52,58],'F/A':[45,53,60],'Eb':[39,55,58],'Bbmaj7':[46,53,57],'Csus':[36,53,55],'F6':[41,57,62]}
CEL={'F':[53,57],'C':[52,55],'Dm':[50,53],'Bb':[58,53],'Gm':[55,58],'A7':[57,55],'C7':[52,58],'F/A':[57,53],'Eb':[51,55],'Bbmaj7':[58,57],'Csus':[53,55],'F6':[53,57]}
# Piano's questioning leap contrasts with the flute's stepwise bow-shaped line.
Q=[
('F','C5:1 F5:1 A5:2 G5:1 F5:1 C5:2','F3:2 A3:1 C4:1 Bb3:2 A3:2','F5:2 G5:2 A5:2 R:2'),('C','E5:1 G5:1 C6:2 B5:1 G5:1 E5:2','C3:1 E3:1 G3:2 Bb3:1 G3:1 E3:2','G5:2 F5:2 E5:2 R:2'),('Dm','A5:1 F5:1 D5:2 E5:1 F5:1 A5:2','D3:2 F3:1 A3:1 C4:2 A3:2','A5:2 G5:2 F5:2 R:2'),('Bb','F5:1 Bb5:1 D6:2 C6:1 Bb5:1 F5:2','Bb2:1 D3:1 F3:2 A3:1 F3:1 D3:2','Bb5:2 A5:2 F5:2 R:2'),('Gm','D6:1 Bb5:1 G5:2 A5:1 Bb5:1 D6:2','G3:2 D3:1 Bb2:1 D3:1 F3:1 G3:2','G5:2 A5:2 Bb5:2 R:2'),('A7','C#6:1 A5:1 G5:1 E5:1 C#5:2 R:2','A2:1 C#3:1 E3:2 G3:1 A3:1 C#4:2','A5:2 G5:2 E5:2 R:2'),('Dm','F5:1 A5:1 D6:2 C6:1 A5:1 F5:2','D3:1 A3:1 F3:2 E3:1 D3:1 A2:2','F5:2 E5:2 D5:2 R:2'),('F/A','C6:2 A5:1 F5:1 E5:1 F5:1 A5:2','A2:2 C3:1 F3:1 A3:2 C4:2','A5:2 G5:2 F5:2 R:2'),('Bbmaj7','A5:1 F5:1 D5:2 F5:1 A5:1 Bb5:2','Bb2:1 D3:1 F3:2 A3:1 C4:1 D4:2','F5:2 A5:2 Bb5:2 R:2'),('Eb','G5:1 Bb5:1 Eb6:2 D6:1 Bb5:1 G5:2','Eb3:2 G3:1 Bb3:1 D4:2 Bb3:2','G5:2 F5:2 Eb5:2 R:2'),('Gm','Bb5:1 G5:1 D5:2 F5:1 G5:1 Bb5:2','G3:1 D3:1 Bb2:2 D3:1 G3:1 Bb3:2','D5:2 F5:2 G5:2 R:2'),('Csus','G5:1 C6:1 F6:2 E6:1 C6:1 G5:2','C3:1 F3:1 G3:2 Bb3:1 G3:1 F3:2','G5:2 F5:2 D5:2 R:2'),('C7','E6:1 C6:1 Bb5:2 G5:1 E5:1 C5:2','C3:2 E3:1 G3:1 Bb3:2 C4:2','G5:2 F5:2 E5:2 R:2'),('F','A5:2 F5:1 C5:1 A4:2 F4:2','F3:1 A3:1 C4:2 A3:1 F3:1 C3:2','F5:2 A5:2 C5:2 R:2'),('F6','C6:1 A5:1 F5:2 D5:1 C5:1 A4:2','F3:2 C3:1 A2:1 D3:1 C3:1 F3:2','A5:2 G5:2 F5:2 R:2')]
Q5=[
('F','F5:2 A5:1 C6:1 F6:2 E6:1 C6:1 A5:2','F3:1 C3:1 A2:2 C3:1 F3:1 A3:2 C4:2','F5:2 G5:2 A5:2 C5:2 R:2'),('Bb','D6:1 Bb5:1 F5:2 G5:1 A5:1 Bb5:2 D6:2','Bb2:2 D3:1 F3:1 A3:2 F3:1 D3:1 Bb2:2','Bb5:2 A5:2 F5:2 D5:2 R:2'),('C7','E6:1 C6:1 Bb5:2 G5:1 E5:1 C5:2 R:2','C3:1 E3:1 G3:2 Bb3:1 C4:1 E4:2 D4:2','G5:2 F5:2 E5:2 C5:2 R:2'),('Dm','F6:2 D6:1 A5:1 F5:1 E5:1 D5:2 A4:2','D3:2 F3:1 A3:1 C4:2 A3:1 F3:1 D3:2','A5:2 G5:2 F5:2 E5:2 R:2'),('Gm','D6:1 Bb5:1 G5:2 F5:1 G5:1 Bb5:2 D6:2','G3:1 D3:1 Bb2:2 D3:1 G3:1 Bb3:2 D4:2','G5:2 A5:2 Bb5:2 D5:2 R:2'),('Csus','F6:1 C6:1 G5:2 F5:1 D5:1 C5:2 R:2','C3:1 F3:1 G3:2 Bb3:1 C4:1 F4:2 R:2','G5:2 F5:2 D5:2 C5:2 R:2')]
Q7=[('Dm','D6:1 A5:1 F5:2 E5:1 D5:2','D3:2 A3:1 F3:1 E3:1 D3:2','F5:2 E5:2 D5:2 R:1'),('Bb','Bb5:1 F5:1 D5:2 C5:1 Bb4:2','Bb2:1 D3:1 F3:2 A3:1 Bb3:2','Bb5:2 A5:2 F5:2 R:1'),('Gm','G5:1 Bb5:1 D6:2 C6:1 Bb5:2','G3:2 Bb3:1 D4:1 C4:1 Bb3:2','G5:2 A5:2 Bb5:2 R:1'),('C7','E6:1 C6:1 Bb5:1 G5:1 E5:1 R:2','C3:1 E3:1 G3:2 Bb3:1 C4:2','G5:2 F5:2 E5:2 R:1'),('F','A5:1 F5:1 C5:1 A4:1 C5:1 F5:2','F3:2 C3:1 A2:1 C3:1 F3:2','A5:2 G5:2 F5:2 R:1')]
Q3=[('F','F5:1 A5:1 C6:2 A5:2','F3:2 A3:1 C4:1 F4:2','F5:2 A5:2 R:2'),('Bb','Bb5:1 D6:1 F6:2 D6:2','Bb2:1 D3:1 F3:2 Bb3:2','Bb5:2 F5:2 R:2'),('C7','E6:1 C6:1 Bb5:2 G5:2','C3:2 E3:1 G3:1 Bb3:2','G5:2 E5:2 R:2'),('F','A5:1 F5:1 C5:2 F5:2','F3:1 C3:1 A2:2 F2:2','A5:2 F5:2 R:2')]
S=[('Curtain_already_open',112,5,'full',[0,1,2,3,4,5,1,2,0]),('A_single_bow',98,4,'flute',[0,1,2,3,12,13]),('Everybody_crosses',116,4,'moving',[0,4,1,3,2,5,6,7,8,9,10,11,12,13,14]),('The_side_door',108,3.5,'bow',[0,1,2,3,4,0,2,1,3,4,3]),('Applause_keeps_time',100,3,'bright',[0,1,2,3,1,2,3]),('A_bow_takes_longer',118,5,'develop',[3,4,1,5,2,0,3,1,4,5,2,1,2,0]),('All_the_way_across',122,4,'cross',[6,7,8,9,10,4,2,5,11,12,0,13,14]),('Leave_the_light_on',102,4,'close',[0,3,7,8,10,11,12,14])]
REV1={}
for n,idx in zip(range(49,63),[0,1,4,3,5,2,1,3,4,0,5,2,4,0]):
 h,r,l,fl=Q5[idx];# same theatre gestures now join into one uninterrupted fourteen-bar bow
 if n in (51,55,60):
  h='Bbmaj7';r='A5:1 Bb5:1 D6:2 C6:1 Bb5:1 A5:2 F5:2';l='Bb2:1 D3:1 F3:2 A3:1 C4:1 D4:2 F3:2';fl='F5:2 A5:2 Bb5:2 A5:2 R:2'
 REV1[n]=(h,r,l,fl)
REV2={}
for n,idx in zip(range(63,76),[7,8,9,10,4,5,6,2,11,12,13,0,14]):
 h,r,l,fl=Q[idx];REV2[n]=(h,r,l,fl)
# One extra turning point replaces the old final gesture, not merely its loudness.
REV2[83]=('F6','F5:1 C5:1 A4:2 F4:2 R:2','F3:2 C3:1 A2:1 F2:2 R:2','A5:2 G5:2 F5:2 R:2')
def build(level):
 w=Writer();n=0
 for sec,bpm,beats,style,route in S:
  for idx in route:
   n+=1;pool=Q5 if beats==5 else Q7 if beats==3.5 else Q3 if beats==3 else Q;h,r,l,fl=pool[idx]
   for lv,rv in [(1,REV1),(2,REV2)]:
    if level>=lv and n in rv:h,r,l,fl=rv[n]
   ch=H[h];w.bar(sec,bpm,beats,h,ch);v={'full':95,'flute':61,'moving':84,'bow':73,'bright':94,'develop':97,'cross':103,'close':84}[style]
   if style=='flute':
    ns,total=decode(r)
    for p,t,d in ns[::2]:w.add(p,t,min(.4,d-.09),49,voice='gesture_shadow',hand='right')
   elif style=='bow':
    ns,total=decode(r)
    for p,t,d in ns[:2]:w.add(p,t,min(.38,d-.09),59,voice='side_door_glint',hand='right')
   else:w.line(r,v,'right')
   # Lower piano line keeps the steps across stage even when the foreground changes.
   w.line(l,v-17,'left')
   if style=='flute' or style in ('develop','cross','close') and n%3==1:
    ns,total=decode(fl);assert total==beats
    for p,t,d in ns:w.add(p,t*(4/3),d-.18,68 if style=='flute' else 77,inst='flute',voice='unspoken_line')
   if style=='bow' or style in ('full','moving','develop','cross') and n%3==2:
    for q,t in zip(CEL[h],[.2,1.8]):w.add(q,t,.86,67 if style=='bow' else 75,inst='cello',voice='bowing_gesture',art='short_bow')
   if level>=2 and 63<=n<=75 and n%3==0:
    # The foreground transfers to one short flute sentence, with cello absent in these bars.
    ns,total=decode(fl)
    for p,t,d in ns:w.add(p,t*(4/3),d-.18,75,inst='flute',voice='last_crossing_answer')
   w.release(28 if style=='flute' else 0,.7)
 return w.result(level)
