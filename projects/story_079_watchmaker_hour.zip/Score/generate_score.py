#!/usr/bin/env python3
"""Original Work 79. Deterministic stdlib score-only generator; never renders audio.
Absolute quarter-note beats, even in 6/8. No external files are read by this script.
"""
from pathlib import Path
import json, math, hashlib, collections, difflib
ROOT=Path(__file__).resolve().parent
TITLE='钟表匠遗失的一小时'
# Each voicing is [left-hand bass, left-hand fifth/compact partner], [right dyad].
H={
'Dm9':([38,45],[65,69],[38,41,45,52],'Dm(add9)'),
'Dm':([38,45],[65,69],[38,41,45],'Dm'),
'Fmaj7':([41,48],[64,69],[41,45,48,52],'Fmaj7'),
'F/A':([45,53],[65,72],[45,48,53],'F/A'),
'G6':([43,50],[64,71],[43,47,50,52],'G6'),
'Gm6':([43,50],[64,70],[43,46,50,52],'Gm6'),
'Bbmaj7':([46,53],[65,69],[46,50,53,57],'Bbmaj7'),
'C/E':([40,48],[67,72],[40,43,48],'C/E'),
'A7':([45,52],[61,67],[45,49,52,55],'A7'),
'A7sus4':([45,52],[62,67],[45,50,52,55],'A7sus4'),
'Em7':([40,47],[62,67],[40,43,47,50],'Em7'),
'Ehalf':([40,46],[62,67],[40,43,46,50],'Em7(b5)'),
'Ebmaj7':([39,46],[62,67],[39,43,46,50],'Ebmaj7'),
'Dm/F':([41,50],[65,69],[41,45,50],'Dm/F'),
'Dopen':([38,45],[62,69],[38,45,50],'D(no3)'),
'F':([41,48],[65,69],[41,45,48],'F'),
}
# Twenty individually specified four-bar sentences. Cello pitches are D3--B3 only.
P=[
('A','未递出的螺丝','first_question','pp','cello',['Dm9','Gm6','A7sus4','Dm'],[[50,57],[55,53],[52,57],[53,None]]),
('A','忙乱的辩词','watchmaker_answer','pp','piano',['Fmaj7','C/E','Bbmaj7','A7'],[[53,57],[52,55],[58,57],[52,None]]),
('A','夹层里的表盘','dial_discovered','pp','cello',['Dm9','Fmaj7','G6','Dm'],[[53,57],[59,57],[55,52],[50,None]]),
('A','门帘再次掀起','doorway_call','pp','piano',['Bbmaj7','F/A','Gm6','A7sus4'],[[58,57],[53,57],[55,52],[57,None]]),
('B','尚有两个名字','unbroken_hour','mf','cello',['Dm','Fmaj7','Gm6','A7sus4'],[[50,53],[57,55],[53,52],[57,None]]),
('B','送菜车第二次经过','returning_cart','mf','cello',['Dm','Fmaj7','Gm6','A7sus4'],[[50,53],[57,55],[53,52],[57,None]]),
('B','抢先问起铰链','anticipating_reply','mf','piano',['Bbmaj7','F/A','Gm6','A7'],[[58,57],[53,57],[55,52],[57,None]]),
('B','没有回答的新问题','new_question','pp','piano',['Dm9','G6','Bbmaj7','A7sus4'],[[50,52],[55,59],[58,53],[52,None]]),
('C','承认署名','admission','mf','cello',['Ehalf','Ebmaj7','A7','Ehalf'],[[52,58],[57,55],[52,53],[52,None]]),
('C','只伸手要螺丝','unchanged_hand','mf','piano',['Ebmaj7','Gm6','Ehalf','A7'],[[58,55],[55,52],[52,58],[57,None]]),
('C','不是新的谈话','cannot_answer','mf','cello',['G6','Gm6','Ehalf','A7'],[[50,59],[58,55],[52,55],[57,None]]),
('C','第四次不递出去','withheld_screw','pp','piano',['Bbmaj7','Ehalf','A7sus4','A7'],[[53,58],[52,55],[57,52],[52,None]]),
('D','拔下长针','remove_hand','pp','cello',['Dm9','Gm6','A7sus4','Dm'],[[50,57],[55,53],[52,57],[50,None]]),
('D','真正越过五点','crossing_five','pp','cello',['Fmaj7','C/E','G6','Dm9'],[[53,57],[52,55],[59,55],[52,None]]),
('D','更正说明','correction_written','mf','piano',['Dm9','Gm6','A7sus4','Dm'],[[50,57],[55,53],[52,57],[50,None]]),
('D','承担重印的费用','cost_of_correction','mf','cello',['Bbmaj7','F/A','Gm6','A7'],[[58,57],[53,57],[55,52],[57,None]]),
('E','十一天没有回信','eleven_days','pp','cello',['Gm6','A7sus4','Dm/F','Dm9'],[[52,55],[57,53],[52,50],[53,None]]),
('E','周四的普通预约','thursday_appointment','pp','piano',['Dm9','Fmaj7','C/E','A7sus4'],[[50,52],[53,57],[52,55],[57,None]]),
('E','一张照常开的单据','ordinary_invoice','pp','piano',['Bbmaj7','Gm6','Ehalf','A7'],[[58,53],[55,52],[52,58],[57,None]]),
('E','第一次新的下一句','unrepeated_next_line','pp','cello',['Dm9','Fmaj7','G6','Dopen'],[[50,52],[53,57],[55,52],[50,None]]),
]
# These are not copies from any other piece. Independent upper-register answers,
# followed in P15 by the opening cello gesture transferred to piano, +24 semitones.
PIANO={
2:[[77,76,72],[74,76],[77,74,70],[73]],
4:[[77,81],[79,77,76],[74,76],[74]],
7:[[77,81,82],[81,77],[79,76,74],[73]],
8:[[74,76],[79,83,79],[77,74],[76]],
10:[[82,79],[77,76,74],[76,79],[73]],
12:[[77],[76,74],[74],[73]],
15:[[74,81],[79,77],[76,81],[74]],
18:[[74,76],[77,81,79],[76,74],[74]],
19:[[77,74],[79,76],[76,74],[73]],
}
SECT_T={'A':'夹层与辩词','B':'不会结束的一小时','C':'旧答案无法回答新问题','D':'退还没有发生的下午','E':'按价结账的星期四'}
TEMPO={'A':78,'B':80,'C':90,'D':76,'E':70}
CELLO_RHY={
'paired':[(.25,.88),(1.75,.72)],
'lean':[(.5,.78),(2,.62)],
'early':[(0,.84),(1.5,.78)],
'broken':[(.75,.75),(2.25,.68)],
}
def dump(name,obj):
 (ROOT/name).write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
def times(bars,beat):
 t=0.
 for b in bars:
  if beat<=b['start']+b['beats']+1e-10:
   return t+max(0,beat-b['start'])*60/b['bpm']
  t+=b['beats']*60/b['bpm']
 return t+(beat-bars[-1]['start']-bars[-1]['beats'])*60/bars[-1]['bpm']
def build(v):
 events=[]; bars=[]; pedals=[]; phrase_meta=[]
 def add(bar,off,dur,pitch,velocity,instrument,voice,role,layer,pid,label,hand=None):
  e=dict(bar=bar,onset=round((bar-1)*3+off,6),duration=round(dur,6),pitch=pitch,velocity=velocity,instrument=instrument,voice=voice,role=role,layer=layer,phrase_id=pid,phrase_label=label,onset_reference='ordinary_trigger')
  if hand:e['hand']=hand
  if instrument=='cello':
   e.update(articulation='arco_separate_bow',sample_layer='Iowa_arco_'+layer,velocity_controls='recorded_layer_then_amplitude',timing_intent='Ordinary MIDI trigger. One separate bowed sample; no true legato, attack compensation, looping, or sustained bow claim.')
  else:e.update(articulation='sung_detached' if voice=='melody' else 'light_support',sample_layer='Moonlight',timing_intent='Ordinary piano MIDI onset; intended breathing and releases are written.')
  e['target_on_beats']=e['onset'];e['target_off_beats']=round(e['onset']+e['duration'],6)
  events.append(e)
 for pi,src in enumerate(P,1):
  section,labelzh,label,layer,plannedlead,hs,melody=src
  hs=list(hs); melody=[list(a) for a in melody]
  lead=plannedlead if v==2 else ('piano' if pi in (2,7,10,12,18,19) else 'cello')
  if v==0:
   if pi in (9,10,11,12):hs=['Dm','Bbmaj7','Gm6','A7']
   if pi==13:melody[-1]=[53,None]
   if pi==20:hs=['Dm9','Fmaj7','Gm6','F'];melody[-1]=[53,None]
  if v>=1:
   if pi==6:melody[-1]=[52,None]
   if pi==8:melody[-1]=[52,None]
  if v==2 and pi==6:melody[2]=[53,None]
  first=(pi-1)*4+1
  cp=f'P{pi:02}_cello'; pp=f'P{pi:02}_piano'
  for j,hk in enumerate(hs):
   bar=first+j; bass,rh,chord,hname=H[hk]; bpm=TEMPO[section]
   if v==0 and section=='C':bpm=82
   thislead=lead
   if v==2 and pi==8:thislead='piano' if j<2 else 'cello'
   if v==2 and pi==13 and j==3:thislead='piano'
   bars.append(dict(bar=bar,start=float((bar-1)*3),beats=3,bpm=bpm,meter='6/8',meter_numerator=6,meter_denominator=8,section=section,section_title_zh=SECT_T[section],harmony_name=hname,harmony=chord,lead_instrument=thislead,role_plan=('Cello foreground; compact quiet piano harmonic support.' if thislead=='cello' else 'Piano foreground call; cello sparse separated answer, never competing continuous line.')+' '+labelzh))
   # Accompaniment respects harmony, strict hand separation, and 12-semitone spans.
   # The pianist avoids a metronomic ticking figure: bass and chord placements vary.
   if v==2 and pi==12 and j==2:
    pass # physically refusing the screw: deliberately empty left/right support bar
   else:
    final=(pi==20 and j==3)
    boff=.5 if final else (0 if j%2==0 else .25)
    bdur=2.15 if final else (.9 if j in (0,2) else .72)
    add(bar,boff,bdur,bass[0],34 if layer=='pp' else 41,'piano','bass','support','soft',pp,label,'left')
    # No regular offbeat accompaniment in the last bar of each sentence.
    if j!=3 and not(v==2 and pi in (8,17,19) and j==2):
     add(bar,1.5,.7,bass[1],32 if layer=='pp' else 39,'piano','accompaniment','support','soft',pp,label,'left')
    if thislead=='cello':
     roff=.5 if final else (.75 if j%2==0 else .5)
     rdur=2.15 if final else (.7 if j!=3 else 1.05)
     # v2 drops one dyad tone in questioning and waiting sentences.
     tones=rh[:1] if v==2 and pi in (1,6,11,17) and j in (1,3) else rh
     for k,p in enumerate(tones):add(bar,roff+k*.035,rdur,p,32 if layer=='pp' else 40,'piano','upper_support','support','soft',pp,label,'right')
   # Melody blocks: lead changes are actual reorchestrations, not label changes.
   if thislead=='piano':
    notes=PIANO.get(pi, [[p+24 for p in a if p is not None] for a in melody])[j]
    if v==2 and pi==8 and j>=2:notes=[]
    if pi==13 and j==3:notes=[74,76] # a new reply after the changed cello arrival
    if len(notes)==3:shape=[(.35,.52),(1.10,.52),(1.90,.68)]
    elif len(notes)==2:shape=[(.35,.86),(1.70,.86)]
    else:shape=[(.5,1.15)]
    if pi==13 and j==3:shape=[(1.55,.48),(2.25,.5)]
    for k,(p,(on,dur)) in enumerate(zip(notes,shape)):
     vel=(56 if layer=='pp' else 68)+(2 if k==0 else -2)
     add(bar,on,dur,p,vel,'piano','melody','lead','foreground_'+layer,pp,label,'right')
   # Cello notes. Piano calls get two short cello responses per four-bar sentence.
   cello_lead=(thislead=='cello')
   if cello_lead:
    notes=melody[j]
    rk=('early' if section=='C' and v==0 else 'broken' if section=='C' else 'lean' if pi in (3,14,17) else 'paired')
    shape=CELLO_RHY[rk]
    if j==3:shape=[(.5,.9),(1.75,.65)];notes=notes[:1]
    if v==2 and pi==6 and j==2:shape=[(.25,.82)];notes=notes[:1]
    if v==2 and pi==17 and j==2:shape=[(.5,.8)];notes=notes[:1]
    role='lead'
   else:
    notes=[];shape=[];role='answer'
    if j==1:notes=[melody[j][0]];shape=[(2.15,.7)]
    if j==3:notes=[melody[j][0]];shape=[(.5,.88)]
    if pi in (2,7,10,18,19) and j==3:shape=[(1.5,.65)]
    if v==2 and pi==12 and j==3:notes=[52];shape=[(1.7,.7)]
    if v==2 and pi==15:
     if j==0:notes=[50];shape=[(0,.75)];role='support'
     elif j==2:notes=[52];shape=[(0,.75)];role='support'
     elif j==1:notes=[];shape=[]
    if v==2 and pi==13 and j==3:notes=[50];shape=[(.5,.85)]
   for k,(p,(on,dur)) in enumerate(zip(notes,shape)):
    if p is None:continue
    vel=(47 if layer=='pp' else 67)+(2 if k==0 else -3)+(1 if j==2 else 0)
    if role in ('support','answer'):vel-=3
    add(bar,on,dur,p,vel,'cello','cello_arco',role,layer,cp,label)
   # Per-bar pedal with early release. No cello pedals. 42 is partial; 76 full.
   # Short harmonic catch only; the coda has an explicit clean terminal release.
   if not(v==2 and pi==12 and j==2):
    final=pi==20 and j==3
    pon=(bar-1)*3+(.58 if final else .12)
    poff=(bar-1)*3+(2.8 if final else 2.60 if j!=3 else 2.3)
    val=76 if (section=='B' and j in (0,2)) else 42
    pedals.extend([dict(onset=round(pon,6),value=val,instrument='piano',controller=64,bar=bar,phrase_id=pp,kind='full' if val>=64 else 'partial'),dict(onset=round(poff,6),value=0,instrument='piano',controller=64,bar=bar,phrase_id=pp,kind='release')])
  for inst,pid in [('cello',cp),('piano',pp)]:
   phrase_meta.append(dict(phrase_id=pid,instrument=inst,phrase_label=label,first_bar=first,last_bar=first+3,section=section,layer=layer if inst=='cello' else ('foreground_'+layer if lead=='piano' else 'soft'),role=('lead' if lead==inst else 'answer_and_support'),timing_intent=('One recorded arco layer throughout; ordinary separate-bow triggers and audible punctuation.' if inst=='cello' else 'Compact accompaniment or explicitly assigned foreground response.')))
 events.sort(key=lambda e:(e['onset'],e['instrument'],e['pitch']))
 for i,e in enumerate(events,1):
  e['event_id']=f'w79-v{v}-{i:04}'
  e['target_on_seconds']=round(times(bars,e['onset']),6)
  e['target_off_seconds']=round(times(bars,e['onset']+e['duration']),6)
 for p in phrase_meta:
  es=[e for e in events if e['phrase_id']==p['phrase_id']]
  p['layers_used']=sorted(set(e['layer'] for e in es));p['roles_used']=sorted(set(e['role'] for e in es));p['voices_used']=sorted(set(e['voice'] for e in es));
  p['target_on_beats']=min(e['onset'] for e in es);p['target_off_beats']=max(e['onset']+e['duration'] for e in es)
  p['target_on_seconds']=round(times(bars,p['target_on_beats']),6);p['target_off_seconds']=round(times(bars,p['target_off_beats']),6)
 for inst in ('cello','piano'):
  ps=[p for p in phrase_meta if p['instrument']==inst]
  for p,q in zip(ps,ps[1:]):p['breath_to_next_phrase_seconds']=round(q['target_on_seconds']-p['target_off_seconds'],6)
 score=dict(id=79,title='The Watchmaker’s Lost Hour',title_zh=TITLE,version=f'v{v}',instrumentation=['piano','cello'],bars=bars,events=events,phrases=phrase_meta,pedals=pedals,total_beats=240.0,tail_seconds=6,performance_contract=dict(audio_status='Draft score only. No audio generated, rendered, or listened to. Numeric checks do not certify sampled performance.',beat_unit='absolute quarter note; each 6/8 bar occupies three quarter beats',piano_instrument='Approved Moonlight acoustic piano; no substitute requested.',cello_instrument='Parent-provided approved Iowa cello arco pp/mf recordings; actual sample evidence pending parent integration.',cello_onset='Ordinary sample trigger; no attack compensation has been applied or requested.',cello_register=[50,59],cello_layers='pp velocities 21–55; mf 56–95. A phrase uses exactly one recorded layer. No ff.',cello_max_nominal_gate_seconds=1.0,cello_min_nominal_inter_note_gate_gap_seconds=.25,cello_min_nominal_phrase_punctuation_seconds=.5,cello_articulation='Bowed separate notes only. No true legato, long loops, electronic sustain, or continuous bow claims.',piano_pedal='CC64 23–63 partial; 64–127 full. Explicit zero releases. Piano only.',piano_hand_span_semitones=12,piano_same_key_overlap='Forbidden across both hands.',balance='Cello lead bars: keep piano sparse and behind the cello. Only assigned piano melody passages take foreground. Actual balance remains for parent audio QA.',nominal_vs_sample='All gates/gaps are nominal score timing. Parent must measure sample onset/release, verify coverage and tails, and revise score timing if required.'))
 return score

def audit(s):
 errors=[];ev=s['events'];piano=[e for e in ev if e['instrument']=='piano'];cel=[e for e in ev if e['instrument']=='cello'];bars=s['bars']
 def sec(e):return times(bars,e['onset']),times(bars,e['onset']+e['duration'])
 maxgate=max(sec(e)[1]-sec(e)[0] for e in cel)
 gaps=[sec(b)[0]-sec(a)[1] for a,b in zip(cel,cel[1:])]
 if maxgate>1+1e-8:errors.append('cello gate over 1 second')
 if min(gaps)<.25-1e-8:errors.append('cello gap under .25 second')
 if any(not 50<=e['pitch']<=59 for e in cel):errors.append('cello range')
 for p in [p for p in s['phrases'] if p['instrument']=='cello']:
  es=[e for e in cel if e['phrase_id']==p['phrase_id']]
  if len(set(e['layer'] for e in es))!=1:errors.append('mixed cello phrase layer')
  if p.get('breath_to_next_phrase_seconds',99)<.5-1e-6:errors.append('phrase punctuation')
 for e in cel:
  lo,hi=(21,55) if e['layer']=='pp' else (56,95)
  if not lo<=e['velocity']<=hi:errors.append('velocity layer')
 overlaps=[]
 for key in set(e['pitch'] for e in piano):
  q=sorted([e for e in piano if e['pitch']==key],key=lambda e:e['onset'])
  for a,b in zip(q,q[1:]):
   if a['onset']+a['duration']>b['onset']+1e-7:overlaps.append([a['event_id'],b['event_id']])
 if overlaps:errors.append('piano same key overlap')
 handspans={}
 for hand in ('left','right'):
  es=[e for e in piano if e['hand']==hand];maxspan=0;maxexample=[]
  for onset in sorted(set(e['onset'] for e in es)):
   sounding=[e['pitch'] for e in es if e['onset']<=onset+1e-8 and e['onset']+e['duration']>onset+1e-8]
   span=max(sounding)-min(sounding)
   if span>maxspan:maxspan=span;maxexample=[onset,sounding]
  handspans[hand]={'maximum_simultaneous_span_semitones':maxspan,'example':maxexample}
  if maxspan>12:errors.append('piano handspan')
 if any(e['onset']<0 or e['duration']<=0 or e['onset']+e['duration']>s['total_beats']+1e-7 for e in ev):errors.append('invalid event times')
 if s['pedals'][-1]['value']!=0:errors.append('terminal pedal')
 for p in s['pedals']:
  if p['value'] and not(23<=p['value']<=127):errors.append('pedal value')
 return dict(version=s['version'],status='PASS' if not errors else 'FAIL',errors=errors,bars=len(bars),events=len(ev),event_counts=dict(collections.Counter(e['instrument'] for e in ev)),voice_counts=dict(collections.Counter(e['voice'] for e in ev)),phrases=len(s['phrases']),tempo_duration_seconds=round(times(bars,240),6),with_tail_seconds=round(times(bars,240)+6,6),cello_pitch_range=[min(e['pitch'] for e in cel),max(e['pitch'] for e in cel)],cello_velocity_by_layer={ly:[min(e['velocity'] for e in cel if e['layer']==ly),max(e['velocity'] for e in cel if e['layer']==ly)] for ly in ('pp','mf')},cello_min_nominal_gate_seconds=round(min(sec(e)[1]-sec(e)[0] for e in cel),6),cello_max_nominal_gate_seconds=round(maxgate,6),cello_min_nominal_inter_note_gate_gap_seconds=round(min(gaps),6),cello_min_nominal_phrase_punctuation_seconds=min(p['breath_to_next_phrase_seconds'] for p in s['phrases'] if p['instrument']=='cello' and 'breath_to_next_phrase_seconds' in p),cello_monophonic=min(gaps)>=0,piano_same_key_overlaps=overlaps,piano_handspans=handspans,pedal_count=len(s['pedals']),pedal_values=sorted(set(p['value'] for p in s['pedals'])),piano_melody_bars=sorted(set(e['bar'] for e in piano if e['voice']=='melody')),source_or_audio_verification_performed=False)

def musical_event(e):
 return {k:e[k] for k in ('bar','onset','duration','pitch','velocity','instrument','voice','role','layer','phrase_id')}
def diff(a,b):
 out=[]
 for ba,bb in zip(a['bars'],b['bars']):
  i=ba['bar'];ea=[musical_event(e) for e in a['events'] if e['bar']==i];eb=[musical_event(e) for e in b['events'] if e['bar']==i]
  changes={k:{'before':ba.get(k),'after':bb.get(k)} for k in ba if ba.get(k)!=bb.get(k)}
  if changes or ea!=eb:out.append(dict(bar=i,bar_field_changes=changes,events_before=ea,events_after=eb))
 return dict(from_version=a['version'],to_version=b['version'],changed_bars=len(out),bars=out)
if __name__=='__main__':
 scores=[build(v) for v in range(3)]
 audits=[]
 for s in scores:
  dump(f"score_{s['version']}.json",s);a=audit(s);audits.append(a);dump(f"audit_{s['version']}.json",a)
  if a['errors']:raise SystemExit(a)
 for a,b in zip(scores,scores[1:]):dump(f"diff_{a['version']}_{b['version']}.json",diff(a,b))
 dump('audit_summary.json',audits)
 for v in range(2):
  f0=(ROOT/f'score_v{v}.json').read_text().splitlines(True);f1=(ROOT/f'score_v{v+1}.json').read_text().splitlines(True)
  (ROOT/f'diff_v{v}_v{v+1}.patch').write_text(''.join(difflib.unified_diff(f0,f1,fromfile=f'score_v{v}.json',tofile=f'score_v{v+1}.json')))
 dump('sha256.json',{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(ROOT.glob('score_v*.json'))})
 print(json.dumps(audits,ensure_ascii=False,indent=2))
