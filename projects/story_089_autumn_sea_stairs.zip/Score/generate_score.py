#!/usr/bin/env python3
"""Deterministic, standard-library-only composer for work 089.

Creates three complete symbolic versions and literal musical diffs. No audio.
All note gates and bar starts use absolute QUARTER-NOTE beats.
"""
import argparse
import copy
import difflib
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
PITCH_CLASSES = {'C': 0, 'D': 2, 'E': 4, 'F': 5, 'G': 7, 'A': 9, 'B': 11}
def pitch(name):
    return 12 * (int(name[-1]) + 1) + PITCH_CLASSES[name[0]] + name[1:-1].count('#') - name[1:-1].count('b')
def melody(text):
    out = [(pitch(t.split(':')[0]), float(t.split(':')[1])) for t in text.split()]
    assert sum(v for _, v in out) == 5
    return out

# Each row is authored; no pseudo-random melody or block transposition.
MELODY = [
 'E5:1.5 A5:.5 G5:1 E5:2', 'F5:1 E5:1 D5:.5 C5:2.5',
 'D5:1.5 F5:.5 E5:1 D5:2', 'B4:1 C5:.5 D5:.5 B4:3',
 'C5:1 E5:1 A5:1 G5:2', 'F5:1 A5:.5 G5:.5 E5:3',
 'D5:1 E5:.5 F5:.5 D5:1 B4:2', 'G#4:1 B4:.5 E5:.5 D5:3',
 'E5:1.5 A5:.5 B5:1 A5:2', 'C6:1 B5:1 A5:1 G5:2',
 'A5:1.5 G5:.5 E5:1 F5:2', 'E5:1 D5:1 C5:1 B4:2',
 'C5:1.5 F5:.5 E5:1 D5:2', 'E5:1 G5:1 A5:.5 G5:2.5',
 'F5:1 E5:1 D5:1 C5:1 B4:1', 'B4:1 D5:.5 C5:.5 B4:1 A4:2',
 'D5:1 F5:1 A5:1 G5:2', 'E5:1.5 G5:.5 F5:1 E5:2',
 'D5:1 F5:.5 E5:.5 C5:3', 'B4:1 D5:1 E5:1 D5:2',
 'F5:1.5 E5:.5 C5:1 D5:2', 'E5:1 G5:1 F5:1 D5:2',
 'C5:1 D5:1 E5:.5 F5:2.5', 'G5:1.5 E5:.5 D5:1 E5:2',
 'F5:1 A5:.5 G5:.5 C6:3', 'B5:1 A5:1 G5:1 E5:2',
 'F5:1.5 E5:.5 D5:1 F5:2', 'E5:1 D5:1 C5:1 G5:2',
 'A5:1.5 C6:.5 B5:1 A5:2', 'G5:1 A5:.5 B5:.5 G5:3',
 'F5:1 A5:1 G5:1 E5:2', 'D5:1.5 E5:.5 F5:1 E5:2',
 'G5:1.5 C6:.5 B5:1 G5:2', 'A5:1 G5:1 E5:1 F5:2',
 'G5:1.5 E5:.5 D5:1 C5:2', 'D5:1 G5:1 F5:1 E5:2',
 'F5:1.5 E5:.5 D5:1 C5:2', 'B4:1 D5:1 F5:1 E5:2',
 'E5:1 F5:.5 G5:.5 E5:3', 'D5:1 C5:1 B4:1 A4:2',
 'C5:1.5 E5:.5 G5:1 A5:2', 'B5:1 A5:1 G5:1 F5:2',
 'E5:1 G5:.5 F5:.5 D5:3', 'C5:1.5 D5:.5 E5:1 G#5:2',
 'A5:1 G5:1 E5:1 D5:2', 'C5:1.5 E5:.5 D5:1 B4:2',
 'D5:1 E5:.5 G#5:.5 F5:3', 'E5:1 D5:1 B4:1 G#4:2',
 'E5:1.5 A5:.5 G5:1 E5:2', 'F5:1 A5:.5 G5:.5 E5:3',
 'D5:1 F5:1 A5:1 G5:.5 F5:1.5', 'E5:1.5 D5:.5 C5:1 B4:2',
 'C5:1 E5:1 A5:1 B5:2', 'C6:1.5 B5:.5 A5:1 G5:2',
 'F5:1 E5:1 D5:1 B4:2', 'E5:1.5 D5:.5 C5:1 A4:2',
 'C5:1.5 E5:.5 D5:1 C5:2', 'B4:1 D5:1 C5:1 B4:2',
 'A4:1.5 C5:.5 E5:1 D5:2', 'C5:1 B4:1 A4:1 G#4:2',
 'A4:1 C5:1 E5:1 A5:2', 'G5:1.5 F5:.5 E5:1 D5:2',
 'C5:1.5 B4:.5 G#4:1 B4:2', 'A4:1 C5:.5 E5:.5 A4:3',
]

HARMONIES = {
 'Am': [45, 48, 52, 57], 'Am/C': [48, 52, 57, 60],
 'Am(add9)': [45, 48, 52, 59], 'Am7': [45, 48, 52, 55],
 'Fmaj7': [41, 45, 48, 52], 'F': [41, 45, 48, 53],
 'F/A': [45, 48, 53, 57], 'Fmaj7/C': [48, 52, 53, 57],
 'Dm': [38, 45, 50, 53], 'Dm/A': [45, 50, 53, 57],
 'Dm7': [38, 41, 45, 48], 'Dm7/F': [41, 45, 48, 50],
 'Dm6/F': [41, 45, 47, 50], 'C': [48, 52, 55, 60],
 'C/E': [40, 43, 48, 52], 'Cmaj7': [48, 52, 55, 59],
 'C/G': [43, 48, 52, 55], 'G': [43, 47, 50, 55],
 'G7': [43, 47, 50, 53], 'G/B': [47, 50, 55, 59],
 'E7': [40, 44, 47, 50], 'E7/B': [47, 50, 52, 56],
 'E7sus4': [40, 45, 47, 50], 'E': [40, 44, 47, 52],
 'Bdim/F': [41, 47, 50, 53], 'BhalfDim': [47, 50, 53, 57],
}
# Replace two wide voicings with explicitly playable octave-contained forms.
HARMONIES['Am(add9)'] = [45, 47, 48, 52]
HARMONIES['Dm'] = [38, 41, 45, 50]
HARM = [
 'Am','Fmaj7/C','Dm/A','E7/B','Am/C','Fmaj7','BhalfDim','E7',
 'Am','Cmaj7','F/A','E7/B','Dm7/F','Am/C','BhalfDim','Am',
 'Dm/A','C/E','Fmaj7/C','E7sus4','Dm7/F','C/G','Fmaj7','E7',
 'F','Cmaj7','Dm7/F','C/G','F/A','G/B','Fmaj7','C/E',
 'C','F/A','C/E','G7','Dm7/F','G7','Am7','Dm/A',
 'Am/C','G/B','Dm7/F','E7','Am','Fmaj7','BhalfDim','E7',
 'Am','Fmaj7/C','Dm/A','E7/B','Am/C','F/A','E7sus4','Am',
 'Fmaj7','G/B','Am','E7','Am/C','Dm6/F','E7','Am',
]

V1_MELODY = {
 17:'D5:1.5 F5:.5 A5:1 G5:.5 F5:1.5',
 18:'E5:1 G5:.5 F5:.5 E5:1 D5:2',
 19:'C5:1.5 E5:.5 F5:1 E5:2',
 20:'D5:2 E5:.5 D5:.5 B4:2',
 21:'C5:1 F5:1 E5:.5 D5:2.5',
 22:'E5:.5 F5:.5 G5:1 F5:1 D5:2',
 23:'C5:1.5 D5:.5 E5:1 G5:2',
 24:'F5:1 E5:1 C5:1 E5:2',
 25:'F5:1.5 A5:.5 C6:1 A5:2',
 26:'G5:1 E5:1 G5:.5 A5:.5 B5:2',
 27:'A5:1 F5:.5 E5:.5 D5:1 F5:2',
 28:'E5:2 D5:.5 C5:.5 G5:2',
 29:'A5:1 C6:.5 B5:.5 A5:1 G5:2',
 30:'B5:1.5 A5:.5 G5:1 D5:2',
 31:'F5:1 A5:.5 G5:.5 E5:1 F5:2',
 32:'E5:1 D5:.5 C5:.5 E5:1 G5:2',
 33:'G5:1 C6:1 B5:.5 G5:2.5',
 34:'A5:1.5 G5:.5 F5:1 E5:2',
 35:'G5:1 E5:.5 D5:.5 C5:1 E5:2',
 36:'D5:1 G5:.5 F5:.5 E5:1 D5:2',
 37:'F5:1 A5:1 G5:1 F5:2',
 38:'D5:1 B4:.5 D5:.5 F5:1 G5:2',
 39:'E5:1.5 G5:.5 A5:1 E5:2',
 40:'F5:1 E5:.5 D5:.5 C5:1 B4:2',
}
V2_MELODY = {
 9:'E5:1 A5:1.5 B5:.5 A5:2',
 10:'C6:1.5 B5:.5 G5:1 A5:2',
 11:'A5:1 G5:.5 E5:.5 F5:1 D5:2',
 12:'E5:1.5 D5:.5 C5:.5 B4:.5 G#4:2',
 41:'E5:1 A5:1 G5:.5 E5:2.5',
 42:'F5:1.5 A5:.5 G5:1 F5:2',
 43:'D5:1 F5:.5 E5:.5 D5:1 B4:2',
 44:'E5:1.5 D5:.5 B4:1 G#4:2',
 45:'C5:1 E5:.5 A5:.5 G5:1 E5:2',
 46:'F5:1.5 E5:.5 D5:1 C5:2',
 47:'B4:1 D5:1 F5:.5 E5:2.5',
 48:'G#4:1 B4:.5 D5:.5 E5:1 G#5:2',
 49:'A5:1.5 C6:.5 B5:1 A5:2',
 50:'G5:1 A5:.5 C6:.5 B5:1 G5:2',
 51:'A5:1 F5:.5 E5:.5 D5:1 F5:2',
 52:'E5:1.5 G#5:.5 F5:1 E5:2',
 53:'E5:.5 A5:1.5 G5:.5 E5:.5 C5:2',
 54:'D5:1 F5:.5 A5:.5 G5:1 F5:2',
 55:'E5:1.5 D5:.5 B4:1 G#4:2',
 56:'A4:1 C5:.5 E5:.5 D5:1 C5:2',
 57:'E5:2 A5:.5 G5:.5 E5:2',
 58:'F5:1.5 E5:.5 D5:1 C5:2',
 59:'D5:1 F5:.5 E5:.5 C5:1 B4:2',
 60:'B4:1 D5:.5 E5:.5 D5:1 G#4:2',
 61:'A4:1.5 C5:.5 E5:1 C5:2',
 62:'D5:1 F5:.5 E5:.5 D5:1 B4:2',
 63:'C5:1 B4:1 G#4:1 B4:2',
 64:'A4:1 E5:1 A4:3',
}
V1_HARM = {19:'Fmaj7',20:'BhalfDim',23:'C/G',24:'C/E',27:'Dm7',30:'G7',32:'C',36:'G/B',39:'Am',40:'E7sus4'}
V2_HARM = {10:'Fmaj7/C',12:'E7',41:'Am',42:'F/A',43:'BhalfDim',44:'E7',46:'Dm7/F',48:'E7/B',49:'Am/C',50:'Cmaj7',52:'E7',53:'Am',54:'Dm/A',55:'E7',57:'Am',58:'Fmaj7/C',59:'BhalfDim',60:'E7',61:'Am/C',62:'Dm6/F'}
PHRASE_LABELS = ['上段三阶与转身','铁桶在扶手旁','量到第四道水痕','下端尚有一步','缺口前的木板','改走售鱼亭后侧','把短料向上传','绳结绕过平台','隔着栏杆递尺','旧漆线上的新箭头','回到先前的量点','把低处的粉笔收起','两人抬过新斜撑','一桶工具先上岸','傍晚复核转向','留住最后一条线']
SECTIONS = [(1,16,'A','沿石阶下行','A minor'),(17,24,'B','中断的平台','A minor / dominant approach'),(25,40,'C','从背街向上传料','F major / C major'),(41,48,'D','重测原来的转角','A minor'),(49,56,'A2','转身后的主题','A minor'),(57,64,'Coda','收起工具仍留标线','A minor')]
BASE_TEMPI = [94,96,94,99,102,99,97,86]

def dumps(x): return json.dumps(x,ensure_ascii=False,indent=2)+'\n'
def save(root,name,x): (root/name).write_text(dumps(x),encoding='utf-8')
def seconds(bars,beat): return sum(min(max(beat-b['start'],0),5)*60/b['bpm'] for b in bars)
def finger_map(keys,hand):
    fingers={1:[3],2:[1,5],3:[1,3,5],4:[1,2,4,5],5:[1,2,3,4,5]}[len(keys)]
    return dict(zip(keys,fingers if hand=='right' else fingers[::-1]))

def compose(version):
    texts=list(MELODY); hs=list(HARM)
    if version>=1:
        for n,v in V1_MELODY.items(): texts[n-1]=v
        for n,v in V1_HARM.items(): hs[n-1]=v
    if version>=2:
        for n,v in V2_MELODY.items(): texts[n-1]=v
        for n,v in V2_HARM.items(): hs[n-1]=v
    bars=[]; events=[]; pedals=[]; plans=[]
    for n in range(1,65):
        sec=next(row for row in SECTIONS if row[0]<=n<=row[1])
        bpm=BASE_TEMPI[(n-1)//8]+[0,1,0,-2][(n-1)%4]
        if n>=61: bpm={61:84,62:83,63:80,64:76}[n]
        bar={'bar':n,'start':float((n-1)*5),'beats':5.0,'bpm':bpm,'meter':'5/4','meter_numerator':5,'meter_denominator':4,
             'section':sec[2],'section_title_zh':sec[3],'harmony_name':hs[n-1],'harmony':HARMONIES[hs[n-1]],
             'lead_instrument':'piano','key_region':sec[4],'phrase_id':f'P{(n-1)//4+1:02d}',
             'phrase_position':(n-1)%4+1,'metrical_grouping':'3+2' if n<25 or n>40 else '2+3',
             'role_plan':'One singing RH line; quiet LH steps carry harmony. Small later RH dyads reinforce the same line.'}
        bars.append(bar)
        phrase=f'P{(n-1)//4+1:02d}_piano'; label=PHRASE_LABELS[(n-1)//4]
        m=melody(texts[n-1]); right_keys=sorted(set(p for p,_ in m))
        # One occasional dyad at a cadence strengthens a lead note; no second melody.
        inner=None
        if version>=2 and n in (49,52,54):
            inner={49:76,52:71,54:74}[n]
            right_keys=sorted(set(right_keys+[inner]))
        assert len(right_keys)<=5 and max(right_keys)-min(right_keys)<=12,(n,right_keys)
        lh_keys=sorted(HARMONIES[hs[n-1]])
        assert max(lh_keys)-min(lh_keys)<=12,(n,lh_keys)
        rmap=finger_map(right_keys,'right'); lmap=finger_map(lh_keys,'left')
        def add(hand,voice,offset,duration,p,velocity,written=None):
            keys=right_keys if hand=='right' else lh_keys
            fmap=rmap if hand=='right' else lmap
            events.append({'bar':n,'onset':round(bar['start']+offset,6),'duration':round(duration,6),'pitch':p,'velocity':velocity,
                'instrument':'piano','voice':voice,'hand':hand,'role':'lead' if voice=='melody' else 'support',
                'phrase_id':phrase,'phrase_label':label,'event_id':f'w89-b{n:02d}-{voice}-{len([e for e in events if e["bar"]==n and e["voice"]==voice])+1:02d}',
                'harmonic_function':'chord_tone' if p%12 in {x%12 for x in lh_keys} else 'melodic_nonchord_tone',
                'written_value_beats':written if written is not None else duration,
                'articulation':'cantabile_released_fingers' if voice=='melody' else 'quiet_released_steps',
                'hand_position_id':f'{hand[0].upper()}-b{n:02d}', 'hand_position_range':[min(keys),max(keys)],
                'position_keys':keys,'finger':fmap[p],
                'fingering_intent':'Fixed bar grip: ascending keys use the declared distinct fingers; close alternatives are never held with one finger. Release and translate at the next bar.'})
        dynamic=[65,68,69,67,70,73,78,61][(n-1)//8]
        off=0
        for i,(p,w) in enumerate(m):
            # Final note releases 0.42 quarter beats before every next position.
            # The last bar instead carries a three-beat tonic key hold.
            gate=w-(0 if n==64 and i==len(m)-1 else .42 if i==len(m)-1 else .06)
            add('right','melody',off,gate,p,dynamic+[0,2,1,-2,-3][i%5],w)
            if inner is not None and i==len(m)-1:
                add('right','harmonic_reinforcement',off,min(gate,1.25),inner,dynamic-20,min(w,1.25))
            off+=w
        ascending=25<=n<=32 or (version>=1 and 25<=n<=40)
        order=lh_keys if ascending else lh_keys[::-1]
        patterns=[[0,1,2,3.5],[0,.75,1.75,3],[0,1.25,2.25,3.75],[0,1,2.5,3.5]]
        times=patterns[(n-1)%4]
        if version>=1 and n in (20,24): times=[0,.75,2,4]
        if version>=2 and n in (41,45,49,53): times=[0,.75,1.5,3.25]
        if n>=61: times={61:[0,1,2.5,3.75],62:[0,1.5,2.5,3.5],63:[0,1,2,3.5],64:[0,1,2,3]}[n]
        for i,(p,t) in enumerate(zip(order,times)):
            following=times[i+1] if i<3 else 5
            gate=following-t-(.34 if i<3 else .52)
            if n==64 and i==3: gate=2.0
            add('left','accompaniment',t,gate,p,dynamic-22+(2 if i==0 else 0),following-t)
        for hand,keys,fm in [('right',right_keys,rmap),('left',lh_keys,lmap)]:
            plans.append({'bar':n,'hand':hand,'position_id':f'{hand[0].upper()}-b{n:02d}',
                'range':[min(keys),max(keys)],'pitch_finger_map':{str(k):fm[k] for k in keys},
                'within_position_method':'Distinct fingers reach an ordered span of at most one octave; no hand translation inside this bar.',
                'next_position_method':'All physical keys release before the next bar; pedal may sustain resonance only.'})
        # Pedal clears on each new harmony and once within each five-beat bar.
        points=[(0,0),(.10,55),(2.88,0),(3.08,48),(4.88,0)]
        if n==64: points=[(0,0),(.10,50),(5,0)]
        for t,v in points:
            pedals.append({'bar':n,'onset':bar['start']+t,'controller':64,'value':v,'instrument':'piano'})
    events.sort(key=lambda e:(e['onset'],e['hand'],e['pitch'],e['voice']))
    for e in events:
        e['target_on_beats']=e['onset'];e['target_off_beats']=round(e['onset']+e['duration'],6)
        e['target_on_seconds']=round(seconds(bars,e['onset']),6);e['target_off_seconds']=round(seconds(bars,e['target_off_beats']),6)
    phrases=[]
    for i,label in enumerate(PHRASE_LABELS):
        pid=f'P{i+1:02d}_piano'; ns=[e for e in events if e['phrase_id']==pid]
        a=min(e['onset'] for e in ns);b=max(e['onset']+e['duration'] for e in ns)
        phrases.append({'phrase_id':pid,'instrument':'piano','phrase_label':label,'first_bar':i*4+1,'last_bar':i*4+4,
            'section':bars[i*4]['section'],'role':'lead_and_support','layer':'not_applicable','layers_used':[],
            'roles_used':['lead','support'],'voices_used':sorted({e['voice'] for e in ns}),
            'target_on_beats':a,'target_off_beats':round(b,6),'target_on_seconds':round(seconds(bars,a),6),'target_off_seconds':round(seconds(bars,b),6),
            'timing_intent':'Four-bar phrase nested in an eight-bar scene; 5/4 = five absolute quarter beats.'})
    return {'id':89,'title':'A Staircase for the Autumn Sea','title_zh':'秋海的台阶','version':f'v{version}',
        'instrumentation':['natural_acoustic_piano'],'bars':bars,'events':events,'phrases':phrases,'pedals':pedals,
        'total_beats':320.0,'tail_seconds':6.0,'hand_position_plan':plans,
        'performance_contract':{
            'audio_status':'Symbolic composition only; no audio generation, DSP, source downloads, installs, or listening.',
            'beat_unit':'Absolute quarter-note beats. A 5/4 bar contains exactly five beats. Quarter-note BPM.',
            'piano_instrument':'Natural acoustic piano; later integration must verify the actual source and balance.',
            'maximum_held_span_semitones':12,'same_key_overlaps':'Forbidden, including between hands.',
            'position_transfer_rule':'Whole-hand motion is checked using the greater of actual held-grip edge and declared position-edge travel. Distances above four require 75 ms + 12 ms per extra semitone after the latest prior physical key release. Every changed position also receives at least 75 ms.',
            'finger_plan':'Every note and every bar-hand position has an explicit ordered pitch/finger map, at most five distinct keys and at most an octave. Within-position melodic movement uses those distinct fingers; no thumb-under or silent finger substitution is assumed.',
            'pedal':'Pedal extends resonance only; held spans and movement time use physical note-off. Numbers express pedal intent, not a sample-specific half-pedal guarantee.',
            'musical_limits':'Symbolic geometric feasibility and documented phrasing only. Human comfort, sound, pedal decay, expressive timing, and mix require later performance/audio review.'}}

def exact_diff(root,a,b):
    sa=json.loads((root/f'score_{a}.json').read_text());sb=json.loads((root/f'score_{b}.json').read_text())
    changes=[]
    for n in range(1,65):
        row={'bar':n,'before_bar':sa['bars'][n-1],'after_bar':sb['bars'][n-1],
            'before_events':[e for e in sa['events'] if e['bar']==n],'after_events':[e for e in sb['events'] if e['bar']==n],
            'before_pedals':[e for e in sa['pedals'] if e['bar']==n],'after_pedals':[e for e in sb['pedals'] if e['bar']==n]}
        if any(row['before_'+k]!=row['after_'+k] for k in ('bar','events','pedals')): changes.append(row)
    sha=lambda n:hashlib.sha256((root/n).read_bytes()).hexdigest()
    save(root,f'exact_diff_{a}_to_{b}.json',{'from':a,'to':b,'before_sha256':sha(f'score_{a}.json'),'after_sha256':sha(f'score_{b}.json'),
        'changed_bars':[x['bar'] for x in changes],'changes':changes,
        'phrase_metadata_before':sa['phrases'],'phrase_metadata_after':sb['phrases'],
        'position_plan_before':sa['hand_position_plan'],'position_plan_after':sb['hand_position_plan']})
    patch=''.join(difflib.unified_diff(dumps(sa).splitlines(True),dumps(sb).splitlines(True),fromfile=f'score_{a}.json',tofile=f'score_{b}.json'))
    (root/f'exact_diff_{a}_to_{b}.patch').write_text(patch,encoding='utf-8')

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--outdir',type=Path,default=ROOT);args=parser.parse_args()
    root=args.outdir.resolve()
    if root!=ROOT and ROOT not in root.parents: raise SystemExit('Output must remain inside this work folder.')
    root.mkdir(parents=True,exist_ok=True)
    for v in range(3): save(root,f'score_v{v}.json',compose(v))
    (root/'score.json').write_bytes((root/'score_v2.json').read_bytes())
    for a,b in [('v0','v1'),('v1','v2')]:exact_diff(root,a,b)
    print(dumps({'created':['score_v0.json','score_v1.json','score_v2.json','score.json'],'duration_with_tail_seconds':round(seconds(compose(2)['bars'],320)+6,6)}))
if __name__=='__main__':main()
