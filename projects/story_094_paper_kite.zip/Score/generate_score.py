#!/usr/bin/env python3
"""Original work094. Symbolic score only. Python standard library, no audio.
Every notation/time value is in quarter-note beats; a 2/4 bar is two beats.
"""
import argparse, copy, difflib, hashlib, json
from pathlib import Path

ROOT=Path(__file__).resolve().parent
PC={'C':0,'D':2,'E':4,'F':5,'G':7,'A':9,'B':11}
def midi(s): return 12*(int(s[-1])+1)+PC[s[0]]+s[1:-1].count('#')-s[1:-1].count('b')
def parse(s):
    out=[(midi(t.split(':')[0]),float(t.split(':')[1])) for t in s.split()]
    assert abs(sum(w for p,w in out)-2)<1e-8,s
    return out

# Each row is an authored eight-bar sentence. Returns quote the short refrain,
# then change its answering interval, harmony, register, or cadence.
LINES=[
 'F4:.5 Bb4:.5 D5:1 | C5:.5 D5:.5 F5:1 | Eb5:.5 D5:.5 C5:1 | A4:1 C5:1 | Bb4:.5 D5:.5 F5:1 | G5:.5 F5:.5 Eb5:1 | D5:1 C5:1 | A4:1 F4:1',
 'D5:.5 C5:.5 Bb4:1 | F5:.5 Eb5:.5 D5:1 | G5:.5 F5:.5 Eb5:.5 D5:.5 | C5:1 A4:.5 C5:.5 | D5:.5 F5:.5 Bb5:1 | A5:.5 G5:.5 F5:1 | Eb5:.5 D5:.5 C5:1 | D5:1 Bb4:1',
 'D5:.5 C5:.5 Bb4:1 | F5:.5 Eb5:.5 D5:1 | G5:1 F5:.5 Eb5:.5 | D5:.5 C5:.5 A4:1 | Bb4:.5 D5:.5 F5:1 | Eb5:.5 G5:.5 F5:1 | Eb5:1 C5:.5 A4:.5 | Bb4:2',
 'F5:.5 D5:.5 Bb4:1 | D5:.5 Eb5:.5 F5:1 | G5:.5 Bb5:.5 A5:1 | F5:.5 Eb5:.5 C5:1 | D5:1 F5:.5 D5:.5 | C5:.5 Eb5:.5 G5:1 | F5:.5 Eb5:.5 C5:1 | D5:.5 C5:.5 Bb4:1',
 'G4:.5 Bb4:.5 D5:1 | Eb5:.5 D5:.5 C5:1 | F5:.5 D5:.5 Bb4:1 | A4:.5 C5:.5 F5:1 | G5:.5 F5:.5 Eb5:1 | D5:.5 Eb5:.5 G5:1 | F5:1 C5:.5 A4:.5 | Bb4:1 D5:1',
 'D5:.5 F5:.5 G5:1 | Eb5:.5 D5:.5 C5:1 | D5:.5 F5:.5 Bb5:1 | A5:.5 F5:.5 C5:1 | Eb5:1 G5:.5 F5:.5 | D5:.5 C5:.5 Bb4:1 | C5:.5 D5:.5 Eb5:1 | F5:1 A5:1',
 'Bb5:.5 A5:.5 G5:1 | F5:.5 Eb5:.5 D5:1 | Eb5:.5 G5:.5 Bb5:1 | A5:1 F5:1 | D5:.5 C5:.5 Bb4:1 | G4:.5 Bb4:.5 D5:1 | C5:1 A4:1 | F4:1 F#4:1',
 'G4:.5 Bb4:.5 D5:1 | C5:.5 Bb4:.5 A4:1 | Bb4:.5 D5:.5 G5:1 | F#5:1 D5:1 | Eb5:.5 D5:.5 C5:1 | Bb4:.5 C5:.5 D5:1 | A4:.5 C5:.5 F#5:1 | G5:1 D5:1',
 'Bb4:1 A4:.5 G4:.5 | C5:.5 D5:.5 Eb5:1 | D5:.5 C5:.5 Bb4:1 | A4:.5 F#4:.5 D4:1 | G4:.5 A4:.5 Bb4:1 | C5:1 Eb5:.5 D5:.5 | F#5:.5 E5:.5 D5:1 | Bb4:1 G4:1',
 'D5:.5 Eb5:.5 D5:1 | G5:.5 F5:.5 Eb5:1 | D5:.5 Bb4:.5 G4:1 | A4:.5 C5:.5 F#5:1 | G5:.5 D5:.5 Bb4:1 | C5:.5 Eb5:.5 D5:1 | F#5:1 A5:1 | G5:1 D5:1',
 'Bb4:.5 D5:.5 G5:1 | Eb5:1 C5:.5 Bb4:.5 | A4:.5 Bb4:.5 D5:1 | F#5:.5 E5:.5 D5:1 | G5:.5 F5:.5 Eb5:1 | C5:.5 Bb4:.5 G4:1 | A4:1 F#4:1 | G4:2',
 'G4:.5 Bb4:.5 D5:1 | Eb5:1 G5:1 | F5:.5 Eb5:.5 D5:1 | C5:.5 A4:.5 F4:1 | Bb4:.5 D5:.5 F5:1 | G5:.5 F5:.5 Eb5:1 | C5:.5 D5:.5 Eb5:1 | F5:2',
 'F5:.5 Eb5:.5 D5:1 | G5:.5 F5:.5 Eb5:1 | D5:.5 C5:.5 Bb4:1 | C5:.5 D5:.5 F5:1 | Eb5:.5 D5:.5 C5:1 | D5:.5 F5:.5 A5:1 | G5:.5 Eb5:.5 C5:1 | A4:1 C5:1',
 'D5:.5 F5:.5 Bb5:1 | A5:.5 G5:.5 F5:1 | G5:.5 F5:.5 Eb5:1 | F5:.5 Eb5:.5 C5:1 | D5:.5 C5:.5 Bb4:1 | C5:.5 D5:.5 Eb5:1 | F5:1 A5:1 | F5:2',
 'D5:.5 C5:.5 Bb4:1 | F5:.5 Eb5:.5 D5:1 | G5:.5 F5:.5 Eb5:.5 D5:.5 | C5:1 A4:.5 C5:.5 | D5:.5 F5:.5 Bb5:1 | A5:.5 G5:.5 F5:1 | Eb5:.5 C5:.5 A4:1 | Bb4:2',
 'F5:.5 Eb5:.5 D5:1 | G5:1 Bb5:1 | A5:.5 G5:.5 F5:1 | Eb5:.5 D5:.5 C5:1 | D5:1 Bb4:.5 D5:.5 | F5:.5 G5:.5 A5:1 | G5:.5 Eb5:.5 C5:1 | F5:1 D5:1',
 'D5:.5 F5:.5 Bb5:1 | C6:.5 Bb5:.5 A5:1 | Bb5:.5 A5:.5 G5:1 | F5:1 A5:1 | Bb5:.5 D6:.5 C6:1 | Bb5:.5 A5:.5 G5:1 | F5:.5 Eb5:.5 C5:1 | D5:1 F5:1',
 'G5:.5 F5:.5 Eb5:1 | F5:.5 Eb5:.5 D5:1 | Bb4:.5 D5:.5 F5:1 | G5:.5 F5:.5 C5:1 | D5:.5 C5:.5 Bb4:1 | Eb5:.5 G5:.5 F5:1 | C5:.5 A4:.5 F4:1 | Bb4:1 D5:1',
 'D5:.5 C5:.5 Bb4:1 | F5:.5 Eb5:.5 D5:1 | G5:.5 Bb5:.5 A5:1 | F5:.5 Eb5:.5 C5:1 | D5:.5 F5:.5 Bb5:1 | A5:1 G5:.5 F5:.5 | Eb5:.5 C5:.5 A4:1 | Bb4:2',
 'Bb4:.5 D5:.5 F5:1 | G5:.5 F5:.5 Eb5:1 | D5:.5 C5:.5 Bb4:1 | A4:.5 C5:.5 F5:1 | Eb5:1 C5:1 | D5:.5 F5:.5 D5:1 | C5:.5 A4:.5 F4:1 | Bb4:2',
 'D5:1 C5:.5 Bb4:.5 | F5:1 Eb5:.5 D5:.5 | G5:.5 F5:.5 Eb5:1 | D5:.5 C5:.5 A4:1 | Bb4:.5 D5:.5 F5:1 | Eb5:.5 D5:.5 C5:1 | A4:1 C5:1 | Bb4:2',
 'F5:.5 D5:.5 Bb4:1 | Eb5:1 C5:1 | D5:.5 C5:.5 Bb4:1 | A4:.5 C5:.5 F5:1 | Eb5:1 C5:1 | D5:1 Bb4:1 | A4:1 C5:1 | Bb4:2',
]
HARM_ROWS=[
 'Bb F/A Eb F7 Bb Eb F7 F7',
 'Bb Bb/D Eb F7 Bb F Eb F7',
 'Bb F/A Eb F7 Bb Cm F7 Bb',
 'Bb Bb/D Eb F7 Gm Cm F7 Bb',
 'Gm Cm Bb/D F/A Eb Cm F7 Bb',
 'Gm Cm Bb F7 Eb Bb Cm F7',
 'Gm Bb/D Eb F7 Bb Gm F7 D7',
 'Gm D7 Gm D7 Cm Gm D7 Gm',
 'Gm Cm Gm D7 Gm Cm D7 Gm',
 'Gm Cm Gm D7 Gm Cm D7 Gm',
 'Gm Cm Gm/Bb D7 Eb Cm D7 Gm',
 'Gm Eb Bb/D F7 Bb Eb Cm F7',
 'Bb/D Eb Bb F/A Cm Dm Cm F7',
 'Bb F/A Eb F7 Bb Cm F7 F7',
 'Bb Bb/D Eb F7 Bb F Eb Bb',
 'Bb/D Eb F7 Cm Gm F/A Cm Bb/D',
 'Bb F Eb F7 Bb Gm F7 Bb',
 'Eb Bb/D Bb F7 Gm Cm F7 Bb',
 'Bb F/A Eb F7 Bb Gm F7 Bb',
 'Bb Eb Gm F7 Cm Bb/D F7 Bb',
 'Bb F/A Eb F7 Bb Cm F7 Bb',
 'Bb Cm Bb/D F7 Eb Bb F7 Bb',
]
HARM={
 'Bb':[46,50,53], 'Bb/D':[50,53,58], 'F':[41,45,48], 'F/A':[45,48,53],
 'F7':[45,48,51,53], 'Eb':[43,46,51], 'Cm':[48,51,55], 'Gm':[43,46,50],
 'Gm/Bb':[46,50,55], 'D7':[42,45,48,50], 'Dm':[45,50,53],
 'Bb6':[46,50,53,55], 'Eb/G':[43,46,51], 'Cm/Eb':[39,43,48],
 'F7/C':[48,51,53,57], 'Gm/D':[38,43,46], 'D7/A':[45,48,50,54],
}
LABELS=['把线轴排在白线后','灯位第一次连成折线','短句从人群上方回来','系好右侧提线','最后一个灯夹有点重','把纸面翻到工作灯下','阵风吹乱演出单','蓝色大鸢仍在地面','长绳退回箱内','水边传来两次哨声','轮到空出来的那一格','先让小鸢走一遍','白板上擦去原来的箭头','重新叫到三个名字','第一条短线升起来','灯点绕开暗着的一角','三只小鸢分层经过','最后一组错开入场','同一句旋律换了收尾','草地上的线轴渐渐停住','还亮着的夹灯被取下来','写明明晚先试哪一只']
SECTIONS=[(1,8,'Intro','河堤试风','B-flat major'),(9,32,'A','纸上的第一条星线','B-flat major'),
 (33,56,'B','改提线和灯夹','B-flat major / G minor'),(57,88,'C','大鸢暂缓','G minor'),
 (89,112,'D','改写出场顺序','G minor to B-flat major'),(113,152,'A2','短线逐一入场','B-flat major'),
 (153,176,'Coda','收线和明晚的记号','B-flat major')]

# A flute response takes the whole foreground for one or two bars. At most two
# consecutive bars have flute, then at least two bars of breathing/other lead.
FLUTE={7:'C5',8:'A5',15:'Eb5',16:'D5',23:'A5',24:'Bb5',31:'C5',32:'D5',
 39:'C5',40:'D5',47:'Eb5',48:'F5',55:'C5',56:'D5',63:'F#5',64:'G5',
 71:'F#5',72:'G5',79:'A5',80:'G5',87:'F#5',88:'G5',95:'Eb5',96:'F5',
 103:'G5',104:'A5',111:'A5',112:'F5',119:'C5',120:'D5',127:'G5',128:'F5',
 135:'C5',136:'D5',143:'A5',144:'Bb5',151:'C5',152:'D5',159:'A5',160:'Bb5',
 167:'A5',168:'Bb5',173:'G5',174:'F5'}

# Revision 1 makes the workshop development less square: changing accents and
# inner bass direction, stronger inversions, and a less predictable minor answer.
V1_LINES={
33:'Bb4:.5 D5:1 G4:.5',34:'Eb5:1 D5:.5 C5:.5',35:'D5:.5 F5:1 Bb4:.5',36:'C5:1 A4:.5 F5:.5',
37:'G5:.5 Eb5:1 F5:.5',38:'Eb5:.5 D5:.5 C5:.5 G4:.5',41:'G5:1 F5:.5 D5:.5',42:'Eb5:.5 C5:1 D5:.5',
43:'F5:.5 D5:.5 Bb5:1',44:'A5:1 G5:.5 F5:.5',45:'G5:.5 F5:.5 Eb5:.5 D5:.5',46:'D5:1 C5:.5 Bb4:.5',
49:'G5:1 Bb5:.5 A5:.5',50:'D5:.5 F5:1 Eb5:.5',51:'G5:.5 Eb5:.5 Bb5:1',52:'F5:1 A5:.5 F5:.5',
53:'Bb4:.5 D5:1 C5:.5',54:'D5:.5 Bb4:1 G4:.5',65:'Bb4:.5 A4:1 G4:.5',66:'C5:1 Eb5:.5 D5:.5',
67:'D5:.5 Bb4:1 C5:.5',68:'A4:1 F#4:.5 D4:.5',69:'G4:.5 Bb4:1 D5:.5',70:'Eb5:.5 C5:1 D5:.5',
}
V1_HARM={33:'Gm/Bb',35:'Bb',36:'F7/C',37:'Eb/G',38:'Cm/Eb',41:'Gm/D',43:'Bb/D',45:'Eb/G',46:'Gm',49:'Gm/Bb',50:'Bb',53:'Bb6',54:'Gm/D',65:'Gm/Bb',67:'Gm/D',69:'Gm/Bb'}
V1_FLUTE={39:'A5',40:'Bb5',47:'G5',48:'A5',55:'A5',56:'F#5',71:'A5',72:'G5'}

# Revision 2 rewrites the return and final cadence; this is not a velocity pass.
V2_LINES={
113:'D5:.5 C5:.5 Bb4:1',114:'F5:1 Eb5:.5 D5:.5',115:'G5:.5 F5:1 Eb5:.5',116:'C5:.5 A4:.5 C5:1',
117:'D5:.5 F5:1 Bb5:.5',118:'A5:1 G5:.5 F5:.5',121:'D5:.5 Eb5:.5 F5:1',122:'G5:.5 Bb5:1 G5:.5',
123:'A5:1 F5:.5 Eb5:.5',124:'D5:.5 C5:1 Eb5:.5',125:'Bb4:.5 D5:1 F5:.5',126:'A5:.5 G5:.5 F5:1',
129:'F5:.5 D5:.5 Bb5:1',130:'C6:1 Bb5:.5 A5:.5',131:'G5:.5 Bb5:1 A5:.5',132:'F5:.5 A5:1 F5:.5',
133:'Bb5:.5 C6:.5 D6:1',134:'C6:.5 Bb5:.5 G5:1',137:'Eb5:.5 G5:1 F5:.5',138:'D5:.5 F5:1 Eb5:.5',
139:'D5:.5 Bb4:.5 F5:1',140:'G5:1 F5:.5 C5:.5',141:'D5:.5 C5:1 Bb4:.5',142:'Eb5:.5 F5:.5 G5:1',
145:'D5:.5 C5:.5 Bb4:1',146:'F5:1 D5:.5 Eb5:.5',147:'G5:.5 F5:.5 Bb5:1',148:'A5:.5 F5:.5 C5:1',
149:'D5:.5 F5:1 Bb5:.5',150:'A5:.5 G5:.5 F5:1',169:'F5:.5 D5:1 Bb4:.5',170:'Eb5:.5 D5:.5 C5:1',
171:'D5:1 C5:.5 Bb4:.5',172:'C5:.5 A4:.5 F5:1',175:'A4:.5 C5:.5 F5:1',176:'Bb4:2',
}
V2_HARM={114:'Bb6',115:'Eb/G',117:'Bb/D',121:'Bb/D',124:'Cm/Eb',125:'Gm/Bb',129:'Bb/D',131:'Eb/G',133:'Bb6',134:'Gm/Bb',137:'Eb/G',139:'Bb/D',141:'Gm/Bb',145:'Bb',147:'Eb/G',149:'Bb/D',150:'Gm',169:'Bb/D',171:'Gm/Bb',174:'Bb/D'}
V2_FLUTE={119:'A5',120:'Bb5',127:'Eb5',128:'D5',135:'A5',136:'Bb5',143:'C5',144:'D5',151:'A5',152:'Bb5',173:'Eb5',174:'D5'}

def dumps(x):return json.dumps(x,ensure_ascii=False,indent=2)+'\n'
def save(root,n,x):(root/n).write_text(dumps(x),encoding='utf-8')
def sec(bars,t):return sum(min(max(t-b['start'],0),b['beats'])*60/b['bpm'] for b in bars)
def fingermap(keys,hand):
    fs={1:[3],2:[1,5],3:[1,3,5],4:[1,2,4,5],5:[1,2,3,4,5]}[len(keys)]
    if len(keys)==4:
        widest=max(range(3),key=lambda i:keys[i+1]-keys[i])
        fs=([1,3,4,5],[1,2,4,5],[1,2,3,5])[widest]
        if hand=='left':return dict(zip(keys,([5,3,2,1],[5,4,2,1],[5,4,3,1])[widest]))
    return dict(zip(keys,fs if hand=='right' else fs[::-1]))
def bpm(n):
    if n<=8:return [108,110,112,112,114,114,112,110][n-1]
    if n<=32:return 116 if n%8 not in (0,7) else 112
    if n<=56:return 118 if n%8 not in (0,7) else 114
    if n<=88:return 104 if n%8 not in (0,7) else 102
    if n<=112:return 108+(n-89)//8*3
    if n<=152:return 118 if n%8 not in (0,7) else 114
    if n<=168:return 110 if n%8 not in (0,7) else 106
    return [108,106,104,102,100,98,94,88][n-169]
def section(n):return next(x for x in SECTIONS if x[0]<=n<=x[1])
def build(version):
    lv=int(version[1:]);mel=[s.strip() for row in LINES for s in row.split('|')];harm=[h for row in HARM_ROWS for h in row.split()];fl=FLUTE.copy()
    assert len(mel)==len(harm)==176
    for level,mm,hh,ff in [(1,V1_LINES,V1_HARM,V1_FLUTE),(2,V2_LINES,V2_HARM,V2_FLUTE)]:
        if lv>=level:
            for n,v in mm.items():mel[n-1]=v
            for n,v in hh.items():harm[n-1]=v
            fl.update(ff)
    bars=[];events=[];plans=[];ped=[]
    for n in range(1,177):
        _,_,sect,stitle,key=section(n);start=(n-1)*2;pid=f'P{(n-1)//8+1:02d}';label=LABELS[(n-1)//8]
        h=harm[n-1];ch=HARM[h];owner='flute' if n in fl else 'piano'
        texture='bass_and_afterbeat'
        if 57<=n<=88:texture='held_minor_shell'
        if lv>=1 and 33<=n<=56:texture='turning_three_note_support'
        if lv>=2 and 113<=n<=152:texture='displaced_chord_answer' if n%4 in (1,2) else 'bass_and_afterbeat'
        if n>=169:texture='spare_cadential_shell'
        b={'bar':n,'start':float(start),'beats':2.0,'bpm':bpm(n),'meter':'2/4','meter_numerator':2,'meter_denominator':4,
           'section':sect,'section_title_zh':stitle,'harmony_name':h,'harmony':ch,'lead_instrument':owner,'lead_hand':'not_applicable' if owner=='flute' else 'right',
           'key_region':key,'phrase_id':pid,'phrase_position':(n-1)%8+1,'metrical_grouping':'1+1','texture':texture,
           'role_plan':'One piano melody or one flute answer; all keyboard support is quieter and belongs to the same named chord.'}
        bars.append(b)
        def add(p,at,dur,vel,inst,voice,hand,role,written=None):
            e={'bar':n,'onset':round(start+at,6),'duration':round(dur,6),'pitch':p,'velocity':vel,'instrument':inst,'voice':voice,'hand':hand,'role':role,
               'phrase_id':pid+'_'+inst,'phrase_label':label,'harmony_name':h,'harmonic_function':'chord_tone' if p%12 in {q%12 for q in ch} else 'melodic_nonchord_tone',
               'written_value_beats':written if written is not None else dur}
            events.append(e);return e
        energy=67 if n<=8 else 72 if n<=32 else 74 if n<=56 else 67 if n<=88 else 70 if n<=112 else 79 if n<=152 else 69
        quiet=39 if n<=56 else 34 if n<=88 else 38 if n<=112 else 43 if n<=152 else 35
        if owner=='piano':
            t=0;seq=parse(mel[n-1])
            for j,(p,w) in enumerate(seq):
                gap=.22 if j==len(seq)-1 else .09
                dur=w-gap
                if n==176:dur=w
                e=add(p,t,dur,energy+[2,-2,1,-3][j%4]-(4 if n>=169 else 0),'piano','melody','right','lead',w)
                e['articulation']='light_detached_scherzo' if n<57 or n>112 else 'connected_minor_sentence_with_real_key_releases'
                t+=w
        else:
            layer='pp' if n<=8 or 57<=n<=104 or n>=153 else 'mf'
            vel=55+(n%3)*2 if layer=='pp' else 70+(n%3)*3
            arrival=.35 if n-1 in fl else 0
            e=add(midi(fl[n]),arrival,1.35,vel,'flute','phrase_answer','not_applicable','answer',2.0-arrival)
            e.update({'layer':layer,'sample_layer':layer,'source_family':'University of Iowa flute','source_pitch_midi':midi(fl[n]),
              'nominal_gate_seconds':round(1.35*60/bpm(n),9),'onset_reference':'ordinary_trigger','articulation':'separate_breath_shaped_note',
              'timing_correction_applied_seconds':0.0,'maximum_later_trigger_advance_seconds':.209,
              'minimum_usable_pitched_seconds_after_209ms_advance':round(1.35*60/bpm(n)-.209,9),
              'breath_id':pid+'_flute_b'+str(n),'release_reason':'The second answer arrives 0.35 beat late, preserving >=0.30 seconds of gap under a worst 159 ms differential trigger advance.',
              'velocity_controls':'within_recorded_layer_amplitude_intent',
              'timing_intent':'Uncompensated ordinary trigger at intended pitched arrival. Owner measures attack and advances once by 50–209 ms; do not advance here or fake legato.'})
            # A restrained upper chord is held under the answer. It is not a
            # competing tune; its single attack stays well below flute mf.
            rhs=[p for p in range(65,77) if p%12 in {q%12 for q in ch}][:3]
            for p in rhs:
                e=add(p,0,1.45,quiet-7,'piano','answer_bed','right','support',2.0);e['articulation']='quiet_chord_under_flute'
        if texture in ('held_minor_shell','spare_cadential_shell'):
            for p in (ch[0],ch[-1]):
                e=add(p,0,1.47,quiet-1,'piano','harmonic_shell','left','support',2.0);e['articulation']='two_note_shell'
        elif texture=='turning_three_note_support':
            for j,(p,t,d) in enumerate([(ch[0],0,.25),(ch[1],.5,.25),(ch[-1],1,.56)]):
                e=add(p,t,d,quiet-1+j,'piano','inner_support','left','support',.5 if j<2 else 1.0);e['articulation']='three_note_chord_tone_turn'
        elif texture=='displaced_chord_answer':
            # First beat is a bass; the second beat answers with a short chord.
            e=add(ch[0],0,.50,quiet-1,'piano','harmonic_bass','left','support',1.0);e['articulation']='short_bass'
            for p in ch[1:]:
                e=add(p,1.15,.39,quiet,'piano','harmonic_afterbeat','left','support',.85);e['articulation']='delayed_afterbeat'
        else:
            e=add(ch[0],0,.48,quiet-1,'piano','harmonic_bass','left','support',1.0);e['articulation']='short_bass'
            for p in ch[1:]:
                e=add(p,1,.56,quiet,'piano','harmonic_afterbeat','left','support',1.0);e['articulation']='light_afterbeat'
        for hand in ('left','right'):
            ns=[e for e in events if e['bar']==n and e['hand']==hand];keys=sorted({e['pitch'] for e in ns});fmap=fingermap(keys,hand)
            plan={'bar':n,'hand':hand,'position_id':hand[0].upper()+f'-b{n:03d}','range':[min(keys),max(keys)],'pitch_finger_map':{str(k):v for k,v in fmap.items()},'active':True,
              'within_position_method':'Distinct ordered fingers in one octave-contained grip; no thumb crossing or finger substitution.',
              'next_position_method':'Every physical key releases before a changed position; maximum grip-edge and position-edge travel is checked independently.'}
            plans.append(plan)
            for e in ns:e.update({'hand_position_id':plan['position_id'],'hand_position_range':plan['range'],'position_keys':keys,'finger':fmap[e['pitch']],
                                 'fingering_intent':'Ordered distinct fingers; actual held notes must fit this grip; pedal does not hold physical keys.'})
        ped.extend([{'bar':n,'onset':float(start),'controller':64,'value':0,'instrument':'piano'},
                    {'bar':n,'onset':start+.08,'controller':64,'value':28 if owner=='piano' else 36,'instrument':'piano'},
                    {'bar':n,'onset':start+1.64,'controller':64,'value':0,'instrument':'piano'}])
    ped.append({'bar':176,'onset':352.0,'controller':64,'value':0,'instrument':'piano'})
    # Reserve the actual physical travel interval, using both full-position
    # edges and the last/first sounding grips. This never extends a key or uses
    # sustain pedal as release. The independent reader recalculates the rule.
    for hand in ('left','right'):
        hp={p['bar']:p for p in plans if p['hand']==hand}
        for n in range(1,176):
            old=[e for e in events if e['bar']==n and e['hand']==hand]
            new=[e for e in events if e['bar']==n+1 and e['hand']==hand]
            a=max(e['onset'] for e in old);z=min(e['onset'] for e in new)
            oldkeys=[e['pitch'] for e in old if e['onset']<=a<e['onset']+e['duration']]
            newkeys=[e['pitch'] for e in new if e['onset']==z]
            edge=max(abs(x-y) for x,y in zip([min(oldkeys),max(oldkeys)],[min(newkeys),max(newkeys)]))
            pos=max(abs(x-y) for x,y in zip(hp[n]['range'],hp[n+1]['range']))
            required=.075+.012*max(0,max(edge,pos)-4)+.008
            latest=z-required*bars[n-1]['bpm']/60
            for e in old:
                if e['onset']+e['duration']>latest:
                    e['duration']=round(latest-e['onset'],6)
                    e['release_adjustment']='Physical release leaves whole-grip transfer time plus an 8 ms score margin.'
    events.sort(key=lambda e:(e['onset'],e['instrument'],e['hand'],e['pitch'],e['voice']))
    counter={}
    for e in events:
        k=(e['bar'],e['instrument'],e['voice']);counter[k]=counter.get(k,0)+1
        e['event_id']=f'w94-b{e["bar"]:03d}-{e["instrument"]}-{e["voice"]}-{counter[k]:02d}'
        e.update({'target_on_beats':e['onset'],'target_off_beats':round(e['onset']+e['duration'],6),
                  'target_on_seconds':round(sec(bars,e['onset']),9),'target_off_seconds':round(sec(bars,e['onset']+e['duration']),9)})
    phrases=[]
    for k in range(22):
        for inst in ('piano','flute'):
            pid=f'P{k+1:02d}_{inst}';ns=[e for e in events if e['phrase_id']==pid]
            if not ns:continue
            a=min(e['onset'] for e in ns);z=max(e['onset']+e['duration'] for e in ns)
            phrases.append({'phrase_id':pid,'instrument':inst,'phrase_label':LABELS[k],'first_bar':k*8+1,'last_bar':k*8+8,'section':bars[k*8]['section'],
              'role':'answer' if inst=='flute' else 'lead_and_support','layer':ns[0]['layer'] if inst=='flute' else 'not_applicable',
              'layers_used':sorted({e['layer'] for e in ns if 'layer' in e}),'roles_used':sorted({e['role'] for e in ns}),'voices_used':sorted({e['voice'] for e in ns}),
              'target_on_beats':a,'target_off_beats':round(z,6),'target_on_seconds':round(sec(bars,a),9),'target_off_seconds':round(sec(bars,z),9),
              'timing_intent':'Eight 2/4 bars form a sixteen-quarter sentence. Flute owns only the named answer bars; it releases between ordinary triggers and rests for six bars after its usual two-bar response.'})
    return {'id':94,'title':'The Paper Kite Constellation','title_zh':'纸鸢的星图','version':version,
      'instrumentation':['natural_acoustic_piano','natural_acoustic_flute'],'bars':bars,'events':events,'phrases':phrases,'pedals':ped,
      'total_beats':352.0,'tail_seconds':4.0,'hand_position_plan':plans,
      'performance_contract':{'audio_status':'Symbolic only: no audio, DSP, samples, downloads, installations or listening performed.',
       'beat_unit':'Absolute quarter-note beats. Every 2/4 bar contains two beats; all tempo markings use quarter-note BPM.',
       'foreground':'One foreground at a time. Piano melody disappears during flute answers; keyboard support remains chord-bound and quieter.',
       'maximum_held_span_semitones':12,'maximum_piano_pitch_midi':87,
       'position_transfer_rule':'Use maximum of actual held-grip edge displacement and full declared position-edge displacement. Every changed grip releases all physical keys for at least 75 ms, plus 12 ms for each travel semitone above four.',
       'same_key_overlaps':'Forbidden on piano across both hands and every voice. Finger collisions and hand crossings are forbidden.',
       'pedal':'CC64 expresses resonance only; it never extends physical keys or excuses transfer time.',
       'flute':'Use recorded MIDI 72–83 only. True pp velocity <=63; true mf velocity >=64. No ff. Nominal ordinary triggers are intended pitched arrivals; owner applies measured 50–209 ms attack advance once. Gates are 0.65–1.10 seconds; release gaps >=0.30 seconds. No fake legato.',
       'musical_limits':'Symbolic audit is not listening acceptance or performer comfort certification. Source quality, attack alignment, acoustic balance, release tails and final render remain owner integration work.'}}

def patch(a,b,path=''):
    if a==b:return []
    if isinstance(a,dict) and isinstance(b,dict):
        out=[]
        for k in sorted(set(a)|set(b)):
            p=path+'/'+k.replace('~','~0').replace('/','~1')
            if k not in b:out.append({'op':'remove','path':p})
            elif k not in a:out.append({'op':'add','path':p,'value':b[k]})
            else:out+=patch(a[k],b[k],p)
        return out
    return [{'op':'replace','path':path,'value':b}]
def emit_diff(root,a,b):
    before=dumps(a);after=dumps(b);av=a['version'];bv=b['version'];changes=[]
    for n in range(1,177):
        row={'bar':n,'before_bar':a['bars'][n-1],'after_bar':b['bars'][n-1],
             'before_events':[e for e in a['events'] if e['bar']==n],'after_events':[e for e in b['events'] if e['bar']==n],
             'before_pedals':[e for e in a['pedals'] if e['bar']==n],'after_pedals':[e for e in b['pedals'] if e['bar']==n]}
        if any(row['before_'+k]!=row['after_'+k] for k in ('bar','events','pedals')):changes.append(row)
    save(root,f'exact_diff_{av}_to_{bv}.json',{'from_version':av,'to_version':bv,'before_sha256':hashlib.sha256(before.encode()).hexdigest(),'after_sha256':hashlib.sha256(after.encode()).hexdigest(),
      'changed_bars':[r['bar'] for r in changes],'changes':changes,'phrase_metadata_before':a['phrases'],'phrase_metadata_after':b['phrases'],
      'position_plan_before':a['hand_position_plan'],'position_plan_after':b['hand_position_plan'],'json_patch':patch(a,b)})
    (root/f'exact_diff_{av}_to_{bv}.patch').write_text(''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile=f'score_{av}.json',tofile=f'score_{bv}.json')),encoding='utf-8')
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--outdir',default=str(ROOT));args=ap.parse_args();root=Path(args.outdir);root.mkdir(parents=True,exist_ok=True)
    ss=[build(v) for v in ('v0','v1','v2')]
    for s in ss:save(root,f'score_{s["version"]}.json',s)
    save(root,'score.json',ss[-1])
    emit_diff(root,ss[0],ss[1]);emit_diff(root,ss[1],ss[2])
if __name__=='__main__':main()
