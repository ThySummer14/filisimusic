"""Original two-wind botanical disputation in changing additive meters. Nominal score only."""
from copy import deepcopy
ID=143;TITLE='Two Springs in One Greenhouse';TITLE_ZH='温室里相反的春天'
INSTRUMENT_MAP={'piano':'piano','clarinet':'clarinet','flute':'flute'}
RENDERER_NOTES='Clarinet and flute represent the north and south beds, with separate melodic and breathing patterns. Piano is an active third participant and takes fast notes. Do not double wind stems or quantize their offsets. All onsets are nominal; no audio has been rendered.'
RENDERER_NOTES += ' The nominal rest layout now reserves at least the next pitch/layer sample delay plus 0.14 seconds before each flute/arco attack. The renderer must still apply recording compensation exactly once.'
H={'Dm':[38,53,57],'D9':[38,54,57,60,64],'Gm':[43,58,62],'C7':[36,52,58,64],'F6':[41,57,60,62],'A7':[45,55,61,64],'BbM':[46,62,65],'Eb6':[39,55,58,60],'DbM':[37,53,56],'E7':[40,56,59,62],'Amin':[45,60,64],'Bdim':[47,62,65],'G7':[43,59,62,65],'Ab6':[44,60,63,65],'Fsharp7':[42,58,61,64],'Dopen':[38,57,64],'Csharpdim':[37,52,55,58]}
STREAMS={'A':('piano','right',60,92,'irrigation_interjections'),'L':('piano','left',33,59,'root_counterline'),'B':('clarinet','none',60,71,'north_bed_subject'),'C':('flute','none',72,83,'south_bed_subject')}
R={
'a':[(0,.4),(.75,.4),(1.5,.6),(2.5,.4),(3,.4),(4,.7)],
'b':[(.25,.35),(.75,.35),(1.25,.35),(2,.35),(2.75,.35),(3.5,.35),(4.25,.5)],
'c':[(0,.22),(.375,.22),(.75,.22),(1.25,.22),(1.625,.22),(2,.22),(2.75,.22),(3.125,.22),(3.5,.22),(4.25,.45)],
'd':[(.5,.6),(1.5,.4),(2.25,.8),(3.5,.45),(4.25,.45)],
'e':[(0,1),(1.5,.65),(2.75,.65),(4,.7)],
'f':[(.25,.35),(1,.35),(1.75,.35),(2.5,.35),(3.25,.35),(4,.35),(4.5,.3)],
'l':[(.5,.8),(1.75,.55),(3,.8),(4.25,.5)],
'm':[(0,.75),(1.25,.65),(2.75,.65),(4,.65)],
'n':[(.25,.55),(1,.55),(2.25,.7),(3.5,.55),(4.5,.3)],
'o':[(0,1.15),(2,.8),(3.25,1)],
'u':[(0,.8),(1.5,.85),(3.25,.9)],
'v':[(.75,.9),(2.5,.8),(4,.75)],
'w':[(.25,1),(2,.9),(3.75,.7)],
'x':[(.5,.85),(2.25,1),(4,.7)],
'y':[(0,1),(1.75,.75),(3.5,.85)],
'z':[(1,.85),(2.75,.85),(4.25,.6)],
'q':[(.75,1),(3,.95)],'rest':[]}
def section(name,count,bpm,meters,hs,A,L,B,C,ar,lr,br,cr,dyn,phrase):
 return dict(name=name,count=count,bpm=bpm,meters=meters,harmonies=hs.split(),pitches={k:v.split() for k,v in [('A',A),('L',L),('B',B),('C',C)]},rhythms={k:v.split() for k,v in [('A',ar),('L',lr),('B',br),('C',cr)]},dyn=dyn,phrase=phrase)
SECTIONS=[
section('The_north_bed_blooms_first',7,100,[5,5,3,5,6],
'Dm Gm A7 Dm F6 C7 Dm',
'D5 A4 F5 E5 G5 D5 A5 F5 E5 C#5 D5 G5 F5 A5 C6 Bb5 G5 E5 D5',
'D3 F3 A3 G3 E3 C#3 D3 A3 F3 G3 Bb3 A3 C3 G3 E3 D3',
'D4 E4 F4 A4 G4 Eb4 C4 Db4 F4 G4 A4 E4 D4 F4 A4 G4 E4',
'A5 F5 E5 G5 D5 F5 Bb5 A5 E5 F5 D5 C5 E5 G5 A5 F5',
'e a d b','o l m','u w v q','x q z y rest',66,'7-bar exposure: the cold bed flowers before the sunlit bed'),
section('South_glass_catches_the_heat',13,108,[5,5,6,5,3,5],
'F6 C7 Dm BbM Gm A7 Dm Eb6 DbM C7 F6 E7 Amin',
'C6 A5 F5 G5 Bb5 A5 E5 G5 D5 F5 A5 C6 Bb5 G5 E5 C#5 D5 F5 Eb5 G5 Bb5 Db6 C6 Ab5 F5 E5 G5 Bb5 A5 F5 E5 C6 B5 G#5 E5 A5',
'F3 A3 C4 Bb3 G3 E3 D3 F3 A3 Bb3 F3 D3 G3 Bb3 A3 E3 C#3 D3 Eb3 Bb2 Db3 Ab3 F3 C3 E3 G3 A3 E3',
'F4 A4 G4 E4 D4 F4 Bb4 A4 G4 E4 C#4 D4 F4 Eb4 G4 Bb4 Ab4 F4 E4 G4 A4 B4 G#4 E4',
'C5 E5 G5 Bb5 A5 F5 D5 F5 A5 G5 E5 C5 D5 F5 Ab5 G5 Eb5 C5 Db5 F5 Ab5 G5 E5 A5 B5 G#5',
'a b d c f e','m n l o n','v u w q u','y z x rest q x z',80,'5+8: the sunlit bed grows its own incompatible sentence'),
section('Frost_crosses_one_pane',9,114,[5,3,5,6,5],
'Amin E7 Amin D9 Gm C7 F6 Bdim E7',
'E6 C6 B5 G#5 A5 C6 D6 F#5 A5 C6 Bb5 G5 E5 F5 A5 C6 B5 G5 F5 D5 E5 G#5 B5 A5',
'A2 E3 G3 B3 A3 F3 D3 F#3 A3 G3 Bb3 D4 C4 A3 F3 B2 F3 D3 E3',
'E4 G#4 B4 A4 F4 E4 D4 F#4 A4 G4 F4 E4 C4 D4 F4 G#4 B4 A4',
'E5 C5 D5 F#5 A5 G5 E5 C5 F5 A5 G5 B5 A5 F5 D5 E5 G#5 B5',
'c f b d a','n m l','w v u rest','z x y q',89,'4+5: an oblique modulation, no rest scene'),
section('Hail_passes_over_the_divider',17,120,[5,6,5,3,5,5,6],
'Amin D9 G7 C7 F6 Fsharp7 Bdim E7 Amin Ab6 DbM C7 F6 BbM Eb6 A7 Dm',
'A5 C6 E6 D6 B5 G5 E5 D5 F#5 A5 C6 B5 G5 E5 C6 Bb5 G5 E5 F5 A5 C6 Eb6 D6 Bb5 F#5 A5 C6 B5 F5 D5 E5 G#5 B5 D6 C6 A5 G5 Ab5 C6 Eb6 Db6 Bb5 Ab5 F5 E5 G5 Bb5 C6 A5 F5 D5 F5 Bb5 A5 G5 Eb5 C#5 E5 G5 A5',
'A2 C3 E3 G3 F#3 D3 A3 C4 B3 G3 E3 C3 E3 G3 Bb3 A3 F3 C3 F#3 A3 C4 B3 F3 D3 E3 G#3 B3 A3 C4 Ab3 Eb3 Db3 Ab3 F3 C3 E3 G3 F3 Bb3 G3 Eb3 A3 E3',
'A4 G4 E4 D4 F#4 A4 B4 G4 E4 C4 D4 F4 A4 G4 F#4 E4 D4 F4 B4 A4 G#4 E4 C4 Eb4 Ab4 G4 F4 Db4 C4 E4 G4 Bb4 A4 F4 D4',
'C5 E5 A5 G5 E5 D5 F#5 A5 B5 G5 E5 C5 F5 A5 C5 Eb5 D5 F#5 A5 G5 F5 D5 E5 G#5 B5 A5 C5 Eb5 Ab5 G5 Db5 F5 Ab5 Bb5 G5 E5 F5 A5 Bb5 G5 Eb5 C#5',
'c f c b d c a','n l m n o','u w v u q w','z x y q x z y',105,'5+5+7: the longest crossing of weather; the wind lines do not share cadences'),
section('Roots_pull_in_opposite_directions',11,108,[3,5,5,6,5],
'Eb6 BbM Gm C7 F6 E7 Amin Ab6 DbM Csharpdim A7',
'Bb5 G5 Eb5 F5 A5 C6 Bb5 G5 D5 F5 A5 G5 C6 Bb5 E5 G#5 B5 A5 G5 E5 C5 Eb5 Ab5 G5 F5 Db5 C5 E5 G5 Bb5 A5 G5 E5 C#5',
'Eb3 Bb3 G3 F3 D3 Bb2 G3 D3 F3 E3 C3 F3 A3 G#3 E3 B2 A2 E3 G3 Ab3 Eb3 Db3 F3 E3 C#3 A2',
'G4 Eb4 F4 A4 Bb4 G4 D4 F4 A4 G4 E4 C4 D4 E4 G#4 A4 G4 Eb4 C4 Db4 F4 E4 C#4',
'Eb5 G5 Bb5 A5 F5 D5 C5 E5 G5 A5 F5 E5 G#5 B5 A5 G5 Eb5 C5 Db5 F5 Ab5 G5 E5 C#5',
'd f b e c','o n l m','q v w u','x z q y w',88,'6+5: displacement stays forceful even when the register narrows'),
section('The_partition_stays',15,112,[5,5,6,3,5,5],
'Dm Gm C7 F6 BbM Eb6 Ab6 DbM Csharpdim A7 Dm G7 C7 A7 Dopen',
'D5 F5 A5 G5 E5 C5 D5 G5 Bb5 A5 F5 E5 C5 F5 A5 C6 Bb5 G5 Eb5 G5 Bb5 Ab5 F5 Db5 Eb5 Ab5 C6 Bb5 G5 E5 C#5 E5 G5 A5 F5 D5 G5 B5 A5 E5 C5 E5 G5 Bb5 A5 E5 C#5 D5 A4',
'D3 A3 F3 G3 Bb3 D4 C4 G3 E3 F3 A3 C4 Bb3 F3 D3 Eb3 G3 Bb3 Ab3 Eb3 C3 Db3 F3 Ab3 G3 E3 C#3 A2 E3 G3 D3 F3 A3 G3 B3 C4 Bb3 E3 C#3 D3',
'D4 F4 E4 A4 G4 Eb4 C4 Db4 F4 G4 Bb4 A4 F4 D4 Eb4 G4 Bb4 Ab4 F4 Db4 C4 E4 G4 A4 F4 D4 G4 B4 A4 E4 C4 D4 F4 E4',
'A5 F5 E5 G5 D5 F5 Bb5 A5 E5 F5 C5 E5 G5 Bb5 A5 F5 D5 Eb5 G5 Bb5 Ab5 F5 Db5 C5 E5 G5 A5 F5 D5 C5 E5 G5 Bb5 A5 E5 D5',
'a c f d b e','m l n o','w u v q w','z x y rest q z',91,'4+6+5: the two beds end at different times; no tutti victory cadence')]
REV1=set(range(8,21))|set(range(30,36));REV2=set(range(42,49))|set(range(60,73))
H1={10:'D9',14:'Eb6',18:'E7',32:'Fsharp7',35:'Ab6'};H2={43:'DbM',46:'Csharpdim',62:'Eb6',68:'G7',71:'Csharpdim'}
def midi(s):return 12*(int(s[-1])+1)+{'C':0,'D':2,'E':4,'F':5,'G':7,'A':9,'B':11}[s[0]]+s[1:-1].count('#')-s[1:-1].count('b')
def fit(p,lo,hi):
 while p<lo:p+=12
 while p>hi:p-=12
 return max(lo,min(hi,p))
def woodwind_breathing(s):
 # Schedule real breathing space in seconds; preserve the existing gate length.
 # If a whole note cannot fit after a breath, omit that attack as a written rest.
 bars={b['bar']:b for b in s['bars']};elapsed={};t=0
 for b in s['bars']:elapsed[b['bar']]=t;t+=b['beats']*60/b['bpm']
 changes=[];removed=set()
 for inst in ('clarinet','flute'):
  last_end=-100
  for e in sorted((x for x in s['events'] if x['instrument']==inst),key=lambda x:x['onset']):
   b=bars[e['bar']];scale=60/b['bpm'];gate=e['duration']*scale
   start_sec=elapsed[e['bar']]+(e['onset']-b['start'])*scale
   if gate<.24:
    removed.add(id(e));changes.append(dict(bar=e['bar'],instrument=inst,action='write_rest_instead_of_truncated_short_attack',old_onset=e['onset'],duration_seconds=gate));continue
   need=max(0,last_end+.145-start_sec)
   if need>1e-7:
    new=e['onset']+need/scale
    if new+e['duration']>b['start']+b['beats']-.001:
     removed.add(id(e));changes.append(dict(bar=e['bar'],instrument=inst,action='write_rest_to_preserve_gate_and_breath',old_onset=e['onset'],duration_seconds=gate));continue
    changes.append(dict(bar=e['bar'],instrument=inst,action='delay_entire_note_for_breath',old_onset=e['onset'],new_onset=round(new,6),unchanged_duration=e['duration']))
    e['onset']=round(new,6);start_sec+=need
   last_end=start_sec+gate
 s['events']=[e for e in s['events'] if id(e) not in removed]
 s['woodwind_breathing_edits']=changes
 return s


# Verified sample metadata is used only by the symbolic checker.
SAMPLE_ONSET_DELAY_SECONDS={'flute': {('pp', 72): 0.08001201545335887, ('pp', 73): 0.0898971264827533, ('pp', 74): 0.07983842903523583, ('pp', 75): 0.1493489920217505, ('pp', 76): 0.20904149215655404, ('pp', 77): 0.14934985469784817, ('pp', 78): 0.11997712832295855, ('pp', 79): 0.16949112668248204, ('pp', 80): 0.09911726838782998, ('pp', 81): 0.07989101914124709, ('pp', 82): 0.08930452854032835, ('pp', 83): 0.07969237353709822, ('mf', 72): 0.060406515461735574, ('mf', 73): 0.07052517082997613, ('mf', 74): 0.11057205801867949, ('mf', 75): 0.10008089987737774, ('mf', 76): 0.10027069311440293, ('mf', 77): 0.09023997500344833, ('mf', 78): 0.11085664032736406, ('mf', 79): 0.08014430460612983, ('mf', 80): 0.09986319709244704, ('mf', 81): 0.08019292717345358, ('mf', 82): 0.05048814813842415, ('mf', 83): 0.050517319660623915}, 'cello': {('pp', 50): 0.10430518803605385, ('pp', 51): 0.10280911869175927, ('pp', 52): 0.10107662039108264, ('pp', 53): 0.10095623968778887, ('pp', 54): 0.1001470130812132, ('pp', 55): 0.09929602634988755, ('pp', 56): 0.10059127916195107, ('pp', 57): 0.10322761451400336, ('pp', 58): 0.10446920374237796, ('pp', 59): 0.10385513320742007, ('mf', 50): 0.10469473964787179, ('mf', 51): 0.10344570956415314, ('mf', 52): 0.10309932466853362, ('mf', 53): 0.10185307413906473, ('mf', 54): 0.10093829174587371, ('mf', 55): 0.1009149971460755, ('mf', 56): 0.10303760532574009, ('mf', 57): 0.10505530283181855, ('mf', 58): 0.10504705203028203, ('mf', 59): 0.10491690185566772}}
SAMPLE_DELAY_PROVENANCE={'flute': {'path': 'assets/iowa_flute_C5_B5/mapping_manifest.json', 'sha256': '716574ead3c7cb0da47d0a4f537e358b24f322f91546396c9a12969d9cb47e52', 'field': 'voiced_onset_delay_after_tuning_seconds'}, 'cello': {'path': 'assets/iowa_cello_arco_D3_B3/mapping_manifest.json', 'sha256': '70053fff468d349619e1e1c00c262fe75098d35f95be6fad7a9d8ef8a69f1d49', 'field': 'coarse_voiced_delay_after_tuning_seconds'}}
# Local beat positions chosen for clearer phrase rests, not recording offsets.
NOMINAL_REST_LAYOUT={0: {('flute', 15): {0: 0.375}, ('flute', 23): {0: 0.5, 1: 2}, ('flute', 27): {0: 0.25}, ('flute', 36): {0: 0.375, 1: 2}, ('flute', 43): {0: 0.375, 1: 2}, ('flute', 60): {0: 0.25}, ('flute', 66): {0: 0.25}}, 1: {('flute', 15): {0: 0.375}, ('flute', 23): {0: 0.5, 1: 2}, ('flute', 27): {0: 0.25}, ('flute', 36): {0: 0.375, 1: 2}, ('flute', 43): {0: 0.375, 1: 2}, ('flute', 60): {0: 0.25}, ('flute', 66): {0: 0.25}}, 2: {('flute', 15): {0: 0.375}, ('flute', 23): {0: 0.5, 1: 2}, ('flute', 27): {0: 0.25}, ('flute', 36): {0: 0.375, 1: 2}, ('flute', 42): {0: 0.25}, ('flute', 48): {0: 0.125}, ('flute', 60): {0: 0.25}, ('flute', 62): {0: 0.125}, ('flute', 68): {0: 0.125}}}

def nominal_rest_layout(s, level):
 # Authored rests on explicit fractional-beat positions. These are musical
 # nominal onsets, never sample-trigger advances. Retain all pitches, velocities,
 # gates and event identities within each line; only the listed attacks move.
 bars={b['bar']:b for b in s['bars']};changes=[]
 for (instrument,bn),positions in NOMINAL_REST_LAYOUT[level].items():
  ee=sorted((e for e in s['events'] if e['instrument']==instrument and e['bar']==bn),key=lambda e:e['onset'])
  for index,local_onset in positions.items():
   e=ee[index];old=e['onset'];new=round(bars[bn]['start']+local_onset,6)
   assert old<=new and new+e['duration']<=bars[bn]['start']+bars[bn]['beats']
   e['onset']=new
   changes.append(dict(bar=bn,instrument=instrument,line_note_index=index,old_nominal_onset=old,new_nominal_onset=new,unchanged_pitch=e['pitch'],unchanged_velocity=e['velocity'],unchanged_duration=e['duration'],reason='Written phrase rest or following attack repositioned; no sample compensation.'))
 s['nominal_rest_layout_edits']=changes
 return s

def harmonic_finish(s):
 # A melodic dissonance is retained only when the next note of that same
 # line resolves by one or two semitones to the actual current harmony.
 # Otherwise correct the local landing, never relabel a collision as style.
 from collections import defaultdict
 groups=defaultdict(list);bars={b['bar']:b for b in s['bars']}
 for e in s['events']:groups[(e['bar'],e['instrument'],e['voice'],e['hand'])].append(e)
 evidence=[]
 for (bn,inst,voice,hand),ee in groups.items():
  ee.sort(key=lambda x:x['onset']);pcs={p%12 for p in bars[bn]['harmony']}
  lo,hi=(60,96) if inst=='piano' and hand=='right' else (31,59) if inst=='piano' else (60,71) if inst=='clarinet' else (72,83) if inst=='flute' else (36,47) if s['instrument_map'].get('cello')=='pizz' else (50,59)
  for i in range(len(ee)-1,-1,-1):
   e=ee[i];p=e['pitch']
   if p%12 in pcs:continue
   nx=ee[i+1] if i+1<len(ee) else None
   resolved=nx and nx['pitch']%12 in pcs and 1<=abs(nx['pitch']-p)<=2
   if resolved:
    evidence.append(dict(bar=bn,instrument=inst,voice=voice,harmony=bars[bn]['harmony_name'],pitch=p,onset=e['onset'],resolution_pitch=nx['pitch'],resolution_onset=nx['onset'],classification='explicit stepwise appoggiatura, neighbor or passing tone; not a chord member'))
   else:
    cc=[q for q in range(lo,hi+1) if q%12 in pcs]
    e['pitch']=min(cc,key=lambda q:(abs(q-p),q))
 s['intentional_nonchord_tones']=sorted(evidence,key=lambda x:(x['bar'],x['onset'],x['instrument']))
 # Report the retained final score pitch, after the unchanged harmonic pass.
 for edit in s.get('nominal_rest_layout_edits',[]):
  ee=sorted((e for e in s['events'] if e['instrument']==edit['instrument'] and e['bar']==edit['bar']),key=lambda e:e['onset'])
  edit['unchanged_pitch']=ee[edit['line_note_index']]['pitch']
 s['harmonic_review_scope']='Each remaining non-chord event resolves by step to a chord member in its own line within the same bar. This is symbolic voice-leading evidence, not an audio quality claim.'
 return s

def build(level):
 bars=[];events=[];pedals=[];start=0;n=0;phrase_map=[]
 for si,s in enumerate(SECTIONS):
  cur={k:0 for k in STREAMS};first=n+1
  for j in range(s['count']):
   n+=1;beats=s['meters'][j%len(s['meters'])];bpm=s['bpm'];h=s['harmonies'][j%len(s['harmonies'])]
   r1=level>=1 and n in REV1;r2=level>=2 and n in REV2
   if r1:h=H1.get(n,h)
   if r2:h=H2.get(n,h)
   bars.append(dict(bar=n,start=start,beats=beats,bpm=bpm,meter_numerator=int(beats),meter_denominator=4,section=s['name'],harmony_name=h,harmony=H[h]))
   for key,(inst,hand,lo,hi,voice) in STREAMS.items():
    cells=deepcopy(R[s['rhythms'][key][j%len(s['rhythms'][key])]])
    if r1 and key=='B':cells=[(.25,.7),(1.75,.85),(3.5,.8)]
    if r1 and key=='L':cells=[(.25,.6),(1.5,.75),(3,.7),(4.25,.5)]
    if r2 and key=='C':cells=[(0,.85),(1.75,.85),(3.5,.95)]
    if r2 and key=='A':cells=deepcopy(R['f' if n<49 else 'b'])
    if n==61 and key=='B':cells=[(0,.65),(1.25,.7),(2.25,.6)]
    if beats==6 and key in ('A','L'):cells.append((5,.6 if key=='L' else .4))
    if si==5 and j>=12 and key=='C':cells=R['q'] if j==12 else []
    for k,(t,dur) in enumerate(cells):
     if t>=beats-.05:continue
     dur=min(dur,beats-t-.025)
     p=midi(s['pitches'][key][cur[key]%len(s['pitches'][key])]);cur[key]+=1
     if r1 and key=='B':p=[62,65,64,69,67,63,60,61,65,67,70,69,65,62][(cur[key]+j)%14]
     if r1 and key=='L':p+=(-2 if k%2==0 else 1)
     if r2 and key=='C':p=[81,77,76,79,74,77,82,81,76,77,74,72][(cur[key]+j)%12]
     if r2 and key=='A':p+=(-12 if k==0 else 2 if k%3==1 else 0)
     p=fit(p,lo,hi)
     # Preserve each authored contour, but give sentence attacks/endings explicit
     # harmonic footing. Middle notes remain passing/neighbor motion.
     if k==0 or k==len(cells)-1:
      candidates=[x for x in range(lo,hi+1) if x%12 in {z%12 for z in H[h]}]
      p=min(candidates,key=lambda x:(abs(x-p),x))
     if ID==142 and key=='B' and n==18:p=[55,57][min(k,1)]
     if ID==142 and key=='C' and n==41:p=[72,73][min(k,1)]
     if ID==142 and key=='B' and n==54:p=[57,55][min(k,1)]
     if ID==143 and key=='B' and n==8:p=[67,65,69][min(k,2)]
     if ID==143 and key=='C' and n==31:p=[79,78,81][min(k,2)]
     if ID==143 and key=='B' and n==61:p=[63,62,65][min(k,2)]
     vv=s['dyn']+([3,-3,1,-1][k%4])-(20 if key=='L' else 8 if key=='A' else 2 if key=='B' else 0)
     events.append(dict(bar=n,onset=round(start+t,6),duration=round(dur,6),pitch=int(p),velocity=int(max(1,min(127,vv))),instrument=inst,voice=voice,hand=hand,articulation='detached'))
   pedals.append(dict(bar=n,onset=start,controller=64,value=0,instrument='piano'));start+=beats
  phrase_map.append(dict(first_bar=first,last_bar=n,design=s['phrase'],independent_subjects=['north_bed_subject','south_bed_subject']))
 pedals.append(dict(bar=n,onset=start-.01,controller=64,value=0,instrument='piano'))
 return harmonic_finish(nominal_rest_layout(woodwind_breathing(dict(id=ID,title=TITLE,title_zh=TITLE_ZH,version=f'v{level}',bars=bars,events=events,pedals=pedals,total_beats=start,tail_seconds=5,instrument_map=INSTRUMENT_MAP,phrase_map=phrase_map)),level))
