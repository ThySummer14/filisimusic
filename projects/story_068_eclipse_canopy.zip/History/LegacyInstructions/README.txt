缝起日食的人 / The Seamstress of the Eclipse — v3
原创虚构故事，原声钢琴与长笛二重奏，约2分56.8秒。

这是钢琴＋长笛配器，不是小提琴录音。完整包打开068_eclipse_canopy_v3.rpp；两条float32音轨均包含，可在REAPER播放和混音，另有三轨MIDI及JSON谱面。自包含的是音频轨播放工程；改音符需外部音源。轻房间使用REAPER自带ReaVerbate，本Linux7.82回开导出经过核验；其他平台可能需重新匹配插件，不保证跨平台PCM一致。输出在Renders/。

重建顺序：Score/compose.py生成原始v0/v1/v2；Score/prepare_performance.py用逐音mapping_manifest.json生成最终v3；Score/export_midi.py导出MIDI。原v2长笛onset表示目标有音高到达，最终ensemble_score.json、flute_score.json和MIDI已经按实测气头提前触发，不要重复补偿。五个门限为避免前一音释放重叠而缩短，最大约71.264ms，均在对齐记录中保留原note-off与实际note-off。最长实际门控1.40349秒，最小门控间隙0.14秒。原生长笛总线含房间尾响的最短句间低电平区约0.69秒（−80dBFS、10ms RMS阈值）；技术阈值不等于人耳判断。

见REGENERATING_NOTES.txt设置SFIZZ_LIBRARY和外部SFZ路径。Tools/render_score_sfizz.py分别读取piano_score.json（Moonlight推荐SFZ，加--enable-details）和flute_score.json（Iowa_flute_vibrato_C5_B5_two_layers.sfz）；写到Media/piano_float32.wav、Media/flute_float32.wav。草稿README与审计保存非音频阶段历史，最终状态以本说明及metadata为准。

钢琴：Moonlight-SalamanderV6.2，Alexander Holm录音，Chisato Yamauchi/Accurate-Salamander重制，Hiroharu Narikawa等调律，CC BY3.0 https://creativecommons.org/licenses/by/3.0/ 。官方 https://www.ir.isas.jaxa.jp/~cyamauch/AccurateSalamander/ 。原README、版本hash随包。
长笛：University of Iowa MIS，Sonja Feig于2000年4月演奏，Lawrence Fritts主持，John Ritz与Michael Cash录音。来源 https://theremin.music.uiowa.edu/MISflute.html ，官方许可 https://theremin.music.uiowa.edu/MIS.html 允许用于任何项目，不另称CC0。原始16bit44.1kHzmono，真实pp/mf层，保留颤音与气头；没有真连奏、循环延音或ff录音层。float32轨和24bit母带不增加原始录音精度。

两次实质作曲修改改变了对话、抉择、回归与结尾；第三轮为逐音气头和释放间隔修订。保持一个前景，钢琴主奏时长笛让开，长笛主奏时钢琴只支持同一和声。没有声称人工听审或现场真人合奏。
