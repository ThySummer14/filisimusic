from pathlib import Path
import json
P=Path(__file__).parent;d=json.loads((P/'revisions/score_v2.json').read_text());changes=[]
for b in d['bars']:
 if b['role_plan']=='cold' and b['harmony_name']=='E7':
  b['harmony_name']='A7';b['harmony']=[45,55,61]
  for e in d['events']:
   if e['bar']!=b['bar']:continue
   if e['voice']=='bass':e['pitch']=45
   elif e['voice']=='accompaniment':e['pitch']={56:55,59:61}[e['pitch']]
   elif e['pitch']==68:e['pitch']=67
  for e in d['events']:
   if e['bar']==b['bar'] and e['voice']=='accompaniment' and e['pitch']==61 and e['onset']-b['start']==2:e['pitch']=57
  changes.append(b['bar'])
# Give the final answer an actual held middle-voice resolution at the same onset.
b=d['bars'][-1]
for n in [54,57]:d['events'].append(dict(bar=b['bar'],onset=b['start'],duration=2.4,pitch=n,velocity=39,voice='accompaniment'))
# Bass octave moved up only for final chord so the left-hand span is a tenth, not a large stretch.
for e in d['events']:
 if e['bar']==b['bar'] and e['voice']=='bass':e['pitch']=50;e['duration']=2.4
# Final left-hand50,54,57 is compact; melody74 is right hand.
d['stage']='v3_dominant_resolution_and_shared_last_chord';d['events'].sort(key=lambda e:(e['onset'],e['pitch']))
for f in ['score.json','revisions/score_v3.json']:(P/f).write_text(json.dumps(d,indent=2))
(P/'revisions/pass3.json').write_text(json.dumps({'round':3,'kind':'substantive_harmonic_and_ending_revision','changes':['Cold-stanza bars20/28 previously paired anE7 accompaniment withC-sharp-directed melody. Replace withA7 andG-natural dominant seventh so both voices resolve together toDminor.','Add a soft sharedD-major middle-voice resolution on the final melodic arrival; move final bass toD3 to keep left-hand notes50/54/57 within a fifth. The last chord belongs to both hands rather than an isolated high note.'],'same_key_conflicts_corrected':2,'changed_dominant_bars':changes,'human_listening_review':False},indent=2));print(changes)
