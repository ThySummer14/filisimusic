import pathlib,json,struct
P=pathlib.Path(__file__).parent;d=json.loads((P/'ensemble_score.json').read_text());ppq=960

def vlq(v):
 a=[v&127];v>>=7
 while v:a.insert(0,128|(v&127));v>>=7
 return bytes(a)
def trk(ev):
 out=bytearray();last=0
 for t,order,data in sorted(ev,key=lambda x:(x[0],x[1])):out+=vlq(t-last)+data;last=t
 return b'MTrk'+struct.pack('>I',len(out))+out
end=round((d['total_beats']+d['tail_seconds']*d['bars'][-1]['bpm']/60+1)*ppq);meta=[];last=None;previous_meter=None
for b in d['bars']:
 tick=round(b['start']*ppq);meter=(b['meter_numerator'],b['meter_denominator'])
 if meter!=previous_meter:meta.append((tick,0,b'\xff\x58\x04'+bytes([meter[0],meter[1].bit_length()-1,36 if meter[1]==8 and meter[0] in(3,6,9,12) else 24,8])));previous_meter=meter
 meta.append((tick,0,b'\xff\x51\x03'+round(60000000/b['bpm']).to_bytes(3,'big')))
 if b['section']!=last:
  s=b['section'].encode();meta.append((tick,1,b'\xff\x06'+vlq(len(s))+s));last=b['section']
meta.append((end,9,b'\xff\x2f\x00'));tracks=[trk(meta)]
for channel,instrument,program in [(0,'piano',0),(1,'clarinet',71)]:
 name=({'clarinet':'Clarinet: changing lead and support','piano':'Piano: shared lead and harmony','flute':'Flute: breath-separated lead','cello':'Cello: one mf pizzicato layer'}[instrument]).encode();ev=[(0,0,b'\xff\x03'+vlq(len(name))+name),(0,1,bytes([0xc0+channel,program]))]
 for e in d['events']:
  if e['instrument']!=instrument:continue
  ev.extend([(round(e['onset']*ppq),3,bytes([0x90+channel,e['pitch'],e['velocity']])),(round((e['onset']+e['duration'])*ppq),1,bytes([0x80+channel,e['pitch'],0]))])
 if instrument=='piano':
  for e in d['pedals']:ev.append((round(e['onset']*ppq),2,bytes([0xb0+channel,64,e['value']])))
  for cc,v in[(20,62),(21,20),(22,18),(23,50)]:ev.append((0,1,bytes([0xb0+channel,cc,v])))
 ev.extend([(end-1,8,bytes([0xb0+channel,64,0])),(end,9,b'\xff\x2f\x00')]);tracks.append(trk(ev))
(P/'117_half_open_blue_door.mid').write_bytes(b'MThd'+struct.pack('>IHHH',6,1,len(tracks),ppq)+b''.join(tracks));print('Original piano and clarinet MIDI with 6/4 broad portrait tempo map')
