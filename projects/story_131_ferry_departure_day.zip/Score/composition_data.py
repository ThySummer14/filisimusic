from copy import deepcopy

def pitch(s):
 return 12*(int(s[-1])+1)+{'C':0,'D':2,'E':4,'F':5,'G':7,'A':9,'B':11}[s[0]]+s[1:-1].count('#')-s[1:-1].count('b')
def decode(line):
 result=[];t=0
 for token in line.split():
  name,units=token.split(':');dur=float(units)/2
  if name!='R':result.append((pitch(name),t,dur))
  t+=dur
 return result,t
class Writer:
 def __init__(self):self.bars=[];self.events=[];self.pedals=[];self.start=0;self.n=0
 def bar(self,name,bpm,beats,h,ch):
  self.n+=1;self.beats=beats;self.bpm=bpm;self.ch=ch
  numerator,denominator=(int(beats*2),8) if beats in (2.5,3.5) else ((6,8) if METER=='6/8' else (int(beats),4))
  self.bars.append(dict(bar=self.n,start=self.start,beats=beats,bpm=bpm,meter_numerator=numerator,meter_denominator=denominator,section=name,harmony_name=h,harmony=ch))
 def add(self,p,t,d,v=72,inst='piano',voice='theme',hand='right',art='detached'):
  if d>0 and t<self.beats:
   self.events.append(dict(bar=self.n,onset=round(self.start+t,6),duration=round(min(d,self.beats-t),6),pitch=int(p),velocity=max(1,min(127,int(v))),instrument=inst,voice=voice,hand=hand if inst=='piano' else 'none',articulation=art))
 def line(self,line,v=80,hand='right',transpose=0):
  notes,total=decode(line);assert abs(total-self.beats)<1e-7,(self.n,total,self.beats,line)
  for p,t,d in notes:self.add(p+transpose,t,max(.11,d-.09),v+(3 if t==0 else 0),hand=hand)
  return notes
 def release(self,amount=0,length=.7):
  self.pedals.append(dict(bar=self.n,onset=self.start,controller=64,value=0,instrument='piano'))
  if amount:
   self.pedals.extend([dict(bar=self.n,onset=self.start+.05,controller=64,value=amount,instrument='piano'),dict(bar=self.n,onset=self.start+length,controller=64,value=0,instrument='piano')])
  self.start+=self.beats
 def result(self,level):
  self.pedals.append(dict(bar=self.n,onset=self.start-.01,controller=64,value=0,instrument='piano'))
  return dict(id=ID,title=TITLE,title_zh=TITLE_ZH,version=f'v{level}',bars=self.bars,events=self.events,pedals=self.pedals,total_beats=self.start,tail_seconds=5,instrument_map=INSTRUMENT_MAP)
def material(level):
 n=0
 for section,bpm,beats,texture,hs,phrase_names in BLOCKS:
  lines=[]
  for pn in phrase_names.split():lines+=P[pn].split('|')
  harmonies=hs.split();assert len(lines)==len(harmonies),(section,len(lines),len(harmonies))
  for h,line in zip(harmonies,lines):
   n+=1
   for lv,rev in [(1,REV1),(2,REV2)]:
    if level>=lv and n in rev:h,line=rev[n]
   yield n,section,bpm,beats,texture,h,line
ID=131;TITLE='Ferry Departure Day';TITLE_ZH='渡轮复航日';METER='4/4';INSTRUMENT_MAP={'piano':'piano'}
RENDERER_NOTES='Solo piano, bright public celebration. Bars25–40 are 3/4; the rest 4/4. Broad late plateau and a clean emphatic cadence, no fade-out.'
H={'A':[45,52,61],'D':[38,54,57],'E':[40,56,59],'F#m':[42,54,61],'Bm':[47,54,62],'E7':[40,56,62],'A/C#':[37,52,57],'B7':[47,57,63],'F#7':[42,58,61],'Dmaj7':[38,54,61],'C#7':[37,53,59],'Asus':[45,50,57]}
P={
'flags':'A5:2 C#6:1 B5:1 A5:1 E5:1 C#5:2|F#5:1 A5:1 D6:2 C#6:1 A5:1 F#5:2|G#5:2 B5:1 E6:1 D6:1 B5:1 G#5:2|A5:2 E5:1 C#5:1 A4:2 R:2',
'cheer':'C#6:1 E6:1 A6:2 G#6:1 E6:1 C#6:2|D6:1 C#6:1 A5:2 F#5:1 E5:1 D5:2|B5:1 G#5:1 E5:1 G#5:1 B5:2 D6:2|C#6:2 A5:1 E5:1 A5:2 R:2',
'board':'E5:1 A5:1 C#6:1 B5:1 A5:2 E5:2|D5:1 F#5:1 A5:1 B5:1 A5:2 F#5:2|E5:1 G#5:1 B5:1 C#6:1 B5:2 G#5:2|A5:1 C#6:1 E6:2 C#6:1 A5:1 E5:2',
'rope':'F#5:2 C#5:1 A4:1 C#5:2|B4:2 D5:1 F#5:1 A5:2|G#5:1 B5:1 E6:2 D6:2|C#6:2 A5:1 E5:1 R:2',
'rope2':'F#5:1 A5:1 D6:2 C#6:2|E5:1 G#5:1 B5:2 A5:2|D5:2 F#5:1 B5:1 A5:2|G#5:2 E5:2 R:2',
'wake':'A5:1 E5:1 C#5:1 E5:1 A5:1 C#6:1 E6:2|F#5:1 A5:1 C#6:1 F#6:1 E6:1 C#6:1 A5:2|D6:1 A5:1 F#5:1 A5:1 D6:1 E6:1 F#6:2|E6:1 B5:1 G#5:1 B5:1 D6:1 E6:1 G#6:2',
'wide':'C#6:2 B5:1 A5:1 E5:2 A5:2|D6:2 C#6:1 A5:1 F#5:2 A5:2|B5:2 A5:1 F#5:1 D#5:2 F#5:2|G#5:2 B5:1 D6:1 E6:2 R:2',
'roof':'A6:2 E6:1 C#6:1 A5:1 B5:1 C#6:2|F#6:2 D6:1 A5:1 F#5:1 G#5:1 A5:2|B5:1 D#6:1 F#6:2 E6:1 D#6:1 B5:2|E6:2 D6:1 B5:1 G#5:1 E5:1 D5:2',
'far':'C#6:2 A5:1 E5:1 C#5:1 E5:1 A5:2|C#6:2 A5:1 F#5:1 C#5:1 F#5:1 A5:2|D6:2 B5:1 F#5:1 D5:1 F#5:1 B5:2|B5:2 G#5:1 E5:1 D5:2 R:2',
'end':'A5:2 E5:1 C#5:1 A4:2 E5:2|F#5:2 D5:1 A4:1 F#4:2 D5:2|G#5:1 B5:1 E6:2 D6:1 B5:1 G#5:2|A5:1 E5:1 C#5:2 A4:2 R:2'
}
BLOCKS=[
('Flags_already_up',112,4,'fanfare','A D E A A D E7 A','flags cheer'),
('Boarding',122,4,'march','A D E A A D E A','board board'),
('Every_window_open',122,4,'fanfare','A D E A A D E7 A','flags cheer'),
('Last_rope',92,3,'three','F#m Bm E7 A D E Bm E7','rope rope2'),
('Water_between',92,3,'three','F#m Bm E7 A D E Bm E7','rope rope2'),
('Wake_widens',116,4,'wake','A F#m D E7 A D B7 E7','wake wide'),
('Whole_roof_singing',126,4,'plateau','A D B7 E7 A D B7 E7','roof roof'),
('Cross_the_channel',128,4,'plateau','A F#m Bm E7 A D B7 E7','far roof'),
('Shore_behind',116,4,'wake','A F#m D E7 A D B7 E7','wake wide'),
('One_more_cheer',124,4,'fanfare','A D E A A D E7 A','flags cheer'),
('Full_ahead',104,4,'close','A F#m Bm E7 A D E7 A','far end')]
REV1={33:('F#m','A5:1 F#5:1 C#5:2 A4:2'),34:('F#7','A#4:1 C#5:1 F#5:2 E5:2'),35:('Bm','F#5:1 B5:1 D6:2 C#6:2'),36:('E7','B5:2 G#5:1 E5:1 R:2'),37:('A/C#','C#6:1 A5:1 E5:2 C#5:2'),38:('Dmaj7','C#6:1 A5:1 F#5:2 D5:2'),39:('B7','A5:1 F#5:1 D#5:2 B4:2'),40:('E7','G#5:1 B5:1 D6:2 R:2')}
REV2={57:('A','A6:2 E6:1 C#6:1 B5:1 A5:1 E5:2'),58:('C#7','G#5:1 C#6:1 F6:2 E6:1 C#6:1 B5:2'),59:('F#m','C#6:2 A5:1 F#5:1 E5:1 F#5:1 A5:2'),60:('B7','D#6:1 B5:1 A5:2 F#5:1 D#5:1 B4:2'),61:('E7','G#5:1 B5:1 E6:2 D6:1 B5:1 G#5:2'),62:('D','A5:1 F#5:1 D5:2 F#5:1 A5:1 D6:2'),63:('Asus','E6:2 D6:1 A5:1 G5:1 E5:1 D5:2'),64:('E7','G#5:2 B5:1 D6:1 E6:2 R:2')}
def build(level):
 w=Writer()
 for n,section,bpm,beats,style,h,line in material(level):
  ch=H[h];w.bar(section,bpm,beats,h,ch);v={'fanfare':96,'march':84,'three':67,'wake':87,'plateau':101,'close':96}[style];notes=w.line(line,v)
  if style=='three':
   # Single bass followed by a compact two-note upper response; not a waltz boom-chick loop.
   w.add(ch[0],0,.65,v-17,voice='rope_pull',hand='left')
   w.add(ch[1],1.75,.55,v-20,voice='release',hand='left')
   if level>=1 and 33<=n<=40:w.add(ch[2],1.75,.55,v-25,voice='open_water',hand='left')
  elif style=='march':
   for j,t in enumerate([0,1.5,2.5]):w.add(ch[0]+(12 if j==1 else 0),t,.38,v-22,voice='boarding_steps',hand='left')
  elif style=='wake':
   for p,t in [(ch[0],0),(ch[1],1),(ch[2],2),(ch[1],3)]:w.add(p,t,.38,v-22,voice='wake_countersong',hand='left')
  else:
   for t in [0,2]:
    w.add(ch[0],t,.5,v-18,voice='departure_bass',hand='left');w.add(ch[0]+7,t,.5,v-24,voice='open_fifth',hand='left')
   if n%2==0:w.add(ch[1],3.25,.38,v-23,voice='cheer_pickup',hand='left')
   first=next((q for q,t,d in notes if t==0),None)
   if first and style in ('fanfare','plateau','close'):
    lower=next((p for p in range(first-3,first-8,-1) if p%12 in [x%12 for x in ch]),first-5)
    w.add(lower,0,.38,v-16,voice='upper_cheer_harmony',hand='right')
   if level>=2 and 57<=n<=64:
    # Bass answer climbs during the plateau while the upper line turns away from a premature cadence.
    w.add(ch[0]+12,1.2,.4,v-17,voice='plateau_answer',hand='left')
  w.release(38 if style=='three' else (27 if style=='close' and n>84 else 0),1)
 return w.result(level)
