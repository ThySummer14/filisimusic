"""115 slow three-half-note movement with an accented second pulse and independent lower replies."""
from pathlib import Path
import json,sys
P=Path(__file__).resolve().parent;sys.path.insert(0,str(P));from composition_data import *
PARAM={'morning':('河面还很低',76,41),'crossings':('一趟接一趟',88,60),'current':('水流把绳拉紧',104,79),'ridge':('最后一趟渡河',116,94),'shore':('收绳以后',84,48)}
def write(p,x):p.write_text(json.dumps(x,ensure_ascii=False,separators=(',',':'))+'\n')
def pitch(s):return 12*(int(s[-1])+1)+{'C':0,'D':2,'E':4,'F':5,'G':7,'A':9,'B':11}[s[0]]+s[1:-1].count('#')-s[1:-1].count('b')
def build(level):
 rows=[]
 for sec,hs,ls in GROUPS:assert len(hs.split())==len(ls);rows.extend((sec,h,l) for h,l in zip(hs.split(),ls))
 assert len(rows)==54
 bars=[];events=[];pedals=[]
 for n,(sec,h,line) in enumerate(rows,1):
  for lv,rd,hd in [(1,REV1,HREV1),(2,REV2,HREV2)]:
   if level>=lv:line=rd.get(n,line);h=hd.get(n,h)
  label,bpm,dyn=PARAM[sec];ch=H[h];start=(n-1)*6
  if n in [10,22,36,46]:bpm-=4
  if n>=52:bpm-=3*(n-51)
  bars.append(dict(bar=n,start=start,beats=6,bpm=bpm,meter='3/2',meter_numerator=3,meter_denominator=2,section=sec,section_title_zh=label,harmony_name=h,harmony=ch,key_region='Ab/F minor with final F-major sixth',metric_intent='second half-note pulse at quarter2 bears expressive tension, not equal three beats'))
  def add(p,t,d,v,voice,hand):
   assert 0<=t<t+d<=6.00001,(n,t,d)
   events.append(dict(bar=n,onset=round(start+t,6),duration=round(d,6),pitch=p,velocity=int(v),instrument='piano',voice=voice,hand=hand))
  at=0;mel=[]
  for i,tok in enumerate(line.split()):
   name,u=tok.split(':');dur=float(u)/2
   if name!='R':
    p=pitch(name);mel.append(p);add(p,at,dur-.09,dyn+(6 if at==2 else 0)-(4 if i==len(line.split())-1 else 0),'river_line','right')
   at+=dur
  assert at==6
  root=ch[0];middle=ch[2];inner=[ch[1]+12,ch[2]+12]
  while max(inner)>=min(mel):inner=[p-12 for p in inner]
  while middle>=min(mel):middle-=12
  add(root,0,1.5 if sec in ['morning','shore'] else 1.25,dyn-18,'first_ground','left')
  if sec in ['morning','shore']:
   add(middle,2,.85,dyn-17,'second_pulse_answer','left')
   if n%2 and n not in [9,53]:add(inner[0],4,.7,dyn-24,'last_soft_reply','left')
  else:
   middle_time=2.0;inner_times=[3.25,5.0]
   if level>=1 and 23<=n<=30:middle_time=2.15;inner_times=[3.5,5.1]
   if level>=2 and 39<=n<=46:middle_time=2.0;inner_times=[3.4,4.75]
   add(middle,middle_time,.70,dyn-17,'second_pulse_answer','left')
   for t,p in zip(inner_times,inner):add(p,t,.60,dyn-24,'independent_lower_reply','left')
  if n in [10,22,30,36,45,46,53]:
   # A notated breath also removes the late supporting line.
   events[:]=[e for e in events if not(e['bar']==n and e['hand']=='left' and e['onset']>=start+3)]
  pedals.extend([dict(bar=n,onset=start,controller=64,value=0,instrument='piano'),dict(bar=n,onset=start+.06,controller=64,value=29 if sec in ['morning','shore'] else 22,instrument='piano'),dict(bar=n,onset=start+1.85,controller=64,value=0,instrument='piano'),dict(bar=n,onset=start+2.08,controller=64,value=26,instrument='piano'),dict(bar=n,onset=start+3.0,controller=64,value=0,instrument='piano'),dict(bar=n,onset=start+4.05,controller=64,value=22,instrument='piano'),dict(bar=n,onset=start+5.8,controller=64,value=0,instrument='piano')])
 events.sort(key=lambda e:(e['onset'],e['pitch']))
 for i,e in enumerate(events):e['event_id']=f'115-v{level}-{i}'
 return dict(id=115,title='The Ferry Rope by the River',title_zh='河边的摆渡绳',version=f'v{level}',bars=bars,events=events,pedals=pedals,total_beats=324,tail_seconds=5,instrument_map={'piano':'piano'},performance_contract='Original through-composed acoustic piano movement using sarabande-like second-pulse tension; not a quoted historical dance or live performance.')
def proj(d,n):return {'bar':d['bars'][n-1],'events':[{k:v for k,v in e.items() if k!='event_id'} for e in d['events'] if e['bar']==n],'pedals':[e for e in d['pedals'] if e['bar']==n]}
for v in range(3):
 d=build(v);write(P/f'score_v{v}.json',d);report={'version':f'v{v}','bars':54,'events':len(d['events']),'duration_seconds':sum(b['beats']*60/b['bpm'] for b in d['bars'])+5,'human_listening_review':False};write(P/f'audit_v{v}.json',report)
 if v:
  a=build(v-1);changes=[{'bar':n,'before':proj(a,n),'after':proj(d,n)} for n in range(1,55) if proj(a,n)!=proj(d,n)];write(P/f'exact_diff_v{v-1}_to_v{v}.json',{'count':len(changes),'changed_bars':[x['bar'] for x in changes],'comparison_excludes':['version','event_id'],'changes':changes});text=[]
  for x in changes:
   text.append(f"BAR {x['bar']}\n")
   for side in ['before','after']:
    q=x[side];text.append(side+' '+q['bar']['harmony_name']+' '+str([(e['voice'],e['hand'],e['onset'],e['pitch'],e['duration'],e['velocity']) for e in q['events']])+'\n')
  (P/f'exact_diff_v{v-1}_to_v{v}.patch').write_text(''.join(text))
for name in ['score.json','ensemble_score.json','piano_score.json']:write(P/name,d)
print(json.dumps(report))
