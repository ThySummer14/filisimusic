#!/usr/bin/env python3
"""Create lossless PCM WAV crops and an explicitly two-layer non-looping SFZ.

Uses only the Python standard library. No renderer, normalizer, resampler,
software installation, network request, sustain loop, or generated note audio.
"""
import os, resource
resource.setrlimit(resource.RLIMIT_AS,(150*1024**2,150*1024**2))
resource.setrlimit(resource.RLIMIT_CPU,(90,90))
if hasattr(os,'sched_getaffinity'):
    os.sched_setaffinity(0,{min(os.sched_getaffinity(0))})
import aifc, hashlib, json, math, pathlib, time, wave
P=pathlib.Path(__file__).resolve().parent
SFZ_NAME='Iowa_flute_vibrato_C5_B5_two_layers.sfz'

def main():
    start=time.monotonic()
    analysis=json.loads((P/'scale_analysis.json').read_text())
    (P/'Samples').mkdir(exist_ok=True)
    rows=[]
    sfz=['// University of Iowa MIS; Sonja Feig, flute with recorded vibrato, April 2000.',
         '// Source permission: https://theremin.music.uiowa.edu/MIS.html ; not CC0.',
         '// Two genuine mono recorded layers: pp and mf only. C5–B5 = MIDI 72–83.',
         '// pp canonical velocities 21–55, extended to 1–20; mf canonical 56–95, extended to 96–127.',
         '// Edge velocities are playback extensions, not extra dynamics. No ff layer.',
         '// Exact source PCM crops; tune adjusts playback only. Natural vibrato and breath remain.',
         '// No recorded legato, dedicated release trigger, round robins, sustain loops, or notes outside range.',
         '<global> ampeg_attack=0.002 ampeg_release=0.12 loop_mode=no_loop amp_veltrack=35']
    for layer in analysis['layers']:
        f=P/layer['source_file']
        assert hashlib.sha256(f.read_bytes()).hexdigest()==layer['sha256']
        with aifc.open(str(f),'rb') as a:
            assert a.getsampwidth()==2 and a.getnchannels()==1 and a.getframerate()==44100
            raw=a.readframes(a.getnframes()); sr=a.getframerate()
        low,high=(1,55) if layer['layer']=='pp' else (56,127)
        sfz.append(f'<group> lovel={low} hivel={high}')
        for note in layer['notes']:
            lo,hi=note['crop_start_frame'],note['crop_end_frame']
            source=raw[lo*2:hi*2]
            little=bytearray(len(source))
            little[0::2]=source[1::2]; little[1::2]=source[0::2]
            name=f"flute_vib_{layer['layer']}_{note['midi']}_{note['name']}.wav"
            out=P/'Samples'/name
            with wave.open(str(out),'wb') as w:
                w.setnchannels(1); w.setsampwidth(2); w.setframerate(sr); w.writeframes(little)
            # Re-read the actual written WAV and compare every original PCM byte
            # after the mandatory container-endian swap, not a numerical tolerance.
            with wave.open(str(out),'rb') as w:
                assert (w.getnchannels(),w.getsampwidth(),w.getframerate(),w.getnframes())==(1,2,sr,hi-lo)
                written=w.readframes(w.getnframes())
            back=bytearray(len(written)); back[0::2]=written[1::2];back[1::2]=written[0::2]
            assert bytes(back)==source,'Lossless crop verification failed'
            tune=note['tune_cents']; ratio=2**(tune/1200)
            sfz.append(f"<region> key={note['midi']} pitch_keycenter={note['midi']} tune={tune:.2f} sample=Samples/{name}")
            rows.append({'layer':layer['layer'],'midi':note['midi'],'note':note['name'],
                         'source':f.name,'source_sha256':layer['sha256'],
                         'source_start_frame_inclusive':lo,'source_end_frame_exclusive':hi,
                         'derived_file':'Samples/'+name,'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),
                         'source_pcm_sha256':hashlib.sha256(source).hexdigest(),
                         'lossless_pcm_verified':True,'sample_rate':sr,'channels':1,'bits':16,
                         'frames':hi-lo,'duration_seconds':(hi-lo)/sr,
                         'playback_duration_after_tuning_seconds':(hi-lo)/sr/ratio,
                         'active_body_seconds':note['active_seconds'],
                         'active_body_after_tuning_seconds':note['active_seconds']/ratio,
                         'voiced_onset_delay_after_tuning_seconds':(note['active_start_frame']-lo)/sr/ratio,
                         'pre_low_threshold_onset_seconds':note['pre_onset_seconds'],
                         'post_low_threshold_tail_seconds':note['post_tail_seconds'],
                         'tune_cents':tune,'window_center_spread_cents':note['window_center_spread_cents'],
                         'measured_vibrato_and_drift_peak_to_peak_cents':note['measured_vibrato_and_drift_peak_to_peak_cents'],
                         'velocity_range':[low,high],'original_body_rms':note['body_rms']})
    shortest=min(rows,key=lambda x:x['active_body_after_tuning_seconds'])
    safe=math.floor((shortest['active_body_after_tuning_seconds']-.20)*20)/20
    sfz.insert(7,f'// Conservative maximum written held-note duration: {safe:.2f} s. Shorter breath-separated phrases recommended.')
    (P/SFZ_NAME).write_text('\n'.join(sfz)+'\n')
    assert len(rows)==24 and all(x['lossless_pcm_verified'] for x in rows)
    assert set(x['midi'] for x in rows)==set(range(72,84))
    manifest={'instrument':'University of Iowa flute, recorded vibrato, pp/mf, C5–B5',
              'sfz':SFZ_NAME,'genuine_recorded_layers':['pp','mf'],
              'canonical_velocity_ranges':{'pp':[21,55],'mf':[56,95]},
              'implemented_velocity_ranges':{'pp':[1,55],'mf':[56,127]},
              'edge_velocity_disclosure':'Velocities 1–20 reuse pp; 96–127 reuse mf. These are not extra recorded dynamics or ff samples.',
              'operations':'Exact integer-PCM source crops, big-endian AIFF to little-endian WAV; no normalization, resampling, denoising, fades or other audio edits. SFZ adds a short 2 ms attack/120 ms release envelope and small constant playback tuning; no loops.',
              'tuning_disclosure':'Per-note centering from three independently checked stable voiced windows. Natural vibrato and intra-note drift remain. This is not perfect intonation or flattened vibrato.',
              'articulation_limits':'One recorded take per note per dynamic. Source is vibrato flute with audible natural breath/attack. No true sampled legato, release-trigger samples, round robins, sustain loops or pitches outside MIDI 72–83.',
              'recommended_max_note_seconds':safe,
              'duration_basis':{'shortest_active_sample':shortest['derived_file'],
                                'original_active_body_seconds':shortest['active_body_seconds'],
                                'tuning_adjusted_active_body_seconds':shortest['active_body_after_tuning_seconds'],
                                'guard_seconds':.20,'round_down_step_seconds':.05,
                                'reason':'Use shortest measured voiced body after playback tuning, subtract a 200 ms guard (larger than the release envelope), and round down. Do not hold notes indefinitely; files are not looped.'},
              'min_crop_seconds':min(x['duration_seconds'] for x in rows),
              'max_crop_seconds':max(x['duration_seconds'] for x in rows),
              'max_abs_tuning_cents':max(abs(x['tune_cents']) for x in rows),
              'max_window_center_spread_cents':max(x['window_center_spread_cents'] for x in rows),
              'max_measured_vibrato_and_drift_peak_to_peak_cents':max(x['measured_vibrato_and_drift_peak_to_peak_cents'] for x in rows),
              'voiced_onset_delay_seconds_range':[min(x['voiced_onset_delay_after_tuning_seconds'] for x in rows),max(x['voiced_onset_delay_after_tuning_seconds'] for x in rows)],
              'files':rows}
    (P/'mapping_manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
    verify={'lossless_crops_verified':len(rows),'sources_unchanged':True,
            'render_test_status':'Not performed by source-preparation worker; authorized parent owns all audio rendering.',
            'sfz':SFZ_NAME,'sfz_sha256':hashlib.sha256((P/SFZ_NAME).read_bytes()).hexdigest(),
            'derived_wav_bytes':sum((P/x['derived_file']).stat().st_size for x in rows),
            'elapsed_seconds':time.monotonic()-start,'peak_rss_mib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss/1024}
    (P/'build_verification.json').write_text(json.dumps(verify,indent=2)+'\n')
    print(json.dumps({k:v for k,v in manifest.items() if k not in ['files']},indent=2))
    print(json.dumps(verify,indent=2))

if __name__=='__main__': main()
