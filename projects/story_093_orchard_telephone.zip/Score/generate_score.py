#!/usr/bin/env python3
"""Original work 093. Deterministic standard-library symbolic score only.
The three-quarter bar is exactly three absolute quarter-note beats.
"""
import argparse
import difflib
import hashlib
import json
from pathlib import Path
ROOT=Path(__file__).resolve().parent
PCS={'C':0,'D':2,'E':4,'F':5,'G':7,'A':9,'B':11}
def pitch(s):return 12*(int(s[-1])+1)+PCS[s[0]]+s[1:-1].count('#')-s[1:-1].count('b')
def line(text):
    notes=[(pitch(x.split(':')[0]),float(x.split(':')[1])) for x in text.split()]
    assert sum(w for _,w in notes)==3,text
    return notes
# Individually authored three-beat sentences. A falling third, a semitone
# leaning back, and a delayed answer supply the call figure; no beep imitation.
MELODY=[
 'C5:1.5 Ab4:.5 G4:.5 Ab4:.5',
 'Bb4:1 C5:.5 Db5:.5 C5:1',
 'Ab4:.5 F4:.5 G4:1 Ab4:.5 Bb4:.5',
 'G4:1 E4:.5 F4:.5 G4:1',
 'C5:1 Ab4:.5 G4:.5 F4:1',
 'Ab4:1 Bb4:.5 C5:.5 Ab4:1',
 'G4:.5 Ab4:.5 Bb4:1 Ab4:.5 G4:.5',
 'E4:1 G4:.5 Bb4:.5 C5:1',
 'C5:1.5 Ab4:.5 Bb4:.5 C5:.5',
 'Db5:1 C5:.5 Bb4:.5 Ab4:1',
 'Bb4:1 Ab4:.5 G4:.5 F4:1',
 'G4:.5 E4:.5 F4:.5 G4:.5 Bb4:1',
 'C5:1 Ab4:.5 F4:.5 Ab4:1',
 'Bb4:.5 Db5:.5 C5:1 Bb4:.5 Ab4:.5',
 'G4:1 Bb4:.5 Ab4:.5 G4:1',
 'F4:1 Ab4:.5 G4:.5 F4:1',
 'Ab4:1.5 C5:.5 Bb4:.5 Ab4:.5',
 'G4:1 Bb4:.5 C5:.5 Bb4:1',
 'F4:.5 Ab4:.5 C5:1 Bb4:.5 Ab4:.5',
 'G4:1 E4:.5 G4:.5 C5:1',
 'Ab4:1 C5:.5 Db5:.5 C5:1',
 'Bb4:1 Db5:.5 C5:.5 Bb4:1',
 'G4:.5 Ab4:.5 Bb4:1 C5:.5 Bb4:.5',
 'G4:1 Bb4:.5 G4:.5 Eb4:1',
 'C5:1 Eb5:.5 Db5:.5 C5:1',
 'Bb4:1 G4:.5 Ab4:.5 Bb4:1',
 'Ab4:.5 C5:.5 Db5:1 C5:.5 Ab4:.5',
 'G4:1 Bb4:.5 C5:.5 Bb4:1',
 'C5:1.5 Eb5:.5 F5:.5 Eb5:.5',
 'Db5:1 C5:.5 Bb4:.5 Ab4:1',
 'Bb4:.5 C5:.5 Db5:1 Eb5:.5 Db5:.5',
 'C5:1 Bb4:.5 Ab4:.5 C5:1',
 'Eb5:1 C5:.5 Bb4:.5 C5:1',
 'Db5:1 F5:.5 Eb5:.5 Db5:1',
 'C5:.5 Eb5:.5 Db5:1 C5:.5 Bb4:.5',
 'Ab4:1 G4:.5 F4:.5 Ab4:1',
 'Bb4:1 Db5:.5 C5:.5 Bb4:1',
 'C5:1 Eb5:.5 Db5:.5 C5:1',
 'Bb4:.5 C5:.5 Db5:1 C5:.5 Bb4:.5',
 'G4:1 Bb4:.5 Ab4:.5 G4:1',
 'Ab4:1 C5:.5 Bb4:.5 Ab4:1',
 'G4:1 Bb4:.5 Ab4:.5 G4:1',
 'F4:.5 Ab4:.5 Bb4:1 Ab4:.5 F4:.5',
 'E4:1 G4:.5 Bb4:.5 G4:1',
 'Ab4:1 C5:.5 Db5:.5 C5:1',
 'Bb4:1 Ab4:.5 G4:.5 F4:1',
 'E4:.5 F4:.5 G4:1 Bb4:.5 G4:.5',
 'G4:1 E4:.5 G4:.5 C5:1',
 'C5:1.5 Ab4:.5 G4:.5 Ab4:.5',
 'Bb4:1 C5:.5 Db5:.5 C5:1',
 'Ab4:1 F4:.5 G4:.5 Ab4:1',
 'G4:1 E4:.5 F4:.5 G4:1',
 'C5:1 Ab4:.5 Bb4:.5 C5:1',
 'Db5:1 C5:.5 Bb4:.5 Ab4:1',
 'G4:.5 Ab4:.5 Bb4:1 Ab4:.5 G4:.5',
 'F4:1 C5:.5 Bb4:.5 Ab4:1',
 'C5:1 Ab4:.5 F4:.5 Ab4:1',
 'Bb4:1 Db5:.5 C5:.5 Bb4:1',
 'Ab4:.5 C5:.5 Bb4:1 Ab4:.5 F4:.5',
 'G4:1 E4:.5 G4:.5 Bb4:1',
 'C5:1.5 Ab4:.5 G4:.5 F4:.5',
 'Ab4:1 Bb4:.5 C5:.5 Bb4:1',
 'G4:1 Bb4:.5 Ab4:.5 G4:1',
 'F4:1 Ab4:.5 G4:.5 F4:1',
 'Ab4:1 F4:.5 G4:.5 Ab4:1',
 'Bb4:1 Ab4:.5 F4:.5 Db4:1',
 'F4:.5 Ab4:.5 G4:1 F4:.5 Eb4:.5',
 'E4:1 G4:.5 Bb4:.5 G4:1',
 'Ab4:1 C5:.5 Ab4:.5 F4:1',
 'Db5:1 C5:.5 Bb4:.5 Ab4:1',
 'G4:1 E4:.5 F4:.5 E4:1',
 'F4:1 Ab4:1 F4:1',
]
HARMONIES={
 'Fm':[41,44,48],'Fm/C':[48,53,56],'Fm/Ab':[44,48,53],
 'Fm7':[41,44,48,51],'Fm(add9)':[41,43,44,48],
 'Ab':[44,48,51],'Ab/C':[48,51,56],'Ab/Eb':[39,44,48],
 'Abmaj7':[44,48,51,55],'Ab6':[44,48,51,53],
 'Db':[49,53,56],'Db/F':[41,44,49],'Db/Ab':[44,49,53],
 'Dbmaj7':[49,53,56,60],'Db6':[49,53,56,58],
 'Bbm':[46,49,53],'Bbm/Db':[49,53,58],'Bbm/F':[41,46,49],
 'Bbm7':[46,49,53,56], 'Bbm6':[46,49,53,55],
 'Eb':[39,43,46],'Eb/G':[43,46,51],'Eb/Bb':[46,51,55],
 'Eb7':[39,43,46,49],'Eb7/G':[43,46,49,51],
 'Cm':[48,51,55],'C':[48,52,55],'C7':[48,52,55,58],
 'C7/G':[43,48,52,58],'C7/E':[40,43,48,58],
 'C7sus4':[48,53,55,58],'GhalfDim':[43,46,49,53],
}
# Close the dominant inversions into physical octave-contained grips.
HARMONIES['C7/G']=[43,46,48,52]
HARMONIES['C7/E']=[40,43,46,48]
HARM=[
 'Fm','Db','Bbm','C7','Fm/Ab','Db/F','GhalfDim','C7',
 'Fm/C','Dbmaj7','Bbm7','C7','Fm/Ab','Bbm/Db','C7sus4','Fm',
 'Ab','Eb/G','Fm','C7','Db','Bbm7','Eb7/G','Eb',
 'Ab','Eb/G','Db','Eb7','Ab/C','Db/F','Bbm7','Ab/Eb',
 'Abmaj7','Db','Cm','Fm/Ab','Bbm','Ab/C','Db','C7',
 'Fm','C7/G','Bbm/F','C7/E','Db','GhalfDim','C7sus4','C7',
 'Fm','Db','Bbm','C7','Fm/Ab','Dbmaj7','C7sus4','Fm',
 'Fm/C','Bbm7','Db/F','C7','Fm/Ab','Bbm','C7','Fm',
 'Fm/Ab','Db','Bbm/F','C7','Fm/C','Bbm7','C7','Fm',
]
V1_MELODY={
 25:'C5:1.5 Eb5:.5 Db5:.5 C5:.5',
 26:'Bb4:.5 G4:.5 Ab4:1 Bb4:.5 C5:.5',
 27:'Db5:1 C5:.5 Ab4:.5 F4:1',
 28:'G4:.5 Bb4:.5 Db5:1 C5:.5 Bb4:.5',
 29:'C5:1 Eb5:.5 F5:.5 Eb5:1',
 30:'Db5:.5 F5:.5 Eb5:1 C5:.5 Ab4:.5',
 31:'Bb4:1 Db5:.5 Eb5:.5 F5:1',
 32:'Eb5:1 C5:.5 Bb4:.5 Ab4:1',
 33:'C5:1.5 Eb5:.5 Db5:.5 C5:.5',
 34:'Db5:.5 Eb5:.5 F5:1 Eb5:.5 Db5:.5',
 35:'C5:1 Eb5:.5 G5:.5 F5:1',
 36:'Eb5:.5 Db5:.5 C5:1 Bb4:.5 Ab4:.5',
 37:'Bb4:1.5 Db5:.5 C5:.5 Bb4:.5',
 38:'C5:.5 Eb5:.5 Db5:1 C5:.5 Ab4:.5',
 39:'Db5:1 C5:.5 Bb4:.5 Ab4:1',
 40:'Bb4:.5 Ab4:.5 G4:1 E4:.5 G4:.5',
 41:'Ab4:1.5 C5:.5 Bb4:.5 Ab4:.5',
 42:'G4:.5 Bb4:.5 C5:1 Bb4:.5 G4:.5',
 43:'F4:1 Ab4:.5 Db5:.5 C5:1',
 44:'Bb4:.5 G4:.5 E4:1 G4:.5 Bb4:.5',
 45:'C5:1 Db5:.5 C5:.5 Ab4:1',
 46:'Bb4:.5 Ab4:.5 G4:1 F4:.5 G4:.5',
 47:'Ab4:1 G4:.5 F4:.5 E4:1',
 48:'G4:1 Bb4:.5 Ab4:.5 G4:1',
}
V1_HARM={26:'Eb7/G',27:'Db/F',28:'Eb7/G',29:'Ab6',30:'Dbmaj7',31:'Bbm7',32:'Ab/C',33:'Abmaj7',34:'Db6',35:'Cm',36:'Fm7',37:'Bbm7',38:'Ab/Eb',39:'GhalfDim',40:'C7',41:'Fm/Ab',43:'Bbm/Db',45:'Dbmaj7',46:'GhalfDim',47:'C7sus4'}
V2_MELODY={
 49:'C5:1.5 Ab4:.5 G4:.5 Ab4:.5',
 50:'Bb4:1 Db5:.5 C5:.5 Bb4:1',
 51:'Ab4:.5 Bb4:.5 C5:1 Db5:.5 C5:.5',
 52:'Bb4:1 G4:.5 E4:.5 G4:1',
 53:'C5:1 Ab4:.5 C5:.5 Eb5:1',
 54:'Db5:.5 C5:.5 Bb4:1 Ab4:.5 Bb4:.5',
 55:'C5:1 Bb4:.5 Ab4:.5 G4:1',
 56:'Ab4:1 F4:.5 G4:.5 Ab4:1',
 57:'C5:1.5 Ab4:.5 Bb4:.5 C5:.5',
 58:'Db5:1 F5:.5 Eb5:.5 Db5:1',
 59:'C5:.5 Bb4:.5 Ab4:1 F4:.5 Ab4:.5',
 60:'G4:1 Bb4:.5 C5:.5 Bb4:1',
 61:'Ab4:1 C5:.5 Bb4:.5 Ab4:1',
 62:'Bb4:1 Ab4:.5 F4:.5 Db4:1',
 63:'E4:.5 F4:.5 G4:1 Ab4:.5 G4:.5',
 64:'F4:1 Ab4:.5 C5:.5 Ab4:1',
 65:'Ab4:1.5 F4:.5 E4:.5 F4:.5',
 66:'Bb4:1 Ab4:.5 F4:.5 Db4:1',
 67:'F4:1 Ab4:.5 G4:.5 F4:1',
 68:'E4:1 G4:.5 Bb4:.5 C5:1',
 69:'C5:1 Ab4:.5 G4:.5 F4:1',
 70:'Ab4:1 F4:.5 Db4:.5 F4:1',
 71:'G4:1 E4:.5 F4:.5 E4:1',
 72:'F4:1 Ab4:.5 G4:.5 F4:1',
}
V2_HARM={49:'Fm(add9)',50:'Bbm7',51:'Dbmaj7',52:'C7',53:'Fm7',54:'Bbm/Db',55:'C7sus4',56:'Fm/Ab',57:'Fm/C',58:'Bbm7',59:'Db/F',60:'C7',61:'Fm/Ab',62:'Bbm/Db',63:'C7',64:'Fm/C',65:'Fm/Ab',66:'Db',67:'Bbm/F',68:'C7/E',69:'Fm/C',70:'Bbm/Db',71:'C7',72:'Fm'}
SECTIONS=[(1,16,'A','还连着线的早班','F minor'),(17,24,'A2','把车引向旧渠桥','F minor / E-flat dominant'),(25,40,'B','绕行与装筐','A-flat major / F minor'),(41,48,'D','等最后一句路线','F minor / C dominant'),(49,64,'A3','接通以后写下岔路','F minor'),(65,72,'Coda','把托架留在墙上','F minor')]
LABELS=['抹去号码旁的粉尘','留出听筒的线长','回问车在哪个桥口','在旧纸上划掉北门','沿渠路能过货车','把第二处岔路补进去','空筐靠边让出通道','车头转向南坡','拖车向棚口倒来','把卡在轮下的木楔抽出','再确认一次限高','听完余下半句','铅笔落在新的箭头旁','将漏写的路口接下去','车进棚后继续分筐','托架上摆着散开的螺钉','将卷线放入纸箱','尺子还压着未写完的单子']
TEMPI=[62,63,65,68,70,68,65,63,60]
def dumps(x):return json.dumps(x,ensure_ascii=False,indent=2)+'\n'
def save(root,name,x):(root/name).write_text(dumps(x),encoding='utf-8')
def sec(bars,t):return sum(min(max(t-b['start'],0),b['beats'])*60/b['bpm'] for b in bars)
def fingermap(keys,hand):
    fs={1:[3],2:[1,5],3:[1,3,5],4:[1,2,4,5],5:[1,2,3,4,5]}[len(keys)]
    return dict(zip(keys,fs if hand=='right' else fs[::-1]))
def compose(version):
    ms=list(MELODY);hs=list(HARM)
    for stage in range(1,version+1):
        for n,m in (V1_MELODY if stage==1 else V2_MELODY).items():ms[n-1]=m
        for n,h in (V1_HARM if stage==1 else V2_HARM).items():hs[n-1]=h
    bars=[];events=[];pedals=[];plans=[]
    for n in range(1,73):
        scene=next(s for s in SECTIONS if s[0]<=n<=s[1]);start=float((n-1)*3)
        bpm=TEMPI[(n-1)//8]+[0,1,0,-1][(n-1)%4]
        if n>=69:bpm={69:59,70:58,71:56,72:53}[n]
        chord=HARMONIES[hs[n-1]];m=line(ms[n-1])
        bar={'bar':n,'start':start,'beats':3.0,'bpm':bpm,'meter':'3/4','meter_numerator':3,'meter_denominator':4,
          'section':scene[2],'section_title_zh':scene[3],'harmony_name':hs[n-1],'harmony':chord,'lead_instrument':'piano','lead_hand':'right',
          'key_region':scene[4],'phrase_id':f'P{(n-1)//4+1:02d}','phrase_position':(n-1)%4+1,'metrical_grouping':'1+2',
          'texture':'singing_line_with_turning_inner_support','role_plan':'One cantabile RH line; quiet LH shells contain moving inner chord tones.'}
        bars.append(bar);keysbyhand={'right':sorted({p for p,w in m}),'left':list(chord)}
        maps={h:fingermap(ks,h) for h,ks in keysbyhand.items()}
        for hand,ks in keysbyhand.items():
            assert len(ks)<=5 and max(ks)-min(ks)<=12,(version,n,hand,ks)
            plans.append({'bar':n,'hand':hand,'position_id':f'{hand[0].upper()}-b{n:02d}','range':[min(ks),max(ks)],
              'pitch_finger_map':{str(k):maps[hand][k] for k in ks},'active':True,
              'within_position_method':'Distinct ordered fingers in a single octave-contained grip. Inner notes enter inside already established outer keys.',
              'next_position_method':'Release every physical key before changed grip; pedal resonance is separate.'})
        dyn=[61,64,64,68,72,66,65,61,56][(n-1)//8]
        if n>=69:dyn={69:55,70:53,71:51,72:48}[n]
        def add(hand,voice,offset,gate,p,velocity,written,art):
            ks=keysbyhand[hand]
            events.append({'bar':n,'onset':round(start+offset,6),'duration':round(gate,6),'pitch':p,'velocity':velocity,
              'instrument':'piano','voice':voice,'hand':hand,'role':'lead' if voice=='melody' else 'support',
              'phrase_id':f'P{(n-1)//4+1:02d}_piano','phrase_label':LABELS[(n-1)//4],
              'event_id':f'w93-b{n:02d}-{voice}-{len([e for e in events if e["bar"]==n and e["voice"]==voice])+1:02d}',
              'harmonic_function':'chord_tone' if p%12 in {q%12 for q in chord} else 'melodic_nonchord_tone',
              'written_value_beats':written,'articulation':art,'hand_position_id':f'{hand[0].upper()}-b{n:02d}',
              'hand_position_range':[min(ks),max(ks)],'position_keys':ks,'finger':maps[hand][p],
              'fingering_intent':'Distinct ordered fingers; no hidden thumb crossing, overlapping reuse or finger substitution.'})
        offset=0
        for i,(p,w) in enumerate(m):
            last=i==len(m)-1;release=0 if n==72 and last else .36 if last else .04
            add('right','melody',offset,w-release,p,dyn+[0,2,-1,-2,-3][i%5],w,'cantabile_with_measured_phrase_release')
            offset+=w
        low,high=chord[0],chord[-1];middle=chord[1:-1];sv=dyn-22
        split=n in (4,8,12,20,24,28,40,44,48,52,60,63,68,71)
        if version>=1 and n in (26,30,34,38,42,46):split=True
        if version>=2 and n in (50,54,58,62):split=True
        if n==72:
            for p in (low,high):add('left','harmonic_shell',0,3,p,sv,3,'final_low_tonic_shell')
            for p in middle:add('left','inner_support',1,2,p,sv-4,2,'late_third_under_final_sigh')
        elif split:
            for off,gate in [(0,1.09),(1.5,1.10)]:
                for p in (low,high):add('left','harmonic_shell',off,gate,p,sv+(0 if off==0 else -2),1.5,'two_quiet_harmonic_arrivals')
            for i,p in enumerate(middle):
                off=1.5+.45*i
                add('left','inner_support',off,2.60-off,p,sv-4,3-off,'inner_resolution_inside_second_shell')
        else:
            for p in (low,high):add('left','harmonic_shell',0,2.60,p,sv,3,'sustained_octave_contained_shell')
            if len(middle)==1:
                for off,gate in [(.65,.72),(1.75,.85)]:add('left','inner_support',off,gate,middle[0],sv-4,gate+.04,'quiet_inner_rearticulation')
            else:
                for i,p in enumerate(middle):
                    off=[.65,1.65][i]
                    add('left','inner_support',off,2.60-off,p,sv-4,3-off,'quiet_inner_chord_motion')
        pts=[(0,0),(.08,42),(2.94,0)]
        if split:pts=[(0,0),(.08,39),(1.36,0),(1.58,35),(2.94,0)]
        if n>=65:pts=[(off,min(val,34)) for off,val in pts]
        if n==72:pts=[(0,0),(.08,30),(3,0)]
        for off,val in pts:pedals.append({'bar':n,'onset':round(start+off,6),'controller':64,'value':val,'instrument':'piano'})
    events.sort(key=lambda e:(e['onset'],e['hand'],e['pitch'],e['voice']))
    for e in events:
        e['target_on_beats']=e['onset'];e['target_off_beats']=round(e['onset']+e['duration'],6)
        e['target_on_seconds']=round(sec(bars,e['onset']),6);e['target_off_seconds']=round(sec(bars,e['target_off_beats']),6)
    phrases=[]
    for i,label in enumerate(LABELS):
        pid=f'P{i+1:02d}_piano';es=[e for e in events if e['phrase_id']==pid];a=min(e['onset'] for e in es);b=max(e['target_off_beats'] for e in es)
        phrases.append({'phrase_id':pid,'instrument':'piano','phrase_label':label,'first_bar':i*4+1,'last_bar':i*4+4,'section':bars[i*4]['section'],
          'role':'lead_and_support','layer':'not_applicable','layers_used':[],'roles_used':sorted({e['role'] for e in es}),'voices_used':sorted({e['voice'] for e in es}),
          'target_on_beats':a,'target_off_beats':b,'target_on_seconds':round(sec(bars,a),6),'target_off_seconds':round(sec(bars,b),6),
          'timing_intent':'Four three-quarter bars make one twelve-quarter sentence. Inner LH arrivals support one RH singing foreground.'})
    return {'id':93,'title':'The Orchard’s Last Telephone','title_zh':'果园最后一部电话','version':f'v{version}',
      'instrumentation':['natural_acoustic_piano'],'bars':bars,'events':events,'phrases':phrases,'pedals':pedals,'total_beats':216.0,'tail_seconds':6.0,'hand_position_plan':plans,
      'performance_contract':{'audio_status':'Symbolic only; no audio, DSP, downloads, installations or listening.',
       'beat_unit':'Absolute quarter-note beats. Every 3/4 bar contains exactly three beats; per-bar tempo is quarter-note BPM.',
       'piano_instrument':'Solo natural acoustic piano. Real source quality and audible balance await integration.',
       'maximum_held_span_semitones':12,'same_key_overlaps':'Forbidden across all voices and both hands.',
       'position_transfer_rule':'Maximum of actual held-grip edge and declared position-edge travel; changed grips receive at least 75 ms and travel above four semitones adds 12 ms per semitone after the latest physical key release.',
       'finger_plan':'At most five ordered distinct fingers in an octave-contained position. Sustained support outer keys enclose their inner motion.',
       'pedal':'CC64 is resonance intent only; it cannot substitute for physical key release or hand travel time.',
       'foreground':'Exactly one nonoverlapping RH melody; LH support is at least nineteen velocity units below the quietest melodic attack.',
       'musical_limits':'Symbolic feasibility only; numeric PASS is not listening approval, performer comfort approval or acoustic source-quality acceptance.'}}

def json_patch(a,b,path=''):
    if type(a)!=type(b):return [{'op':'replace','path':path,'value':b}]
    if isinstance(a,dict):
        out=[]
        for key in sorted(a.keys()-b.keys()):out.append({'op':'remove','path':path+'/'+key.replace('~','~0').replace('/','~1')})
        for key in sorted(b):
            sub=path+'/'+key.replace('~','~0').replace('/','~1')
            if key not in a:out.append({'op':'add','path':sub,'value':b[key]})
            else:out.extend(json_patch(a[key],b[key],sub))
        return out
    if a!=b:return [{'op':'replace','path':path,'value':b}]
    return []
def exact_diff(root,a,b):
    sa=json.loads((root/f'score_{a}.json').read_text());sb=json.loads((root/f'score_{b}.json').read_text());changes=[]
    for n in range(1,73):
        row={'bar':n,'before_bar':sa['bars'][n-1],'after_bar':sb['bars'][n-1],
             'before_events':[e for e in sa['events'] if e['bar']==n],'after_events':[e for e in sb['events'] if e['bar']==n],
             'before_pedals':[e for e in sa['pedals'] if e['bar']==n],'after_pedals':[e for e in sb['pedals'] if e['bar']==n]}
        if any(row['before_'+k]!=row['after_'+k] for k in ('bar','events','pedals')):changes.append(row)
    sha=lambda name:hashlib.sha256((root/name).read_bytes()).hexdigest()
    save(root,f'exact_diff_{a}_to_{b}.json',{'from':a,'to':b,'before_sha256':sha(f'score_{a}.json'),'after_sha256':sha(f'score_{b}.json'),
      'changed_bars':[r['bar'] for r in changes],'changes':changes,'phrase_metadata_before':sa['phrases'],'phrase_metadata_after':sb['phrases'],
      'position_plan_before':sa['hand_position_plan'],'position_plan_after':sb['hand_position_plan'],'json_patch':json_patch(sa,sb)})
    patch=''.join(difflib.unified_diff(dumps(sa).splitlines(True),dumps(sb).splitlines(True),fromfile=f'score_{a}.json',tofile=f'score_{b}.json'))
    (root/f'exact_diff_{a}_to_{b}.patch').write_text(patch,encoding='utf-8')
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--outdir',type=Path,default=ROOT);args=ap.parse_args();root=args.outdir.resolve()
    if root!=ROOT and ROOT not in root.parents:raise SystemExit('Output must remain within this isolated work folder.')
    root.mkdir(parents=True,exist_ok=True)
    for v in range(3):save(root,f'score_v{v}.json',compose(v))
    (root/'score.json').write_bytes((root/'score_v2.json').read_bytes())
    for a,b in [('v0','v1'),('v1','v2')]:exact_diff(root,a,b)
    s=compose(2);print(dumps({'selected':'v2','bars':72,'total_beats':216,'duration_with_tail_seconds':round(sec(s['bars'],216)+6,6)}))
if __name__=='__main__':main()
