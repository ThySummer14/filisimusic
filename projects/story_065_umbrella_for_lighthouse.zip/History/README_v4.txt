An Umbrella for the Lighthouse / 给灯塔撑一把伞 — v4
Original fictional narrative and original instrumental composition.
Extent: full_composition.

Open065_umbrella_for_lighthouse_v4.rpp in REAPER. Media/piano_float32.wav is included in the FULL archive, so playback and a new master export need no external instrument. Output goes to relative Renders/. This is an AUDIO-TRACK project, not a self-contained virtual-instrument MIDI project. The MIDI and structured note score are separately editable in Score/.

Regenerating performance from changed notes requires the externally downloaded Moonlight-SalamanderV6.2 bank and official sfizz1.2.3 library, Python3 and NumPy. Set SFIZZ_LIBRARY to libsfizz.so.1. Run Tools/render_score_sfizz.py --score Score/score.json --sfz <bank/sfz_live/Moonlight-SalamanderGrandPiano_treble1.0db.Recommended.sfz> --out Media/piano_float32.wav --enable-details. REAPER then exports the master. The mastering project uses fixed audio timing; the included MIDI carries the composition's tempo and meter map. Cross-platform bit identity is not promised.

Original recordings Alexander Holm; remaster Chisato Yamauchi/Accurate-Salamander; retuning Hiroharu Narikawa and contributors named in the bundled original README. Bank license CC BY3.0: https://creativecommons.org/licenses/by/3.0/ . Source: https://www.ir.isas.jaxa.jp/~cyamauch/AccurateSalamander/ . The shared2GB bank is NOT bundled or copied to a public gallery.

Revisions/ records the actual score/performance/mix corrections and technical checks. The full work has not been represented as human-auditioned. The story is fiction, not lived experience. No reference melody, lyric or recording was copied.
