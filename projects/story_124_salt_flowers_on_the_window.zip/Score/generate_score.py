"""Self-contained deterministic rebuild: python3 generate_score.py. No audio."""
from pathlib import Path
from collections import Counter
import json,hashlib,importlib.util
P=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('composition_data',P/'composition_data.py');d=importlib.util.module_from_spec(spec);spec.loader.exec_module(d)
def write(n,x):(P/n).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def stripped(e):return {k:v for k,v in e.items() if k not in ('event_id','version')}
def canon(x):return json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':'))
scores=[]
for v in range(3):
 s=d.build(v);s['events'].sort(key=lambda x:(x['onset'],x['instrument'],x['pitch']))
 for i,e in enumerate(s['events']):e['event_id']=f'{d.ID}-v{v}-{i:05d}'
 s['performance_contract']='Original nominal score for real sampled acoustic instruments. Recording onset compensation belongs to the renderer. No audio or listening approval is claimed.'
 scores.append(s);write(f'score_v{v}.json',s)
for a,b in ((0,1),(1,2)):
 old,new=scores[a],scores[b];changes=[]
 for n in range(1,len(new['bars'])+1):
  aa=[stripped(e) for e in old['events'] if e['bar']==n];bb=[stripped(e) for e in new['events'] if e['bar']==n]
  if aa!=bb:
   ca,cb=Counter(map(canon,aa)),Counter(map(canon,bb))
   changes.append(dict(bar=n,section=new['bars'][n-1]['section'],before={'bar':old['bars'][n-1],'events':aa},after={'bar':new['bars'][n-1],'events':bb},notes_removed=sum((ca-cb).values()),notes_added=sum((cb-ca).values())))
 write(f'exact_diff_v{a}_to_v{b}.json',dict(changed_bars=[x['bar'] for x in changes],bar_count=len(changes),event_ids_excluded=True,evidence=changes))
(P/'score.json').write_bytes((P/'score_v2.json').read_bytes())
spec=importlib.util.spec_from_file_location('independent_verify',P/'independent_verify.py');v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v);summary=v.run()
ready=dict(id=d.ID,title=d.TITLE,title_zh=d.TITLE_ZH,status='nominal_score_ready',final_score='score_v2.json',self_contained_rebuild='python3 generate_score.py',independent_verification='python3 independent_verify.py',nominal_onsets_no_sample_compensation=True,audio_rendered=False,human_listening_review=False,duration_seconds=summary['versions'][-1]['duration_seconds'],versions=['v0','v1','v2'],actual_revision_changes=[{'from_version':f'v{a}','to_version':f'v{b}','changed_bars':json.loads((P/f'exact_diff_v{a}_to_v{b}.json').read_text())['changed_bars']} for a,b in ((0,1),(1,2))],renderer_notes=d.RENDERER_NOTES)
write('READY_FOR_REVIEW.json',ready)
files=[x for x in P.iterdir() if x.is_file() and x.suffix in ('.py','.json','.txt','.md') and x.name not in ('hashes.json','library_receipt.json','library_roundtrip_verification.json','local_zip_verification.json')]
write('hashes.json',{x.name:hashlib.sha256(x.read_bytes()).hexdigest() for x in sorted(files)})
print(json.dumps(summary,ensure_ascii=False))
