# 098 北风花园

原创虚构故事与钢琴、长笛完整作品。score.json选择完整v2；v0/v1以及精确修订差异保留。全部时间单位为四分音符拍，5/8小节含2.5拍。

generate_score.py保存逐小节原创前景、和声和三版配置。verify_symbolic.py独立读取磁盘，不导入作曲函数，核对实际和声、乐句、真实持键、指号与移手、长笛真实层/范围/名义门长、差分重建和新进程复现。符号稿使用普通触发，尚未重复应用音源起音补偿。

story_zh.txt为纯叙事，虚构性质在此说明。music_notes_zh.md与revision_notes.md保存曲式、发音限制和实际修改。history_revision_criteria留有检查判据的修正记录。最终音频、原生REAPER设置和完整/轻量工程说明以后续正式metadata与交付README为准；符号检查不代表试听通过。
