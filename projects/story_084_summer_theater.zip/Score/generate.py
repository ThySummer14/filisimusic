#!/usr/bin/env python3
"""Deterministic, standard-library-only symbolic composition. No audio or sample access."""
import copy
import hashlib
import json
from collections import Counter, defaultdict
from pathlib import Path

OUT = Path(__file__).resolve().parent
NAMES = {'C':0,'D':2,'E':4,'F':5,'G':7,'A':9,'B':11}

def pitch(s):
    pc = NAMES[s[0]]
    if len(s) == 3: pc += {'b':-1,'#':1}[s[1]]
    return 12*(int(s[-1])+1)+pc

# Bass, bounded upper left-hand support, pitch classes, descriptive harmonic name.
H = {
 'F':       (41,[48,53,57],[5,9,0],'F'),
 'F/A':     (45,[48,53,57],[5,9,0],'F/A'),
 'F/C':     (48,[53,57,60],[5,9,0],'F/C'),
 'F6':      (41,[48,53,57],[5,9,0,2],'F6'),
 'Fmaj7':   (41,[48,52,57],[5,9,0,4],'Fmaj7'),
 'C/E':     (40,[48,52,55],[0,4,7],'C/E'),
 'C':       (48,[52,55,60],[0,4,7],'C'),
 'C7':      (48,[52,55,58],[0,4,7,10],'C7'),
 'C7/G':    (43,[48,52,58],[0,4,7,10],'C7/G'),
 'C7sus':   (48,[53,55,58],[0,5,7,10],'C7sus4'),
 'Bb':      (46,[53,58,62],[10,2,5],'Bb'),
 'Bb/D':    (50,[53,58,62],[10,2,5],'Bb/D'),
 'Bb/F':    (41,[50,53,58],[10,2,5],'Bb/F'),
 'Bbmaj7':  (46,[53,57,62],[10,2,5,9],'Bbmaj7'),
 'Dm':      (50,[53,57,62],[2,5,9],'Dm'),
 'Dm/F':    (41,[50,53,57],[2,5,9],'Dm/F'),
 'Dm/A':    (45,[50,53,57],[2,5,9],'Dm/A'),
 'Dm/C':    (48,[50,53,57],[2,5,9,0],'Dm7/C'),
 'Gm':      (43,[50,55,58],[7,10,2],'Gm'),
 'Gm7':     (43,[50,53,58],[7,10,2,5],'Gm7'),
 'Gm/Bb':   (46,[50,55,58],[7,10,2],'Gm/Bb'),
 'A7':      (45,[52,55,61],[9,1,4,7],'A7'),
 'A7/C#':   (49,[52,55,57],[9,1,4,7],'A7/C#'),
 'Em7b5':   (40,[50,55,58],[4,7,10,2],'Em7b5'),
 'D7':      (50,[54,57,60],[2,6,9,0],'D7'),
 'Eb':      (51,[55,58,63],[3,7,10],'Eb'),
 'F7':      (41,[51,53,57],[5,9,0,3],'F7'),
 'F7/A':    (45,[51,53,57],[5,9,0,3],'F7/A'),
}
RHYTHMS = {
 'a':[.5,.5,.5], 'b':[1,.5], 'c':[.5,1], 'd':[1.5],
 'e':[.25,.25,.5,.5], 'f':[.5,.25,.25,.5],
 'g':[.25]*6, 'h':[.75,.25,.5],
}

def bar(h, notes, rhythm='a'):
    ns = notes.split()
    assert len(ns) == len(RHYTHMS[rhythm]), (notes,rhythm)
    return {'h':h, 'melody':[pitch(n) for n in ns], 'rhythm':rhythm}

def phrase(harmonies, tunes):
    hs = harmonies.split()
    assert len(hs)==len(tunes)==8
    return [bar(h,*t) if isinstance(t,tuple) else bar(h,t) for h,t in zip(hs,tunes)]

# Eighteen authored eight-bar sentences. The identifying gesture is A-C-Bb / G-A,
# followed by F-G-A: an upward third, retreat, and stepwise re-entry into the dance.
FINAL = [
 phrase('F C/E Bb F/A Gm C7 C7 F', [
  'A4 C5 Bb4',('G4 A4','b'),'F4 G4 A4','C5 Bb4 A4',
  'G4 Bb4 A4','E4 G4 C5','Bb4 A4 G4',('F4','d')]),
 phrase('F Dm Bb F/A Gm Dm/A Gm7 C7', [
  'C5 F5 E5','D5 C5 A4','Bb4 D5 C5','A4 C5 F5',
  'D5 Bb4 G4','A4 F4 A4','Bb4 A4 G4',('E5 C5','c')]),
 phrase('F C/E Dm Bb Gm C7 F/C C7', [
  'A4 C5 Bb4','G4 E4 G4',('A4 D5 C5 Bb4','e'),'D5 C5 Bb4',
  'G4 A4 Bb4','C5 Bb4 G4',('A4 G4 F4 A4','e'),('G4','d')]),
 phrase('F C/E Bb F/A Gm C7 C7 F', [
  ('A4 Bb4 C5 Bb4','e'),('G4 A4','b'),
  ('F4 G4 A4 Bb4','e'),'C5 Bb4 A4','G4 Bb4 D5',
  ('E5 D5 C5 Bb4','e'),'G4 C5 E5',('F5 A4','c')]),
 phrase('Dm A7 Dm Dm/C Bb Gm C7 F', [
  'A4 D5 C5','C#5 E5 D5','F5 E5 D5','C5 A4 F4',
  ('D5 C5 Bb4 A4','e'),'Bb4 A4 G4','E5 D5 C5',('A4 F4','c')]),
 phrase('Dm C/E F F/A Bb Gm C7 C7', [
  ('F5 E5 D5 C5','f'),'E5 G5 F5','A5 G5 F5','C6 A5 F5',
  ('D5 F5 E5 D5','e'),'Bb4 D5 C5',('E5 F5 G5 E5','e'),('C5','d')]),
 phrase('Dm A7 Gm Dm/F Em7b5 A7 A7 Dm', [
  'F4 A4 G4',('E4 F4','b'),'D4 E4 F4','A4 G4 F4',
  'E4 G4 Bb4','C#5 Bb4 A4','G4 E4 C#4',('D4 F4','c')]),
 phrase('Dm Dm/C Bb Gm A7/C# Dm Em7b5 A7', [
  ('A4 Bb4 A4 G4','e'),'F4 A4 C5','D5 C5 Bb4','G4 Bb4 D5',
  ('E5 D5 C#5 B4','e'),'A4 F4 D4','E4 G4 Bb4',('C#5 A4','c')]),
 phrase('Dm A7 Dm D7 Gm C7 F7 Bb', [
  'F4 A4 G4',('E4 C#4 E4 G4','e'),'F4 A4 D5','F#5 E5 D5',
  'D5 Bb4 G4','E5 D5 C5','Eb5 C5 A4',('Bb4 D5','c')]),
 phrase('Bb F7/A Eb Bb/D Gm F7 F7 Bb', [
  'D5 F5 Eb5',('C5 D5','b'),'Bb4 C5 D5','F5 Eb5 D5',
  'Bb4 D5 C5','A4 C5 F5','Eb5 D5 C5',('Bb4','d')]),
 phrase('Bb Bbmaj7 Eb Bb/D Gm D7 Gm F7', [
  ('F5 G5 F5 D5','e'),'D5 F5 A5','G5 F5 Eb5',('F5 D5','b'),
  'D5 Bb4 G4','F#4 A4 C5',('Bb4 A4 G4 Bb4','e'),('A4 C5','c')]),
 phrase('Bb F7/A Bb Gm Eb C7 F7 C7', [
  'D5 F5 Eb5','C5 A4 C5','Bb4 D5 F5','G5 F5 D5',
  ('Eb5 F5 G5 F5','e'),'E5 D5 C5','A4 C5 Eb5',('E5 G5','c')]),
 phrase('F C/E Bb F/A Gm C7 C7 F', [
  ('A5 G5 F5 A5','f'),'G5 E5 C5',('F5 E5 D5 F5','f'),
  'C5 F5 A5','Bb5 A5 G5',('E5 F5 G5 A5 Bb5 G5','g'),
  'E5 G5 C6',('A5 F5','c')]),
 phrase('Dm A7 Dm C/E F Bb Gm C7', [
  ('F5 A5 G5 F5','e'),('E5 G5 F5 E5','e'),'D5 F5 A5',
  'G5 E5 C5',('A4 C5 Bb4 A4','e'),'F4 Bb4 D5',
  ('D5 C5 Bb4 A4','f'),('G4 E5','c')]),
 phrase('F C/E Dm Bb Gm C7 Dm C7', [
  ('A4 C5 Bb4','a'),('G4 A4','b'),'F4 A4 D5',
  ('D5 C5 Bb4 A4','e'),'G4 Bb4 D5',('E5 D5 C5 Bb4','e'),
  'A4 F4 D4',('E4 G4','c')]),
 phrase('F C/E Bb F/A Gm C7 C7 F', [
  'A4 C5 Bb4',('G4 A4','b'),'F4 G4 A4',('C5 A4','b'),
  'Bb4 A4 G4','E4 G4 C5',('Bb4 G4','b'),('A4 F4','c')]),
 phrase('F Bb/F F/A Dm Gm C7 F/C C7', [
  ('A4 C5 Bb4 A4','e'),('F4 G4 A4','a'),('C5 A4','b'),
  'A4 F4 D4','G4 A4 Bb4',('C5 Bb4 G4','a'),
  ('A4 G4 F4','a'),('E4 G4','c')]),
 phrase('F6 Bb/F F/A Gm C7sus C7 F F', [
  ('A4 C5 D5','a'),('D5 C5 Bb4','a'),('A4 C5 F5','a'),
  ('D5 Bb4 G4','a'),('F4 G4 Bb4','a'),('E4 G4','b'),
  ('A4 G4 F4','a'),('F4','d')]),
]

SCENES = [
 ('瓷碟里的十八位观众','F major',66,'flow','右手主题；左手三步舞蹈支撑'),
 ('前排正在变矮','F major / D minor foreshadowing',72,'light','右手跳跃与短装饰；左手轻盈但连续'),
 ('把追光撤下来','D minor',66,'urgent','右手主题缩成急促问句；左手低音引导和声'),
 ('舞台移到脚边','Bb major',63,'exchange','主题交给左手；右手窄音程和声回应'),
 ('最后一粒雪的节目单','F major / D minor',71,'fleet','右手主题展开后主动缩短；左手保持舞步'),
 ('落幕以前先鞠躬','F major',59,'bow','回归中声区；左手支持呼吸和最终共同收束'),
]

V0_6 = phrase('F C/E Bb F/A Gm C7 C7 F',[
 'A4 C5 Bb4',('G4 A4','b'),'F4 G4 A4','C5 Bb4 A4',
 'G4 Bb4 A4','E4 G4 C5','Bb4 A4 G4',('F4','d')])
V0_9 = phrase('Dm A7 Gm Dm/F Em7b5 A7 A7 Dm',[
 'F4 A4 G4',('E4 F4','b'),'D4 E4 F4','A4 G4 F4',
 'E4 G4 Bb4','C#5 Bb4 A4','G4 E4 C#4',('D4','d')])
V1_14 = phrase('F C/E Bb F/A Gm C7 C7 F',[
 'A5 C6 Bb5',('G5 A5','b'),'F5 G5 A5','C6 Bb5 A5',
 'G5 Bb5 A5','E5 G5 C6','Bb5 A5 G5',('F5','d')])
V1_15 = phrase('F Dm Bb F/A Gm Dm/A Gm7 C7',[
 'C5 F5 E5','D5 C5 A4','Bb4 D5 C5','A4 C5 F5',
 'D5 Bb4 G4','A4 F4 A4','Bb4 A4 G4',('E5 C5','c')])
V1_17 = copy.deepcopy(FINAL[0])
V1_18 = copy.deepcopy(FINAL[0])

def version_phrases(version):
    phrases = copy.deepcopy(FINAL)
    if version in ('v0','v1'):
        for i,replacement in [(13,V1_14),(14,V1_15),(16,V1_17),(17,V1_18)]:
            phrases[i] = copy.deepcopy(replacement)
    if version == 'v0':
        phrases[5]=copy.deepcopy(V0_6)
        phrases[8]=copy.deepcopy(V0_9)
    return phrases

def melody_hand(scene,version):
    return 'left' if scene==3 and version!='v0' else 'right'

def bpm_for(scene,local,version):
    base=SCENES[scene][2]
    # Phrase breath is small; motion continues through bar lines.
    curve=[-1,0,1,1,2,1,0,-2]
    bpm=base+curve[local%8]
    if scene==2 and local>=16: bpm += 2
    if scene==4 and local>=16 and version=='v2': bpm -= 4
    if scene==5:
        if local<16: bpm -= local//8
        else: bpm=[58,58,57,56,54,51,48,44][local-16]
    return bpm

def high_voicing(h):
    pcs=H[h][2]
    pitches=[p for p in range(69,80) if p%12 in pcs]
    # A compact two-note response, never an imitation of a separate tune.
    return [pitches[0],pitches[-1]] if len(pitches)>1 else pitches

def make_score(version):
    events=[]; bars=[]; pedals=[]; cadence=[]
    phrases=version_phrases(version)
    def event(b,on,d,p,v,voice,hand):
        events.append({'bar':b+1,'onset':round(b*1.5+on,6),'duration':round(d,6),
                       'pitch':p,'velocity':max(20,min(100,int(v))),
                       'voice':voice,'instrument':'piano','hand':hand})
    for phrase_idx,ph in enumerate(phrases):
      scene=phrase_idx//3
      for j,mb in enumerate(ph):
        bi=phrase_idx*8+j; local=bi%24; start=bi*1.5
        h=mb['h']; bass,upper,pcs,label=H[h]
        tempo=bpm_for(scene,local,version)
        leadhand=melody_hand(scene,version)
        section,key,_,style,roles=SCENES[scene]
        if scene==3 and version=='v0': roles='右手高声区主题，左手分解和声；尚未改为脚边演出'
        if bi==95 and version!='v0': roles+='；末个旋律音由右手接过，左手准备下一小节低音'
        bars.append({'bar':bi+1,'start':start,'beats':1.5,'bpm':tempo,
          'section':section,'meter_numerator':3,'meter_denominator':8,
          'harmony_name':label,'harmony':[p for p in range(48,60) if p%12 in pcs],
          'lead_instrument':'piano','role_plan':roles,'key_region':key,
          'phrase_id':phrase_idx+1,'phrase_position':j+1})
        # Velocity contour shapes whole sentences, rather than random note accents.
        contour=[0,1,2,4,5,3,0,-4][j]
        lead_base=[65,68,67,60,71,61][scene]+contour
        if scene==5 and local>=16: lead_base-=int((local-16)*1.3)
        ns=mb['melody']; lengths=RHYTHMS[mb['rhythm']]
        on=0.0
        for ni,(p,ln) in enumerate(zip(ns,lengths)):
            if leadhand=='left': p-=12
            # Short articulations retain dance movement; long notes truly sustain.
            gap=.055 if ln>=.5 else .038
            if scene==1: gap=.09 if ln>=.5 else .052
            if scene==2: gap=.045 if ln>=.5 else .032
            if scene==5 and local>=16: gap=.035
            dur=ln-gap
            # The left-hand scene stays in Bb3-G4, compact enough for every turn.
            actualhand='right' if (leadhand=='left' and bi==95 and ni==len(ns)-1) else leadhand
            event(bi,on,dur,p,lead_base+([1,0,-2,1,-1,-3][ni%6]),'melody',actualhand)
            on+=ln
        support_v=[44,43,46,40,47,40][scene]+contour//2
        if scene==5 and local>=16: support_v-=int((local-16)*.9)
        if leadhand=='left':
            voicing=high_voicing(h)
            # An upper chord on the first eighth and an answering tone on the third.
            # Left-hand theme remains unencumbered by a low bass obligation.
            for p in voicing:event(bi,0,.31,p,support_v,'accompaniment','right')
            event(bi,.5,.31,voicing[0],support_v-3,'accompaniment','right')
            event(bi,1,.31,voicing[-1],support_v-1,'accompaniment','right')
        else:
            # Three changing, harmony-bound supports: one pulse per eighth note.
            # All notes release before transfers; no impossible held low/high spans.
            seq=[bass,upper[0],upper[1]]
            if (scene==1 and local>=8) or (scene==4 and local<16):
                seq=[bass,upper[1],upper[2]]
            if scene==2: seq=[bass,upper[1],upper[0]]
            if scene==5 and local>=16:
                seq=[bass,upper[0],upper[1]]
            for k,p in enumerate(seq):
                dur=.31
                if k==2 and bi<143 and (bi+1)//24!=3:
                    nextbar=phrases[(bi+1)//8][(bi+1)%8]
                    if abs(p-H[nextbar['h']][0])>17:dur=.21
                event(bi,k*.5,dur,p,support_v+([2,-2,0][k]),
                      'bass' if k==0 else 'accompaniment','left')
            # Only phrase arrivals gain a second support note, within an octave.
            # This is intentional weight at a cadence, not a continuous block texture.
            if j==7 and scene!=2:
                p=seq[2]+(3 if (seq[2]+3)%12 in pcs else 4)
                if p%12 in pcs and p<min(ns)-1:
                    event(bi,1,.31,p,support_v-4,'cadence_support','left')
        if bi==143:
            # Last attack belongs to both hands, and physical release precedes pedal lift.
            events=[e for e in events if not (e['bar']==144 and e['hand']=='left')]
            for p in (41,48,53):event(bi,0,1.43,p,35+(p==41)*3,'final_bass','left')
            for p in (69,72):event(bi,0,1.43,p,39,'final_upper','right')
        pedals += [{'onset':start,'value':0},
                   {'onset':round(start+.055,6),'value':76 if (scene==5 and local>=16) else 42},
                   {'onset':round(start+1.43,6),'value':0}]
        if j==7:
            cadence.append({'phrase':phrase_idx+1,'bar':bi+1,'harmony':label,
                            'melody_last_pitch':ns[-1]-(12 if leadhand=='left' else 0),
                            'type':'tonic' if h in ('F','Bb','Dm') else 'open / onward',
                            'last_note_chord_tone':ns[-1]%12 in pcs})
    pedals.append({'onset':216.0,'value':0})
    return {'id':84,'title':'Snow at the Summer Theater','title_zh':'夏日剧场的雪',
            'version':version,'bars':bars,
            'events':sorted(events,key=lambda e:(e['onset'],e['pitch'],e['voice'])),
            'pedals':pedals,'total_beats':216.0,'tail_seconds':6},cadence

def seconds_at(score,beat):
    result=0.0
    for b in score['bars']:
        if beat<=b['start']:break
        result+=min(b['beats'],beat-b['start'])*60/b['bpm']
    return result

def audit(score,cadences):
    es=score['events']; bars=score['bars']; problems=[]
    # Key-held geometry, independent of pedal resonance.
    spans={}; transfers=[]; overlap=[]; crosses=[]
    for hand in ['left','right']:
        ne=[e for e in es if e['hand']==hand]
        maxspan=0; location=None
        for t in sorted(set(e['onset'] for e in ne)):
            sounding=[e for e in ne if e['onset']-1e-7<=t<e['onset']+e['duration']-1e-7]
            span=max(e['pitch'] for e in sounding)-min(e['pitch'] for e in sounding)
            if span>maxspan:maxspan=span;location=t
            if span>12:problems.append({'kind':'hand_span','hand':hand,'beat':t,'span':span})
        spans[hand]={'maximum_semitones':maxspan,'at_beat':location}
        groups=defaultdict(list)
        for e in ne:groups[e['onset']].append(e)
        times=sorted(groups)
        for a,b in zip(times,times[1:]):
            old,new=groups[a],groups[b]
            jump=min(abs(x['pitch']-y['pitch']) for x in old for y in new)
            if jump>12:
                release=max(x['onset']+x['duration'] for x in old)
                gap=seconds_at(score,b)-seconds_at(score,release)
                required=.22 if jump>21 else .18 if jump>17 else .12
                item={'hand':hand,'from_beat':a,'to_beat':b,'distance_semitones':jump,
                      'released_seconds':round(gap,6),'required_seconds':required}
                transfers.append(item)
                if gap<required-1e-6:problems.append({'kind':'wide_transfer',**item})
    for p in sorted(set(e['pitch'] for e in es)):
        ns=sorted([e for e in es if e['pitch']==p],key=lambda e:e['onset'])
        for a,b in zip(ns,ns[1:]):
            if b['onset']<a['onset']+a['duration']-1e-7:
                overlap.append({'pitch':p,'first':a,'second':b})
    if overlap:problems.append({'kind':'same_key_overlap','count':len(overlap)})
    for e in es:
        if not (0<=e['onset'] and e['onset']+e['duration']<=216+1e-7 and e['duration']>0):
            problems.append({'kind':'event_bounds','event':e})
    melody=[e for e in es if e['voice']=='melody']
    # Strong phrase entrances and final attacks are checked against the actual support.
    support_mismatch=[]; downbeat_nonchord=[]; phrase_signatures=[]
    for b in bars:
        pcs={p%12 for p in b['harmony']}
        be=[e for e in es if e['bar']==b['bar']]
        support_mismatch.extend(e for e in be if e['voice']!='melody' and e['pitch']%12 not in pcs)
        downbeat_nonchord.extend(e for e in be if e['voice']=='melody' and e['onset']==b['start'] and e['pitch']%12 not in pcs)
    if support_mismatch:problems.append({'kind':'support_harmony','events':support_mismatch})
    if downbeat_nonchord:problems.append({'kind':'melody_downbeat','events':downbeat_nonchord})
    phrase_audit=[]
    for ph in range(1,19):
        bs=[b for b in bars if b['phrase_id']==ph]
        me=[e for e in melody if bs[0]['bar']<=e['bar']<=bs[-1]['bar']]
        first,last=me[0],me[-1]
        phrase_signatures.append(tuple((e['onset']-bs[0]['start'],e['duration'],e['pitch']) for e in me))
        firstpcs=[p%12 for p in bs[0]['harmony']]
        lastpcs=[p%12 for p in bs[-1]['harmony']]
        item={'phrase':ph,'bars':[bs[0]['bar'],bs[-1]['bar']],
              'first_melody_pitch':first['pitch'],'last_melody_pitch':last['pitch'],
              'first_is_chord_tone':first['pitch']%12 in firstpcs,
              'last_is_chord_tone':last['pitch']%12 in lastpcs,
              'melody_note_count':len(me),'unique_pitches':len(set(e['pitch'] for e in me)),
              'range':[min(e['pitch'] for e in me),max(e['pitch'] for e in me)],
              'articulated_silence_seconds':round(sum(max(0,seconds_at(score,b['onset'])-seconds_at(score,a['onset']+a['duration'])) for a,b in zip(me,me[1:])),3)}
        phrase_audit.append(item)
        if not item['first_is_chord_tone'] or not item['last_is_chord_tone']:
            problems.append({'kind':'phrase_anchor',**item})
    # A continuous acoustic floor: maximum period during which neither hand holds a key.
    intervals=sorted((e['onset'],e['onset']+e['duration']) for e in es)
    union=[]
    for a,b in intervals:
        if union and a<=union[-1][1]:union[-1][1]=max(union[-1][1],b)
        else:union.append([a,b])
    gaps=[seconds_at(score,b[0])-seconds_at(score,a[1]) for a,b in zip(union,union[1:])]
    scene_times=[]
    for si in range(6):
        t0=seconds_at(score,si*36);t1=seconds_at(score,(si+1)*36)
        scene_times.append({'scene':si+1,'section':SCENES[si][0],
                            'bars':[si*24+1,(si+1)*24],
                            'start_seconds':round(t0,3),'end_seconds':round(t1,3)})
    assert all(b['beats']==1.5 and b['start']==(b['bar']-1)*1.5 for b in bars)
    assert set(x['value'] for x in score['pedals'])<={0,42,76}
    assert score['pedals'][-1]=={'onset':216.0,'value':0}
    return {'version':score['version'],'passed':not problems,'problems':problems,
            'bars':len(bars),'note_events':len(es),'melody_notes':len(melody),
            'sounding_duration_seconds':round(seconds_at(score,216),6),
            'tail_seconds':6,'total_duration_seconds':round(seconds_at(score,216)+6,6),
            'hand_spans':spans,'wide_transfers':transfers,
            'same_key_overlap_count':len(overlap),'same_key_overlaps':overlap,
            'support_harmony_mismatch_count':len(support_mismatch),
            'melody_downbeat_nonchord_count':len(downbeat_nonchord),
            'unique_eight_bar_melody_sentences':len(set(phrase_signatures)),
            'maximum_all_hands_key_release_gap_seconds':round(max(gaps),6),
            'phrases':phrase_audit,'cadences':cadences,'scenes':scene_times,
            'limits':'Symbolic geometry and harmonic-anchor audits are not a rendered listening test. Pedal resonance is not counted as a held finger. Interior passing and neighbor notes are intentionally permitted.'}

def dump(path,obj):
    path.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')

def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()

def differences(a,b):
    changes=[]
    for ba,bb in zip(a['bars'],b['bars']):
        n=ba['bar']; ea=[e for e in a['events'] if e['bar']==n];eb=[e for e in b['events'] if e['bar']==n]
        pa=[e for e in a['pedals'] if ba['start']<=e['onset']<ba['start']+1.5]
        pb=[e for e in b['pedals'] if bb['start']<=e['onset']<bb['start']+1.5]
        if ba!=bb or ea!=eb or pa!=pb:
            changes.append({'bar':n,'bar_before':ba,'bar_after':bb,
                            'events_before':ea,'events_after':eb,
                            'pedals_before':pa,'pedals_after':pb})
    return {'from_version':a['version'],'to_version':b['version'],
            'changed_bars':[d['bar'] for d in changes],
            'note_event_count_before':len(a['events']),'note_event_count_after':len(b['events']),
            'exact_changes':changes}

def main():
    scores={}; audits={}
    for version in ['v0','v1','v2']:
        scores[version],cadences=make_score(version)
        audits[version]=audit(scores[version],cadences)
        dump(OUT/f'score_{version}.json',scores[version])
        dump(OUT/f'audit_{version}.json',audits[version])
    dump(OUT/'score.json',scores['v2'])
    for a,b in [('v0','v1'),('v1','v2')]:dump(OUT/f'diff_{a}_{b}.json',differences(scores[a],scores[b]))
    manifests={p.name:sha(p) for p in sorted(OUT.iterdir())
               if p.is_file() and p.name!='manifest.json' and p.suffix in ('.json','.md','.py')}
    dump(OUT/'manifest.json',{'algorithm':'SHA-256','files':manifests})
    for v,a in audits.items():
        print(v, 'PASS' if a['passed'] else 'FAIL', a['total_duration_seconds'],a['note_events'])
        if not a['passed']:print(json.dumps(a['problems'],ensure_ascii=False,indent=2))
    print('score.json SHA-256',sha(OUT/'score.json'))
    if not all(a['passed'] for a in audits.values()):raise SystemExit(1)

if __name__=='__main__':main()
