local out='PRODUCTION_ROOT/059_migrating_shadows/revisions/native_mix_parameter_audit.tsv'
local f=assert(io.open(out,'w'))
for i=0,reaper.CountTracks(0)-1 do
 local tr=reaper.GetTrack(0,i)
 local ok,name=reaper.GetTrackName(tr,'')
 f:write(i..'\t'..name)
 for _,key in ipairs({'D_VOL','D_PAN','D_WIDTH','D_PANLAW','I_PANMODE'}) do f:write('\t'..key..'='..reaper.GetMediaTrackInfo_Value(tr,key)) end
 f:write('\n')
end
f:close();reaper.Main_OnCommand(40004,0)
