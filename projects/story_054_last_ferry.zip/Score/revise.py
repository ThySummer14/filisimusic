import pathlib,json,copy,collections,math
P=pathlib.Path(__file__).parent;d=json.loads((P/'revisions/score_v0.json').read_text());material=json.loads((P/'thematic_material.json').read_text());v1=copy.deepcopy(d);v1['stage']='v1_related_bank_themes_and_joint_arrivals'
# The introduction anticipates the answer, not a literal repetition of the first four theme bars.
intro_chords=[('Em7',[40,55,59,62]),('BmD',[50,54,59,62]),('Fs7',[42,52,58,61]),('Bm',[47,54,59,62])];v1['events']=[e for e in v1['events'] if e['bar']>4]
for j,((h,ch),line) in enumerate(zip(intro_chords,material['east_A'][4:8])):
 b=v1['bars'][j];b['harmony_name']=h;b['harmony']=ch;beat=b['start'];off=0
 for n,l in line:
  if n>=0:v1['events'].append(dict(bar=j+1,onset=beat+off,duration=l*.982,pitch=n,velocity=61+j*2+(3 if off in(0,1.5)else 0),voice='melody'))
  off+=l
 v1['events'] += [dict(bar=j+1,onset=beat,duration=.32,pitch=ch[0],velocity=39,voice='bass'),dict(bar=j+1,onset=beat+1.5,duration=.28,pitch=ch[1],velocity=34,voice='bass')]
 for t,n in [(.5,ch[1]),(1,ch[2]),(2,ch[3]),(2.5,ch[2])]:
  if j==3 and t>=2.5:continue
  v1['events'].append(dict(bar=j+1,onset=beat+t,duration=.42,pitch=n,velocity=30,voice='accompaniment'))
# The reunion's last sentence incorporates the opening gesture in one continuous shared cadence.
b=v1['bars'][83];v1['events']=[e for e in v1['events'] if not(e['bar']==84 and e['voice']=='melody')]
for k,n in enumerate([74,73,71,66,69,71]):v1['events'].append(dict(bar=84,onset=b['start']+k*.5,duration=.491,pitch=n,velocity=75+(2 if k==0 else 0),voice='melody'))
v1['events'].append(dict(bar=84,onset=b['start']+2.5,duration=.42,pitch=59,velocity=35,voice='accompaniment'))
for e in v1['events']:
 if 53<=e['bar']<=56:e['velocity']-=10 if e['voice'].startswith('melody')else 6
(P/'revisions/score_v1.json').write_text(json.dumps(v1,indent=2));(P/'revisions/pass1.json').write_text(json.dumps({'pass':1,'changes':['Recompose the introduction as the answering half of the main theme with matchingEm7→Bm/D→F#7→Bm support, avoiding a literal duplicated question at the start.','Join the reunion and coda with a new continuous cadence quoting the main theme’s opening gesture; left hand shares the final tonic arrival.','Pull the first four name-in-the-pocket bars inward dynamically, so this personal discovery is not another uniformly louder passage.'],'intent':'Two melodic banks belong to one connected musical sentence. No claim of listening review.'},indent=2))
v2=copy.deepcopy(v1);v2['stage']='v2_sung_phrases_and_compound_pulse';bybar=collections.defaultdict(list)
for e in v2['events']:bybar[e['bar']].append(e)
for b in v2['bars']:
 melody=sorted([e for e in bybar[b['bar']] if e['voice']=='melody'],key=lambda e:e['onset'])
 for i,e in enumerate(melody):
  e['velocity']+=[0,1,2,-1,1,3,1,-4][(e['bar']-1)%8]
  if i+1<len(melody):
   delta=melody[i+1]['onset']-e['onset']
   if delta-e['duration']/.982<.05:e['duration']=delta*.99
  if i==len(melody)-1 and b['bar']%8==4:e['velocity']-=3
 for e in bybar[b['bar']]:
  if e['voice']=='accompaniment' and e['onset']-b['start']>=2:e['velocity']-=2
  e['velocity']=max(24,min(98,e['velocity']))
# Final physical-key arbitration keeps the melody in charge of any overlapping note.
by=collections.defaultdict(list);skip=set();fixes=[]
for i,e in enumerate(v2['events']):by[e['pitch']].append((i,e))
for pitch,seq in by.items():
 seq.sort(key=lambda x:x[1]['onset'])
 for (ia,a),(ib,b)in zip(seq,seq[1:]):
  if ia in skip or ib in skip:continue
  if a['onset']+a['duration']>b['onset']+.001:
   if a['voice'].startswith('melody') and b['voice']=='accompaniment':skip.add(ib);fixes.append({'bar':b['bar'],'pitch':pitch,'change':'omit accompaniment retrigger under melody'})
   else:a['duration']=max(.035,b['onset']-a['onset']-.02);fixes.append({'bar':b['bar'],'pitch':pitch,'change':'release before next articulation'})
v2['events']=[e for i,e in enumerate(v2['events'])if i not in skip];(P/'revisions/score_v2.json').write_text(json.dumps(v2,indent=2));(P/'score.json').write_text(json.dumps(v2,indent=2));(P/'revisions/pass2.json').write_text(json.dumps({'pass':2,'changes':['Connect notes inside the long sung melody rather than leave gaps between isolated high notes.','Use a gentle phrase-level dynamic arc and soften accompaniment at the second dotted-quarter pulse.','Keep compound6/8 grouping distinct from53’s swinging3/4; no swing transformation is applied.','Review and reconcile any shared physical piano keys across voices.'],'key_corrections':fixes},indent=2));print('54 score revisions saved')
