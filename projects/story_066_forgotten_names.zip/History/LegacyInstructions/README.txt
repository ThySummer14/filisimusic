遗忘姓名的列车 / The Train of Forgotten Names — v3
原创虚构故事，钢琴与大提琴拨弦摇摆二重奏，2分56.8秒。

完整包打开066_forgotten_names_v3.rpp。两条float32音轨已包含，可在REAPER播放和混音；另有三轨MIDI及JSON谱面。它不是自包含虚拟乐器MIDI工程。轻房间为REAPER自带ReaVerbate，本Linux7.82已实际回开核验；其他平台可能需重新匹配插件，不保证跨平台PCM相同。输出在Renders/。

重建：Score/compose.py生成v0/v1/v2，Score/prepare_scores.py分出piano_score.json和cello_score.json，Score/export_midi.py生成三轨MIDI。使用Tools/render_score_sfizz.py，钢琴选外部Moonlight推荐SFZ并加--enable-details，大提琴选Iowa_cello_pizz_C2_B2_mf.sfz及对应外部Samples目录。输出Media/piano_float32.wav和Media/cello_float32.wav。2:1摇摆已经写入onset，请勿量化回均匀八分音符。大提琴承担低音支点，不另加一条钢琴低音来倍增。历史草稿说明保留最初非音频阶段，最终状态见本说明及metadata。

钢琴：Moonlight-SalamanderV6.2，Alexander Holm录音，Chisato Yamauchi/Accurate-Salamander重制，Hiroharu Narikawa等调律，CC BY3.0 https://creativecommons.org/licenses/by/3.0/ 。官方 https://www.ir.isas.jaxa.jp/~cyamauch/AccurateSalamander/ ，原README与版本hash随包。
大提琴：University of Iowa MIS，Jean Montes演奏，Lawrence Fritts主持，Michael Cash与Andrew Stuck-Marcell录音技术。来源 https://theremin.music.uiowa.edu/MIScello.html ，官方许可 https://theremin.music.uiowa.edu/MIS.html 允许用于任何项目，不另称CC0。原始16bit44.1kHzmono，只有C2–B2、一个mf拨弦层；velocity只控制幅度，不代表额外录制的弱强层。逐音切片、原始hash、稳定段音高校准均记录；自然衰减中的小幅漂移保留，没有弓奏或延音循环。

两轮实质谱面修改重写了小调车厢里的对话，以及最终回归和尾声。第三轮是实际REAPER总线平衡与尾静默完善：为让低音支点更清楚，将大提琴gain4调到5.2，保留所有真实层、音符和摇摆时序。音色和音乐效果仍待用户听审；程序与总线能量检查不是听感保证。不是现场真人合奏，故事纯属虚构。
