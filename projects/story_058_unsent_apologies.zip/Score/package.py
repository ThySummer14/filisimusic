"""Portable audio-track duet archive, with honest external-instrument regeneration dependencies."""
import pathlib,json,shutil,os,re,zipfile,hashlib,argparse
ap=argparse.ArgumentParser();ap.add_argument('--archive',action='store_true');a=ap.parse_args();P=pathlib.Path(__file__).parent;R=P.parent;O=pathlib.Path('DELIVERABLES');S=P/'standalone_v3';base='058_unsent_apologies_v3'
for d in['Media','Score','Revisions','Tools','InstrumentMapping']:(S/d).mkdir(parents=True,exist_ok=True)
def copy_link(src,dst):
 if dst.exists():return
 try:os.link(src,dst)
 except OSError as e:
  if e.errno==18:shutil.copy2(src,dst)
  else:raise
master=P/'revisions/058_duet_v3.wav';mp3=O/'058_没有寄出的道歉博物馆_v3.mp3';copy_link(mp3,S/(base+'.mp3'))
for instrument,v in[('piano','v2'),('clarinet','v3')]:copy_link(P/f'revisions/{instrument}_stem_{v}.wav',S/f'Media/{instrument}_float32.wav')
rpp=(P/'revisions/058_duet_v3.rpp').read_text();rpp=re.sub(r'(?m)^\s*RENDER_FILE .*$', '  RENDER_FILE "Renders"',rpp)
if re.search(r'(?m)^\s*RENDER_PATTERN ',rpp):rpp=re.sub(r'(?m)^\s*RENDER_PATTERN .*$', '  RENDER_PATTERN "$project"',rpp)
else:rpp=rpp.replace('  RENDER_FMT','  RENDER_PATTERN "$project"\n  RENDER_FMT',1)
rpp=rpp.replace('FILE "piano_stem_v2.wav"','FILE "Media/piano_float32.wav"').replace('FILE "clarinet_stem_v3.wav"','FILE "Media/clarinet_float32.wav"')
files=re.findall(r'(?m)^\s*FILE "([^"]+)"',rpp);assert sorted(files)==['Media/clarinet_float32.wav','Media/piano_float32.wav'];(S/(base+'.rpp')).write_text(rpp)
for f in P.iterdir():
 if f.is_file()and f.suffix in('.py','.mid','.lua','.json'):shutil.copy2(f,S/'Score'/f.name)
for f in(P/'revisions').iterdir():
 if f.is_file()and f.suffix in('.json','.rpp','.txt'):shutil.copy2(f,S/'Revisions'/f.name)
shutil.copy2(P/'story_zh.txt',S/'story_zh.txt')
for f in['render_score_sfizz.py','qa_pcm.py']:shutil.copy2(R/'tools'/f,S/'Tools'/f)
B=R/'assets/iowa_clarinet_C4_B4'
for f in['provenance.json','mapping_manifest.json','scale_analysis.json','Iowa_clarinet_C4_B4_museum_v3.sfz','analyze_scales.py','build_mapping.py','TECHNICAL_RESULT.json']:shutil.copy2(B/f,S/'InstrumentMapping'/f)
for f in['README.txt','README.orig.txt']:shutil.copy2(R/'assets/MoonlightSalamanderV6.2'/f,S/('PianoBank_'+f))
shutil.copy2(R/'assets/moonlight_verification.json',S/'PianoBank_version_and_hash.json')
qa=json.loads(master.with_suffix('.qa.json').read_text());sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();meta={'id':58,'title':'The Museum of Unsent Apologies','title_zh':'没有寄出的道歉博物馆','version':'v3','work_extent':'full_composition','duration_seconds':qa['duration'],'style':'Original lyrical chamber duet for sampled clarinet and piano','musical_story':'Unfinished clarinet questions receive piano replies within the same harmony; mailing a letter yields a shared arrival, not a guarantee of forgiveness.','story_kind':'Original fiction','authorship':'Original AI-assisted composition and story; credited acoustic samples, not live human performance.','rendering':'Official sfizz1.2.3 C API genuine float32 instrument stems; actual REAPER7.82 with native ReaVerbate shared room, balance and24bit master.','sample_banks':[{'instrument':'piano','name':'Moonlight-SalamanderV6.2','credit':'Alexander Holm original recordings; Chisato Yamauchi/Accurate-Salamander remaster; Hiroharu Narikawa and contributors retuning','license':'CC BY3.0','source':'https://www.ir.isas.jaxa.jp/~cyamauch/AccurateSalamander/'},{'instrument':'clarinet','name':'University of Iowa MIS BbClarinetC4–B4','credit':'Lawrence Fritts / University of Iowa; Christine Bellomy performer; John Ritz and Eric Durian recording technicians listed on source page','license':'Official permission for use in any projects without restrictions, not relabeled asCC0','license_source':'https://theremin.music.uiowa.edu/MIS.html','source':'https://theremin.music.uiowa.edu/MISBbclarinet.html','original_format':'16bit44.1kHzmono','bank_layers':['pp','mf','ff'],'layers_used_in_this_piece':['pp','mf'],'adaptations':'Documented lossless per-note crop/WAVconversion, small pitch-calibration metadata; piece-specificpp+3dB,mf-1dB mapping balance.','real_legato':False,'sustain_loops':False,'maximum_written_note_seconds':1.24}], 'revision_rounds':3,'actual_reaper_export_versions':2,'full_human_listening_review':False,'qa':qa,'master_wav_sha256':sha(master),'mp3_sha256':sha(mp3),'project_kind':'Standalone two-audio-track REAPER project with both float32 stems; separate editable three-track MIDI and event scores. Stock ReaVerbate bundled with REAPER is used.','regeneration_dependency':'ExternalMoonlightV6.2 bank plus documentedIowa36-note bank, officialsfizz1.2.3, Python3/NumPy. Neither raw bank nor engine binaries are bundled. Otherplatforms may need to resolve the bundled ReaVerbate plugin; thisLinux7.82 reopening is the tested one.'}
v=P/'revisions/portable_project_verification.json'
if v.exists():meta['portable_verification']=json.loads(v.read_text())
(P/'metadata.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2));(S/'metadata.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2))
(S/'README.txt').write_text('''没有寄出的道歉博物馆 / The Museum of Unsent Apologies — v3
Original fictional story and original chamber duet, about3:08.

FULL archive: open058_unsent_apologies_v3.rpp in REAPER. Both audio stems are included underMedia/. This is a self-contained AUDIO-TRACK playback/mastering project, with separate editable MIDI and scores. It is not a self-contained virtual-instrument MIDI project. The very subtle shared room is the stock ReaVerbate bundled with REAPER. This exactLinuxREAPER7.82 project is reopen/export tested; other platforms may need to resolve the bundled plugin, and cross-platform bit identity is not promised. Output goes to relativeRenders/.

Regenerating changed notes requires external instruments: Moonlight-SalamanderV6.2 for piano, and the documented University of IowaC4–B4 clarinet data. The compact archive omits rendered stems and listening audio and cannot play until those are regenerated. Set SFIZZ_LIBRARY to an installed officiallibsfizz.so.1 and useTools/render_score_sfizz.py withScore/piano_score.json plus the pianoSFZ and--enable-details; renderScore/clarinet_score.json with the includedIowa_clarinet_C4_B4_museum_v3.sfz placed beside its externalSamples/ directory. Write outputs asMedia/piano_float32.wav andMedia/clarinet_float32.wav. The sourceMIDI carries the composition's tempo map; the masteringRPP uses fixed audio timing. If changing form duration, also update the mastering ranges/markers.

The Iowa original files and SHA256 values are inInstrumentMapping/provenance.json. The recorded source is16bitmono.36WAVsamples are lossless crops, not new higher-resolution recordings. Exact frame bounds, output hashes and pitch offsets are in mapping_manifest.json. The piece uses genuinepp andmf recorded dynamics; ff exists in the shared bank but is not forced into this quiet piece. No truelegato or sustainloops are claimed; written notes stay within verified short durations and breaths. The piece-specific mapping adjustspp+3dB andmf-1dB for ensemble balance.

Piano credit: Alexander Holm recordings; Chisato Yamauchi/Accurate-Salamander remaster; Hiroharu Narikawa and contributors retuning. CC BY3.0 https://creativecommons.org/licenses/by/3.0/ . Official source https://www.ir.isas.jaxa.jp/~cyamauch/AccurateSalamander/ . Original piano README files are included.
Clarinet credit: Lawrence Fritts / University of IowaMIS; Christine Bellomy, clarinet; John Ritz and Eric Durian, recording technicians as listed on the instrument page. Permission https://theremin.music.uiowa.edu/MIS.html . Source https://theremin.music.uiowa.edu/MISBbclarinet.html . Official page permits use in any projects without restrictions. This is not asserted to be aCC0 license.

Three real revision passes are recorded: extended questions and harmonic rewriting; layer-consistent phrasing and aligned piano replies; render-informedpp/mfbalance and finalmix. Technical tests do not constitute human listening approval. The story is fiction and the recording is sample-based, not a live human performance.
''')
manifest={'mp3':str(mp3),'wav':str(master),'compact':str(O/(base+'_compact_source.zip')),'full':str(O/(base+'_full_REAPER.zip')),'stage':str(S),'project':str(S/(base+'.rpp'))};(P/'delivery_manifest.json').write_text(json.dumps(manifest,indent=2))
if a.archive:
 for key,media in[('compact',False),('full',True)]:
  dest=pathlib.Path(manifest[key])
  with zipfile.ZipFile(dest,'w',zipfile.ZIP_DEFLATED,2 if media else 6)as z:
   for f in S.rglob('*'):
    rel=f.relative_to(S)
    if not f.is_file()or'Renders'in rel.parts:continue
    if not media and('Media'in rel.parts or f.suffix=='.mp3'):continue
    z.write(f,rel)
   if not media:z.writestr('COMPACT_NOTICE.txt','Regenerable source only; external banks/player and rebuilt audio stems required before playback. Full audio-track project is a separate archive.\n')
  with zipfile.ZipFile(dest)as z:assert z.testzip()is None
  print(key,dest.stat().st_size,'CRC passed')
print(json.dumps(manifest))
