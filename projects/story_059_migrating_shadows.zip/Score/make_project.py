import pathlib
import json
import argparse

ap = argparse.ArgumentParser()
ap.add_argument('--version', required=True)
ap.add_argument('--end-seconds', type=float)
ap.add_argument('--piano-gain', type=float, default=5.5)
ap.add_argument('--clarinet-gain', type=float, default=5.5)
ap.add_argument('--cello-gain', type=float, default=3.0)
ap.add_argument('--master-volume', type=float, default=.85)
a = ap.parse_args()
P = pathlib.Path(__file__).parent
d = json.loads((P / 'ensemble_score.json').read_text())
duration = a.end_seconds or json.loads((P / 'revisions/piano_stem_v2.render.json').read_text())['duration']
rpp = f'''<REAPER_PROJECT 0.1 7.82 1
  SAMPLERATE 44100 0 0
  TEMPO 132 5 8 0
  MASTER_VOLUME {a.master_volume}
  RENDER_FILE "{P}/revisions/059_trio_{a.version}.wav"
  RENDER_FMT 0 2 44100
  RENDER_1X 0
  RENDER_RANGE 0 0 {duration:.10f} 0 1000
  RENDER_STEMS 0
  RENDER_DITHER 0
  <RENDER_CFG
    ZXZhdxgAAA==
  >
'''
time = 0
last = None
index = 0
for bar in d['bars']:
    if bar['section'] != last:
        index += 1
        rpp += f'  MARKER {index} {time:.8f} "{bar["section"]}" 0\n'
        last = bar['section']
    time += bar['beats'] * 60 / bar['bpm']
for instrument, gain, pan, width in [('piano', a.piano_gain, -.35, .50),
                                     ('clarinet', a.clarinet_gain, -.12, 1),
                                     ('cello', a.cello_gain, .12, 1)]:
    rpp += f'''  <TRACK
    NAME "{instrument} | original acoustic trio"
    PANMODE 5
    VOLPAN {gain} {pan} 1 -1 {width}
    MAINSEND 1
    <ITEM
      POSITION 0
      LENGTH {duration:.10f}
      VOLPAN 1 0 1 -1
      FADEIN 1 0.003
      FADEOUT 1 0.8
      <SOURCE WAVE
        FILE "{instrument}_stem_v2.wav"
      >
    >
  >
'''
rpp += '>\n'
project = P / f'revisions/059_trio_{a.version}.rpp'
project.write_text(rpp)
(P / f'add_room_{a.version}.lua').write_text(f'''local master=reaper.GetMasterTrack(0)
local fx=reaper.TrackFX_AddByName(master,'ReaVerbate (Cockos)',false,-1)
assert(fx>=0,'Bundled ReaVerbate unavailable')
local widths={{0.50,1,1}}
for i=0,reaper.CountTracks(0)-1 do
 local tr=reaper.GetTrack(0,i)
 assert(reaper.SetMediaTrackInfo_Value(tr,'D_PANLAW',1))
 assert(reaper.SetMediaTrackInfo_Value(tr,'D_WIDTH',widths[i+1]))
end
for i,v in pairs({{[0]=0.05,[1]=1,[2]=0.18,[3]=0.62,[4]=0.70,[5]=0,[6]=1,[7]=0}}) do reaper.TrackFX_SetParam(master,fx,i,v) end
local audit=assert(io.open('{P}/revisions/native_mix_{a.version}_verified.tsv','w'))
for i=0,reaper.CountTracks(0)-1 do local tr=reaper.GetTrack(0,i);audit:write(i..'\\tD_VOL='..reaper.GetMediaTrackInfo_Value(tr,'D_VOL')..'\\tD_PAN='..reaper.GetMediaTrackInfo_Value(tr,'D_PAN')..'\\tD_WIDTH='..reaper.GetMediaTrackInfo_Value(tr,'D_WIDTH')..'\\tD_PANLAW='..reaper.GetMediaTrackInfo_Value(tr,'D_PANLAW')..'\\n')end
audit:close()
reaper.Main_SaveProject(0,false)
local f=assert(io.open('{P}/revisions/native_room_{a.version}_saved.txt','w'));f:write('Actual REAPER stock shared room saved: wet0.05,dry1,room0.18,damp0.62,width0.70.');f:close()
reaper.Main_OnCommand(40004,0)
''')
print('Three-track mastering project prepared:', duration)
