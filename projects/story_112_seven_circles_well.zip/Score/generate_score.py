"""112 seven distinct composed chaconne variations; fixed ground is structural, not audio reuse."""
from pathlib import Path
import json,difflib,bisect,sys
P=Path(__file__).resolve().parent;sys.path.insert(0,str(P));from composition_data import *
def pitch(s):return 12*(int(s[-1])+1)+{'C':0,'D':2,'E':4,'F':5,'G':7,'A':9,'B':11}[s[0]]+s[1:-1].count('#')-s[1:-1].count('b')
PARAM=[('circle1','第一圈，轮廓',88,56),('circle2','第二圈，抬头',96,70),('circle3','第三圈，碎光',104,83),('circle4','第四圈，重压',112,95),('circle5','第五圈，只听回声',96,42),('circle6','第六圈，颜色改变',104,83),('circle7','第七圈，未描尽',92,65),('coda','井沿空下的一段',80,45)]
def build(level):
 lines=sum(UPPER,[])+CODA;hs=sum(CYCLE_H,[])+CODA_H;assert len(lines)==len(hs)==60
 for lv,rd,hd in [(1,REV1,HREV1),(2,REV2,HREV2)]:
  if level>=lv:
   for n,s in rd.items():lines[n-1]=s
   for n,h in hd.items():hs[n-1]=h
 bars=[];events=[];pedals=[]
 for n,(line,h) in enumerate(zip(lines,hs),1):
  ci=(n-1)//8;sec,label,bpm,dyn=PARAM[ci];ch=H[h];start=(n-1)*6
  if n in [8,16,24,32,40,48,56]:bpm-=4
  if n>=58:bpm-=2*(n-57)
  bars.append(dict(bar=n,start=start,beats=6,bpm=bpm,meter='3/2',meter_numerator=3,meter_denominator=2,section=sec,section_title_zh=label,harmony_name=h,harmony=ch,key_region='D major/D-minor interchange' if ci>=5 else 'D minor',ground_cycle=ci+1,texture='independent_upper_variation_over_chaconne_ground',ground_is_written_notes_not_audio_loop=True))
  def add(p,t,d,v,inst,voice,hand='none'):
   assert 0<=t<t+d<=6.00001,(n,t,d)
   events.append(dict(bar=n,onset=round(start+t,6),duration=round(d,6),pitch=p,velocity=int(v),instrument=inst,voice=voice,hand=hand,harmony_name=h,role='lead' if voice in ['upper_variation','cello_echo'] else 'support',phrase_id=f'circle{ci+1}_bar{(n-1)%8+1}',articulation='short_separate_bow' if inst=='cello' else 'connected_line_over_spaced_ground',written_value_beats=d))
  at=0;mel=[]
  for i,tok in enumerate(line.split()):
   name,u=tok.split(':');dur=float(u)/2
   if name!='R':
    p=pitch(name);mel.append(p);add(p,at,dur-.08,dyn+(4 if at==4 and ci in [2,3,5] else 0)-(4 if i==len(line.split())-1 else 0),'piano','upper_variation','right')
   at+=dur
  assert at==6
  root=ch[0];fifth=ch[2]
  while fifth>48:fifth-=12
  low=[(0,root,1.4),(3,fifth,.7)]
  if ci==0:low=[(0,root,1.8),(3,fifth,1.1)]
  if ci==4:low=[(0,root,1.3)]
  if ci==7:low=[(0,root,1.6)]
  if level>=1 and 25<=n<=32:low=[(0,root,1.1),(3.5,fifth,.6)]
  for t,p,dur in low:add(p,t,dur,dyn-20,'piano','chaconne_ground','left')
  inner=[ch[1]+12,ch[2]+12]
  while max(inner)>=min(mel):inner=[p-12 for p in inner]
  if ci in [1,2,3,5,6]:
   times=[2,4.5];notes=inner
   if ci==2:notes=list(reversed(inner))
   if level>=1 and ci==3:times=[1.75,4.75];notes=list(reversed(inner))
   if level>=2 and ci==5:times=[2.0,4.25];notes=inner
   for t,p in zip(times,notes):add(p,t,.65,dyn-27,'piano','independent_inner_reply','left')
  avail=[p for p in range(50,60) if p%12 in {x%12 for x in ch}];assert avail
  notes=[]
  if ci==0 and n%2==0:notes=[(.45,avail[0],.62)]
  elif ci in [1,2] and n%2==1:notes=[(3.2,avail[-1],.56)]
  elif ci==3:notes=[(4.4,avail[0],.48)] if n%2 else []
  elif ci==4:notes=[(.45,avail[-1],.68),(3.2,avail[0],.64)]
  elif ci==5:notes=[(3.2,avail[-1],.57)] if n%2 else [(.45,avail[0],.64)]
  elif ci==6 and n%2==1:notes=[(.45,avail[0],.64),(3.2,avail[-1],.6)]
  elif ci==7 and n in [57,60]:notes=[(.45,avail[0],.75)]
  if level>=1 and ci==3:notes=[(4.3,avail[-1],.49)] if n in [26,28,30] else []
  if level>=2 and n in [53,54,55]:notes=[(.45,avail[-1],.62)]
  for t,p,body in notes:add(p,t,body*bpm/60,48 if ci in [0,4,7] else 68 if ci in [1,6] else 76,'cello','cello_echo')
  pedals.append(dict(bar=n,onset=start,controller=64,value=0,instrument='piano'))
  if ci in [0,4,6,7]:
   pedals.extend([dict(bar=n,onset=start+.06,controller=64,value=25,instrument='piano'),dict(bar=n,onset=start+1.8,controller=64,value=0,instrument='piano'),dict(bar=n,onset=start+3.05,controller=64,value=22,instrument='piano'),dict(bar=n,onset=start+4.85,controller=64,value=0,instrument='piano')])
 events.sort(key=lambda e:(e['onset'],e['instrument'],e['pitch']))
 for i,e in enumerate(events):e['event_id']=f'w112-v{level}-{i:04d}'
 return dict(id=112,title='Seven Circles at the Well',title_zh='井沿的第七圈',version=f'v{level}',bars=bars,events=events,pedals=pedals,total_beats=360,tail_seconds=5,instrument_map={'piano':'piano','cello':'arco'},performance_contract='Original chaconne with seven newly composed upper lines and real separate cello short bows; not live performance or a repeated audio loop.')
def proj(d,n):return {'bar':d['bars'][n-1],'events':[{k:v for k,v in e.items() if k!='event_id'} for e in d['events'] if e['bar']==n],'pedals':[e for e in d['pedals'] if e['bar']==n]}
for v in range(3):
 d=build(v);(P/f'score_v{v}.json').write_text(json.dumps(d,ensure_ascii=False,indent=2));report={'version':f'v{v}','bars':60,'events':len(d['events']),'duration_seconds':sum(b['beats']*60/b['bpm'] for b in d['bars'])+5,'human_listening_review':False};(P/f'audit_v{v}.json').write_text(json.dumps(report,indent=2))
 if v:
  a=build(v-1);rows=[];patch=[]
  for n in range(1,61):
   x=proj(a,n);y=proj(d,n)
   if x!=y:
    rows.append({'bar':n,'before':x,'after':y});patch.extend(difflib.unified_diff(json.dumps(x,ensure_ascii=False,indent=2).splitlines(True),json.dumps(y,ensure_ascii=False,indent=2).splitlines(True),f'v{v-1}/bar{n}',f'v{v}/bar{n}'))
  (P/f'exact_diff_v{v-1}_to_v{v}.json').write_text(json.dumps({'count':len(rows),'changed_bars':[x['bar'] for x in rows],'comparison_excludes':['version','event_id'],'changes':rows},ensure_ascii=False,indent=2));(P/f'exact_diff_v{v-1}_to_v{v}.patch').write_text(''.join(patch))
(P/'score.json').write_text((P/'score_v2.json').read_text());d=build(2);starts=[b['start'] for b in d['bars']];times=[];t=0
for b in d['bars']:times.append(t);t+=b['beats']*60/b['bpm']
def sec(t):
 i=max(0,bisect.bisect_right(starts,t)-1);return times[i]+(t-starts[i])*60/d['bars'][i]['bpm']
def beat(t):
 i=max(0,bisect.bisect_right(times,t)-1);return starts[i]+(t-times[i])*d['bars'][i]['bpm']/60
mp=P.parent/'assets/iowa_cello_arco_D3_B3/mapping_manifest.json';lat={(x['layer'],x['midi']):x['coarse_voiced_delay_after_tuning_seconds'] for x in json.loads(mp.read_text())['files']};alignment=[]
for e in d['events']:
 if e['instrument']!='cello':continue
 layer='pp' if e['velocity']<=55 else 'mf';target=sec(e['onset']);end=sec(e['onset']+e['duration']);delay=lat[layer,e['pitch']];trigger=target-delay;assert trigger>=0;e['nominal_onset']=e['onset'];e['onset']=beat(trigger);e['duration']=beat(end)-e['onset'];e['layer']=layer;e['attack_compensated_once']=True;assert .30<=end-target and end-trigger<=1.15;alignment.append(dict(event_id=e['event_id'],target_seconds=target,trigger_seconds=trigger,delay_seconds=delay,gate_seconds=end-trigger,layer=layer))
ce=sorted([e for e in d['events'] if e['instrument']=='cello'],key=lambda e:e['onset'])
for a,b in zip(ce,ce[1:]):assert sec(b['onset'])-sec(a['onset']+a['duration'])>=.14
(P/'ensemble_score.json').write_text(json.dumps(d,ensure_ascii=False,indent=2))
for inst in ['piano','cello']:
 x={**d,'events':[e for e in d['events'] if e['instrument']==inst],'pedals':d['pedals'] if inst=='piano' else []};(P/f'{inst}_score.json').write_text(json.dumps(x,ensure_ascii=False,indent=2))
(P/'revisions/cello_attack_alignment.json').write_text(json.dumps({'method':'Once-only coarse recorded onset compensation, separated real pp/mf short bows','events':alignment},indent=2));print(json.dumps(report))
