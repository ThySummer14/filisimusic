from copy import deepcopy

def pitch(s):
 return 12*(int(s[-1])+1)+{'C':0,'D':2,'E':4,'F':5,'G':7,'A':9,'B':11}[s[0]]+s[1:-1].count('#')-s[1:-1].count('b')
def decode(line):
 result=[];t=0
 for token in line.split():
  name,units=token.split(':');dur=float(units)/2
  if name!='R':result.append((pitch(name),t,dur))
  t+=dur
 return result,t
class Writer:
 def __init__(self):self.bars=[];self.events=[];self.pedals=[];self.start=0;self.n=0
 def bar(self,name,bpm,beats,h,ch):
  self.n+=1;self.beats=beats;self.bpm=bpm;self.ch=ch
  numerator,denominator=(int(beats*2),8) if beats in (2.5,3.5) else ((6,8) if METER=='6/8' else (int(beats),4))
  self.bars.append(dict(bar=self.n,start=self.start,beats=beats,bpm=bpm,meter_numerator=numerator,meter_denominator=denominator,section=name,harmony_name=h,harmony=ch))
 def add(self,p,t,d,v=72,inst='piano',voice='theme',hand='right',art='detached'):
  if d>0 and t<self.beats:
   self.events.append(dict(bar=self.n,onset=round(self.start+t,6),duration=round(min(d,self.beats-t),6),pitch=int(p),velocity=max(1,min(127,int(v))),instrument=inst,voice=voice,hand=hand if inst=='piano' else 'none',articulation=art))
 def line(self,line,v=80,hand='right',transpose=0):
  notes,total=decode(line);assert abs(total-self.beats)<1e-7,(self.n,total,self.beats,line)
  for p,t,d in notes:self.add(p+transpose,t,max(.11,d-.09),v+(3 if t==0 else 0),hand=hand)
  return notes
 def release(self,amount=0,length=.7):
  self.pedals.append(dict(bar=self.n,onset=self.start,controller=64,value=0,instrument='piano'))
  if amount:
   self.pedals.extend([dict(bar=self.n,onset=self.start+.05,controller=64,value=amount,instrument='piano'),dict(bar=self.n,onset=self.start+length,controller=64,value=0,instrument='piano')])
  self.start+=self.beats
 def result(self,level):
  self.pedals.append(dict(bar=self.n,onset=self.start-.01,controller=64,value=0,instrument='piano'))
  return dict(id=ID,title=TITLE,title_zh=TITLE_ZH,version=f'v{level}',bars=self.bars,events=self.events,pedals=self.pedals,total_beats=self.start,tail_seconds=5,instrument_map=INSTRUMENT_MAP)
def material(level):
 n=0
 for section,bpm,beats,texture,hs,phrase_names in BLOCKS:
  lines=[]
  for pn in phrase_names.split():lines+=P[pn].split('|')
  harmonies=hs.split();assert len(lines)==len(harmonies),(section,len(lines),len(harmonies))
  for h,line in zip(harmonies,lines):
   n+=1
   for lv,rev in [(1,REV1),(2,REV2)]:
    if level>=lv and n in rev:h,line=rev[n]
   yield n,section,bpm,beats,texture,h,line
ID=136;TITLE='The Turn at the End of the Lane';TITLE_ZH='泳道尽头的转身';METER='4/4';INSTRUMENT_MAP={'piano':'piano'}
RENDERER_NOTES='Solo piano with independently written upper/lower thematic lines. Phrase lengths 7/10/11/13/6/9/14/12/10 bars; continuous development, no central quiet interlude.'
H={'Cm':[36,51,55],'Ab':[44,51,60],'G7':[43,53,59],'Eb':[39,55,58],'Fm':[41,56,60],'Bb':[46,53,62],'Dm7b5':[38,53,56],'Cm/G':[43,51,60],'Abmaj7':[44,55,60],'Db':[37,53,56],'Gsus':[43,55,60]}
# Each paired row is an explicitly notated bar. Lower line B has its own contour and displaced answering rhythm.
A=[
('Cm','G5:1 C6:1 Eb6:2 D6:1 C6:1 G5:2','C3:2 R:1 Eb3:1 G3:1 F3:1 Eb3:2'),
('Ab','C6:1 Ab5:1 G5:1 F5:1 Eb5:2 C5:2','Ab2:1 Eb3:1 Ab3:2 G3:1 F3:1 Eb3:2'),
('Fm','F5:2 Ab5:1 C6:1 Bb5:1 Ab5:1 F5:2','F3:2 C3:1 F3:1 Ab3:2 G3:2'),
('G7','B5:1 G5:1 F5:2 D5:1 B4:1 G4:2','G2:1 B2:1 D3:2 F3:1 D3:1 B2:2'),
('Cm','G5:1 Eb5:1 C5:2 D5:1 Eb5:1 G5:2','C3:1 G3:1 Eb3:2 R:1 G3:1 C4:2'),
('Ab','Ab5:1 G5:1 Eb5:2 C5:1 Eb5:1 Ab5:2','Ab2:2 C3:1 Eb3:1 G3:2 Eb3:2'),
('G7','F5:1 D5:1 B4:2 D5:1 F5:1 G5:2','G2:1 D3:1 F3:1 G3:1 B3:2 R:2')]
B=[
('Eb','Bb5:2 G5:1 Eb5:1 F5:1 G5:1 Bb5:2','Eb3:1 G3:1 Bb3:1 Ab3:1 G3:2 F3:2'),
('Bb','D6:1 Bb5:1 F5:2 G5:1 Ab5:1 F5:2','Bb2:2 F3:1 D3:1 Bb2:2 R:2'),
('Cm','Eb6:1 D6:1 C6:1 G5:1 Eb5:2 G5:2','C3:2 Eb3:1 G3:1 C4:2 Bb3:2'),
('Ab','C6:2 Ab5:1 Eb5:1 F5:1 G5:1 Ab5:2','Ab2:1 C3:1 Eb3:2 Ab3:1 G3:1 Eb3:2'),
('Fm','Ab5:1 C6:1 F6:2 Eb6:1 C6:1 Ab5:2','F3:1 C3:1 Ab2:2 C3:1 Eb3:1 F3:2'),
('Bb','Bb5:2 F5:1 D5:1 C5:1 D5:1 F5:2','Bb2:1 D3:1 F3:1 Ab3:1 Bb3:2 R:2'),
('Eb','G5:1 Bb5:1 Eb6:2 D6:1 Bb5:1 G5:2','Eb3:2 Bb2:1 G2:1 Bb2:2 Eb3:2'),
('Dm7b5','F5:1 Ab5:1 C6:2 Bb5:1 Ab5:1 F5:2','D3:2 F3:1 Ab3:1 C4:1 Bb3:1 Ab3:2'),
('G7','B5:1 G5:1 D5:1 F5:1 G5:2 D5:2','G2:1 B2:1 D3:2 F3:1 G3:1 B3:2'),
('Cm','Eb5:1 G5:1 C6:2 Bb5:1 G5:1 Eb5:2','C3:1 Eb3:1 G3:2 R:1 Eb3:1 C3:2')]
C=[
('Fm','C6:1 Ab5:1 F5:1 Eb5:1 C5:2 F5:2','F3:1 Ab3:1 C4:2 Bb3:1 Ab3:1 F3:2'),
('Db','Ab5:1 F5:1 Db5:2 Eb5:1 F5:1 Ab5:2','Db3:2 F3:1 Ab3:1 C4:1 Ab3:1 F3:2'),
('G7','B5:1 D6:1 F6:1 Eb6:1 D6:1 B5:1 G5:2','G2:2 D3:1 B2:1 D3:1 F3:1 G3:2'),
('Cm/G','G5:2 C6:1 Eb6:1 D6:2 C6:2','G2:1 C3:1 Eb3:2 G3:1 F3:1 Eb3:2'),
('Abmaj7','G5:1 C6:1 Eb6:2 C6:1 Ab5:1 G5:2','Ab2:1 Eb3:1 G3:2 C4:1 G3:1 Eb3:2'),
('Bb','F5:2 Bb5:1 D6:1 C6:1 Bb5:1 Ab5:2','Bb2:2 D3:1 F3:1 Ab3:2 F3:2'),
('Eb','G5:1 Eb5:1 Bb4:2 Eb5:1 G5:1 Bb5:2','Eb3:1 G3:1 Bb3:1 Ab3:1 G3:1 F3:1 Eb3:2'),
('Ab','C6:1 Ab5:1 F5:1 Eb5:1 C5:2 Eb5:2','Ab2:1 C3:1 Eb3:1 F3:1 Ab3:2 G3:2'),
('Fm','Ab5:1 F5:1 C5:2 Eb5:1 F5:1 Ab5:2','F3:2 C3:1 Ab2:1 C3:1 Eb3:1 F3:2'),
('Gsus','C6:1 G5:1 F5:1 D5:1 G5:2 R:2','G2:1 C3:1 D3:2 F3:1 G3:1 C4:2'),
('G7','B5:2 G5:1 F5:1 D5:1 B4:1 R:2','G3:1 F3:1 D3:1 B2:1 G2:2 R:2')]
# Development keeps the two characters but rewrites their ordering/cadences over a thirteen-bar span.
D=[
('Cm','Eb6:1 C6:1 G5:2 Bb5:1 C6:1 Eb6:2','C3:2 G3:1 Eb3:1 D3:1 Eb3:1 G3:2'),
('Fm','C6:1 F6:1 Eb6:1 C6:1 Ab5:2 F5:2','F3:1 C3:1 Ab2:2 C3:1 F3:1 Ab3:2'),
('Ab','Eb6:1 C6:1 Ab5:1 G5:1 F5:1 Eb5:1 C5:2','Ab2:2 Eb3:1 C3:1 Eb3:1 G3:1 Ab3:2'),
('G7','D6:2 B5:1 G5:1 F5:2 D5:2','G2:1 D3:1 B3:1 G3:1 F3:1 D3:1 B2:2'),
('Cm/G','C6:1 G5:1 Eb5:2 D5:1 C5:1 G4:2','G2:2 C3:1 Eb3:1 G3:1 Bb3:1 C4:2'),
('Db','F5:1 Ab5:1 Db6:2 C6:1 Ab5:1 F5:2','Db3:2 Ab2:1 F2:1 Ab2:1 C3:1 Db3:2'),
('Fm','Ab5:1 C6:1 F6:1 Eb6:1 C6:2 Ab5:2','F3:1 Ab3:1 C4:1 Bb3:1 Ab3:2 F3:2'),
('Bb','D6:1 Bb5:1 F5:1 D5:1 F5:1 Ab5:1 Bb5:2','Bb2:1 F3:1 D3:2 F3:1 Ab3:1 Bb3:2'),
('Eb','Bb5:1 G5:1 Eb5:2 D5:1 Eb5:1 G5:2','Eb3:2 G3:1 Bb3:1 Eb4:2 D4:2'),
('Abmaj7','C6:1 G5:1 Eb5:1 C5:1 Eb5:1 G5:1 Ab5:2','Ab2:1 Eb3:1 G3:2 C4:1 Bb3:1 G3:2'),
('Dm7b5','Ab5:2 F5:1 D5:1 C5:2 Ab4:2','D3:1 F3:1 Ab3:1 C4:1 Bb3:1 Ab3:1 F3:2'),
('G7','B4:1 D5:1 G5:1 B5:1 D6:2 F6:2','G2:2 D3:1 B2:1 G2:2 D3:2'),
('Cm','Eb6:2 C6:1 G5:1 Eb5:2 C5:2','C3:1 Eb3:1 G3:2 C4:1 G3:1 Eb3:2')]
# Later sections deliberately share thematic material, but join after unequal lengths and continue into new endings.
E=[('Ab', 'Eb5:2 C5:1 Ab4:1 C5:1 Eb5:1 G5:2','Ab2:1 Eb3:1 Ab3:2 G3:1 Eb3:1 C3:2'),('Fm','F5:2 C5:1 Ab4:1 C5:2 Eb5:2','F3:1 Ab3:1 C4:2 Bb3:1 Ab3:1 F3:2'),('Bb','F5:1 Bb5:1 D6:2 C6:2 Bb5:2','Bb2:2 F3:1 D3:1 F3:1 Ab3:1 Bb3:2'),('Eb','G5:2 Eb5:1 Bb4:1 G4:2 Bb4:2','Eb3:1 G3:1 Bb3:1 C4:1 Bb3:2 G3:2'),('Dm7b5','F5:1 Ab5:1 C6:2 Bb5:1 Ab5:1 F5:2','D3:2 F3:1 Ab3:1 C4:2 R:2'),('G7','B5:1 G5:1 F5:1 D5:1 B4:2 G4:2','G2:1 B2:1 D3:2 F3:1 G3:1 B3:2')]
F=B[:7]+[('Gsus','D6:1 C6:1 G5:2 F5:1 D5:1 C5:2','G2:1 C3:1 D3:2 F3:1 G3:1 C4:2'),('G7','B4:1 D5:1 F5:1 G5:1 B5:2 R:2','G2:2 D3:1 B2:1 G2:2 R:2')]
G=D[:11]+[('Fm','C6:1 Ab5:1 F5:1 C5:1 F5:1 Ab5:1 C6:2','F3:2 C3:1 Ab2:1 C3:1 F3:1 Ab3:2'),('G7','D6:1 B5:1 G5:1 F5:1 D5:1 B4:1 G4:2','G2:1 B2:1 D3:2 F3:1 D3:1 B2:2'),('Cm','C6:2 G5:1 Eb5:1 C5:2 R:2','C3:2 G3:1 Eb3:1 C3:2 R:2')]
I=C[:9]+[('Cm/G','G5:1 C6:1 Eb6:2 D6:1 C6:1 G5:2','G2:1 C3:1 Eb3:1 G3:1 C4:2 Bb3:2'),('G7','B5:1 G5:1 D5:1 F5:1 G5:2 B5:2','G2:1 B2:1 D3:1 F3:1 G3:2 B3:2'),('Cm','C6:2 G5:1 Eb5:1 C5:1 Eb5:1 G5:2','C3:2 Eb3:1 G3:1 C4:2 G3:2')]
J=A[:5]+[('Ab','C6:1 Ab5:1 Eb5:2 C5:1 Eb5:1 Ab5:2','Ab2:2 Eb3:1 C3:1 Ab2:2 Eb3:2'),('Fm','Ab5:1 F5:1 C5:2 Ab4:1 C5:1 F5:2','F3:2 C3:1 Ab2:1 F2:2 C3:2'),('G7','B5:1 G5:1 F5:1 D5:1 G5:2 R:2','G2:1 B2:1 D3:1 F3:1 G3:2 R:2'),('Cm','G5:1 Eb5:1 C5:2 Eb5:1 G5:1 C6:2','C3:2 G3:1 Eb3:1 C3:1 G2:1 C3:2'),('Cm','C5:2 G4:1 Eb4:1 C4:2 R:2','C3:2 G2:2 C2:2 R:2')]
SECTIONS=[('First_lap',110,A),('Count_the_tiles',114,B),('Longer_strokes',116,C),('Turn_under_water',122,D),('Find_the_surface',106,E),('Breath_between_strokes',118,F),('Arms_and_tiles',128,G),('Return_to_the_wall',120,I),('One_complete_length',108,J)]
REV1={31:('Fm','F6:1 C6:1 Ab5:2 G5:1 F5:1 C5:2','F3:1 Ab3:1 C4:2 Ab3:1 F3:1 C3:2'),32:('G7','B5:2 D6:1 F6:1 D6:1 B5:1 G5:2','G2:1 D3:1 F3:1 G3:1 B3:2 D4:2'),33:('Cm/G','G5:1 Eb5:1 C5:2 G4:1 C5:1 Eb5:2','G2:1 C3:1 Eb3:1 G3:1 C4:2 G3:2'),34:('Abmaj7','C6:1 G5:1 Eb5:2 C5:1 Eb5:1 G5:2','Ab2:2 Eb3:1 G3:1 C4:2 Bb3:2'),35:('Fm','Ab5:1 F5:1 C5:2 Eb5:1 F5:1 Ab5:2','F3:1 C3:1 Ab2:2 C3:1 Eb3:1 F3:2'),36:('Bb','D6:2 Bb5:1 F5:1 Ab5:1 Bb5:1 D6:2','Bb2:1 D3:1 F3:1 Ab3:1 Bb3:2 F3:2'),37:('Eb','Eb6:1 Bb5:1 G5:1 Eb5:1 D5:1 Eb5:1 G5:2','Eb3:2 Bb2:1 G2:1 Bb2:2 Eb3:2'),38:('Dm7b5','C6:1 Ab5:1 F5:1 D5:1 F5:1 Ab5:1 C6:2','D3:1 F3:1 Ab3:2 C4:1 Bb3:1 Ab3:2'),39:('G7','B5:1 G5:1 F5:2 D5:1 B4:1 G4:2','G2:2 B2:1 D3:1 F3:2 G3:2'),40:('Cm','Eb5:1 G5:1 C6:2 Bb5:1 G5:1 Eb5:2','C3:1 Eb3:1 G3:2 C4:1 Bb3:1 G3:2'),41:('Cm/G','C6:1 G5:1 Eb5:2 C5:1 Eb5:1 G5:2','G2:1 C3:1 Eb3:2 G3:1 Eb3:1 C3:2')}
REV2={}
# Seven-bar local reworking plus an extended three-bar ending: two unequal revision scopes.
for n,(h,r,l) in zip(range(70,77),[('Fm','C6:1 F6:1 Eb6:2 C6:1 Ab5:1 F5:2','F3:1 Ab3:1 C4:1 Bb3:1 Ab3:1 G3:1 F3:2'),('Abmaj7','G5:1 C6:1 Eb6:2 C6:1 Ab5:1 G5:2','Ab2:1 Eb3:1 G3:2 C4:1 G3:1 Eb3:2'),('Bb','Bb5:1 D6:1 F6:2 Eb6:1 D6:1 Bb5:2','Bb2:2 F3:1 D3:1 F3:1 Ab3:1 Bb3:2'),('Eb','G5:1 Bb5:1 Eb6:2 D6:1 Bb5:1 G5:2','Eb3:1 Bb2:1 G2:2 Bb2:1 D3:1 Eb3:2'),('Fm','Ab5:2 F5:1 C5:1 Eb5:1 F5:1 Ab5:2','F3:2 C3:1 Ab2:1 C3:1 Eb3:1 F3:2'),('Gsus','C6:2 G5:1 F5:1 D5:1 C5:1 G4:2','G2:1 C3:1 D3:2 F3:1 G3:1 C4:2'),('G7','B5:1 D6:1 F6:2 D6:1 B5:1 G5:2','G2:2 B2:1 D3:1 F3:1 G3:1 B3:2')]):REV2[n]=(h,r,l)
REV2.update({90:('G7','D6:1 B5:1 G5:1 F5:1 D5:2 R:2','G2:1 B2:1 D3:2 F3:1 G3:1 B3:2'),91:('Cm','Eb6:2 C6:1 G5:1 Eb5:2 C5:2','C3:1 Eb3:1 G3:2 C4:1 G3:1 Eb3:2'),92:('Cm','C5:1 G4:1 Eb4:2 C4:2 R:2','C3:2 G2:1 Eb2:1 C2:2 R:2')})
def build(level):
 w=Writer();n=0
 for section,bpm,rows in SECTIONS:
  for h,r,l in rows:
   n+=1
   for lv,rv in [(1,REV1),(2,REV2)]:
    if level>=lv and n in rv:h,r,l=rv[n]
   w.bar(section,bpm,4,h,H[h]);v=77+{'First_lap':0,'Count_the_tiles':4,'Longer_strokes':8,'Turn_under_water':14,'Find_the_surface':-4,'Breath_between_strokes':9,'Arms_and_tiles':23,'Return_to_the_wall':13,'One_complete_length':6}[section]
   w.line(r,v,'right');w.line(l,v-11,'left');w.release()
 return w.result(level)
