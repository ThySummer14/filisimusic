from pathlib import Path
import json,shutil,os,re,zipfile,hashlib,sys
P=Path(__file__).parent;R=P.parent;O=Path('DELIVERABLES');S=P/'standalone_v3';base='059_migrating_shadows_v3'
for d in ['Media','Score','Revisions','Tools','ClarinetMapping','CelloMapping']:(S/d).mkdir(parents=True,exist_ok=True)
def link(a,b):
 if not b.exists():
  try:os.link(a,b)
  except OSError:shutil.copy2(a,b)
master=P/'revisions/059_trio_v3.wav';mp3=O/'059_给迁徙的影子架桥_v3.mp3';link(mp3,S/(base+'.mp3'))
rpp=(P/'revisions/059_trio_v3.rpp').read_text();rpp=re.sub(r'(?m)^\s*RENDER_FILE .*$', '  RENDER_FILE "Renders"',rpp)
rpp=re.sub(r'(?m)^\s*RENDER_PATTERN .*$', '  RENDER_PATTERN "$project"',rpp) if 'RENDER_PATTERN' in rpp else rpp.replace('  RENDER_FMT','  RENDER_PATTERN "$project"\n  RENDER_FMT',1)
for i in ['piano','clarinet','cello']:
 link(P/f'revisions/{i}_stem_v2.wav',S/f'Media/{i}_float32.wav');rpp=rpp.replace(f'FILE "{i}_stem_v2.wav"',f'FILE "Media/{i}_float32.wav"')
(S/(base+'.rpp')).write_text(rpp)
for f in P.iterdir():
 if f.is_file() and f.suffix in ['.py','.mid','.json','.lua']:shutil.copy2(f,S/'Score'/f.name)
for f in (P/'revisions').iterdir():
 if f.is_file() and f.suffix in ['.json','.txt','.tsv','.rpp'] and not f.name.startswith('diagnostic_'):shutil.copy2(f,S/'Revisions'/f.name)
for instrument,folder in [('clarinet','iowa_clarinet_C4_B4'),('cello','iowa_cello_pizz_C2_B2')]:
 for f in (R/'assets'/folder).iterdir():
  if f.is_file() and f.suffix in ['.json','.py','.sfz','.txt']:shutil.copy2(f,S/(instrument.capitalize()+'Mapping')/f.name)
for f in ['render_score_sfizz.py','qa_pcm.py']:shutil.copy2(R/'tools'/f,S/'Tools'/f)
for f in ['README.txt','README.orig.txt']:shutil.copy2(R/'assets/MoonlightSalamanderV6.2'/f,S/('PianoBank_'+f))
shutil.copy2(R/'assets/moonlight_verification.json',S/'PianoBank_version_and_hash.json');shutil.copy2(P/'story_zh.txt',S/'story_zh.txt')
qa=json.loads(master.with_suffix('.qa.json').read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
meta={'id':59,'title_zh':'给迁徙的影子架桥','title':'A Bridge for Migrating Shadows','version':'v3','work_extent':'full_composition','duration_seconds':qa['duration'],'story_kind':'original fiction','style':'Asymmetric-meter acoustic chamber trio','instrumentation':['Moonlight sampled grand piano','Iowa sampled Bb clarinet, mf layer','Iowa sampled cello pizzicato, one mf layer'],'revision_rounds':3,'actual_reaper_export_versions':2,'human_performance':False,'full_human_listening_review':False,'qa':qa,'master_wav_sha256':sha(master),'mp3_sha256':sha(mp3),'project_kind':'Standalone three-audio-track REAPER project with original float32 stems and bundled stock ReaVerbate. Separate editable MIDI/event scores. External instruments needed to regenerate changed notes.','native_track_parameter_verification':'Revisions/native_mix_v3_verified.tsv','balance_diagnostic':'Revisions/native_role_balance_v3.json','sample_disclosure':'Clarinet and cello originals16bit44.1kHzmono; float32 stems do not add original recording precision. No true legato or sustain loops. Cello velocity changes amplitude only, not recorded layer. Piano uses genuine16 recorded dynamic layers.'}
v=P/'revisions/portable_project_verification.json'
if v.exists():meta['portable_verification']=json.loads(v.read_text())
(P/'metadata.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2));(S/'metadata.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2))
readme='''给迁徙的影子架桥 / A Bridge for Migrating Shadows — v3
原创虚构故事与原创三重奏，约3分13秒。钢琴代表河东五块木板，单簧管回答河西七步；桥接合时合为12/8，归途中顺序倒转，尾声共同落在C小调。

完整包包含三条实际float32音轨，可在REAPER打开059_migrating_shadows_v3.rpp播放和混音。另有可编辑MIDI与JSON乐谱。音轨工程自包含；改变音符后重新生成需要外部音源和官方sfizz1.2.3，未把巨大共享音源重复打包。共享房间为REAPER自带ReaVerbate，本Linux7.82原生回开导出经过验证；其他平台可能需要重新匹配插件，不保证跨平台PCM一致。

钢琴：Moonlight-SalamanderV6.2。Alexander Holm原录音，Chisato Yamauchi/Accurate-Salamander重制，Hiroharu Narikawa等调律。CC BY3.0 https://creativecommons.org/licenses/by/3.0/ 。官方来源 https://www.ir.isas.jaxa.jp/~cyamauch/AccurateSalamander/ 。原README和版本hash随包。
单簧管：University of Iowa MIS；Christine Bellomy演奏，Lawrence Fritts，John Ritz和Eric Durian录音技术。来源 https://theremin.music.uiowa.edu/MISBbclarinet.html 。本曲使用mf真实录音层，短句分离发音，没有真实连奏过渡或循环延音。
大提琴：University of Iowa MIS；Jean Montes演奏，Lawrence Fritts，Michael Cash和Andrew Stuck-Marcell录音技术。来源 https://theremin.music.uiowa.edu/MIScello.html 。本曲仅C2–B2、拨弦、一个mf录音层，力度控制只是音量变化。录音音高偏差按稳定段测量校准，原PCM保留；自然衰减中的音高漂移仍存在。
Iowa官方使用许可 https://theremin.music.uiowa.edu/MIS.html 允许下载并用于任何项目，无限制。这里没有将其另称为CC0。两个管弦音源实际都是16bit44.1kHzmono，切片/转换及音高标定见各Mapping目录；float32演奏轨不等于高精度原始录音。

生成：Tools/render_score_sfizz.py读取Score/piano_score.json（加--enable-details）、clarinet_score.json、cello_score.json。各自选择外部Moonlight推荐SFZ、Iowa_clarinet_C4_B4_trio_articulated.sfz、Iowa_cello_pizz_C2_B2_trio.sfz。Mapping内SFZ需放在对应外部Samples目录旁。输出Media/*_float32.wav。原始MIDI包含混合拍号与速度，母带工程是固定时序音轨。

修订：第一轮改写西岸和声接点与共同终止；第二轮调整句弧、呼吸、回答时点和钢琴手部关系；第三轮纠正生成器声像律/宽度字段、用原生API设置回读并重新平衡。历史v2保留。三个乐器真实REAPER总线分轨的能量分析用于排查主伴层次，不代表人工听感评价。未宣称真人演奏或人工听审。
'''
(S/'README.txt').write_text(readme)
manifest={'mp3':str(mp3),'wav':str(master),'compact':str(O/(base+'_compact_source.zip')),'full':str(O/(base+'_full_REAPER.zip')),'stage':str(S),'project':str(S/(base+'.rpp'))};(P/'delivery_manifest.json').write_text(json.dumps(manifest,indent=2))
if '--archive' in sys.argv:
 for key,media in [('compact',False),('full',True)]:
  with zipfile.ZipFile(manifest[key],'w',zipfile.ZIP_DEFLATED,2 if media else 6) as z:
   for f in S.rglob('*'):
    rel=f.relative_to(S)
    if not f.is_file() or 'Renders' in rel.parts or (not media and ('Media' in rel.parts or f.suffix=='.mp3')):continue
    z.write(f,rel)
   if not media:z.writestr('COMPACT_NOTICE.txt','Regenerable score/source only: no rendered stems or listening audio; external instrument banks and sfizz required.\n')
  with zipfile.ZipFile(manifest[key]) as z:assert z.testzip() is None
  print(key,Path(manifest[key]).stat().st_size)
print(json.dumps(manifest))
