local master=reaper.GetMasterTrack(0)
local fx=reaper.TrackFX_AddByName(master,'ReaVerbate (Cockos)',false,-1)
assert(fx>=0,'Bundled ReaVerbate unavailable')
local widths={1,1}
for i=0,reaper.CountTracks(0)-1 do
 local tr=reaper.GetTrack(0,i)
 assert(reaper.SetMediaTrackInfo_Value(tr,'D_PANLAW',1))
 assert(reaper.SetMediaTrackInfo_Value(tr,'D_WIDTH',widths[i+1]))
end
for i,v in pairs({[0]=0.055,[1]=1,[2]=0.20,[3]=0.65,[4]=0.70,[5]=0,[6]=1,[7]=0}) do reaper.TrackFX_SetParam(master,fx,i,v) end
local audit=assert(io.open('PRODUCTION_ROOT/073_footstep_island/revisions/native_mix_v3_verified.tsv','w'))
for i=0,reaper.CountTracks(0)-1 do local tr=reaper.GetTrack(0,i);audit:write(i..'\tD_VOL='..reaper.GetMediaTrackInfo_Value(tr,'D_VOL')..'\tD_PAN='..reaper.GetMediaTrackInfo_Value(tr,'D_PAN')..'\tD_WIDTH='..reaper.GetMediaTrackInfo_Value(tr,'D_WIDTH')..'\tD_PANLAW='..reaper.GetMediaTrackInfo_Value(tr,'D_PANLAW')..'\n')end
audit:close()
reaper.Main_SaveProject(0,false)
local f=assert(io.open('PRODUCTION_ROOT/073_footstep_island/revisions/native_room_v3_saved.txt','w'));f:write('Actual REAPER stock shared room saved: wet0.055,dry1,room0.20,damp0.65,width0.70.');f:close()
reaper.Main_OnCommand(40004,0)
