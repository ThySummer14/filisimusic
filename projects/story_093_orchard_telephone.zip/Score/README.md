# 093 — The Orchard’s Last Telephone / 果园最后一部电话

Original contemporary fiction and a complete symbolic solo-acoustic-piano lament. Selected v2: F minor, 72 bars of 3/4, 216 absolute quarter-note beats, 639 note events, 200.959336 seconds of score plus 6 seconds of tail, 206.959336 seconds total (about 3:27).

A falling-third call figure leads into a substantial A-flat-major middle, dominant preparation, a returning theme with newly composed continuation, and an eight-bar restrained close. One singing RH foreground remains clear over soft sustained LH shells and purposeful inner chord motion.

## Deliverables

- score_v0.json, score_v1.json, score_v2.json: three complete preserved versions.
- score.json: selected final score, byte-identical to score_v2.json.
- generate_score.py: deterministic standard-library Python generator, no dependencies.
- verify_symbolic.py: independent disk checker, without generator imports.
- audit_v0.json, audit_v1.json, audit_v2.json: detailed physical-key histories, transfer measurements and within-position melodic movement.
- independent_verification.json and reproducibility_check.json: verification and fresh-process byte equality results.
- exact_diff_v0_to_v1.json and exact_diff_v1_to_v2.json: literal before/after bars, notes, pedal, metadata, source hashes and complete reconstructive JSON patches.
- Corresponding .patch files: readable exact text changes.
- story_zh.txt: original contemporary Chinese fiction.
- music_notes_zh.md and revision_notes.md: Chinese form, performance, revision and limitation notes.
- hash_manifest.json: byte sizes and SHA-256 for every other regular file in this isolated folder.

## Rebuild

Run `python generate_score.py`, then `python verify_symbolic.py` in this folder. The generator accepts `--outdir` only for this directory or a child directory. Verification runs a fresh Python process in a temporary child folder, compares all regenerated artifacts byte for byte, then removes that temporary reproduction.

## Integration contract

Every onset, duration, bar start, pedal onset and target beat alias is expressed in absolute quarter-note beats. A 3/4 bar is exactly three beats. Tempo is supplied per bar. Read total_beats and tail_seconds separately; never reinterpret the 216 quarters as 216 three-quarter bars.

Notes identify instrument, hand, role, voice, phrase, finger, explicit hand position, written rhythm, physical gate and exact integrated seconds. Both hands have an active declared position in every bar. All foreground melody is RH; the LH is support. Sustain pedal is resonance intent only, distinct from physical key holds and hand travel.

Actual whole-hand transfer is checked against the larger of held-grip edge motion and declared position-edge motion. Every declared position change receives at least 75 ms after the latest earlier physical key release; distances beyond four semitones add 12 ms per additional semitone. Ordered fingers justify genuine within-position melodic movement. No same-key overlap, finger collision or hand crossing is allowed; held spans cannot exceed 12 semitones.

No audio, DSP, rendering, MIDI realization, downloads, installations or changes to live files are included. Numerical PASS is not listening approval, source-quality acceptance or a guarantee of individual performer comfort.
