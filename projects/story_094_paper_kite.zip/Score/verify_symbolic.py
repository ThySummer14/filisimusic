#!/usr/bin/env python3
"""Independent work094 disk reader: never imports the generator. No audio."""
import copy,hashlib,difflib,json,math,subprocess,sys,tempfile
from collections import defaultdict
from pathlib import Path
ROOT=Path(__file__).resolve().parent
def load(n):return json.loads((ROOT/n).read_text(encoding='utf-8'))
def save(n,x):(ROOT/n).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def sha(n):return hashlib.sha256((ROOT/n).read_bytes()).hexdigest()
def end(e):return round(e['onset']+e['duration'],6)

def inspect(s):
    errors=[];bs=s['bars'];ns=s['events'];pn=[e for e in ns if e['instrument']=='piano'];fn=[e for e in ns if e['instrument']=='flute']
    def check(ok,msg):
        if not ok:errors.append(msg)
    def sec(t):return sum(min(max(t-b['start'],0),b['beats'])*60/b['bpm'] for b in bs)
    check(s['id']==94 and s['total_beats']==352 and s['tail_seconds']==4,'work endpoint')
    check(len(bs)==176 and 190<=sec(352)+4<=220,'176-bar 3:10–3:40 form')
    check(s['instrumentation']==['natural_acoustic_piano','natural_acoustic_flute'],'acoustic instrument plan')
    check([b['bar'] for b in bs if b['key_region']=='G minor']==list(range(57,89)),'G-minor contrast')
    named_chords={'Bb':{10,2,5},'F':{5,9,0},'F7':{5,9,0,3},'Eb':{3,7,10},'Cm':{0,3,7},'Gm':{7,10,2},'D7':{2,6,9,0},'Dm':{2,5,9},'Bb6':{10,2,5,7}}
    named_bass={'A':9,'Bb':10,'C':0,'D':2,'Eb':3,'G':7}
    for i,b in enumerate(bs):
        check((b['bar'],b['start'],b['beats'],b['meter_numerator'],b['meter_denominator'])==(i+1,i*2,2,2,4),'quarter-note grid')
        check(88<=b['bpm']<=120 and b['meter']=='2/4','tempo/meter')
        check(b['phrase_id']==f'P{i//8+1:02d}','bar phrase')
        parts=b['harmony_name'].split('/')
        check({p%12 for p in b['harmony']}==named_chords[parts[0]],'actual MIDI matches named chord '+str(i+1))
        if len(parts)>1:check(min(b['harmony'])%12==named_bass[parts[1]],'actual inversion bass '+str(i+1))
    check(len({e['event_id'] for e in ns})==len(ns),'unique event IDs')
    check(ns==sorted(ns,key=lambda e:(e['onset'],e['instrument'],e['hand'],e['pitch'],e['voice'])),'chronological events')
    plans={(p['bar'],p['hand']):p for p in s['hand_position_plan']}
    check(len(plans)==len(s['hand_position_plan'])==352,'352 hand plans')
    for e in ns:
        tag=e['event_id'];b=bs[e['bar']-1]
        check(all(math.isfinite(e[k]) for k in ('onset','duration','pitch','velocity')),'finite '+tag)
        check(isinstance(e['pitch'],int) and 21<=e['pitch']<=108 and 1<=e['velocity']<=127,'MIDI '+tag)
        check(b['start']<=e['onset']<end(e)<=b['start']+2,'bar bounds '+tag)
        check(e['target_on_beats']==e['onset'] and abs(e['target_off_beats']-end(e))<1e-6,'beat aliases')
        check(abs(e['target_on_seconds']-sec(e['onset']))<1.1e-6 and abs(e['target_off_seconds']-sec(end(e)))<1.1e-6,'integrated seconds')
        chord=e['pitch']%12 in {p%12 for p in b['harmony']}
        check(e['harmonic_function']==('chord_tone' if chord else 'melodic_nonchord_tone'),'harmonic label')
        if e['role']=='support':check(chord and e['instrument']=='piano','support chord membership '+tag)
        else:check(e['instrument']==b['lead_instrument'],'foreground bar ownership')
        check(e['written_value_beats']>=e['duration']>0,'written/physical values')
        if e['instrument']=='piano':
            check(e['hand'] in ('left','right') and e['pitch']<=87,'piano limits')
            check(sec(end(e))-sec(e['onset'])>=.055,'vanishing gate '+tag)
            p=plans[(e['bar'],e['hand'])]
            check(e['hand_position_id']==p['position_id'] and e['hand_position_range']==p['range'],'position identity')
            check(e['position_keys']==sorted(int(k) for k in p['pitch_finger_map']),'position keys')
            check(p['pitch_finger_map'].get(str(e['pitch']))==e['finger'] and 1<=e['finger']<=5,'finger identity')
            if e['role']=='lead':check(e['voice']=='melody' and e['hand']=='right','piano melodic role')
        else:
            check(e['instrument']=='flute' and e['role']=='answer' and e['hand']=='not_applicable','flute identity')
            check(72<=e['pitch']<=83 and e['source_pitch_midi']==e['pitch'],'recorded flute pitch')
            check(e['layer']==e['sample_layer'] and ((e['layer']=='pp' and e['velocity']<=63) or (e['layer']=='mf' and e['velocity']>=64)),'true pp/mf layer')
            gate=sec(end(e))-sec(e['onset'])
            check(.65<=gate<=1.10 and abs(gate-e['nominal_gate_seconds'])<1e-6,'flute gate')
            check(e['onset_reference']=='ordinary_trigger','ordinary trigger')
            check(e['timing_correction_applied_seconds']==0,'no double compensation')
            check(abs(e['minimum_usable_pitched_seconds_after_209ms_advance']-(gate-.209))<1e-6 and gate-.209>=.50,'conservative usable pitched length')
    for key,p in plans.items():
        es=[e for e in pn if (e['bar'],e['hand'])==key];ps=sorted({e['pitch'] for e in es});fs=[p['pitch_finger_map'][str(q)] for q in ps]
        check(p['active'] and p['range']==[min(ps),max(ps)] and max(ps)-min(ps)<=12,'whole position '+str(key))
        check(len(ps)<=5 and len(fs)==len(set(fs)),'distinct fingers')
        check(fs==sorted(fs,reverse=p['hand']=='left'),'finger order')
        # A thumb–little-finger sixth is playable; adjacent-finger geometry
        # must use the actual finger interval, not only neighboring key order.
        allowance={1:5,2:9,3:11,4:12}
        check(all(b-a<=allowance[abs(g-f)] for a,b,f,g in zip(ps,ps[1:],fs,fs[1:])),'assigned finger interval spacing')
    changes=defaultdict(list);attacks={h:defaultdict(list) for h in ('left','right')}
    for i,e in enumerate(ns):
        changes[e['onset']].append((1,i));changes[end(e)].append((0,i))
        if e['instrument']=='piano':attacks[e['hand']][e['onset']].append(e)
    held={};physical={h:{} for h in attacks};maxspan={h:0 for h in attacks};maxkeys={h:0 for h in attacks}
    overlap=[];cross=[];finger=[];foreground=[];silence=[];lastoff=None
    for t in sorted(changes):
        was=bool(held)
        for kind,i in sorted(changes[t]):
            if kind==0:held.pop(i,None)
            else:
                e=ns[i]
                for old in held.values():
                    if e['instrument']==old['instrument']=='piano':
                        if e['pitch']==old['pitch']:overlap.append((old['event_id'],e['event_id']))
                        if e['hand']==old['hand'] and e['finger']==old['finger']:finger.append((old['event_id'],e['event_id']))
                held[i]=e
        if was and not held:lastoff=t
        if held and lastoff is not None:
            if t>lastoff:silence.append(sec(t)-sec(lastoff))
            lastoff=None
        foreground.append(sum(e['role'] in ('lead','answer') for e in held.values()))
        hands={h:[e for e in held.values() if e['instrument']=='piano' and e['hand']==h] for h in attacks}
        for h,es in hands.items():
            if es:
                ps=[e['pitch'] for e in es];maxspan[h]=max(maxspan[h],max(ps)-min(ps));maxkeys[h]=max(maxkeys[h],len(ps))
                if t in attacks[h]:physical[h][t]=[min(ps),max(ps)]
        if all(hands.values()) and max(e['pitch'] for e in hands['left'])>=min(e['pitch'] for e in hands['right']):cross.append(t)
    check(not overlap and not cross and not finger,'same-key overlap / crossing / finger collision')
    check(max(maxspan.values())<=12 and max(maxkeys.values())<=5,'held geometry')
    check(max(foreground)==1,'one nonoverlapping foreground')
    check(max(silence,default=0)<.40,'no silence padding')
    transfers=[];within=[]
    for hand in attacks:
        groups=sorted(attacks[hand].items());latest=0
        for i,(t,group) in enumerate(groups):
            if i:
                prev_t,prev=groups[i-1];old=physical[hand][prev_t];new=physical[hand][t]
                edge=max(abs(a-b) for a,b in zip(old,new));op=plans[(prev[0]['bar'],hand)];np=plans[(group[0]['bar'],hand)]
                pe=max(abs(a-b) for a,b in zip(op['range'],np['range']));change=op['position_id']!=np['position_id'];melodic=all(e['voice']=='melody' for e in prev+group)
                if change or (edge>4 and not melodic):
                    travel=max(edge,pe) if change else edge;required=.075+.012*max(0,travel-4);available=sec(t)-sec(latest)
                    row={'hand':hand,'from_beat':prev_t,'to_beat':t,'old_grip':old,'new_grip':new,'old_position':op['range'],'new_position':np['range'],
                      'whole_position_changed':change,'grip_edge_semitones':edge,'position_edge_semitones':pe,'checked_travel_semitones':travel,
                      'last_prior_key_release_beat':latest,'available_seconds':round(available,9),'required_seconds':round(required,9),
                      'margin_seconds':round(available-required,9),'passed':available+1e-7>=required}
                    transfers.append(row);check(row['passed'],f'transfer {hand} at {t}')
                elif edge>4:within.append({'hand':hand,'from_beat':prev_t,'to_beat':t,'position_id':np['position_id'],'edge_semitones':edge,'method':'Explicit unchanged ordered finger grip, single melody, no crossing or substitution.'})
            latest=max(latest,*(end(e) for e in group))
    lead=[e for e in ns if e['role'] in ('lead','answer')]
    for n in range(1,177):
        es=[e for e in lead if e['bar']==n];sup=[e for e in pn if e['bar']==n and e['role']=='support']
        check(es and len({e['instrument'] for e in es})==1,'one lead instrument each bar')
        check(max(e['velocity'] for e in sup)<=min(e['velocity'] for e in es)-17,'support hierarchy '+str(n))
        if bs[n-1]['lead_instrument']=='piano':
            cursor=(n-1)*2
            for e in es:check(abs(e['onset']-cursor)<1e-6,'written rhythm '+str(n));cursor+=e['written_value_beats']
            check(abs(cursor-n*2)<1e-6,'written two beats '+str(n))
    fs=sorted(fn,key=lambda e:e['onset']);gaps=[sec(b['onset'])-sec(end(a)) for a,b in zip(fs,fs[1:])]
    check(min(gaps)>=.30,'flute release gaps')
    check(min(gaps)-.159>=.30,'flute gap after worst differential advance')
    fb=sorted({e['bar'] for e in fn});runs=[];run=[]
    for n in fb:
        if run and n!=run[-1]+1:runs.append(run);run=[]
        run.append(n)
    if run:runs.append(run)
    check(all(len(x)<=2 for x in runs) and all(b[0]-a[-1]>=3 for a,b in zip(runs,runs[1:])),'breaths every two flute bars')
    check({e['layer'] for e in fn}=={'pp','mf'},'both flute layers retained')
    phrases={p['phrase_id']:p for p in s['phrases']};check(len(phrases)==44,'44 instrument phrase records')
    for pid,p in phrases.items():
        es=[e for e in ns if e['phrase_id']==pid]
        check(es and all(p['first_bar']<=e['bar']<=p['last_bar'] for e in es),'phrase membership')
        check(abs(p['target_on_beats']-min(e['onset'] for e in es))<1e-6 and abs(p['target_off_beats']-max(end(e) for e in es))<1e-6,'phrase targets')
        check(abs(sec(p['target_on_beats'])-p['target_on_seconds'])<1.1e-6 and abs(sec(p['target_off_beats'])-p['target_off_seconds'])<1.1e-6,'phrase seconds')
    signatures=[tuple((round(e['onset']-i*16,6),e['pitch'],e['written_value_beats'],e['instrument']) for e in lead if i*8<e['bar']<=i*8+8) for i in range(22)]
    check(len(set(signatures))>=21,'distinct developed phrases')
    ped=s['pedals'];check(ped==sorted(ped,key=lambda p:p['onset']),'pedal order')
    check(all(p['controller']==64 and p['instrument']=='piano' and 0<=p['onset']<=352 and 0<=p['value']<=127 for p in ped),'pedal bounds')
    check(ped[-1]['onset']==352 and ped[-1]['value']==0,'pedal terminal release')
    check(bs[-2]['harmony_name']=='F7' and bs[-1]['harmony_name']=='Bb','dominant-tonic coda')
    check(lead[-1]['pitch']==70 and end(lead[-1])==352,'final B-flat reaches boundary')
    flute_phrase_timing=[]
    for pid in sorted({e['phrase_id'] for e in fn}):
        es=[e for e in fn if e['phrase_id']==pid]
        flute_phrase_timing.append({'phrase_id':pid,'bars':[e['bar'] for e in es],
          'nominal_gate_seconds':[e['nominal_gate_seconds'] for e in es],
          'usable_pitched_seconds_if_gate_unchanged_after_209ms_advance':[e['minimum_usable_pitched_seconds_after_209ms_advance'] for e in es],
          'pitched_arrival_seconds':[e['target_on_seconds'] for e in es],
          'nominal_release_seconds':[e['target_off_seconds'] for e in es],
          'minimum_internal_release_gap_seconds':round(min(sec(b['onset'])-sec(end(a)) for a,b in zip(es,es[1:])),9),
          'minimum_internal_gap_after_worst_differential_advance_seconds':round(min(sec(b['onset'])-sec(end(a)) for a,b in zip(es,es[1:]))-.159,9)})
    return {'passed':not errors,'errors':errors,'event_count':len(ns),'bars':176,'total_quarter_beats':352,'duration_with_tail_seconds':round(sec(352)+4,6),
      'maximum_held_span_semitones':maxspan,'maximum_simultaneous_keys':maxkeys,'same_key_overlap_count':len(overlap),'hand_crossing_count':len(cross),'finger_collision_count':len(finger),
      'maximum_simultaneous_foreground_notes':max(foreground),'piano_pitch_range':[min(e['pitch'] for e in pn),max(e['pitch'] for e in pn)],'flute_pitch_range':[min(e['pitch'] for e in fn),max(e['pitch'] for e in fn)],
      'flute_event_count':len(fn),'flute_layers':sorted({e['layer'] for e in fn}),'flute_gate_seconds_range':[min(e['nominal_gate_seconds'] for e in fn),max(e['nominal_gate_seconds'] for e in fn)],
      'minimum_flute_gap_seconds':round(min(gaps),9),'minimum_flute_gap_after_worst_differential_advance_seconds':round(min(gaps)-.159,9),
      'maximum_consecutive_flute_bars':max(map(len,runs)),'maximum_physical_key_silence_seconds':round(max(silence,default=0),9),
      'flute_phrase_timing':flute_phrase_timing,'minimum_usable_flute_pitched_seconds_after_209ms_advance':min(e['minimum_usable_pitched_seconds_after_209ms_advance'] for e in fn),
      'minimum_piano_gate_seconds':round(min(sec(end(e))-sec(e['onset']) for e in pn),9),'unique_eight_bar_phrases':len(set(signatures)),
      'strict_transfer_count':len(transfers),'minimum_transfer_margin_seconds':min(r['margin_seconds'] for r in transfers),'strict_transfers':transfers,'within_position_large_melodic_moves':within,
      'limits':'Symbolic geometry, sample-range and target-time checks only; no listening, comfort or acoustic-quality approval.'}

def patch_apply(original,patch):
    target=copy.deepcopy(original)
    for p in patch:
        keys=[x.replace('~1','/').replace('~0','~') for x in p['path'].split('/')[1:]]
        if not keys:target=p['value'];continue
        obj=target
        for k in keys[:-1]:obj=obj[int(k)] if isinstance(obj,list) else obj[k]
        key=int(keys[-1]) if isinstance(obj,list) else keys[-1]
        if p['op']=='remove':del obj[key]
        else:obj[key]=copy.deepcopy(p['value'])
    return target

def verify_diff(a,b,d):
    errors=[];expected=[];musical=[];dimensions={'foreground_pitch':[],'written_rhythm':[],'actual_harmony_pitches':[],'texture':[]}
    core=lambda ns:[{k:e[k] for k in ('onset','duration','pitch','instrument','voice','hand')} for e in ns]
    for n in range(1,177):
        row={'bar':n,'before_bar':a['bars'][n-1],'after_bar':b['bars'][n-1],
             'before_events':[e for e in a['events'] if e['bar']==n],'after_events':[e for e in b['events'] if e['bar']==n],
             'before_pedals':[e for e in a['pedals'] if e['bar']==n],'after_pedals':[e for e in b['pedals'] if e['bar']==n]}
        if any(row['before_'+k]!=row['after_'+k] for k in ('bar','events','pedals')):expected.append(row)
        if core(row['before_events'])!=core(row['after_events']) or row['before_bar']['harmony']!=row['after_bar']['harmony']:musical.append(n)
        for dimension,keys in [('foreground_pitch',('pitch','instrument')),('written_rhythm',('onset','written_value_beats'))]:
            old=[tuple(e[k] for k in keys) for e in row['before_events'] if e['role'] in ('lead','answer')]
            new=[tuple(e[k] for k in keys) for e in row['after_events'] if e['role'] in ('lead','answer')]
            if old!=new:dimensions[dimension].append(n)
        if row['before_bar']['harmony']!=row['after_bar']['harmony']:dimensions['actual_harmony_pitches'].append(n)
        if row['before_bar']['texture']!=row['after_bar']['texture']:dimensions['texture'].append(n)
    if expected!=d['changes'] or [x['bar'] for x in expected]!=d['changed_bars']:errors.append('literal per-bar diff')
    if len(musical)<16:errors.append('fewer than sixteen substantive musical bars')
    if any(len(rows)<4 for rows in dimensions.values()):errors.append('revision does not substantially change every musical dimension')
    for label,s in [('before',a),('after',b)]:
        if d[label+'_sha256']!=sha(f'score_{s["version"]}.json'):errors.append('diff hash')
        if d['phrase_metadata_'+label]!=s['phrases'] or d['position_plan_'+label]!=s['hand_position_plan']:errors.append('metadata diff')
    if patch_apply(a,d['json_patch'])!=b:errors.append('full-document JSON patch reconstruction')
    text_before=(ROOT/f'score_{a["version"]}.json').read_text(encoding='utf-8')
    text_after=(ROOT/f'score_{b["version"]}.json').read_text(encoding='utf-8')
    expected_patch=''.join(difflib.unified_diff(text_before.splitlines(True),text_after.splitlines(True),
      fromfile=f'score_{a["version"]}.json',tofile=f'score_{b["version"]}.json'))
    exact_text=(ROOT/f'exact_diff_{a["version"]}_to_{b["version"]}.patch').read_text(encoding='utf-8')==expected_patch
    if not exact_text:errors.append('exact unified text patch')
    return {'passed':not errors,'errors':errors,'changed_bars':d['changed_bars'],'strict_musical_changed_bars':musical,
            'strict_musical_changed_bar_count':len(musical),'changed_bars_by_musical_dimension':dimensions,'full_document_patch_reconstructs_next_version':patch_apply(a,d['json_patch'])==b,'exact_text_patch_matches':exact_text}

def main():
    scores={v:load(f'score_{v}.json') for v in ('v0','v1','v2')};audits={v:inspect(s) for v,s in scores.items()}
    for v,r in audits.items():save(f'audit_{v}.json',r)
    diffs={f'{a}_to_{b}':verify_diff(scores[a],scores[b],load(f'exact_diff_{a}_to_{b}.json')) for a,b in [('v0','v1'),('v1','v2')]}
    same=(ROOT/'score.json').read_bytes()==(ROOT/'score_v2.json').read_bytes()
    with tempfile.TemporaryDirectory(prefix='.reproduction_',dir=ROOT) as tmp:
        subprocess.run([sys.executable,str(ROOT/'generate_score.py'),'--outdir',tmp],check=True,capture_output=True)
        reproduction={p.name:(ROOT/p.name).read_bytes()==p.read_bytes() for p in sorted(Path(tmp).iterdir()) if p.is_file()}
    save('reproducibility_check.json',{'passed':all(reproduction.values()),'byte_identical_files':reproduction,
      'method':'Fresh standard-library Python process generated all score/diff artifacts in a temporary subdirectory, followed by byte-for-byte comparisons.'})
    keys=('passed','errors','event_count','duration_with_tail_seconds','maximum_held_span_semitones','maximum_simultaneous_keys','same_key_overlap_count','hand_crossing_count','finger_collision_count','strict_transfer_count','minimum_transfer_margin_seconds','unique_eight_bar_phrases','maximum_physical_key_silence_seconds')
    result={'passed':same and all(r['passed'] for r in audits.values()) and all(r['passed'] for r in diffs.values()) and all(reproduction.values()),
      'selected_equals_v2_byte_for_byte':same,'selected_score_sha256':sha('score.json'),
      'version_summaries':{v:{k:r[k] for k in keys} for v,r in audits.items()},'revision_checks':diffs,
      'reproducibility_passed':all(reproduction.values()),'scope':'Independent saved-file symbolic checks plus fresh-process byte reproducibility. No audio rendering, DSP or listening.'}
    save('independent_verification.json',result)
    files={p.name:{'bytes':p.stat().st_size,'sha256':sha(p.name)} for p in sorted(ROOT.iterdir()) if p.is_file() and p.name!='hash_manifest.json'}
    save('hash_manifest.json',{'algorithm':'SHA-256','files':files,'excludes_self':True,'scope':'Every regular deliverable file in this isolated draft folder.'})
    print(json.dumps(result,ensure_ascii=False,indent=2))
    if not result['passed']:raise SystemExit(1)
if __name__=='__main__':main()
