"""Original low-register piano elegy; a shared open-fifth memory inside the melody."""
from pathlib import Path
import json,copy
P=Path(__file__).parent
A=[[(61,1.5),(64,.5),(66,1),(68,1.5),(64,.5),(63,1)],[(64,1.5),(63,.5),(61,1),(59,1),(56,1),(61,1)],[(66,1),(64,.5),(63,.5),(61,1),(56,1),(57,1),(59,1)],[(63,1),(56,1),(60,1),(63,1),(66,1),(-1,1)],[(61,2),(64,1),(68,1),(66,1),(64,1)],[(59,1),(61,.5),(63,.5),(64,1),(66,1),(68,1),(64,1)],[(66,1),(63,1),(59,1),(57,1),(54,1),(56,1)],[(61,3),(56,2),(-1,1)]]
B=[[(64,1),(68,1),(71,1),(73,1.5),(71,.5),(68,1)],[(69,1.5),(68,.5),(64,1),(61,1),(59,1),(57,1)],[(66,1),(69,.5),(73,.5),(71,1),(69,1),(68,1),(66,1)],[(63,1),(66,1),(71,1),(69,1),(66,1),(-1,1)],[(68,1.5),(66,.5),(64,1),(61,1),(64,1),(68,1)],[(69,1),(73,1),(76,1),(73,1),(69,1),(66,1)],[(68,1),(66,1),(63,1),(60,1),(63,1),(68,1)],[(73,2),(68,1),(64,1),(61,1),(-1,1)]]
H={'Csm':[37,44,52],'A':[45,49,52],'Fsm':[42,45,49],'Gs7':[44,51,54],'E':[40,47,52],'B7':[47,51,57],'D':[38,45,54],'Bsus':[47,52,54]};pa=['Csm','A','Fsm','Gs7','Csm','E','Fsm','Csm'];pb=['E','A','Fsm','B7','Csm','D','Gs7','Csm']
sections=[('The old rope on the table',2,64,'intro'),('Remembering the missing hour',8,68,'memory'),('Along the drowned wall',6,72,'descent'),('A garden inside the bell',8,70,'garden'),('You said you could bring it back',4,66,'refusal'),('The shore keeps a different sound',8,68,'shore'),('Still there, still missed',4,60,'coda')]
events=[];bars=[];pedals=[];beat=0;bar=0
for title,count,bpm,kind in sections:
 for j in range(count):
  bar+=1
  if kind in ['intro','memory','descent','refusal']:line=copy.deepcopy(A[j%8]);h=pa[j%8]
  elif kind in ['garden','shore']:line=copy.deepcopy(B[j%8]);h=pb[j%8]
  else:
   line=copy.deepcopy([[(64,1),(63,1),(61,1),(56,2),(-1,1)],[(66,1.5),(64,.5),(61,1),(57,1),(56,1),(54,1)],[(60,1),(63,1),(68,2),(66,1),(63,1)],[(61,3),(63,1),(61,1),(-1,1)]][j]);h=['Csm','Fsm','Gs7','Csm'][j]
  assert sum(l for n,l in line)==6
  tempo=bpm if kind!='coda' else [60,58,56,50][j];vel={'intro':57,'memory':64,'descent':67,'garden':71,'refusal':69,'shore':65,'coda':55}[kind];ch=H[h]
  bars.append(dict(bar=bar,start=beat,beats=6,bpm=tempo,meter_numerator=6,meter_denominator=4,section=title,harmony_name=h,harmony=ch,role_plan=kind,phrase_position=j))
  off=0
  for n,l in line:
   if n>=0:events.append(dict(bar=bar,onset=beat+off,duration=l*.97,pitch=n,velocity=vel+(2 if off==0 else 0),voice='melody'))
   off+=l
  for t,n in [(0,ch[0]),(3,ch[0]+7)]:events.append(dict(bar=bar,onset=beat+t,duration=.55,pitch=n,velocity=vel-26,voice='bass'))
  for t,n in [(1,ch[1]),(2,ch[2]),(4,ch[1]),(5,ch[2])]:
   if kind=='coda' and j==3 and t>=3:continue
   events.append(dict(bar=bar,onset=beat+t,duration=.75,pitch=n,velocity=vel-35,voice='accompaniment'))
  for t,v in [(0,0),(.13,44),(2.90,0),(3.10,39),(5.85,0)]:pedals.append(dict(onset=beat+t,value=v))
  beat+=6
d=dict(id=70,title='The Bell Beneath the Lake',title_zh='湖底的钟',stage='v0_original_low_register_elegy',bars=bars,events=events,pedals=pedals,total_beats=beat,tail_seconds=4)
for f in ['score.json','revisions/score_v0.json']:(P/f).write_text(json.dumps(d,indent=2))
(P/'thematic_material.json').write_text(json.dumps(dict(A=A,B=B),indent=2));print(bar,sum(b['beats']*60/b['bpm'] for b in bars)+4)
