#!/usr/bin/env python3
raise SystemExit("Unsafe direct streaming entry disabled. Use Tools/SafeRegeneration/regenerate.py after reading its README and Score/RenderInputs/manifest.json.")
