from fractions import Fraction
from copy import deepcopy

def pitch(s):
 return 12*(int(s[-1])+1)+{'C':0,'D':2,'E':4,'F':5,'G':7,'A':9,'B':11}[s[0]]+s[1:-1].count('#')-s[1:-1].count('b')
def decode(line):
 result=[];t=0
 for token in line.split():
  name,units=token.split(':');dur=float(Fraction(units))/2
  if name!='R':result.append((pitch(name),t,dur))
  t+=dur
 return result,t
class Writer:
 def __init__(self):self.bars=[];self.events=[];self.pedals=[];self.start=0;self.n=0
 def bar(self,name,bpm,beats,h,ch):
  self.n+=1;self.beats=beats;self.bpm=bpm;self.ch=ch
  numerator,denominator=(int(beats*2),8) if beats in (2.5,3.5) else ((6,8) if METER=='6/8' else (int(beats),4))
  self.bars.append(dict(bar=self.n,start=self.start,beats=beats,bpm=bpm,meter_numerator=numerator,meter_denominator=denominator,section=name,harmony_name=h,harmony=ch))
 def add(self,p,t,d,v=72,inst='piano',voice='theme',hand='right',art='detached'):
  if d>0 and t<self.beats:
   self.events.append(dict(bar=self.n,onset=round(self.start+t,6),duration=round(min(d,self.beats-t),6),pitch=int(p),velocity=max(1,min(127,int(v))),instrument=inst,voice=voice,hand=hand if inst=='piano' else 'none',articulation=art))
 def line(self,line,v=80,hand='right',transpose=0):
  notes,total=decode(line);assert abs(total-self.beats)<1e-7,(self.n,total,self.beats,line)
  for p,t,d in notes:self.add(p+transpose,t,max(.11,d-.09),v+(3 if t==0 else 0),hand=hand)
  return notes
 def release(self,amount=0,length=.7):
  self.pedals.append(dict(bar=self.n,onset=self.start,controller=64,value=0,instrument='piano'))
  if amount:
   self.pedals.extend([dict(bar=self.n,onset=self.start+.05,controller=64,value=amount,instrument='piano'),dict(bar=self.n,onset=self.start+length,controller=64,value=0,instrument='piano')])
  self.start+=self.beats
 def result(self,level):
  self.pedals.append(dict(bar=self.n,onset=self.start-.01,controller=64,value=0,instrument='piano'))
  return dict(id=ID,title=TITLE,title_zh=TITLE_ZH,version=f'v{level}',bars=self.bars,events=self.events,pedals=self.pedals,total_beats=self.start,tail_seconds=5,instrument_map=INSTRUMENT_MAP)
def material(level):
 n=0
 for section,bpm,beats,texture,hs,phrase_names in BLOCKS:
  lines=[]
  for pn in phrase_names.split():lines+=P[pn].split('|')
  harmonies=hs.split();assert len(lines)==len(harmonies),(section,len(lines),len(harmonies))
  for h,line in zip(harmonies,lines):
   n+=1
   for lv,rev in [(1,REV1),(2,REV2)]:
    if level>=lv and n in rev:h,line=rev[n]
   yield n,section,bpm,beats,texture,h,line
ID=133;TITLE='Shuttle Under Night Lights';TITLE_ZH='夜灯下的羽球';METER='4/4';INSTRUMENT_MAP={'piano':'piano','flute':'flute'}
RENDERER_NOTES='4/4 with deliberately notated 2:1 swing pairs in the piano. Flute C5–B5 only, slower separated gestures. End emphatic after a bright major turn; no fade.'
H={'Gm':[43,58,62],'C9':[36,52,58],'F':[41,57,60],'Bb6':[46,55,62],'Ebmaj7':[39,55,62],'D7':[38,54,60],'Cm':[36,55,63],'A7':[45,55,61],'Gm6':[43,52,58],'E7':[40,56,62],'G6':[43,52,59],'Ab':[44,56,60]}
P={
'serve':'G5:4/3 Bb5:2/3 D6:2 Bb5:4/3 A5:2/3 G5:2|E5:4/3 G5:2/3 Bb5:2 A5:4/3 G5:2/3 E5:2|F5:4/3 A5:2/3 C6:2 A5:4/3 G5:2/3 F5:2|D5:4/3 F5:2/3 G5:2 Bb5:2 R:2',
'reply':'Bb5:2 G5:4/3 F5:2/3 D5:2 G5:2|G5:4/3 Eb5:2/3 C5:2 Eb5:4/3 G5:2/3 Bb5:2|A5:4/3 F#5:2/3 D5:2 C5:4/3 A4:2/3 F#4:2|G5:2 D5:4/3 Bb4:2/3 G4:2 R:2',
'net':'G5:4/3 D6:2/3 Bb5:4/3 G5:2/3 A5:2 G5:2|E5:4/3 Bb5:2/3 G5:4/3 E5:2/3 F5:2 E5:2|A5:4/3 C6:2/3 F6:2 E6:4/3 C6:2/3 A5:2|D6:4/3 Bb5:2/3 G5:2 F5:4/3 D5:2/3 Bb4:2',
'lob':'G5:2 Bb5:2 D6:2 R:2|E5:2 G5:2 Bb5:2 R:2|F5:2 A5:2 C6:2 R:2|F#5:2 A5:2 D6:2 R:2',
'dash':'G5:1 Bb5:1 D6:1 C6:1 Bb5:1 A5:1 G5:1 D5:1|C5:1 E5:1 G5:1 Bb5:1 A5:1 G5:1 E5:1 C5:1|F5:1 A5:1 C6:1 E6:1 D6:1 C6:1 A5:1 F5:1|D6:1 C6:1 A5:1 F#5:1 D5:2 R:2',
'miss':'R:2 D5:2 G5:2 R:2|R:4 Eb5:2 G5:2|F#5:2 D5:2 R:4|G5:2 R:6',
'corner':'Eb5:4/3 G5:2/3 Bb5:2 D6:4/3 C6:2/3 Bb5:2|E5:4/3 G5:2/3 C#6:2 B5:4/3 A5:2/3 G5:2|F#5:4/3 A5:2/3 D6:2 C6:4/3 A5:2/3 F#5:2|G5:4/3 Bb5:2/3 E6:2 D6:4/3 Bb5:2/3 G5:2',
'long':'D6:4/3 Bb5:2/3 G5:2 A5:4/3 Bb5:2/3 D6:2|C6:4/3 A5:2/3 F5:2 G5:4/3 A5:2/3 C6:2|Bb5:4/3 G5:2/3 Eb5:2 F5:4/3 G5:2/3 Bb5:2|A5:4/3 F#5:2/3 D5:2 F#5:4/3 A5:2/3 C6:2',
'bright':'B5:4/3 D6:2/3 G6:2 E6:4/3 D6:2/3 B5:2|E6:4/3 C6:2/3 G5:2 E5:4/3 G5:2/3 C6:2|D6:4/3 C6:2/3 A5:2 F#5:4/3 A5:2/3 D6:2|B5:2 G5:4/3 D5:2/3 B4:2 R:2',
'end':'G5:4/3 B5:2/3 D6:2 B5:4/3 A5:2/3 G5:2|E5:4/3 G5:2/3 C6:2 G5:4/3 E5:2/3 C5:2|F#5:4/3 A5:2/3 D6:2 C6:4/3 A5:2/3 F#5:2|G5:2 D5:2 B4:2 R:2'
}
BLOCKS=[
('First_serve',96,4,'serve','Gm C9 F Bb6 Gm Cm D7 Gm','serve reply'),
('At_the_net',104,4,'net','Gm C9 F Bb6 Gm C9 F Bb6','net net'),
('High_return',102,4,'lob','Gm C9 F D7 Gm Cm D7 Gm','lob reply'),
('Run_for_it',124,4,'dash','Gm C9 F D7 Gm C9 F D7','dash dash'),
('Laugh_after_miss',88,4,'miss','Gm Ebmaj7 D7 Gm Gm Ebmaj7 D7 Gm','miss miss'),
('Change_corners',108,4,'net','Ebmaj7 A7 D7 Gm6 Ebmaj7 A7 D7 Gm6','corner corner'),
('Long_rally',112,4,'rally','Gm F Ebmaj7 D7 Gm F Ebmaj7 D7','long long'),
('Last_run',126,4,'dash','Gm C9 F D7 Gm C9 F D7','dash dash'),
('Forget_the_score',114,4,'bright','G6 C9 D7 G6 G6 C9 D7 G6','bright bright'),
('Lights_warning',104,4,'lob','Gm C9 F D7 G6 C9 D7 G6','lob end'),
('One_more_shot',116,4,'close','G6 C9 D7 G6 G6 C9 D7 G6','bright end')]
REV1={41:('Ebmaj7','Bb5:4/3 G5:2/3 Eb5:2 D5:4/3 G5:2/3 Bb5:2'),42:('Ab','C6:4/3 Ab5:2/3 Eb5:2 F5:4/3 Ab5:2/3 C6:2'),43:('D7','F#5:4/3 A5:2/3 C6:2 D6:4/3 C6:2/3 A5:2'),44:('Gm6','Bb5:2 E5:4/3 G5:2/3 D6:2 R:2'),45:('Cm','G5:4/3 C6:2/3 Eb6:2 D6:4/3 C6:2/3 G5:2'),46:('A7','C#6:4/3 A5:2/3 G5:2 E5:4/3 C#5:2/3 A4:2'),47:('D7','F#5:4/3 D5:2/3 A4:2 C5:4/3 D5:2/3 F#5:2'),48:('Gm','G5:2 D5:4/3 Bb4:2/3 R:4')}
REV2={65:('G6','D6:4/3 B5:2/3 G5:2 E5:4/3 G5:2/3 B5:2'),66:('E7','G#5:4/3 B5:2/3 E6:2 D6:4/3 B5:2/3 G#5:2'),67:('A7','A5:4/3 C#6:2/3 E6:2 G6:4/3 E6:2/3 C#6:2'),68:('D7','F#5:2 A5:4/3 C6:2/3 D6:2 R:2'),69:('G6','B5:4/3 D6:2/3 G6:2 D6:4/3 B5:2/3 G5:2'),70:('C9','E5:4/3 G5:2/3 Bb5:2 A5:4/3 G5:2/3 E5:2'),71:('D7','A5:4/3 F#5:2/3 D5:2 C5:4/3 D5:2/3 F#5:2'),72:('G6','G5:2 B4:4/3 D5:2/3 G4:2 R:2')}
def build(level):
 w=Writer()
 for n,section,bpm,beats,style,h,line in material(level):
  ch=H[h];w.bar(section,bpm,beats,h,ch);v={'serve':79,'net':82,'lob':73,'dash':99,'miss':56,'rally':88,'bright':92,'close':98}[style];notes,total=decode(line)
  if style=='lob' and n%2:
   for q,t in zip([notes[0][0],notes[-1][0]],[.25,2.25]):w.add(72+q%12,t,1.0,72,inst='flute',voice='high_arc')
   w.add(ch[1]+12,1.5,.4,54,voice='racket_punctuation',hand='right')
  else:w.line(line,v)
  if style=='miss':
   if n%4 in (1,3):w.add(ch[0],0,.6,42,voice='one_foot_down',hand='left')
  else:
   # Swing bass is economical: low attack, then a compact offbeat dyad, not a continuous walking loop.
   w.add(ch[0],0,.42,v-21,voice='court_step',hand='left')
   t=1+2/3 if n%2 else 2+2/3
   w.add(ch[1],t,.30,v-23,voice='racket',hand='left');w.add(ch[2],t,.30,v-27,voice='racket_harmony',hand='left')
   if style in ('dash','rally'):w.add(ch[0]+12,3.5,.26,v-24,voice='next_step',hand='left')
   if level>=1 and 41<=n<=48:
    w.add(ch[0]+12,.8,.35,v-20,voice='corner_cut',hand='left')
  if style in ('serve','rally','close') and n%4==0:w.add(72+ch[2]%12,2.25,1.0,72,inst='flute',voice='shuttle_returns')
  if level>=2 and 65<=n<=72 and n%2==0:
   for q,t in zip([ch[2],ch[1]],[.25,2.25]):w.add(72+q%12,t,.95,75,inst='flute',voice='score_forgotten')
  w.release()
 return w.result(level)
