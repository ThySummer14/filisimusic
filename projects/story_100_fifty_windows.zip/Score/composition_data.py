"""Original two-theme piano finale: every foreground bar is authored here."""
LINES=[
 'E4 G#4 B4 C#5 B4 G#4 F#4 E4 | D#4 F#4 B4 A4 F#4 D#4 F#4 A4 | C#5 B4 G#4 E4 F#4 G#4 B4 C#5 | C#5 E5 F#5 E5 C#5 B4 A4 B4 | G#4 B4 E5 D#5 B4 G#4 F#4 G#4 | A4 C#5 E5 D#5 C#5 A4 F#4 A4 | F#4 A4 B4 D#5 B4 A4 F#4 D#4 | B4 G#4 F#4 E4',
 'B4 E5 F#5 G#5 F#5 E5 D#5 B4 | C#5 E5 G#5 F#5 E5 C#5 B4 C#5 | A4 C#5 F#5 E5 C#5 A4 G#4 A4 | B4 D#5 F#5 A5 F#5 D#5 C#5 B4 | G#5 F#5 E5 D#5 B4 | A5 G#5 F#5 E5 C#5 | F#5 E5 D#5 B4 A4 | E5 B4 G#4 F#4 E4',
 'C#5 E5 G#5 B5 G#5 F#5 E5 C#5 | D#5 F#5 A5 G#5 F#5 D#5 C#5 D#5 | E5 G#5 B5 A5 G#5 E5 D#5 E5 | F#5 A5 C#6 B5 A5 F#5 E5 F#5 | G#5 F#5 E5 C#5 B4 | F#5 E5 C#5 A4 G#4 | D#5 F#5 B5 A5 F#5 D#5 C#5 D#5 | E5 C#5 B4 G#4 E4',
 'G#4 C#5 E5 D#5 C#5 B4 G#4 | F#4 A4 C#5 B4 A4 G#4 F#4 | G#4 B4 D#5 C#5 B4 A4 G#4 | F#4 G#4 B4 D#5 C#5 B4 G#4 | E5 D#5 C#5 G#4 C#5 E5 | F#5 E5 C#5 A4 C#5 F#5 | D#5 C#5 B4 F#4 G#4 B4 D#5 | E5 D#5 C#5 G#4',
 'E4 G#4 C#5 D#5 C#5 B4 G#4 E4 | F#4 A4 C#5 E5 C#5 A4 G#4 F#4 | G#4 B4 D#5 F#5 D#5 B4 A4 G#4 | A4 C#5 E5 G#5 E5 C#5 B4 A4 | B4 D#5 F#5 E5 D#5 C#5 B4 | C#5 E5 G#5 F#5 E5 D#5 C#5 | A4 B4 D#5 E5 D#5 B4 A4 | G#4 B4 E5 D#5 B4 G#4',
 'A4 C#5 E5 D5 C#5 A4 | F#4 A4 C#5 B4 A4 F#4 | B4 D5 F#5 E5 D5 B4 | C#5 E5 A5 G#5 E5 C#5 | D5 F#5 A5 G#5 F#5 D5 | C#5 B4 A4 E4 A4 C#5 | B4 D5 E5 G#5 F#5 E5 | A4 E5 C#5 A4',
 'C#5 E5 F#5 A5 F#5 E5 | D5 F#5 B5 A5 F#5 D5 | E5 G#5 C#6 B5 G#5 E5 | F#5 A5 B5 C#6 B5 A5 | G#5 F#5 E5 C#5 E5 G#5 | F#5 E5 D5 B4 D5 F#5 | D#5 F#5 A5 G#5 F#5 D#5 | B4 D#5 F#5 E5 D#5 B4',
 'E5 G#5 B5 C#6 B5 G#5 F#5 E5 | D#5 F#5 B5 A5 F#5 D#5 F#5 A5 | C#6 B5 G#5 E5 F#5 G#5 B5 C#6 | C#6 D#6 C#6 B5 A5 G#5 A5 B5 | G#5 B5 C#6 B5 G#5 F#5 E5 G#5 | A5 C#6 B5 A5 G#5 F#5 G#5 A5 | F#5 A5 B5 D#6 B5 A5 F#5 | E5 B4 G#4 E4',
 'G#5 B5 D#6 C#6 B5 A5 G#5 | F#5 A5 C#6 B5 A5 G#5 F#5 | G#5 B5 C#6 B5 A5 G#5 F#5 | A5 C#6 D#6 C#6 B5 A5 G#5 | B5 A5 G#5 F#5 E5 | C#6 B5 A5 G#5 F#5 | D#6 C#6 B5 A5 F#5 | E5 G#5 B5 C#6 B5 G#5 F#5 E5',
 'C#6 B5 G#5 E5 G#5 B5 C#6 | D#6 C#6 A5 F#5 A5 C#6 D#6 | B5 C#6 D#6 C#6 B5 G#5 F#5 | C#6 D#6 E6 D#6 C#6 B5 G#5 | E6 D#6 C#6 B5 G#5 | D#6 C#6 B5 A5 F#5 | B5 A5 F#5 D#5 F#5 A5 B5 | G#5 F#5 E5 B4 E5 G#5',
 'E4 G#4 B4 C#5 B4 G#4 E4 | D#4 F#4 A4 B4 A4 F#4 D#4 | E4 G#4 C#5 B4 G#4 F#4 E4 | A4 C#5 E5 F#5 E5 C#5 B4 A4 | G#4 B4 E5 D#5 B4 G#4 F#4 G#4 | F#4 A4 C#5 E5 C#5 B4 A4 F#4 | D#5 F#5 A5 G#5 F#5 D#5 B4 | E5 D#5 B4 G#4 E4',
 'A4 C#5 E5 D5 C#5 A4 | F#4 A4 C#5 B4 A4 F#4 | B4 D5 F#5 E5 D5 B4 | C#5 E5 A5 G#5 E5 C#5 | D5 F#5 A5 B5 A5 F#5 E5 D5 | C#5 E5 A5 G#5 E5 C#5 B4 | D#5 F#5 A5 G#5 F#5 D#5 B4 | E5 B4 G#4 E4',
 'G#4 B4 E5 F#5 E5 B4 G#4 | A4 C#5 F#5 E5 C#5 B4 A4 | B4 D#5 G#5 F#5 D#5 C#5 B4 | C#5 E5 A5 G#5 E5 D#5 C#5 | B5 A5 G#5 E5 C#5 | A5 G#5 F#5 D#5 B4 | F#5 A5 B5 D#6 B5 A5 F#5 | E5 G#5 B5 G#5 F#5 E5',
 'E5 B4 G#4 E4 | D#5 B4 F#4 D#4 | C#5 G#4 E4 C#4 | C#5 E5 A5 E5 C#5 A4 | B4 D#5 F#5 E5 D#5 B4 | A4 C#5 E5 D#5 C#5 A4 | F#4 A4 B4 D#5 B4 A4 F#4 | G#4 B4 E5 B4 G#4 E4',
 'C#5 B4 G#4 E4 | A4 C#5 E5 C#5 B4 A4 | F#4 A4 C#5 B4 A4 F#4 | D#5 C#5 B4 F#4 | E5 D#5 C#5 B4 G#4 | F#5 E5 D#5 B4 A4 | D#5 B4 A4 F#4 | B4 G#4 F#4 E4',
]
HARM_ROWS=[
 'E B/D# C#m A E/G# F#m B7 E',
 'E C#m F#m B7 E A B7 E',
 'C#m F#m E A E/G# F#m B7 E',
 'C#m F#m G#m B C#m A B7 C#m',
 'C#m F#m G#m A B7 C#m B7 E',
 'A F#m Bm E7 D A E7 A',
 'F#m Bm C#m F#m E/G# Bm B7 B7',
 'E B/D# C#m A E/G# F#m B7 E',
 'G#m F#m E A E/G# F#m B7 E',
 'C#m F#m B7 A E B7 B7 E',
 'E B/D# C#m A E/G# F#m B7 E',
 'A F#m Bm E7 D A/C# B7 E',
 'E F#m G#m A C#m B B7 E',
 'E B/D# C#m A E/G# F#m B7 E',
 'C#m A F#m B7 E/G# F#m B7 E',
]
H={'E':[40,44,47],'E/G#':[44,47,52],'E/B':[47,52,56],'E(add9)':[52,54,56,59],'A':[45,49,52],'A/C#':[49,52,57],'A/E':[40,45,49],'Amaj7':[45,49,52,56],'B':[47,51,54],'B/D#':[39,42,47],'B7':[47,51,54,57],'B7/D#':[39,42,45,47],'C#m':[49,52,56],'C#m/G#':[44,49,52],'C#m/E':[40,44,49],'F#m':[42,45,49],'F#m/A':[45,49,54],'F#m/C#':[37,42,45],'G#m':[44,47,51],'G#m/B':[47,51,56],'Bm':[47,50,54],'Bm/D':[50,54,59],'E7':[40,44,47,50],'E7/G#':[44,47,50,52],'D':[38,42,45],'D/F#':[42,45,50]}
V1={
33:'G#4 C#5 E5 D#5 C#5 B4 G#4',34:'A4 C#5 E5 F#5 E5 C#5 A4',35:'B4 D#5 F#5 E5 D#5 B4 G#4',36:'C#5 E5 G#5 F#5 E5 C#5 A4',37:'D#5 F#5 A5 G#5 F#5 D#5 B4',38:'E5 G#5 F#5 E5 D#5 C#5',39:'F#5 E5 D#5 B4 A4',40:'B4 E5 D#5 B4 G#4 E4',
41:'C#5 E5 A5 G#5 E5 C#5',42:'A4 C#5 F#5 E5 C#5 A4',43:'D5 F#5 B5 A5 F#5 D5',44:'E5 G#5 A5 G#5 E5 C#5',45:'F#5 A5 G#5 F#5 D5',46:'E5 C#5 B4 A4 C#5 E5',47:'D5 E5 G#5 F#5 E5 B4',48:'C#5 E5 A5 E5 C#5 A4',
49:'A4 C#5 F#5 G#5 F#5 C#5',50:'F#5 B5 A5 F#5 D5',51:'G#5 C#6 B5 G#5 E5',52:'A5 B5 C#6 B5 A5 F#5',53:'E5 G#5 F#5 E5 C#5',54:'D5 F#5 E5 D5 B4',55:'F#5 A5 G#5 F#5 D#5',56:'D#5 F#5 E5 D#5 B4',
}
V1_H={33:'C#m/E',34:'F#m/A',35:'G#m/B',36:'Amaj7',37:'B7/D#',38:'C#m/G#',39:'B7/D#',41:'Amaj7',42:'F#m/A',43:'Bm/D',44:'E7/G#',45:'D/F#',46:'A/E',47:'E7/G#',49:'F#m/C#',50:'Bm/D',51:'C#m/E',52:'F#m/A',53:'E/B',54:'Bm/D',55:'B7/D#'}
V2={
73:'E5 G#5 B5 C#6 B5 G#5 E5',74:'F#5 A5 C#6 D#6 C#6 A5 F#5',75:'G#5 B5 D#6 C#6 B5 A5 G#5',76:'B5 C#6 E6 D#6 C#6 B5 G#5',77:'E6 D#6 B5 G#5 B5 C#6 B5',78:'D#6 B5 A5 F#5 A5 B5 C#6',79:'F#5 A5 B5 D#6 B5 A5 F#5',80:'G#5 E5 D#5 B4 G#4',
81:'E4 G#4 B4 C#5 B4 G#4 F#4 E4',82:'F#4 A4 B4 A4 F#4 D#4',83:'G#4 C#5 E5 D#5 C#5 B4 G#4',84:'C#5 E5 F#5 E5 C#5 B4 A4',85:'B4 E5 F#5 G#5 F#5 E5 D#5 B4',86:'C#5 F#5 E5 C#5 B4 A4',87:'F#5 A5 G#5 F#5 D#5 B4',88:'G#4 B4 E5 D#5 B4 G#4 E4',
89:'C#5 E5 A5 G#5 E5 C#5',90:'A4 C#5 F#5 E5 C#5 A4',91:'D5 F#5 B5 A5 F#5 D5',92:'E5 G#5 A5 G#5 E5 C#5',93:'F#5 A5 B5 A5 F#5 E5 D5',94:'E5 C#5 B4 A4 C#5 E5',95:'F#5 A5 G#5 F#5 D#5 B4',96:'G#4 B4 E5 B4 G#4 E4',
97:'B4 E5 F#5 G#5 F#5 E5 B4',98:'C#5 F#5 G#5 F#5 E5 C#5 A4',99:'D#5 G#5 F#5 D#5 C#5 B4',100:'E5 A5 G#5 E5 D#5 C#5',101:'G#5 B5 A5 G#5 E5 C#5',102:'F#5 A5 G#5 F#5 D#5 B4',103:'A5 B5 D#6 B5 A5 F#5',104:'G#5 E5 D#5 B4 E5',
113:'G#4 B4 C#5 B4 G#4 E4',114:'C#5 E5 D#5 C#5 A4',115:'A4 C#5 B4 A4 F#4',116:'B4 D#5 C#5 B4 F#4',117:'G#4 B4 E5 D#5 B4 G#4',118:'A4 C#5 E5 D#5 C#5 A4',119:'F#4 A4 B4 D#5 B4 F#4',120:'B4 G#4 F#4 E4',
}
V2_H={73:'C#m/E',74:'F#m/A',75:'B7/D#',76:'Amaj7',77:'E/B',78:'B7/D#',79:'B7/D#',81:'E(add9)',82:'B/D#',83:'C#m/G#',84:'A/C#',85:'E/B',86:'F#m/A',87:'B7/D#',89:'Amaj7',90:'F#m/A',91:'Bm/D',92:'E7/G#',93:'D/F#',94:'A/E',95:'B7/D#',97:'E/B',98:'F#m/C#',99:'G#m/B',100:'A/C#',101:'C#m/E',102:'B/D#',103:'B7/D#',104:'E/G#',113:'C#m/E',114:'A/E',115:'F#m/A',116:'B7/D#',117:'E/B',118:'F#m/A'}
LABELS=['从第一排开始','把手套翻到干的一面','沿同一高度逐扇推回','第二十七号窗前停下','把那道磨痕记下来','展开留下的时刻表','另一行铅笔字','脚步重新接上','远处的早班车灯','最后一段较快的复查','从原路看第二遍','把纸折回原来的线','重新试过的窗扣','等维修记录写完','把检查表压在夹板上']
SECTIONS=[(1,24,'A','第一轮窗扣检查','E major'),(25,40,'B','第二十七号的磨痕','C-sharp minor'),(41,56,'C','椅面上的旧时刻表','A major'),(57,80,'D','灯光逐排亮起','E major'),(81,104,'A2','复查同一条走廊','E major'),(105,120,'Coda','交班前的最后几行','E major')]
def section(n):return next(x for x in SECTIONS if x[0]<=n<=x[1])
def bpm(n):
 if n<=24:return 126 if n%8 else 120
 if n<=40:return 118 if n%8 else 112
 if n<=56:return 94 if n%8 else 90
 if n<=80:return 130 if n%8 else 124
 if n<=104:return 120 if n%8 else 114
 return [110,110,108,108,106,106,104,102,104,102,100,98,98,96,94,90][n-105]
