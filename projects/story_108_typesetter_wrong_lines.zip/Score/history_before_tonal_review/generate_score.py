"""Original108: piano two-beat toccata with actual low-voice subject entries."""
from pathlib import Path
import json,difflib,sys
P=Path(__file__).resolve().parent;sys.path.insert(0,str(P));from composition_data import *
def pitch(s):return 12*(int(s[-1])+1)+{'C':0,'D':2,'E':4,'F':5,'G':7,'A':9,'B':11}[s[0]]+s[1:-1].count('#')-s[1:-1].count('b')
def section(n):
 if n<=16:return 'Opening','活字签名',116,73,2
 if n<=48:return 'A','两行先后进入',120,83,2
 if n<=72:return 'B','试印反读',128,94,2
 if n<=88:return 'C','一字一格的空白',80,43,4
 if n<=128:return 'R','重排的两条线',120,82,2
 if n<=152:return 'F','最终校样',126,92,2
 return 'Coda','留下的空格',84,48,4

def build(level):
 hs=[];lines=[]
 for key in ORDER:
  h,s=BLOCKS[key];hs+=h.split();lines+=s.split('|')
 assert len(lines)==len(hs)==160
 for lv,rd,hd in [(1,REV1,HREV1),(2,REV2,HREV2)]:
  if level>=lv:
   for n,s in rd.items():lines[n-1]=s
   for n,h in hd.items():hs[n-1]=h
 bars=[];events=[];pedals=[];start=0.
 for n,(line,h) in enumerate(zip(lines,hs),1):
  sec,label,bpm,dyn,beats=section(n);ch=H[h];low=n<=8 or sec=='C';canon=(17<=n<=48 or 89<=n<=144)
  if n in [16,48,72,88,128,152]:bpm-=4
  if n>=157:bpm-=2*(n-156)
  bars.append(dict(bar=n,start=start,beats=beats,bpm=bpm,meter=f'{beats}/4',meter_numerator=beats,meter_denominator=4,section=sec,section_title_zh=label,harmony_name=h,harmony=ch,key_region='A/E major' if sec=='C' else 'C# minor',texture='imitative_lower_subject' if canon else 'low_voice_cantabile' if low else 'toccata_question_and_answer',role_plan='Only actual independent lines are called counterpoint; not a claim of a full classical fugue.'))
  def add(p,t,d,v,voice,hand):
   assert 0<=t<t+d<=beats+.00001,(n,t,d,beats)
   events.append(dict(bar=n,onset=round(start+t,6),duration=round(d,6),pitch=p,velocity=int(v),instrument='piano',voice=voice,hand=hand,harmony_name=h,phrase_id=f'{sec}_{(n-1)//4}',role='lead' if voice in ['melody','imitative_subject'] else 'support',articulation='toccata_detachment_or_blank_space',written_value_beats=d))
  at=0.;melody=[]
  for i,tok in enumerate(line.split()):
   name,u=tok.split(':');dur=float(u)/2
   if name!='R':
    p=pitch(name)-(12 if n<=8 else 0);melody.append(p);add(p,at,max(.08,dur-.07),dyn+(4 if at==0 and not low else 0)-(4 if i==len(line.split())-1 else 0),'melody','left' if low else 'right')
   at+=dur
  assert at==beats,(n,at,beats)
  if low:
   if n<=8 and n%2:add(76,1,.40,dyn-26,'upper_punctuation','right')
   elif sec=='C' and n%4==1:add(80,2,.65,dyn-19,'distant_upper_reply','right')
  elif canon:
   root=ch[0]
   if root<47:root+=12
   if root>56:root-=12
   if n%2:
    offsets=[0,7,-2,2,3];durations=[.25,.25,.5,.5,.5]
   else:offsets=[8,7,0];durations=[.5,.5,1]
   major=not ('m' in h and 'maj' not in h)
   if major:offsets=[4 if q==3 else q for q in offsets]
   if level>=1 and 33<=n<=48 and n%2:offsets=[0,7,3,2,-2]
   if level>=2 and 89<=n<=128 and n%4==2:offsets=[7,8,0]
   if level>=2 and n in [96,120,128,136]:offsets=[0];durations=[.65]
   t=0.
   for p,d in zip(offsets,durations):add(root+p,t,max(.08,d-.07),dyn-19,'imitative_subject','left');t+=d
  elif sec=='Coda':
   pats=[(0,ch[0],1.1),(2,ch[1],1.3)] if n!=160 else [(0,ch[0],.65)]
   for t,p,d in pats:
    if p>=min(melody):p-=12
    add(p,t,d,dyn-14,'closing_lower_line','left')
  else:
   pat=[(0,ch[0],.3),(1,ch[2],.32)]
   if n%4==2:pat=[(.5,ch[1],.27),(1.5,ch[0],.27)]
   if level>=1 and 49<=n<=64:pat=[(.5,ch[0],.25),(1.5,ch[1],.27)]
   if n in [16,64,72,152]:pat=[(0,ch[0],.45)]
   for t,p,d in pat:add(p,t,d,dyn-26,'lower_spacing','left')
  pedals.append(dict(bar=n,onset=start,controller=64,value=0,instrument='piano'))
  if beats==4:
   pedals +=[dict(bar=n,onset=start+.06,controller=64,value=33,instrument='piano'),dict(bar=n,onset=start+1.65,controller=64,value=0,instrument='piano'),dict(bar=n,onset=start+2.12,controller=64,value=26,instrument='piano'),dict(bar=n,onset=start+3.82,controller=64,value=0,instrument='piano')]
  start+=beats
 events.sort(key=lambda e:(e['onset'],e['pitch']))
 for i,e in enumerate(events):e['event_id']=f'w108-v{level}-{i:04d}'
 return dict(id=108,title='The Typesetter’s Reversed Lines',title_zh='排字工的错行',version=f'v{level}',bars=bars,events=events,pedals=pedals,total_beats=start,tail_seconds=5,instrumentation=['piano'],performance_contract='Original sample-based solo piano with independently written imitative entries; no claim of live performance or completed human listening.')
for v in range(3):
 d=build(v);(P/f'score_v{v}.json').write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n');report=dict(version=f'v{v}',bars=160,notes=len(d['events']),duration_seconds=sum(b['beats']*60/b['bpm'] for b in d['bars'])+5,human_listening_review=False);(P/f'audit_v{v}.json').write_text(json.dumps(report,indent=2))
 if v:
  old=build(v-1);changed=[]
  for n in range(1,161):
   clean=lambda e:{k:x for k,x in e.items() if k!='event_id'}
   if [clean(e) for e in old['events'] if e['bar']==n]!=[clean(e) for e in d['events'] if e['bar']==n]:changed.append(n)
  a=(P/f'score_v{v-1}.json').read_text();b=(P/f'score_v{v}.json').read_text();(P/f'exact_diff_v{v-1}_to_v{v}.patch').write_text(''.join(difflib.unified_diff(a.splitlines(True),b.splitlines(True),f'score_v{v-1}.json',f'score_v{v}.json')));(P/f'exact_diff_v{v-1}_to_v{v}.json').write_text(json.dumps({'changed_bars':changed,'count':len(changed)},indent=2))
for name in ['score.json','ensemble_score.json','piano_score.json']:(P/name).write_text((P/'score_v2.json').read_text())
print(json.dumps(report));print([json.loads((P/f'exact_diff_v{i}_to_v{i+1}.json').read_text())['count'] for i in range(2)])
