"""117: two individually written piano lines, broad six-quarter phrases and low woodwind answers."""
from pathlib import Path
import json,sys,bisect
P=Path(__file__).resolve().parent;sys.path.insert(0,str(P));from composition_data import *
PARAM={'threshold':('蓝门留着一道缝',96,48),'outline':('镜中轮廓',108,66),'scrape':('擦去急促的线',116,88),'mirror':('看清自己的目光',100,43),'open':('把半扇门推开',112,76),'portrait':('画布上的呼吸',88,46)}
WIND={3:[70],5:[68],7:[66],9:[65,61],11:[68,60],13:[70,66],15:[66,63],17:[65,61],19:[66,63],21:[70,66],22:[65],30:[60],31:[65,61],32:[70,65],33:[68,65],34:[70,65],35:[66,63],36:[60,63],37:[65,61],38:[70,66],39:[66,70],40:[60,63],41:[65,61],42:[65],44:[70],46:[68],48:[60],50:[62],52:[60],54:[70,66],56:[66,63],58:[65,61],59:[70],60:[65]}
def write(p,x):p.write_text(json.dumps(x,ensure_ascii=False,separators=(',',':'))+'\n')
def pitch(s):return 12*(int(s[-1])+1)+{'C':0,'D':2,'E':4,'F':5,'G':7,'A':9,'B':11}[s[0]]+s[1:-1].count('#')-s[1:-1].count('b')
def build(level):
 rows=[]
 for sec,hs,upper,lower in GROUPS:assert len(hs.split())==len(upper)==len(lower),(sec,len(hs.split()),len(upper),len(lower));rows.extend(zip([sec]*len(upper),hs.split(),upper,lower))
 assert len(rows)==60
 events=[];bars=[];pedals=[]
 for n,(sec,h,upper,lower) in enumerate(rows,1):
  if n==60 and level<2:lower='Db2:4 Ab2:2 F3:2 Bb2:2 Db3:2'
  if level>=1:upper=REV1.get(n,upper);lower=LOW1.get(n,lower)
  if level>=2:upper=REV2.get(n,upper);lower=LOW2.get(n,lower)
  label,bpm,dyn=PARAM[sec];start=(n-1)*6
  if n>=58:bpm-=2*(n-57)
  bars.append(dict(bar=n,start=start,beats=6,bpm=bpm,meter='6/4',meter_numerator=6,meter_denominator=4,section=sec,section_title_zh=label,harmony_name=h,harmony=H[h],key_region='D-flat major; B-flat dominant points toward E-flat minor'))
  def add(p,t,d,v,inst,voice,hand='none'):
   assert 0<=t<t+d<=6.00001,(n,t,d)
   events.append(dict(bar=n,onset=round(start+t,6),duration=round(d,6),pitch=p,velocity=int(v),instrument=inst,voice=voice,hand=hand))
  for line,hand,voice in [(upper,'right','portrait_theme'),(lower,'left','independent_lower_line')]:
   at=0;tokens=line.split()
   for i,tok in enumerate(tokens):
    name,u=tok.split(':');dur=float(u)/2
    if name!='R':
     v=dyn if hand=='right' else dyn-15
     if hand=='right':v+=4 if at==0 and sec in ['outline','scrape','open'] else -5 if i==len(tokens)-1 else 0
     if level>=2 and 42<=n<=53 and hand=='left':v+=4 if n in [43,47,51] else -3
     add(pitch(name),at,dur-.075,v,'piano',voice,hand)
    at+=dur
   assert at==6,(n,line,at)
  wind=WIND.get(n,[])
  if level>=2 and 42<=n<=53:wind=[65] if n==42 else [70] if n==44 else [60] if n==48 else [66] if n==51 else []
  if level>=2 and n>=58:wind=[65] if n==58 else []
  at=[3.3,4.8] if sec=='mirror' else [.5,3.8] if len(wind)>1 else [3.8]
  body=.62 if sec=='mirror' else .88 if sec in ['threshold','portrait'] else .80
  for t,p in zip(at,wind):add(p,t,body*bpm/60,49 if sec in ['threshold','mirror','portrait'] else 64,'clarinet','unhurried_answer')
  pedals.append(dict(bar=n,onset=start,controller=64,value=0,instrument='piano'))
  if sec in ['threshold','mirror','portrait']:
   pedals.extend([dict(bar=n,onset=start+.08,controller=64,value=25,instrument='piano'),dict(bar=n,onset=start+2.8,controller=64,value=0,instrument='piano')])
 events.sort(key=lambda e:(e['onset'],e['instrument'],e['pitch']))
 for i,e in enumerate(events):e['event_id']=f'117-v{level}-{i}'
 return dict(id=117,title='The Half-open Blue Door',title_zh='半开的蓝门',version=f'v{level}',bars=bars,events=events,pedals=pedals,total_beats=360,tail_seconds=5,instrument_map={'piano':'piano','clarinet':'clarinet'},performance_contract='Original two explicit piano lines with broad six-quarter phrasing and breath-separated low clarinet responses; sampled instruments, no live or human-listening claim.')
def proj(d,n):return {'bar':d['bars'][n-1],'events':[{k:v for k,v in e.items() if k!='event_id'} for e in d['events'] if e['bar']==n],'pedals':[e for e in d['pedals'] if e['bar']==n]}
for v in range(3):
 d=build(v);write(P/f'score_v{v}.json',d);report=dict(version=f'v{v}',bars=60,events=len(d['events']),duration_seconds=sum(b['beats']*60/b['bpm'] for b in d['bars'])+5,human_listening_review=False);write(P/f'audit_v{v}.json',report)
 if v:
  a=build(v-1);changes=[{'bar':n,'before':proj(a,n),'after':proj(d,n)} for n in range(1,61) if proj(a,n)!=proj(d,n)];write(P/f'exact_diff_v{v-1}_to_v{v}.json',{'count':len(changes),'changed_bars':[x['bar'] for x in changes],'comparison_excludes':['version','event_id'],'changes':changes});lines=[]
  for x in changes:
   lines.append(f"BAR {x['bar']}\n")
   for side in ['before','after']:
    q=x[side];lines.append(side+' '+q['bar']['harmony_name']+' '+str([(e['instrument'],e['voice'],e['onset'],e['pitch'],e['duration'],e['velocity']) for e in q['events']])+'\n')
  (P/f'exact_diff_v{v-1}_to_v{v}.patch').write_text(''.join(lines))
write(P/'score.json',d);write(P/'ensemble_score.json',d)
for inst in ['piano','clarinet']:write(P/f'{inst}_score.json',{**d,'events':[e for e in d['events'] if e['instrument']==inst],'pedals':d['pedals'] if inst=='piano' else []})
starts=[b['start'] for b in d['bars']];times=[];t=0
for b in d['bars']:times.append(t);t+=b['beats']*60/b['bpm']
def sec(t):
 i=max(0,bisect.bisect_right(starts,t)-1);return times[i]+(t-starts[i])*60/d['bars'][i]['bpm']
w=sorted([e for e in d['events'] if e['instrument']=='clarinet'],key=lambda e:e['onset']);gaps=[sec(b['onset'])-sec(a['onset']+a['duration']) for a,b in zip(w,w[1:])];assert min(gaps)>=.14;print(json.dumps({**report,'clarinet_min_gap_seconds':min(gaps)}))
