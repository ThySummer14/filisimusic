#!/usr/bin/env python3
"""Bounded corruption tests of independent score checks; no score files edited."""
from pathlib import Path
import copy,json,importlib.util,sys
sys.dont_write_bytecode=True
root=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('independent_090',root/'verify_symbolic.py');v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v)
base=v.load('score_v2.json');results=[]
def check(name,edit,expected):
 s=copy.deepcopy(base);edit(s);r=v.inspect(s);passed=not r['passed'] and expected in r['errors'];results.append({'case':name,'expected_error':expected,'rejected':not r['passed'],'expected_error_found':expected in r['errors'],'passed':passed})
def first(s,p):return next(e for e in s['events'] if p(e))
check('clarinet_gate_too_short',lambda s:first(s,lambda e:e['instrument']=='clarinet').update(duration=.03),'natural clarinet gate window')
check('clarinet_pitch_outside_recorded_bank',lambda s:first(s,lambda e:e['instrument']=='clarinet').update(pitch=72,source_pitch_midi=72),'recorded clarinet range, no transpose')
check('wrong_recorded_layer',lambda s:first(s,lambda e:e['instrument']=='clarinet' and e['layer']=='pp').update(layer='ff',sample_layer='ff'),'actual clarinet layer by velocity')
def collide(s):
 e=first(s,lambda e:e['instrument']=='piano' and e['hand']=='right' and e['onset']==0);e['pitch']=first(s,lambda e:e['instrument']=='piano' and e['hand']=='left' and e['onset']==0)['pitch']
check('same_key_collision_between_hands',collide,'no same-key overlap across hands')
def span(s):
 es=[e for e in s['events'] if e['bar']==144 and e['hand']=='left'];max(es,key=lambda e:e['pitch'])['pitch']=min(e['pitch'] for e in es)+13
check('held_span_over_octave',span,'held hand span')
def transfer(s):
 audit=v.load('audit_v2.json');t=next(x for x in audit['strict_transfers'] if max(x['actual_grip_edge_travel_semitones'],x['position_edge_travel_semitones'])>4);es=[e for e in s['events'] if e['instrument']=='piano' and e['hand']==t['hand'] and e['onset']<t['onset']];e=max(es,key=lambda e:e['onset']+e['duration']);e['duration']=t['onset']-e['onset']-.001
check('insufficient_real_release_before_travel',transfer,'actual whole-hand released transfer')
a=v.load('score_v0.json');b=v.load('score_v1.json');d=v.load('exact_diff_v0_to_v1.json');d['changes']=d['changes'][1:];r=v.verify_diff(a,b,d);results.append({'case':'missing_revision_bar','rejected':not r['passed'],'passed':not r['passed'] and not r['full_score_reconstruction_equal']})
report={'passed':all(r['passed'] for r in results),'method':'Corrupt in-memory copies of final disk score; import only independent verifier, never generator. No delivered score edited.','cases':results};v.save('verifier_regression_report.json',report);print(json.dumps(report,indent=2));raise SystemExit(not report['passed'])
