"""Restored nominal-score writer from visible task history. No audio work.
The original score serializer is retained; technical audits are rerun locally.
"""
from pathlib import Path
from collections import defaultdict,Counter
import json,hashlib
P=Path(__file__).resolve().parent
D=json.loads((P/'composition_data.json').read_text())
def dump(p,x): (P/p).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def canon(x): return json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':'))
def pitch(n):return 12*(int(n[-1])+1)+{'C':0,'D':2,'E':4,'F':5,'G':7,'A':9,'B':11}[n[0]]+n[1:-1].count('#')-n[1:-1].count('b')
def decode(line):
 t=0.;o=[]
 for token in line.split():
  n,d=token.split(':');d=float(d)/2
  if n!='R':o.append((pitch(n),t,d))
  t+=d
 return o,t
def build(ver):
 bars=[];events=[];pedals=[];start=0
 for n,row in enumerate(D['versions'][ver],1):
  beats=row['numerator']*4/row['denominator'];bars.append(dict(bar=n,start=start,beats=beats,bpm=row['bpm'],meter_numerator=row['numerator'],meter_denominator=row['denominator'],meter=str(row['numerator'])+'/'+str(row['denominator']),section=row['section'],harmony_name=row['harmony_name'],harmony=D['harmonies'][row['harmony_name']]))
  for hand,key in [('right','right'),('left','left')]:
   line,total=decode(row[key]);assert abs(total-beats)<1e-8,(n,key,total,beats)
   velocities=row[key+'_velocities'];assert len(velocities)==len(line),(n,key,len(line),velocities)
   for (p,t,d),v in zip(line,velocities):events.append(dict(bar=n,onset=start+t,duration=round(max(.10,d-.075),6),pitch=p,velocity=v,instrument='piano',voice='upper_subject' if hand=='right' else 'lower_subject',hand=hand,articulation='detached' if d<=.75 else 'tenuto'))
  for e in row.get('piano_accents',[]):
   events.append(dict(bar=n,onset=start+e['onset'],duration=e['duration'],pitch=pitch(e['note']),velocity=e['velocity'],instrument='piano',voice='accent_dyad',hand=e['hand'],articulation='accent'))
  for e in row.get('solo',[]):
   inst=D['solo_instrument'];art=D['solo_articulation'];events.append(dict(bar=n,onset=start+e['onset'],duration=e['duration'],pitch=pitch(e['note']),velocity=e['velocity'],instrument=inst,voice='independent_solo',hand='none',articulation=art))
  pedals.append(dict(bar=n,onset=start,value=0,controller=64,instrument='piano'))
  start+=beats
 pedals.append(dict(bar=len(bars),onset=start-.01,value=0,controller=64,instrument='piano'))
 events.sort(key=lambda e:(e['onset'],e['instrument'],e['pitch']))
 for i,e in enumerate(events):e['event_id']=f"{D['id']}-{ver}-{i:05d}"
 return dict(id=D['id'],title=D['title'],title_zh=D['title_zh'],version=ver,bars=bars,events=events,pedals=pedals,total_beats=start,tail_seconds=5,instrument_map=D['instrument_map'],performance_contract='Original nominal sample-based instrumental score. No onset precompensation is stored. Symbolic checks are not subjective listening review. No audio has been rendered in this package.')
def validate(s):
 errors=[];bars={b['bar']:b for b in s['bars']};positions={};run=0
 for b in s['bars']:positions[b['bar']]=run;run+=b['beats']*60/b['bpm']
 def sec(e):b=bars[e['bar']];return positions[e['bar']]+(e['onset']-b['start'])*60/b['bpm']
 for e in s['events']:
  b=bars[e['bar']]
  if not b['start']<=e['onset']<e['onset']+e['duration']<=b['start']+b['beats']+1e-8:errors.append(['out_of_bar',e])
  if not isinstance(e['pitch'],int) or not 21<=e['pitch']<=108 or not 1<=e['velocity']<=127:errors.append(['bad_pitch_velocity',e])
  if e['instrument']=='clarinet' and not 60<=e['pitch']<=71:errors.append(['range',e])
  if e['instrument']=='cello' and not ((s['instrument_map']['cello']=='pizz' and 36<=e['pitch']<=47) or(s['instrument_map']['cello']=='arco' and 50<=e['pitch']<=59)):errors.append(['range',e])
 keys=defaultdict(list)
 for e in s['events']:
  if e['instrument']=='piano':keys[e['pitch']].append(e)
 for p,ee in keys.items():
  for a,b in zip(ee,ee[1:]):
   if a['onset']+a['duration']>b['onset']+1e-7:errors.append(['same_key_overlap',p,a['bar'],b['bar']])
 maxspan=0;maxkeys=0;piano=[e for e in s['events'] if e['instrument']=='piano']
 for t in sorted(set(e['onset'] for e in piano)):
  held={h:[e['pitch'] for e in piano if e['hand']==h and e['onset']<=t+1e-8 and e['onset']+e['duration']>t+1e-8] for h in ['left','right']}
  for h,pp in held.items():
   if pp:maxspan=max(maxspan,max(pp)-min(pp));maxkeys=max(maxkeys,len(pp))
   if pp and(max(pp)-min(pp)>12 or len(pp)>5):errors.append(['hand_span_or_keys',h,t,pp])
  if held['left'] and held['right'] and max(held['left'])>=min(held['right']):errors.append(['hand_crossing',t,held])
 solo=[e for e in s['events'] if e['instrument']!='piano'];timing=[];delays=D.get('sample_onset_delays_seconds',{})
 def delay(e):return delays.get(('pp' if e['velocity']<=55 else 'mf')+':'+str(e['pitch']),0.)
 for i,e in enumerate(solo):
  nominal_d=e['duration']*60/bars[e['bar']]['bpm'];de=delay(e);gate=nominal_d+de
  minimum=.3 if D.get('solo_articulation')=='short_bow' else .0;maxgate=1.15 if D.get('solo_articulation')=='short_bow' else 1.6
  if D.get('solo_articulation')!='pizzicato' and (nominal_d<minimum-1e-8 or gate>maxgate+1e-8):errors.append(['sample_gate_or_effective_body',e['bar'],nominal_d,gate])
  row=dict(bar=e['bar'],pitch=e['pitch'],layer='pp' if e['velocity']<=55 else 'mf',nominal_onset_seconds=sec(e),nominal_off_seconds=sec(e)+nominal_d,sample_delay_seconds=de,effective_body_seconds=nominal_d,compensated_trigger_gate_seconds=gate)
  if i:
   prev=solo[i-1];gap=sec(e)-de-(sec(prev)+prev['duration']*60/bars[prev['bar']]['bpm']);limit=.20 if D.get('solo_articulation')=='short_bow' else .14 if e['instrument']=='clarinet' else 0
   row['gap_after_compensation_seconds']=gap
   if gap<limit-1e-8:errors.append(['trigger_gap',e['bar'],gap,limit])
  timing.append(row)
 if not 180<=run+5<=240:errors.append(['duration',run+5])
 if s['pedals'][-1]['value']!=0:errors.append(['pedal_final'])
 tensions=[];unresolved=[];byvoice=defaultdict(list)
 for e in s['events']:byvoice[(e['instrument'],e['voice'])].append(e)
 for vv,ee in byvoice.items():
  for i,e in enumerate(ee):
   b=bars[e['bar']];pcs={p%12 for p in b['harmony']}
   if e['pitch']%12 in pcs:continue
   nxt=next((x for x in ee[i+1:] if 0<x['onset']-e['onset']<=1.5+1e-8 and x['pitch']%12 in {p%12 for p in bars[x['bar']]['harmony']} and abs(x['pitch']-e['pitch'])<=2),None)
   strong=abs((e['onset']-b['start'])-round(e['onset']-b['start']))<1e-6
   item=dict(bar=e['bar'],instrument=e['instrument'],voice=e['voice'],pitch=e['pitch'],onset_in_bar=e['onset']-b['start'],harmony=b['harmony_name'],strong_integer_quarter_position=strong,intent='Locally resolved melodic appoggiatura, passing note or neighbour; explicit pitches retained as harmonic tension.',resolution=None if nxt is None else dict(bar=nxt['bar'],onset_in_bar=nxt['onset']-bars[nxt['bar']]['start'],pitch=nxt['pitch']))
   tensions.append(item)
   if nxt is None:unresolved.append(item)
 if unresolved:errors.append(['unresolved_nonchord_tones',unresolved])
 report=dict(id=s['id'],version=s['version'],pass_all_symbolic_checks=not errors,errors=errors,bars=len(s['bars']),events=len(s['events']),duration_seconds=round(run+5,3),nominal_duration_without_tail_seconds=round(run,3),instrument_counts=dict(Counter(e['instrument'] for e in s['events'])),piano_active_hand_span_max_semitones=maxspan,piano_max_simultaneous_keys_per_hand=maxkeys,piano_no_same_key_overlap=not any(x[0]=='same_key_overlap' for x in errors),piano_no_crossing=not any(x[0]=='hand_crossing' for x in errors),final_pedal_released=True,pedal_crosses_harmony=False,nominal_onsets_uncompensated=True,unresolved_nonchord_tones=len(unresolved),intentional_nonchord_tones=len(tensions),audio_rendered=False,human_listening_review=False,scope='Symbolic validity and prospective sample triggering only; not an auditory quality verdict.')
 return report,tensions,timing
def stripped(s,n):return dict(bar=s['bars'][n-1],events=[{k:v for k,v in e.items() if k not in ['event_id','version']} for e in s['events'] if e['bar']==n],pedals=[e for e in s['pedals'] if e['bar']==n])
scores=[]
for ver in ['v0','v1','v2']:
 s=build(ver);scores.append(s);report,tensions,timing=validate(s)
 dump('score_'+ver+'.json',s);dump('validation_'+ver+'.json',report);dump('tension_resolution_'+ver+'.json',tensions);dump('sample_timing_'+ver+'.json',timing)
 if not report['pass_all_symbolic_checks']:print(ver,json.dumps(report['errors'],ensure_ascii=False));raise SystemExit(1)
diffs=[]
for i in [0,1]:
 old,new=scores[i:i+2];changes=[]
 for n in range(1,len(new['bars'])+1):
  a,b=stripped(old,n),stripped(new,n)
  if canon(a)!=canon(b):
   ca=Counter(canon(e) for e in a['events']);cb=Counter(canon(e) for e in b['events']);changes.append(dict(bar=n,notes_removed=sum((ca-cb).values()),notes_added=sum((cb-ca).values()),before=a,after=b))
 diff=dict(excluded_fields=['event_id','version'],changed_bars=[x['bar'] for x in changes],bar_count=len(changes),count=len(changes),notes_removed=sum(x['notes_removed'] for x in changes),notes_added=sum(x['notes_added'] for x in changes),evidence=changes)
 assert len(changes)>=8;dump(f'exact_diff_v{i}_to_v{i+1}.json',diff);diffs.append({k:v for k,v in diff.items() if k!='evidence'})
(P/'score.json').write_bytes((P/'score_v2.json').read_bytes())
ready=dict(id=D['id'],title=D['title'],title_zh=D['title_zh'],status='nominal_score_ready_for_independent_review_and_render',self_contained_rebuild='python generate_score.py',final_score='score.json',versions=['v0','v1','v2'],duration_seconds=validate(scores[-1])[0]['duration_seconds'],instrument_map=D['instrument_map'],nominal_onsets_no_sample_compensation=True,audio_rendered=False,human_listening_review=False,actual_revision_changes=diffs,revision_evidence=['exact_diff_v0_to_v1.json','exact_diff_v1_to_v2.json'],renderer_notes=D['renderer_notes'])
dump('READY_FOR_RENDER.json',ready)
files=[p for p in P.iterdir() if p.is_file() and p.name not in ['hashes.json'] and p.suffix!='.zip'];dump('hashes.json',{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(files)})
print(D['id'],ready['duration_seconds'],'revision bars',[x['bar_count'] for x in diffs],hashlib.sha256((P/'score.json').read_bytes()).hexdigest())
