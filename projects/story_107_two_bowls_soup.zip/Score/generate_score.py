"""Work107: warm second-beat dance, argument and shared afterglow."""
from pathlib import Path
import json,difflib,sys,bisect
P=Path(__file__).resolve().parent;sys.path.insert(0,str(P));from composition_data import *
def pitch(s):return 12*(int(s[-1])+1)+{'C':0,'D':2,'E':4,'F':5,'G':7,'A':9,'B':11}[s[0]]+s[1:-1].count('#')-s[1:-1].count('b')
def section(n):
 if n<=8:return 'Intro','餐桌上的试步',108,63
 if n<=32:return 'A','锅与热汤',112,77
 if n<=56:return 'B','谁把它带走',120,91
 if n<=72:return 'C','先把火关小',72,44
 if n<=96:return 'R','把做法写下来',108,75
 if n<=112:return 'F','两碗摆好',112,85
 return 'Coda','留下的一点余温',84,49

def build(level):
 hs=[];lines=[]
 for key in ORDER:
  h,s=BLOCKS[key];hs+=h.split();lines+=s.split('|')
 assert len(lines)==len(hs)==120
 for lv,rd,hd in [(1,REV1,HREV1),(2,REV2,HREV2)]:
  if level>=lv:
   for n,s in rd.items():lines[n-1]=s
   for n,h in hd.items():hs[n-1]=h
 bars=[];events=[];pedals=[]
 for n,(line,h) in enumerate(zip(lines,hs),1):
  sec,label,bpm,dyn=section(n);ch=H[h];start=3*(n-1)
  if n in [8,32,56,72,96,112]:bpm-=4
  if n>=117:bpm-=2*(n-116)
  bars.append(dict(bar=n,start=start,beats=3,bpm=bpm,meter='3/4',meter_numerator=3,meter_denominator=4,section=sec,section_title_zh=label,harmony_name=h,harmony=ch,key_region='Ab major' if sec=='C' else 'C minor' if sec=='B' else 'Eb major',metrical_grouping='second-quarter lift, not equal three beats',texture='warm_mazurka_and_short_bowed_responses'))
  def add(p,t,d,v,inst,voice,hand='none'):
   assert 0<=t<t+d<=3.00001,(n,t,d)
   events.append(dict(bar=n,onset=round(start+t,6),duration=round(d,6),pitch=p,velocity=int(v),instrument=inst,voice=voice,hand=hand,harmony_name=h,phrase_id=f'{sec}_{(n-1)//4}',role='lead' if voice=='melody' else 'support',articulation='second_beat_lift_and_breath',written_value_beats=d))
  at=0.;pitches=[]
  for i,tok in enumerate(line.split()):
   name,u=tok.split(':');dur=int(u)/2
   if name!='R':
    p=pitch(name);pitches.append(p);add(p,at,dur-.08,dyn+(6 if at==1 and sec!='C' else 0)-(4 if i==len(line.split())-1 else 0),'piano','melody','left' if sec=='C' else 'right')
   at+=dur
  assert at==3
  if sec=='C':
   if n%4==1:add(75 if h.startswith('Ab') else 77,1.5,.8,dyn-18,'piano','distant_upper_reply','right')
  elif sec=='Coda':
   for t,p,d in [(0,ch[0],.8),(2,ch[1],.6)]:add(p,t,d,dyn-15,'piano','settled_three_beat_answer','left')
  else:
   pat=[(0,ch[0],.38),(1,ch[1],.34),(2,ch[2],.32)]
   if n%4==2:pat=[(.5,ch[0],.32),(1.5,ch[1],.32),(2.5,ch[2],.28)]
   if n%4==0:pat=[(0,ch[0],.45),(1,ch[1],.35)]
   if level>=1 and 33<=n<=48:pat=[(0,ch[0],.35),(1.5,ch[1],.32),(2.5,ch[2],.28)]
   if level>=2 and 73<=n<=88:pat=[(0,ch[0],.38),(1,ch[2],.32),(2.5,ch[1],.28)]
   if n in [32,48,56,80,88,104,112]:pat=[(0,ch[0],.6)]
   for t,p,d in pat:add(p,t,d,dyn-24+(4 if t==1 else 0),'piano','mazurka_lower_lift','left')
  available=[p for p in range(50,60) if p%12 in {x%12 for x in ch}];assert available
  notes=[]
  if sec=='C' and n%4 in [1,3]:notes=[(.5,available[-1],.68)]
  elif sec=='Coda' and n in [113,117,120]:notes=[(.5,available[0],.65)]
  elif sec not in ['C','Coda'] and n%4==2:notes=[(1,available[0],.52)]
  elif sec not in ['C','Coda'] and n%4==3:notes=[(.5,available[-1],.43),(2,available[0],.43)]
  if level>=1 and 33<=n<=48:notes=[(1,available[-1],.45)] if n%2 else []
  if level>=2 and 73<=n<=88:notes=[(.5,available[0],.47),(2,available[-1],.43)] if n%4==3 else [(1.5,available[0],.43)] if n%4==2 else []
  for t,p,body in notes:add(p,t,min(body*bpm/60,3-t-.12),48 if sec in ['C','Coda'] else 76 if sec=='B' else 65,'cello','short_bowed_phrase_answer')
  pedals.append(dict(bar=n,onset=start,controller=64,value=0,instrument='piano'))
  if sec in ['C','Coda']:
   pedals +=[dict(bar=n,onset=start+.07,controller=64,value=34,instrument='piano'),dict(bar=n,onset=start+1.55,controller=64,value=0,instrument='piano'),dict(bar=n,onset=start+2.1,controller=64,value=25,instrument='piano'),dict(bar=n,onset=start+2.84,controller=64,value=0,instrument='piano')]
  elif n%4==1:pedals +=[dict(bar=n,onset=start+.05,controller=64,value=22,instrument='piano'),dict(bar=n,onset=start+.55,controller=64,value=0,instrument='piano')]
 events.sort(key=lambda e:(e['onset'],e['instrument'],e['pitch']))
 for i,e in enumerate(events):e['event_id']=f'w107-v{level}-{i:04d}'
 return dict(id=107,title='Two Bowls of Hot Soup',title_zh='两碗热汤',version=f'v{level}',bars=bars,events=events,pedals=pedals,total_beats=360,tail_seconds=5,instrumentation=['piano','cello_short_bowed'],performance_contract='Original warm acoustic second-beat dance; genuine short pp/mf cello bows, not a live human performance.')
for v in range(3):
 d=build(v);(P/f'score_v{v}.json').write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n');report=dict(version=f'v{v}',bars=120,notes=len(d['events']),duration_seconds=sum(b['beats']*60/b['bpm'] for b in d['bars'])+5,human_listening_review=False);(P/f'audit_v{v}.json').write_text(json.dumps(report,indent=2))
 if v:
  old=build(v-1);changed=[]
  for n in range(1,121):
   clean=lambda e:{k:x for k,x in e.items() if k!='event_id'}
   if [clean(e) for e in old['events'] if e['bar']==n]!=[clean(e) for e in d['events'] if e['bar']==n]:changed.append(n)
  a=(P/f'score_v{v-1}.json').read_text();b=(P/f'score_v{v}.json').read_text();(P/f'exact_diff_v{v-1}_to_v{v}.patch').write_text(''.join(difflib.unified_diff(a.splitlines(True),b.splitlines(True),f'score_v{v-1}.json',f'score_v{v}.json')));(P/f'exact_diff_v{v-1}_to_v{v}.json').write_text(json.dumps({'changed_bars':changed,'count':len(changed)},indent=2))
(P/'score.json').write_text((P/'score_v2.json').read_text());d=build(2);starts=[b['start'] for b in d['bars']];times=[];total=0.
for b in d['bars']:times.append(total);total+=b['beats']*60/b['bpm']
def sec(t):
 i=max(0,bisect.bisect_right(starts,t)-1);return times[i]+(t-starts[i])*60/d['bars'][i]['bpm']
def beat(t):
 i=max(0,bisect.bisect_right(times,t)-1);return starts[i]+(t-times[i])*d['bars'][i]['bpm']/60
mp=P.parent/'assets/iowa_cello_arco_D3_B3/mapping_manifest.json';lat={(x['layer'],x['midi']):x['coarse_voiced_delay_after_tuning_seconds'] for x in json.loads(mp.read_text())['files']};alignment=[]
for e in d['events']:
 if e['instrument']!='cello':continue
 layer='pp' if e['velocity']<=55 else 'mf';target=sec(e['onset']);end=sec(e['onset']+e['duration']);delay=lat[layer,e['pitch']];trigger=target-delay;assert trigger>=0;e['nominal_onset']=e['onset'];e['onset']=beat(trigger);e['duration']=beat(end)-e['onset'];e['layer']=layer;e['attack_compensated_once']=True
 alignment.append(dict(event_id=e['event_id'],target_seconds=target,trigger_seconds=trigger,delay_seconds=delay,gate_seconds=end-trigger,layer=layer));assert .30<=end-target and end-trigger<=1.15
ce=sorted([e for e in d['events'] if e['instrument']=='cello'],key=lambda e:e['onset'])
for a,b in zip(ce,ce[1:]):assert sec(b['onset'])-sec(a['onset']+a['duration'])>=.14-1e-6
(P/'ensemble_score.json').write_text(json.dumps(d,ensure_ascii=False,indent=2))
for inst in ['piano','cello']:
 x={**d,'events':[e for e in d['events'] if e['instrument']==inst],'pedals':d['pedals'] if inst=='piano' else []};(P/f'{inst}_score.json').write_text(json.dumps(x,ensure_ascii=False,indent=2))
(P/'revisions/cello_attack_alignment.json').write_text(json.dumps({'method':'Once-only coarse pitch/layer short-bow onset compensation; no perceptual-listening claim.','events':alignment},indent=2));print(json.dumps(report));print([json.loads((P/f'exact_diff_v{i}_to_v{i+1}.json').read_text())['count'] for i in range(2)])
