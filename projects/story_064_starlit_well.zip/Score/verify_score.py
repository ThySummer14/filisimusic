#!/usr/bin/env python3
"""Independent read-back validation of the delivered final JSON, without audio."""
from pathlib import Path
import json, hashlib
R=Path(__file__).resolve().parent
s=json.loads((R/'score_v2.json').read_text())
assert set(s)=={'id','title','title_zh','bars','events','pedals','total_beats','tail_seconds'}
bk={'bar','start','beats','bpm','section','meter_numerator','meter_denominator','harmony_name','harmony','role_plan','lead_instrument'}
ek={'bar','onset','duration','pitch','velocity','voice','instrument'}
assert all(set(b)==bk for b in s['bars'])
assert all(set(e)==ek for e in s['events'])
assert all(set(p)=={'onset','value'} and 0<=p['value']<=63 for p in s['pedals'])
assert s['id']==64 and s['title_zh']=='记得星星的井' and s['tail_seconds']==4
cursor=0; elapsed=0; starts={}
for i,b in enumerate(s['bars'],1):
 assert b['bar']==i and b['start']==cursor
 assert b['beats']==b['meter_numerator'] and b['meter_denominator']==4
 starts[i]=elapsed;elapsed+=b['beats']*60/b['bpm'];cursor+=b['beats']
assert cursor==s['total_beats']==155
fl=[];l=[];r=[]
for e in s['events']:
 b=s['bars'][e['bar']-1];offset=e['onset']-b['start']
 assert offset>=0 and offset+e['duration']<=b['beats']+1e-7
 if e['instrument']=='flute':
  assert e['voice']=='flute' and 72<=e['pitch']<=83 and 21<=e['velocity']<=95
  assert e['duration']*60/b['bpm']<=1.60
  assert b['lead_instrument']=='flute'
  fl.append(e)
 else:
  assert e['instrument']=='piano'
  if e['voice']=='melody': assert b['lead_instrument']=='piano'
  (l if e['voice'] in ('bass','accompaniment') else r).append(e)
for a,b in zip(fl,fl[1:]): assert a['onset']+a['duration']<=b['onset']+1e-7
for a in l:
 for b in r:
  if max(a['onset'],b['onset'])<min(a['onset']+a['duration'],b['onset']+b['duration'])-1e-8:
   assert a['pitch']<b['pitch'], 'Hand crossing or simultaneous same-key assignment'

for ph in json.loads((R/'phrases_v2.json').read_text()):
 ev=[e for e in fl if e['bar'] in ph['bars']]
 assert len(ev)==4
 assert all(21<=e['velocity']<=55 for e in ev) if ph['layer']=='pp' else all(56<=e['velocity']<=95 for e in ev)
assert (R/'score.json').read_bytes()==(R/'score_v2.json').read_bytes()
assert not list(R.glob('*.wav')) and not list(R.glob('*.mp3')) and not list(R.glob('*.rpp'))
# Two separately documented musical revisions must change many events in distinct bars.
diffs=json.loads((R/'revision_diff.json').read_text())
assert len(diffs)==2 and all(d['added_events']+d['removed_events']>=40 and len(d['changed_bars'])>=8 for d in diffs)
result={'status':'PASS','schema':'exact required keys','bars':len(s['bars']),'total_beats':cursor,'events':len(s['events']),'flute_events':len(fl),'seconds_plus_tail':round(elapsed+4,6),'score_v2_sha256':hashlib.sha256((R/'score_v2.json').read_bytes()).hexdigest(),'audio_created':False,'independent_readback':True,'cross_hand_or_same_key_conflicts':0}
(R/'validation_readback.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(result,ensure_ascii=False,indent=2))
