from pathlib import Path
import json,bisect,copy
P=Path(__file__).parent;R=P.parent;d=json.loads((P/'score_v2.json').read_text())
mp=R/'assets/iowa_flute_C5_B5/mapping_manifest.json'
if not mp.exists():mp=R/'InstrumentMapping/iowa_flute_C5_B5/mapping_manifest.json'
lat={(x['layer'],x['midi']):x['voiced_onset_delay_after_tuning_seconds'] for x in json.loads(mp.read_text())['files']}
d['technical_preroll_seconds']=0;d['musical_bar_count']=88
starts=[b['start'] for b in d['bars']];times=[];t=0
for b in d['bars']:times.append(t);t+=b['beats']*60/b['bpm']
def sec(x):
 i=max(0,bisect.bisect_right(starts,x)-1);return times[i]+(x-starts[i])*60/d['bars'][i]['bpm']
def beat(x):
 i=max(0,bisect.bisect_right(times,x)-1);return starts[i]+(x-times[i])*d['bars'][i]['bpm']/60
rows=[]
for e in d['events']:
 e['nominal_target_seconds_with_preroll']=sec(e['onset'])
 if e['instrument']!='flute':continue
 target=sec(e['onset']);end=sec(e['onset']+e['duration']);delay=lat[e['layer'],e['pitch']];trigger=target-delay;assert trigger>=0
 e['onset']=beat(trigger);e['duration']=beat(end)-e['onset'];e['onset_reference']='sample_trigger_after_single_measured_attack_compensation'
 rows.append({'event_id':e['event_id'],'phrase_id':e['phrase_id'],'pitch':e['pitch'],'layer':e['layer'],'target_voiced_arrival_seconds':target,'sample_trigger_seconds':trigger,'measured_advance_seconds':delay,'intended_note_off_seconds':end})
flute=sorted([e for e in d['events'] if e['instrument']=='flute'],key=lambda e:e['onset']);shorten=[]
for a,b in zip(flute,flute[1:]):
 end=sec(a['onset']+a['duration']);limit=sec(b['onset'])-.14
 if end>limit:
  assert limit-sec(a['onset'])>.10
  shorten.append({'event_id':a['event_id'],'original_end':end,'actual_end':limit,'shortening_seconds':end-limit});a['duration']=beat(limit)-a['onset']
lookup={e['event_id']:e for e in flute}
for row in rows:
 e=lookup[row['event_id']];row['actual_note_off_seconds']=sec(e['onset']+e['duration']);row['actual_gate_seconds']=row['actual_note_off_seconds']-sec(e['onset']);assert row['actual_gate_seconds']<=1.60
for a,b in zip(flute,flute[1:]):assert sec(b['onset'])-sec(a['onset']+a['duration'])>=.14-1e-8
for phrase in d['phrases']:
 phrase['nominal_target_on_seconds_with_preroll']=phrase['target_on_seconds']+0;phrase['nominal_target_off_seconds_with_preroll']=phrase['target_off_seconds']+0
 ev=[e for e in d['events'] if e['phrase_id']==phrase['phrase_id']];phrase['actual_trigger_start_seconds']=min(sec(e['onset']) for e in ev);phrase['actual_noteoff_end_seconds']=max(sec(e['onset']+e['duration']) for e in ev)
d['events'].sort(key=lambda e:(e['onset'],e['instrument'],e['pitch']));d['version']='v3_per_sample_attack_preserving_written_pickup'
for f in ['ensemble_score.json','revisions/ensemble_v3.json']:(P/f).write_text(json.dumps(d,ensure_ascii=False,indent=2))
for inst in ['flute','cello']:
 x={**d,'events':[e for e in d['events'] if e['instrument']==inst],'pedals':[]}
 for f in [f'{inst}_score.json',f'revisions/{inst}_v3.json']:(P/f).write_text(json.dumps(x,ensure_ascii=False,indent=2))
(P/'revisions/flute_attack_alignment_v3.json').write_text(json.dumps({'method':'Written flute pickup already leaves sufficient attack time; advance each flute trigger by measured pitch/layer breath onset once; preserve desired offs unless explicit release-clearance shortening. Cello remains ordinary pizzicato trigger. Not human listening or perfect perceptual alignment.','rows':rows,'shortenings':shorten,'max_gate':max(x['actual_gate_seconds'] for x in rows)},indent=2));print('notes',len(rows),'shortenings',len(shorten),'maxgate',max(x['actual_gate_seconds'] for x in rows))
