from pathlib import Path
import json,subprocess,os,re,hashlib
P=Path(__file__).parent;R=P.parent;V=P/'revisions';sfz=R/'assets/iowa_clarinet_C4_B4/Iowa_clarinet_C4_B4_wind_balance.sfz';score=P/'clarinet_score.json';candidate=V/'clarinet_v2.wav';reference=V/'clarinet_independent_reference_v2.wav';bank=V/'clarinet_independent_all_regions.sfz'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert not candidate.exists() and not reference.exists()
subprocess.run(['python',str(R/'tools/render_score_sfizz.py'),'--score',str(score),'--sfz',str(sfz),'--library',str(R/'tools/sfizz_user/usr/lib/libsfizz.so.1.2.3'),'--out',str(candidate),'--mode','complete-bank','--ram-cap-mib','400'],check=True)
s=sfz.read_text();assert 'hint_ram_based' not in s
s=re.sub(r'sample=([^\s]+)',lambda m:'sample='+str((sfz.parent/m.group(1)).resolve()),s);bank.write_text('<control> hint_ram_based=1\n'+s)
subprocess.run(['python',str(R/'renderer_streaming_audit_20261006/render_after_load.py'),'--score',str(score),'--sfz',str(bank),'--out',str(reference)],check=True,env={**os.environ,'SFIZZ_LIBRARY':str(R/'tools/sfizz_user/usr/lib/libsfizz.so.1.2.3')})
assert sha(candidate)==sha(reference)
proof={'scope':'Entire clarinet performance; complete original36region bank retained in both runs','production_pipeline':'Safe complete-bank RAM with native coverage query','reference_pipeline':'Independent complete-bank RAM directive and original after-load renderer','production_sha256':sha(candidate),'reference_sha256':sha(reference),'source_sfz_sha256':sha(sfz),'score_sha256':sha(score),'full_file_and_PCM_exact':True,'actual_native_original_region_coverage_checked':True,'sampled_legato':False};(V/'clarinet_reference_comparison.json').write_text(json.dumps(proof,indent=2));print('Clarinet full source reference exact')
