"""Original piano work104: compound motion, hemiola and left-hand cantabile."""
from pathlib import Path
import json,difflib,sys
P=Path(__file__).resolve().parent;sys.path.insert(0,str(P));from composition_data import *
def pitch(s):return 12*(int(s[-1])+1)+{'C':0,'D':2,'E':4,'F':5,'G':7,'A':9,'B':11}[s[0]]+s[1:-1].count('#')-s[1:-1].count('b')
def section(n):
 if n<=8:return 'Opening','加时开球',138,86
 if n<=32:return 'A','两侧穿插',138,76
 if n<=48:return 'B','急攻失衡',150,89
 if n<=64:return 'C','暂停的三句话',86,49
 if n<=96:return 'D','有准备的传递',144,83
 if n<=112:return 'E','终场前的一球',136,94
 return 'Coda','坐回边线',82,50

def build(level):
 hs=[];lines=[]
 for h,s in ROWS:hs+=h.split();lines+=s.split('|')
 assert len(lines)==len(hs)==128
 for lv,rd,hd in [(1,REV1,HREV1),(2,REV2,HREV2)]:
  if level>=lv:
   for n,s in rd.items():lines[n-1]=s
   for n,h in hd.items():hs[n-1]=h
 bars=[];ev=[];ped=[]
 for n,(line,h) in enumerate(zip(lines,hs),1):
  sec,label,bpm,dyn=section(n);start=(n-1)*3;ch=H[h];hemi=n in [41,42,45,46];meter='3/4' if hemi or sec in ['C','Coda'] else '6/8'
  if n in [8,32,48,64,96,112]:bpm-=6
  if n>=125:bpm-=2*(n-124)
  bars.append(dict(bar=n,start=start,beats=3,bpm=bpm,meter=meter,meter_numerator=3 if meter=='3/4' else 6,meter_denominator=4 if meter=='3/4' else 8,section=sec,section_title_zh=label,harmony_name=h,harmony=ch,key_region='G major' if sec=='C' else 'B minor',metrical_grouping='three quarter accents' if meter=='3/4' else 'two dotted-quarter accents',texture='piano_theme_and_coordinated_lower_response'))
  def add(p,t,d,v,voice,hand):
   assert 0<=t<t+d<=3.00001,(n,t,d)
   ev.append(dict(bar=n,onset=round(start+t,6),duration=round(d,6),pitch=p,velocity=int(v),instrument='piano',voice=voice,hand=hand,harmony_name=h,phrase_id=f'{sec}_{(n-1)//4}',role='lead' if voice=='melody' else 'support',articulation='compound_pulse_and_released_hand_travel',written_value_beats=d))
  at=0.
  for i,tok in enumerate(line.split()):
   note,u=tok.split(':');dur=int(u)/2
   if note!='R':add(pitch(note),at,max(.12,dur-.09),dyn+(5 if at in [0,1.5] and meter=='6/8' else 0)-(4 if i==len(line.split())-1 else 0),'melody','left' if sec=='C' else 'right')
   at+=dur
  assert at==3,(n,at)
  if sec=='C':
   # The pause changes who sings: sparse upper punctuation leaves the left-hand line alone.
   p=74 if h.startswith('D') else 71 if 'Bm' in h else 76 if h.startswith('Em') else 74
   if n%2:add(p,1.5,.95,dyn-18,'upper_quiet_response','right')
  elif hemi:
   for t,p in [(0,ch[0]),(1,ch[1]),(2,ch[2])]:add(p,t,.38,dyn-23,'hemiola_anchor','left')
  elif sec=='Coda':
   pat=[(0,ch[0],1.2),(1.75,ch[1],.9)] if n%2 else [(0,ch[0],1.6)]
   for t,p,d in pat:add(p,t,d,dyn-14,'settled_counterline','left')
  else:
   pat=[(0,ch[0],.42),(1.5,ch[2],.48)]
   if n%4==2:pat=[(.5,ch[1],.32),(2,ch[0],.32)]
   if n%4==3:pat=[(0,ch[0],.4),(1,ch[1],.32),(2,ch[2],.38)]
   if level>=1 and 33<=n<=48 and not hemi:pat=[(.5,ch[0],.28),(1.5,ch[1],.32),(2.5,ch[2],.27)]
   if level>=2 and 89<=n<=112:pat=[(0,ch[0],.35),(1.5,ch[1],.35),(2.5,ch[2],.30)] if n%2 else [(.5,ch[1],.30),(2,ch[0],.40)]
   if n in [32,48,96,104,112]:pat=[(0,ch[0],.6)]
   for t,p,d in pat:add(p,t,d,dyn-27,'counterstep','left')
   if n in [1,9,17,25,65,81,97,105]:add(ch[1],0,.35,dyn-31,'inner_anchor','left')
  ped.append(dict(bar=n,onset=start,controller=64,value=0,instrument='piano'))
  if sec in ['C','Coda']:
   ped +=[dict(bar=n,onset=start+.06,controller=64,value=35,instrument='piano'),dict(bar=n,onset=start+1.35,controller=64,value=0,instrument='piano'),dict(bar=n,onset=start+1.8,controller=64,value=27,instrument='piano'),dict(bar=n,onset=start+2.82,controller=64,value=0,instrument='piano')]
  elif n%4==1:ped +=[dict(bar=n,onset=start+.05,controller=64,value=25,instrument='piano'),dict(bar=n,onset=start+.55,controller=64,value=0,instrument='piano')]
 ev.sort(key=lambda e:(e['onset'],e['pitch']))
 for i,e in enumerate(ev):e['event_id']=f'w104-v{level}-{i:04d}'
 return dict(id=104,title='Overtime at the Old Court',title_zh='旧球馆加时',version=f'v{level}',bars=bars,events=ev,pedals=ped,total_beats=384,tail_seconds=5,instrumentation=['piano'],performance_contract='Original sample-based solo piano composition; no live human performance or full listening approval claimed.')
for v in range(3):
 d=build(v);(P/f'score_v{v}.json').write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n');report=dict(version=f'v{v}',bars=128,notes=len(d['events']),duration_seconds=sum(b['beats']*60/b['bpm'] for b in d['bars'])+5,human_listening_review=False);(P/f'audit_v{v}.json').write_text(json.dumps(report,indent=2))
 if v:
  old=build(v-1);changed=[]
  for n in range(1,129):
   clean=lambda e:{k:x for k,x in e.items() if k!='event_id'}
   if [clean(e) for e in old['events'] if e['bar']==n]!=[clean(e) for e in d['events'] if e['bar']==n]:changed.append(n)
  a=(P/f'score_v{v-1}.json').read_text();b=(P/f'score_v{v}.json').read_text();(P/f'exact_diff_v{v-1}_to_v{v}.patch').write_text(''.join(difflib.unified_diff(a.splitlines(True),b.splitlines(True),f'score_v{v-1}.json',f'score_v{v}.json')));(P/f'exact_diff_v{v-1}_to_v{v}.json').write_text(json.dumps({'changed_bars':changed,'count':len(changed)},indent=2))
for f in ['score.json','ensemble_score.json','piano_score.json']:(P/f).write_text((P/'score_v2.json').read_text())
print(json.dumps(report));print([json.loads((P/f'exact_diff_v{i}_to_v{i+1}.json').read_text())['count'] for i in range(2)])
