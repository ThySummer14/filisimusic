local master=reaper.GetMasterTrack(0)
local fx=reaper.TrackFX_AddByName(master,'ReaVerbate (Cockos)',false,-1)
assert(fx>=0,'Bundled ReaVerbate unavailable')
for i,v in pairs({[0]=0.05,[1]=1,[2]=0.18,[3]=0.62,[4]=0.70,[5]=0,[6]=1,[7]=0}) do reaper.TrackFX_SetParam(master,fx,i,v) end
reaper.Main_SaveProject(0,false)
local f=assert(io.open('PRODUCTION_ROOT/059_migrating_shadows/revisions/native_room_v2_saved.txt','w'));f:write('Actual REAPER stock shared room saved: wet0.05,dry1,room0.18,damp0.62,width0.70.');f:close()
reaper.Main_OnCommand(40004,0)
