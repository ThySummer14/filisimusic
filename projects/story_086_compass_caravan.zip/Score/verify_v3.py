#!/usr/bin/env python3
"""Independent v3 validation; reads saved JSON only and changes no historical file."""
import bisect
import hashlib
import json
from collections import defaultdict
from pathlib import Path

P = Path(__file__).resolve().parent
load = lambda n: json.loads((P / n).read_text())
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
s, old = load('score_v3.json'), load('score_v2.json')
errors = []
starts, accumulated, elapsed = [], [], 0
for i, b in enumerate(s['bars']):
    starts.append(b['start']); accumulated.append(elapsed)
    elapsed += b['beats'] * 60 / b['bpm']
    if (b['bar'], b['start'], b['beats'], b['meter_numerator'], b['meter_denominator']) != (i + 1, 4.5 * i, 4.5, 9, 8): errors.append('bar schema')
def seconds(beat):
    i = max(0, min(len(starts) - 1, bisect.bisect_right(starts, beat) - 1))
    return accumulated[i] + (beat - starts[i]) * 60 / s['bars'][i]['bpm']

events = s['events']
changes = defaultdict(list)
attacks = {'left': defaultdict(list), 'right': defaultdict(list)}
for i, e in enumerate(events):
    if e['instrument'] != 'piano' or e['hand'] not in attacks or not 21 <= e['pitch'] <= 108: errors.append('event ownership')
    if e['duration'] <= 0 or not 0 <= e['onset'] < e['onset'] + e['duration'] <= s['total_beats']: errors.append('event bounds')
    changes[round(e['onset'], 6)].append((1, i))
    changes[round(e['onset'] + e['duration'], 6)].append((0, i))
    attacks[e['hand']][e['onset']].append(e)
held = {}
maxspan = {'left': 0, 'right': 0}
maxkeys = {'left': 0, 'right': 0}
key_overlap = hand_crossing = 0
physical_grips = {'left': {}, 'right': {}}
for t in sorted(changes):
    for kind, i in sorted(changes[t]):
        if kind == 0: held.pop(i, None)
        else:
            e = events[i]
            if any(v['pitch'] == e['pitch'] for v in held.values()): key_overlap += 1
            held[i] = e
    byhand = {h: [v for v in held.values() if v['hand'] == h] for h in attacks}
    for h, ns in byhand.items():
        if ns:
            ps = [e['pitch'] for e in ns]
            maxspan[h] = max(maxspan[h], max(ps) - min(ps))
            maxkeys[h] = max(maxkeys[h], len(ps))
            if t in attacks[h]: physical_grips[h][t] = [min(ps), max(ps)]
    if byhand['left'] and byhand['right'] and max(e['pitch'] for e in byhand['left']) >= min(e['pitch'] for e in byhand['right']): hand_crossing += 1
if key_overlap or hand_crossing or max(maxspan.values()) > 12: errors.append('key geometry')

# All prior key releases are included; using the last onset group alone could
# miss a low key that survives under a later upper support.
times = sorted(attacks['left'])
latest_release = 0
travel = []
for i, t in enumerate(times):
    group = attacks['left'][t]
    if i:
        a = physical_grips['left'][times[i - 1]]
        b = physical_grips['left'][t]
        edge = max(abs(a[0] - b[0]), abs(a[1] - b[1]))
        if edge > 4:
            free = seconds(t) - seconds(latest_release)
            required = .075 + .012 * (edge - 4)
            row = {'from_beat': times[i - 1], 'to_beat': t, 'source_edges': a, 'target_edges': b,
                   'distance_semitones': edge, 'actual_release_seconds': round(free, 9),
                   'required_seconds': round(required, 9), 'margin_seconds': round(free - required, 9)}
            travel.append(row)
            if free + 1e-7 < required: errors.append('LH edge travel')
    latest_release = max(latest_release, *(e['onset'] + e['duration'] for e in group))

plan = load('right_hand_position_plan_v3.json')['plan']
position_errors = []
for i, b in enumerate(s['bars']):
    pos = plan[i]
    lo, hi = pos['hand_window']
    ns = [e for e in events if e['hand'] == 'right' and e['bar'] == b['bar']]
    if hi - lo != 12 or pos['bar'] != b['bar'] or any(not lo <= e['pitch'] <= hi for e in ns): position_errors.append(b['bar'])
    delta = abs(lo - plan[i - 1]['hand_window'][0]) if i else 0
    if delta > 4 or delta != pos['position_translation_semitones']: position_errors.append(b['bar'])
if position_errors: errors.append('RH actual position plan')

# Held shapes and position planning cannot excuse a changed main melody.
rh_exact = [e for e in events if e['hand'] == 'right'] == [e for e in old['events'] if e['hand'] == 'right']
structure_exact = all(s[k] == old[k] for k in ('bars', 'pedals', 'total_beats', 'tail_seconds'))
if not rh_exact or not structure_exact: errors.append('unauthorized musical scope')
if s['version'] != 'v3' or (P / 'score.json').read_bytes() != (P / 'score_v3.json').read_bytes(): errors.append('selected version')

# Reconstruct a literal event diff and check its recorded bar set.
changed = []
for n in range(1, 65):
    if [e for e in events if e['bar'] == n] != [e for e in old['events'] if e['bar'] == n]: changed.append(n)
if changed != load('exact_diff_v2_to_v3.json')['changed_bars']: errors.append('revision completeness')

# Every historical file is verified against the preserved old manifest. Root
# v0-v2 score files are separately verified against their archived identities.
historical_manifest = load('historical_v2/hash_manifest.json')
history_bad = [n for n, digest in historical_manifest['files'].items() if sha(P / 'historical_v2' / n) != digest]
for v in ('v0', 'v1', 'v2'):
    if sha(P / ('score_' + v + '.json')) != sha(P / 'historical_v2' / ('score_' + v + '.json')): history_bad.append('root score_' + v)
if sha(P / 'hash_manifest_v2.json') != sha(P / 'historical_v2/hash_manifest.json'): history_bad.append('historical manifest copy')
if history_bad: errors.append('history altered')

result = {'passed': not errors, 'errors': errors, 'selected_score_sha256': sha(P / 'score.json'),
          'selected_equals_v3_byte_for_byte': (P / 'score.json').read_bytes() == (P / 'score_v3.json').read_bytes(),
          'right_hand_events_unchanged': rh_exact, 'form_harmony_tempo_pedals_duration_unchanged': structure_exact,
          'total_duration_seconds': round(elapsed + s['tail_seconds'], 6),
          'max_held_span_semitones': maxspan, 'max_simultaneous_keys': maxkeys,
          'same_key_overlap_count': key_overlap, 'hand_crossing_count': hand_crossing,
          'left_hand_travel_rule': 'max(abs(target_low-source_low), abs(target_high-source_high)); for distances >4, require 75ms + 12ms*(distance-4). All prior key releases count; pedal does not.',
          'strict_left_transfers_checked': len(travel), 'strict_left_minimum_margin_seconds': min(t['margin_seconds'] for t in travel),
          'strict_left_transfer_records': travel, 'right_hand_position_plan_errors': position_errors,
          'right_hand_maximum_actual_position_change_semitones': max(p['position_translation_semitones'] for p in plan),
          'right_hand_model_scope': 'Each complete bar is assigned a verified octave-width position. Notes inside that position use fingers; actual position shifts are checked separately. This is a suggested feasible position plan, not a rendered or human performance.',
          'changed_bars': changed, 'historical_hash_mismatches': history_bad,
          'limits': 'Symbolic feasibility only; no audio or listening judgment.'}
(P / 'independent_verification_v3.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({k: v for k, v in result.items() if k != 'strict_left_transfer_records'}, ensure_ascii=False, indent=2))
if errors: raise SystemExit(1)
