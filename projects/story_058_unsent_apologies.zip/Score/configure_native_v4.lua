local values={{4.3,-0.10,1},{4,-0.35,0.45}}
for i,v in ipairs(values) do local tr=reaper.GetTrack(0,i-1);assert(reaper.SetMediaTrackInfo_Value(tr,'D_VOL',v[1]));assert(reaper.SetMediaTrackInfo_Value(tr,'D_PAN',v[2]));assert(reaper.SetMediaTrackInfo_Value(tr,'D_WIDTH',v[3]));assert(reaper.SetMediaTrackInfo_Value(tr,'D_PANLAW',1)) end
reaper.SetMediaTrackInfo_Value(reaper.GetMasterTrack(0),'D_VOL',1.3)
reaper.Main_SaveProject(0,false)
local f=assert(io.open("PRODUCTION_ROOT/058_unsent_apologies/revisions/native_mix_v4_verified.tsv",'w'));for i=0,1 do local tr=reaper.GetTrack(0,i);f:write(i);for _,k in ipairs({'D_VOL','D_PAN','D_WIDTH','D_PANLAW'}) do f:write('\t'..k..'='..reaper.GetMediaTrackInfo_Value(tr,k)) end;f:write('\n') end;f:close();reaper.Main_OnCommand(40004,0)
