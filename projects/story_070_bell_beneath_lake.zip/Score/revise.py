from pathlib import Path
import json
P=Path(__file__).parent;d=json.loads((P/'revisions/score_v0.json').read_text())
def melody(bar,line):
 b=d['bars'][bar-1];d['events']=[e for e in d['events'] if not(e['bar']==bar and e['voice']=='melody')];off=0
 for n,l in line:
  if n>=0:d['events'].append(dict(bar=bar,onset=b['start']+off,duration=l*.97,pitch=n,velocity=65,voice='melody'))
  off+=l
 assert off==6
D=[[(68,1),(66,1),(64,1),(63,1),(61,1),(56,1)],[(64,1.5),(61,.5),(57,1),(56,1),(57,1),(61,1)],[(66,1),(61,1),(57,1),(54,1),(56,1),(57,1)],[(60,1),(63,.5),(66,.5),(68,1),(66,1),(63,1),(-1,1)],[(64,1),(61,1),(56,2),(59,1),(61,1)],[(64,1.5),(68,.5),(71,1),(68,1),(64,1),(-1,1)]]
S=[[(64,1),(63,.5),(64,.5),(68,1),(71,1),(68,1),(64,1)],[(61,1),(64,1),(69,1.5),(68,.5),(64,1),(-1,1)],[(66,1.5),(64,.5),(61,1),(57,1),(61,1),(66,1)],[(63,1),(59,1),(66,1),(69,1),(66,1),(-1,1)],[(68,1),(64,1),(61,1),(59,.5),(61,.5),(64,1),(68,1)],[(69,1),(66,.5),(64,.5),(62,1),(66,1),(69,1),(73,1)],[(68,1),(66,.5),(63,.5),(60,1),(63,1),(66,1),(-1,1)],[(61,2),(64,1),(63,1),(61,1),(-1,1)]]
for j,x in enumerate(D):melody(11+j,x)
for j,x in enumerate(S):melody(29+j,x)
d['stage']='v1_distinct_descent_and_changed_shoreline_return';(P/'revisions/score_v1.json').write_text(json.dumps(d,indent=2));(P/'revisions/pass1.json').write_text(json.dumps({'round':1,'kind':'substantive_composition_revision','changes':['Write a new descending6-bar exploration rather than repeat the remembered theme at a different tempo.','Replace the8-bar shoreline return with new phrases: the thin new bell recalls the rhythm but does not pretend to be the recovered old bell.']},indent=2))
R=[[(61,1),(64,.5),(66,.5),(68,1),(66,1),(64,1),(-1,1)],[(64,2),(61,1),(57,1),(-1,2)],[(66,1),(64,1),(61,1),(59,1),(57,1),(-1,1)],[(63,1),(60,1),(56,1),(60,1),(63,1),(-1,1)]]
for j,x in enumerate(R):melody(25+j,x)
arc=[-2,0,2,-3,0,1,2,-5]
for b in d['bars']:
 kind=b['role_plan'];j=b['phrase_position'];base={'intro':56,'memory':64,'descent':66,'garden':70,'refusal':68,'shore':63,'coda':54}[kind];ns=[e for e in d['events'] if e['bar']==b['bar'] and e['voice']=='melody'];end=max(e['onset']+e['duration'] for e in ns);breath=end<b['start']+5.4
 for e in [e for e in d['events'] if e['bar']==b['bar']]:
  if e['voice']=='melody':e['velocity']=base+arc[j%8]+(2 if e['duration']>1.2 else 0)
  else:
   e['velocity']=base-(27 if e['voice']=='bass' else 36)+arc[j%8]//2
   if breath and e['onset']>=b['start']+5:e['remove']=True
   if kind=='refusal' and e['onset']>=b['start']+3:e['velocity']-=4
 for x in d['pedals']:
  if b['start']<=x['onset']<b['start']+6 and x['value']>0:x['value']=30 if kind=='refusal' else 43 if kind=='garden' else 38
# End with the old open fifth in the low middle register; no brilliant upper-register triumph.
b=d['bars'][-1];d['events']=[e for e in d['events'] if not(e['bar']==b['bar'] and e['voice']!='melody')]
for t,n,l,v in [(0,37,.6,31),(1,44,3.6,25),(1,49,3.6,25)]:d['events'].append(dict(bar=b['bar'],onset=b['start']+t,duration=l,pitch=n,velocity=v,voice='bass' if t==0 else'accompaniment'))
d['events']=[e for e in d['events'] if not e.pop('remove',False)];d['events'].sort(key=lambda e:(e['onset'],e['pitch']));d['stage']='v2_unresolved_argument_and_shared_low_register_release'
for f in ['score.json','revisions/score_v2.json']:(P/f).write_text(json.dumps(d,indent=2))
(P/'revisions/pass2.json').write_text(json.dumps({'round':2,'kind':'substantive_score_and_performance_revision','changes':['Recompose the four-bar argument into shorter incomplete answers; do not force a consoling major-key resolution.','Make support follow the same phrase and withdraw at explicit breath points; reduce second-half support and pedal during the argument.','Finish with a soft shared low-middle open fifth beneath the original melodic shape, leaving grief unresolved rather than adding a triumphant high ending.'],'human_listening_review':False},indent=2))
