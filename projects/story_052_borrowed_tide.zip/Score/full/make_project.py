import pathlib,json,argparse
ap=argparse.ArgumentParser();ap.add_argument('--version',required=True);ap.add_argument('--gain',type=float,default=5.8);a=ap.parse_args();p=pathlib.Path(__file__).parent;v=a.version;d=json.loads((p/f'revisions/score_{v}.json').read_text());m=json.loads((p/f'revisions/piano_stem_{v}.render.json').read_text());dur=m['duration'];r=f'''<REAPER_PROJECT 0.1 7.82 1
  SAMPLERATE 44100 0 0
  TEMPO 144
  MASTER_VOLUME 1
  RENDER_FILE "{p}/revisions/052_{v}.wav"
  RENDER_FMT 0 2 44100
  RENDER_1X 0
  RENDER_RANGE 0 0 {dur:.10f} 0 1000
  RENDER_RESAMPLE 3 0 1
  RENDER_STEMS 0
  RENDER_DITHER 0
  <RENDER_CFG
    ZXZhdxgAAA==
  >
''';t=0;last=None;i=0
for b in d['bars']:
 if b['section']!=last:i+=1;r+=f'  MARKER {i} {t:.8f} "{b["section"]}" 0\n';last=b['section']
 t+=b['beats']*60/b['bpm']
r+=f'''  <TRACK
    NAME "Original52 full work | coordinated lead and accompaniment"
    PANMODE 5
    VOLPAN {a.gain} -0.25 0.6 -1
    MAINSEND 1
    <ITEM
      POSITION 0
      LENGTH {dur:.10f}
      NAME "Original sampled piano full performance"
      VOLPAN 1 0 1 -1
      FADEIN 1 0.005
      FADEOUT 1 1.0
      <SOURCE WAVE
        FILE "piano_stem_{v}.wav"
      >
    >
  >
>
''';(p/f'revisions/052_{v}.rpp').write_text(r)
