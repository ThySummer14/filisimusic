from copy import deepcopy

def pitch(s):
 return 12*(int(s[-1])+1)+{'C':0,'D':2,'E':4,'F':5,'G':7,'A':9,'B':11}[s[0]]+s[1:-1].count('#')-s[1:-1].count('b')
def decode(line):
 result=[];t=0
 for token in line.split():
  name,units=token.split(':');dur=float(units)/2
  if name!='R':result.append((pitch(name),t,dur))
  t+=dur
 return result,t
class Writer:
 def __init__(self):self.bars=[];self.events=[];self.pedals=[];self.start=0;self.n=0
 def bar(self,name,bpm,beats,h,ch):
  self.n+=1;self.beats=beats;self.bpm=bpm;self.ch=ch
  numerator,denominator=(int(beats*2),8) if beats in (2.5,3.5) else ((6,8) if METER=='6/8' else (int(beats),4))
  self.bars.append(dict(bar=self.n,start=self.start,beats=beats,bpm=bpm,meter_numerator=numerator,meter_denominator=denominator,section=name,harmony_name=h,harmony=ch))
 def add(self,p,t,d,v=72,inst='piano',voice='theme',hand='right',art='detached'):
  if d>0 and t<self.beats:
   self.events.append(dict(bar=self.n,onset=round(self.start+t,6),duration=round(min(d,self.beats-t),6),pitch=int(p),velocity=max(1,min(127,int(v))),instrument=inst,voice=voice,hand=hand if inst=='piano' else 'none',articulation=art))
 def line(self,line,v=80,hand='right',transpose=0):
  notes,total=decode(line);assert abs(total-self.beats)<1e-7,(self.n,total,self.beats,line)
  for p,t,d in notes:self.add(p+transpose,t,max(.11,d-.09),v+(3 if t==0 else 0),hand=hand)
  return notes
 def release(self,amount=0,length=.7):
  self.pedals.append(dict(bar=self.n,onset=self.start,controller=64,value=0,instrument='piano'))
  if amount:
   self.pedals.extend([dict(bar=self.n,onset=self.start+.05,controller=64,value=amount,instrument='piano'),dict(bar=self.n,onset=self.start+length,controller=64,value=0,instrument='piano')])
  self.start+=self.beats
 def result(self,level):
  self.pedals.append(dict(bar=self.n,onset=self.start-.01,controller=64,value=0,instrument='piano'))
  return dict(id=ID,title=TITLE,title_zh=TITLE_ZH,version=f'v{level}',bars=self.bars,events=self.events,pedals=self.pedals,total_beats=self.start,tail_seconds=5,instrument_map=INSTRUMENT_MAP)
def material(level):
 n=0
 for section,bpm,beats,texture,hs,phrase_names in BLOCKS:
  lines=[]
  for pn in phrase_names.split():lines+=P[pn].split('|')
  harmonies=hs.split();assert len(lines)==len(harmonies),(section,len(lines),len(harmonies))
  for h,line in zip(harmonies,lines):
   n+=1
   for lv,rev in [(1,REV1),(2,REV2)]:
    if level>=lv and n in rev:h,line=rev[n]
   yield n,section,bpm,beats,texture,h,line
ID=137;TITLE='The Rooftop Radio';TITLE_ZH='天台的无线电';METER='4/4';INSTRUMENT_MAP={'piano':'piano','clarinet':'clarinet'}
RENDERER_NOTES='Independent clarinet countertheme is explicitly written, not extracted from piano notes. 3/4,4/4,5/4 blocks of unequal lengths. Short articulated clarinet notes C4–B4, phrase breaks and full-rest bars.'
H={'Em':[40,55,59],'C':[36,52,55],'G':[43,55,59],'B7':[47,57,63],'Am':[45,52,60],'D':[38,54,57],'F#dim':[42,57,60],'Em/B':[47,55,59],'Cmaj7':[36,55,59],'F':[41,53,57],'Bsus':[47,57,64],'E':[40,56,59]}
# Upper piano station: leap, return, incomplete turn. Second station below is an independent stepwise line.
P5=[
('Em','B4:1 E5:1 G5:1 F#5:1 E5:2 D5:1 B4:1 E5:2'),('C','G5:1 E5:1 C5:2 D5:1 E5:1 G5:2 B5:2'),('G','D6:1 B5:1 G5:1 F#5:1 D5:2 G5:1 A5:1 B5:2'),('B7','D#5:1 F#5:1 B5:2 A5:1 F#5:1 D#5:2 R:2'),('Am','E5:1 A5:1 C6:1 B5:1 A5:2 G5:1 E5:1 C5:2'),('B7','F#5:2 D#5:1 B4:1 A4:1 B4:1 D#5:2 F#5:2'),('Em','G5:1 E5:1 B4:2 E5:1 G5:1 B5:2 A5:2'),('Cmaj7','G5:1 B5:1 C6:2 B5:1 G5:1 E5:2 C5:2'),('Am','C6:2 A5:1 E5:1 C5:1 E5:1 A5:2 G5:2'),('F#dim','F#5:1 A5:1 C6:2 B5:1 A5:1 F#5:2 C5:2'),('B7','D#5:1 F#5:1 A5:2 B5:1 A5:1 F#5:2 R:2')]
P4=[
('Em','E5:1 G5:1 B5:2 A5:1 G5:1 E5:2'),('C','E5:2 G5:1 C6:1 B5:1 G5:1 E5:2'),('G','B5:1 D6:1 G6:2 F#6:1 D6:1 B5:2'),('D','A5:1 F#5:1 D5:2 E5:1 F#5:1 A5:2'),('Am','C6:1 A5:1 E5:2 G5:1 A5:1 C6:2'),('Em/B','B5:2 G5:1 E5:1 D5:1 B4:1 E5:2'),('F#dim','A5:1 F#5:1 C5:2 D5:1 F#5:1 A5:2'),('B7','D#6:1 B5:1 A5:1 F#5:1 D#5:2 R:2'),('Em','G5:1 E5:1 B4:1 E5:1 G5:1 B5:1 E6:2'),('C','C6:1 G5:1 E5:2 C5:1 E5:1 G5:2'),('F','A5:1 C6:1 F6:2 E6:1 C6:1 A5:2'),('B7','D#5:2 F#5:1 B5:1 A5:2 R:2'),('Em','E6:1 B5:1 G5:2 E5:1 B4:1 G4:2'),('Em','E5:2 B4:1 G4:1 E4:2 R:2')]
P3=[('Em','B4:2 E5:1 G5:1 B5:2'),('Cmaj7','B5:2 G5:1 E5:1 C5:2'),('Am','E5:1 A5:1 C6:2 B5:2'),('B7','A5:1 F#5:1 D#5:2 B4:2'),('Em','G5:2 E5:2 R:2')]
# Countertheme descends, then turns upward; gaps separate 2–3-note cells, every multi-bar phrase has a rest bar.
W5=['E4:2 F#4:2 G4:2 R:4','G4:2 E4:2 D4:2 C4:2 R:2','B4:2 A4:2 G4:2 R:4','F#4:2 D#4:2 R:6','E4:2 G4:2 A4:2 R:4','F#4:2 E4:2 D#4:2 R:4','R:10','G4:2 B4:2 A4:2 G4:2 R:2','E4:2 C4:2 E4:2 R:4','F#4:2 A4:2 C4:2 R:4','B4:2 A4:2 F#4:2 R:4']
W4=['G4:2 F#4:2 E4:2 R:2','E4:2 D4:2 C4:2 R:2','G4:2 A4:2 B4:2 R:2','A4:2 F#4:2 E4:2 R:2','C4:2 E4:2 A4:2 R:2','B4:2 G4:2 E4:2 R:2','R:8','F#4:2 D#4:2 R:4','E4:2 F#4:2 G4:2 R:2','C4:2 D4:2 E4:2 R:2','F4:2 A4:2 G4:2 R:2','F#4:2 D#4:2 R:4','B4:2 G4:2 E4:2 R:2','R:8']
# Each section selects an explicitly ordered through-route; indexes intentionally overlap for recognizable return, not uniform loops.
S=[('Static_with_a_rhythm',118,5,[(i,'piano') for i in [0,1,2,3,4,5]]),('Station_one',108,4,[(i,'duet') for i in [0,1,2,3,4,5,6,7,8]]),('Turn_the_dial',122,5,[(i,'piano') for i in [6,7,8,9,10,1,3]]),('Two_signals',114,4,[(i,'duet') for i in [0,4,1,5,2,3,6,7,8,9,10,11,12,13]]),('Station_identity',92,3,[(i,'wind') for i in range(5)]),('Keep_the_signal',116,4,[(i,'duet') for i in [4,5,0,1,6,7,9,10,2,11,8]]),('Antenna_in_wind',126,5,[(i,'drive') for i in [0,4,8,1,7,9,10,6]]),('Voices_cross',120,4,[(i,'duet') for i in [8,4,0,9,5,1,10,2,3,6,7,11,12]]),('Leave_it_tuned',106,4,[(i,'duet') for i in [0,1,4,5,9,10,6,7,12,13]]),('The_city_keeps_talking',102,5,[(i,'close') for i in [6,7,8,9,10,3,0]])]
REV1={24:('Am','C6:1 A5:1 E5:1 C5:1 E5:1 G5:1 A5:2','E4:2 G4:2 A4:2 R:2'),25:('Cmaj7','B5:1 G5:1 E5:2 C5:1 E5:1 G5:2','E4:2 D4:2 C4:2 R:2'),26:('Em/B','G5:1 E5:1 B4:2 D5:1 E5:1 G5:2','B4:2 A4:2 G4:2 R:2'),27:('G','D6:2 B5:1 G5:1 A5:1 B5:1 D6:2','G4:2 A4:2 B4:2 R:2'),28:('D','F#5:1 A5:1 D6:2 C6:1 A5:1 F#5:2','F#4:2 E4:2 D4:2 R:2'),29:('F#dim','C6:1 A5:1 F#5:2 E5:1 C5:1 A4:2','R:8'),30:('B7','D#6:2 B5:1 A5:1 F#5:1 D#5:1 B4:2','A4:2 F#4:2 D#4:2 R:2'),31:('Em','G5:1 B5:1 E6:2 D6:1 B5:1 G5:2','G4:2 F#4:2 E4:2 R:2'),32:('C','E5:1 G5:1 C6:1 B5:1 G5:2 E5:2','C4:2 D4:2 E4:2 R:2'),33:('Am','E5:1 A5:1 C6:2 B5:1 A5:1 E5:2','A4:2 G4:2 E4:2 R:2'),34:('B7','F#5:1 B5:1 D#6:2 C#6:1 B5:1 A5:2','F#4:2 E4:2 D#4:2 R:2'),35:('Em','B5:1 G5:1 E5:2 D5:1 B4:1 G4:2','E4:2 G4:2 B4:2 R:2'),36:('Em','E5:2 B4:1 G4:1 E4:2 R:2','R:8')}
REV2={}
for n,i in zip(range(61,74),[9,4,8,1,5,0,10,2,3,6,7,11,12]):
 h,r=P4[i];parts=r.split();# written rearticulation: last sustained cell becomes two repeated attacks only on selected bars
 if n in (61,65,69):
  for j in range(len(parts)-1,-1,-1):
   note,u=parts[j].split(':')
   if note!='R' and u=='2':parts[j:j+1]=[note+':1',note+':1'];break
 REV2[n]=(h,' '.join(parts),W4[(i+2)%len(W4)] if i not in (6,13) else 'R:8')
# The revised countertheme is separately composed against each new harmonic target.
for n,wind in zip(range(61,74),['E4:2 D4:2 C4:2 R:2','C4:2 E4:2 A4:2 R:2','G4:2 F#4:2 E4:2 R:2','G4:2 E4:2 C4:2 R:2','B4:2 A4:2 G4:2 R:2','E4:2 G4:2 B4:2 R:2','A4:2 G4:2 F4:2 R:2','B4:2 A4:2 G4:2 R:2','F#4:2 E4:2 D4:2 R:2','R:8','A4:2 F#4:2 D#4:2 R:2','F#4:2 E4:2 D#4:2 R:2','E4:2 G4:2 B4:2 R:2']):
 h,r,_=REV2[n];REV2[n]=(h,r,wind)
def build(level):
 w=Writer();n=0
 for section,bpm,beats,route in S:
  for idx,style in route:
   n+=1;pool=P5 if beats==5 else P4 if beats==4 else P3;h,r=pool[idx];wind=W5[idx] if beats==5 else W4[idx] if beats==4 else ['E4:2 G4:2 R:2','G4:2 E4:2 R:2','A4:2 G4:2 R:2','F#4:2 D#4:2 R:2','E4:2 R:4'][idx]
   for lv,rv in [(1,REV1),(2,REV2)]:
    if level>=lv and n in rv:h,r,wind=rv[n]
   ch=H[h];w.bar(section,bpm,beats,h,ch);v=88 if style in ('piano','drive') else 73 if style=='duet' else 61 if style=='wind' else 81
   if style=='wind':
    notes,total=decode(r)
    for p,t,d in notes[:1]:w.add(p,t,.55,49,voice='signal_glint',hand='right')
   else:w.line(r,v)
   if style in ('duet','wind') or style=='close' and n%3!=0:
    wn,total=decode(wind);assert total==beats
    for p,t,d in wn:w.add(p,t*1.15,d-.18,64 if style=='wind' else 72,inst='clarinet',voice='second_station')
   # Low piano part is a sparse answer to the new clarinet subject, not an ostinato under every note.
   times=[0,2.5,4] if beats==5 else ([0,2] if beats==4 else [0])
   if style=='duet':times=[.5,3] if beats==4 else [0,3.5]
   for j,t in enumerate(times):w.add(ch[0] if j%2==0 else ch[1],t,.4,v-23,voice='dial_response',hand='left')
   w.release()
 return w.result(level)
