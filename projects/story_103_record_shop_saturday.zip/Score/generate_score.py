"""Work103: intimate opening, lightly swinging dialogue, asymmetric energy arc."""
from pathlib import Path
import json,difflib,copy,sys
P=Path(__file__).resolve().parent
sys.path.insert(0,str(P));from composition_data import *
def pitch(s):return 12*(int(s[-1])+1)+{'C':0,'D':2,'E':4,'F':5,'G':7,'A':9,'B':11}[s[0]]+s[1:-1].count('#')-s[1:-1].count('b')
def section(n):
 if n<=4:return 'Prelude','卷帘门还未打开',78,44,False
 if n<=20:return 'A','第一排试听位',118,68,True
 if n<=32:return 'B','柜角卡住',128,85,True
 if n<=40:return 'C','先腾出拐角',92,47,False
 if n<=60:return 'D','面对面挪动',120,72,True
 if n<=76:return 'E','新位置的第一张唱片',126,89,True
 if n<=84:return 'After','临时加出的尾句',106,63,True
 return 'Coda','门铃响过以后',72,45,False

def build(level):
 hs=[];lines=[]
 for h,s in PIANO_ROWS:hs+=h.split();lines +=s.split('|')
 assert len(lines)==len(hs)==88
 for lv,rd,hd in [(1,REV1,HREV1),(2,REV2,HREV2)]:
  if level>=lv:
   for n,s in rd.items():lines[n-1]=s
   for n,h in hd.items():hs[n-1]=h
 bars=[];events=[];pedals=[]
 for n,(line,h) in enumerate(zip(lines,hs),1):
  sec,label,bpm,dyn,swing=section(n);start=(n-1)*4;ch=CHORDS[h]
  if n in [4,20,32,40,60,76,84]:bpm-=4
  if n==88:bpm=64
  bars.append(dict(bar=n,start=start,beats=4,bpm=bpm,meter='4/4',meter_numerator=4,meter_denominator=4,section=sec,section_title_zh=label,harmony_name=h,harmony=ch,key_region='Db major' if sec=='C' else 'F major with secondary dominants',swing_eighth_pair_ratio='5:3 when explicitly paired' if swing else 'straight',texture='light_swing_call_and_response'))
  def add(p,t,d,v,inst,voice,hand='none'):
   assert 0<=t<t+d<=4.00001,(n,t,d)
   events.append(dict(bar=n,onset=round(start+t,6),duration=round(d,6),pitch=p,velocity=int(v),instrument=inst,voice=voice,hand=hand,harmony_name=h,phrase_id=f'{sec}_{(n-1)//4}',role='lead' if voice in ['melody','wind_theme'] else 'support',articulation='breath_and_light_swing',written_value_beats=d))
  tokens=[(p,float(u)/2) for p,u in (t.split(':') for t in line.split())]
  if swing:
   at=0.;i=0
   while i<len(tokens)-1:
    p,a=tokens[i];q,b=tokens[i+1]
    if a==b==.5 and abs(at-round(at))<1e-8:
     tokens[i]=(p,.625);tokens[i+1]=(q,.375);at+=1;i+=2
    else:at+=a;i+=1
  t=0.
  for i,(p,dur) in enumerate(tokens):
   if p!='R':add(pitch(p),t,dur-(.06 if swing else .04),dyn+(3 if t%1>.5 else 0)-(12 if sec in ['Prelude','C'] else 0)-(3 if i==len(tokens)-1 else 0),'piano','melody','right')
   t+=dur
  assert t==4
  # Two-beat bass with occasional approaches; no fixed four-on-the-floor loop.
  if sec=='Prelude':pat=[(0,ch[0],1.1)] if n in [1,3] else []
  elif sec=='C':pat=[(0,ch[0],1.4),(2.5,ch[1],1.2)]
  else:
   pat=[(0,ch[0],.56),(2,ch[2],.50)]
   if n%4 in [1,3]:pat.append((3.5,ch[1],.30))
   if n%4==0:pat=[(0,ch[0],.6),(2.625,ch[1],.32)]
   if level>=1 and 21<=n<=32:pat=[(.625,ch[0],.30),(2,ch[1],.4),(3.625,ch[2],.25)]
   if level>=2 and 61<=n<=76:pat=[(0,ch[0],.42),(1.625,ch[1],.30),(3,ch[2],.4)]
   if n in [32,40,60,84,88]:pat=[(0,ch[0],.65)]
  for at,p,d in pat:add(p,at,d,dyn-23,'piano','changing_two_beat_bass','left')
  if sec not in ['Prelude','C','Coda'] and n%4==2 and not (level>=2 and 61<=n<=76):
   add(ch[1],1.5,.30,dyn-27,'piano','offbeat_inner_response','left')
  if n<=4:
   ct=0.
   for tok in CLARINET_INTRO[n-1].split():
    p,u=tok.split(':');dur=int(u)/2
    if p!='R':add(pitch(p),ct,min(dur-.12,1.20*bpm/60),48,'clarinet','wind_theme')
    ct+=dur
  else:
   # Limited concert C4–B4 samples: genuine low-register answering phrases.
   available=[p for p in range(60,72) if p%12 in {x%12 for x in ch}]
   slots=[]
   if sec=='C' and n%4 in [1,2,3]:slots=[(.5,available[-1],.9),(2.5,available[0],.85)]
   elif n%4==1 and sec!='Coda':slots=[(1.25,available[0],.62),(2.75,available[-1],.60)]
   elif n%4==3 and sec not in ['B','Coda']:slots=[(.5,available[-1],.68),(2.5,available[0],.60)]
   elif n in [86,87]:slots=[(.5,available[0],.72)]
   if level>=1 and 21<=n<=32:slots=[(.5,available[-1],.48)] if n%2 else [(2.5,available[0],.52)]
   if level>=2 and 61<=n<=76:slots=[(.5,available[0],.5),(2.5,available[-1],.5)] if n%4 in [1,2] else []
   for at,p,seconds in slots:
    dur=min(seconds*bpm/60,4-at-.15);vel=48 if sec in ['C','Coda'] else 72 if sec in ['B','E'] else 64
    add(p,at,dur,vel,'clarinet','wind_answer')
  pedals.append(dict(bar=n,onset=start,controller=64,value=0,instrument='piano'))
  if sec in ['Prelude','C','Coda']:
   pedals +=[dict(bar=n,onset=start+.06,controller=64,value=31,instrument='piano'),dict(bar=n,onset=start+1.6,controller=64,value=0,instrument='piano'),dict(bar=n,onset=start+2.6,controller=64,value=27,instrument='piano'),dict(bar=n,onset=start+3.85,controller=64,value=0,instrument='piano')]
 events.sort(key=lambda e:(e['onset'],e['instrument'],e['pitch']))
 for i,e in enumerate(events):e['event_id']=f'w103-v{level}-{i:04d}'
 return dict(id=103,title='Saturday Morning at the Record Shop',title_zh='黑胶店的周六早晨',version=f'v{level}',bars=bars,events=events,pedals=pedals,total_beats=352,tail_seconds=5,instrumentation=['piano','clarinet'],performance_contract='Original recorded-acoustic-sample miniature, no imitation of another composition or live-performance claim.')
for v in range(3):
 d=build(v);(P/f'score_v{v}.json').write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
 report=dict(version=f'v{v}',bars=88,notes=len(d['events']),duration_seconds=sum(b['beats']*60/b['bpm'] for b in d['bars'])+5,human_listening_review=False)
 (P/f'audit_v{v}.json').write_text(json.dumps(report,indent=2))
 if v:
  old=build(v-1);changed=[]
  for n in range(1,89):
   clean=lambda e:{k:x for k,x in e.items() if k!='event_id'}
   if [clean(e) for e in old['events'] if e['bar']==n]!=[clean(e) for e in d['events'] if e['bar']==n]:changed.append(n)
  a=(P/f'score_v{v-1}.json').read_text();b=(P/f'score_v{v}.json').read_text();(P/f'exact_diff_v{v-1}_to_v{v}.patch').write_text(''.join(difflib.unified_diff(a.splitlines(True),b.splitlines(True),f'score_v{v-1}.json',f'score_v{v}.json')));(P/f'exact_diff_v{v-1}_to_v{v}.json').write_text(json.dumps({'changed_bars':changed,'count':len(changed)},indent=2))
for f in ['score.json','ensemble_score.json']:(P/f).write_text((P/'score_v2.json').read_text())
for inst in ['piano','clarinet']:
 x={**d,'events':[e for e in d['events'] if e['instrument']==inst],'pedals':d['pedals'] if inst=='piano' else []};(P/f'{inst}_score.json').write_text(json.dumps(x,ensure_ascii=False,indent=2))
print(json.dumps(report));print([json.loads((P/f'exact_diff_v{i}_to_v{i+1}.json').read_text())['count'] for i in range(2)])
