"""111. Newly authored rag strains, actual offbeat melody and alternating bass/chords."""
from pathlib import Path
import sys,json,difflib
P=Path(__file__).resolve().parent;sys.path.insert(0,str(P));from composition_data import *
def pitch(s):return 12*(int(s[-1])+1)+{'C':0,'D':2,'E':4,'F':5,'G':7,'A':9,'B':11}[s[0]]+s[1:-1].count('#')-s[1:-1].count('b')
def section(n):
 if n<=4:return 'intro','打开铅笔盒',88,66
 if n<=36:return 'rag_a','长线越过格子',88,80
 if n<=68:return 'rag_b','橡皮屑的小步',92,91
 if n<=72:return 'bridge','甩掉手上的灰',86,78
 if n<=104:return 'rag_c','纸背另一幅画',82,48 if n<=88 else 66
 if n<=136:return 'rag_d','把错线接起来',94,90 if n<=120 else 94
 return 'coda','合上盒盖之前',88,82

def build(level):
 hs=[];lines=[]
 for key in ORDER:h,s=BLOCKS[key];hs+=h.split();lines+=s.split('|')
 assert len(lines)==len(hs)==144,(len(lines),len(hs))
 for lv,rd,hd in [(1,REV1,HREV1),(2,REV2,HREV2)]:
  if level>=lv:
   for n,s in rd.items():lines[n-1]=s
   for n,h in hd.items():hs[n-1]=h
 bars=[];events=[];pedals=[]
 for n,(line,h) in enumerate(zip(lines,hs),1):
  sec,label,bpm,dyn=section(n);ch=H[h];start=(n-1)*2
  if n in [20,36,52,68,88,104,120,136]:bpm-=2
  if n==144:bpm=80
  bars.append(dict(bar=n,start=start,beats=2,bpm=bpm,meter='2/4',meter_numerator=2,meter_denominator=4,section=sec,section_title_zh=label,harmony_name=h,harmony=ch,key_region='F major' if sec=='rag_c' else 'G major' if sec=='rag_b' else 'A minor/C major' if sec=='rag_d' else 'C major',texture='syncopated_rag_strain',swing_ratio='straight written sixteenths; no triplet swing'))
  def add(p,t,d,v,voice,hand):
   assert 0<=t<t+d<=2.00001,(n,t,d)
   events.append(dict(bar=n,onset=round(start+t,6),duration=round(d,6),pitch=p,velocity=int(v),instrument='piano',voice=voice,hand=hand,harmony_name=h,role='lead' if voice=='rag_theme' else 'support',phrase_id=f'{sec}_{(n-1)//4}',articulation='clear_rag_syncopation',written_value_beats=d))
  at=0;mel=[]
  for i,tok in enumerate(line.split()):
   name,u=tok.split(':');dur=float(u)/4
   if name!='R':
    p=pitch(name);mel.append(p);add(p,at,dur-.035,dyn+(4 if at%1==.5 else 0)-(4 if i==len(line.split())-1 else 0),'rag_theme','right')
   at+=dur
  assert at==2
  root=ch[0]-12 if ch[0]>=48 else ch[0];fifth=ch[2]
  while fifth>48:fifth-=12
  chord=[ch[1],ch[2]]
  while max(chord)>=min(mel):chord=[p-12 for p in chord]
  bass=[(0,root,.20),(1,fifth,.20)];chord_times=[.5,1.5]
  if sec=='rag_c' and n<=88:bass=[(0,root,.38)];chord_times=[1.5]
  if n in [4,36,68,72,88,104,136]:bass=[(0,root,.24)];chord_times=[.5]
  if level>=1 and 53<=n<=68:
   # Answer off the theme's held note; the bass still gives an unambiguous two-beat floor.
   chord_times=[.75,1.5] if n%2 else [.5]
   if n in [56,60,64,68]:bass=[(0,root,.23)];chord_times=[.5]
  if level>=2 and 121<=n<=136:
   bass=[(0,root,.22),(1,ch[0] if ch[0]<min(mel) else root,.22)]
   chord_times=[.5,1.75] if n%2 else [.75,1.5]
   if n in [124,128,132,136]:bass=[(0,root,.26)];chord_times=[.5]
  if n==144:bass=[(0,36,.22),(1,48,.22)];chord_times=[.5,1.5]
  for t,p,d in bass:add(p,t,d,dyn-22,'alternating_low_step','left')
  for t in chord_times:
   for p in chord:add(p,t,.18 if t!=1.75 else .16,dyn-27,'offbeat_two_note_chord','left')
  pedals.append(dict(bar=n,onset=start,controller=64,value=0,instrument='piano'))
 events.sort(key=lambda e:(e['onset'],e['pitch']))
 for i,e in enumerate(events):e['event_id']=f'w111-v{level}-{i:04d}'
 return dict(id=111,title='A Rag in the Pencil Case',title_zh='铅笔盒里的爵士步',version=f'v{level}',bars=bars,events=events,pedals=pedals,total_beats=288,tail_seconds=5,instrument_map={'piano':'piano'},performance_contract='Original rag-inspired acoustic piano composition; straight notated syncopation, no copied rag melody or live-performance claim.')
def proj(d,n):return {'bar':d['bars'][n-1],'events':[{k:v for k,v in e.items() if k!='event_id'} for e in d['events'] if e['bar']==n],'pedals':[e for e in d['pedals'] if e['bar']==n]}
for v in range(3):
 d=build(v);(P/f'score_v{v}.json').write_text(json.dumps(d,ensure_ascii=False,indent=2));report={'version':f'v{v}','bars':144,'events':len(d['events']),'duration_seconds':sum(b['beats']*60/b['bpm'] for b in d['bars'])+5,'human_listening_review':False};(P/f'audit_v{v}.json').write_text(json.dumps(report,indent=2))
 if v:
  a=build(v-1);rows=[];patch=[]
  for n in range(1,145):
   x=proj(a,n);y=proj(d,n)
   if x!=y:
    rows.append({'bar':n,'before':x,'after':y});patch.extend(difflib.unified_diff(json.dumps(x,ensure_ascii=False,indent=2).splitlines(True),json.dumps(y,ensure_ascii=False,indent=2).splitlines(True),f'v{v-1}/bar{n}',f'v{v}/bar{n}'))
  (P/f'exact_diff_v{v-1}_to_v{v}.json').write_text(json.dumps({'count':len(rows),'changed_bars':[x['bar'] for x in rows],'comparison_excludes':['version','event_id'],'changes':rows},ensure_ascii=False,indent=2));(P/f'exact_diff_v{v-1}_to_v{v}.patch').write_text(''.join(patch))
for name in ['score.json','ensemble_score.json','piano_score.json']:(P/name).write_text((P/'score_v2.json').read_text())
print(json.dumps(report))
