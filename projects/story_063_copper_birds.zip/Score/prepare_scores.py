from pathlib import Path
import json
P=Path(__file__).parent;d=json.loads((P/'score_v2.json').read_text());(P/'ensemble_score.json').write_text(json.dumps(d,ensure_ascii=False,indent=2))
for instrument in ['clarinet','cello']:
 x={**d,'events':[e for e in d['events'] if e['instrument']==instrument],'pedals':[]}
 for f in [f'{instrument}_score.json',f'revisions/{instrument}_v2.json']:(P/f).write_text(json.dumps(x,ensure_ascii=False,indent=2))
