"""Original float32 sample-render bridge using the unmodified official sfizz C API.
Final arrangement/master is separately exported by actual REAPER.
"""
import ctypes as C,json,pathlib,argparse,struct,math,bisect,os
import numpy as np
ap=argparse.ArgumentParser();ap.add_argument('--score',required=True);ap.add_argument('--sfz',required=True);ap.add_argument('--out',required=True);ap.add_argument('--max-seconds',type=float);ap.add_argument('--enable-details',action='store_true');ap.add_argument('--preload-floats',type=int);a=ap.parse_args()
p=pathlib.Path(__file__).parent;lib=C.CDLL(os.environ.get('SFIZZ_LIBRARY',str(p/'sfizz_user/usr/lib/libsfizz.so.1')))
ptr=C.c_void_p;I=C.c_int;F=C.c_float
for name,rest,args in [('sfizz_create_synth',ptr,[]),('sfizz_free',None,[ptr]),('sfizz_set_sample_rate',None,[ptr,F]),('sfizz_set_samples_per_block',None,[ptr,I]),('sfizz_set_num_voices',None,[ptr,I]),('sfizz_enable_freewheeling',None,[ptr]),('sfizz_load_file',C.c_bool,[ptr,C.c_char_p]),('sfizz_send_note_on',None,[ptr,I,I,I]),('sfizz_send_note_off',None,[ptr,I,I,I]),('sfizz_send_cc',None,[ptr,I,I,I]),('sfizz_render_block',None,[ptr,C.POINTER(C.POINTER(F)),I,I]),('sfizz_get_unknown_opcodes',C.c_char_p,[ptr])]:
 fn=getattr(lib,name);fn.restype=rest;fn.argtypes=args
s=lib.sfizz_create_synth();sr=44100;block=512
lib.sfizz_get_preload_size.argtypes=[ptr];lib.sfizz_get_preload_size.restype=C.c_uint
lib.sfizz_set_preload_size.argtypes=[ptr,C.c_uint];lib.sfizz_set_preload_size.restype=None
original_preload=lib.sfizz_get_preload_size(s)
if a.preload_floats is not None:
 assert 256<=a.preload_floats<=1048576
 lib.sfizz_set_preload_size(s,a.preload_floats)
actual_preload=lib.sfizz_get_preload_size(s)
if a.preload_floats is not None:assert actual_preload==a.preload_floats
print('preload floats:',actual_preload,'default:',original_preload,flush=True)
lib.sfizz_set_sample_rate(s,sr);lib.sfizz_set_samples_per_block(s,block);lib.sfizz_set_num_voices(s,64);lib.sfizz_enable_freewheeling(s)
assert lib.sfizz_load_file(s,str(pathlib.Path(a.sfz).resolve()).encode()),'SFZ load failed'
unknown=lib.sfizz_get_unknown_opcodes(s);print('unsupported SFZ opcodes:',unknown.decode() if unknown else '(none)',flush=True)
d=json.loads(pathlib.Path(a.score).read_text());bars=d['bars'];starts=[b['start'] for b in bars];times=[];t=0
for b in bars:times.append(t);t+=b['beats']*60/b['bpm']
def seconds(beat):
 i=max(0,bisect.bisect_right(starts,beat)-1);return times[i]+(beat-starts[i])*60/bars[i]['bpm']
ev=[]
for e in d['events']:
 ev.extend([(round(seconds(e['onset'])*sr),2,'on',e['pitch'],e['velocity']),(round(seconds(e['onset']+e['duration'])*sr),0,'off',e['pitch'],0)])
for e in d.get('pedals',[]):ev.append((round(seconds(e['onset'])*sr),1,'cc',64,e['value']))
if a.enable_details:
 ev.extend([(0,1,'cc',20,62),(0,1,'cc',21,20),(0,1,'cc',22,18),(0,1,'cc',23,50)])
duration=t+d.get('tail_seconds',8)
if a.max_seconds:duration=min(duration,a.max_seconds)
frames=round(duration*sr);ev=sorted(e for e in ev if e[0]<frames);k=0
left=np.zeros(block,dtype=np.float32);right=np.zeros(block,dtype=np.float32);channels=(C.POINTER(F)*2)(left.ctypes.data_as(C.POINTER(F)),right.ctypes.data_as(C.POINTER(F)));interleaved=np.zeros((block,2),dtype='<f4');peak=0.;ss=0.;path=pathlib.Path(a.out);path.parent.mkdir(parents=True,exist_ok=True)
# IEEE float32 RIFF WAVE, two channels, no intermediate integer quantization.
with path.open('wb') as f:
 nbytes=frames*8;fmt=struct.pack('<HHIIHH',3,2,sr,sr*8,8,32);header=b'RIFF'+struct.pack('<I',36+nbytes)+b'WAVEfmt '+struct.pack('<I',16)+fmt+b'data'+struct.pack('<I',nbytes);f.write(header)
 for pos in range(0,frames,block):
  n=min(block,frames-pos)
  while k<len(ev) and ev[k][0]<pos+n:
   tick,_,typ,key,value=ev[k];delay=max(0,tick-pos)
   {'on':lib.sfizz_send_note_on,'off':lib.sfizz_send_note_off,'cc':lib.sfizz_send_cc}[typ](s,delay,key,value);k+=1
  lib.sfizz_render_block(s,channels,2,n);interleaved[:n,0]=left[:n];interleaved[:n,1]=right[:n];y=interleaved[:n];assert np.isfinite(y).all();peak=max(peak,float(np.abs(y).max()));ss+=float(np.sum(y.astype(np.float64)**2));f.write(y.tobytes())
lib.sfizz_free(s)
r={'sample_rate':sr,'channels':2,'source_bits':'IEEEfloat32','frames':frames,'duration':duration,'peak':peak,'rms':math.sqrt(ss/(frames*2)),'source_sfz':str(pathlib.Path(a.sfz).resolve()),'score':str(pathlib.Path(a.score).resolve()),'details_enabled':a.enable_details,'preload_floats':actual_preload,'default_preload_floats':original_preload,'renderer':'official libsfizz1.2.3 C API, original event scheduler','final_master_requires':'actual REAPER export'};path.with_suffix('.render.json').write_text(json.dumps(r,indent=2));print(json.dumps(r))
