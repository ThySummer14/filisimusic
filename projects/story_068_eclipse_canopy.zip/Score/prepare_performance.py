from pathlib import Path
import json,bisect,copy
P=Path(__file__).parent;R=P.parent;d=json.loads((P/'score_v2.json').read_text());mapping_path=R/'assets/iowa_flute_C5_B5/mapping_manifest.json';mapping_path=mapping_path if mapping_path.exists() else R/'InstrumentMapping/iowa_flute_C5_B5/mapping_manifest.json';mapping=json.loads(mapping_path.read_text());lat={(x['layer'],x['midi']):x['voiced_onset_delay_after_tuning_seconds'] for x in mapping['files']};starts=[b['start'] for b in d['bars']];times=[];t=0
for b in d['bars']:times.append(t);t+=b['beats']*60/b['bpm']
def sec(beat):
 i=max(0,bisect.bisect_right(starts,beat)-1);return times[i]+(beat-starts[i])*60/d['bars'][i]['bpm']
def beat(seconds):
 i=max(0,bisect.bisect_right(times,seconds)-1);return starts[i]+(seconds-times[i])*d['bars'][i]['bpm']/60
rows=[]
for e in d['events']:
 if e['instrument']!='flute':continue
 layer='pp' if e['velocity']<=55 else 'mf';target=sec(e['onset']);end=sec(e['onset']+e['duration']);advance=lat[layer,e['pitch']];trigger=target-advance;assert trigger>=0;new_onset=beat(trigger);new_end=beat(end)
 rows.append({'pitch':e['pitch'],'layer':layer,'bar':e['bar'],'target_voiced_arrival_seconds':target,'sample_trigger_seconds':trigger,'measured_advance_seconds':advance,'note_off_seconds':end,'actual_gate_seconds':end-trigger})
 e['onset']=new_onset;e['duration']=new_end-new_onset;e['bar']=d['bars'][max(0,bisect.bisect_right(starts,new_onset)-1)]['bar']
 assert end-trigger<=1.60+1e-8
flute=sorted([e for e in d['events'] if e['instrument']=='flute'],key=lambda e:e['onset']);gaps=[];shortenings=[]
for a,b in zip(flute,flute[1:]):
 end=sec(a['onset']+a['duration']);limit=sec(b['onset'])-.14
 if end>limit:
  shortenings.append({'bar':a['bar'],'pitch':a['pitch'],'original_note_off_seconds':end,'actual_note_off_seconds':limit,'shortening_seconds':end-limit})
  a['duration']=beat(limit)-a['onset']
  assert a['duration']>0
for a,b in zip(flute,flute[1:]):
 gap=sec(b['onset'])-sec(a['onset']+a['duration']);assert gap>.12+1e-8;gaps.append(gap)
for row,event in zip(rows,flute):
 assert row['pitch']==event['pitch']
 row['intended_original_note_off_seconds']=row['note_off_seconds']
 row['note_off_seconds']=sec(event['onset']+event['duration'])
 row['actual_gate_seconds']=row['note_off_seconds']-sec(event['onset'])
d['events'].sort(key=lambda e:(e['onset'],e['pitch']));d['stage']='v3_sample_aware_flute_arrivals_and_release_clearance'
for f in ['ensemble_score.json','revisions/ensemble_v3.json']:(P/f).write_text(json.dumps(d,ensure_ascii=False,indent=2))
for inst in ['piano','flute']:
 x={**d,'events':[e for e in d['events'] if e['instrument']==inst],'pedals':d['pedals'] if inst=='piano' else []}
 for f in [f'{inst}_score.json',f'revisions/{inst}_v3.json']:(P/f).write_text(json.dumps(x,ensure_ascii=False,indent=2))
(P/'revisions/flute_attack_alignment_v3.json').write_text(json.dumps({'method':'Advance each sampled note by its recorded pitch/layer coarse voiced-onset delay after tuning. Preserve intended note-off unless a documented shortening is needed for0.14sec separation from the next trigger; gate includes breath. This is measured-attack-informed scheduling, not perfect perceptual alignment or human listening.','rows':rows,'max_actual_gate_seconds':max(x['actual_gate_seconds'] for x in rows),'min_inter_note_gate_gap_seconds':min(gaps),'release_setting_seconds':.12,'gate_shortenings_to_prevent_release_overlap':shortenings},indent=2))
(P/'revisions/pass3.json').write_text(json.dumps({'round':3,'kind':'sample_aware_performance_correction','changes':['Preserve original voiced-arrival intentions and align each flute sample trigger using its own pitch/layer measured breath delay, not a globaloffset.','Keep intended note-offs except documented short reductions needed to keep0.14sec gate clearance; re-audit actual gates under1.60sec. Preserve piano harmony and target pitched arrivals.'],'substantive_score_revisions':2,'human_listening_review':False},indent=2));print('maxgate',max(x['actual_gate_seconds'] for x in rows),'mingap',min(gaps))
