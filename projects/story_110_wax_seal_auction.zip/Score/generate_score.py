"""110: piano scherzo phrases and low-register clarinet bidding/long-line roles."""
from pathlib import Path
import json,difflib,sys,bisect
P=Path(__file__).resolve().parent;sys.path.insert(0,str(P));from composition_data import *
def pitch(s):return 12*(int(s[-1])+1)+{'C':0,'D':2,'E':4,'F':5,'G':7,'A':9,'B':11}[s[0]]+s[1:-1].count('#')-s[1:-1].count('b')
def section(n):
 if n<=8:return 'opening','举牌的试句',126,64,3
 if n<=40:return 'bidders','两个不同的号码',132,77,3
 if n<=64:return 'compression','越来越短的加价',144,91,3
 if n<=80:return 'rubbing','纸上的错字',78,44,4
 if n<=104:return 'exchange','交换拓片',132,81,3
 if n<=112:return 'new_print','新印落纸',120,86,3
 if n<=120:return 'release','慢慢放下',116,66,3
 return 'coda','摊开晾干',78,45,3

def build(level):
 lines=[];hs=[]
 for key in ORDER:h,s=BLOCKS[key];hs+=h.split();lines+=s.split('|')
 assert len(lines)==len(hs)==128
 for lv,rd,hd in [(1,REV1,HREV1),(2,REV2,HREV2)]:
  if level>=lv:
   for n,s in rd.items():lines[n-1]=s
   for n,h in hd.items():hs[n-1]=h
 bars=[];events=[];pedals=[];start=0
 for n,(line,h) in enumerate(zip(lines,hs),1):
  sec,label,bpm,dyn,beats=section(n);ch=H[h]
  if n in [8,40,64,80,104,120]:bpm-=4
  if n>=125:bpm-=2*(n-124)
  isquiet=sec=='rubbing';delegated=level>=2 and sec=='exchange' and n%4 in [1,2]
  bars.append(dict(bar=n,start=start,beats=beats,bpm=bpm,meter='4/4' if isquiet else '3/4' if sec=='coda' else '6/8',meter_numerator=4 if isquiet else 3 if sec=='coda' else 6,meter_denominator=4 if isquiet or sec=='coda' else 8,section=sec,section_title_zh=label,harmony_name=h,harmony=ch,key_region='Db major' if isquiet else 'C minor/E major side-step' if sec=='compression' else 'Ab major',texture='clarinet_lead_with_sparse_piano' if isquiet or delegated else 'light_scherzo_with_low_wind_replies'))
  def add(p,t,d,v,inst,voice,hand='none'):
   assert 0<=t<t+d<=beats+.00001,(n,t,d,beats)
   events.append(dict(bar=n,onset=round(start+t,6),duration=round(d,6),pitch=p,velocity=int(v),instrument=inst,voice=voice,hand=hand,harmony_name=h,role='lead' if voice in ['theme','clarinet_line','delegated_tail'] else 'support',phrase_id=f'{sec}_{(n-1)//6}',articulation='shaped_nonlegato',written_value_beats=d))
  at=0.;mel=[]
  for i,tok in enumerate(line.split()):
   name,u=tok.split(':');dur=float(u)/2
   if name!='R':
    p=pitch(name);mel.append(p)
    if not delegated or at==0:add(p,at,min(.32,dur-.07) if delegated else dur-.07,(28 if isquiet else dyn)+(4 if at==1.5 and not isquiet else 0)-(4 if i==len(line.split())-1 else 0),'piano','theme','right')
   at+=dur
  assert at==beats,(n,at,beats)
  if isquiet:pat=[(0,ch[0],.55),(2,ch[1],.45)]
  elif sec=='coda':pat=[(0,ch[0],.75)] if n%2 else [(1.5,ch[1],.6)]
  else:
   pat=[(0,ch[0],.34),(1.5,ch[1],.34)]
   if n%3==1:pat=[(.5,ch[1],.30),(2,ch[0],.36)]
   if n%3==2:pat=[(0,ch[0],.38),(2.5,ch[2],.26)]
   if level>=1 and sec=='compression':
    # Six-bar, then four-bar, then two-bar fragments leave whole large beats empty.
    pat=[(0,ch[0],.3),(1.5,ch[2],.3)] if n<=56 else [(0,ch[0],.38)] if n<=60 else [(.5,ch[1],.30)]
   if delegated:pat=[(0,ch[0],.3),(1.5,ch[2],.3)]
   if n in [8,40,64,80,104,112,120]:pat=[(0,ch[0],.5)]
  for t,p,dur in pat:
   while p>=min(mel):p-=12
   add(p,t,dur,29 if isquiet else dyn-25,'piano','lower_bid_pulse','left')
  available=[p for p in range(60,72) if p%12 in {x%12 for x in ch}];assert available
  wind=[]
  if isquiet:
   for t,s in zip([.25,2.25],WIND_QUIET[n-65]):
    if s is not None:wind.append((t,pitch(s),1.35*60/bpm,48,'clarinet_line'))
  elif delegated:
   # Exact compositional handoff, rather than doubling the deleted right-hand tail.
   pairs={1:(63,68),2:(67,60),3:(61,65),0:(63,67)};a,b=pairs[n%4]
   pcs={x%12 for x in ch}
   def tonal(p):return p if p%12 in pcs else min(available,key=lambda q:abs(q-p))
   wind=[(.5,tonal(a),.40,70,'delegated_tail'),(1.9,tonal(b),.38,68,'delegated_tail')]
  elif sec=='opening' and n in [4,8]:wind=[(1.6,available[-1],.48,62,'low_bid')]
  elif sec=='bidders' and n%4==2:wind=[(.5,available[0],.46,64,'low_bid'),(1.9,available[-1],.40,64,'low_bid')]
  elif sec=='bidders' and n%4==0:wind=[(1.6,available[0],.5,64,'low_bid')]
  elif sec=='compression' and n in [46,50,52,58,60,62,64]:wind=[(1.7,available[-1],.40,78,'short_counterbid')]
  elif sec in ['exchange','new_print'] and n%4==0:wind=[(1.6,available[0],.48,69,'low_bid')]
  elif sec=='release' and n in [113,116,119]:wind=[(.6,available[-1],.72,48,'afterprint')]
  elif sec=='coda' and n in [122,125,128]:wind=[(.5,available[0],.8,48,'drying_line')]
  for t,p,seconds,v,voice in wind:
   dur=seconds*bpm/60;assert dur*60/bpm<=1.25;add(p,t,dur,v,'clarinet',voice)
  pedals.append(dict(bar=n,onset=start,controller=64,value=0,instrument='piano'))
  if isquiet:
   pedals.extend([dict(bar=n,onset=start+.06,controller=64,value=27,instrument='piano'),dict(bar=n,onset=start+1.7,controller=64,value=0,instrument='piano'),dict(bar=n,onset=start+2.12,controller=64,value=23,instrument='piano'),dict(bar=n,onset=start+3.8,controller=64,value=0,instrument='piano')])
  elif sec in ['release','coda']:pedals.extend([dict(bar=n,onset=start+.06,controller=64,value=25,instrument='piano'),dict(bar=n,onset=start+1.25,controller=64,value=0,instrument='piano')])
  start+=beats
 events.sort(key=lambda e:(e['onset'],e['instrument'],e['pitch']))
 for i,e in enumerate(events):e['event_id']=f'w110-v{level}-{i:04d}'
 return dict(id=110,title='The Wax-Seal Auction',title_zh='蜡封竞拍厅',version=f'v{level}',bars=bars,events=events,pedals=pedals,total_beats=start,tail_seconds=5,instrument_map={'piano':'piano','clarinet':'clarinet'},performance_contract='Original acoustic-sample chamber scherzo. Genuine Iowa clarinet layers, separated notes, no live-performance or listening claim.')
def proj(d,n):return {'bar':d['bars'][n-1],'events':[{k:v for k,v in e.items() if k!='event_id'} for e in d['events'] if e['bar']==n],'pedals':[e for e in d['pedals'] if e['bar']==n]}
for v in range(3):
 d=build(v);(P/f'score_v{v}.json').write_text(json.dumps(d,ensure_ascii=False,indent=2));report={'version':f'v{v}','bars':128,'events':len(d['events']),'duration_seconds':sum(b['beats']*60/b['bpm'] for b in d['bars'])+5,'human_listening_review':False};(P/f'audit_v{v}.json').write_text(json.dumps(report,indent=2))
 if v:
  a=build(v-1);rows=[];patch=[]
  for n in range(1,129):
   x=proj(a,n);y=proj(d,n)
   if x!=y:
    rows.append({'bar':n,'before':x,'after':y});patch.extend(difflib.unified_diff(json.dumps(x,ensure_ascii=False,indent=2).splitlines(True),json.dumps(y,ensure_ascii=False,indent=2).splitlines(True),f'v{v-1}/bar{n}',f'v{v}/bar{n}'))
  (P/f'exact_diff_v{v-1}_to_v{v}.json').write_text(json.dumps({'count':len(rows),'changed_bars':[x['bar'] for x in rows],'comparison_excludes':['version','event_id'],'changes':rows},ensure_ascii=False,indent=2));(P/f'exact_diff_v{v-1}_to_v{v}.patch').write_text(''.join(patch))
for name in ['score.json','ensemble_score.json']:(P/name).write_text((P/'score_v2.json').read_text())
for inst in ['piano','clarinet']:
 x={**d,'events':[e for e in d['events'] if e['instrument']==inst],'pedals':d['pedals'] if inst=='piano' else []};(P/f'{inst}_score.json').write_text(json.dumps(x,ensure_ascii=False,indent=2))
starts=[b['start'] for b in d['bars']];times=[];t=0
for b in d['bars']:times.append(t);t+=b['beats']*60/b['bpm']
def sec(t):
 i=max(0,bisect.bisect_right(starts,t)-1);return times[i]+(t-starts[i])*60/d['bars'][i]['bpm']
w=sorted([e for e in d['events'] if e['instrument']=='clarinet'],key=lambda e:e['onset']);gaps=[sec(b['onset'])-sec(a['onset']+a['duration']) for a,b in zip(w,w[1:])];assert min(gaps)>=.14;print(json.dumps({**report,'clarinet_min_gap_seconds':min(gaps)}))
