#!/usr/bin/env python3
"""Independent disk-based symbolic verifier for work 088.
Does not import or execute the generator, use its constants, or touch audio.
Standard library only. Recomputes seconds by integrating each bar, tests actual
held grips, checks pedal-extended bass windows and reconstructs exact revisions.
"""
from pathlib import Path
from collections import defaultdict,Counter
import json,math,hashlib,difflib,statistics
R=Path(__file__).resolve().parent

def load(n):return json.loads((R/n).read_text(encoding='utf-8'))
def sha(n):return hashlib.sha256((R/n).read_bytes()).hexdigest()
def save(n,d):(R/n).write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def inspect(s):
 errors=[];warnings=[];bs=s['bars'];ev=s['events']
 def ck(ok,message):
  if not ok:errors.append(message)
 def sec(t):return sum(max(0,min(t-b['start'],b['beats']))*60/b['bpm'] for b in bs)
 def off(e):return e['onset']+e['duration']
 ck(s['id']==88 and s['title']=='The Archivist of Thunder','work identity')
 ck(len(bs)==72 and s['total_beats']==288 and s['tail_seconds']==6,'total grid')
 for i,b in enumerate(bs):
  ck((b['bar'],b['start'],b['beats'],b['meter_numerator'],b['meter_denominator'])==(i+1,4*i,4,4,4),f'bar grid {i+1}')
  ck(40<=b['bpm']<=180,'tempo');ck(abs(b['time_start_seconds']-sec(b['start']))<1e-7,'bar seconds')
 ck(195<=sec(288)+s['tail_seconds']<=220,'duration target')
 ck(abs(s['music_seconds']-sec(288))<1e-7 and abs(s['total_seconds_with_tail']-sec(288)-6)<1e-7,'top-level seconds')
 ck(len({e['event_id'] for e in ev})==len(ev),'duplicate event IDs')
 ck(ev==sorted(ev,key=lambda e:(e['onset'],e['instrument'],e['pitch'],e['event_id'])),'stable event sort')
 keys=('event_id','bar','onset','duration','pitch','velocity','instrument','voice','hand','role','phrase_id','layer','sample_layer')
 for e in ev:
  ck(all(k in e for k in keys),'event schema')
  ck(all(math.isfinite(e[k]) for k in ('onset','duration','pitch','velocity')),'nonfinite event')
  ck(e['duration']>0 and 0<=e['onset']<off(e)<=288,'event bounds')
  ck(isinstance(e['pitch'],int) and 0<=e['pitch']<=127 and isinstance(e['velocity'],int) and 1<=e['velocity']<=127,'MIDI bounds')
  b=bs[e['bar']-1];ck(b['start']<=e['onset']<b['start']+b['beats'],'event/bar membership')
  ck(e['harmony_name']==b['harmony_name'],'event harmony tag')
  ck(abs(e['target_on_beats']-e['onset'])<1e-6 and abs(e['target_off_beats']-off(e))<1e-6,'absolute beat fields')
  ck(abs(e['target_on_seconds']-sec(e['onset']))<1e-7 and abs(e['target_off_seconds']-sec(off(e)))<1e-7,'seconds integral')
  if e['harmonic_function']=='chord_tone':ck(e['pitch']%12 in {x%12 for x in b['harmony']},'chord-tone claim')
  if e['hand']=='left':ck(e['harmonic_function']=='chord_tone','LH harmonic sentence')
 pn=[e for e in ev if e['instrument']=='piano'];cs=sorted([e for e in ev if e['instrument']=='cello'],key=lambda e:e['onset']);mel=sorted([e for e in pn if e['voice']=='melody'],key=lambda e:e['onset'])
 ck({e['instrument'] for e in ev}=={'piano','cello'},'instrument set')
 for e in pn:
  ks=e['hand_position_keys'];lo,hi=e['hand_position_range'];ck(ks==sorted(set(ks)) and [lo,hi]==[ks[0],ks[-1]] and hi-lo<=12,'position key/range')
  ck(e['pitch'] in ks and 1<=e['finger']<=5,'finger range')
  if e['hand']=='right':
   ck(len(ks)==5 and ks[e['finger']-1]==e['pitch'],'RH explicit five-finger mapping')
   ck(e['hand_position_id']=='R'+'_'.join(map(str,ks)),'RH position identity')
  else:
   ck(e['hand']=='left' and len(ks)==3 and [5,3,1][ks.index(e['pitch'])]==e['finger'],'LH explicit grip mapping')
   ck(e['hand_position_id']=='L'+'_'.join(map(str,ks)),'LH position identity')
  ck(e['layer']=='natural' and e['sample_layer']=='approved_natural_piano','piano source intent')
 # Sweep all attacks and releases; pedal never enters the active-key set.
 endpoints=defaultdict(list)
 for i,e in enumerate(pn):endpoints[e['onset']].append((1,i));endpoints[off(e)].append((0,i))
 active={};same=[];cross=[];fc=[];spans={'left':0,'right':0};keysheld={'left':0,'right':0}
 for t,changes in sorted(endpoints.items()):
  for kind,i in sorted(changes):
   if kind==0:active.pop(i,None)
   else:active[i]=pn[i]
  notes=list(active.values());counts=Counter(e['pitch'] for e in notes)
  if max(counts.values(),default=0)>1:same.append(t)
  hh={h:[e for e in notes if e['hand']==h] for h in spans}
  for h,ns in hh.items():
   if not ns:continue
   pitches=[e['pitch'] for e in ns];spans[h]=max(spans[h],max(pitches)-min(pitches));keysheld[h]=max(keysheld[h],len(ns))
   if len({e['finger'] for e in ns})!=len(ns):fc.append({'time':t,'hand':h})
   if len({e['hand_position_id'] for e in ns})>1:errors.append('held notes across a declared hand reposition')
  if hh['left'] and hh['right'] and max(e['pitch'] for e in hh['left'])>=min(e['pitch'] for e in hh['right']):cross.append(t)
 ck(not same and not cross and not fc,'held-key overlap/crossing/finger collision');ck(max(spans.values())<=12,'held hand span')
 transfers=[];exemptions=[]
 for hand in ('left','right'):
  ns=[e for e in pn if e['hand']==hand];groups=defaultdict(list)
  for e in ns:groups[e['onset']].append(e)
  groups=sorted(groups.items())
  for (oldon,old),(on,new) in zip(groups,groups[1:]):
   op=old[0]['hand_position_range'];np=new[0]['hand_position_range'];og=[min(e['pitch'] for e in old),max(e['pitch'] for e in old)];ng=[min(e['pitch'] for e in new),max(e['pitch'] for e in new)]
   gp=max(abs(a-b) for a,b in zip(og,ng));pm=max(abs(a-b) for a,b in zip(op,np));change=old[0]['hand_position_id']!=new[0]['hand_position_id']
   if not change and hand=='right':
    if gp>4:exemptions.append({'onset':on,'travel_semitones':gp,'position_keys':new[0]['hand_position_keys'],'from_finger':old[0]['finger'],'to_finger':new[0]['finger']})
    continue
   if not change and gp<=4:continue
   need=.075+.012*max(0,max(gp,pm)-4);latest=max(off(e) for e in ns if e['onset']<on);avail=sec(on)-sec(latest);ok=avail+1e-6>=need
   transfers.append({'hand':hand,'onset':on,'old_grip':og,'new_grip':ng,'old_position':op,'new_position':np,'actual_grip_edge_travel_semitones':gp,'position_edge_travel_semitones':pm,'required_release_seconds':round(need,9),'available_release_seconds':round(avail,9),'passed':ok});ck(ok,'strict released grip transfer')
 # Explicit bow gates, actual source register and layers.
 for e in cs:
  ck(50<=e['pitch']<=59 and e['source_pitch_midi']==e['pitch'],'recorded cello range/no transposition')
  ck(e['layer']==e['sample_layer'] and e['layer'] in ('pp','mf'),'recorded cello layer')
  ck(e['source_family']=='University of Iowa cello arco' and e['articulation']=='arco_short_separate_bows','cello source/articulation')
  ck(e['hand']=='not_applicable' and e['velocity_controls']=='within_recorded_layer_amplitude_intent','cello hand/layer semantics')
  ck(abs(sec(off(e))-sec(e['onset'])-e['nominal_gate_seconds'])<1e-6,'cello seconds metadata')
 gates=[sec(off(e))-sec(e['onset']) for e in cs];gaps=[sec(b['onset'])-sec(off(a)) for a,b in zip(cs,cs[1:])]
 ck(min(gates)>=.4-1e-6 and max(gates)<=.85+1e-6,'cello bowed gates');ck(min(gaps)>=.15-1e-6,'cello bow-change gap')
 ck({e['layer'] for e in cs}=={'pp','mf'},'both recorded cello layers used')
 # Reconstruct pedal-resonating LH windows independently from CC64 states.
 pedals=s['pedals'];ck(pedals==sorted(pedals,key=lambda e:e['onset']),'pedal order')
 for e in pedals:ck(e['instrument']=='piano' and e['controller']==64 and 0<=e['value']<=127 and abs(e['target_on_seconds']-sec(e['onset']))<1e-7,'pedal schema')
 ck(pedals[-1]['value']==0 and pedals[-1]['onset']<=288,'final pedal release')
 lh=[e for e in pn if e['hand']=='left'];resonances=[]
 for e in lh:
  end=off(e);state=[pd for pd in pedals if pd['onset']<=end]
  if state and state[-1]['value']>0:
   releases=[pd['onset'] for pd in pedals if pd['onset']>end and pd['value']==0];ck(bool(releases),'unreleased pedal');end=releases[0] if releases else 288
  resonances.append((e['onset'],end,e['event_id']))
 clear=[];before=[];after=[]
 for c in cs:
  for start,end,eid in resonances:
   if end<=c['onset']:
    gap=sec(c['onset'])-sec(end);before.append(gap)
   elif start>=off(c):
    gap=sec(start)-sec(off(c));after.append(gap)
   else:gap=-1
   clear.append(gap)
 ck(min(clear)>=.18-1e-6,'pedal-aware LH/cello gap');ck(min(before)>=.22-1e-6,'LH before cello clearance')
 quiet_lead=[b['bar'] for b in bs if b['lead_instrument']=='cello'];ck(quiet_lead==[38,40,42,44,46],'quieter cello answer leads')
 ck(not any(e['bar'] in quiet_lead for e in lh),'LH leaves quiet leads')
 phrases={p['phrase_id']:p for p in s['phrases']};ck(len(phrases)==len(s['phrases'])==36,'phrase list')
 ck(set(phrases)=={e['phrase_id'] for e in ev},'phrase coverage')
 for pid,ph in phrases.items():
  ns=[e for e in ev if e['phrase_id']==pid];ck(all(ph['first_bar']<=e['bar']<=ph['last_bar'] and ph['instrument']==e['instrument'] for e in ns),'phrase membership')
  ck(abs(ph['target_on_beats']-min(e['onset'] for e in ns))<1e-6 and abs(ph['target_off_beats']-max(off(e) for e in ns))<1e-6,'phrase endpoints')
  ck(ph['layers_used']==sorted({e['layer'] for e in ns}) and ph['roles_used']==sorted({e['role'] for e in ns}) and ph['voices_used']==sorted({e['voice'] for e in ns}),'phrase classification')
  ck(abs(ph['target_on_seconds']-sec(ph['target_on_beats']))<1e-7 and abs(ph['target_off_seconds']-sec(ph['target_off_beats']))<1e-6,'phrase seconds')
 ck({e['bar'] for e in mel}==set(range(1,73)),'piano melodic thread through form')
 leaps=[abs(a['pitch']-b['pitch']) for a,b in zip(mel,mel[1:])];ck(max(leaps)<=12,'melody successive leap')
 signatures=[]
 for q in range(18):signatures.append(tuple((e['pitch'],round(e['onset']-16*q,6),e['written_value_beats']) for e in mel if 4*q+1<=e['bar']<=4*q+4))
 duplicate_phrases=[(i+1,j+1) for i,a in enumerate(signatures) for j,b in enumerate(signatures) if i<j and a==b]
 if s['version']=='v2':ck(not duplicate_phrases,'final phrases all developed')
 quiet=[e for e in mel if 37<=e['bar']<=48];drama=[e for e in mel if 25<=e['bar']<=36];qvel=statistics.mean(e['velocity'] for e in quiet);dvel=statistics.mean(e['velocity'] for e in drama)
 ck(dvel-qvel>=20,'real dynamic contrast');ck(statistics.mean(e['written_value_beats'] for e in quiet)>statistics.mean(e['written_value_beats'] for e in drama) or s['version']=='v0','rhythmic contrast')
 # Longest fully unheld gap, excluding the requested final reverb tail.
 intervals=sorted((e['onset'],off(e)) for e in ev);merged=[]
 for st,en in intervals:
  if merged and st<=merged[-1][1]:merged[-1][1]=max(merged[-1][1],en)
  else:merged.append([st,en])
 silences=[{'start_beat':a[1],'end_beat':b[0],'seconds':sec(b[0])-sec(a[1])} for a,b in zip(merged,merged[1:])];longest=max(silences,key=lambda x:x['seconds']);ck(longest['seconds']<1.2,'needless all-voice silence')
 # Repeated-pitch cello density is descriptive; no sample audition loops.
 runs=[];run=1
 for a,b in zip(cs,cs[1:]):
  if a['pitch']==b['pitch']:run+=1
  else:runs.append(run);run=1
 runs.append(run)
 return {'passed':not errors,'errors':sorted(set(errors)),'warnings':warnings,'event_count':len(ev),'duration_with_tail_seconds':round(sec(288)+6,9),'maximum_held_span_semitones':spans,'maximum_simultaneous_keys':keysheld,'same_key_overlap_count':len(same),'hand_crossing_count':len(cross),'finger_collision_count':len(fc),'strict_transfer_count':len(transfers),'strict_transfer_count_by_hand':dict(Counter(x['hand'] for x in transfers)),'minimum_transfer_margin_seconds':round(min(x['available_release_seconds']-x['required_release_seconds'] for x in transfers),9),'strict_transfers':transfers,'verified_RH_five_finger_exemptions':exemptions,'cello_event_count':len(cs),'cello_range':[min(e['pitch'] for e in cs),max(e['pitch'] for e in cs)],'actual_recorded_layers':dict(Counter(e['layer'] for e in cs)),'cello_gate_seconds':[round(min(gates),9),round(max(gates),9)],'minimum_cello_bow_gap_seconds':round(min(gaps),9),'minimum_pedal_aware_LH_clearance_seconds':round(min(clear),9),'minimum_pedal_aware_LH_before_cello_seconds':round(min(before),9),'minimum_LH_after_cello_seconds':round(min(after),9),'quiet_cello_lead_bars':quiet_lead,'maximum_melody_leap_semitones':max(leaps),'unique_four_bar_melodies':len(set(signatures)),'duplicate_four_bar_melodies':duplicate_phrases,'quiet_mean_melody_velocity':round(qvel,3),'development_mean_melody_velocity':round(dvel,3),'longest_all_voice_key_gate_silence':longest,'maximum_consecutive_repeated_cello_pitch_count':max(runs),'scope':'Independent symbolic timing, source-contract and playability audit; no audio or timbre assertion.'}

def verify_diff(a,b,d):
 errors=[];changes=[];musical=[]
 def core(ns):return [{k:e[k] for k in ('onset','duration','pitch','instrument','voice','hand')} for e in ns]
 entries={x['bar']:x for x in d['changes']}
 for n in range(1,73):
  ab=a['bars'][n-1];bb=b['bars'][n-1];ae=[e for e in a['events'] if e['bar']==n];be=[e for e in b['events'] if e['bar']==n];ap=[e for e in a['pedals'] if e['bar']==n];bp=[e for e in b['pedals'] if e['bar']==n]
  if (ab,ae,ap)!=(bb,be,bp):
   changes.append(n);expected={'bar':n,'before_bar':ab,'after_bar':bb,'before_events':ae,'after_events':be,'before_pedals':ap,'after_pedals':bp}
   if entries.get(n)!=expected:errors.append('exact bar body mismatch '+str(n))
  if core(ae)!=core(be) or ab['harmony']!=bb['harmony']:musical.append(n)
 if changes!=d['changed_bars'] or sorted(entries)!=changes:errors.append('changed bar list')
 if len(musical)<8:errors.append('insubstantial revision')
 if d['before_sha256']!=sha('score_'+a['version']+'.json') or d['after_sha256']!=sha('score_'+b['version']+'.json'):errors.append('hash mismatch')
 rebuilt=json.loads(json.dumps(a));rebuilt['version']=d['top_level_version_after'];rebuilt['phrases']=d['phrase_metadata_after'];rebuilt['cadences']=d['cadences_after']
 for x in d['changes']:
  n=x['bar'];rebuilt['bars'][n-1]=x['after_bar'];rebuilt['events']=[e for e in rebuilt['events'] if e['bar']!=n]+x['after_events'];rebuilt['pedals']=[e for e in rebuilt['pedals'] if e['bar']!=n]+x['after_pedals']
 rebuilt['events'].sort(key=lambda e:(e['onset'],e['instrument'],e['pitch'],e['event_id']));rebuilt['pedals'].sort(key=lambda e:e['onset'])
 if rebuilt!=b:errors.append('full score reconstruction mismatch')
 before=(R/f'score_{a["version"]}.json').read_text().splitlines(True);after=(R/f'score_{b["version"]}.json').read_text().splitlines(True);expected=''.join(difflib.unified_diff(before,after,fromfile=f'score_{a["version"]}.json',tofile=f'score_{b["version"]}.json'))
 if (R/f'exact_diff_{a["version"]}_to_{b["version"]}.patch').read_text()!=expected:errors.append('unified patch mismatch')
 return {'passed':not errors,'errors':errors,'changed_bars':changes,'strict_musical_changed_bars':musical,'strict_musical_changed_bar_count':len(musical),'full_score_reconstruction_equal':rebuilt==b}

def main():
 scores={v:load('score_'+v+'.json') for v in ('v0','v1','v2')};versions={v:inspect(s) for v,s in scores.items()};diffs={a+'_to_'+b:verify_diff(scores[a],scores[b],load('exact_diff_'+a+'_to_'+b+'.json')) for a,b in [('v0','v1'),('v1','v2')]};equal=(R/'score.json').read_bytes()==(R/'score_v2.json').read_bytes()
 result={'passed':equal and all(x['passed'] for x in versions.values()) and all(x['passed'] for x in diffs.values()),'selected_equals_v2_byte_for_byte':equal,'selected_sha256':sha('score.json'),'versions':versions,'revision_checks':diffs,'method':'Independent disk-based verifier. It does not import or execute the generator. All seconds are recomputed by piecewise bar integration. Exact diffs reconstruct the full next-version score.','limitations':'No audio rendered, sources opened, or listening performed. Timbral quality, actual recorded attack/release, loudness balance and final pedal behavior require later verification.'}
 save('independent_verification.json',result)
 print(json.dumps({'passed':result['passed'],'versions':{v:{k:x[k] for k in ('passed','errors','event_count','strict_transfer_count','minimum_transfer_margin_seconds','minimum_cello_bow_gap_seconds','minimum_pedal_aware_LH_clearance_seconds')} for v,x in versions.items()},'revisions':diffs},indent=2))
 if not result['passed']:raise SystemExit(1)
if __name__=='__main__':main()
