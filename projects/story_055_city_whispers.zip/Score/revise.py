import pathlib,json,copy,collections
P=pathlib.Path(__file__).parent;v1=json.loads((P/'revisions/score_v0.json').read_text());mat=json.loads((P/'thematic_material.json').read_text());v1['stage']='v1_bell_transformation_and_shared_silence'
# Let the cracked bell foreshadow the later simple tune, instead of duplicating the march.
intro=[[(65,1),(71,.5),(72,.5),(69,1),(67,1)],[(70,1.5),(69,.5),(65,1),(62,1)],[(69,1),(72,1),(77,1),(76,.5),(74,.5)],[(72,2),(67,1),(-1,1)]]
v1['events']=[e for e in v1['events'] if not(e['bar']<=4 and e['voice']=='melody')]
for j,line in enumerate(intro):
 off=0
 for n,l in line:
  if n>=0:v1['events'].append(dict(bar=j+1,onset=j*4+off,duration=l*.96,pitch=n,velocity=70+j,voice='melody'))
  off+=l
# Everyone stops together before the child speaks: remove the square's final beat.
for e in v1['events']:
 if e['bar']==52 and e['onset']+e['duration']>207:e['duration']=max(.03,207-e['onset'])
v1['events']=[e for e in v1['events'] if not(e['bar']==52 and e['onset']>=207)]
v1['pedals']=[e for e in v1['pedals'] if not(207<=e['onset']<208)]+[dict(onset=207,value=0)]
# Returning citizens start with the quiet bell melody on F, then unfold the march.
v1['events']=[e for e in v1['events'] if not(e['bar']==61 and e['voice'].startswith('melody'))]
for off,n,l in [(0,77,1.5),(1.5,76,.5),(2,74,1),(3,72,1)]:v1['events'].append(dict(bar=61,onset=240+off,duration=l*.98,pitch=n,velocity=84,voice='melody'))
(P/'revisions/score_v1.json').write_text(json.dumps(v1,indent=2));(P/'revisions/pass1.json').write_text(json.dumps({'pass':1,'changes':['Rewrite the four-bar introduction as the bell’s imperfect prototype, including a short resolving sharpened-fourth neighbor.','Make all voices release together before the child’s entrance rather than sustaining an unrelated bass through the silence.','Let the returned procession start with the newly understood bell phrase before the broad theme continues.']},indent=2))
v2=copy.deepcopy(v1);v2['stage']='v2_shared_phrasing_key_reconciliation'
for e in v2['events']:
 b=v2['bars'][e['bar']-1];k=(e['bar']-5)%8
 if e['voice']=='melody':
  e['velocity']+=[0,2,4,-2,3,1,2,-5][k]
  if e['bar']>4:e['duration']*=1.014
 elif e['voice']=='accompaniment':
  # Repairs displace one chord accent, while keeping melody and root firmly on the beat.
  if b['role_plan']=='repair' and e['bar']%2==0:e['onset']-=.25;e['duration']=.42
  if b['role_plan']=='return':e['velocity']-=3
 e['velocity']=max(22,min(99,e['velocity']))
by=collections.defaultdict(list);omit=set();fix=[]
for i,e in enumerate(v2['events']):by[e['pitch']].append((i,e))
for pitch,seq in by.items():
 seq.sort(key=lambda x:x[1]['onset'])
 for (ia,a),(ib,b) in zip(seq,seq[1:]):
  if ia in omit or ib in omit:continue
  if a['onset']+a['duration']>b['onset']+.001:
   if a['voice'].startswith('melody') and b['voice']=='accompaniment':omit.add(ib);fix.append({'bar':b['bar'],'pitch':pitch,'change':'omit accompaniment under held melody'})
   elif abs(a['onset']-b['onset'])<.001:
    omit.add(ia if not a['voice'].startswith('melody')else ib);fix.append({'bar':b['bar'],'pitch':pitch,'change':'one physical articulation'})
   else:a['duration']=max(.025,b['onset']-a['onset']-.02);fix.append({'bar':b['bar'],'pitch':pitch,'change':'release before melodic entry'})
v2['events']=[e for i,e in enumerate(v2['events'])if i not in omit];(P/'revisions/score_v2.json').write_text(json.dumps(v2,indent=2));(P/'score.json').write_text(json.dumps(v2,indent=2));(P/'revisions/pass2.json').write_text(json.dumps({'pass':2,'changes':['Shape eight-bar melodic breaths and connect touches within the sung line.','In the repairs section, shift selected chord accents by an eighth note without displacing bass/melody goals.','Thin return accompaniment so the broadened melodic theme remains primary.','Resolve actual shared-key flags from the independent read-only score review.'],'key_corrections':fix},indent=2));print('55 revisions saved',len(fix),'key corrections')
