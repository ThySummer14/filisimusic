"""An original through-composed compound-meter chamber journey, nominal events only."""
from copy import deepcopy
ID=142;TITLE='The Other Mouth of the Salt Cave';TITLE_ZH='盐洞的另一个出口'
INSTRUMENT_MAP={'piano':'piano','cello':'arco','flute':'flute'}
RENDERER_NOTES='Cello uses short-bow D3–B3 only, 0.48 or 0.51 seconds per stroke, with at least 0.20 seconds between strokes. It is an independent chalk-mark subject, not a bass doubling. Flute C5–B5 answers in breathable cells. Piano takes all fast compound-meter passagework. This is an unrendered nominal score.'
RENDERER_NOTES += ' The nominal rest layout now reserves at least the next pitch/layer sample delay plus 0.14 seconds before each flute/arco attack. The renderer must still apply recording compensation exactly once.'
H={'Dm9':[38,53,57,64],'Gm6':[43,58,62,64],'A7':[45,55,61,64],'Fmaj7':[41,57,60,64],'Bb6':[46,62,65,67],'C9':[36,52,58,62],'Ehalf':[40,55,58,62],'D7':[38,54,60,64],'G7':[43,59,62,65],'Ebmaj7':[39,55,58,62],'Gsus':[43,55,60,62],'Dopen':[38,57,64],'Fsharpdim':[42,57,60,63],'BflatM':[46,62,65],'AflatM':[44,60,63],'Em7':[40,55,59,62]}
STREAMS={'A':('piano','right',60,96,'rope_running_subject'),'L':('piano','left',31,59,'underground_counterline'),'B':('cello','none',50,59,'chalk_mark_subject'),'C':('flute','none',72,83,'air_from_unknown_exit')}
R={
'a':[(0,.38),(.5,.38),(1,.38),(1.5,.38),(2.25,.52)],
'b':[(.25,.38),(.75,.6),(1.75,.38),(2.25,.38),(2.75,.2)],
'c':[(0,.22),(.375,.22),(.75,.22),(1.125,.22),(1.5,.22),(1.875,.22),(2.25,.22),(2.625,.22)],
'd':[(0,.85),(1.125,.35),(1.75,.35),(2.375,.4)],
'e':[(.5,.35),(1,.35),(1.5,.35),(2,.35),(2.5,.35)],
'f':[(0,.4),(.75,.4),(1.5,.4),(2.25,.4)],
'g':[(.25,.55),(1.25,.55),(2.25,.55)],
'l':[(0,.65),(1.25,.6),(2.25,.5)],
'm':[(.5,.7),(1.75,.8)],
'n':[(0,.45),(.75,.5),(1.75,.5),(2.5,.3)],
'o':[(.25,.65),(1.5,.65)],
'x':[(.25,'bow'),(1.5,'bow')],
'y':[(.2,'bow'),(1.45,'bow')],
'z':[(.75,'bow'),(2,'bow')],
'u':[(.25,.7),(1.5,.7)],
'v':[(.75,.85),(2.25,.5)],
'w':[(0,.8),(1.5,.8)],
'q':[(1,.85)],'rest':[]}
def section(name,count,bpm,meters,hs,A,L,B,C,ar,lr,br,cr,dyn,phrase):
 return dict(name=name,count=count,bpm=bpm,meters=meters,harmonies=hs.split(),pitches={k:v.split() for k,v in [('A',A),('L',L),('B',B),('C',C)]},rhythms={k:v.split() for k,v in [('A',ar),('L',lr),('B',br),('C',cr)]},dyn=dyn,phrase=phrase)
SECTIONS=[
section('A_rope_uncoils_into_the_dark',17,76,[3,3,3.5,3,2.5,4],
'Dm9 Gm6 A7 Dm9 Fmaj7 C9 Bb6 Ehalf A7 Dm9 Gm6 C9 Fmaj7 Bb6 Gm6 A7 Dm9',
'A4 D5 F5 E5 A5 G5 E5 F5 D5 C5 A4 G4 Bb4 D5 F5 E5 D5 C#5 E5 G5 A5 F5 E5 D5 C5 F5 A5 G5 E5 C5 D5 Bb4 A4 D5 F5 G5 A5 C6 Bb5 G5 F5 E5 C#5 D5',
'D3 A3 F3 E3 G3 Bb3 A3 F3 E3 C#3 E3 G3 F3 D3 C3 F3 A3 G3 E3 C3 Bb2 F3 G3 A3 E3 C#3 D3',
'D3 F3 E3 A3 G3 F3 D3 E3 G3 A3 B3 A3 F3 E3 D3 F3 A3 G3 E3 D3',
'A5 G5 F5 D5 E5 G5 A5 Bb5 G5 E5 D5 C5 F5 A5 G5 E5',
'a d b e a f d','l m o n','x z y x rest z','rest q u rest v rest w',68,'4+6+7: the rope tune moves forward while the chalk tune repeatedly looks back'),
section('Every_white_wall_looks_familiar',19,84,[3,3.5,3,2.5,3,4,3],
'Fmaj7 C9 Dm9 Bb6 Ehalf A7 Dm9 Gm6 D7 Gm6 C9 Fmaj7 Ebmaj7 BflatM Ehalf A7 Dm9 G7 C9',
'C6 A5 G5 E5 F5 A5 D6 C6 A5 F5 D5 E5 G5 Bb5 A5 G5 E5 C#5 D5 F5 E5 A5 G5 D5 Bb4 C5 Eb5 G5 Bb5 A5 F5 D5 C5 E5 G5 A5 C6 B5 G5 E5 D5 C5',
'F3 A3 C4 Bb3 G3 E3 D3 F3 A3 Bb3 F3 D3 E3 G3 Bb3 A3 E3 C#3 D3 F#3 A3 G3 Bb3 D4 C4 G3 E3 F3 Eb3 Bb2 F3 A3',
'F3 A3 G3 E3 D3 F3 G3 B3 A3 G3 E3 F3 A3 B3 G3 E3 D3 A3 F3 E3 G3 F3 D3',
'F5 A5 G5 E5 D5 F5 Bb5 A5 G5 E5 C5 D5 E5 G5 B5 A5 F5 E5',
'b c d a e c f','m n l o n','z x y rest x z y','u rest v q rest w q',83,'5+5+9: apparent repetitions keep extending instead of returning to a refrain'),
section('The_chalk_line_stops_but_the_rope_does_not',23,92,[3,3,4,2.5,3.5],
'Dm9 A7 Dm9 Ehalf A7 Fmaj7 G7 C9 Fmaj7 Fsharpdim Gm6 D7 Gm6 Ebmaj7 AflatM G7 C9 Ehalf A7 Dm9 Bb6 Gsus Dopen',
'D6 A5 F5 E5 G5 Bb5 A5 E5 C#5 D5 F5 A5 C6 B5 G5 E5 F5 A5 C6 E6 D6 B5 G5 F5 Eb5 C5 D5 F#5 A5 C6 Bb5 G5 F5 Eb5 G5 Bb5 Db6 C6 Ab5 G5 F5 E5 D5 C5 E5 G5 Bb5 A5 G5 F5 E5 C#5 D5 F5 A5 C6 D6 A5 F5 E5 D5',
'D3 F3 A3 C4 Bb3 G3 E3 C#3 A2 E3 G3 Bb3 A3 F3 C3 E3 G3 B3 C4 A3 F3 D3 F#3 A3 C4 Bb3 G3 Eb3 Bb2 F3 Ab3 C4 B3 G3 E3 C3 D3 F3 A3 G3 E3 D3',
'A3 F3 E3 D3 G3 B3 A3 F3 E3 G3 F3 D3 E3 A3 G3 F3 D3 B3 A3 G3 F3 E3 D3 F3 A3 B3 A3 G3 E3 D3',
'D5 F5 A5 C5 E5 G5 B5 A5 G5 F5 D5 Eb5 G5 Bb5 Ab5 G5 F5 E5 C5 D5 F5 A5 G5 E5 D5',
'c a c b f c e d','n l o n m l','y x z y x rest z','w u rest v u q rest w',102,'6+8+9: a prolonged ascent, with the most active cello argument below the piano'),
section('The_sea_is_not_where_the_map_put_it',21,80,[3.5,3,4,3,2.5,3],
'Fmaj7 C9 G7 C9 Fmaj7 Bb6 Gm6 D7 Gm6 Ebmaj7 AflatM Ebmaj7 Bb6 Fmaj7 Em7 A7 Dm9 C9 Bb6 Gsus Dopen',
'A5 C6 B5 G5 E5 F5 A5 G5 C6 Bb5 G5 E5 F5 D5 Bb4 D5 G5 F5 A5 C6 Bb5 F5 Eb5 G5 Bb5 Ab5 G5 Eb5 C5 F5 A5 G5 E5 C5 D5 F5 A5 C6 B5 G5 E5 C#5 D5 A5 G5 F5 E5 D5 C5 Bb4 A4 E5 D5',
'F3 C4 A3 G3 E3 C3 G2 D3 F3 E3 C3 F3 A3 C4 Bb3 G3 D3 F#3 G3 Bb3 Eb3 Ab3 C4 Bb3 F3 A3 G3 E3 C#3 D3 F3 A3 G3 E3 D3 A2',
'F3 E3 G3 A3 B3 A3 G3 F3 E3 D3 G3 F3 A3 B3 G3 E3 F3 A3 G3 E3 D3 F3 E3 D3',
'C5 E5 G5 B5 A5 F5 E5 D5 F5 A5 Bb5 G5 Eb5 C5 Eb5 Ab5 G5 F5 E5 D5 C5 F5 A5 G5 E5 D5',
'd b f c e a g','o n m l n','z y x rest z x','u v q w rest u v',90,'7+6+8: a new view is earned by continued motion; the final question remains open')]
REV1=set(range(18,29))|set(range(38,45))
REV2=set(range(53,61))|set(range(68,81))
H1={20:'Ebmaj7',24:'D7',28:'G7',39:'Fsharpdim',43:'Ebmaj7'}
H2={54:'AflatM',58:'Gsus',70:'Em7',75:'Bb6',79:'Gsus'}
def midi(s):return 12*(int(s[-1])+1)+{'C':0,'D':2,'E':4,'F':5,'G':7,'A':9,'B':11}[s[0]]+s[1:-1].count('#')-s[1:-1].count('b')
def fit(p,lo,hi):
 while p<lo:p+=12
 while p>hi:p-=12
 # A pitch-class outside the short-bow window is resolved to the closest edge.
 return max(lo,min(hi,p))
def woodwind_breathing(s):
 # Schedule real breathing space in seconds; preserve the existing gate length.
 # If a whole note cannot fit after a breath, omit that attack as a written rest.
 bars={b['bar']:b for b in s['bars']};elapsed={};t=0
 for b in s['bars']:elapsed[b['bar']]=t;t+=b['beats']*60/b['bpm']
 changes=[];removed=set()
 for inst in ('clarinet','flute'):
  last_end=-100
  for e in sorted((x for x in s['events'] if x['instrument']==inst),key=lambda x:x['onset']):
   b=bars[e['bar']];scale=60/b['bpm'];gate=e['duration']*scale
   start_sec=elapsed[e['bar']]+(e['onset']-b['start'])*scale
   if gate<.24:
    removed.add(id(e));changes.append(dict(bar=e['bar'],instrument=inst,action='write_rest_instead_of_truncated_short_attack',old_onset=e['onset'],duration_seconds=gate));continue
   need=max(0,last_end+.145-start_sec)
   if need>1e-7:
    new=e['onset']+need/scale
    if new+e['duration']>b['start']+b['beats']-.001:
     removed.add(id(e));changes.append(dict(bar=e['bar'],instrument=inst,action='write_rest_to_preserve_gate_and_breath',old_onset=e['onset'],duration_seconds=gate));continue
    changes.append(dict(bar=e['bar'],instrument=inst,action='delay_entire_note_for_breath',old_onset=e['onset'],new_onset=round(new,6),unchanged_duration=e['duration']))
    e['onset']=round(new,6);start_sec+=need
   last_end=start_sec+gate
 s['events']=[e for e in s['events'] if id(e) not in removed]
 s['woodwind_breathing_edits']=changes
 return s


# Verified sample metadata is used only by the symbolic checker.
SAMPLE_ONSET_DELAY_SECONDS={'flute': {('pp', 72): 0.08001201545335887, ('pp', 73): 0.0898971264827533, ('pp', 74): 0.07983842903523583, ('pp', 75): 0.1493489920217505, ('pp', 76): 0.20904149215655404, ('pp', 77): 0.14934985469784817, ('pp', 78): 0.11997712832295855, ('pp', 79): 0.16949112668248204, ('pp', 80): 0.09911726838782998, ('pp', 81): 0.07989101914124709, ('pp', 82): 0.08930452854032835, ('pp', 83): 0.07969237353709822, ('mf', 72): 0.060406515461735574, ('mf', 73): 0.07052517082997613, ('mf', 74): 0.11057205801867949, ('mf', 75): 0.10008089987737774, ('mf', 76): 0.10027069311440293, ('mf', 77): 0.09023997500344833, ('mf', 78): 0.11085664032736406, ('mf', 79): 0.08014430460612983, ('mf', 80): 0.09986319709244704, ('mf', 81): 0.08019292717345358, ('mf', 82): 0.05048814813842415, ('mf', 83): 0.050517319660623915}, 'cello': {('pp', 50): 0.10430518803605385, ('pp', 51): 0.10280911869175927, ('pp', 52): 0.10107662039108264, ('pp', 53): 0.10095623968778887, ('pp', 54): 0.1001470130812132, ('pp', 55): 0.09929602634988755, ('pp', 56): 0.10059127916195107, ('pp', 57): 0.10322761451400336, ('pp', 58): 0.10446920374237796, ('pp', 59): 0.10385513320742007, ('mf', 50): 0.10469473964787179, ('mf', 51): 0.10344570956415314, ('mf', 52): 0.10309932466853362, ('mf', 53): 0.10185307413906473, ('mf', 54): 0.10093829174587371, ('mf', 55): 0.1009149971460755, ('mf', 56): 0.10303760532574009, ('mf', 57): 0.10505530283181855, ('mf', 58): 0.10504705203028203, ('mf', 59): 0.10491690185566772}}
SAMPLE_DELAY_PROVENANCE={'flute': {'path': 'assets/iowa_flute_C5_B5/mapping_manifest.json', 'sha256': '716574ead3c7cb0da47d0a4f537e358b24f322f91546396c9a12969d9cb47e52', 'field': 'voiced_onset_delay_after_tuning_seconds'}, 'cello': {'path': 'assets/iowa_cello_arco_D3_B3/mapping_manifest.json', 'sha256': '70053fff468d349619e1e1c00c262fe75098d35f95be6fad7a9d8ef8a69f1d49', 'field': 'coarse_voiced_delay_after_tuning_seconds'}}
# Local beat positions chosen for clearer phrase rests, not recording offsets.
NOMINAL_REST_LAYOUT={0: {('cello', 65): {0: 0.375}, ('cello', 71): {0: 0.375}, ('cello', 77): {0: 0.375}}, 1: {('cello', 65): {0: 0.375}, ('cello', 71): {0: 0.375}, ('cello', 77): {0: 0.375}}, 2: {('cello', 65): {0: 0.375}, ('cello', 71): {0: 0.375}, ('cello', 77): {0: 0.375}, ('flute', 56): {0: 0.375}}}

def nominal_rest_layout(s, level):
 # Authored rests on explicit fractional-beat positions. These are musical
 # nominal onsets, never sample-trigger advances. Retain all pitches, velocities,
 # gates and event identities within each line; only the listed attacks move.
 bars={b['bar']:b for b in s['bars']};changes=[]
 for (instrument,bn),positions in NOMINAL_REST_LAYOUT[level].items():
  ee=sorted((e for e in s['events'] if e['instrument']==instrument and e['bar']==bn),key=lambda e:e['onset'])
  for index,local_onset in positions.items():
   e=ee[index];old=e['onset'];new=round(bars[bn]['start']+local_onset,6)
   assert old<=new and new+e['duration']<=bars[bn]['start']+bars[bn]['beats']
   e['onset']=new
   changes.append(dict(bar=bn,instrument=instrument,line_note_index=index,old_nominal_onset=old,new_nominal_onset=new,unchanged_pitch=e['pitch'],unchanged_velocity=e['velocity'],unchanged_duration=e['duration'],reason='Written phrase rest or following attack repositioned; no sample compensation.'))
 s['nominal_rest_layout_edits']=changes
 return s

def harmonic_finish(s):
 # A melodic dissonance is retained only when the next note of that same
 # line resolves by one or two semitones to the actual current harmony.
 # Otherwise correct the local landing, never relabel a collision as style.
 from collections import defaultdict
 groups=defaultdict(list);bars={b['bar']:b for b in s['bars']}
 for e in s['events']:groups[(e['bar'],e['instrument'],e['voice'],e['hand'])].append(e)
 evidence=[]
 for (bn,inst,voice,hand),ee in groups.items():
  ee.sort(key=lambda x:x['onset']);pcs={p%12 for p in bars[bn]['harmony']}
  lo,hi=(60,96) if inst=='piano' and hand=='right' else (31,59) if inst=='piano' else (60,71) if inst=='clarinet' else (72,83) if inst=='flute' else (36,47) if s['instrument_map'].get('cello')=='pizz' else (50,59)
  for i in range(len(ee)-1,-1,-1):
   e=ee[i];p=e['pitch']
   if p%12 in pcs:continue
   nx=ee[i+1] if i+1<len(ee) else None
   resolved=nx and nx['pitch']%12 in pcs and 1<=abs(nx['pitch']-p)<=2
   if resolved:
    evidence.append(dict(bar=bn,instrument=inst,voice=voice,harmony=bars[bn]['harmony_name'],pitch=p,onset=e['onset'],resolution_pitch=nx['pitch'],resolution_onset=nx['onset'],classification='explicit stepwise appoggiatura, neighbor or passing tone; not a chord member'))
   else:
    cc=[q for q in range(lo,hi+1) if q%12 in pcs]
    e['pitch']=min(cc,key=lambda q:(abs(q-p),q))
 s['intentional_nonchord_tones']=sorted(evidence,key=lambda x:(x['bar'],x['onset'],x['instrument']))
 s['harmonic_review_scope']='Each remaining non-chord event resolves by step to a chord member in its own line within the same bar. This is symbolic voice-leading evidence, not an audio quality claim.'
 return s

def build(level):
 bars=[];events=[];pedals=[];start=0;n=0;phrase_map=[]
 for si,s in enumerate(SECTIONS):
  cur={k:0 for k in STREAMS};first=n+1
  for j in range(s['count']):
   n+=1;beats=s['meters'][j%len(s['meters'])];bpm=s['bpm'];h=s['harmonies'][j%len(s['harmonies'])]
   r1=level>=1 and n in REV1;r2=level>=2 and n in REV2
   if r1:h=H1.get(n,h)
   if r2:h=H2.get(n,h)
   num,den=(int(beats*2),8) if beats%1 else ((6,8) if beats==3 else (int(beats),4))
   bars.append(dict(bar=n,start=start,beats=beats,bpm=bpm,meter_numerator=num,meter_denominator=den,section=s['name'],harmony_name=h,harmony=H[h]))
   for key,(inst,hand,lo,hi,voice) in STREAMS.items():
    cells=deepcopy(R[s['rhythms'][key][j%len(s['rhythms'][key])]])
    if r1 and key=='B':cells=[(.1,'bow'),(1.45,'bow')]
    if r1 and key=='A':cells=deepcopy(R['b' if j%3 else 'd'])
    if r2 and key=='A':cells=deepcopy(R['c' if n<61 else 'f'])
    if r2 and key=='C':cells=[(.25,.65),(1.75,.65)]
    if beats>=3.5 and key in ('A','L'):cells.append((3,.35 if key=='A' else .4))
    for k,(t,dur) in enumerate(cells):
     if t>=beats-.05:continue
     if dur=='bow':
      dur=(.48+.03*((j+k)%2))*bpm/60
      if beats-t-.025<.35*bpm/60:continue
     dur=min(dur,beats-t-.025)
     p=midi(s['pitches'][key][cur[key]%len(s['pitches'][key])]);cur[key]+=1
     if r1 and key=='B':p=[50,53,57,55,52,59,57,54,55][(cur[key]+j)%9]
     if r1 and key=='A':p+=(-2 if k%3==0 else 1)
     if r2 and key=='A':p+=(12 if n<61 and k%4==0 else -2 if n>=68 and k%3==1 else 0)
     if r2 and key=='C':p=[74,77,81,79,76,72,75,79,82,80,77,74][(cur[key]+j)%12]
     p=fit(p,lo,hi)
     # Preserve each authored contour, but give sentence attacks/endings explicit
     # harmonic footing. Middle notes remain passing/neighbor motion.
     if k==0 or k==len(cells)-1:
      candidates=[x for x in range(lo,hi+1) if x%12 in {z%12 for z in H[h]}]
      p=min(candidates,key=lambda x:(abs(x-p),x))
     if ID==142 and key=='B' and n==18:p=[55,57][min(k,1)]
     if ID==142 and key=='C' and n==41:p=[72,73][min(k,1)]
     if ID==142 and key=='B' and n==54:p=([58,56] if h=='AflatM' else [57,55])[min(k,1)]
     if ID==143 and key=='B' and n==8:p=[67,65,69][min(k,2)]
     if ID==143 and key=='C' and n==31:p=[79,78,81][min(k,2)]
     if ID==143 and key=='B' and n==61:p=[63,62,65][min(k,2)]
     vv=s['dyn']+([4,-3,1,-1][k%4])-(17 if key=='L' else 16 if key=='B' else 13 if key=='C' else 0)
     if inst=='cello':vv=min(84,max(56,vv))
     events.append(dict(bar=n,onset=round(start+t,6),duration=round(dur,6),pitch=int(p),velocity=int(max(1,min(127,vv))),instrument=inst,voice=voice,hand=hand,articulation='short_bow' if inst=='cello' else 'detached'))
   pedals.append(dict(bar=n,onset=start,controller=64,value=0,instrument='piano'))
   if si==3 and j in (0,7,13):pedals.extend([dict(bar=n,onset=start+.05,controller=64,value=28,instrument='piano'),dict(bar=n,onset=start+.8,controller=64,value=0,instrument='piano')])
   start+=beats
  phrase_map.append(dict(first_bar=first,last_bar=n,design=s['phrase'],independent_subjects=['rope_running_subject','chalk_mark_subject'],flute_role='independent air motif'))
 pedals.append(dict(bar=n,onset=start-.01,controller=64,value=0,instrument='piano'))
 return harmonic_finish(nominal_rest_layout(woodwind_breathing(dict(id=ID,title=TITLE,title_zh=TITLE_ZH,version=f'v{level}',bars=bars,events=events,pedals=pedals,total_beats=start,tail_seconds=5,instrument_map=INSTRUMENT_MAP,phrase_map=phrase_map)),level))
