#!/usr/bin/env python3
"""Independent disk-based verifier; does not import the composition generator.
Standard library only. No audio, DSP, source access, or listening.
"""
import hashlib
import json
import math
from collections import defaultdict
from pathlib import Path

ROOT=Path(__file__).resolve().parent
def read(n): return json.loads((ROOT/n).read_text(encoding='utf-8'))
def sha(n): return hashlib.sha256((ROOT/n).read_bytes()).hexdigest()
def save(n,x): (ROOT/n).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')

def inspect(s):
    errors=[]; bars=s['bars']; notes=s['events']
    def check(ok,message):
        if not ok: errors.append(message)
    def sec(beat): return sum(min(max(beat-b['start'],0),b['beats'])*60/b['bpm'] for b in bars)
    def end(e): return e['onset']+e['duration']
    check(len(bars)==80 and s['total_beats']==240 and s['tail_seconds']==7,'total grid')
    check(195<=sec(240)+s['tail_seconds']<=220,'duration')
    for i,b in enumerate(bars):
        check((b['bar'],b['start'],b['beats'],b['meter_numerator'],b['meter_denominator'])==(i+1,i*3,3,6,8),'bar grid')
        check(0<b['bpm']<=200,'tempo')
    check(len({e['event_id'] for e in notes})==len(notes),'unique IDs')
    piano=[e for e in notes if e['instrument']=='piano']
    cello=sorted([e for e in notes if e['instrument']=='cello'],key=lambda e:e['onset'])
    melody=sorted([e for e in piano if e['voice']=='melody'],key=lambda e:e['onset'])
    check({e['bar'] for e in melody}==set(range(1,81)),'piano lead every bar')
    check({e['instrument'] for e in notes}=={'piano','cello'},'instrument set')
    pcs={1,3,4,6,8,10,11}; lf={49:5,51:4,52:4,54:3,56:2,58:2,59:1,61:1}
    for e in notes:
        check(all(math.isfinite(e[k]) for k in ('onset','duration','pitch','velocity')),'finite values')
        check(e['duration']>0 and e['onset']>=0 and end(e)<=240,'event bounds')
        b=bars[e['bar']-1]
        check(b['start']<=e['onset']<b['start']+3,'event/bar association')
        check(isinstance(e['pitch'],int) and 1<=e['velocity']<=127,'MIDI range')
        check(e['pitch']%12 in pcs,'modal pitch')
        check(abs(sec(e['onset'])-e['target_on_seconds'])<1.1e-6 and abs(sec(end(e))-e['target_off_seconds'])<1.1e-6,'time integral')
        check(abs(e['target_on_beats']-e['onset'])<1.1e-6 and abs(e['target_off_beats']-end(e))<1.1e-6,'beat fields')
        if e['voice']!='melody': check(e['pitch']%12 in {p%12 for p in b['harmony']},'support harmony')
        if e['instrument']=='cello':
            check(36<=e['pitch']<=47 and e['hand']=='not_applicable','cello coverage/hand')
            check(e['layer']==e['sample_layer']=='mf','single mf recorded layer')
            check(e['articulation']=='pizzicato_short_separate','pizzicato articulation')
            check(e['velocity_controls']=='amplitude_only_single_recorded_mf_layer','no invented layers')
        else:
            lo,hi=e['hand_position_range']
            check(lo<=e['pitch']<=hi and hi-lo<=12 and 1<=e['finger']<=5,'finger/position bounds')
            if e['hand']=='right':
                keys=[p for p in range(lo,hi+1) if p%12 in pcs]
                check(len(keys)==5 and keys[e['finger']-1]==e['pitch'],'five-finger RH position')
            else: check([lo,hi]==[49,61] and lf.get(e['pitch'])==e['finger'],'fixed LH octave position')

    collisions=[]; crossings=[]; fingers=[]
    for i,a in enumerate(piano):
        for b in piano[i+1:]:
            if min(end(a),end(b))-max(a['onset'],b['onset'])<=1e-8: continue
            if a['pitch']==b['pitch']: collisions.append([a['event_id'],b['event_id']])
            if a['hand']==b['hand']:
                if a['finger']==b['finger']: fingers.append([a['event_id'],b['event_id']])
            else:
                l,r=(a,b) if a['hand']=='left' else (b,a)
                if l['pitch']>=r['pitch']: crossings.append([l['event_id'],r['event_id']])
    check(not collisions and not crossings and not fingers,'key/hand/finger collisions')
    spans={}; transfers=[]
    for hand in ('left','right'):
        ns=[e for e in piano if e['hand']==hand]; spans[hand]=0; attacks=defaultdict(list)
        for e in ns: attacks[e['onset']].append(e)
        for t in attacks:
            active=[e['pitch'] for e in ns if e['onset']<=t<end(e)]
            spans[hand]=max(spans[hand],max(active)-min(active))
        check(spans[hand]<=12,'held span')
        groups=sorted(attacks.items())
        for (old_on,old),(on,new) in zip(groups,groups[1:]):
            op=old[0]['hand_position_range']; np=new[0]['hand_position_range']
            if op==np: continue
            og=[min(e['pitch'] for e in old),max(e['pitch'] for e in old)]
            ng=[min(e['pitch'] for e in new),max(e['pitch'] for e in new)]
            grip=max(abs(x-y) for x,y in zip(og,ng))
            position=max(abs(x-y) for x,y in zip(op,np))
            required=.075+.012*max(0,max(grip,position)-4)
            # Full prior release history, not only the immediately previous note.
            latest=max(end(e) for e in ns if e['onset']<on)
            available=sec(on)-sec(latest)
            valid=available+1e-6>=required
            transfers.append({'hand':hand,'onset':on,'old_grip':og,'new_grip':ng,
                              'old_position':op,'new_position':np,
                              'grip_edge_travel_semitones':grip,'position_edge_travel_semitones':position,
                              'required_release_seconds':round(required,6),
                              'available_release_seconds':round(available,6),'passed':valid})
            check(valid,'released grip-edge transfer')
    gates=[sec(end(e))-sec(e['onset']) for e in cello]
    gaps=[sec(b['onset'])-sec(end(a)) for a,b in zip(cello,cello[1:])]
    check(max(gates)<=.5 and min(gaps)>=.6,'cello gate / scored release gap')
    pedals=s['pedals']
    check(pedals==sorted(pedals,key=lambda p:p['onset']),'pedal order')
    check(all(p['instrument']=='piano' and p['controller']==64 for p in pedals),'piano-only CC64')
    check(pedals[-1]['value']==0 and pedals[-1]['onset']<=240,'final pedal release')
    extended=[]
    for e in piano:
        if e['hand']!='left': continue
        off=end(e); prior=[p for p in pedals if p['onset']<=off]
        if prior and prior[-1]['value']>0:
            off=next(p['onset'] for p in pedals if p['onset']>off and p['value']==0)
        extended.append((e['onset'],off))
    clearances=[]
    for c in cello:
        ds=[]
        for start,off in extended:
            if off<=c['onset']: ds.append(sec(c['onset'])-sec(off))
            elif start>=end(c): ds.append(sec(start)-sec(end(c)))
            else: ds.append(-1)
        clearances.append(min(ds))
    check(min(clearances)>=.18-1e-6,'pedal-aware LH/cello silence')
    phrases={p['phrase_id']:p for p in s['phrases']}
    check(len(phrases)==len(s['phrases'])==40,'phrase IDs')
    for pid,p in phrases.items():
        ns=[e for e in notes if e['phrase_id']==pid]
        check(bool(ns) and all(p['first_bar']<=e['bar']<=p['last_bar'] for e in ns),'phrase membership')
        check(abs(p['target_on_beats']-min(e['onset'] for e in ns))<1e-6 and abs(p['target_off_beats']-max(end(e) for e in ns))<1e-6,'phrase endpoints')
        if p['instrument']=='cello': check(p['layers_used']==['mf'],'phrase layer')
    signatures=[tuple((e['pitch'],e['onset']-12*i,e['duration']) for e in melody if i*4<e['bar']<=i*4+4) for i in range(20)]
    check(len(set(signatures))==20,'distinct four-bar melodies')
    max_leap=max(abs(a['pitch']-b['pitch']) for a,b in zip(melody,melody[1:]))
    check(max_leap<=12,'melody leap bound')
    return {'passed':not errors,'errors':errors,'event_count':len(notes),'duration_with_tail_seconds':round(sec(240)+s['tail_seconds'],6),
            'maximum_held_span_semitones':spans,'same_key_overlap_count':len(collisions),'hand_crossing_count':len(crossings),'finger_collision_count':len(fingers),
            'grip_edge_transfer_rule':'75 ms + 12 ms per semitone beyond four, using max(actual grip-edge, declared position-edge travel).',
            'position_transfers':transfers,'position_transfer_count':len(transfers),'all_position_transfers_pass':all(x['passed'] for x in transfers),
            'cello_range':[min(e['pitch'] for e in cello),max(e['pitch'] for e in cello)],'cello_max_gate_seconds':round(max(gates),6),
            'cello_min_release_gap_seconds':round(min(gaps),6),'minimum_pedal_aware_left_hand_clearance_seconds':round(min(clearances),6),
            'unique_four_bar_melody_phrases':len(set(signatures)),'maximum_successive_melody_leap_semitones':max_leap}

def verify_diff(a,b,d):
    errors=[]; changed=[]; musical=[]; entries={x['bar']:x for x in d['changes']}
    def core(ns): return [{k:e[k] for k in ('onset','duration','pitch','instrument','voice','hand')} for e in ns]
    for n in range(1,81):
        ae=[e for e in a['events'] if e['bar']==n]; be=[e for e in b['events'] if e['bar']==n]
        ap=[p for p in a['pedals'] if p['bar']==n]; bp=[p for p in b['pedals'] if p['bar']==n]
        ab=a['bars'][n-1]; bb=b['bars'][n-1]
        if (ae,ap,ab)!=(be,bp,bb):
            changed.append(n)
            expected={'bar':n,'before_bar':ab,'after_bar':bb,'before_events':ae,'after_events':be,'before_pedals':ap,'after_pedals':bp}
            if entries.get(n)!=expected: errors.append(f'exact diff body mismatch {n}')
        if core(ae)!=core(be) or ab['harmony']!=bb['harmony']: musical.append(n)
    if changed!=d['changed_bars'] or sorted(entries)!=changed: errors.append('changed-bar list')
    if d['phrase_metadata_before']!=a['phrases'] or d['phrase_metadata_after']!=b['phrases']: errors.append('phrase diff')
    if d['before_sha256']!=sha(f'score_{a["version"]}.json') or d['after_sha256']!=sha(f'score_{b["version"]}.json'): errors.append('diff hashes')
    if len(musical)<8: errors.append('substantive revision count')
    return {'passed':not errors,'errors':errors,'actual_changed_bars':changed,
            'pitch_rhythm_harmony_or_texture_changed_bars':musical,'strict_musical_changed_bar_count':len(musical)}

def main():
    scores={v:read(f'score_{v}.json') for v in ('v0','v1','v2')}
    results={v:inspect(s) for v,s in scores.items()}
    revisions={f'{a}_to_{b}':verify_diff(scores[a],scores[b],read(f'exact_diff_{a}_to_{b}.json')) for a,b in (('v0','v1'),('v1','v2'))}
    same=(ROOT/'score.json').read_bytes()==(ROOT/'score_v2.json').read_bytes()
    result={'passed':same and all(x['passed'] for x in results.values()) and all(x['passed'] for x in revisions.values()),
            'selected_equals_v2_byte_for_byte':same,'selected_score_sha256':sha('score.json'),'versions':results,'revision_checks':revisions,
            'scope':'Independent symbolic file checks only; no audio, source access, rendering, DSP, or listening.'}
    save('independent_verification.json',result)
    files={p.name:{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(ROOT.iterdir()) if p.is_file() and p.name!='hash_manifest.json'}
    save('hash_manifest.json',{'algorithm':'SHA-256','files':files,'excludes_self':True,'scope':'Every regular file in this draft folder.'})
    print(json.dumps({'passed':result['passed'],'selected_equals_v2_byte_for_byte':same,
                      'versions':{v:{k:r[k] for k in ('passed','errors','event_count','position_transfer_count')} for v,r in results.items()},
                      'revision_checks':revisions},ensure_ascii=False,indent=2))
    if not result['passed']: raise SystemExit(1)

if __name__=='__main__': main()
