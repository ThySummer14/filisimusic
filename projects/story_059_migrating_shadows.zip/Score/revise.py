import pathlib
import json
import copy
import collections

P = pathlib.Path(__file__).parent
v1 = json.loads((P / 'revisions/ensemble_v0.json').read_text())
v1['stage'] = 'v1_western_answer_and_joint_final_cadence'

def replace_lead(cell, instrument, line, velocity):
    bs = [b for b in v1['bars'] if b['cell'] == cell]
    start = bs[0]['start']
    ids = {b['bar'] for b in bs}
    v1['events'][:] = [e for e in v1['events'] if not (e['bar'] in ids and e['instrument'] == instrument and e['voice'] == 'melody')]
    offset = 0
    for pitch, duration in line:
        b = next((b for b in reversed(bs) if start + offset >= b['start']), bs[0])
        if pitch >= 0:
            v1['events'].append(dict(bar=b['bar'], onset=start + offset, duration=duration * .93,
                                     pitch=pitch, velocity=velocity, voice='melody', instrument=instrument))
        offset += duration
    assert offset == 6

replace_lead(22, 'clarinet', [(63, 1), (67, .5), (70, .5), (67, 1), (63, 1), (62, .5), (60, .5), (63, .5), (-1, .5)], 76)
replace_lead(23, 'clarinet', [(71, .5), (69, .5), (67, 1), (65, 1), (62, .5), (65, .5), (67, 1), (71, .5), (-1, .5)], 78)

# End the actual work together: G7 remains under the pickup, then all three arrive on C minor.
last = v1['bars'][-1]
s = last['start']
last['harmony_name'] = 'G7 to Cm at beat 2'
last['harmony_segments'] = [{'offset': 0, 'harmony': [55, 59, 62], 'bass': 43},
                            {'offset': 2, 'harmony': [55, 60, 63], 'bass': 36}]
last['harmony'] = [55, 60, 63]
v1['events'] = [e for e in v1['events'] if not (e['bar'] == last['bar'] and
                 (e['instrument'] == 'cello' or e['voice'] == 'accompaniment'))]
for onset, pitch, duration, velocity in [(s, 43, 1.6, 51), (s + 2, 36, 2.3, 59)]:
    v1['events'].append(dict(bar=last['bar'], onset=onset, duration=duration, pitch=pitch,
                            velocity=velocity, voice='cello_bass', instrument='cello'))
for onset, chord, duration in [(s + .5, [55, 59, 62], .9), (s + 2, [55, 60, 63], 2.85)]:
    for pitch in chord:
        v1['events'].append(dict(bar=last['bar'], onset=onset, duration=duration, pitch=pitch,
                                velocity=42, voice='accompaniment', instrument='piano'))
(P / 'revisions/ensemble_v1.json').write_text(json.dumps(v1, indent=2))
(P / 'revisions/pass1.json').write_text(json.dumps({
    'pass': 1,
    'changes': [
        'Write a fresh two-cell western continuation; spell the G7 answer with B natural instead of carrying an unrelated E-flat-theme ending over the dominant.',
        'Replace the default final pizzicato fifth with a deliberate G-to-C bass arrival.',
        'Coordinate final piano voicing and clarinet tonic at beat 2; remove late accompaniment stabs after the ending has already arrived.'
    ]
}, indent=2))

v2 = copy.deepcopy(v1)
v2['stage'] = 'v2_meter_connected_phrasing_and_real_instrument_limits'
section_first = {}
for b in v2['bars']:
    section_first.setdefault(b['section'], b['cell'])
for e in v2['events']:
    b = v2['bars'][e['bar'] - 1]
    phase = (b['cell'] - section_first[b['section']]) % 8
    if e['voice'] == 'melody':
        e['velocity'] += [0, 2, 3, -2, 1, 4, 0, -4][phase]
        if e['instrument'] == 'clarinet':
            e['velocity'] = max(60, min(94, e['velocity']))
            e['duration'] = min(e['duration'], 1.5 * b['bpm'] / 60)
        else:
            e['velocity'] = max(50, min(104, e['velocity']))
    if e['instrument'] == 'piano' and e['voice'] == 'accompaniment' and b['lead_instrument'] == 'clarinet':
        e['velocity'] -= 3
    if e['instrument'] == 'cello':
        e['velocity'] += 2 if abs(e['onset'] - b['start']) < .001 else -2
        # All these velocities scale ONE recorded mf pluck; they do not imply extra recorded layers.

# Replies follow the last clarinet key release in that six-quarter-note cell.
for cell in sorted({b['cell'] for b in v2['bars']}):
    bs = [b for b in v2['bars'] if b['cell'] == cell]
    ids = {b['bar'] for b in bs}
    lead = [e for e in v2['events'] if e['bar'] in ids and e['instrument'] == 'clarinet' and e['voice'] == 'melody']
    if not lead:
        continue
    release = max(e['onset'] + e['duration'] for e in lead)
    end = bs[0]['start'] + 6
    for e in v2['events']:
        if e['bar'] in ids and e['voice'] == 'reply':
            e['onset'] = max(e['onset'], release + .025)
            e['duration'] = min(e['duration'], end - e['onset'] - .04)
v2['events'] = [e for e in v2['events'] if e['duration'] > .015]

# Piano-only physical-key reconciliation; legitimate ensemble unisons are not conflicts.
by_pitch = collections.defaultdict(list)
for e in v2['events']:
    if e['instrument'] == 'piano':
        by_pitch[e['pitch']].append(e)
fixes = []
for pitch, events in by_pitch.items():
    events.sort(key=lambda e: e['onset'])
    for a, b in zip(events, events[1:]):
        if a['onset'] + a['duration'] > b['onset'] + .001:
            a['duration'] = max(.025, b['onset'] - a['onset'] - .02)
            fixes.append(dict(bar=b['bar'], pitch=pitch, change='release before next piano articulation'))

for instrument, lo, hi in [('clarinet', 60, 71), ('cello', 36, 47)]:
    events = sorted([e for e in v2['events'] if e['instrument'] == instrument], key=lambda e: e['onset'])
    assert all(lo <= e['pitch'] <= hi for e in events)
    assert all(a['onset'] + a['duration'] <= b['onset'] + .0001 for a, b in zip(events, events[1:]))
    if instrument == 'clarinet':
        assert all(e['duration'] * 60 / v2['bars'][e['bar'] - 1]['bpm'] <= 1.55 for e in events)

(P / 'revisions/ensemble_v2.json').write_text(json.dumps(v2, indent=2))
(P / 'ensemble_score.json').write_text(json.dumps(v2, indent=2))
for instrument in ['piano', 'clarinet', 'cello']:
    d = copy.deepcopy(v2)
    d['events'] = [e for e in d['events'] if e['instrument'] == instrument]
    if instrument != 'piano':
        d['pedals'] = []
    (P / f'revisions/{instrument}_score_v2.json').write_text(json.dumps(d, indent=2))
    (P / f'{instrument}_score.json').write_text(json.dumps(d, indent=2))
(P / 'revisions/pass2.json').write_text(json.dumps({
    'pass': 2,
    'changes': [
        'Shape full six-quarter-note phrases through the 5+7 and later 7+5 bar boundaries rather than reaccent every high note independently.',
        'Keep clarinet entirely within the actual recorded mf region and verified pitch/duration range, with explicit articulated gaps.',
        'Make the cello root accents support the same harmonic arrivals; disclose its one recorded mf layer and gain-only velocity response.',
        'Lighten piano support when clarinet leads and align the answering notes after its real written release.'
    ],
    'piano_key_corrections': fixes,
    'clarinet_recorded_layers_used': ['mf'],
    'cello_recorded_layers_used': ['mf'],
    'cello_velocity_is_gain_only': True
}, indent=2))
print('59 v2 saved; piano key corrections:', len(fixes))
