from copy import deepcopy

def pitch(s):
 return 12*(int(s[-1])+1)+{'C':0,'D':2,'E':4,'F':5,'G':7,'A':9,'B':11}[s[0]]+s[1:-1].count('#')-s[1:-1].count('b')
def decode(line):
 result=[];t=0
 for token in line.split():
  name,units=token.split(':');dur=float(units)/2
  if name!='R':result.append((pitch(name),t,dur))
  t+=dur
 return result,t
class Writer:
 def __init__(self):self.bars=[];self.events=[];self.pedals=[];self.start=0;self.n=0
 def bar(self,name,bpm,beats,h,ch):
  self.n+=1;self.beats=beats;self.bpm=bpm;self.ch=ch
  numerator,denominator=(int(beats*2),8) if beats in (2.5,3.5) else ((6,8) if METER=='6/8' else (int(beats),4))
  self.bars.append(dict(bar=self.n,start=self.start,beats=beats,bpm=bpm,meter_numerator=numerator,meter_denominator=denominator,section=name,harmony_name=h,harmony=ch))
 def add(self,p,t,d,v=72,inst='piano',voice='theme',hand='right',art='detached'):
  if d>0 and t<self.beats:
   self.events.append(dict(bar=self.n,onset=round(self.start+t,6),duration=round(min(d,self.beats-t),6),pitch=int(p),velocity=max(1,min(127,int(v))),instrument=inst,voice=voice,hand=hand if inst=='piano' else 'none',articulation=art))
 def line(self,line,v=80,hand='right',transpose=0):
  notes,total=decode(line);assert abs(total-self.beats)<1e-7,(self.n,total,self.beats,line)
  for p,t,d in notes:self.add(p+transpose,t,max(.11,d-.09),v+(3 if t==0 else 0),hand=hand)
  return notes
 def release(self,amount=0,length=.7):
  self.pedals.append(dict(bar=self.n,onset=self.start,controller=64,value=0,instrument='piano'))
  if amount:
   self.pedals.extend([dict(bar=self.n,onset=self.start+.05,controller=64,value=amount,instrument='piano'),dict(bar=self.n,onset=self.start+length,controller=64,value=0,instrument='piano')])
  self.start+=self.beats
 def result(self,level):
  self.pedals.append(dict(bar=self.n,onset=self.start-.01,controller=64,value=0,instrument='piano'))
  return dict(id=ID,title=TITLE,title_zh=TITLE_ZH,version=f'v{level}',bars=self.bars,events=self.events,pedals=self.pedals,total_beats=self.start,tail_seconds=5,instrument_map=INSTRUMENT_MAP)
def material(level):
 n=0
 for section,bpm,beats,texture,hs,phrase_names in BLOCKS:
  lines=[]
  for pn in phrase_names.split():lines+=P[pn].split('|')
  harmonies=hs.split();assert len(lines)==len(harmonies),(section,len(lines),len(harmonies))
  for h,line in zip(harmonies,lines):
   n+=1
   for lv,rev in [(1,REV1),(2,REV2)]:
    if level>=lv and n in rev:h,line=rev[n]
   yield n,section,bpm,beats,texture,h,line
ID=127;TITLE='The Observatory Gear';TITLE_ZH='观测台的齿轮';METER='5/4';INSTRUMENT_MAP={'piano':'piano'}
RENDERER_NOTES='Solo piano. Five-quarter motion grouped 3+2, with cross-hand exchange in bars33–40. Preserve the late stall and decisive restart.'
H={'Fm':[41,48,56],'Db':[37,49,56],'Ab':[44,51,60],'Eb':[39,55,58],'C7':[36,52,58],'Bbm':[46,53,61],'Fm/C':[36,53,56],'Gb':[42,54,58],'Dbmaj7':[37,48,53],'Csus':[36,53,58],'F':[41,48,57]}
P={
'a':'C5:1 F5:1 Ab5:2 G5:1 F5:1 C5:2 R:2|Db5:1 F5:1 Ab5:1 C6:1 Ab5:2 F5:2 Eb5:2|Eb5:2 G5:1 Bb5:1 G5:2 F5:1 Eb5:1 Bb4:2|E5:1 G5:1 Bb5:2 G5:1 E5:1 C5:2 R:2',
'b':'F5:1 Ab5:1 C6:2 Bb5:1 Ab5:1 G5:2 F5:2|Ab5:1 F5:1 Db5:2 Eb5:1 F5:1 Ab5:2 C6:2|Bb5:2 G5:1 Eb5:1 F5:2 G5:1 Bb5:1 G5:2|F5:2 C5:1 Ab4:1 F4:2 R:4',
'c':'Ab5:1 C6:1 Eb6:1 Db6:1 C6:2 Ab5:2 G5:2|Gb5:1 Bb5:1 Db6:2 C6:1 Bb5:1 Ab5:2 Gb5:2|F5:1 Ab5:1 Db6:1 C6:1 Ab5:2 F5:1 Eb5:1 Db5:2|E5:1 G5:1 C6:1 Bb5:1 G5:2 E5:2 R:2',
'd':'F5:1 C6:1 Ab5:1 F5:1 Eb5:1 Db5:1 C5:2 R:2|Db5:1 Ab5:1 F5:1 Db5:1 C5:1 Bb4:1 Ab4:2 R:2|Eb5:1 Bb5:1 G5:1 Eb5:1 Db5:1 C5:1 Bb4:2 R:2|C5:1 G5:1 E5:1 C5:1 Bb4:1 G4:1 E4:2 R:2',
'low':'F3:2 C4:1 Ab3:1 G3:2 F3:2 C3:2|Db3:2 Ab3:1 F3:1 Eb3:2 Db3:2 Ab2:2|Bb2:1 F3:1 Db4:2 C4:1 Bb3:1 Ab3:2 F3:2|C3:2 G3:1 Bb3:1 E4:2 D4:2 R:2',
'low2':'Ab3:2 C4:1 Eb4:1 Db4:2 C4:1 Ab3:1 G3:2|Gb3:2 Bb3:1 Db4:1 C4:2 Bb3:2 Ab3:2|G3:1 Bb3:1 Eb4:2 Db4:1 Bb3:1 G3:2 Eb3:2|C3:2 E3:1 G3:1 Bb3:2 R:4',
'e':'F5:1 Ab5:1 C6:1 Ab5:1 F5:1 G5:1 Ab5:1 Bb5:1 C6:2|Db6:1 C6:1 Ab5:1 F5:1 Db5:2 F5:1 Ab5:1 C6:2|Eb6:1 Bb5:1 G5:1 Eb5:1 G5:1 Bb5:1 Db6:1 C6:1 Bb5:2|E5:1 G5:1 Bb5:1 C6:1 E6:2 D6:1 C6:1 Bb5:2',
'f':'C6:2 Ab5:1 F5:1 G5:1 Ab5:1 C6:1 Eb6:1 F6:2|Db6:2 Ab5:1 F5:1 Ab5:2 C6:1 Db6:1 F6:2|Eb6:2 Bb5:1 G5:1 Bb5:2 Db6:1 C6:1 Bb5:2|C6:1 Bb5:1 G5:1 E5:1 C5:2 R:4',
'stall':'R:2 C5:2 F5:1 Ab5:1 R:4|R:4 Db5:2 F5:2 R:2|Eb5:1 G5:1 Bb5:2 R:6|E5:2 R:8',
'g':'F5:1 C6:1 Ab5:2 F5:1 Ab5:1 C6:2 Eb6:2|Db6:1 Ab5:1 F5:2 Ab5:1 C6:1 Db6:2 F6:2|Eb6:1 Bb5:1 G5:2 Bb5:1 Db6:1 Eb6:2 G6:2|C6:1 G5:1 E5:2 G5:1 Bb5:1 C6:2 R:2',
'finish':'F5:2 A5:1 C6:1 F6:2 E6:1 C6:1 A5:2|Bb5:2 F5:1 Db5:1 F5:2 Ab5:2 Bb5:2|G5:1 E5:1 C5:2 Bb4:1 C5:1 E5:2 G5:2|F5:2 C5:1 A4:1 F4:2 R:4'
}
BLOCKS=[
('Gear_engaged',124,5,'teeth','Fm Db Eb C7 Fm Db Eb Fm','a b'),
('First_sweep',132,5,'teeth','Fm Db Eb C7 Fm Db Eb Fm','a b'),
('Dome_shadow',110,5,'arcs','Ab Gb Db C7 Fm Db Eb C7','c d'),
('Misaligned',138,5,'slip','Fm Db Eb C7 Fm Db Eb Fm','a b'),
('Hands_below',96,5,'bass','Fm Db Bbm C7 Ab Gb Eb C7','low low2'),
('Mesh_again',124,5,'weave','Fm Db Eb C7 Fm Db Eb C7','e f'),
('Full_rotation',132,5,'weave','Fm Db Eb C7 Fm Db Eb C7','e f'),
('Late_stall',88,5,'stall','Fm Db Eb C7 Fm Db Eb C7','stall stall'),
('Restart',140,5,'run','Fm Db Eb C7 Fm Db Eb C7','g e'),
('Star_in_frame',126,5,'finish','Fm Db Eb C7 F Bbm C7 F','g finish')]
REV1={25:('Fm/C','R:1 C5:1 F5:1 Ab5:1 G5:2 F5:1 C5:1 R:2'),26:('Dbmaj7','F5:1 Ab5:1 C6:2 Ab5:1 F5:1 Eb5:1 Db5:1 C5:2'),27:('Eb','G5:1 Bb5:1 Eb6:1 Db6:1 Bb5:2 G5:1 F5:1 Eb5:2'),28:('Csus','G5:1 C6:1 F6:2 Eb6:1 C6:1 Bb5:2 R:2'),29:('Fm','Ab5:1 C6:1 F6:1 Eb6:1 C6:2 Ab5:1 G5:1 F5:2'),30:('Bbm','Db6:1 Bb5:1 F5:2 Db5:1 F5:1 Ab5:2 Bb5:2'),31:('C7','E5:2 G5:1 Bb5:1 C6:2 Bb5:1 G5:1 E5:2'),32:('Fm/C','F5:1 C5:1 Ab4:2 G4:1 F4:1 R:4')}
REV2={57:('Fm','C5:2 F5:2 R:6'),58:('Dbmaj7','R:2 C5:2 Db5:1 F5:1 R:4'),59:('Eb','Bb4:1 Eb5:1 G5:2 F5:2 R:4'),60:('Csus','G4:2 C5:2 F5:2 R:4'),61:('Fm/C','R:8 C5:1 F5:1'),62:('Db','R:6 Db5:1 F5:1 Ab5:2'),63:('C7','R:4 E5:1 G5:1 Bb5:1 C6:1 E6:2'),64:('C7','G5:1 E5:1 C5:2 R:6')}
def build(level):
 w=Writer()
 for n,section,bpm,beats,style,h,line in material(level):
  w.bar(section,bpm,beats,h,H[h]);ch=H[h];v={'teeth':85,'arcs':72,'slip':91,'bass':66,'weave':88,'stall':60,'run':100,'finish':94}[style]
  w.line(line,v,'left' if style=='bass' else 'right')
  if style=='bass':
   for j,t in enumerate([.75,3.25]):w.add(ch[j+1]+24,t,.65,v-16,voice='upper_bearing',hand='right')
  elif style=='stall':
   if n%4==1:w.add(ch[0],0,1.1,v-13,voice='weight',hand='left')
   if level>=2 and n in (62,63):
    for t in ([0,1.5] if n==62 else [0,1,2]):w.add(ch[0]+12,t,.26,64,voice='restart_teeth',hand='left')
  elif style in ('weave','run'):
   # Five-beat countersubject: two-hand sixteenth runs appear in the right-hand rests only.
   for j,t in enumerate([0,1,2.5,3.5]):
    if not(n%4==0 and t>=3):w.add(ch[j%3]-(12 if j==2 else 0),t,.28,v-20,voice='meshed_lower',hand='left')
   if n%4==0:
    for j,t in enumerate([3,3.5,4,4.5]):w.add(ch[j%3]+12,t,.28,v-10,voice='answer_to_right_rest',hand='left')
  else:
   times=[0,1.5,3] if style in ('teeth','finish') else ([0,2] if style=='arcs' else [0,2.5,4])
   if style=='slip' and level>=1:times=[.5,2,3.5,4.5]
   for j,t in enumerate(times):w.add(ch[0] if j%2==0 else ch[1],t,.36,v-22,voice='five_tooth_step',hand='left')
   if style=='arcs':w.add(ch[2],3.25,.8,v-25,voice='dome_inner',hand='left')
  w.release(34 if style in ('arcs','bass') else 0,1.1)
 return w.result(level)
