#!/usr/bin/env python3
"""Work 73: deterministic, standard-library-only composition. No rendering or samples.
Run: python generate_score.py (writes only beside this script).
Every onset is a target absolute quarter beat; flute targets are uncompensated.
"""
from copy import deepcopy
from pathlib import Path
import difflib
import hashlib
import json

ROOT = Path(__file__).resolve().parent
CHORDS = {
    'Dm': [38, 41, 45], 'Dm7': [38, 41, 45, 36],
    'C': [36, 40, 43], 'C/E': [40, 43, 36], 'C/G': [43, 36, 40],
    'F': [41, 45, 36], 'Fmaj7': [41, 45, 36, 40],
    'G': [43, 47, 38], 'G/D': [38, 43, 47], 'Gsus4': [43, 36, 38],
    'Am': [45, 36, 40], 'Am/G': [43, 45, 36, 40],
    'Em': [40, 43, 47], 'Em/B': [47, 40, 43],
}
SECTIONS = {
    'A': ('来路上的伞钉', 104, [3,3,3,3], 'The walker sets off: two forward gestures curve back to D; space remains after each phrase.'),
    'B': ('多出的地砖', 108, [3,3,4,3], 'A fourth beat appears in the third bar: the return has made enough ground for one extra action.'),
    'C': ('赶路让海水靠近', 116, [3,3,3,3], 'A busier contour and an omitted return note make the route contract; not virtuoso running notes.'),
    'D': ('折返测量', 92, [4,4,4,4], 'Measured walking reveals the rule; flute leaves a test interval for the plucked cello response.'),
    'E': ('回程巷开张', 108, [4,4,4,4], 'A useful delivery route turns the return figure into a regular public walking pattern.'),
    'F': ('星期三的收据', 96, [4,3,4,3], 'The route is now ordinary work; the final return lands on C, and the cello supplies a dry receipt stamp.'),
}

# Each R list explicitly fixes target onset and nominal gate in quarter beats.
# No randomization, arpeggiator, repeated playback loop, or sample-duration inference.
def R(onsets, durations):
    assert len(onsets) == len(durations)
    return list(zip(onsets, durations))

def P(section, label, pitches, rhythm, harmony, layer='mf', velocities=None, cello=None):
    if velocities is None:
        base = 74 if layer == 'mf' else 43
        contour = [3,0,-3,1,-5,2,-2,0,-4,1]
        velocities = [base + contour[i] for i in range(len(pitches))]
    assert len(pitches) == len(rhythm) == len(velocities)
    return dict(section=section, label=label, pitches=pitches, rhythm=rhythm,
                harmony=harmony, layer=layer, velocities=velocities,
                cello=cello or [(0.0,0,0,.55,49),(5.75,1,0,.50,44),(10.5,3,0,.60,46)])

# Cello tuples: local onset, harmonic-bar index, chord-tone index, gate SECONDS,
# velocity. Layer stays the single recorded mf pizzicato layer at every velocity.
BASE = [
 P('A','A1_first_return',[74,77,76,74,79,76,74],
   R([.5,1.75,3.25,4.75,6.25,7.5,9],[.65,.65,.8,.6,.65,.75,1.15]), ['Dm','C/E','F','Dm']),
 P('A','A2_umbrella_pin',[76,79,77,76,72,74,77],
   R([.5,2,3.5,5,6.5,8,9.5],[.7,.8,.7,.65,.65,.85,1.0]), ['C/E','F','Dm','G']),
 P('A','A3_watch_the_door',[77,76,74,79,77,76],
   R([.5,2,3.5,5.25,7,9],[.65,.85,.7,.75,.95,1.3]), ['F','Dm','G/D','C/E'],layer='pp',
   cello=[(0,0,0,.50,41),(5.75,1,0,.50,38),(10.75,3,0,.55,40)]),
 P('A','A4_back_at_the_bench',[74,77,76,74,81,79,77],
   R([.5,2,3.25,4.5,6,8,9.75],[.7,.6,.6,.65,.85,1.0,.65]), ['Dm','C/E','Am','F']),
 P('B','B1_extra_tile',[74,77,76,79,81,79,76,74],
   R([.5,1.75,3.25,4.75,6.25,7.75,9.25,10.5],[.6,.65,.75,.7,.75,.7,.6,.8]), ['Dm','F','C','Dm'],
   cello=[(0,0,0,.56,50),(6,2,0,.52,45),(11.6,3,0,.58,49)]),
 P('B','B2_pot_moves_outside',[77,79,81,79,76,77,74],
   R([.5,2.25,4,5.5,7.25,9,10.5],[.75,.85,.8,.75,.9,.7,.8]), ['F','C/G','Am','Dm'],
   cello=[(0,0,0,.54,49),(5.5,1,0,.50,43),(11.75,3,0,.57,47)]),
 P('B','B3_count_the_doorways',[79,76,74,77,76,72,74,76],
   R([.5,1.75,3.25,4.5,6.25,7.75,9.25,10.5],[.6,.7,.6,.8,.7,.75,.6,.75]), ['C/G','Dm','Fmaj7','C/E'],
   cello=[(0,0,0,.52,48),(6.1,2,0,.55,45),(11.75,3,0,.56,48)]),
 P('B','B4_try_to_get_more',[77,81,79,83,81,79,76],
   R([.5,2,3.5,5,6.5,8.5,10.25],[.65,.75,.7,.65,.9,1.0,.8]), ['F','Am','Em/B','G'],
   velocities=[75,79,75,84,79,74,71],cello=[(0,0,0,.52,49),(6,2,0,.52,49),(11.5,3,0,.55,52)]),
 P('C','C1_hurry',[74,77,76,74,79,76,74],
   R([.5,1.75,3,4.5,6,7.5,9.25],[.6,.6,.6,.65,.7,.65,.8]), ['Dm','Am','G','Dm'],
   velocities=[80,83,79,77,84,78,75],cello=[(0,0,0,.50,52),(4.75,1,0,.45,49),(10.6,3,0,.52,53)]),
 P('C','C2_smaller_quay',[77,79,81,79,76,74,76],
   R([.5,1.75,3.25,4.75,6.25,7.75,9.25],[.6,.6,.65,.6,.65,.7,.8]), ['F','Am','C/E','G'],
   velocities=[78,82,85,80,77,75,78],cello=[(0,0,0,.48,52),(5.25,1,0,.48,50),(10.5,3,0,.50,53)]),
 P('C','C3_stop_before_the_water',[81,79,77,76,74,76],
   R([.5,2,3.5,5.25,7,9.25],[.65,.7,.7,.8,.9,.75]), ['Am','Em','F','Gsus4'],
   velocities=[84,80,76,72,69,66],cello=[(0,0,0,.48,52),(4.8,1,0,.45,47),(10.75,3,0,.50,46)]),
 P('D','D1_chalk_test',[74,77,76,79,76,74],
   R([1,3,5.5,8.5,10.5,13],[1.05,1.0,1.15,1.15,1.2,1.4]), ['Dm','C/E','G','Dm'],layer='pp',
   cello=[(0,0,0,.60,39),(7.25,1,0,.55,38),(14.75,3,0,.60,42)]),
 P('D','D2_return_the_same_way',[76,79,77,76,74,77,76],
   R([.5,2.5,4.5,6.5,8.75,11,13.25],[1.05,1.1,1.1,1.05,1.25,1.15,1.1]), ['C/E','F','Dm','C/E'],layer='pp',
   cello=[(0,0,0,.60,41),(7.8,1,0,.58,39),(14.75,3,0,.60,43)]),
 P('D','D3_make_room_for_a_turn',[77,74,76,79,77,76,74],
   R([.5,2.5,4.5,6.5,9,11.25,13.25],[1.05,1.05,1.05,1.05,1.2,1.1,1.1]), ['F','Dm','G','Dm'],layer='pp',
   cello=[(0,0,0,.62,43),(7.85,1,0,.55,40),(14.85,3,0,.62,44)]),
 P('D','D4_measure_without_rushing',[74,77,76,79,81,79,76],
   R([.5,2.5,4.5,6.5,8.75,11,13.25],[1.05,1.1,1.0,1.1,1.2,1.15,1.1]), ['Dm','F','Am','C/E'],
   velocities=[59,63,61,64,67,63,60],cello=[(0,0,0,.60,43),(7.8,1,0,.56,42),(14.75,3,0,.62,45)]),
 P('E','E1_route_opens',[74,77,76,74,79,76,74,76,79],
   R([.5,2,3.5,5,6.5,8,10,11.5,13.25],[.75,.75,.75,.7,.8,1.05,.75,.9,1.0]), ['Dm','F','C','G'],
   cello=[(0,0,0,.55,49),(4.25,1,0,.55,46),(8.8,2,0,.56,48),(14.8,3,0,.58,51)]),
 P('E','E2_baskets_at_the_turn',[77,81,79,76,77,74,76,72],
   R([.5,2.25,4,5.75,7.5,9.5,11.25,13.25],[.85,.85,.8,.8,.95,.9,1.0,1.0]), ['F','C/E','Dm','C'],
   cello=[(0,0,0,.55,48),(5,1,0,.52,45),(10.6,2,0,.55,48),(14.75,3,0,.60,49)]),
 P('E','E3_other_feet_join',[79,81,83,81,79,76,77,76,74],
   R([.5,2,3.5,5,6.5,8.25,10,11.5,13.25],[.75,.75,.75,.75,.85,.95,.7,.85,1.0]), ['C/G','Am','F','Dm'],
   velocities=[75,79,83,78,75,71,74,71,68],cello=[(0,0,0,.54,50),(4.5,1,0,.55,47),(9.35,2,0,.56,48),(14.8,3,0,.57,50)]),
 P('E','E4_last_delivery',[74,77,76,74,79,77,76,74],
   R([.5,2.25,4,5.75,7.5,9.5,11.25,13.25],[.85,.85,.8,.8,.95,.9,1.0,1.0]), ['Dm','F','C/G','Gsus4'],
   cello=[(0,0,0,.56,49),(4.5,1,0,.53,46),(10.6,2,0,.56,48),(14.8,3,0,.58,47)]),
 P('F','F1_wednesday',[76,79,77,76,74,76,72],
   R([.5,2.25,4,5.75,7.5,9.25,11.25],[.9,.85,.95,.9,.85,1.1,1.15]), ['C/E','F','Dm','C'],layer='pp',
   cello=[(0,0,0,.60,40),(6.4,1,0,.55,38),(12.75,3,0,.60,42)]),
 P('F','F2_empty_return_cart',[74,77,76,79,77,76,74],
   R([.5,2.25,4,5.75,7.5,9.25,11.25],[.9,.85,.95,.9,.85,1.1,1.15]), ['Dm','F','C/G','Dm'],layer='pp',
   cello=[(0,0,0,.58,41),(6.4,1,0,.56,38),(12.75,3,0,.60,40)]),
 P('F','F3_receipt_stamp',[76,74,77,76,74,76,72],
   R([.5,2.25,4,5.75,7.5,9.25,11.25],[.9,.85,.95,.9,.85,1.1,1.15]), ['C/E','F','G','C'],layer='pp',
   velocities=[43,46,42,40,38,41,37],cello=[(0,0,0,.60,40),(6.5,1,0,.55,37),(12.9,3,0,.62,43)]),
]


def plans(version):
    ps = deepcopy(BASE)
    sections = deepcopy(SECTIONS)
    if version >= 1:
        # Revision 1: true contraction rather than simply accelerating the home tune.
        ps[8].update(pitches=[81,79,77,76,79,77,74],
            rhythm=R([.5,1.75,3,4.25,6.25,7.5,9.25],[.6,.6,.6,.6,.6,.65,.8]),
            harmony=['Am','Em','F','Dm'],label='C1_missing_return')
        ps[9].update(pitches=[83,81,79,77,76,74],
            rhythm=R([1,2.25,3.5,5,7,9.25],[.6,.6,.65,.8,.9,.8]),
            velocities=[85,81,78,75,73,70], harmony=['Em/B','Am','F','Dm'],label='C2_quay_contracts')
        ps[10].update(pitches=[79,77,76,74,72],
            rhythm=R([.5,2,4.25,6.25,8.5],[.65,.8,.9,1.1,1.15]),
            velocities=[77,73,69,65,60],harmony=['G','Dm','F','C'],label='C3_put_down_the_parcel')
        old = sections['D']
        sections['D'] = (old[0],old[1],[5,3,5,3],old[3] + ' The 5/4 bar contains the outward inspection and a turn; the 3/4 bar is the actual return.')
        ps[11].update(rhythm=R([1,3,5.5,8.5,10.5,13],[1.05,1.0,1.15,1.15,1.2,1.4]),
            harmony=['Dm','Dm','G/D','Dm'],label='D1_same_chalk_line',
            cello=[(0,0,0,.60,39),(7.3,1,0,.55,38),(14.95,3,0,.60,42)])
        ps[12].update(pitches=[76,79,77,76,74,76],
            rhythm=R([.5,2.5,5.5,8.5,10.75,13.25],[1.1,1.2,1.1,1.2,1.2,1.1]),
            velocities=[44,47,43,42,39,43],harmony=['C/E','C/E','Dm','C/E'],
            cello=[(0,0,0,.60,41),(7.1,1,1,.58,39),(14.8,3,0,.60,43)])
        ps[13].update(pitches=[77,74,76,79,77,74],
            rhythm=R([.5,2.5,5.5,8.5,10.75,13.25],[1.05,1.2,1.15,1.2,1.2,1.1]),
            velocities=[46,42,44,48,43,40],harmony=['F','F','G/D','Dm'],
            cello=[(0,0,0,.62,43),(7.15,1,2,.55,40),(14.85,3,0,.62,44)])
        ps[14].update(pitches=[74,77,76,79,76,74,72],
            rhythm=R([.5,2.5,5.25,6.75,8.75,11,13.25],[1.05,1.1,.8,.85,1.2,1.15,1.1]),
            harmony=['Dm','F','G/D','C'],label='D4_draw_a_useful_route')
    if version >= 2:
        # Revision 2: the working route changes who answers and where the return lands.
        ps[15].update(pitches=[77,76,74,79,76,74,72,76,79],harmony=['F','Dm','C','G'],
            label='E1_turning_point_first')
        ps[16].update(pitches=[77,81,79,76,74,76,72],
            rhythm=R([.5,2.25,4,5.75,8.5,11,13.25],[.85,.85,.8,.85,1.1,1.1,1.0]),
            velocities=[74,79,75,70,68,72,67],label='E2_return_baskets_answer',
            cello=[(0,0,0,.55,48),(4.5,1,0,.52,44),(7.25,1,2,.56,47),(10,2,0,.58,48),(14.85,3,0,.60,50)])
        ps[17]['cello']=[(0,0,0,.54,49),(5.2,1,0,.55,46),(9.4,2,0,.56,46),(14.85,3,0,.57,49)]
        ps[18].update(pitches=[74,77,76,79,77,76,74,72],harmony=['Dm','F','G','C'],
            label='E4_delivery_completed',velocities=[72,76,73,78,73,70,68,65])
        ps[19].update(pitches=[76,79,77,76,74,72],
            rhythm=R([.5,2.25,4,6.5,8.5,11.25],[.9,.85,1.1,1.0,1.1,1.15]),
            velocities=[44,47,43,41,38,40],label='F1_a_regular_wednesday')
        ps[20].update(pitches=[74,77,76,74,79,76,72],
            rhythm=R([.5,2,3.5,5.5,7.25,9.25,11.25],[.8,.8,.95,.95,.95,1.0,1.15]),
            harmony=['Dm','F','G','C'],label='F2_return_with_empty_baskets',
            cello=[(0,0,0,.58,40),(6.7,1,0,.56,38),(12.8,3,0,.60,42)])
        ps[21].update(pitches=[76,74,77,76,74,72],
            rhythm=R([.5,2.5,4.5,6.5,8.75,10.75],[1.1,1.1,1.15,1.1,1.1,1.3]),
            velocities=[43,40,45,41,38,36],harmony=['C/E','Dm','G','C'],
            label='F3_paid_on_return',
            cello=[(0,0,0,.60,39),(7,2,0,.55,37),(12.9,3,0,.65,43)])
    # Following each end-of-phrase answer, let the next grounding pluck lag the
    # new flute step; this also keeps the cello's written gates cleanly separated.
    for index, phrase in enumerate(ps):
        if index:
            first = phrase['cello'][0]
            phrase['cello'][0] = (.75,) + first[1:]
    return ps, sections


def seconds_at(beat, bars):
    t=0.0
    for b in bars:
        if beat >= b['start'] + b['beats']:
            t += b['beats'] * 60.0 / b['bpm']
        elif beat >= b['start']:
            return t + (beat-b['start'])*60.0/b['bpm']
        else:
            break
    return t


def make_score(version):
    ps, sections = plans(version)
    bars=[]; events=[]; phrases=[]; cursor=0.0
    for pi,p in enumerate(ps):
        sec=p['section']; title,bpm,meters,intent=sections[sec]
        first_bar=len(bars)+1; local_starts=[]; local=0
        for bi,meter in enumerate(meters):
            local_starts.append(local)
            h=p['harmony'][bi]
            bars.append(dict(bar=len(bars)+1,start=round(cursor+local,6),beats=meter,bpm=bpm,
                meter_numerator=meter,meter_denominator=4,section=sec,section_title_zh=title,
                harmony_name=h,harmony=CHORDS[h],lead_instrument='flute',
                role_plan='Flute foreground melody; one-layer pizzicato cello gives sparse grounding or a dry answer. '+intent))
            local += meter
        assert len(p['pitches'])==len(p['rhythm'])==len(p['velocities'])
        for ni,(pitch,(on,dur),vel) in enumerate(zip(p['pitches'],p['rhythm'],p['velocities'])):
            bar_index=max(i for i,s in enumerate(local_starts) if on>=s)
            events.append(dict(bar=first_bar+bar_index,onset=round(cursor+on,6),duration=dur,pitch=pitch,
                velocity=vel,instrument='flute',voice='flute_melody',role='lead',layer=p['layer'],
                phrase_id=f'P{pi+1:02d}_flute',phrase_label=p['label'],
                articulation='detached_breathed',onset_reference='pitched_arrival',
                timing_intent='Uncompensated pitched arrival; advance by the actual pitch/layer sample attack once in parent integration.',
                target_on_beats=round(cursor+on,6),target_off_beats=round(cursor+on+dur,6)))
        for ci,(on,hi,tone,gate,vel) in enumerate(p['cello']):
            bar_index=max(i for i,s in enumerate(local_starts) if on>=s)
            # Checked separately: supplied harmony index must be the onset's actual bar.
            assert hi==bar_index,(pi+1,on,hi,bar_index)
            pitch=CHORDS[p['harmony'][hi]][tone]
            dur=gate*bpm/60.0
            events.append(dict(bar=first_bar+bar_index,onset=round(cursor+on,6),duration=round(dur,6),pitch=pitch,
                velocity=vel,instrument='cello',voice='cello_pizzicato',
                role='answer' if ci==len(p['cello'])-1 or (version==2 and pi==16 and ci==2) else 'support',
                layer='mf',sample_layer='single_recorded_mf_pizzicato',velocity_controls='amplitude_only',
                phrase_id=f'P{pi+1:02d}_cello',phrase_label=p['label'],articulation='pizzicato',
                onset_reference='ordinary_trigger',
                timing_intent='Ordinary MIDI trigger; natural one-shot pizzicato decay, no bowed sustain or legato.',
                target_on_beats=round(cursor+on,6),target_off_beats=round(cursor+on+dur,6)))
        for instrument in ['flute','cello']:
            es=[e for e in events if e['phrase_id']==f'P{pi+1:02d}_{instrument}']
            phrases.append(dict(phrase_id=f'P{pi+1:02d}_{instrument}',instrument=instrument,
                phrase_label=p['label'],first_bar=first_bar,last_bar=first_bar+3,
                section=sec,layer=p['layer'] if instrument=='flute' else 'mf',
                role='lead' if instrument=='flute' else 'sparse_support_and_answer',
                target_on_beats=min(e['onset'] for e in es),
                target_off_beats=max(e['target_off_beats'] for e in es),
                timing_intent='Pitched arrivals, one recorded layer for the entire phrase, then an audible breath.' if instrument=='flute' else 'Individual single-layer plucks, with space between them; amplitude variation only.'))
        cursor+=local
    events.sort(key=lambda e:(e['onset'], e['instrument']))
    for i,e in enumerate(events):
        e['event_id']=f'w73-v{version}-{i+1:04d}'
        e['target_on_seconds']=round(seconds_at(e['onset'],bars),6)
        e['target_off_seconds']=round(seconds_at(e['target_off_beats'],bars),6)
    for ph in phrases:
        ph['target_on_seconds']=round(seconds_at(ph['target_on_beats'],bars),6)
        ph['target_off_seconds']=round(seconds_at(ph['target_off_beats'],bars),6)
    for instr in ['flute','cello']:
        ordered=sorted([p for p in phrases if p['instrument']==instr],key=lambda p:p['target_on_beats'])
        for i,p in enumerate(ordered):
            p['breath_to_next_phrase_seconds']=round(ordered[i+1]['target_on_seconds']-p['target_off_seconds'],6) if i+1<len(ordered) else None
    return dict(id=73,title='The Island Grown by Footsteps',title_zh='脚步长成的岛',version=f'v{version}',
        instrumentation=['flute','cello'],bars=bars,events=events,phrases=phrases,pedals=[],
        total_beats=cursor,tail_seconds=4,
        performance_contract=dict(
            audio_status='No audio generated, rendered, or listened to. Numerical score checks are not an auditory quality guarantee.',
            flute_onset='All flute onsets are intended pitched arrivals. No attack compensation has been applied. Parent applies actual 50–209 ms pitch/layer sample advance exactly once.',
            flute_compensation_applied_here=False,
            note_off='Target written note-off after pitched arrival. When advancing a flute trigger, retain the target note-off; do not subtract attack twice or shorten the intended sounding gate.',
            flute_layers='pp velocities 21–55, mf 56–95; one recorded layer per phrase, no ff.',
            flute_register=[72,83],flute_max_nominal_gate_seconds=1.30,
            flute_min_nominal_inter_note_gap_seconds=.30,flute_min_phrase_breath_seconds=.90,
            cello_register=[36,47],cello_layer='Single recorded mf pizzicato only, regardless of velocity. Velocity changes amplitude only, never sampled dynamic or articulation.',
            cello_gate_seconds=[.40,.80],cello_onset='Ordinary trigger; do not apply flute compensation.',
            recommended_render_pre_roll_seconds=.5,minimum_render_pre_roll_seconds=.209,
            sustain='No sustain pedal, bowed cello, true legato, layered doubles, sample loops, or overlapping notes in either instrument.',
            balance='Flute melody is foreground. Keep cello sparse and perceptually below flute, especially pp flute phrases; final balance must be checked on actual samples.',
            timing_check_after_integration='Recheck compensated flute triggers, measured releases, breath gaps, real sample duration, tempo integration, and end tail on the parent rendered result.'))


def audit(s):
    errors=[]; measures={}
    assert set(s['instrumentation'])=={'flute','cello'}
    for ins,low,high in [('flute',72,83),('cello',36,47)]:
        es=sorted([e for e in s['events'] if e['instrument']==ins],key=lambda e:e['onset'])
        gates=[e['target_off_seconds']-e['target_on_seconds'] for e in es]
        gaps=[b['target_on_seconds']-a['target_off_seconds'] for a,b in zip(es,es[1:])]
        ps=[p for p in s['phrases'] if p['instrument']==ins]
        breaths=[p['breath_to_next_phrase_seconds'] for p in ps if p['breath_to_next_phrase_seconds'] is not None]
        measures[ins]=dict(events=len(es),phrases=len(ps),pitch_min=min(e['pitch'] for e in es),pitch_max=max(e['pitch'] for e in es),
            gate_min_seconds=round(min(gates),6),gate_max_seconds=round(max(gates),6),
            minimum_inter_note_gap_seconds=round(min(gaps),6),minimum_phrase_gap_seconds=round(min(breaths),6),
            layers=sorted(set(e['layer'] for e in es)),velocity_min=min(e['velocity'] for e in es),velocity_max=max(e['velocity'] for e in es))
        for e,g in zip(es,gates):
            if not low<=e['pitch']<=high: errors.append('Pitch out of range: '+e['event_id'])
            if ins=='flute':
                bounds=(21,55) if e['layer']=='pp' else (56,95)
                if not bounds[0]<=e['velocity']<=bounds[1]:errors.append('Flute velocity/layer mismatch: '+e['event_id'])
                if g>1.300002:errors.append('Flute gate >1.30 seconds: '+e['event_id'])
                if e['onset_reference']!='pitched_arrival':errors.append('Flute timing reference')
            else:
                if not .399998<=g<=.800002:errors.append('Cello gate outside .40-.80: '+e['event_id'])
                if e['layer']!='mf' or e['articulation']!='pizzicato':errors.append('Cello layer/articulation mismatch')
            if e['target_off_beats']>s['total_beats']:errors.append('Event beyond written end')
        if min(gaps)<-1e-6:errors.append(ins+' overlap')
        if ins=='flute' and min(gaps)<.299998:errors.append('Flute gap below .30 seconds')
        if ins=='flute' and min(breaths)<.899998:errors.append('Flute phrase breath below .90 seconds')
        if ins=='cello' and min(gaps)<.399998:errors.append('Cello gaps insufficiently clear')
        for p in ps:
            layers={e['layer'] for e in es if e['phrase_id']==p['phrase_id']}
            if len(layers)!=1:errors.append('Mixed phrase layers: '+p['phrase_id'])
        signatures=[]
        for p in ps:
            ee=[e for e in es if e['phrase_id']==p['phrase_id']]
            signatures.append(tuple((round(e['onset']-ee[0]['onset'],6),e['pitch'],e['duration']) for e in ee))
        measures[ins]['exact_duplicate_phrase_signatures']=len(signatures)-len(set(signatures))
    flute_signatures=measures['flute']['exact_duplicate_phrase_signatures']
    if flute_signatures:errors.append('Exact duplicated flute phrase')
    sections=[]
    for key in ['A','B','C','D','E','F']:
        bs=[b for b in s['bars'] if b['section']==key]
        sections.append(dict(section=key,title=bs[0]['section_title_zh'],first_bar=bs[0]['bar'],last_bar=bs[-1]['bar'],
            meters=sorted(set(f"{b['meter_numerator']}/{b['meter_denominator']}" for b in bs)),
            bpm=bs[0]['bpm'],start_seconds=round(seconds_at(bs[0]['start'],s['bars']),6),
            end_seconds=round(seconds_at(bs[-1]['start']+bs[-1]['beats'],s['bars']),6)))
    measures['worst_case_gap_after_209ms_trigger_advance_seconds']=round(measures['flute']['minimum_inter_note_gap_seconds']-.209,6)
    measures['worst_case_phrase_breath_after_209ms_trigger_advance_seconds']=round(measures['flute']['minimum_phrase_gap_seconds']-.209,6)
    return dict(work=73,version=s['version'],status='PASS' if not errors else 'FAIL',errors=errors,
        total_bars=len(s['bars']),total_beats=s['total_beats'],total_events=len(s['events']),
        written_duration_seconds=round(seconds_at(s['total_beats'],s['bars']),6),
        with_nominal_tail_seconds=round(seconds_at(s['total_beats'],s['bars'])+s['tail_seconds'],6),
        sections=sections,measurements=measures,
        caveat='Score-only technical checks. No rendering, listening, actual sample attack/release measurement, loudness check, or auditory quality guarantee.')


def dump(path,data):
    path.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')


def main():
    scores=[]; audits=[]
    for v in range(3):
        s=make_score(v); a=audit(s)
        if a['errors']:raise AssertionError(a['errors'])
        scores.append(s);audits.append(a)
        dump(ROOT/f'score_v{v}.json',s);dump(ROOT/f'audit_v{v}.json',a)
        (ROOT/f'audit_v{v}.md').write_text(f"# Work 73 / v{v}: {a['status']}\n\n"+
            f"{a['total_bars']} bars; {a['total_beats']} quarter beats; {a['total_events']} events. Written duration {a['written_duration_seconds']:.3f} s; with nominal tail {a['with_nominal_tail_seconds']:.3f} s.\n\n"+
            '\n'.join(f"- {i}: {m['events']} notes; MIDI {m['pitch_min']}–{m['pitch_max']}; gates {m['gate_min_seconds']:.3f}–{m['gate_max_seconds']:.3f} s; minimum note gap {m['minimum_inter_note_gap_seconds']:.3f} s; minimum phrase gap {m['minimum_phrase_gap_seconds']:.3f} s; {m['exact_duplicate_phrase_signatures']} exact duplicate phrase signatures." for i,m in a['measurements'].items() if isinstance(m,dict))+
            '\n\nFlute pitch, dynamic-layer membership, phrase-layer consistency, gate limits, nominal breaths, timing-reference fields, monophony, and cello register/layer/gate checks passed.\n\n'+a['caveat']+'\n',encoding='utf-8')
    for i in range(2):
        left=(ROOT/f'score_v{i}.json').read_text().splitlines(keepends=True)
        right=(ROOT/f'score_v{i+1}.json').read_text().splitlines(keepends=True)
        (ROOT/f'score_v{i}_to_v{i+1}.diff').write_text(''.join(difflib.unified_diff(left,right,fromfile=f'score_v{i}.json',tofile=f'score_v{i+1}.json')),encoding='utf-8')
        changes=[]
        pa,_=plans(i); pb,_=plans(i+1)
        for j,(a,b) in enumerate(zip(pa,pb)):
            changed=[k for k in a if a[k]!=b[k]]
            if changed:changes.append(dict(phrase=f'P{j+1:02d}',changed_fields=changed,before=a,after=b))
        dump(ROOT/f'composition_diff_v{i}_to_v{i+1}.json',dict(from_version=f'v{i}',to_version=f'v{i+1}',
            meter_changes=[dict(bar=a['bar'],before=a['beats'],after=b['beats']) for a,b in zip(scores[i]['bars'],scores[i+1]['bars']) if a['beats']!=b['beats']],phrase_changes=changes))
    files=sorted(p for p in ROOT.iterdir() if p.is_file() and p.name!='sha256_manifest.json')
    dump(ROOT/'sha256_manifest.json',{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in files})
    print(json.dumps(dict(status='PASS',versions=[a['version'] for a in audits],final=audits[-1]),ensure_ascii=False,indent=2))

if __name__=='__main__':main()
