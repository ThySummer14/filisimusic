local root='PRODUCTION_ROOT/058_unsent_apologies'
local tr=reaper.GetTrack(0,0)
assert(tr,'Expected own inspection project')
local fx=reaper.TrackFX_GetByName(tr,'ReaVerbate (Cockos)',false)
assert(fx>=0,'Expected bundled room effect')
for i,v in pairs({[0]=0.08,[1]=1,[2]=0.20,[3]=0.60,[4]=0.70,[5]=0,[6]=1,[7]=0})do reaper.TrackFX_SetParam(tr,fx,i,v)end
local f=assert(io.open(root..'/revisions/native_room_configured.tsv','w'))
for i=0,7 do local ok,n=reaper.TrackFX_GetParamName(tr,fx,i,'');local ok2,v=reaper.TrackFX_GetFormattedParamValue(tr,fx,i,'');f:write(i..'\t'..n..'\t'..v..'\n')end
f:close()
reaper.Main_SaveProject(0,false)
reaper.Main_SaveProjectEx(0,root..'/revisions/native_room_configured.rpp',0)
reaper.Main_OnCommand(40004,0)
