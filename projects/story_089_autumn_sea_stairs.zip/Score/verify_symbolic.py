#!/usr/bin/env python3
"""Independent disk-based checks: never imports the composition generator.
Reproduction is a separate subprocess followed by byte comparison. No audio.
"""
import hashlib
import json
import math
import subprocess
import sys
import tempfile
from collections import defaultdict
from pathlib import Path

ROOT=Path(__file__).resolve().parent
def load(name):return json.loads((ROOT/name).read_text(encoding='utf-8'))
def save(name,x):(ROOT/name).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def sha(name):return hashlib.sha256((ROOT/name).read_bytes()).hexdigest()
def end(e):return round(e['onset']+e['duration'],6)

def inspect(s):
    errors=[];bars=s['bars'];notes=s['events']
    def check(ok,msg):
        if not ok:errors.append(msg)
    def sec(t):return sum(min(max(t-b['start'],0),b['beats'])*60/b['bpm'] for b in bars)
    check(s['id']==89 and s['total_beats']==320 and s['tail_seconds']==6,'work/duration metadata')
    check(len(bars)==64 and 195<=sec(320)+6<=220,'form / target duration')
    for i,b in enumerate(bars):
        check((b['bar'],b['start'],b['beats'],b['meter_numerator'],b['meter_denominator'])==(i+1,i*5,5,5,4),f'bar grid {i+1}')
        check(60<=b['bpm']<=110,f'tempo {i+1}')
    check(len(set(e['event_id'] for e in notes))==len(notes),'event IDs unique')
    check(notes==sorted(notes,key=lambda e:(e['onset'],e['hand'],e['pitch'],e['voice'])),'chronological event order')
    plans={(p['bar'],p['hand']):p for p in s['hand_position_plan']}
    check(len(plans)==128,'position-plan completeness')
    for e in notes:
        check(e['instrument']=='piano' and e['hand'] in ('left','right'),'ownership')
        check(all(math.isfinite(e[k]) for k in ('onset','duration','pitch','velocity')),'finite event')
        check(isinstance(e['pitch'],int) and 21<=e['pitch']<=108 and 1<=e['velocity']<=127,'MIDI bounds')
        check(0<=e['onset']<end(e)<=320,'note bounds')
        b=bars[e['bar']-1];p=plans[(e['bar'],e['hand'])]
        check(b['start']<=e['onset']<b['start']+5,'note/bar membership')
        check(abs(e['target_on_seconds']-sec(e['onset']))<1.1e-6 and abs(e['target_off_seconds']-sec(end(e)))<1.1e-6,'absolute time integral')
        check(e['target_on_beats']==e['onset'] and abs(e['target_off_beats']-end(e))<1.1e-6,'beat aliases')
        check(e['hand_position_id']==p['position_id'] and e['hand_position_range']==p['range'],'position identity')
        check(e['position_keys']==sorted(int(k) for k in p['pitch_finger_map']),'position keys')
        check(p['pitch_finger_map'].get(str(e['pitch']))==e['finger'] and 1<=e['finger']<=5,'finger identity')
        if e['voice']!='melody':check(e['pitch']%12 in {x%12 for x in b['harmony']},'support chord membership')
    for key,p in plans.items():
        ns=[e for e in notes if (e['bar'],e['hand'])==key]
        ps=sorted(set(e['pitch'] for e in ns));fs=[p['pitch_finger_map'][str(k)] for k in ps]
        check(ps and p['range']==[min(ps),max(ps)] and max(ps)-min(ps)<=12,'real position bounds')
        check(len(ps)<=5 and len(set(fs))==len(fs),'distinct keys/fingers in position')
        check(fs==sorted(fs,reverse=p['hand']=='left'),'uncrossed finger order')
        # Avoid labelling a wildly stretched adjacent-finger assignment feasible.
        check(all(abs(b-a)<=7 for a,b in zip(ps,ps[1:])),'adjacent assigned key distance')
    changes=defaultdict(list);attacks={h:defaultdict(list) for h in ('left','right')}
    for i,e in enumerate(notes):
        changes[e['onset']].append((1,i));changes[end(e)].append((0,i));attacks[e['hand']][e['onset']].append(e)
    held={};maxspan={'left':0,'right':0};maxkeys={'left':0,'right':0}
    overlap=[];cross=[];fingers=[];physical={h:{} for h in attacks};silent=[];lastoff=None
    for t in sorted(changes):
        was=bool(held)
        for kind,i in sorted(changes[t]):
            if kind==0:held.pop(i,None)
            else:
                e=notes[i]
                for old in held.values():
                    if old['pitch']==e['pitch']:overlap.append([old['event_id'],e['event_id']])
                    if old['hand']==e['hand'] and old['finger']==e['finger']:fingers.append([old['event_id'],e['event_id']])
                held[i]=e
        if was and not held:lastoff=t
        if held and lastoff is not None:
            if t>lastoff:silent.append(sec(t)-sec(lastoff))
            lastoff=None
        hands={h:[e for e in held.values() if e['hand']==h] for h in attacks}
        for h,ns in hands.items():
            if ns:
                ps=[e['pitch'] for e in ns];maxspan[h]=max(maxspan[h],max(ps)-min(ps));maxkeys[h]=max(maxkeys[h],len(ps))
                if t in attacks[h]:physical[h][t]=[min(ps),max(ps)]
        if all(hands.values()) and max(e['pitch'] for e in hands['left'])>=min(e['pitch'] for e in hands['right']):cross.append(t)
    check(not overlap and not cross and not fingers,'same-key / hand-crossing / finger collision')
    check(max(maxspan.values())<=12 and max(maxkeys.values())<=5,'held geometry')
    check(max(silent,default=0)<.4,'no silence used as duration padding')
    transfers=[];within=[]
    for hand in attacks:
        groups=sorted(attacks[hand].items());latest=0
        for i,(t,group) in enumerate(groups):
            if i:
                prev_t,prev=groups[i-1];old=physical[hand][prev_t];new=physical[hand][t]
                edge=max(abs(a-b) for a,b in zip(old,new))
                old_plan=plans[(prev[0]['bar'],hand)];new_plan=plans[(group[0]['bar'],hand)]
                position_edge=max(abs(a-b) for a,b in zip(old_plan['range'],new_plan['range']))
                changing=old_plan['position_id']!=new_plan['position_id']
                # RH within a bar uses the explicit finger map. LH is additionally
                # stress-tested for every >4-semitone attack-grip movement.
                needed=changing or (hand=='left' and edge>4)
                if needed:
                    travel=max(edge,position_edge) if changing else edge
                    required=.075+.012*max(0,travel-4)
                    available=sec(t)-sec(latest)
                    row={'hand':hand,'from_beat':prev_t,'to_beat':t,'old_grip':old,'new_grip':new,
                         'old_position':old_plan['range'],'new_position':new_plan['range'],
                         'whole_position_changed':changing,'grip_edge_semitones':edge,'position_edge_semitones':position_edge,
                         'checked_travel_semitones':travel,'last_prior_key_release_beat':latest,
                         'available_seconds':round(available,9),'required_seconds':round(required,9),
                         'margin_seconds':round(available-required,9),'passed':available+1e-7>=required}
                    transfers.append(row);check(row['passed'],f'transfer {hand} at {t}')
                elif hand=='right' and edge>4:
                    within.append({'from_beat':prev_t,'to_beat':t,'position_id':new_plan['position_id'],
                        'edge_semitones':edge,'from_pitches':[e['pitch'] for e in prev],'to_pitches':[e['pitch'] for e in group],
                        'from_fingers':[e['finger'] for e in prev],'to_fingers':[e['finger'] for e in group],
                        'method':'Different mapped fingers in the same independently checked octave-or-smaller position.'})
            latest=max(latest,*(end(e) for e in group))
    lead=[e for e in notes if e['voice']=='melody']
    check({e['bar'] for e in lead}==set(range(1,65)),'singing lead every bar')
    for n in range(1,65):check(abs(sum(e['written_value_beats'] for e in lead if e['bar']==n)-5)<1e-9,'complete five-beat melody bar')
    phrases={p['phrase_id']:p for p in s['phrases']}
    check(len(phrases)==16,'phrase count')
    for pid,p in phrases.items():
        ns=[e for e in notes if e['phrase_id']==pid]
        check(ns and all(p['first_bar']<=e['bar']<=p['last_bar'] for e in ns),'phrase membership')
        check(abs(p['target_on_beats']-min(e['onset'] for e in ns))<1e-6 and abs(p['target_off_beats']-max(end(e) for e in ns))<1e-6,'phrase bounds')
    signatures=[tuple((e['onset']-i*20,e['pitch'],e['duration']) for e in lead if i*4<e['bar']<=i*4+4) for i in range(16)]
    check(len(set(signatures))==16,'distinct four-bar phrases')
    directions={}
    for n in range(1,65):
        ns=[e for e in notes if e['bar']==n and e['hand']=='left'];ps=[e['pitch'] for e in ns]
        directions[n]='ascending' if ps==sorted(ps) else 'descending' if ps==sorted(ps,reverse=True) else 'other'
    check(all(directions[n]=='descending' for n in range(1,17)),'opening descending stairs')
    central=range(25,33 if s['version']=='v0' else 41)
    check(all(directions[n]=='ascending' for n in central),'reversed middle stairs')
    ped=s['pedals'];check(ped==sorted(ped,key=lambda p:p['onset']),'pedal chronology')
    check(all(p['instrument']=='piano' and p['controller']==64 and 0<=p['onset']<=320 and 0<=p['value']<=127 for p in ped),'pedal bounds')
    check(ped[-1]['onset']==320 and ped[-1]['value']==0,'terminal pedal release')
    return {'passed':not errors,'errors':errors,'event_count':len(notes),'bars':len(bars),'total_quarter_beats':320,
        'duration_with_tail_seconds':round(sec(320)+6,6),'maximum_held_span_semitones':maxspan,'maximum_simultaneous_keys':maxkeys,
        'same_key_overlap_count':len(overlap),'hand_crossing_count':len(cross),'finger_collision_count':len(fingers),
        'pitch_range':[min(e['pitch'] for e in notes),max(e['pitch'] for e in notes)],
        'maximum_physical_key_silence_seconds':round(max(silent,default=0),9),'unique_four_bar_phrases':len(set(signatures)),
        'distinct_harmonies':len(set(b['harmony_name'] for b in bars)),'ascending_middle_bars':[n for n,d in directions.items() if d=='ascending'],
        'strict_transfer_count':len(transfers),'minimum_transfer_margin_seconds':min(t['margin_seconds'] for t in transfers),
        'strict_transfers':transfers,'right_hand_within_position_large_moves':within,
        'limits':'Checks cover symbolic geometry, authored gates, pitch/finger positions and structure. They do not establish human comfort, acoustic realism, audio quality or listener response.'}

def verify_diff(a,b,d):
    errors=[];expected=[];musical=[]
    core=lambda ns:[{k:e[k] for k in ('onset','duration','pitch','instrument','voice','hand')} for e in ns]
    for n in range(1,65):
        row={'bar':n,'before_bar':a['bars'][n-1],'after_bar':b['bars'][n-1],
            'before_events':[e for e in a['events'] if e['bar']==n],'after_events':[e for e in b['events'] if e['bar']==n],
            'before_pedals':[e for e in a['pedals'] if e['bar']==n],'after_pedals':[e for e in b['pedals'] if e['bar']==n]}
        if any(row['before_'+k]!=row['after_'+k] for k in ('bar','events','pedals')):expected.append(row)
        if core(row['before_events'])!=core(row['after_events']) or row['before_bar']['harmony']!=row['after_bar']['harmony']:musical.append(n)
    if expected!=d['changes'] or [x['bar'] for x in expected]!=d['changed_bars']:errors.append('literal per-bar diff')
    if len(musical)<8:errors.append('revision must change at least eight musical bars')
    for label,s in [('before',a),('after',b)]:
        if d[label+'_sha256']!=sha(f'score_{s["version"]}.json'):errors.append('diff hashes')
        if d['phrase_metadata_'+label]!=s['phrases'] or d['position_plan_'+label]!=s['hand_position_plan']:errors.append('complete metadata diff')
    return {'passed':not errors,'errors':errors,'changed_bars':d['changed_bars'],'strict_musical_changed_bars':musical,'strict_musical_changed_bar_count':len(musical)}

def main():
    scores={v:load(f'score_{v}.json') for v in ('v0','v1','v2')}
    audits={v:inspect(s) for v,s in scores.items()}
    for v,result in audits.items():save(f'audit_{v}.json',result)
    diffs={f'{a}_to_{b}':verify_diff(scores[a],scores[b],load(f'exact_diff_{a}_to_{b}.json')) for a,b in [('v0','v1'),('v1','v2')]}
    same=(ROOT/'score.json').read_bytes()==(ROOT/'score_v2.json').read_bytes()
    # Separate fresh process; deterministic output is checked byte for byte.
    with tempfile.TemporaryDirectory(prefix='.reproduction_',dir=ROOT) as tmp:
        subprocess.run([sys.executable,str(ROOT/'generate_score.py'),'--outdir',tmp],check=True,capture_output=True)
        reproduction={p.name:(ROOT/p.name).read_bytes()==p.read_bytes() for p in sorted(Path(tmp).iterdir()) if p.is_file()}
    save('reproducibility_check.json',{'passed':all(reproduction.values()),'byte_identical_files':reproduction,'method':'Fresh standard-library Python process wrote into a temporary subdirectory of this work folder; all generated files compared byte for byte.'})
    result={'passed':same and all(x['passed'] for x in audits.values()) and all(x['passed'] for x in diffs.values()) and all(reproduction.values()),
        'selected_equals_v2_byte_for_byte':same,'selected_score_sha256':sha('score.json'),
        'version_summaries':{v:{k:r[k] for k in ('passed','errors','event_count','duration_with_tail_seconds','maximum_held_span_semitones','maximum_simultaneous_keys','same_key_overlap_count','hand_crossing_count','finger_collision_count','strict_transfer_count','minimum_transfer_margin_seconds','unique_four_bar_phrases','maximum_physical_key_silence_seconds')} for v,r in audits.items()},
        'revision_checks':diffs,'reproducibility_passed':all(reproduction.values()),
        'scope':'Disk-read symbolic verification independent of generator logic; reproduction invokes the generator in a separate process. No audio, listening, rendering or DSP.'}
    save('independent_verification.json',result)
    files={p.name:{'bytes':p.stat().st_size,'sha256':sha(p.name)} for p in sorted(ROOT.iterdir()) if p.is_file() and p.name!='hash_manifest.json'}
    save('hash_manifest.json',{'algorithm':'SHA-256','files':files,'excludes_self':True,'scope':'Every regular deliverable file in this draft folder; no files outside it changed.'})
    print(json.dumps(result,ensure_ascii=False,indent=2))
    if not result['passed']:raise SystemExit(1)
if __name__=='__main__':main()
