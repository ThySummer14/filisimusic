#!/usr/bin/env python3
"""Independent disk-based audit. Never imports/executes the composition generator.
Standard library only. Recomputes seconds, actual held-key geometry, source
contracts, breath gaps, form, and complete exact-diff reconstruction from disk.
"""
from pathlib import Path
from collections import defaultdict,Counter
import json, math, hashlib, difflib, statistics
R=Path(__file__).resolve().parent

def load(n):return json.loads((R/n).read_text(encoding='utf-8'))
def sha(n):return hashlib.sha256((R/n).read_bytes()).hexdigest()
def save(n,d):(R/n).write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def inspect(s):
 errors=[];bs=s['bars'];ev=s['events'];total=s['total_beats']
 def ck(ok,msg):
  if not ok:errors.append(msg)
 def sec(t):return sum(max(0,min(t-b['start'],b['beats']))*60/b['bpm'] for b in bs)
 def off(e):return e['onset']+e['duration']
 ck(s['id']==90 and s['title']=='The Moon’s Lost Luggage','identity');ck(len(bs)==144 and total==320 and s['tail_seconds']==5,'full form totals')
 cursor=0
 for i,b in enumerate(bs):
  ck(b['bar']==i+1 and b['start']==cursor,'sequential absolute bar grid');ck(b['beats']==4*b['meter_numerator']/b['meter_denominator'],'meter length');ck(b['meter']==f'{b["meter_numerator"]}/{b["meter_denominator"]}','meter label');cursor+=b['beats']
  ck(88<=b['bpm']<=107,'actual walk/trio tempo');ck(abs(b['time_start_seconds']-sec(b['start']))<1e-7,'bar seconds');ck(b['macro_phrase_length_bars']==8 and b['phrase_position']==i%8+1,'eight-bar sentence contract')
 ck(cursor==total,'last bar end');ck(195<=sec(total)+5<=220,'duration window');ck(abs(s['music_seconds']-sec(total))<1e-7 and abs(s['total_seconds_with_tail']-sec(total)-5)<1e-7,'top seconds')
 ck([b['bar'] for b in bs if b['meter']=='3/4']==list(range(57,89)),'expansive 32-bar trio');ck(Counter(b['meter'] for b in bs)=={'2/4':112,'3/4':32},'meter distribution')
 ck(len({e['event_id'] for e in ev})==len(ev),'unique event IDs');ck(ev==sorted(ev,key=lambda e:(e['onset'],e['instrument'],e['pitch'],e['event_id'])),'stable event ordering')
 required=('event_id','bar','onset','duration','pitch','velocity','instrument','voice','hand','role','phrase_id','layer','sample_layer')
 for e in ev:
  ck(all(k in e for k in required),'event schema');ck(all(math.isfinite(e[k]) for k in ('onset','duration','pitch','velocity')),'finite event numbers');ck(0<=e['onset']<off(e)<=total,'event bounds');ck(isinstance(e['pitch'],int) and 0<=e['pitch']<=127 and isinstance(e['velocity'],int) and 1<=e['velocity']<=127,'MIDI bounds')
  b=bs[e['bar']-1];ck(b['start']<=e['onset']<b['start']+b['beats'],'event/bar membership');ck(e['harmony_name']==b['harmony_name'],'harmony label');ck(e['onset_reference']=='ordinary_trigger','unshifted sample contract')
  ck(abs(e['target_on_beats']-e['onset'])<1e-7 and abs(e['target_off_beats']-off(e))<1e-7,'beat endpoints');ck(abs(e['target_on_seconds']-sec(e['onset']))<1e-7 and abs(e['target_off_seconds']-sec(off(e)))<1e-7,'integrated event seconds')
  if e['harmonic_function']=='chord_tone':ck(e['pitch']%12 in {x%12 for x in b['harmony']},'chord-tone claim')
  if e['role']=='support':ck(e['harmonic_function']=='chord_tone','shared harmonic support')
 ck({e['instrument'] for e in ev}=={'piano','clarinet'},'instrument set')
 pn=[e for e in ev if e['instrument']=='piano'];cs=sorted([e for e in ev if e['instrument']=='clarinet'],key=lambda e:e['onset'])
 for e in pn:
  ks=e['hand_position_keys'];ck(ks==sorted(set(ks)) and e['hand_position_range']==[ks[0],ks[-1]] and ks[-1]-ks[0]<=12,'named hand position');ck(e['pitch'] in ks and 1<=e['finger']<=5,'explicit finger/pitch');h=e['hand']
  if h=='right':ck(len(ks)==5 and 1<=e['finger']<=5 and ks[e['finger']-1]==e['pitch'] and e['hand_position_id']=='R'+'_'.join(map(str,ks)),'RH five-key fingers')
  else:ck(h=='left' and len(ks)==3 and e['pitch'] in ks and [5,3,1][ks.index(e['pitch'])]==e['finger'] and e['hand_position_id']=='L'+'_'.join(map(str,ks)),'LH three-key fingers')
  ck(e['layer']=='natural' and e['sample_layer']=='approved_natural_piano','approved piano intent')
 endpoints=defaultdict(list)
 for i,e in enumerate(pn):endpoints[e['onset']].append((1,i));endpoints[off(e)].append((0,i))
 active={};same=[];cross=[];fingers=[];positions=[];spans={'left':0,'right':0};maxkeys={'left':0,'right':0}
 for t,changes in sorted(endpoints.items()):
  for kind,i in sorted(changes):
   if kind==0:active.pop(i,None)
   else:active[i]=pn[i]
  notes=list(active.values());counts=Counter(e['pitch'] for e in notes)
  if max(counts.values(),default=0)>1:same.append(t)
  hands={h:[e for e in notes if e['hand']==h] for h in spans}
  for h,es in hands.items():
   if not es:continue
   ps=[e['pitch'] for e in es];spans[h]=max(spans[h],max(ps)-min(ps));maxkeys[h]=max(maxkeys[h],len(es))
   if len({e['finger'] for e in es})!=len(es):fingers.append(t)
   if len({e['hand_position_id'] for e in es})!=1:positions.append(t)
  if hands['left'] and hands['right'] and max(e['pitch'] for e in hands['left'])>=min(e['pitch'] for e in hands['right']):cross.append(t)
 ck(not same,'no same-key overlap across hands');ck(not cross,'no hand crossing');ck(not fingers,'no simultaneous finger reuse');ck(not positions,'no holding across a position change');ck(max(spans.values())<=12,'held hand span')
 transfers=[];within=[]
 for hand in ('left','right'):
  ns=[e for e in pn if e['hand']==hand];groups=defaultdict(list)
  for e in ns:groups[e['onset']].append(e)
  gg=sorted(groups.items())
  for (oo,old),(on,new) in zip(gg,gg[1:]):
   og=[min(e['pitch'] for e in old),max(e['pitch'] for e in old)];ng=[min(e['pitch'] for e in new),max(e['pitch'] for e in new)];op=old[0]['hand_position_range'];np=new[0]['hand_position_range'];gp=max(abs(a-b) for a,b in zip(og,ng));pm=max(abs(a-b) for a,b in zip(op,np));change=old[0]['hand_position_id']!=new[0]['hand_position_id']
   if not change and hand=='right':
    if gp>4:within.append({'onset':on,'grip_edge_motion_semitones':gp,'position_keys':new[0]['hand_position_keys'],'from_fingers':[e['finger'] for e in old],'to_fingers':[e['finger'] for e in new]})
    continue
   if not change and gp<=4:continue
   need=.075+.012*max(0,max(gp,pm)-4);latest=max(off(e) for e in ns if e['onset']<on);available=sec(on)-sec(latest);passed=available+1e-7>=need
   transfers.append({'hand':hand,'onset':on,'old_grip':og,'new_grip':ng,'old_position':op,'new_position':np,'actual_grip_edge_travel_semitones':gp,'position_edge_travel_semitones':pm,'required_release_seconds':round(need,9),'available_release_seconds':round(available,9),'passed':passed});ck(passed,'actual whole-hand released transfer')
 for e in cs:
  ck(60<=e['pitch']<=71 and e['source_pitch_midi']==e['pitch'],'recorded clarinet range, no transpose');expected='pp' if e['velocity']<=55 else 'mf' if e['velocity']<=95 else 'ff';ck(e['layer']==e['sample_layer']==expected,'actual clarinet layer by velocity');ck(e['source_family']=='University of Iowa clarinet' and e['sample_transition']=='none','source and no legato transition');ck(e['articulation']=='naturally_separated_breathed_tone' and e['hand']=='not_applicable','clarinet articulation/hand');ck(abs(e['nominal_gate_seconds']-sec(off(e))+sec(e['onset']))<1e-7,'clarinet gate seconds')
 gates=[sec(off(e))-sec(e['onset']) for e in cs];gaps=[sec(b['onset'])-sec(off(a)) for a,b in zip(cs,cs[1:])];breaths=[sec(b['onset'])-sec(off(a)) for a,b in zip(cs,cs[1:]) if a['phrase_id']!=b['phrase_id']]
 ck(min(gates)>=.30-1e-7 and max(gates)<=1.5+1e-7,'natural clarinet gate window');ck(min(gaps)>=.065-1e-7,'clarinet monophony/air gap');ck(min(breaths)>=.25-1e-7,'real interphrase breath');ck({e['layer'] for e in cs}=={'pp','mf','ff'},'all three genuine layers');ck([e['bar'] for e in cs if e['layer']=='ff']==[101,102],'ff confined to earned local climax')
 pedals=s['pedals'];ck(pedals==sorted(pedals,key=lambda e:e['onset']),'pedal sort');state=0
 for e in pedals:
  ck(e['instrument']=='piano' and e['controller']==64 and 0<=e['value']<=127,'pedal schema');ck(abs(e['target_on_seconds']-sec(e['onset']))<1e-7,'pedal seconds');ck(e['value']==0 if state else e['value']>0,'pedal down/up pairing');state=e['value']
 ck(state==0 and pedals[-1]['onset']<=total,'final pedal release')
 for b in bs:
  ons=[e for e in ev if e['bar']==b['bar']];lead=[e for e in ons if e['role']=='lead'];support=[e for e in ons if e['role']=='support']
  ck(bool(lead) and {e['instrument'] for e in lead}=={b['lead_instrument']},'exactly one foreground instrument per bar');ck(any(e['hand']=='left' for e in support),'supported melodic foreground');ck(max(e['velocity'] for e in support)<min(e['velocity'] for e in lead),'support dynamic intent');ck(not any(e['instrument']=='clarinet' for e in ons) if b['lead_instrument']=='piano' else not any(e['voice']=='melody' for e in ons),'noncompeting roles')
 phs={p['phrase_id']:p for p in s['phrases']};ck(len(phs)==len(s['phrases']) and set(phs)=={e['phrase_id'] for e in ev},'complete unique phrase coverage')
 for pid,p in phs.items():
  es=[e for e in ev if e['phrase_id']==pid];ck(p['first_bar']==min(e['bar'] for e in es) and p['last_bar']==max(e['bar'] for e in es),'phrase bars');ck(all(e['instrument']==p['instrument'] for e in es),'phrase instrument');on=min(e['onset'] for e in es);end=max(off(e) for e in es);ck(abs(on-p['target_on_beats'])<1e-7 and abs(end-p['target_off_beats'])<1e-7,'phrase endpoints');ck(abs(sec(on)-p['target_on_seconds'])<1e-7 and abs(sec(end)-p['target_off_seconds'])<1e-7,'phrase seconds');ck(p['layers_used']==sorted({e['layer'] for e in es}) and p['roles_used']==sorted({e['role'] for e in es}) and p['voices_used']==sorted({e['voice'] for e in es}),'phrase layer/role/voice contract')
 leads=[e for e in ev if e['role']=='lead'];signatures=[]
 for q in range(18):
  b0=bs[q*8]['start'];es=[e for e in leads if q*8+1<=e['bar']<=(q+1)*8];signatures.append(tuple((e['pitch'],round(e['onset']-b0,7),e['written_value_beats'],e['instrument']) for e in es))
 duplicates=[(i+1,j+1) for i,a in enumerate(signatures) for j,b in enumerate(signatures) if i<j and a==b]
 if s['version']=='v2':ck(not duplicates,'no duplicated full final melodic sentences')
 trio=[e for e in leads if 57<=e['bar']<=88];march=[e for e in leads if e['bar']<=56];trio_mean=statistics.mean(e['written_value_beats'] for e in trio);march_mean=statistics.mean(e['written_value_beats'] for e in march)
 if s['version']!='v0':ck(trio_mean>march_mean*1.5,'genuinely expanded trio note values')
 merged=[]
 for a,b in sorted((e['onset'],off(e)) for e in ev):
  if merged and a<=merged[-1][1]:merged[-1][1]=max(merged[-1][1],b)
  else:merged.append([a,b])
 silences=[{'start_beat':a[1],'end_beat':b[0],'seconds':round(sec(b[0])-sec(a[1]),9)} for a,b in zip(merged,merged[1:])];longest=max(silences,key=lambda x:x['seconds']);ck(longest['seconds']<1.1,'no padding by full-voice silence')
 sections=[]
 for name in ('A','B','T','D','R','Z'):
  bb=[b for b in bs if b['section']==name];nn=[e for e in leads if bs[e['bar']-1]['section']==name];sections.append({'section':name,'bars':[bb[0]['bar'],bb[-1]['bar']],'seconds':round(sum(b['beats']*60/b['bpm'] for b in bb),6),'lead_bar_counts':dict(Counter(b['lead_instrument'] for b in bb)),'lead_register':[min(e['pitch'] for e in nn),max(e['pitch'] for e in nn)],'lead_note_count':len(nn)})
 return {'passed':not errors,'errors':sorted(set(errors)),'event_count':len(ev),'duration_with_tail_seconds':round(sec(total)+5,9),'bar_count':len(bs),'total_beats':total,'meter_counts':dict(Counter(b['meter'] for b in bs)),'maximum_held_span_semitones':spans,'maximum_simultaneous_keys':maxkeys,'same_key_overlap_count':len(same),'hand_crossing_count':len(cross),'finger_collision_count':len(fingers),'held_position_collision_count':len(positions),'strict_transfer_count':len(transfers),'strict_transfer_count_by_hand':dict(Counter(t['hand'] for t in transfers)),'minimum_transfer_margin_seconds':round(min(t['available_release_seconds']-t['required_release_seconds'] for t in transfers),9),'strict_transfers':transfers,'verified_RH_within_position_finger_motion':within,'clarinet_event_count':len(cs),'clarinet_range':[min(e['pitch'] for e in cs),max(e['pitch'] for e in cs)],'recorded_clarinet_layers':dict(Counter(e['layer'] for e in cs)),'clarinet_gate_seconds':[round(min(gates),9),round(max(gates),9)],'minimum_clarinet_inter_note_gap_seconds':round(min(gaps),9),'minimum_clarinet_interphrase_breath_seconds':round(min(breaths),9),'phrase_count':len(phs),'lead_bar_counts':dict(Counter(b['lead_instrument'] for b in bs)),'unique_eight_bar_melodic_sentences':len(set(signatures)),'duplicate_eight_bar_sentences':duplicates,'trio_mean_written_note_beats':round(trio_mean,6),'opening_march_mean_written_note_beats':round(march_mean,6),'longest_all_voice_key_gate_silence':longest,'section_development':sections,'scope':'Independent symbolic timing, geometry, source and role contracts. No audio-quality assertion.'}

def verify_diff(a,b,d):
 errors=[];changes=[];musical=[];entries={x['bar']:x for x in d['changes']}
 def core(es):return [{k:e[k] for k in ('onset','duration','pitch','instrument','voice','hand')} for e in es]
 for ab,bb in zip(a['bars'],b['bars']):
  n=ab['bar'];ae=[e for e in a['events'] if e['bar']==n];be=[e for e in b['events'] if e['bar']==n];ap=[e for e in a['pedals'] if e['bar']==n];bp=[e for e in b['pedals'] if e['bar']==n]
  if (ab,ae,ap)!=(bb,be,bp):
   changes.append(n);expected={'bar':n,'before_bar':ab,'after_bar':bb,'before_events':ae,'after_events':be,'before_pedals':ap,'after_pedals':bp}
   if entries.get(n)!=expected:errors.append('exact bar-body mismatch '+str(n))
  if core(ae)!=core(be) or ab['harmony']!=bb['harmony']:musical.append(n)
 if changes!=d['changed_bars'] or sorted(entries)!=changes or musical!=d['strict_musical_changed_bars']:errors.append('changed-bar ledger mismatch')
 if len(musical)<8:errors.append('insubstantial revision')
 if d['before_sha256']!=sha('score_'+a['version']+'.json') or d['after_sha256']!=sha('score_'+b['version']+'.json'):errors.append('version hash mismatch')
 rebuilt=json.loads(json.dumps(a));rebuilt.update(d['top_level_replacements'])
 for x in d['changes']:
  n=x['bar'];rebuilt['bars'][n-1]=x['after_bar'];rebuilt['events']=[e for e in rebuilt['events'] if e['bar']!=n]+x['after_events'];rebuilt['pedals']=[e for e in rebuilt['pedals'] if e['bar']!=n]+x['after_pedals']
 rebuilt['events'].sort(key=lambda e:(e['onset'],e['instrument'],e['pitch'],e['event_id']));rebuilt['pedals'].sort(key=lambda e:e['onset'])
 if rebuilt!=b:errors.append('full next score reconstruction differs')
 an='score_'+a['version']+'.json';bn='score_'+b['version']+'.json';patch=''.join(difflib.unified_diff((R/an).read_text().splitlines(True),(R/bn).read_text().splitlines(True),fromfile=an,tofile=bn))
 if (R/f'exact_diff_{a["version"]}_to_{b["version"]}.patch').read_text()!=patch:errors.append('unified patch differs')
 return {'passed':not errors,'errors':errors,'changed_bars':changes,'strict_musical_changed_bars':musical,'strict_musical_changed_bar_count':len(musical),'full_score_reconstruction_equal':rebuilt==b}

def main():
 scores={v:load('score_'+v+'.json') for v in ('v0','v1','v2')};reports={v:inspect(s) for v,s in scores.items()};diffs={a+'_to_'+b:verify_diff(scores[a],scores[b],load('exact_diff_'+a+'_to_'+b+'.json')) for a,b in [('v0','v1'),('v1','v2')]};equal=(R/'score.json').read_bytes()==(R/'score_v2.json').read_bytes()
 for v,r in reports.items():save('audit_'+v+'.json',r)
 result={'passed':equal and all(x['passed'] for x in reports.values()) and all(x['passed'] for x in diffs.values()),'selected_equals_v2_byte_for_byte':equal,'selected_score_sha256':sha('score.json'),'versions':reports,'revision_checks':diffs,'method':'Separate disk-based verifier. Does not import/execute generator. Integrates each bar independently, sweeps true note gates and reconstructs complete versions from exact diffs.','limitations':'No audio rendered, sources opened or listening performed. Sample attacks/releases, timbre, loudness and final mix must be checked at integration.'};save('independent_verification.json',result)
 print(json.dumps({'passed':result['passed'],'versions':{v:{k:r[k] for k in ('passed','errors','event_count','duration_with_tail_seconds','strict_transfer_count','minimum_transfer_margin_seconds','clarinet_gate_seconds','minimum_clarinet_inter_note_gap_seconds','minimum_clarinet_interphrase_breath_seconds','unique_eight_bar_melodic_sentences')} for v,r in reports.items()},'revisions':diffs},ensure_ascii=False,indent=2))
 if not result['passed']:raise SystemExit(1)
if __name__=='__main__':main()
