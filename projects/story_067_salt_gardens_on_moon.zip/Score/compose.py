"""Original flowing acoustic-piano narrative with expanding and narrowing sentences."""
from pathlib import Path
import json,copy
P=Path(__file__).parent
A=[[(72,1),(75,.5),(80,1.5),(79,.5),(75,.5)],[(77,1),(75,.5),(72,.5),(70,1),(68,1)],[(70,.5),(72,.5),(75,1),(77,1),(75,1)],[(79,1),(77,.5),(75,.5),(73,1),(70,.5),(-1,.5)],[(72,.5),(73,.5),(75,2),(72,1)],[(73,1),(68,.5),(65,.5),(68,1),(72,1)],[(75,1),(79,.5),(82,.5),(80,1),(79,1)],[(80,2),(75,1),(-1,1)],[(79,1),(75,.5),(72,.5),(70,1),(68,1)],[(73,1),(75,.5),(77,.5),(80,1),(77,1)],[(79,.5),(82,.5),(85,1),(84,.5),(82,.5),(79,1)],[(80,1),(75,1),(72,1),(-1,1)]]
B=[[(75,.5),(80,.5),(84,1),(82,.5),(80,.5),(75,1)],[(77,1),(80,.5),(84,.5),(82,1),(80,1)],[(82,1),(80,.5),(77,.5),(75,.5),(73,.5),(70,1)],[(79,.5),(75,.5),(70,1),(73,.5),(75,.5),(79,1)],[(80,1),(77,.5),(75,.5),(72,1),(68,1)],[(77,.5),(80,.5),(85,1.5),(84,.5),(80,1)],[(82,1),(79,.5),(75,.5),(73,1),(70,1)],[(80,2.5),(-1,1.5)],[(84,1),(80,.5),(77,.5),(75,1),(72,1)],[(80,.5),(77,.5),(73,1),(75,.5),(77,.5),(80,1)],[(82,1),(85,.5),(87,.5),(85,1),(82,1)],[(84,1),(80,1),(75,1),(-1,1)]]
R=[[(72,1.5),(70,.5),(68,1),(67,1)],[(68,1),(72,.5),(75,.5),(73,1),(72,1)],[(70,1),(73,.5),(75,.5),(73,1),(70,1)],[(71,.5),(74,.5),(77,1),(74,1),(-1,1)],[(72,1),(68,.5),(65,.5),(67,1),(68,1)],[(73,1.5),(72,.5),(70,1),(68,1)],[(67,.5),(70,.5),(73,1),(75,1),(79,1)],[(80,2),(75,1),(-1,1)]]
H={'Ab':[44,51,56,60],'Fm':[41,53,56,60],'Db':[37,53,56,61],'Eb7':[39,55,58,61],'Cm':[48,55,60,63],'Bbm':[46,53,58,61],'G7':[43,53,59,62],'Eb':[39,55,58,63]}
pa=['Ab','Fm','Db','Eb7','Fm','Db','Eb7','Ab','Fm','Db','Eb7','Ab'];pr=['Cm','Fm','Bbm','G7','Fm','Db','Eb7','Ab']
sections=[('Clear trays beneath the window',4,64,'intro'),('Letters become branching salt',12,68,'letters'),('Three pauses during a walk',12,72,'branches'),('Reading the same edges',8,66,'reread'),('Sending a voice toward Earth',12,70,'outward'),('Room beside the new branch',6,60,'coda')]
events=[];bars=[];pedals=[];beat=0;bar=0
for title,count,bpm,kind in sections:
 for j in range(count):
  bar+=1
  if kind in ['intro','letters']:line=copy.deepcopy(A[j%12]);h=pa[j%12]
  elif kind in ['branches','outward']:line=copy.deepcopy(B[j%12]);h=pa[j%12]
  elif kind=='reread':line=copy.deepcopy(R[j]);h=pr[j]
  else:
   line=copy.deepcopy([[(77,1),(75,.5),(72,.5),(68,2)],[(73,.5),(77,.5),(80,1),(77,.5),(75,.5),(73,1)],[(75,1.5),(73,.5),(70,1),(67,1)],[(72,1),(75,.5),(80,.5),(79,1),(75,1)],[(77,1),(75,.5),(73,.5),(70,1),(68,1)],[(72,1),(70,2),(-1,1)]][j]);h=['Fm','Db','Eb7','Ab','Db','Ab'][j]
  assert sum(l for n,l in line)==4
  tempo=bpm if kind!='coda' else [60,60,58,58,54,48][j];vel={'intro':60,'letters':68,'branches':74,'reread':59,'outward':73,'coda':59}[kind];ch=H[h]
  bars.append(dict(bar=bar,start=beat,beats=4,bpm=tempo,meter_numerator=4,meter_denominator=4,section=title,harmony_name=h,harmony=ch,role_plan=kind,phrase_position=j))
  off=0
  for n,l in line:
   if n>=0:events.append(dict(bar=bar,onset=beat+off,duration=l*.975,pitch=n,velocity=vel+(2 if off==0 else 0),voice='melody'))
   off+=l
  events.append(dict(bar=bar,onset=beat,duration=.56,pitch=ch[0],velocity=vel-23,voice='bass'))
  for t,n in [(.75,ch[1]),(1.25,ch[2]),(1.75,ch[3]),(2.25,ch[2]),(2.75,ch[1]),(3.25,ch[2])]:
   if kind=='coda' and j==5 and t>1.75:continue
   events.append(dict(bar=bar,onset=beat+t,duration=.46,pitch=n,velocity=vel-34+(2 if t==1.75 else 0),voice='accompaniment'))
  for t,v in [(0,0),(.12,48),(3.86,0)]:pedals.append(dict(onset=beat+t,value=v))
  beat+=4
d=dict(id=67,title='Salt Gardens on the Moon',title_zh='月上的盐花园',stage='v0_original_flowing_piano_narrative',bars=bars,events=events,pedals=pedals,total_beats=beat,tail_seconds=4)
for f in ['score.json','revisions/score_v0.json']:(P/f).write_text(json.dumps(d,indent=2))
(P/'thematic_material.json').write_text(json.dumps(dict(A=A,B=B,R=R),indent=2));print(bar,sum(b['beats']*60/b['bpm'] for b in bars)+4)
