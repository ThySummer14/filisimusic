"""Work101: original bar-authored chamber miniature, three symbolic versions.
No existing work's notes, harmony sequence or stories are imported.
"""
from pathlib import Path
import copy, json, hashlib, difflib
P=Path(__file__).resolve().parent
# Every token is pitch:eighth-note units. R is a composed rest.
PHRASES=[
('Dm A7 Dm Bb Gm Dm/A A7 Dm', '''D5:2 A5:1 F5:1 E5:2 G5:1|F5:2 C#5:2 D5:3|D5:1 F5:1 A5:2 G5:1 F5:1 E5:1|F5:3 D5:1 C5:1 Bb4:2|D5:2 G5:1 F5:1 D5:1 Bb4:1 A4:1|A4:1 D5:1 E5:1 F5:1 E5:1 D5:2|C#5:2 E5:1 A5:1 G5:1 E5:1 C#5:1|D5:3 R:1 A4:1 C5:1 D5:1'''),
('Dm C Bb A7 Dm F Gm A7', '''D5:1 A5:1 F5:1 E5:1 D5:2 A4:1|E5:2 G5:1 E5:1 D5:1 C5:2|F5:1 D5:1 Bb4:1 D5:2 F5:2|E5:1 C#5:1 A4:2 C#5:1 E5:2|D5:2 F5:1 A5:1 G5:1 F5:1 E5:1|C5:1 F5:2 A5:1 G5:1 F5:2|G5:2 D5:1 Bb4:1 A4:1 Bb4:1 D5:1|C#5:1 E5:1 G5:1 A5:1 G5:1 E5:2'''),
('Bb F/A Gm A7 Dm Bb Gm A7', '''F5:2 D5:2 Bb4:1 C5:1 D5:1|C5:2 A4:1 C5:1 F5:1 E5:2|D5:1 Bb4:1 G4:1 Bb4:1 D5:1 F5:2|E5:2 C#5:1 A4:1 G4:1 A4:2|F5:1 E5:1 D5:2 A4:1 C5:1 D5:1|D5:2 F5:1 Bb5:1 A5:1 F5:2|G5:1 F5:1 D5:1 Bb4:1 D5:1 G5:2|E5:2 C#5:2 R:1 A4:2'''),
('Dm Dm/C Bb A7 Gm Dm/F A7 Dm', '''D5:1 F5:1 A5:1 G5:1 F5:1 E5:2|D5:2 A4:1 C5:1 D5:1 F5:2|F5:1 D5:1 Bb4:1 C5:1 D5:1 F5:2|E5:1 C#5:1 A4:1 E5:1 G5:1 A5:2|G5:2 F5:1 D5:1 Bb4:1 A4:1 G4:1|F4:1 A4:1 D5:2 E5:1 F5:2|E5:2 C#5:1 A4:1 R:1 E5:1 C#5:1|D5:4 R:3'''),
('Gm Dm/F Eb A7 Bb C A7 Dm', '''G5:1 F5:1 D5:1 Bb4:1 D5:1 F5:1 G5:1|A5:1 F5:1 E5:1 D5:1 F5:1 A5:2|G5:1 Eb5:1 D5:1 C5:1 Bb4:1 G4:2|C#5:1 E5:1 A5:1 G5:1 E5:1 C#5:2|D5:1 F5:1 Bb5:1 A5:1 F5:1 D5:2|E5:1 G5:1 C6:1 Bb5:1 G5:1 E5:2|G5:1 E5:1 C#5:1 A4:1 C#5:1 E5:2|F5:1 E5:1 D5:2 A4:1 D5:2'''),
('Dm Bb Gm A7 F C/E Gm A7', '''A5:1 G5:1 F5:1 E5:1 D5:1 F5:2|Bb5:1 A5:1 F5:1 D5:1 C5:1 D5:2|G5:1 F5:1 D5:1 Bb4:1 A4:1 Bb4:2|A5:1 G5:1 E5:1 C#5:1 A4:1 C#5:2|F5:2 A5:1 G5:1 F5:1 E5:2|G5:1 E5:1 C5:1 E5:1 G5:1 E5:2|D5:1 Bb4:1 G4:2 R:1 D5:2|C#5:1 E5:1 R:2 A4:1 R:2'''),
('F C/E Dm Bb Gm F/A C F Dm Bb A7 Dm', '''A4:3 C5:1 F5:3 R:1|G4:2 C5:2 E5:2 D5:2|F5:3 E5:1 D5:2 A4:2|D5:2 C5:2 Bb4:3 R:1|Bb4:3 A4:1 G4:2 D5:2|C5:2 A4:1 G4:1 F4:4|E4:2 G4:2 C5:3 R:1|A4:2 C5:2 F5:4|F5:2 D5:1 C5:1 A4:2 F4:2|D5:2 C5:1 Bb4:1 F4:3 R:1|E5:2 C#5:2 A4:3 R:1|D5:4 R:4'''),
('Dm C Bb A7 Dm F Gm A7', '''D5:2 A5:1 F5:1 E5:2 G5:1|E5:2 G5:1 C6:1 Bb5:1 G5:2|F5:2 D5:1 Bb4:1 D5:1 F5:2|E5:2 C#5:2 D5:3|D5:1 F5:1 A5:1 G5:1 F5:1 E5:2|F5:1 A5:1 C6:1 A5:1 G5:1 F5:2|G5:2 Bb5:1 A5:1 G5:1 F5:1 D5:1|E5:1 G5:1 A5:1 G5:1 E5:1 C#5:2'''),
('Bb F/A Gm A7 Dm C Bb A7', '''F5:1 D5:1 F5:1 Bb5:1 A5:1 G5:2|A5:1 F5:1 E5:1 C5:1 A4:1 C5:2|D5:1 G5:1 Bb5:1 A5:1 G5:1 F5:2|E5:1 C#5:1 E5:1 G5:1 A5:1 G5:2|F5:2 E5:1 D5:1 A4:1 C5:2|E5:1 G5:1 C6:1 Bb5:1 A5:1 G5:2|F5:1 D5:1 Bb4:1 D5:1 F5:1 Bb5:2|A5:1 G5:1 E5:1 C#5:1 E5:1 G5:2'''),
('Dm F Bb A7 Gm Dm/F A7 Dm', '''A5:2 F5:1 D5:1 E5:1 F5:2|C6:1 A5:1 G5:1 F5:1 E5:1 F5:2|Bb5:1 A5:1 F5:1 D5:1 F5:1 G5:2|A5:2 G5:1 E5:1 C#5:1 E5:2|G5:1 F5:1 D5:1 Bb4:1 D5:1 G5:2|F5:1 E5:1 D5:1 A4:1 D5:1 F5:2|E5:1 G5:1 A5:1 G5:1 E5:1 C#5:2|D5:2 A5:1 F5:1 D5:3'''),
('Gm Bb F A7 Dm Bb A7 Dm', '''D5:1 G5:1 Bb5:1 A5:1 G5:1 F5:2|D5:1 F5:1 Bb5:1 A5:1 F5:1 D5:2|C5:1 F5:1 A5:1 G5:1 F5:1 E5:2|C#5:1 E5:1 A5:1 G5:1 E5:1 C#5:2|D5:2 F5:1 A5:1 G5:1 F5:2|F5:2 D5:1 Bb4:1 C5:1 D5:2|E5:1 C#5:1 A4:1 C#5:1 E5:1 R:2|D5:5 R:2'''),
('Bb Gm A7 Dm', '''D5:2 F5:1 D5:1 Bb4:2 F4:2|Bb4:2 A4:1 G4:1 D4:4|E4:2 G4:1 A4:1 C#5:2 R:2|D5:2 A4:2 F4:2 D4:2'''),
]
# Substantive revision1: broken chase, displaced answers and harmonic rerouting.
R1={17:'F5:1 A5:1 F5:2 D5:1 C5:1 D5:1',18:'E5:1 C5:2 A4:1 C5:1 F5:2',19:'D5:2 R:1 Bb4:1 A4:1 G4:2',20:'E5:1 C#5:1 A4:1 R:1 C#5:1 E5:2',23:'G5:2 R:1 D5:1 F5:1 G5:2',24:'E5:1 C#5:1 E5:1 R:2 A4:2',33:'G5:1 D5:1 G5:1 Bb5:1 A5:1 G5:2',34:'F5:1 A5:1 F5:1 E5:1 D5:1 C5:2',35:'G5:1 Eb5:1 Bb4:2 C5:1 D5:2',36:'E5:1 C#5:1 R:1 A4:1 C#5:1 E5:2',37:'F5:1 D5:1 F5:1 Bb5:1 A5:1 F5:2',38:'G5:1 E5:1 C5:1 G5:1 E5:1 D5:2',39:'C#5:1 E5:1 G5:1 R:1 A5:1 G5:2',40:'F5:2 E5:1 D5:1 R:1 A4:2',45:'F5:1 C5:1 A4:2 C5:1 F5:2',46:'E5:1 C5:1 G4:2 C5:1 E5:2',47:'D5:1 Bb4:1 G4:1 R:2 D5:2',48:'C#5:1 E5:1 A4:1 R:4'}
H1={17:'Bbmaj7',18:'F/A',23:'Gm7',33:'Gm7',35:'Ebmaj7',37:'Bbmaj7',38:'C/E',45:'F/A',46:'C/E'}
# Revision2: return answers after the quiet section, changed phrase lengths and climax release.
R2={61:'D5:2 A5:1 F5:1 R:1 E5:1 G5:1',62:'E5:1 G5:1 C6:1 Bb5:1 G5:1 E5:2',63:'F5:1 D5:1 Bb4:1 R:1 D5:1 F5:2',64:'E5:1 C#5:1 R:1 A4:1 C#5:1 D5:2',65:'F5:1 E5:1 D5:1 A4:1 D5:1 F5:2',66:'A5:1 G5:1 F5:2 C5:1 F5:2',67:'G5:1 D5:1 G5:1 Bb5:1 A5:1 G5:2',68:'E5:2 C#5:1 E5:1 G5:1 A5:2',73:'D5:1 F5:1 A5:1 D6:1 C6:1 A5:2',74:'G5:1 E5:1 G5:1 C6:1 Bb5:1 G5:2',75:'F5:2 D5:1 Bb4:1 F5:1 Bb5:2',76:'A5:1 G5:1 E5:1 C#5:1 A4:1 C#5:2',77:'A5:1 F5:1 D5:1 F5:1 A5:1 D6:2',78:'C6:2 A5:1 G5:1 F5:1 A5:2',79:'Bb5:1 F5:1 D5:1 F5:1 Bb5:1 A5:2',80:'G5:1 E5:1 C#5:1 E5:1 G5:1 A5:2',81:'Bb5:2 A5:1 G5:1 F5:1 D5:2',82:'F5:1 E5:1 D5:2 A4:1 F4:2',83:'E5:1 C#5:1 A4:1 R:1 C#5:1 E5:2',84:'D5:3 R:4',89:'D5:1 A5:1 F5:1 E5:1 D5:1 F5:2',90:'F5:2 D5:1 C5:1 Bb4:1 F4:2',91:'E5:1 C#5:1 A4:1 E5:1 C#5:1 R:2',92:'D5:2 A4:1 F4:1 D4:1 R:2',95:'E4:2 G4:1 A4:1 C#5:1 R:3',96:'D5:1 A4:1 F4:2 D4:4'}
H2={61:'Dm(add9)',63:'Bbmaj7',65:'Dm/F',66:'F/A',67:'Gm7',73:'Dm/A',75:'Bbmaj7',77:'Dm/A',78:'F/A',79:'Bbmaj7',81:'Gm7',82:'Dm/F',89:'Dm/F',90:'Bbmaj7'}
H={
'Dm':[50,53,57],'Dm/A':[45,50,53],'Dm/F':[53,57,62],'Dm/C':[48,50,53], 'Dm(add9)':[50,53,57,64],
'A7':[45,49,52,55],'Bb':[46,50,53],'Bbmaj7':[46,50,53,57],'Gm':[43,46,50],'Gm7':[43,46,50,53],
'F':[53,57,60],'F/A':[45,48,53],'C':[48,52,55],'C/E':[52,55,60], 'Eb':[51,55,58],'Ebmaj7':[51,55,58,62]}
ROOTS={'Dm':38,'A7':45,'Bb':46,'Gm':43,'F':41,'C':36,'Eb':39}
def pitch(s):return 12*(int(s[-1])+1)+{'C':0,'D':2,'E':4,'F':5,'G':7,'A':9,'B':11}[s[0]]+s[1:-1].count('#')-s[1:-1].count('b')
def sect(n):
 if n<=8:return 'A0','冲出雨棚',112,3.5,84
 if n<=32:return 'A','街角换步',112,3.5,76
 if n<=48:return 'B','积水封住路口',120,3.5,86
 if n<=60:return 'C','邮袋里的旧地址',76,4,49
 if n<=84:return 'A2','沿屋檐跑向新门',116,3.5,86
 if n<=92:return 'D','铃响前的最后一段',112,3.5,91
 return 'Coda','门终于打开',72,4,52

def make(level):
 lines=[];harm=[]
 for hr,lr in PHRASES:harm+=hr.split();lines+=[x.strip() for x in lr.split('|')]
 assert len(lines)==len(harm)==96
 for lv,rd,hd in [(1,R1,H1),(2,R2,H2)]:
  if level>=lv:
   for n,s in rd.items():lines[n-1]=s
   for n,s in hd.items():harm[n-1]=s
 bars=[];events=[];pedals=[];beat=0.
 for n,(line,h) in enumerate(zip(lines,harm),1):
  section,label,bpm,beats,dyn=sect(n)
  if n in [8,32,48,60,84,92]:bpm-=4
  if n==96:bpm=62
  chord=H[h];root=ROOTS[next(k for k in ROOTS if h.startswith(k))]
  b=dict(bar=n,start=beat,beats=beats,bpm=bpm,meter='7/8' if beats==3.5 else '4/4',meter_numerator=7 if beats==3.5 else 4,meter_denominator=8 if beats==3.5 else 4,section=section,section_title_zh=label,harmony_name=h,harmony=chord,key_region='F major' if section=='C' else 'D minor',metrical_grouping='2+2+3' if beats==3.5 else 'breathing quarters',texture='pizzicato_acoustic_drive' if beats==3.5 else 'unaccompanied_answer_and_inner_voice')
  bars.append(b)
  def add(p,t,d,v,instrument,voice,hand='none'):
   assert 0<=t<beats and d>0 and t+d<=beats+1e-8,(n,t,d)
   events.append(dict(bar=n,onset=round(beat+t,6),duration=round(d,6),pitch=p,velocity=max(1,min(115,int(v))),instrument=instrument,voice=voice,hand=hand,harmony_name=h,phrase_id=f'{section}_{(n-1)//4}',role='lead' if voice=='melody' else 'support',written_value_beats=d,articulation='released_acoustic_phrase'))
  at=0.
  for i,tok in enumerate(line.split()):
   note,units=tok.split(':');dur=int(units)/2
   if note!='R':
    # Phrase accents and strict detached travel prevent same-hand impossible legato.
    vel=dyn+(5 if at in (0.,1.,2.) and beats==3.5 else 0)+(3 if 77<=n<=81 else 0)-(5 if i==len(line.split())-1 else 0)
    add(pitch(note),at,max(.08,dur-(.10 if beats==3.5 else .06)),vel,'piano','melody','right')
   at+=dur
  assert abs(at-beats)<1e-8,(n,at,beats)
  # Piano is deliberately clear of cello's low octave. Left hand anchors chosen accents,
  # then answers in spaces; the quiet middle has independent quarter-note voice leading.
  if beats==3.5:
   pattern=[(0,0,.38),(1,1,.32),(2,2,.45)]
   if n%4==0:pattern=[(0,0,.4),(1.5,1,.35)]
   if level>=1 and (17<=n<=24 or 33<=n<=48):pattern=[(.5,1,.3),(1.5,2,.3),(2.5,0,.42)]
   if level>=2 and 61<=n<=84:pattern=[(0,0,.32),(1,2,.32),(2.5,1,.35)] if n%2 else [(0,0,.35),(1.5,1,.3),(2.5,2,.4)]
   if level>=2 and n in [84,92]:pattern=[(0,0,.6)]
   for t,idx,d in pattern:
    add(chord[idx],t,d,dyn-27,'piano','harmonic_step','left')
    if n%4==1 and t==0 and n not in [61]:add(chord[min(idx+1,len(chord)-1)],t,d,dyn-31,'piano','inner_anchor','left')
  else:
   pattern=[(0,0,.85),(1.5,1,.9),(3,2,.75)]
   if n%4==0:pattern=[(0,0,1.4),(2,1,1.5)]
   if n==96:pattern=[(0,0,3.65)]
   for t,idx,d in pattern:add(chord[idx],t,d,dyn-14,'piano','quiet_counterline','left')
  # Cello changes from primary pulse to absent/single-point punctuation.
  if beats==3.5 and n not in [32,48]:
   entries=[(0,.48),(2,.45)] if n%2 else [(1,.45)]
   if level>=1 and 33<=n<=48:entries=[(0,.38),(1.5,.38),(2.5,.4)] if n%4!=0 else [(0,.4)]
   if level>=2 and 61<=n<=84:entries=[(.5,.4),(2,.42)] if n%2 else [(0,.45),(2.5,.42)]
   if n in [84,92]:entries=[(0,.5)]
   for i,(t,d) in enumerate(entries):
    cp=root if i==0 else 36+(root+7)%12
    add(cp,t,d,dyn+5,'cello','pizzicato_pulse')
  elif n in [49,57,60,93,96]:add(root,0,.6,dyn+4,'cello','punctuation')
  pedals += [dict(bar=n,onset=beat,controller=64,value=0,instrument='piano')]
  if beats==4:
   pedals += [dict(bar=n,onset=beat+.07,controller=64,value=45,instrument='piano'),dict(bar=n,onset=beat+beats-.12,controller=64,value=0,instrument='piano')]
  elif n%4==0 and n not in [48,84]:
   pedals += [dict(bar=n,onset=beat+.06,controller=64,value=27,instrument='piano'),dict(bar=n,onset=beat+.65,controller=64,value=0,instrument='piano')]
  beat+=beats
 events.sort(key=lambda e:(e['onset'],e['instrument'],e['pitch']))
 for i,e in enumerate(events):e['event_id']=f'w101-v{level}-{i:04d}'
 return dict(id=101,title='Rain City Courier',title_zh='雨城疾邮',version=f'v{level}',instrumentation=['piano','cello_pizzicato'],bars=bars,events=events,pedals=pedals,total_beats=beat,tail_seconds=5,performance_contract='Original acoustic-sample chamber composition. Separate hands, original 2+2+3 motive, wide structural contrast. No claim of live performance or human listening approval.')

def musical(e):return {k:v for k,v in e.items() if k not in ['event_id']}
for v in range(3):
 d=make(v);(P/f'score_v{v}.json').write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
 for inst in ['piano','cello']:
  x=copy.deepcopy(d);x['events']=[e for e in x['events'] if e['instrument']==inst];x['pedals']=x['pedals'] if inst=='piano' else []
  if v==2:(P/f'{inst}_score.json').write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
 duration=sum(b['beats']*60/b['bpm'] for b in d['bars'])+d['tail_seconds']
 report=dict(version=f'v{v}',bars=len(d['bars']),notes=len(d['events']),duration_seconds=duration,composer_revision_stage=['first_complete_score','theme_rhythm_and_harmonic_revision','return_orchestration_and_release_revision'][v],human_listening_review=False)
 (P/f'audit_v{v}.json').write_text(json.dumps(report,indent=2))
 if v:
  old=make(v-1);changed=[]
  for n in range(1,97):
   oe=[musical(e) for e in old['events'] if e['bar']==n];ne=[musical(e) for e in d['events'] if e['bar']==n]
   if oe!=ne or old['bars'][n-1]!=d['bars'][n-1]:changed.append(n)
  a=(P/f'score_v{v-1}.json').read_text();b=(P/f'score_v{v}.json').read_text()
  (P/f'exact_diff_v{v-1}_to_v{v}.patch').write_text(''.join(difflib.unified_diff(a.splitlines(True),b.splitlines(True),f'score_v{v-1}.json',f'score_v{v}.json')))
  (P/f'exact_diff_v{v-1}_to_v{v}.json').write_text(json.dumps(dict(changed_bars=changed,count=len(changed),musical_content_compared_excluding_ids=True),indent=2))
(P/'score.json').write_text((P/'score_v2.json').read_text());(P/'ensemble_score.json').write_text((P/'score_v2.json').read_text())
print(json.dumps(report));print('Two musical revisions:',[json.loads((P/f'exact_diff_v{i}_to_v{i+1}.json').read_text())['count'] for i in range(2)])
