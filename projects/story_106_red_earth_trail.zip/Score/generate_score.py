"""Work106: early effort peak, long late pause and a gentler shared return."""
from pathlib import Path
import json,difflib,sys,bisect
P=Path(__file__).resolve().parent;sys.path.insert(0,str(P));from composition_data import *
def pitch(s):return 12*(int(s[-1])+1)+{'C':0,'D':2,'E':4,'F':5,'G':7,'A':9,'B':11}[s[0]]+s[1:-1].count('#')-s[1:-1].count('b')
def section(n):
 if n<=16:return 'Start','红土上的准备步',96,60,2.5
 if n<=40:return 'A','先一步越过弯道',116,81,2.5
 if n<=64:return 'B','坡度忽然加重',120,96,2.5
 if n<=80:return 'Drain','用尽的步幅',108 if n<=72 else 96,64,2.5
 if n<=96:return 'Pause','等同伴走到身边',84,43,4
 if n<=120:return 'Shared','缩短到同一个步幅',112,77,2.5
 if n<=128:return 'Ridge','越过最后一道脊线',104,81,2.5
 return 'Coda','一起慢下来',74,47,4

def build(level):
 hs=[];lines=[]
 for key in ORDER:
  h,s=BLOCKS[key];hs+=h.split();lines+=s.split('|')
 assert len(lines)==len(hs)==132
 for lv,rd,hd in [(1,REV1,HREV1),(2,REV2,HREV2)]:
  if level>=lv:
   for n,s in rd.items():lines[n-1]=s
   for n,h in hd.items():hs[n-1]=h
 bars=[];events=[];pedals=[];start=0.
 for n,(line,h) in enumerate(zip(lines,hs),1):
  sec,label,bpm,dyn,beats=section(n);ch=H[h];meter='4/4' if beats==4 else '5/8';alternate=41<=n<=48 or 57<=n<=64
  if n in [16,40,64,80,96,120,128]:bpm-=4
  if n==132:bpm=66
  bars.append(dict(bar=n,start=start,beats=beats,bpm=bpm,meter=meter,meter_numerator=4 if beats==4 else 5,meter_denominator=4 if beats==4 else 8,section=sec,section_title_zh=label,harmony_name=h,harmony=ch,key_region='A major' if sec=='Pause' else 'F# minor',metrical_grouping='2+3 eighths' if alternate else '3+2 eighths' if beats==2.5 else 'long shared breaths',texture='late_pause_after_early_peak'))
  def add(p,t,d,v,inst,voice,hand='none'):
   assert 0<=t<t+d<=beats+.00001,(n,t,d,beats)
   events.append(dict(bar=n,onset=round(start+t,6),duration=round(d,6),pitch=p,velocity=int(v),instrument=inst,voice=voice,hand=hand,harmony_name=h,phrase_id=f'{sec}_{(n-1)//4}',role='lead' if voice in ['melody','flute_song'] else 'support',articulation='asymmetric_run_or_real_breath',written_value_beats=d))
  at=0.
  for i,tok in enumerate(line.split()):
   name,u=tok.split(':');dur=int(u)/2
   if name!='R':add(pitch(name),at,dur-.09,dyn+(4 if at==1.5 and beats==2.5 else 0)-(4 if i==len(line.split())-1 else 0),'piano','melody','left' if sec=='Pause' else 'right')
   at+=dur
  assert at==beats,(n,at)
  if sec=='Pause':
   if n%2:add(76 if h.startswith('A') else 78,2,.55,dyn-21,'piano','sparse_upper_answer','right')
  elif sec=='Coda':
   for t,p,d in [(0,ch[0],1.5),(2,ch[1],1.4)]:add(p,t,d,dyn-15,'piano','settled_lower_voice','left')
  else:
   pat=[(0,ch[0],.32),(1 if alternate else 1.5,ch[2],.36)]
   if n%4==2:pat=[(.5,ch[1],.30),(1.75,ch[0],.30)]
   if level>=1 and 41<=n<=56:pat=[(.5,ch[0],.26),(1.5,ch[1],.26),(2,ch[2],.25)]
   if level>=2 and 97<=n<=112:pat=[(0,ch[0],.3),(1,ch[1],.28)] if n%2 else [(.5,ch[1],.28),(1.75,ch[2],.3)]
   if n in [40,64,80,96,104,112,120,128]:pat=[(0,ch[0],.45)]
   for t,p,d in pat:add(p,t,d,dyn-27,'piano','coordinated_running_step','left')
  # Wind is genuinely sampled C5–B5, never guessed or stretched to missing notes.
  available=[p for p in range(72,84) if p%12 in {x%12 for x in ch}];assert available
  if sec=='Pause':
   one,two=WIND_HUSH[n-81]
   for t,p in [(.5,one),(2.5,two)]:add(p,t,.84*bpm/60,48,'flute','flute_song')
  elif sec=='Coda':
   if n in [129,132]:add(78 if n==132 else available[-1],.5,1.05*bpm/60,46,'flute','final_breath')
  elif n>=9 and n%8 in [4,5]:
   p=available[-1] if n%8==4 else available[0];add(p,.5,.52*bpm/60,73 if sec=='B' else 63,'flute','phrase_answer')
  if level>=1 and 41<=n<=56 and n%8 in [1,2]:add(available[0],.5,.48*bpm/60,74,'flute','climb_answer')
  if level>=2 and 97<=n<=120 and n%8 in [1,2]:add(available[0],.5,.53*bpm/60,62,'flute','shared_answer')
  pedals.append(dict(bar=n,onset=start,controller=64,value=0,instrument='piano'))
  if sec in ['Pause','Coda']:
   pedals +=[dict(bar=n,onset=start+.06,controller=64,value=31,instrument='piano'),dict(bar=n,onset=start+1.7,controller=64,value=0,instrument='piano'),dict(bar=n,onset=start+2.1,controller=64,value=28,instrument='piano'),dict(bar=n,onset=start+3.8,controller=64,value=0,instrument='piano')]
  elif n%4==0:pedals +=[dict(bar=n,onset=start+.04,controller=64,value=21,instrument='piano'),dict(bar=n,onset=start+.50,controller=64,value=0,instrument='piano')]
  start+=beats
 events.sort(key=lambda e:(e['onset'],e['instrument'],e['pitch']))
 for i,e in enumerate(events):e['event_id']=f'w106-v{level}-{i:04d}'
 return dict(id=106,title='Red Earth Trail',title_zh='红土越野',version=f'v{level}',bars=bars,events=events,pedals=pedals,total_beats=start,tail_seconds=5,instrumentation=['piano','flute'],performance_contract='Original acoustic sample work; fastest/loudest effort precedes a long late pause. Final shared motion is gentler, not a louder duplicate.')
for v in range(3):
 d=build(v);(P/f'score_v{v}.json').write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n');report=dict(version=f'v{v}',bars=132,notes=len(d['events']),duration_seconds=sum(b['beats']*60/b['bpm'] for b in d['bars'])+5,human_listening_review=False);(P/f'audit_v{v}.json').write_text(json.dumps(report,indent=2))
 if v:
  old=build(v-1);changed=[]
  for n in range(1,133):
   clean=lambda e:{k:x for k,x in e.items() if k!='event_id'}
   if [clean(e) for e in old['events'] if e['bar']==n]!=[clean(e) for e in d['events'] if e['bar']==n]:changed.append(n)
  a=(P/f'score_v{v-1}.json').read_text();b=(P/f'score_v{v}.json').read_text();(P/f'exact_diff_v{v-1}_to_v{v}.patch').write_text(''.join(difflib.unified_diff(a.splitlines(True),b.splitlines(True),f'score_v{v-1}.json',f'score_v{v}.json')));(P/f'exact_diff_v{v-1}_to_v{v}.json').write_text(json.dumps({'changed_bars':changed,'count':len(changed)},indent=2))
(P/'score.json').write_text((P/'score_v2.json').read_text());d=build(2);starts=[b['start'] for b in d['bars']];times=[];total=0
for b in d['bars']:times.append(total);total+=b['beats']*60/b['bpm']
def sec(t):
 i=max(0,bisect.bisect_right(starts,t)-1);return times[i]+(t-starts[i])*60/d['bars'][i]['bpm']
def beat(t):
 i=max(0,bisect.bisect_right(times,t)-1);return starts[i]+(t-times[i])*d['bars'][i]['bpm']/60
mp=P.parent/'assets/iowa_flute_C5_B5/mapping_manifest.json';lat={(x['layer'],x['midi']):x['voiced_onset_delay_after_tuning_seconds'] for x in json.loads(mp.read_text())['files']};alignment=[]
for e in d['events']:
 if e['instrument']!='flute':continue
 layer='pp' if e['velocity']<=55 else 'mf';target=sec(e['onset']);end=sec(e['onset']+e['duration']);delay=lat[layer,e['pitch']];trigger=target-delay;assert trigger>=0;e['nominal_onset']=e['onset'];e['onset']=beat(trigger);e['duration']=beat(end)-e['onset'];e['layer']=layer;e['attack_compensated_once']=True
 alignment.append(dict(event_id=e['event_id'],target_seconds=target,trigger_seconds=trigger,delay_seconds=delay,gate_seconds=end-trigger,layer=layer))
 assert .30<=end-target and end-trigger<=1.60
fl=sorted([e for e in d['events'] if e['instrument']=='flute'],key=lambda e:e['onset'])
for a,b in zip(fl,fl[1:]):assert sec(b['onset'])-sec(a['onset']+a['duration'])>=.14-1e-6
(P/'ensemble_score.json').write_text(json.dumps(d,ensure_ascii=False,indent=2))
for inst in ['piano','flute']:
 x={**d,'events':[e for e in d['events'] if e['instrument']==inst],'pedals':d['pedals'] if inst=='piano' else []};(P/f'{inst}_score.json').write_text(json.dumps(x,ensure_ascii=False,indent=2))
(P/'revisions/flute_attack_alignment.json').write_text(json.dumps({'method':'Once-only measured pitch/layer attack advance. No perfect perceptual-sync or listening claim.','events':alignment},indent=2))
print(json.dumps(report));print([json.loads((P/f'exact_diff_v{i}_to_v{i+1}.json').read_text())['count'] for i in range(2)])
