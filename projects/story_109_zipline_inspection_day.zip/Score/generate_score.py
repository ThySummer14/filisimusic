"""109: irregular short-step chamber form with separately composed bow answers."""
from pathlib import Path
import json,difflib,bisect,sys
P=Path(__file__).resolve().parent;sys.path.insert(0,str(P));from composition_data import *
def pitch(s):return 12*(int(s[-1])+1)+{'C':0,'D':2,'E':4,'F':5,'G':7,'A':9,'B':11}[s[0]]+s[1:-1].count('#')-s[1:-1].count('b')
PARAM={'signal':('开工信号',126,86,4.5),'walk':('沿检修步道',126,76,4.5),'call':('空荡的对端',136,90,4.5),'listen':('停机听辨',76,44,3),'reverse':('倒序复核',130,77,4.5),'glide':('空载滑行',138,94,4.5),'land':('落地后',84,49,3)}
def build(level):
 rows=[]
 for sec,hs,lines in GROUPS:
  assert len(hs.split())==len(lines),(sec,len(hs.split()),len(lines))
  rows.extend((sec,h,line) for h,line in zip(hs.split(),lines))
 assert len(rows)==104
 events=[];bars=[];pedals=[];start=0
 for n,(sec,h,line) in enumerate(rows,1):
  for lv,rev,hr in [(1,REV1,HREV1),(2,REV2,HREV2)]:
   if level>=lv:line=rev.get(n,line);h=hr.get(n,h)
  label,bpm,dyn,beats=PARAM[sec];ch=H[h]
  if n in [8,28,44,60,80,96]:bpm-=4
  if n>=101:bpm-=2*(n-100)
  bars.append(dict(bar=n,start=start,beats=beats,bpm=bpm,meter='3/4' if beats==3 else '9/8',meter_numerator=3 if beats==3 else 9,meter_denominator=4 if beats==3 else 8,section=sec,section_title_zh=label,harmony_name=h,harmony=ch,key_region='G Dorian with explicit Eb/D7 inflections',metrical_grouping='2+2+2+3 eighths' if beats==4.5 else 'three spacious quarters',texture='low_voice_solo' if sec=='listen' else 'short_steps_and_bow_answers'))
  def add(p,t,d,v,inst,voice,hand='none'):
   assert 0<=t<t+d<=beats+.00001,(n,t,d,beats)
   events.append(dict(bar=n,onset=round(start+t,6),duration=round(d,6),pitch=p,velocity=int(v),instrument=inst,voice=voice,hand=hand,harmony_name=h,phrase_id=f'{sec}_{(n-1)//5}',role='lead' if voice in ['step_theme','bow_answer'] else 'support',articulation='short_separate_bow' if inst=='cello' else 'shaped_detached_or_sustained',written_value_beats=d))
  at=0;mel=[]
  for i,tok in enumerate(line.split()):
   name,u=tok.split(':');dur=float(u)/2
   if name!='R':
    p=pitch(name);mel.append(p);add(p,at,max(.08,dur-.075),dyn+(4 if at in [0,3] and sec!='listen' else 0)-(4 if i==len(line.split())-1 else 0),'piano','step_theme','left' if sec=='listen' else 'right')
   at+=dur
  assert at==beats,(n,at,beats)
  if sec=='listen':
   if n in [45,50,55]:add(74 if h=='Bb' else 76,2,.55,29,'piano','distant_pin','right')
  elif sec=='land':
   if n not in [100,103]:
    p=ch[0]
    while p>=min(mel):p-=12
    add(p,.1,.8,34,'piano','grounded_step','left')
  else:
   # The 2+2+2+3 grouping is embodied by the written low entries, not metadata only.
   phase=(n-9)%5
   pat=[(0,ch[0],.32),(1,ch[1],.32),(3,ch[2],.52)]
   if phase==1:pat=[(0,ch[0],.4),(2,ch[1],.32),(3,ch[2],.65)]
   if phase==2:pat=[(1,ch[1],.32),(2,ch[0],.32),(3.5,ch[2],.6)]
   if phase==3:pat=[(0,ch[0],.38),(1,ch[2],.38),(2,ch[1],.38)]
   if phase==4:pat=[(0,ch[0],.55),(3,ch[2],.65)]
   if level>=1 and sec=='call':pat=[(0,ch[0],.3),(2,ch[2],.38)] if n%2 else [(1,ch[1],.3),(3,ch[0],.42)]
   if sec=='reverse':pat=[(.5,ch[2],.32),(1.5,ch[1],.32),(3,ch[0],.6)]
   if level>=2 and sec=='glide':pat=[(0,ch[0],.48),(2,ch[1],.38),(3,ch[2],.6)] if n%2 else [(1,ch[1],.38),(3,ch[0],.64)]
   if n in [8,28,44,60,80,92,96]:pat=[(0,ch[0],.5)]
   for t,p,d in pat:
    while p>=min(mel):p-=12
    add(p,t,d,dyn-25,'piano','inspection_footfall','left')
  available=[p for p in range(50,60) if p%12 in {x%12 for x in ch}];assert available
  # Bow answers carry a D-E-G / Bb-A-G contour; harmony-specific notes are intentional.
  notes=[]
  if sec=='signal' and n in [2,6]:notes=[(3,52,.42)]
  elif sec=='walk' and (n-9)%5==3:notes=[(2.3,available[0],.38),(3.75,available[-1],.30)]
  elif sec=='walk' and (n-9)%5==4:notes=[(.6,55,.45)]
  elif sec=='call':notes=[(3.1,available[-1],.43)] if n%2 else [(1.4,available[0],.42)]
  elif sec=='listen' and n in [47,51,55,59]:notes=[(.45,available[0],.55)]
  elif sec=='reverse' and n%5 in [0,1]:notes=[(.55,available[-1],.4),(2.4,available[0],.43)]
  elif sec=='glide' and n%4==1:notes=[(3.0,available[0],.42)]
  elif sec=='land' and n in [98,102]:notes=[(.5,52,.56)]
  if level>=1 and sec=='call':
   notes=[(3.1,available[-1],.40)] if n%2 else [(2.9,available[0],.45)]
  if level>=2 and sec=='glide':
   notes=[(2.15,available[0],.38),(3.65,available[-1],.30)] if n in [87,88,92] else [(3.1,available[0],.4)] if n in [81,85,89,93] else []
  for t,p,body in notes:add(p,t,body*bpm/60,48 if sec in ['listen','land'] else 74 if sec in ['call','glide'] else 64,'cello','bow_answer')
  pedals.append(dict(bar=n,onset=start,controller=64,value=0,instrument='piano'))
  if sec in ['listen','land']:
   pedals += [dict(bar=n,onset=start+.08,controller=64,value=28,instrument='piano'),dict(bar=n,onset=start+1.42,controller=64,value=0,instrument='piano'),dict(bar=n,onset=start+1.6,controller=64,value=24,instrument='piano'),dict(bar=n,onset=start+2.9,controller=64,value=0,instrument='piano')]
  start+=beats
 events.sort(key=lambda e:(e['onset'],e['instrument'],e['pitch']))
 for i,e in enumerate(events):e['event_id']=f'w109-v{level}-{i:04d}'
 return dict(id=109,title='Zipline Inspection Day',title_zh='滑索检修日',version=f'v{level}',bars=bars,events=events,pedals=pedals,total_beats=start,tail_seconds=5,instrument_map={'piano':'piano','cello':'arco'},performance_contract='Original9/8 chamber work; real acoustic samples with short separate cello bows. Human listening pending.')
def projection(d,n):return {'bar':d['bars'][n-1],'events':[{k:v for k,v in e.items() if k!='event_id'} for e in d['events'] if e['bar']==n],'pedals':[e for e in d['pedals'] if e['bar']==n]}
for v in range(3):
 d=build(v);(P/f'score_v{v}.json').write_text(json.dumps(d,ensure_ascii=False,indent=2));report={'version':f'v{v}','bars':104,'events':len(d['events']),'duration_seconds':sum(b['beats']*60/b['bpm'] for b in d['bars'])+5,'human_listening_review':False};(P/f'audit_v{v}.json').write_text(json.dumps(report,indent=2))
 if v:
  old=build(v-1);rows=[];patch=[]
  for n in range(1,105):
   a=projection(old,n);b=projection(d,n)
   if a!=b:
    rows.append({'bar':n,'before':a,'after':b});patch.extend(difflib.unified_diff(json.dumps(a,ensure_ascii=False,indent=2).splitlines(True),json.dumps(b,ensure_ascii=False,indent=2).splitlines(True),f'v{v-1}/bar{n}',f'v{v}/bar{n}'))
  (P/f'exact_diff_v{v-1}_to_v{v}.json').write_text(json.dumps({'count':len(rows),'changed_bars':[r['bar'] for r in rows],'comparison_excludes':['version','event_id'],'changes':rows},ensure_ascii=False,indent=2));(P/f'exact_diff_v{v-1}_to_v{v}.patch').write_text(''.join(patch))
(P/'score.json').write_text((P/'score_v2.json').read_text());d=build(2);starts=[b['start'] for b in d['bars']];times=[];total=0
for b in d['bars']:times.append(total);total+=b['beats']*60/b['bpm']
def sec(t):
 i=max(0,bisect.bisect_right(starts,t)-1);return times[i]+(t-starts[i])*60/d['bars'][i]['bpm']
def beat(t):
 i=max(0,bisect.bisect_right(times,t)-1);return starts[i]+(t-times[i])*d['bars'][i]['bpm']/60
mp=P.parent/'assets/iowa_cello_arco_D3_B3/mapping_manifest.json';lat={(x['layer'],x['midi']):x['coarse_voiced_delay_after_tuning_seconds'] for x in json.loads(mp.read_text())['files']};alignment=[]
for e in d['events']:
 if e['instrument']!='cello':continue
 layer='pp' if e['velocity']<=55 else 'mf';target=sec(e['onset']);end=sec(e['onset']+e['duration']);delay=lat[layer,e['pitch']];trigger=target-delay;assert trigger>=0;e['nominal_onset']=e['onset'];e['onset']=beat(trigger);e['duration']=beat(end)-e['onset'];e['layer']=layer;e['attack_compensated_once']=True
 alignment.append(dict(event_id=e['event_id'],target_seconds=target,trigger_seconds=trigger,delay_seconds=delay,gate_seconds=end-trigger,layer=layer));assert .30-1e-6<=end-target and end-trigger<=1.15
ce=sorted([e for e in d['events'] if e['instrument']=='cello'],key=lambda e:e['onset'])
for a,b in zip(ce,ce[1:]):assert sec(b['onset'])-sec(a['onset']+a['duration'])>=.14-1e-6,(a,b)
(P/'ensemble_score.json').write_text(json.dumps(d,ensure_ascii=False,indent=2))
for inst in ['piano','cello']:
 x={**d,'events':[e for e in d['events'] if e['instrument']==inst],'pedals':d['pedals'] if inst=='piano' else []};(P/f'{inst}_score.json').write_text(json.dumps(x,ensure_ascii=False,indent=2))
(P/'revisions/cello_attack_alignment.json').write_text(json.dumps({'method':'Once-only coarse pitch/layer short-bow onset compensation; not a subjective listening test.','events':alignment},indent=2));print(json.dumps(report))
