#!/usr/bin/env python3
"""Independent JSON readback, no use of composer internals and no audio operations."""
from pathlib import Path
from collections import Counter
import json,hashlib,subprocess,sys
R=Path(__file__).resolve().parent
ROOT_KEYS={'id','title','title_zh','bars','events','pedals','total_beats','tail_seconds'}
BAR_KEYS={'bar','start','beats','bpm','section','meter_numerator','meter_denominator','harmony_name','harmony','role_plan','lead_instrument'}
EVENT_KEYS={'bar','onset','duration','pitch','velocity','voice','instrument'}


def validate(v):
 s=json.loads((R/f'score_v{v}.json').read_text());ph=json.loads((R/f'phrases_v{v}.json').read_text())
 assert set(s)==ROOT_KEYS
 assert s['id']==68 and s['title_zh']=='缝起日食的人' and s['tail_seconds']==4
 assert len(s['bars'])==80 and s['total_beats']==320
 cursor=0; elapsed=0;times={}
 for i,b in enumerate(s['bars'],1):
  assert set(b)==BAR_KEYS and b['bar']==i and b['start']==cursor
  assert b['beats']==4 and b['meter_numerator']==4 and b['meter_denominator']==4
  assert 60<=b['bpm']<=160
  assert b['lead_instrument'] in ['piano','flute']
  assert b['harmony'] and all(isinstance(p,int) and 0<=p<=127 for p in b['harmony'])
  times[i]=elapsed;cursor+=4;elapsed+=240/b['bpm']
 def sec(q):
  if q==320:return elapsed
  b=s['bars'][min(79,int(q//4))]
  return times[b['bar']]+(q-b['start'])*60/b['bpm']
 flute=[];left=[];right=[];all_gates=[]
 for e in s['events']:
  assert set(e)==EVENT_KEYS and 1<=e['bar']<=80
  b=s['bars'][e['bar']-1];o=e['onset']-b['start']
  assert 0<=o<4 and 0<e['duration'] and o+e['duration']<=4+1e-7
  assert isinstance(e['pitch'],int) and 0<=e['pitch']<=127
  assert isinstance(e['velocity'],int) and 1<=e['velocity']<=127
  if e['instrument']=='flute':
   assert e['voice']=='flute' and b['lead_instrument']=='flute'
   assert 72<=e['pitch']<=83
   assert 21<=e['velocity']<=95
   gate=sec(e['onset']+e['duration'])-sec(e['onset'])
   assert gate<=1.35+1e-7
   assert gate+.209<=1.60+1e-7
   all_gates.append(gate);flute.append(e)
  else:
   assert e['instrument']=='piano' and e['voice'] in ['melody','upper_support','bass','accompaniment']
   if e['voice']=='melody':assert b['lead_instrument']=='piano'
   if b['lead_instrument']=='flute':assert e['voice']!='melody'
   (left if e['voice'] in ['bass','accompaniment'] else right).append(e)
 # Nominal voices, key conflicts, and simultaneous finger spans.
 starts=sorted(set(e['onset'] for e in s['events']))
 maxspan={'left':0,'right':0};maxpoly={'left':0,'right':0}
 for t in starts:
  la=[e for e in left if e['onset']<=t<e['onset']+e['duration']-1e-8]
  ra=[e for e in right if e['onset']<=t<e['onset']+e['duration']-1e-8]
  for name,a in [('left',la),('right',ra)]:
   pitches=[e['pitch'] for e in a]
   assert len(pitches)==len(set(pitches)),('same hand key conflict',t,name)
   span=max(pitches)-min(pitches) if pitches else 0
   maxspan[name]=max(maxspan[name],span);maxpoly[name]=max(maxpoly[name],len(pitches))
   assert span<=12,(name,t,span)
   assert len(pitches)<=5
  if la and ra:assert max(e['pitch'] for e in la)<min(e['pitch'] for e in ra),('hand crossing',t)
 # Both piano support voices belong to the stated harmony, except explicitly
 # nonharmonic MELODY suspensions/passing tones; chord dictionaries not inflated.
 assert all(e['pitch'] in s['bars'][e['bar']-1]['harmony'] for e in left)
 assert all(e['pitch'] in s['bars'][e['bar']-1]['harmony'] for e in right if e['voice']=='upper_support')
 for b in s['bars']:
  fg=[e for e in s['events'] if e['bar']==b['bar'] and e['voice'] in ['melody','flute']]
  assert fg
  first=min(fg,key=lambda e:e['onset'])
  assert first['pitch'] in b['harmony'] or (v==2 and b['bar']==79 and first['pitch']==74),('unintended harmonic arrival',b['bar'])
 for a,b in zip(sorted(flute,key=lambda e:e['onset']),sorted(flute,key=lambda e:e['onset'])[1:]):
  assert sec(a['onset']+a['duration'])<=sec(b['onset'])-.209+1e-7,('potential compensated flute overlap',a,b)
 assert len(flute)==30 and len(ph)==10
 phrase_gaps=[];within_gaps=[]
 for i,p in enumerate(ph):
  ev=sorted([e for e in flute if e['bar'] in p['bars']],key=lambda e:e['onset'])
  assert len(ev)==3 and p['layer'] in ['pp','mf']
  lim=(21,55) if p['layer']=='pp' else (56,95)
  assert all(lim[0]<=e['velocity']<=lim[1] for e in ev)
  assert abs(sec(ev[0]['onset'])-p['target_start_seconds'])<1e-7
  assert abs(sec(ev[-1]['onset']+ev[-1]['duration'])-p['nominal_end_seconds'])<1e-7
  for a,b in zip(ev,ev[1:]):within_gaps.append(sec(b['onset'])-sec(a['onset']+a['duration']))
  if i+1<len(ph):
   gap=ph[i+1]['target_start_seconds']-p['nominal_end_seconds'];phrase_gaps.append(gap)
   assert gap>=.85-1e-7
  for e in ev:
   pe=[x for x in s['events'] if x['instrument']=='piano' and x['bar']==e['bar']]
   assert max(x['pitch'] for x in pe)<e['pitch']
 # Every first/third flute pitched arrival has a simultaneous piano chord attack.
 for p in ph:
  ev=sorted([e for e in flute if e['bar'] in p['bars']],key=lambda e:e['onset'])
  for e in [ev[0],ev[-1]]:
   assert any(x['instrument']=='piano' and x['voice']=='upper_support' and x['onset']==e['onset'] for x in s['events'])
 assert all(set(p)=={'onset','value'} and 0<=p['value']<=63 and 0<=p['onset']<=320 for p in s['pedals'])
 assert s['pedals']==sorted(s['pedals'],key=lambda p:p['onset'])
 assert s['pedals'][-1]['value']==0
 # Hand-offs remain separated under worst published attack advance.
 for e in flute:
  trigger=sec(e['onset'])-.209;end=sec(e['onset']+e['duration'])
  for x in s['events']:
   if x['voice']=='melody':
    assert max(trigger,sec(x['onset']))>=min(end,sec(x['onset']+x['duration']))-1e-8
 result=dict(status='PASS',version=v,bars=80,total_beats=320,events=len(s['events']),piano_events=len(s['events'])-30,flute_events=30,score_seconds=round(elapsed,9),with_tail_seconds=round(elapsed+4,9),flute_range=[min(e['pitch'] for e in flute),max(e['pitch'] for e in flute)],nominal_flute_gate_seconds=[round(min(all_gates),9),round(max(all_gates),9)],worst_adjusted_gate_seconds=round(max(all_gates)+.209,9),min_phrase_gap_seconds=round(min(phrase_gaps),9),min_phrase_gap_after_max_advance_seconds=round(min(phrase_gaps)-.209,9),min_intra_phrase_gap_seconds=round(min(within_gaps),9),min_intra_phrase_gap_after_max_advance_seconds=round(min(within_gaps)-.209,9),max_keyheld_hand_span_semitones=maxspan,max_hand_polyphony=maxpoly,foreground_conflicts=0,unintended_harmonic_arrival_conflicts=0,exact_sample_delays_applied=False,audio_rendered=False,human_listening_claim=False,score_sha256=hashlib.sha256((R/f'score_v{v}.json').read_bytes()).hexdigest())
 (R/f'audit_v{v}.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
 return result

results=[validate(v) for v in range(3)]
assert (R/'score.json').read_bytes()==(R/'score_v2.json').read_bytes()
s=json.loads((R/'score_v2.json').read_text());rows=json.loads((R/'flute_entry_intentions.json').read_text());fl=[e for e in s['events'] if e['instrument']=='flute']
assert len(rows)==len(fl)==30
for row,e in zip(rows,fl):
 assert (row['bar'],row['pitch'],row['velocity'],row['target_arrival_quarterbeats'])==(e['bar'],e['pitch'],e['velocity'],e['onset'])
 assert abs(row['nominal_noteoff_quarterbeats']-e['onset']-e['duration'])<1e-7
 assert row['layer']==('pp' if e['velocity']<=55 else 'mf')
changes=json.loads((R/'revision_changes.json').read_text())
assert len(changes)==2
assert all(len(d['changed_bars'])>=20 and d['added_events']+d['removed_events']>=200 for d in changes)
# The return changes every full piano melody bar, instead of looping theme A.
def melody_bar(bar):
 return tuple((round(e['onset']-(bar-1)*4,6),e['duration'],e['pitch']) for e in s['events'] if e['bar']==bar and e['voice']=='melody')
seed_bars={melody_bar(b) for b in range(5,17)}
assert all(melody_bar(b) not in seed_bars for b in list(range(49,65))+list(range(73,81)))
assert not any(p.suffix.lower() in ['.wav','.mp3','.flac','.aiff','.rpp'] for p in R.iterdir())
# Re-run the actual build and prove every generated score/entry file is identical.
repro_paths=[R/f'score_v{v}.json' for v in range(3)]+[R/f'phrases_v{v}.json' for v in range(3)]+[R/'score.json',R/'flute_entry_intentions.json',R/'revision_changes.json',R/'build_manifest.json',R/'form_design.json',R/'thematic_material.json']
before={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in repro_paths}
cp=subprocess.run([sys.executable,str(R/'compose.py')],capture_output=True,text=True,check=True)
after={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in repro_paths}
assert before==after
(R/'reproducibility_check.json').write_text(json.dumps(dict(status='PASS',method='Re-run standard-library compose.py and compare SHA-256 for all twelve generated files',deterministic=True,files=after),ensure_ascii=False,indent=2)+'\n')
(R/'validation_readback.json').write_text(json.dumps(dict(status='PASS',independent_json_readback=True,all_versions=results,score_alias_byte_identical=True,entry_intentions_matched=True,return_bar_copy_count=0,reproducibility='PASS',non_rendered=True,limitation='Structural and timing feasibility only; no sample playback or listening judgment.'),ensure_ascii=False,indent=2)+'\n')
print(json.dumps(results[-1],ensure_ascii=False,indent=2))
