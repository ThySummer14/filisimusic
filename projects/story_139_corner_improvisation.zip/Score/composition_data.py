from copy import deepcopy

def pitch(s):
 return 12*(int(s[-1])+1)+{'C':0,'D':2,'E':4,'F':5,'G':7,'A':9,'B':11}[s[0]]+s[1:-1].count('#')-s[1:-1].count('b')
def decode(line):
 result=[];t=0
 for token in line.split():
  name,units=token.split(':');dur=float(units)/2
  if name!='R':result.append((pitch(name),t,dur))
  t+=dur
 return result,t
class Writer:
 def __init__(self):self.bars=[];self.events=[];self.pedals=[];self.start=0;self.n=0
 def bar(self,name,bpm,beats,h,ch):
  self.n+=1;self.beats=beats;self.bpm=bpm;self.ch=ch
  numerator,denominator=(int(beats*2),8) if beats in (2.5,3.5) else ((6,8) if METER=='6/8' else (int(beats),4))
  self.bars.append(dict(bar=self.n,start=self.start,beats=beats,bpm=bpm,meter_numerator=numerator,meter_denominator=denominator,section=name,harmony_name=h,harmony=ch))
 def add(self,p,t,d,v=72,inst='piano',voice='theme',hand='right',art='detached'):
  if d>0 and t<self.beats:
   self.events.append(dict(bar=self.n,onset=round(self.start+t,6),duration=round(min(d,self.beats-t),6),pitch=int(p),velocity=max(1,min(127,int(v))),instrument=inst,voice=voice,hand=hand if inst=='piano' else 'none',articulation=art))
 def line(self,line,v=80,hand='right',transpose=0):
  notes,total=decode(line);assert abs(total-self.beats)<1e-7,(self.n,total,self.beats,line)
  for p,t,d in notes:self.add(p+transpose,t,max(.11,d-.09),v+(3 if t==0 else 0),hand=hand)
  return notes
 def release(self,amount=0,length=.7):
  self.pedals.append(dict(bar=self.n,onset=self.start,controller=64,value=0,instrument='piano'))
  if amount:
   self.pedals.extend([dict(bar=self.n,onset=self.start+.05,controller=64,value=amount,instrument='piano'),dict(bar=self.n,onset=self.start+length,controller=64,value=0,instrument='piano')])
  self.start+=self.beats
 def result(self,level):
  self.pedals.append(dict(bar=self.n,onset=self.start-.01,controller=64,value=0,instrument='piano'))
  return dict(id=ID,title=TITLE,title_zh=TITLE_ZH,version=f'v{level}',bars=self.bars,events=self.events,pedals=self.pedals,total_beats=self.start,tail_seconds=5,instrument_map=INSTRUMENT_MAP)
def material(level):
 n=0
 for section,bpm,beats,texture,hs,phrase_names in BLOCKS:
  lines=[]
  for pn in phrase_names.split():lines+=P[pn].split('|')
  harmonies=hs.split();assert len(lines)==len(harmonies),(section,len(lines),len(harmonies))
  for h,line in zip(harmonies,lines):
   n+=1
   for lv,rev in [(1,REV1),(2,REV2)]:
    if level>=lv and n in rev:h,line=rev[n]
   yield n,section,bpm,beats,texture,h,line
ID=139;TITLE='An Improvised Dance at the Corner';TITLE_ZH='街角即兴舞';METER='4/4';INSTRUMENT_MAP={'piano':'piano','cello':'pizz'}
RENDERER_NOTES='Two explicit piano lines, sparse cello pizzicato C2–B2 single mf layer. Forms of 5/13/9/16/7/14/11/12/8 bars; 3+3+2 attacks shift through meter changes, no uniform middle hush.'
H={'Db':[37,53,56],'Ab7':[44,54,60],'Bbm':[46,53,61],'Gb':[42,54,58],'Ebm':[39,54,58],'F7':[41,57,63],'Db/F':[41,56,61],'Gbmaj7':[42,53,58],'Cb':[47,54,59],'Ebm7':[39,54,61],'Absus':[44,54,61]}
Q=[
('Db','Db5:1 F5:2 Ab5:1 F5:1 Eb5:1 Db5:2','Db3:3 Ab3:1 F3:2 Eb3:2'),('Ab7','C5:1 Eb5:2 Gb5:1 Ab5:1 Gb5:1 Eb5:2','Ab2:1 Eb3:2 Gb3:1 C4:2 Bb3:2'),('Bbm','F5:1 Bb5:2 Ab5:1 F5:1 Eb5:1 Db5:2','Bb2:2 F3:1 Db4:1 C4:1 Bb3:1 F3:2'),('Gb','Bb5:1 Gb5:1 Db5:1 Eb5:1 Gb5:2 F5:2','Gb3:3 Db3:1 Bb2:2 Db3:2'),('Ebm','Gb5:1 Bb5:2 Eb6:1 Db6:1 Bb5:1 Gb5:2','Eb3:1 Gb3:2 Bb3:1 Db4:2 Bb3:2'),('F7','A5:1 F5:1 Eb5:2 C5:1 A4:1 F4:2','F3:2 C3:1 A2:1 C3:1 Eb3:1 F3:2'),('Bbm','Bb5:2 F5:1 Db5:1 C5:1 Db5:1 F5:2','Bb2:1 Db3:1 F3:1 Ab3:1 Bb3:2 R:2'),('Db/F','Ab5:1 F5:2 Db5:1 Eb5:1 F5:1 Ab5:2','F3:1 Ab3:1 Db4:2 C4:1 Ab3:1 F3:2'),('Gbmaj7','F5:1 Bb5:1 Db6:2 Bb5:1 Gb5:1 F5:2','Gb3:2 Db3:1 Bb2:1 Db3:2 F3:2'),('Cb','Gb5:1 B5:1 Eb6:2 Db6:1 B5:1 Gb5:2','B2:1 Eb3:1 Gb3:2 Bb3:1 Ab3:1 Gb3:2'),('Ebm7','Db6:1 Bb5:1 Gb5:2 F5:1 Eb5:1 Bb4:2','Eb3:1 Gb3:1 Bb3:2 Db4:1 Bb3:1 Gb3:2'),('Absus','Ab5:2 Db6:1 C6:1 Ab5:1 Gb5:1 Eb5:2','Ab2:2 Db3:1 Eb3:1 Gb3:2 Ab3:2'),('Ab7','C6:1 Ab5:1 Gb5:2 Eb5:1 C5:1 R:2','Ab2:1 C3:1 Eb3:2 Gb3:1 Ab3:1 C4:2'),('Db','F5:1 Ab5:1 Db6:2 C6:1 Ab5:1 F5:2','Db3:2 Ab2:1 F2:1 Ab2:1 C3:1 Db3:2'),('Gb','Bb5:2 Gb5:1 Db5:1 Bb4:1 Db5:1 Gb5:2','Gb3:1 Db3:1 Bb2:2 Db3:1 Eb3:1 Gb3:2'),('Ab7','Eb5:1 Ab5:1 C6:2 Bb5:1 Ab5:1 Gb5:2','Ab2:1 Eb3:1 Gb3:2 C4:1 Bb3:1 Ab3:2'),('Db','Db6:2 Ab5:1 F5:1 Eb5:1 Db5:1 Ab4:2','Db3:1 F3:1 Ab3:2 Db4:1 C4:1 Ab3:2')]
Q7=[('Bbm','Bb5:1 F5:1 Db5:2 Eb5:1 F5:2','Bb2:2 F3:1 Db4:1 C4:1 Bb3:2'),('Gb','Gb5:1 Bb5:1 Db6:1 C6:1 Bb5:1 Gb5:2','Gb3:1 Db3:1 Bb2:2 Db3:1 Gb3:2'),('Ebm','Eb5:1 Gb5:1 Bb5:2 Ab5:1 Gb5:2','Eb3:2 Gb3:1 Bb3:1 Db4:1 Bb3:2'),('Ab7','C6:1 Ab5:1 Gb5:1 Eb5:1 C5:1 R:2','Ab2:1 C3:1 Eb3:2 Gb3:1 Ab3:2'),('Db','F5:1 Ab5:1 Db6:2 C6:1 Ab5:2','Db3:2 F3:1 Ab3:1 C4:1 Db4:2')]
Q5=[('Db','Ab5:1 Db6:2 C6:1 Ab5:1 F5:1 Eb5:2 Db5:2','Db3:2 F3:1 Ab3:1 Db4:2 C4:1 Ab3:1 F3:2'),('Gb','Bb5:1 Db6:2 Gb6:1 F6:1 Db6:1 Bb5:2 Gb5:2','Gb3:1 Db3:1 Bb2:2 Db3:1 Gb3:1 Bb3:2 Db4:2'),('Ebm','Gb5:1 Bb5:2 Eb6:1 Db6:1 Bb5:1 Ab5:2 Gb5:2','Eb3:2 Gb3:1 Bb3:1 Db4:2 Bb3:1 Gb3:1 Eb3:2'),('Ab7','C6:1 Eb6:2 Gb6:1 Eb6:1 C6:1 Ab5:2 R:2','Ab2:1 C3:1 Eb3:2 Gb3:1 Ab3:1 C4:2 R:2')]
Q3=[('Bbm','F5:2 Db5:1 Bb4:1 F4:2','Bb2:1 Db3:1 F3:2 Ab3:2'),('Gb','Gb5:2 Db5:1 Bb4:1 Gb4:2','Gb3:1 Db3:1 Bb2:2 Db3:2'),('Ebm','Bb5:1 Gb5:1 Eb5:2 Gb5:2','Eb3:2 Gb3:1 Bb3:1 Db4:2'),('Ab7','C6:1 Ab5:1 Gb5:2 Eb5:2','Ab2:1 Eb3:1 Gb3:2 C4:2'),('Db','F5:2 Ab5:1 Db6:1 R:2','Db3:2 F3:1 Ab3:1 Db4:2')]
S=[('Step_out',112,4,[0,1,2,3,12]),('Make_room',116,4,[0,2,4,5,6,7,8,9,10,11,12,13,16]),('Wrong_foot_right_time',120,3.5,[0,1,2,3,4,2,1,3,4]),('Everybody_has_a_step',118,4,[3,7,13,0,1,2,6,5,4,8,9,10,11,12,15,16]),('One_long_turn',110,5,[0,1,2,3,1,2,3]),('Stay_in_motion',126,4,[13,0,2,4,5,6,7,8,9,10,11,12,15,16]),('Watch_from_the_edge',92,3,[0,1,2,3,4,1,0,2,3,4,3]),('Come_back_in',122,4,[13,7,8,3,4,10,5,6,11,12,15,16]),('A_clean_stop',114,4,[0,1,2,3,4,12,13,16])]
REV1={}
for n,idx in zip(range(28,44),[7,3,0,13,6,2,4,5,8,10,9,11,15,12,16,13]):
 h,r,l=Q[idx];REV1[n]=(h,r,l)
REV2={}
for n,idx in zip(range(76,88),[6,7,13,8,10,4,9,3,11,15,12,16]):
 h,r,l=Q[idx]
 # Exchange the short cell's order inside each bar, preserving an explicitly grounded bass route.
 tok=r.split();first=tok[0];last=next((j for j in range(len(tok)-1,-1,-1) if not tok[j].startswith('R:')),0)
 # Swap pitch identities of the two boundary notes; duration/phrase accents stay authored.
 a,u=tok[0].split(':');b,v=tok[last].split(':');tok[0]=b+':'+u;tok[last]=a+':'+v
 REV2[n]=(h,' '.join(tok),l)
REV2[94]=('Ab7','C6:1 Ab5:1 Gb5:1 Eb5:1 C5:2 R:2','Ab2:1 C3:1 Eb3:2 Gb3:1 Ab3:1 C4:2')
REV2[95]=('Db','Db6:1 Ab5:1 F5:2 Db5:2 R:2','Db3:2 Ab2:1 F2:1 Db2:2 R:2')
def build(level):
 w=Writer();n=0
 for sec,bpm,beats,route in S:
  for idx in route:
   n+=1;pool=Q if beats==4 else Q7 if beats==3.5 else Q5 if beats==5 else Q3;h,r,l=pool[idx]
   for lv,rv in [(1,REV1),(2,REV2)]:
    if level>=lv and n in rv:h,r,l=rv[n]
   ch=H[h];w.bar(sec,bpm,beats,h,ch);v={'Step_out':85,'Make_room':88,'Wrong_foot_right_time':93,'Everybody_has_a_step':87,'One_long_turn':84,'Stay_in_motion':103,'Watch_from_the_edge':71,'Come_back_in':99,'A_clean_stop':94}[sec]
   w.line(r,v,'right');w.line(l,v-16,'left')
   if sec in ('Make_room','Everybody_has_a_step','Stay_in_motion','Come_back_in') and n%3==1:
    w.add(36+ch[0]%12,1.25,.78,72,inst='cello',voice='heel_response',art='pizzicato')
   if sec=='One_long_turn' and n%2:w.add(36+ch[0]%12,3.6,.8,72,inst='cello',voice='turn_lands',art='pizzicato')
   if level>=2 and 76<=n<=87 and n%3==0:
    w.add(36+ch[0]%12,2.75,.78,72,inst='cello',voice='returned_step',art='pizzicato')
   w.release()
 return w.result(level)
