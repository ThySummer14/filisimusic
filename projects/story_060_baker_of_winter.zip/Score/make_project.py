from pathlib import Path
import json,argparse
ap=argparse.ArgumentParser();ap.add_argument('--version',required=True);ap.add_argument('--source-version',default='v2');ap.add_argument('--gain',type=float,default=3.9);ap.add_argument('--pan',type=float,default=-.30);ap.add_argument('--width',type=float,default=.65);ap.add_argument('--end-seconds',type=float);a=ap.parse_args();P=Path(__file__).parent
s=json.loads((P/'score.json').read_text());dur=a.end_seconds or sum(b['beats']*60/b['bpm'] for b in s['bars'])+s['tail_seconds'];out=P/f'revisions/060_baker_{a.version}.rpp'
r=f'''<REAPER_PROJECT 0.1 7.82 1
  SAMPLERATE 44100 0 0
  TEMPO 104 3 4 0
  MASTER_VOLUME 1
  RENDER_FILE "{P}/revisions/060_baker_{a.version}.wav"
  RENDER_FMT 0 2 44100
  RENDER_1X 0
  RENDER_RANGE 0 0 {dur:.10f} 0 1000
  RENDER_STEMS 0
  RENDER_DITHER 0
  <RENDER_CFG
    ZXZhdxgAAA==
  >
'''
t=0;last=None;k=0
for b in s['bars']:
 if b['section']!=last:k+=1;r+=f'  MARKER {k} {t:.8f} "{b["section"]}" 0\n';last=b['section']
 t+=b['beats']*60/b['bpm']
r+=f'''  <TRACK
    NAME "Original60 folk piano | coordinated seven-plus-five phrasing"
    PANMODE 5
    VOLPAN {a.gain} {a.pan} 1 -1 {a.width}
    MAINSEND 1
    <ITEM
      POSITION 0
      LENGTH {dur:.10f}
      VOLPAN 1 0 1 -1
      FADEIN 1 0.003
      FADEOUT 1 0.8
      <SOURCE WAVE
        FILE "piano_stem_{a.source_version}.wav"
      >
    >
  >
>
'''
out.write_text(r)
lua=f'''local tr=reaper.GetTrack(0,0)
assert(reaper.SetMediaTrackInfo_Value(tr,'D_WIDTH',{a.width}))
assert(reaper.SetMediaTrackInfo_Value(tr,'D_PANLAW',1))
reaper.Main_SaveProject(0,false)
local f=assert(io.open({json.dumps(str(P/f'revisions/native_mix_{a.version}.tsv'))},'w'));for _,k in ipairs({{'D_VOL','D_PAN','D_WIDTH','D_PANLAW'}})do f:write(k..'='..reaper.GetMediaTrackInfo_Value(tr,k)..'\\n')end;f:close();reaper.Main_OnCommand(40004,0)
'''
(P/f'configure_{a.version}.lua').write_text(lua);print(out)
