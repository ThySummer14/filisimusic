from copy import deepcopy

def pitch(s):
 return 12*(int(s[-1])+1)+{'C':0,'D':2,'E':4,'F':5,'G':7,'A':9,'B':11}[s[0]]+s[1:-1].count('#')-s[1:-1].count('b')
def decode(line):
 result=[];t=0
 for token in line.split():
  name,units=token.split(':');dur=float(units)/2
  if name!='R':result.append((pitch(name),t,dur))
  t+=dur
 return result,t
class Writer:
 def __init__(self):self.bars=[];self.events=[];self.pedals=[];self.start=0;self.n=0
 def bar(self,name,bpm,beats,h,ch):
  self.n+=1;self.beats=beats;self.bpm=bpm;self.ch=ch
  numerator,denominator=(int(beats*2),8) if beats in (2.5,3.5) else ((6,8) if METER=='6/8' else (int(beats),4))
  self.bars.append(dict(bar=self.n,start=self.start,beats=beats,bpm=bpm,meter_numerator=numerator,meter_denominator=denominator,section=name,harmony_name=h,harmony=ch))
 def add(self,p,t,d,v=72,inst='piano',voice='theme',hand='right',art='detached'):
  if d>0 and t<self.beats:
   self.events.append(dict(bar=self.n,onset=round(self.start+t,6),duration=round(min(d,self.beats-t),6),pitch=int(p),velocity=max(1,min(127,int(v))),instrument=inst,voice=voice,hand=hand if inst=='piano' else 'none',articulation=art))
 def line(self,line,v=80,hand='right',transpose=0):
  notes,total=decode(line);assert abs(total-self.beats)<1e-7,(self.n,total,self.beats,line)
  for p,t,d in notes:self.add(p+transpose,t,max(.11,d-.09),v+(3 if t==0 else 0),hand=hand)
  return notes
 def release(self,amount=0,length=.7):
  self.pedals.append(dict(bar=self.n,onset=self.start,controller=64,value=0,instrument='piano'))
  if amount:
   self.pedals.extend([dict(bar=self.n,onset=self.start+.05,controller=64,value=amount,instrument='piano'),dict(bar=self.n,onset=self.start+length,controller=64,value=0,instrument='piano')])
  self.start+=self.beats
 def result(self,level):
  self.pedals.append(dict(bar=self.n,onset=self.start-.01,controller=64,value=0,instrument='piano'))
  return dict(id=ID,title=TITLE,title_zh=TITLE_ZH,version=f'v{level}',bars=self.bars,events=self.events,pedals=self.pedals,total_beats=self.start,tail_seconds=5,instrument_map=INSTRUMENT_MAP)
def material(level):
 n=0
 for section,bpm,beats,texture,hs,phrase_names in BLOCKS:
  lines=[]
  for pn in phrase_names.split():lines+=P[pn].split('|')
  harmonies=hs.split();assert len(lines)==len(harmonies),(section,len(lines),len(harmonies))
  for h,line in zip(harmonies,lines):
   n+=1
   for lv,rev in [(1,REV1),(2,REV2)]:
    if level>=lv and n in rev:h,line=rev[n]
   yield n,section,bpm,beats,texture,h,line
ID=138;TITLE='Return Lines on the Ice';TITLE_ZH='冰面上的折返线';METER='6/8';INSTRUMENT_MAP={'piano':'piano'}
RENDERER_NOTES='Solo piano independent upper/lower lines. Same three-quarter bar alternates 6/8 and 3/4 accents, with 13/17/9/15/11/18/16/13-bar trajectories. No generic chord accompaniment.'
H={'Bb':[46,53,62],'F':[41,57,60],'Gm':[43,58,62],'Eb':[39,55,58],'Cm':[36,55,63],'D7':[38,54,60],'Bb/D':[38,53,58],'F7':[41,57,63],'Ab':[44,56,60],'Ebmaj7':[39,55,62],'G7':[43,53,59],'Fsus':[41,58,60]}
Q=[
('Bb','F5:1 Bb5:1 D6:2 C6:1 Bb5:1','Bb2:2 D3:1 F3:1 G3:2'),('F','A5:1 C6:1 F6:2 E6:1 C6:1','F3:1 C3:1 A2:2 C3:2'),('Gm','Bb5:1 D6:1 G6:1 F6:1 D6:2','G3:2 D3:1 Bb2:1 D3:2'),('Eb','G5:2 Eb5:1 Bb4:1 G4:2','Eb3:1 G3:1 Bb3:2 C4:2'),('Cm','G5:1 C6:1 Eb6:2 D6:1 C6:1','C3:2 Eb3:1 G3:1 Bb3:2'),('F7','A5:1 G5:1 F5:1 Eb5:1 C5:2','F3:1 A3:1 C4:2 Eb4:2'),('Bb','D6:2 Bb5:1 F5:1 D5:2','Bb2:1 D3:1 F3:1 G3:1 Bb3:2'),('D7','F#5:1 A5:1 C6:1 Bb5:1 A5:2','D3:2 F#3:1 A3:1 C4:2'),('Gm','G5:2 D5:1 Bb4:1 G4:2','G3:1 D3:1 Bb2:1 D3:1 G3:2'),('Eb','Bb5:1 G5:1 Eb5:2 F5:1 G5:1','Eb3:2 Bb2:1 G2:1 Bb2:2'),('Ab','C6:1 Ab5:1 Eb5:2 F5:1 Ab5:1','Ab2:1 C3:1 Eb3:2 G3:2'),('F7','Eb6:1 C6:1 A5:2 G5:1 F5:1','F3:1 C3:1 A2:2 F2:2'),('Bb','D6:1 Bb5:1 F5:2 Bb5:2','Bb2:2 D3:1 F3:1 Bb3:2'),
('Gm','D6:1 G6:1 F6:1 D6:1 Bb5:2','G3:2 Bb3:1 D4:1 C4:2'),('Cm','Eb6:1 C6:1 G5:2 Eb5:2','C3:1 G3:1 Eb3:2 C3:2'),('D7','A5:2 F#5:1 D5:1 C5:2','D3:1 F#3:1 A3:1 C4:1 D4:2'),('Gm','Bb5:1 A5:1 G5:1 F5:1 D5:2','G3:2 D3:1 Bb2:1 G2:2'),('Bb/D','F5:1 Bb5:1 D6:2 C6:1 Bb5:1','D3:1 F3:1 Bb3:2 A3:2'),('Ebmaj7','D6:1 Bb5:1 G5:2 F5:1 Eb5:1','Eb3:1 G3:1 Bb3:2 D4:2'),('Cm','C6:1 G5:1 Eb5:1 D5:1 C5:2','C3:2 G3:1 Eb3:1 C3:2'),('G7','B5:1 G5:1 D5:2 F5:2','G3:1 D3:1 B2:1 D3:1 F3:2'),('Cm','Eb6:1 D6:1 C6:2 G5:2','C3:1 Eb3:1 G3:1 Bb3:1 C4:2'),('Fsus','C6:1 Bb5:1 F5:2 Eb5:2','F3:2 Bb3:1 C4:1 Eb4:2'),('F7','A5:1 C6:1 Eb6:1 D6:1 C6:2','F3:1 A3:1 C4:1 Eb4:1 C4:2'),('Bb','Bb5:2 F5:1 D5:1 Bb4:2','Bb2:1 F3:1 D3:1 C3:1 Bb2:2')]
S=[('First_trace',108,'6/8',[0,1,2,3,4,5,6,7,8,9,10,11,12]),('Outside_edge',116,'6/8',[0,2,1,3,13,14,15,16,17,18,19,20,21,22,23,12,24]),('Across_the_marks',92,'3/4',[6,8,9,14,15,16,19,23,24]),('Long_curve',112,'6/8',[13,17,18,0,2,4,5,6,10,18,19,20,21,22,23]),('Inside_edge',104,'3/4',[8,7,16,19,20,21,9,10,18,23,12]),('Speed_without_hurry',122,'6/8',[0,1,13,14,15,16,17,18,19,20,21,22,23,12,2,3,4,5]),('Cross_your_own_line',110,'6/8',[13,14,15,16,0,2,17,18,19,20,21,22,23,12,24,6]),('Last_complete_curve',102,'6/8',[0,1,2,3,17,18,19,20,21,22,23,12,24])]
REV1={}
for n,idx in zip(range(43,62),[17,18,4,5,12,10,9,14,20,21,22,23,6,7,8,19,15,16,24]):
 h,r,l=Q[idx];# Each selected phrase is rejoined to a new, separately ordered lower continuation.
 lh=Q[[0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18][n-43]][2]
 # Keep the new line's contour but align its pitch content with the target chord when notes would be foreign.
 pcs={x%12 for x in H[h]};parts=[]
 for tok in lh.split():
  name,u=tok.split(':');p=pitch(name);candidates=[x for x in range(p-2,p+3) if x%12 in pcs];q=min(candidates,key=lambda q:abs(q-p)) if candidates else p
  nn=['C','C#','D','Eb','E','F','F#','G','Ab','A','Bb','B'][q%12]+str(q//12-1);parts.append(nn+':'+u)
 REV1[n]=(h,r,' '.join(parts))
REV2={}
for n,idx in zip(range(87,100),[18,17,13,14,20,21,9,10,19,22,23,12,24]):
 h,r,l=Q[idx]
 # Hand exchange is register-separated: lower subject rises one octave; upper subject drops two.
 nr=[];nl=[]
 for tok in l.split():
  name,u=tok.split(':');q=pitch(name)+24;nr.append(['C','C#','D','Eb','E','F','F#','G','Ab','A','Bb','B'][q%12]+str(q//12-1)+':'+u)
 for tok in r.split():
  name,u=tok.split(':');q=pitch(name)-24;nl.append(['C','C#','D','Eb','E','F','F#','G','Ab','A','Bb','B'][q%12]+str(q//12-1)+':'+u)
 REV2[n]=(h,' '.join(nr),' '.join(nl))
REV2[111]=('F7','C6:1 A5:1 F5:1 Eb5:1 C5:2','F3:1 A3:1 C4:1 Eb4:1 C4:2')
REV2[112]=('Bb','Bb5:1 F5:1 D5:1 C5:1 Bb4:2','Bb3:1 F3:1 D3:1 C3:1 Bb2:2')
def build(level):
 w=Writer();n=0
 for sec,bpm,meter,route in S:
  for idx in route:
   n+=1;h,r,l=Q[idx]
   for lv,rv in [(1,REV1),(2,REV2)]:
    if level>=lv and n in rv:h,r,l=rv[n]
   w.bar(sec,bpm,3,h,H[h]);w.bars[-1]['meter_numerator']=6 if meter=='6/8' else 3;w.bars[-1]['meter_denominator']=8 if meter=='6/8' else 4
   v={'First_trace':76,'Outside_edge':83,'Across_the_marks':66,'Long_curve':85,'Inside_edge':75,'Speed_without_hurry':99,'Cross_your_own_line':90,'Last_complete_curve':83}[sec]
   w.line(r,v,'right');w.line(l,v-10,'left');w.release(25 if meter=='3/4' else 0,.65)
 return w.result(level)
