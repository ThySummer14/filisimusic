"""Original interrupted-refrain piano/pizzicato study. Nominal score only."""
from copy import deepcopy
ID=144;TITLE='The Third Blue of the Kiln';TITLE_ZH='陶窑的第三种蓝'
INSTRUMENT_MAP={'piano':'piano','cello':'pizz'}
RENDERER_NOTES='Piano has two independent subjects and selected real dyads; active hand span stays within an octave. Cello pizzicato C2–B2 uses only the mf sample, separated 0.50-second strokes as kiln-tap fragments. Preserve nominal starts. No rendered audio or listening certification.'
H={'Bm9':[47,62,66,69,73],'Em6':[40,55,59,61],'Fsharp7':[42,58,61,64],'Dmaj7':[38,54,57,61],'Gmaj7':[43,59,62,66],'A9':[45,61,64,67,71],'Cshalf':[37,52,55,59],'B7':[47,63,66,69],'E9':[40,56,59,62,66],'Cmaj7':[36,52,55,59],'Gsharpdim':[44,59,62,65],'Amin':[45,60,64],'FsharpSus':[42,59,61,64],'Bopen':[47,66,73],'D7':[38,54,57,60],'Em9':[40,55,59,62,66],'Gminor':[43,58,62]}
STREAMS={'A':('piano','right',60,96,'flame_subject'),'L':('piano','left',31,59,'potter_counting_subject'),'B':('cello','none',36,47,'test_tap_fragment')}
R={
'a':[(0,.35),(.5,.35),(1.25,.6),(2.25,.35),(3,.7)],
'b':[(.25,.4),(1,.35),(1.5,.35),(2,.35),(2.75,.35),(3.5,.35)],
'c':[(0,.2),(.25,.2),(.75,.2),(1,.2),(1.5,.2),(1.75,.2),(2.25,.2),(2.5,.2),(3,.2),(3.25,.2),(3.75,.2)],
'd':[(.5,.65),(1.75,.5),(2.75,.65)],
'e':[(0,.8),(1.25,.4),(2,.6),(3,.65)],
'f':[(.25,.35),(.75,.35),(1.5,.35),(2.25,.35),(2.75,.35),(3.5,.35)],
'l':[(.25,.6),(1.5,.7),(3,.7)],
'm':[(0,.6),(1,.4),(1.75,.7),(3,.55)],
'n':[(.5,.55),(1.25,.45),(2.25,.55),(3.25,.55)],
'o':[(0,.75),(1.5,.6),(2.75,.6)],
'x':[(.5,'pizz'),(2,'pizz')],
'y':[(1,'pizz')],
'z':[(0,'pizz'),(2.25,'pizz')],
'q':[(2.5,'pizz')],'rest':[]}
def section(name,count,bpm,meters,hs,A,L,B,ar,lr,br,dyn,phrase):
 return dict(name=name,count=count,bpm=bpm,meters=meters,harmonies=hs.split(),pitches={k:v.split() for k,v in [('A',A),('L',L),('B',B)]},rhythms={k:v.split() for k,v in [('A',ar),('L',lr),('B',br)]},dyn=dyn,phrase=phrase)
SECTIONS=[
section('Two_labeled_jars',6,92,[4,4,5],
'Bm9 Em6 Fsharp7 Bm9 Dmaj7 Gmaj7',
'F#5 B5 A5 D6 C#6 F#5 E5 G5 F#5 D5 C#5 E5 A5 G5 F#5 D5 B4 F#5',
'B2 D3 F#3 E3 A2 C#3 E3 D3 G3 F#3 E3 C#3 F#3 A3 G3 D3 B2',
'F#2 B2 A2 G2 E2 F#2 D2 C#2',
'a e b d','l m o','y x rest z',71,'6-bar refrain, already interrupted before a square cadence'),
section('The_temperature_refuses_the_card',9,102,[4,5,4,3],
'Em9 A9 Dmaj7 Gmaj7 Cshalf Fsharp7 Bm9 B7 Em6',
'G5 B5 A5 F#5 E5 C#5 E5 G5 F#5 A5 C#6 B5 G5 F#5 E5 D5 C#5 E5 G5 Bb5 A5 F#5 D#5 F#5 A5 G5 E5',
'E3 G3 B3 A3 E3 C#3 D3 F#3 A3 G3 D3 B2 C#3 E3 G3 F#3 C#3 A2 B2 D#3 F#3 E3',
'E2 G2 B2 A2 F#2 D2 G2 E2 C#2 F#2 A2 B2',
'b f d c a','n l m o','x q y rest z',82,'4+5: rising heat cuts into the counting line'),
section('The_refrain_loses_a_corner',10,110,[4,4,5,4],
'Bm9 Dmaj7 E9 A9 D7 Gmaj7 Gminor Cshalf FsharpSus Fsharp7',
'B5 A5 F#5 E5 G#5 B5 D6 C#6 A5 G5 F#5 D5 F#5 A5 C6 B5 G5 Bb5 D6 C#6 A5 G5 E5 C#5 F#5 B5 A5 G#5 F#5',
'B2 F#3 D3 C#3 E3 G#3 B3 A3 E3 C#3 D3 F#3 A3 G3 B3 D4 C#4 G3 E3 F#3',
'B2 A2 F#2 E2 G#2 A2 D2 G2 Bb2 F#2 C#2',
'a c f e b','m n o l','z y x rest y',92,'4+6: same contour, a longer and altered harmonic destination'),
section('The_flame_goes_around_the_vase',11,98,[5,4,3,4],
'Cmaj7 Gmaj7 A9 Dmaj7 Gsharpdim Cshalf Fsharp7 Bm9 E9 Amin Fsharp7',
'E5 G5 B5 A5 F#5 D5 G5 B5 A5 E5 C#5 F#5 A5 C#6 B5 G#5 F5 D5 E5 G5 B5 A5 F#5 D5 C#5 E5 G#5 B5 A5 C6 B5 G#5 F#5',
'C3 G3 E3 B2 D3 G3 A3 E3 C#3 D3 A3 F#3 G#3 D3 F3 E3 C#3 G3 F#3 A3 B3 E3 G#3 A3',
'C2 E2 G2 B2 A2 F#2 D2 G#2 E2 C#2 F#2',
'd b e f a','o l n m','q x y z rest',85,'5+6: oblique side path; the pulse keeps turning'),
section('The_count_is_wrong_by_one',7,116,[4,4,3,5],
'Bm9 Fsharp7 Bm9 Em6 A9 Dmaj7 Fsharp7',
'F#5 B5 A5 D6 C#6 F#5 E5 G5 B5 A5 F#5 D5 C#5 E5 G5 F#5 A5 C#6 B5 A5 G5 F#5',
'B2 D3 F#3 A3 G3 E3 C#3 A2 C#3 E3 G3 F#3 D3 A2 D3 F#3 A3 G3 C#3',
'B2 F#2 A2 G2 E2 C#2 F#2 D2',
'c a f b','n m l','x z rest y',98,'3+4: a displaced return, not a repeated eight-bar chorus'),
section('Blue_drips_toward_black',12,108,[4,5,4,3,4],
'Em9 B7 Em6 Cmaj7 Gmaj7 Gminor D7 Gmaj7 Cshalf Fsharp7 E9 FsharpSus',
'B5 G5 E5 F#5 A5 C6 B5 G5 D#5 F#5 A5 B5 C6 A5 G5 E5 D5 G5 B5 D6 C6 Bb5 G5 F#5 A5 C6 B5 G5 E5 C#5 F#5 A5 C#6 B5 G#5 E5 F#5',
'E3 B3 G3 F#3 D#3 B2 E3 G3 B3 C4 G3 E3 B2 D3 G3 Bb3 F3 D3 A2 D3 F#3 G3 B3 C#4 G3 E3 F#3',
'E2 B2 G2 A2 F#2 D#2 E2 C2 G2 Bb2 D2 F#2',
'f c b c d a','l n o m n','z x y q rest',101,'5+7: the darkest energy is still dancing, not a quiet bridge'),
section('The_third_blue_is_already_inside',13,120,[4,5,4,4,3],
'Bm9 E9 A9 Dmaj7 Gmaj7 D7 Gminor Cmaj7 Cshalf Fsharp7 Bm9 Em9 Fsharp7',
'F#5 B5 D6 C#6 A5 F#5 E5 G#5 B5 D6 C#6 A5 G5 E5 F#5 A5 C#6 E6 D6 B5 G5 A5 C6 D6 Bb5 G5 F5 D5 E5 G5 B5 D6 C#6 G5 E5 F#5 A5 C#6 B5 F#5 D5 E5 G5 B5 A5 F#5',
'B2 D3 F#3 A3 G#3 E3 B2 E3 G#3 B3 A3 C#4 B3 F#3 D3 G3 B3 D4 C4 A3 F#3 G3 Bb3 D4 C4 G3 E3 C#3 E3 G3 F#3 A3 B3 G3 E3 C#3',
'B2 F#2 D2 E2 G#2 A2 C#2 D2 F#2 G2 Bb2 E2 C#2 F#2 A2',
'c f c a b c e','n m n l o','x z y x q rest',109,'4+4+5: longest refrain, broadened by dyads and the moving bass argument'),
section('Open_the_door_without_repainting_it',8,96,[5,4,4,3],
'Gmaj7 Dmaj7 Em6 A9 D7 Gminor FsharpSus Bm9',
'B5 G5 F#5 A5 C#6 B5 A5 F#5 E5 G5 B5 A5 F#5 D5 F#5 A5 C6 Bb5 G5 E5 C#5 F#5 B5 A5 F#5 D5',
'G3 D3 B2 D3 F#3 A3 E3 G3 B3 A3 E3 C#3 D3 F#3 A3 G3 Bb3 D4 C#4 F#3 B2',
'G2 D2 B2 E2 A2 F#2 D2 G2 Bb2 C#2 F#2',
'e b d f a','o n l m','y rest x z',90,'3+5: the last departure keeps the kiln pulse in the left hand'),
section('No_second_firing',5,82,[4,5,4,3,4],
'Em9 Cshalf Fsharp7 Bm9 Bopen',
'G5 E5 B5 A5 G5 E5 C#5 F#5 A5 G#5 F#5 D5 C#5 B4 F#5 B5',
'E3 G3 B3 C#4 G3 E3 F#3 A3 C#4 B3 F#3 D3 B2 F#3 B3',
'E2 C#2 F#2 A2 B2 F#2',
'd e b a','l o m','q y rest',77,'5-bar door-latch coda, complete without a tutti unison')]
REV1=set(range(16,26))|set(range(38,44));REV2=set(range(53,63))|set(range(74,82))
H1={18:'E9',21:'Gminor',24:'FsharpSus',40:'Cshalf',43:'B7'};H2={55:'Cmaj7',59:'Gminor',62:'E9',75:'Cshalf',79:'FsharpSus'}
def midi(s):return 12*(int(s[-1])+1)+{'C':0,'D':2,'E':4,'F':5,'G':7,'A':9,'B':11}[s[0]]+s[1:-1].count('#')-s[1:-1].count('b')
def fit(p,lo,hi):
 while p<lo:p+=12
 while p>hi:p-=12
 return max(lo,min(hi,p))
def woodwind_breathing(s):
 # Schedule real breathing space in seconds; preserve the existing gate length.
 # If a whole note cannot fit after a breath, omit that attack as a written rest.
 bars={b['bar']:b for b in s['bars']};elapsed={};t=0
 for b in s['bars']:elapsed[b['bar']]=t;t+=b['beats']*60/b['bpm']
 changes=[];removed=set()
 for inst in ('clarinet','flute'):
  last_end=-100
  for e in sorted((x for x in s['events'] if x['instrument']==inst),key=lambda x:x['onset']):
   b=bars[e['bar']];scale=60/b['bpm'];gate=e['duration']*scale
   start_sec=elapsed[e['bar']]+(e['onset']-b['start'])*scale
   if gate<.24:
    removed.add(id(e));changes.append(dict(bar=e['bar'],instrument=inst,action='write_rest_instead_of_truncated_short_attack',old_onset=e['onset'],duration_seconds=gate));continue
   need=max(0,last_end+.145-start_sec)
   if need>1e-7:
    new=e['onset']+need/scale
    if new+e['duration']>b['start']+b['beats']-.001:
     removed.add(id(e));changes.append(dict(bar=e['bar'],instrument=inst,action='write_rest_to_preserve_gate_and_breath',old_onset=e['onset'],duration_seconds=gate));continue
    changes.append(dict(bar=e['bar'],instrument=inst,action='delay_entire_note_for_breath',old_onset=e['onset'],new_onset=round(new,6),unchanged_duration=e['duration']))
    e['onset']=round(new,6);start_sec+=need
   last_end=start_sec+gate
 s['events']=[e for e in s['events'] if id(e) not in removed]
 s['woodwind_breathing_edits']=changes
 return s
def harmonic_finish(s):
 # A melodic dissonance is retained only when the next note of that same
 # line resolves by one or two semitones to the actual current harmony.
 # Otherwise correct the local landing, never relabel a collision as style.
 from collections import defaultdict
 groups=defaultdict(list);bars={b['bar']:b for b in s['bars']}
 for e in s['events']:groups[(e['bar'],e['instrument'],e['voice'],e['hand'])].append(e)
 evidence=[]
 for (bn,inst,voice,hand),ee in groups.items():
  ee.sort(key=lambda x:x['onset']);pcs={p%12 for p in bars[bn]['harmony']}
  lo,hi=(60,96) if inst=='piano' and hand=='right' else (31,59) if inst=='piano' else (60,71) if inst=='clarinet' else (72,83) if inst=='flute' else (36,47) if s['instrument_map'].get('cello')=='pizz' else (50,59)
  for i in range(len(ee)-1,-1,-1):
   e=ee[i];p=e['pitch']
   if p%12 in pcs:continue
   nx=ee[i+1] if i+1<len(ee) else None
   resolved=nx and nx['pitch']%12 in pcs and 1<=abs(nx['pitch']-p)<=2
   if resolved:
    evidence.append(dict(bar=bn,instrument=inst,voice=voice,harmony=bars[bn]['harmony_name'],pitch=p,onset=e['onset'],resolution_pitch=nx['pitch'],resolution_onset=nx['onset'],classification='explicit stepwise appoggiatura, neighbor or passing tone; not a chord member'))
   else:
    cc=[q for q in range(lo,hi+1) if q%12 in pcs]
    e['pitch']=min(cc,key=lambda q:(abs(q-p),q))
 s['intentional_nonchord_tones']=sorted(evidence,key=lambda x:(x['bar'],x['onset'],x['instrument']))
 s['harmonic_review_scope']='Each remaining non-chord event resolves by step to a chord member in its own line within the same bar. This is symbolic voice-leading evidence, not an audio quality claim.'
 return s
def voiced_dyads(s):
 extra=[]
 for bn in [19,23,39,42,56,58,60,63,65,67,69,77,80]:
  b=s['bars'][bn-1];es=[e for e in s['events'] if e['bar']==bn and e['instrument']=='piano' and e['hand']=='right']
  if not es:continue
  e=es[-1];p=e['pitch'];pcs={x%12 for x in b['harmony']};candidates=[q for q in range(p+3,min(96,p+8)+1) if q%12 in pcs]
  if candidates:
   x=deepcopy(e);x['pitch']=candidates[0];x['voice']='flame_dyad_extension';x['velocity']-=8;extra.append(x)
 for bn in [55,60,66,71,81]:
  pcs={x%12 for x in s['bars'][bn-1]['harmony']}
  es=[e for e in s['events'] if e['bar']==bn and e['instrument']=='piano' and e['hand']=='left' and e['pitch']%12 in pcs]
  if es and es[0]['pitch']>=43:
   x=deepcopy(es[0]);x['pitch']-=12;x['voice']='counting_octave_punctuation';x['velocity']-=7;extra.append(x)
 s['events']+=extra;return s

def build(level):
 bars=[];events=[];pedals=[];start=0;n=0;phrase_map=[]
 for si,s in enumerate(SECTIONS):
  cur={k:0 for k in STREAMS};first=n+1
  for j in range(s['count']):
   n+=1;beats=s['meters'][j%len(s['meters'])];bpm=s['bpm'];h=s['harmonies'][j%len(s['harmonies'])];r1=level>=1 and n in REV1;r2=level>=2 and n in REV2
   if r1:h=H1.get(n,h)
   if r2:h=H2.get(n,h)
   bars.append(dict(bar=n,start=start,beats=beats,bpm=bpm,meter_numerator=int(beats),meter_denominator=4,section=s['name'],harmony_name=h,harmony=H[h]))
   for key,(inst,hand,lo,hi,voice) in STREAMS.items():
    cells=deepcopy(R[s['rhythms'][key][j%len(s['rhythms'][key])]])
    if r1 and key=='A':cells=deepcopy(R['f' if j%3 else 'e'])
    if r1 and key=='L':cells=[(.25,.55),(1.25,.55),(2.25,.55),(3.25,.55)]
    if r2 and key=='A':cells=deepcopy(R['c' if n<64 else 'd'])
    if r2 and key=='B':cells=[(.25,'pizz'),(1.75,'pizz')]
    if beats==5 and key in ('A','L'):cells.append((4,.65 if key=='L' else .4))
    for k,(t,dur) in enumerate(cells):
     if t>=beats-.05:continue
     if dur=='pizz':
      dur=.50*bpm/60
      if beats-t-.025<.3*bpm/60:continue
     dur=min(dur,beats-t-.025);p=midi(s['pitches'][key][cur[key]%len(s['pitches'][key])]);cur[key]+=1
     if r1 and key=='A':p+=(-2 if k%3==0 else 1)
     if r1 and key=='L':p=[47,50,54,52,45,49,52,50,55,54,52,49][(cur[key]+j)%12]
     if r2 and key=='A':p+=(12 if n<64 and k%5==0 else -12 if n>=74 and k==0 else 0)
     if r2 and key=='B':p=[42,47,45,43,40,42,38,37][(cur[key]+j)%8]
     p=fit(p,lo,hi)
     if k==0 or k==len(cells)-1:
      cc=[q for q in range(lo,hi+1) if q%12 in {z%12 for z in H[h]}];p=min(cc,key=lambda q:(abs(q-p),q))
     if key=='L' and n==16:p=[48,47,50,54][min(k,3)]
     if key=='L' and n==55:p=[54,52,55,59][min(k,3)]
     if key=='B' and n==75:p=[38,37][min(k,1)]
     vv=72 if inst=='cello' else s['dyn']+([4,-2,1,-3][k%4])-(14 if key=='L' else 0)
     events.append(dict(bar=n,onset=round(start+t,6),duration=round(dur,6),pitch=int(p),velocity=int(max(1,min(127,vv))),instrument=inst,voice=voice,hand=hand,articulation='pizzicato' if inst=='cello' else 'detached'))
   pedals.append(dict(bar=n,onset=start,controller=64,value=0,instrument='piano'))
   if si in (3,7) and j in (0,4):pedals.extend([dict(bar=n,onset=start+.08,controller=64,value=32,instrument='piano'),dict(bar=n,onset=start+.85,controller=64,value=0,instrument='piano')])
   start+=beats
  phrase_map.append(dict(first_bar=first,last_bar=n,design=s['phrase'],independent_subjects=['flame_subject','potter_counting_subject']))
 pedals.append(dict(bar=n,onset=start-.01,controller=64,value=0,instrument='piano'))
 return voiced_dyads(harmonic_finish(woodwind_breathing(dict(id=ID,title=TITLE,title_zh=TITLE_ZH,version=f'v{level}',bars=bars,events=events,pedals=pedals,total_beats=start,tail_seconds=5,instrument_map=INSTRUMENT_MAP,phrase_map=phrase_map))))
