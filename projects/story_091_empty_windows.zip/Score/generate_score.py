#!/usr/bin/env python3
"""Work 091: deterministic original symbolic solo-piano score, standard library only.
No audio or DSP. All score times are absolute quarter-note beats.
"""
import argparse
import difflib
import hashlib
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parent
PCS={'C':0,'D':2,'E':4,'F':5,'G':7,'A':9,'B':11}
def pitch(s):return 12*(int(s[-1])+1)+PCS[s[0]]+s[1:-1].count('#')-s[1:-1].count('b')
def line(text):
    out=[(pitch(x.split(':')[0]),float(x.split(':')[1])) for x in text.split()]
    assert sum(w for _,w in out)==4,text
    return out

# Sixty-four individually authored bars. The opening fourth and its folded
# descent, not a pitch generator or stock arpeggio, provide the thematic thread.
MELODY=[
 'F#4:1 B4:.5 A4:.5 F#4:1 D4:1',
 'E4:1 F#4:.5 A4:.5 F#4:1 E4:1',
 'F#4:.5 G4:.5 B4:1 A4:.5 F#4:1.5',
 'E4:1 C#4:.5 D4:.5 C#4:2',
 'D4:1 F#4:.5 A4:.5 B4:1 F#4:1',
 'G4:1 F#4:.5 E4:.5 D4:1 E4:1',
 'E4:.5 G4:.5 F#4:1 E4:1 C#4:1',
 'A#3:1 C#4:.5 E4:.5 F#4:2',
 'F#4:1 B4:.5 C#5:.5 D5:1 B4:1',
 'A4:1 F#4:.5 E4:.5 F#4:2',
 'G4:.5 B4:.5 A4:1 F#4:1 E4:1',
 'F#4:1 E4:.5 C#4:.5 A#3:2',
 'D4:1 F#4:1 A4:.5 G4:.5 F#4:1',
 'E4:1 G4:.5 F#4:.5 D4:2',
 'C#4:.5 E4:.5 F#4:1 E4:.5 C#4:1.5',
 'D4:1 C#4:.5 B3:.5 F#4:1 B3:1',
 'D4:1 G4:.5 F#4:.5 E4:1 D4:1',
 'C#4:.5 E4:.5 A4:1 G4:1 E4:1',
 'F#4:1 A4:.5 G4:.5 F#4:.5 D4:1.5',
 'E4:1 D4:.5 C#4:.5 B3:2',
 'E4:.5 F#4:.5 G4:1 B4:1 A4:1',
 'A4:1 G4:.5 F#4:.5 E4:1 D4:1',
 'C#4:1 E4:.5 F#4:.5 G4:1 E4:1',
 'E4:1 C#4:1 A3:1 C#4:1',
 'F#4:1 A4:.5 B4:.5 D5:1 A4:1',
 'B4:1 D5:.5 C#5:.5 A4:1 F#4:1',
 'G4:1 B4:.5 A4:.5 G4:1 E4:1',
 'F#4:1 E4:.5 D4:.5 C#4:2',
 'A4:.5 D5:1.5 E5:.5 D5:.5 A4:1',
 'F#5:1 E5:.5 D5:.5 B4:1 A4:1',
 'G4:.5 A4:.5 B4:1 D5:1 B4:1',
 'A4:1 F#4:.5 E4:.5 D4:2',
 'F#3:1 B3:.5 A3:.5 F#3:1 D3:1',
 'E3:1 F#3:.5 A3:.5 B3:1 F#3:1',
 'G3:.5 B3:.5 D4:1 B3:1 G3:1',
 'F#3:1 E3:.5 D3:.5 E3:2',
 'D3:1 F#3:.5 A3:.5 B3:1 A3:1',
 'G3:1 B3:.5 A3:.5 F#3:1 E3:1',
 'E3:1 G3:.5 F#3:.5 E3:1 C#3:1',
 'C#3:1 E3:.5 F#3:.5 A#3:1 F#3:1',
 'F#4:1 B4:.5 A4:.5 F#4:1 D4:1',
 'E4:.5 F#4:.5 A4:1 C#5:1 A4:1',
 'B4:1 D5:.5 C#5:.5 B4:1 G4:1',
 'A4:1 G4:.5 F#4:.5 E4:1 C#4:1',
 'D4:.5 F#4:.5 B4:1 A4:1 F#4:1',
 'G4:1 B4:.5 A4:.5 G4:1 E4:1',
 'F#4:1 E4:.5 C#4:.5 E4:.5 F#4:1.5',
 'D4:1 C#4:.5 B3:.5 F#4:1 B3:1',
 'F#4:1 B4:.5 A4:.5 F#4:1 D4:1',
 'E4:1 F#4:1 A4:.5 F#4:.5 E4:1',
 'D4:1 F#4:.5 E4:.5 D4:1 C#4:1',
 'C#4:1 A#3:1 C#4:1 F#4:1',
 'F#4:1 B4:1 A4:.5 F#4:.5 D4:1',
 'E4:1 G4:.5 F#4:.5 E4:.5 D4:1.5',
 'D4:.5 F#4:.5 A4:1 G4:1 F#4:1',
 'E4:1 C#4:.5 E4:.5 F#4:2',
 'F#4:1 D4:1 E4:.5 F#4:.5 B4:1',
 'A4:1 F#4:.5 E4:.5 D4:2',
 'G4:1 E4:.5 D4:.5 C#4:1 E4:1',
 'F#4:1 E4:.5 C#4:.5 A#3:2',
 'B3:1 D4:.5 F#4:.5 D4:2',
 'E4:1 G4:.5 F#4:.5 E4:1 C#4:1',
 'C#4:1 E4:.5 F#4:.5 A#3:2',
 'B3:1 D4:1 B3:2',
]
# Actual support voicings. Every grip is octave-contained.
HARMONIES={
 'Bm':[47,50,54], 'Bm/F#':[42,47,50], 'Bm/D':[50,54,59],
 'Bm7':[47,50,54,57], 'Bm(add9)':[47,49,50,54],
 'D':[50,54,57], 'D/F#':[42,45,50], 'D/A':[45,50,54],
 'Dmaj7':[50,54,57,61], 'D6':[50,54,57,59],
 'A':[45,49,52], 'A/E':[40,45,49], 'A7':[45,49,52,55],
 'A7/C#':[49,52,55,57], 'A7/E':[40,45,49,55],
 'G':[43,47,50], 'G/B':[47,50,55], 'Gmaj7':[43,47,50,54],
 'Em':[40,43,47], 'Em/G':[43,47,52], 'Em7':[40,43,47,50],
 'C#halfDim':[49,52,55,59], 'C#dim/E':[40,43,49],
 'F#':[42,46,49], 'F#7':[42,46,49,52],
 'F#7/C#':[49,52,54,58], 'F#7sus4':[42,47,49,52],
}
# Avoid the spread-thirteenth E-bass seventh; retain its inversion in one octave.
HARMONIES['A7/E']=[40,43,45,49]
HARM=[
 'Bm','A/E','Gmaj7','F#7/C#','Bm/D','Em/G','C#halfDim','F#7',
 'Bm','D/A','Em7','F#7','Bm/D','G','F#7sus4','Bm',
 'G','A7','D/F#','Bm/F#','Em','G','A7/C#','A',
 'D','Bm/D','Em/G','A7','D','Bm/D','Gmaj7','D/A',
 'Bm','D','G','A7','Bm','Em7','C#halfDim','F#7',
 'Bm','A7','G/B','F#7','Bm/D','Em/G','F#7sus4','Bm',
 'Bm','A/E','G','F#7','Bm','Em','D/A','F#7',
 'Bm/D','G','C#halfDim','F#7','Bm','Em/G','F#7','Bm',
]
V1_MELODY={
 17:'D4:1.5 G4:.5 F#4:.5 E4:.5 D4:1',
 18:'C#4:1 E4:.5 A4:.5 G4:1 E4:1',
 19:'F#4:.5 A4:1.5 G4:.5 F#4:.5 D4:1',
 20:'E4:.5 D4:.5 C#4:1 B3:1 D4:1',
 21:'E4:1 G4:.5 B4:.5 A4:1 G4:1',
 22:'F#4:1 A4:.5 G4:.5 E4:1 D4:1',
 23:'E4:1 C#4:.5 D4:.5 E4:.5 G4:1.5',
 24:'G4:1 E4:.5 C#4:.5 A3:1 C#4:1',
 25:'F#4:1.5 A4:.5 B4:.5 D5:.5 A4:1',
 26:'B4:1 D5:.5 C#5:.5 A4:.5 F#4:1.5',
 27:'G4:.5 B4:1.5 A4:.5 G4:.5 E4:1',
 28:'E4:1 G4:.5 F#4:.5 E4:1 C#4:1',
 29:'A4:1 D5:.5 E5:.5 F#5:1 D5:1',
 30:'E5:1 D5:.5 B4:.5 A4:.5 B4:1.5',
 31:'B4:1 D5:.5 C#5:.5 B4:1 G4:1',
 32:'A4:1 F#4:.5 E4:.5 D4:1 F#4:1',
 33:'F#3:1 B3:.5 A3:.5 F#3:.5 D3:1.5',
 34:'D3:1 F#3:.5 A3:.5 B3:1 F#3:1',
 35:'G3:1 B3:.5 D4:.5 B3:1 A3:1',
 36:'G3:.5 F#3:.5 E3:1 D3:.5 E3:1.5',
 37:'D3:.5 F#3:.5 A3:1 B3:.5 A3:1.5',
 38:'G3:1 B3:.5 A3:.5 F#3:.5 E3:1.5',
 39:'E3:.5 G3:.5 F#3:1 E3:.5 C#3:1.5',
 40:'C#3:1 E3:.5 F#3:.5 A#3:.5 F#3:1.5',
}
V1_HARM={18:'A7/E',20:'Bm',22:'D/F#',24:'A7',26:'D6',28:'A7/C#',30:'Bm7',32:'D/F#',34:'D6',36:'A7/E',37:'Bm/D',38:'Em/G'}
V2_MELODY={
 41:'F#4:1.5 B4:.5 A4:.5 F#4:.5 D4:1',
 42:'E4:1 A4:.5 C#5:.5 B4:.5 A4:1.5',
 43:'B4:1 D5:.5 E5:.5 D5:1 B4:1',
 44:'A#4:1 C#5:.5 B4:.5 F#4:2',
 45:'F#4:1 B4:.5 D5:.5 C#5:1 B4:1',
 46:'B4:1 G4:.5 F#4:.5 E4:1 G4:1',
 47:'F#4:.5 A#4:.5 C#5:1 B4:.5 A#4:1.5',
 48:'B4:1 F#4:.5 E4:.5 D4:1 F#4:1',
 49:'F#4:1.5 B4:.5 A4:.5 F#4:.5 D4:1',
 50:'D4:1 F#4:.5 A4:.5 B4:1 F#4:1',
 51:'E4:1 G4:.5 F#4:.5 E4:1 C#4:1',
 52:'A#3:1 C#4:.5 E4:.5 F#4:2',
 53:'F#4:1 B4:.5 A4:.5 F#4:.5 D4:1.5',
 54:'G4:1 F#4:.5 E4:.5 D4:.5 E4:1.5',
 55:'F#4:1 A4:.5 G4:.5 F#4:1 D4:1',
 56:'E4:1 C#4:.5 A#3:.5 C#4:1 F#4:1',
 57:'D4:1 F#4:.5 B4:.5 A4:.5 F#4:1.5',
 58:'G4:1 E4:.5 D4:.5 B3:2',
 59:'C#4:1 E4:.5 G4:.5 F#4:1 E4:1',
 60:'F#4:1 E4:.5 C#4:.5 A#3:2',
 61:'B3:1 D4:.5 F#4:.5 D4:1 B3:1',
 62:'E4:1 G4:.5 F#4:.5 E4:1 D4:1',
 63:'C#4:1 E4:.5 F#4:.5 A#3:1 C#4:1',
 64:'B3:1 D4:.5 F#4:.5 B3:2',
}
V2_HARM={41:'Bm(add9)',42:'A7/C#',43:'Gmaj7',44:'F#7',45:'Bm/D',46:'Em/G',47:'F#7',48:'Bm',50:'Bm/D',51:'C#halfDim',54:'Em/G',55:'D/F#',57:'Bm/D',58:'Em/G',59:'C#halfDim',61:'Bm',62:'Em/G'}
SECTIONS=[(1,16,'A','早班钥匙与第一扇窗','B minor'),(17,24,'B','百叶帘留出的窄光','B minor / A dominant'),(25,32,'C','在街对面等待反光','D major'),(33,40,'D','从室内重新取景','B minor / D major'),(41,48,'E','接触印样与重定边框','B minor'),(49,52,'Solo','黑布下的一次确认','B minor'),(53,64,'Coda','装入透明袋的照片','B minor')]
LABELS=['钥匙按营业次序排好','门框内的折返','第二扇玻璃里的公交车','用窄边裁掉招牌','帘片调到同一角度','门口测光后过街','反光移到窗框右侧','保留没有拉齐的帘角','从屋里接过同一条线','让台面低于画面边缘','在接触印样上移动纸框','红铅笔停在第四格','黑布下保留一条轮廓','重印后放回原来的次序','给装裱留出白边','袋口还没压平']
TEMPI=[75,76,77,80,77,79,74,71]

def dumps(x):return json.dumps(x,ensure_ascii=False,indent=2)+'\n'
def save(root,name,x):(root/name).write_text(dumps(x),encoding='utf-8')
def sec(bars,t):return sum(min(max(t-b['start'],0),b['beats'])*60/b['bpm'] for b in bars)
def fingermap(keys,hand):
    fs={1:[3],2:[1,5],3:[1,3,5],4:[1,2,4,5],5:[1,2,3,4,5]}[len(keys)]
    return dict(zip(keys,fs if hand=='right' else fs[::-1]))

def compose(version):
    ms=list(MELODY);hs=list(HARM)
    for stage in range(1,version+1):
        for b,m in (V1_MELODY if stage==1 else V2_MELODY).items():ms[b-1]=m
        for b,h in (V1_HARM if stage==1 else V2_HARM).items():hs[b-1]=h
    bars=[];events=[];pedals=[];plans=[]
    for n in range(1,65):
        scene=next(row for row in SECTIONS if row[0]<=n<=row[1]);start=float((n-1)*4)
        leadhand='left' if 33<=n<=40 else 'right';supporthand='right' if leadhand=='left' else 'left'
        exposed=49<=n<=(52 if version>=2 else 50)
        bpm=TEMPI[(n-1)//8]+[0,1,0,-1][(n-1)%4]
        if n>=61:bpm={61:70,62:68,63:66,64:62}[n]
        chord=HARMONIES[hs[n-1]]
        bar={'bar':n,'start':start,'beats':4.0,'bpm':bpm,'meter':'4/4','meter_numerator':4,'meter_denominator':4,
             'section':scene[2],'section_title_zh':scene[3],'harmony_name':hs[n-1],'harmony':chord,
             'lead_instrument':'piano','lead_hand':leadhand,'key_region':scene[4],'phrase_id':f'P{(n-1)//4+1:02d}',
             'phrase_position':(n-1)%4+1,'metrical_grouping':'2+2','texture':'exposed_single_line' if exposed else 'singing_line_with_sustained_shells',
             'role_plan':'One cantabile foreground. Sustained chord shells and delayed inner tones share its harmonic arrivals.'}
        bars.append(bar);m=line(ms[n-1]);leadkeys=sorted({p for p,w in m})
        # The exchanged part places quiet sustained chord shells above the LH song.
        skeys=sorted(set(p+24 for p in chord)) if supporthand=='right' else list(chord)
        if supporthand=='right':
            # Close the inversion into a coherent treble band; never isolated pings.
            skeys=sorted({p+12 if p<64 else p-12 if p>77 else p for p in skeys})
        if exposed:skeys=[]
        keysbyhand={leadhand:leadkeys,supporthand:skeys};maps={h:fingermap(ks,h) for h,ks in keysbyhand.items() if ks}
        for h,ks in keysbyhand.items():
            if ks:
                assert len(ks)<=5 and max(ks)-min(ks)<=12,(version,n,h,ks)
                plans.append({'bar':n,'hand':h,'position_id':f'{h[0].upper()}-b{n:02d}','range':[min(ks),max(ks)],
                    'pitch_finger_map':{str(k):maps[h][k] for k in ks},'active':True,
                    'within_position_method':'Ordered distinct fingers; all keys lie inside one octave. Within-position changes do not imply translation.',
                    'next_position_method':'Release every physical key before a changed grip; pedal resonance is separate.'})
            else:plans.append({'bar':n,'hand':h,'position_id':f'{h[0].upper()}-b{n:02d}','range':None,'pitch_finger_map':{},'active':False,'within_position_method':'Hand rests during exposed monody.','next_position_method':'No physical keys held.'})
        dyn=[63,65,62,67,63,72,60,57][(n-1)//8]
        if exposed:dyn=59
        if n>=61:dyn={61:56,62:54,63:52,64:49}[n]
        def add(hand,voice,offset,duration,p,vel,written,art):
            ks=keysbyhand[hand];fmap=maps[hand]
            events.append({'bar':n,'onset':round(start+offset,6),'duration':round(duration,6),'pitch':p,'velocity':vel,
                'instrument':'piano','voice':voice,'hand':hand,'role':'lead' if voice=='melody' else 'support',
                'phrase_id':f'P{(n-1)//4+1:02d}_piano','phrase_label':LABELS[(n-1)//4],
                'event_id':f'w91-b{n:02d}-{voice}-{len([e for e in events if e["bar"]==n and e["voice"]==voice])+1:02d}',
                'harmonic_function':'chord_tone' if p%12 in {q%12 for q in chord} else 'melodic_nonchord_tone',
                'written_value_beats':written,'articulation':art,'hand_position_id':f'{hand[0].upper()}-b{n:02d}',
                'hand_position_range':[min(ks),max(ks)],'position_keys':ks,'finger':fmap[p],
                'fingering_intent':'Distinct ordered fingers in the declared grip; no thumb crossing or hidden finger substitution.'})
        offset=0
        for i,(p,w) in enumerate(m):
            last=i==len(m)-1
            release=0 if n==64 and last else .40 if last else .055
            # The two octave lead handovers receive a visibly sufficient release.
            if n in (32,40) and last:release=.46
            if exposed and last:release=.26
            gate=w-release
            vel=dyn+[0,3,1,-1,-3][i%5]
            add(leadhand,'melody',offset,gate,p,vel,w,'cantabile_connected_finger_release')
            offset+=w
        if skeys:
            low,high=skeys[0],skeys[-1];middle=skeys[1:-1]
            supportvel=dyn-(24 if supporthand=='right' else 21)
            style=(n-1)%4
            # Harmonic shells stay in one place. Nonperiodic inner entries make
            # the accompaniment breathe with the sentence, not an arpeggio loop.
            split=(n in (4,8,12,20,24,28,36,44,48,56,60,63))
            if version>=1 and n in (17,19,25,27,33,35,37,39):split=True
            if version>=2 and n in (41,43,45,47,53,55,57,59):split=True
            if n==64:
                for p in skeys:add(supporthand,'cadential_harmony',0,4,p,supportvel,4,'settled_tonic_hold')
            elif split:
                # Two quiet harmonic arrivals; neither is a foreground response.
                for off,gate in [(0,1.72),(2,1.56)]:
                    for p in (low,high):add(supporthand,'harmonic_shell',off,gate,p,supportvel+(1 if off==0 else -2),2,'soft_rearticulated_shell')
                for i,p in enumerate(middle):
                    off=2 if i==0 else 2.75
                    add(supporthand,'inner_support',off,3.56-off,p,supportvel-4,4-off,'quiet_shared_harmonic_arrival')
            else:
                for p in (low,high):add(supporthand,'harmonic_shell',0,3.56,p,supportvel,4,'sustained_quiet_shell')
                offsets=[1.5,2.5] if style in (0,2) else [.75,2.25]
                for i,p in enumerate(middle):
                    off=offsets[i];add(supporthand,'inner_support',off,3.56-off,p,supportvel-4,4-off,'quiet_shared_harmonic_arrival')
        # The single line is dry so its exposed physical shape is genuine.
        points=[(0,0)] if exposed else [(0,0),(.09,44 if supporthand=='left' else 37),(3.91,0)]
        if n in (24,28,44,60,63) and not exposed:points=[(0,0),(.09,40),(1.86,0),(2.10,36),(3.91,0)]
        if n==64:points=[(0,0),(.09,40),(4,0)]
        for off,val in points:pedals.append({'bar':n,'onset':round(start+off,6),'controller':64,'value':val,'instrument':'piano'})
    events.sort(key=lambda e:(e['onset'],e['hand'],e['pitch'],e['voice']))
    for e in events:
        e['target_on_beats']=e['onset'];e['target_off_beats']=round(e['onset']+e['duration'],6)
        e['target_on_seconds']=round(sec(bars,e['onset']),6);e['target_off_seconds']=round(sec(bars,e['target_off_beats']),6)
    phrases=[]
    for i,label in enumerate(LABELS):
        pid=f'P{i+1:02d}_piano';es=[e for e in events if e['phrase_id']==pid];a=min(e['onset'] for e in es);b=max(e['target_off_beats'] for e in es)
        phrases.append({'phrase_id':pid,'instrument':'piano','phrase_label':label,'first_bar':i*4+1,'last_bar':i*4+4,
            'section':bars[i*4]['section'],'role':'lead_and_support' if any(e['role']=='support' for e in es) else 'lead',
            'layer':'not_applicable','layers_used':[],'roles_used':sorted({e['role'] for e in es}),'voices_used':sorted({e['voice'] for e in es}),
            'target_on_beats':a,'target_off_beats':b,'target_on_seconds':round(sec(bars,a),6),'target_off_seconds':round(sec(bars,b),6),
            'timing_intent':'Four-bar sentence with connected notes; quarter-note BPM; one melody shared between hands at the two scored handovers.'})
    return {'id':91,'title':'The Photographer of Empty Windows','title_zh':'空窗摄影师','version':f'v{version}',
      'instrumentation':['natural_acoustic_piano'],'bars':bars,'events':events,'phrases':phrases,'pedals':pedals,
      'total_beats':256.0,'tail_seconds':6.0,'hand_position_plan':plans,
      'performance_contract':{'audio_status':'Symbolic only; no audio, DSP, downloads, installs or listening.',
       'beat_unit':'Absolute quarter-note beats. Each 4/4 bar contains four beats; tempo is quarter-note BPM.',
       'piano_instrument':'Solo natural acoustic piano. Source realism and audible balance await later integration.',
       'maximum_held_span_semitones':12,'same_key_overlaps':'Forbidden across all voices and both hands.',
       'position_transfer_rule':'Greater of actual held-grip edge and declared position-edge travel. Whole-hand shifts above four semitones require 75 ms plus 12 ms per additional semitone after the latest physical key release; every changed position receives at least 75 ms.',
       'finger_plan':'At most five distinct pitches in an ordered octave-contained grip; explicit fingers and positions distinguish melody from translation. No hidden crossing or finger substitution.',
       'pedal':'CC64 is resonance intent only. Key spans, hand travel and monody are checked on physical gates. Dry monody at bars 49–50 in v0/v1 and 49–52 in v2.',
       'foreground':'Exactly one nonoverlapping melody. Bars 33–40 transfer it to LH with quiet RH harmonic support; every other bar has RH lead.',
       'musical_limits':'Symbolic feasibility and score structure only; no listening approval or claim of human comfort, acoustic realism or rendering quality.'}}

def json_patch(a,b,path=''):
    if type(a)!=type(b):return [{'op':'replace','path':path,'value':b}]
    if isinstance(a,dict):
        out=[]
        for key in sorted(a.keys()-b.keys()):out.append({'op':'remove','path':path+'/'+key.replace('~','~0').replace('/','~1')})
        for key in sorted(b):
            sub=path+'/'+key.replace('~','~0').replace('/','~1')
            if key not in a:out.append({'op':'add','path':sub,'value':b[key]})
            else:out.extend(json_patch(a[key],b[key],sub))
        return out
    if a!=b:return [{'op':'replace','path':path,'value':b}]
    return []
def exact_diff(root,a,b):
    sa=json.loads((root/f'score_{a}.json').read_text());sb=json.loads((root/f'score_{b}.json').read_text());changes=[]
    for n in range(1,65):
        row={'bar':n,'before_bar':sa['bars'][n-1],'after_bar':sb['bars'][n-1],
             'before_events':[e for e in sa['events'] if e['bar']==n],'after_events':[e for e in sb['events'] if e['bar']==n],
             'before_pedals':[e for e in sa['pedals'] if e['bar']==n],'after_pedals':[e for e in sb['pedals'] if e['bar']==n]}
        if any(row['before_'+k]!=row['after_'+k] for k in ('bar','events','pedals')):changes.append(row)
    sha=lambda name:hashlib.sha256((root/name).read_bytes()).hexdigest()
    save(root,f'exact_diff_{a}_to_{b}.json',{'from':a,'to':b,'before_sha256':sha(f'score_{a}.json'),'after_sha256':sha(f'score_{b}.json'),
      'changed_bars':[r['bar'] for r in changes],'changes':changes,'phrase_metadata_before':sa['phrases'],'phrase_metadata_after':sb['phrases'],
      'position_plan_before':sa['hand_position_plan'],'position_plan_after':sb['hand_position_plan'],'json_patch':json_patch(sa,sb)})
    patch=''.join(difflib.unified_diff(dumps(sa).splitlines(True),dumps(sb).splitlines(True),fromfile=f'score_{a}.json',tofile=f'score_{b}.json'))
    (root/f'exact_diff_{a}_to_{b}.patch').write_text(patch,encoding='utf-8')

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--outdir',type=Path,default=ROOT);args=ap.parse_args();root=args.outdir.resolve()
    if root!=ROOT and ROOT not in root.parents:raise SystemExit('Output must remain within this isolated work folder.')
    root.mkdir(parents=True,exist_ok=True)
    for v in range(3):save(root,f'score_v{v}.json',compose(v))
    (root/'score.json').write_bytes((root/'score_v2.json').read_bytes())
    for a,b in [('v0','v1'),('v1','v2')]:exact_diff(root,a,b)
    s=compose(2);print(dumps({'selected':'v2','bars':64,'total_beats':256,'duration_with_tail_seconds':round(sec(s['bars'],256)+6,6)}))
if __name__=='__main__':main()
