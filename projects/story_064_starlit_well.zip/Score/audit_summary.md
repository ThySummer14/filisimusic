# Final score-only audit

- Exact schema read-back: PASS
- Final version: score_v2.json, a48059a7596cad3afebc2f4f5907552004119dd5bb319812096365160022890e
- Bars / quarterbeats: 48 / 155.0
- Duration including 4 s tail: 179.071155 s
- Total events / flute notes: 290 / 52
- Flute used range: MIDI 73–83 (approved range 72–83)
- Longest flute gate after tempo integration: 1.35 s
- Minimum inter-phrase gate rest: 1.396552 s
- After conservative 209 ms early next trigger: 1.187552 s, before accounting for release tail
- 13 phrases; each uses one pp or mf layer; zero layer changes inside phrases
- Left hand: at most 2 simultaneous notes, 7-semitone simultaneous span
- Right hand: at most 2 simultaneous notes, 5-semitone simultaneous span
- Zero hand crossing, simultaneous same-key assignments, cross-instrument foreground overlaps, and flute-note overlaps
- Minimum release gap before a left-hand move of at least 12 semitones: 0.4375 s
- Final structural issues: 0

The earlier v0 FAIL is intentionally retained: three rushed left-hand repositionings were fixed in v1. Both v1 and v2 pass. This is a score and timing audit only; it neither establishes musical quality nor proves actual sample silence. Read integration_notes.md before rendering.
