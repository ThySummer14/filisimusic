import pathlib,argparse,wave,json,numpy as np,hashlib,math
ap=argparse.ArgumentParser();ap.add_argument('wav');ap.add_argument('--score');a=ap.parse_args();p=pathlib.Path(a.wav)
with wave.open(str(p),'rb') as w:
 sr=w.getframerate();ch=w.getnchannels();bits=w.getsampwidth()*8;n=w.getnframes();rms=[];peaks=[];clipped=0;dc=np.zeros(ch);energy=np.zeros(ch);peak=0.;last=None;maxstep=0.;offset=0;first_nonzero=None;last_nonzero=None
 while raw:=w.readframes(sr//10):
  if bits==24:
   q=np.frombuffer(raw,dtype=np.uint8).reshape(-1,3);v=q[:,0].astype(np.int32)|(q[:,1].astype(np.int32)<<8)|(q[:,2].astype(np.int32)<<16);v=np.where(v&0x800000,v-0x1000000,v);x=v.reshape(-1,ch).astype(float)/8388608
  elif bits==16:x=np.frombuffer(raw,dtype='<i2').reshape(-1,ch).astype(float)/32768
  else:raise ValueError('unsupported PCM')
  non=np.flatnonzero(np.max(np.abs(x),axis=1)>1e-6)
  if len(non):
   if first_nonzero is None:first_nonzero=(offset+non[0])/sr
   last_nonzero=(offset+non[-1])/sr
  dx=np.diff(x,axis=0)
  if len(dx):maxstep=max(maxstep,float(np.abs(dx).max()))
  if last is not None:maxstep=max(maxstep,float(np.max(np.abs(x[0]-last))))
  last=x[-1];offset+=len(x);pk=float(np.max(np.abs(x)));peak=max(peak,pk);peaks.append(pk);rms.append(float(np.sqrt(np.mean(x*x))));clipped+=int(np.count_nonzero(np.abs(x)>=1));dc+=x.sum(axis=0);energy+=(x*x).sum(axis=0)
secs=n/sr;out={'file':p.name,'duration':secs,'sample_rate':sr,'channels':ch,'bits':bits,'peak':peak,'peak_dbfs':20*math.log10(max(peak,1e-12)),'rms_dbfs':20*math.log10(max(math.sqrt(energy.sum()/n/ch),1e-12)),'clipped_samples':clipped,'dc_per_channel':(dc/n).tolist(),'channel_rms':np.sqrt(energy/n).tolist(),'max_adjacent_sample_step':maxstep,'first_sound_seconds':first_nonzero,'last_sound_seconds':last_nonzero,'final_1sec_peak':max(peaks[-10:]),'final_1sec_rms':float(np.sqrt(np.mean(np.array(rms[-10:])**2))),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'ten_second_windows':[{'start':i/10,'rms_dbfs':20*math.log10(max(float(np.sqrt(np.mean(np.array(rms[i:i+100])**2))),1e-12)),'peak':max(peaks[i:i+100])}for i in range(0,len(rms),100)]}
if a.score:
 d=json.loads(pathlib.Path(a.score).read_text());groups=[];t=0
 for b in d['bars']:
  if not groups or groups[-1]['title']!=b['section']:groups.append({'title':b['section'],'start':t})
  t+=b['beats']*60/b['bpm']
 for i,g in enumerate(groups):
  end=groups[i+1]['start'] if i+1<len(groups) else t; vals=rms[int(g['start']*10):int(end*10)];g['end']=end;g['rms_dbfs']=20*math.log10(max(float(np.sqrt(np.mean(np.array(vals)**2))),1e-12))
 out['sections']=groups
p.with_suffix('.qa.json').write_text(json.dumps(out,indent=2));print(json.dumps({k:v for k,v in out.items() if k!='ten_second_windows'},indent=2))
