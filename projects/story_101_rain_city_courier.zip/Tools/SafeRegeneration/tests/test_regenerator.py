"""Only synthetic metadata/static/native-response fixtures. No real engine load/render."""
import contextlib
import copy
import io
import json
import os
import signal
import time
from pathlib import Path
import struct
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch
import wave

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import regenerate
from sfz_support import emit, inspect, parse, score_info, sha, verify_emitted, verify_native

class RegeneratorTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(dir=ROOT/'tests')
        self.p = Path(self.temp.name)
        self.sfz = self.p/'original.sfz'; self.score = self.p/'score.json'; self.library = self.p/'explicit_engine.fixture'
        self.library.write_bytes(b'NOT A LOADABLE ENGINE: static testing only')
        for name in ['low', 'high', 'unused', 'release', 'cc']:
            with wave.open(str(self.p/(name+'.wav')), 'wb') as w:
                w.setnchannels(1); w.setsampwidth(2); w.setframerate(44100); w.writeframes(b'\0\0'*256)
        self.sfz.write_text('''// Original content must not be modified.
<control> set_cc20=0
<global> ampeg_release=0.1
<group> volume=-3
<region> sample=low.wav key=60 lovel=1 hivel=71
<region> sample=high.wav key=60 lovel=72 hivel=127
<region> sample=unused.wav key=61 lovel=1 hivel=127
<region> sample=release.wav key=60 lovel=127 hivel=127 trigger=release
<region> sample=cc.wav key=10 on_locc64=1 on_hicc64=127
<curve> curve_index=1 v000=0 v127=1
''')
        self.score.write_text(json.dumps({'bars': [{'start': 0, 'beats': 4, 'bpm': 120}], 'events': [
            {'onset': 0, 'duration': 1, 'pitch': 60, 'velocity': 72}], 'pedals': [], 'tail_seconds': 1}))
        self.subset = self.p/'output'/'subset.sfz'; self.subset.parent.mkdir()
    def tearDown(self): self.temp.cleanup()
    def plan(self, mode='moonlight-subset', max_seconds=None): return inspect(self.sfz, self.score, mode, max_seconds)
    def native(self, plan):
        actual72 = 0.5669291019439697
        regions = [
            {'index': 0, 'key_range': [60,60], 'vel_range': [0,actual72], 'sample': ['low.wav'], 'trigger': ['attack']},
            {'index': 1, 'key_range': [60,60], 'vel_range': [0.5669291615486145,1], 'sample': ['high.wav'], 'trigger': ['attack']},
            {'index': 2, 'key_range': [61,61], 'vel_range': [0,1], 'sample': ['unused.wav'], 'trigger': ['attack']},
            {'index': 3, 'key_range': [60,60], 'vel_range': [1,1], 'sample': ['release.wav'], 'trigger': ['release']},
            {'index': 4, 'key_range': [10,10], 'vel_range': [0,1], 'sample': ['cc.wav'], 'trigger': ['attack']},
        ]
        table = {str(v): {'value': v/127} for v in range(1,128)}; table['72']['value'] = actual72
        return {'sfz_sha256': sha(self.sfz), 'library_sha256': sha(self.library), 'regions': regions,
                'integer_velocity_to_actual_trigger_value': table}
    def args(self, *extra):
        return ['--score',str(self.score),'--sfz',str(self.sfz),'--library',str(self.library),'--out',str(self.p/'result.wav'),
                '--mode','moonlight-subset','--ram-cap-mib','200', *extra]
    def test_velocity_boundary_keeps_neighbor_release_and_cc(self):
        p = self.plan(); self.assertEqual([r['source_region_index'] for r in p['selected']], [0,1,3,4])
        self.assertEqual(p['score_info']['frames'],132300)
        emit(p,self.subset); verify_emitted(p,self.subset)
        result=verify_native(p,self.subset,self.native(p),self.library)
        self.assertEqual(result['proof'][0]['ordered_note_candidates'],[0]); self.assertEqual(result['all_cc_region_ids'],[4])
    def test_missing_old_integer_candidate_fails(self):
        p=self.plan(); p['selected']=[r for r in p['selected'] if r['source_region_index']!=0]
        emit(p,self.subset)
        with self.assertRaisesRegex(ValueError,'Missing native candidate'): verify_native(p,self.subset,self.native(p),self.library)
    def test_effective_parameter_edit_fails(self):
        p=self.plan(); emit(p,self.subset); self.subset.write_text(self.subset.read_text().replace('volume=-3','volume=-2'))
        with self.assertRaisesRegex(ValueError,'Header/curve'): verify_emitted(p,self.subset)
    def test_native_library_hash_mismatch_fails(self):
        p=self.plan(); emit(p,self.subset); n=self.native(p); self.library.write_bytes(b'changed')
        with self.assertRaisesRegex(ValueError,'library hash'): verify_native(p,self.subset,n,self.library)
    def test_native_key_disagreement_fails(self):
        p=self.plan(); emit(p,self.subset); n=self.native(p); n['regions'][0]['key_range']=[59,60]
        with self.assertRaisesRegex(ValueError,'key range'): verify_native(p,self.subset,n,self.library)
    def test_complete_bank_retains_all(self):
        p=self.plan('complete-bank'); self.assertEqual(len(p['selected']),5); self.assertFalse(p['removed'])
        emit(p,self.subset); verify_native(p,self.subset,self.native(p),self.library)
    def test_iowa_control_header_added(self):
        self.sfz.write_text(self.sfz.read_text().replace('<control> set_cc20=0\n',''))
        p=self.plan('complete-bank'); emit(p,self.subset); verify_emitted(p,self.subset)
        self.assertIn('<control> hint_ram_based=1',self.subset.read_text())
    def test_macro_and_selection_change_fail(self):
        source=self.sfz.read_text()
        for text in ['#include "hidden.sfz"\n'+source,source.replace('volume=-3','volume=-3 sw_last=60')]:
            self.sfz.write_text(text)
            with self.assertRaises(ValueError): self.plan()
    def test_dry_run_does_not_spawn_load_or_write(self):
        before={p.name:sha(p) for p in self.p.iterdir() if p.is_file()}
        with patch('regenerate.run_guarded', side_effect=AssertionError('Engine must not run')), contextlib.redirect_stdout(io.StringIO()) as output:
            self.assertEqual(regenerate.main(self.args('--dry-run')),0)
        d=json.loads(output.getvalue()); self.assertEqual(d['status'],'STATIC_PLAN_ONLY_NOT_NATIVE_VERIFIED')
        self.assertFalse((self.p/'result.regeneration').exists()); self.assertFalse((self.p/'result.wav').exists())
        self.assertEqual(before,{p.name:sha(p) for p in self.p.iterdir() if p.is_file()})
    def test_ram_cap_rejected_before_engine(self):
        args=self.args('--dry-run'); args[args.index('200')]='128'
        with patch('regenerate.run_guarded', side_effect=AssertionError('Engine must not run')):
            with self.assertRaisesRegex(ValueError,'RAM plan exceeds cap'): regenerate.main(args)
    def test_existing_output_never_overwritten(self):
        out=self.p/'result.wav'; out.write_bytes(b'keep me')
        with self.assertRaisesRegex(ValueError,'exists'): regenerate.main(self.args('--dry-run'))
        self.assertEqual(out.read_bytes(),b'keep me')
    def test_prefix_is_bound_and_future_notes_excluded(self):
        d=json.loads(self.score.read_text()); d['events'].append({'onset':3,'duration':1,'pitch':61,'velocity':90}); self.score.write_text(json.dumps(d))
        p=self.plan(max_seconds=1)
        self.assertEqual(p['score_info']['pairs'],[(60,72)]); self.assertEqual(p['score_info']['frames'],44100)
        self.assertEqual(p['score_info']['max_seconds'],1); self.assertEqual(p['score_info']['full_score_events'],2)
        emit(p,self.subset); verify_native(p,self.subset,self.native(p),self.library)
    def test_bad_score_or_empty_prefix_rejected(self):
        d=json.loads(self.score.read_text()); d['events'][0]['onset']=1; self.score.write_text(json.dumps(d))
        with self.assertRaisesRegex(ValueError,'No note-ons'): self.plan(max_seconds=0.1)
        d['events'][0]['velocity']=0; self.score.write_text(json.dumps(d))
        with self.assertRaisesRegex(ValueError,'positive velocities'): self.plan()
    def test_generated_float_header_validator(self):
        out=self.p/'float_fixture.wav'; data=struct.pack('<ff',0.25,-0.25)
        out.write_bytes(b'RIFF'+struct.pack('<I',36+len(data))+b'WAVEfmt '+struct.pack('<IHHIIHH',16,3,2,44100,352800,8,32)+b'data'+struct.pack('<I',len(data))+data)
        regenerate.check_float32_output(out,1)
        with self.assertRaisesRegex(ValueError,'length'): regenerate.check_float32_output(out,2)
    def test_duplicate_header_opcode_is_preserved(self):
        self.sfz.write_text(self.sfz.read_text().replace('<group> volume=-3','<group> hicc64=0 hicc64=32 volume=-3'))
        p=self.plan(); emit(p,self.subset); verify_emitted(p,self.subset)
        self.subset.write_text(self.subset.read_text().replace('hicc64=0 hicc64=32','hicc64=1 hicc64=32'))
        with self.assertRaisesRegex(ValueError,'Ordered header'): verify_emitted(p,self.subset)
    def test_disabled_key_cc_is_retained(self):
        self.sfz.write_text(self.sfz.read_text().replace('sample=cc.wav key=10','sample=cc.wav key=-1'))
        p=self.plan(); emit(p,self.subset); n=self.native(p); n['regions'][4]['key_range']=[0,127]
        verify_native(p,self.subset,n,self.library)
    def test_query_estimate_includes_offsets(self):
        base=self.plan()['query_preload_bytes']
        with wave.open(str(self.p/'low.wav'),'wb') as w:
            w.setnchannels(1); w.setsampwidth(2); w.setframerate(44100); w.writeframes(b'\0\0'*1024)
        self.sfz.write_text(self.sfz.read_text().replace('sample=low.wav key=60','sample=low.wav offset=100 key=60'))
        self.assertEqual(self.plan()['query_preload_bytes'],base+400)
    def test_success_manifest_binds_inputs_and_native_bounds(self):
        p=self.plan(); emit(p,self.subset)
        p.update({'library_sha256':sha(self.library),'renderer_sha256':sha(ROOT/'render_score_sfizz.py'),'enable_details':True})
        for item in p['samples']: item['sha256']=sha(item['sample'])
        native=self.native(p); provenance=regenerate.input_provenance(p,native,self.subset)
        self.assertEqual(provenance['score_sha256'],sha(self.score)); self.assertEqual(provenance['original_bank_sfz_sha256'],sha(self.sfz))
        self.assertEqual(provenance['library_sha256'],sha(self.library)); self.assertEqual(provenance['native_bounds'],native)
        self.assertEqual(len(provenance['rendered_sample_set_sha256']),64)
        self.assertEqual(len(provenance['rendered_original_samples']),4)

    @unittest.skipUnless(os.name=='posix','Process-group tests require POSIX.')
    def test_sigterm_cleans_owned_sleep_stage_and_descendant(self):
        self.check_interruption(signal.SIGTERM,False)

    @unittest.skipUnless(os.name=='posix','Process-group tests require POSIX.')
    def test_sigterm_forces_term_ignoring_owned_descendants(self):
        self.check_interruption(signal.SIGTERM,True)

    @unittest.skipUnless(os.name=='posix','Process-group tests require POSIX.')
    def test_sigint_cleans_owned_sleep_stage_and_descendant(self):
        self.check_interruption(signal.SIGINT,True)

    @unittest.skipUnless(os.name=='posix','Process-group tests require POSIX.')
    def test_keyboardinterrupt_exception_cleans_owned_stage(self):
        self.check_interruption(None,True)

    def check_interruption(self, signum, ignore_term):
        ready=self.p/'sleep_ready.json'; log=self.p/'sleep_guard.log'
        code = "import sys,os,time; from pathlib import Path; sys.path.insert(0,"+repr(str(ROOT))+"); import regenerate as r\n"
        if signum is None:
            code += "original_rss=r.rss_tree_kib\ndef injected_rss(pid):\n if pid!=os.getpid():\n  until=time.monotonic()+5\n  while not Path("+repr(str(ready))+").exists() and time.monotonic()<until: time.sleep(.01)\n  raise KeyboardInterrupt('fixture')\n return original_rss(pid)\nr.rss_tree_kib=injected_rss\n"
        command=[sys.executable,str(ROOT/'tests/sleep_stage_fixture.py'),str(ready),'ignore' if ignore_term else 'normal']
        code += "try:\n r.run_guarded("+repr(command)+","+repr(str(log))+",128,30,dict(os.environ))\nexcept r.StageInterrupted as e: sys.exit(128+e.signum)\nexcept KeyboardInterrupt: sys.exit(130)\n"
        wrapper=subprocess.Popen([sys.executable,'-c',code],stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True)
        owned=None
        def alive(pid):
            result=subprocess.run(['ps','-p',str(pid),'-o','stat='],capture_output=True,text=True)
            return result.returncode==0 and bool(result.stdout.strip()) and not result.stdout.strip().startswith('Z')
        try:
            until=time.monotonic()+5
            while not ready.exists() and wrapper.poll() is None and time.monotonic()<until: time.sleep(.01)
            self.assertTrue(ready.exists(),'sleep stage did not become ready')
            owned=json.loads(ready.read_text()); self.assertNotEqual(owned['pgid'],wrapper.pid)
            if signum is not None: os.killpg(wrapper.pid,signum)
            stdout,stderr=wrapper.communicate(timeout=5)
            self.assertEqual(wrapper.returncode,128+signum if signum else 130,stderr.decode())
            until=time.monotonic()+2
            while any(alive(owned[k]) for k in ('stage_pid','descendant_pid')) and time.monotonic()<until: time.sleep(.02)
            self.assertFalse(alive(owned['stage_pid']),'owned stage survived wrapper interruption')
            self.assertFalse(alive(owned['descendant_pid']),'owned descendant survived wrapper interruption')
            result=json.loads(Path(str(log)+'.result.json').read_text())
            self.assertTrue(result['owned_stage_cleanup_completed'])
            self.assertEqual(result['interruption_signal'],signum)
        finally:
            if owned is not None:
                try: os.killpg(owned['pgid'],signal.SIGKILL)
                except ProcessLookupError: pass
            if wrapper.poll() is None:
                os.killpg(wrapper.pid,signal.SIGKILL); wrapper.wait()

    @unittest.skipUnless(sys.platform.startswith('linux'),'The /proc comparison is Linux-specific.')
    def test_compare_proc_and_ps_for_new_session_descendants(self):
        ready=self.p/'enumeration_ready.json'; log=self.p/'enumeration_guard.log'
        command=[sys.executable,str(ROOT/'tests/sleep_stage_fixture.py'),str(ready),'normal']
        code="import sys,os; sys.path.insert(0,"+repr(str(ROOT))+"); import regenerate as r\ntry:\n r.run_guarded("+repr(command)+","+repr(str(log))+",128,30,dict(os.environ))\nexcept r.StageInterrupted as e: sys.exit(128+e.signum)\n"
        wrapper=subprocess.Popen([sys.executable,'-c',code],stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True)
        owned=None
        try:
            until=time.monotonic()+5
            while not ready.exists() and wrapper.poll() is None and time.monotonic()<until: time.sleep(.01)
            self.assertTrue(ready.exists(),'sleep stage did not become ready')
            owned=json.loads(ready.read_text()); expected={wrapper.pid,owned['stage_pid'],owned['descendant_pid']}
            self.assertNotEqual(owned['pgid'],wrapper.pid)
            # The outer limiter walks every task's children file; reproduce that
            # read-only enumeration for this owned fixture tree only.
            todo=[wrapper.pid]; proc_seen=set(); proc_rss={}
            while todo:
                pid=todo.pop()
                if pid in proc_seen: continue
                proc_seen.add(pid)
                try:
                    status=Path('/proc/'+str(pid)+'/status').read_text()
                    proc_rss[pid]=int(next(line.split()[1] for line in status.splitlines() if line.startswith('VmRSS:')))
                    for task in Path('/proc/'+str(pid)+'/task').iterdir():
                        try: todo.extend(map(int,(task/'children').read_text().split()))
                        except FileNotFoundError: pass
                except (FileNotFoundError,StopIteration): pass
            table=subprocess.run(['ps','-axo','pid=,ppid=,rss='],capture_output=True,text=True,check=True)
            entries=[tuple(map(int,line.split())) for line in table.stdout.splitlines() if line.strip()]
            ps_seen={wrapper.pid}
            while True:
                expanded=ps_seen|{pid for pid,parent,rss in entries if parent in ps_seen}
                if expanded==ps_seen: break
                ps_seen=expanded
            ps_rss={pid:rss for pid,parent,rss in entries if pid in ps_seen}
            self.assertIn(wrapper.pid,proc_seen); self.assertTrue(expected<=ps_seen)
            self.assertTrue(all(ps_rss[pid]>0 for pid in expected))
            children_evidence=[]; status_evidence=[]
            for pid in sorted(expected):
                status=Path('/proc/'+str(pid)+'/status').read_text()
                status_evidence.append({'pid':pid,'fields':[line for line in status.splitlines() if line.split(':',1)[0] in {'Pid','PPid','NSpid','VmRSS'}]})
                for task in Path('/proc/'+str(pid)+'/task').iterdir():
                    try: children_evidence.append({'pid':pid,'tid':int(task.name),'children':(task/'children').read_text()})
                    except FileNotFoundError: children_evidence.append({'pid':pid,'tid':int(task.name),'children':'FILE_UNAVAILABLE'})
            report={'status':'PASS_COMPARISON_RECORDED','fixture':'No-audio sleeping wrapper, new-session stage, and stage descendant.',
                    'expected_process_count':3,'proc_found_all_expected':expected<=proc_seen,'ps_found_all_expected':True,
                    'known_fixture_pids':{'wrapper':wrapper.pid,**owned},'proc_discovered_pids':sorted(proc_seen),
                    'ps_discovered_pids':sorted(ps_seen),'proc_expected_tree_rss_kib':sum(proc_rss.get(pid,0) for pid in expected),
                    'ps_expected_tree_rss_kib':sum(ps_rss[pid] for pid in expected),
                    'ps_known_rows':[{'pid':pid,'parent':parent,'rss_kib':rss} for pid,parent,rss in entries if pid in expected],
                    'proc_task_children_evidence':children_evidence,'proc_status_evidence':status_evidence,
                    'stage_has_different_session_group':True,
                    'scope':'Separate sequential snapshots. This records current discovery behavior, not exact peak agreement and not the cause of a historical watchdog observation.'}
            (ROOT/'tests/PROCESS_ENUMERATION_REPORT.json').write_text(json.dumps(report,indent=2)+'\n')
        finally:
            if wrapper.poll() is None:
                os.killpg(wrapper.pid,signal.SIGTERM)
                try: wrapper.communicate(timeout=5)
                except subprocess.TimeoutExpired: os.killpg(wrapper.pid,signal.SIGKILL); wrapper.wait()
            if owned is not None:
                try: os.killpg(owned['pgid'],signal.SIGKILL)
                except ProcessLookupError: pass

    def test_bundle_renderer_integrity(self):
        manifest=regenerate.verify_bundle(); self.assertIn('render_score_sfizz.py',manifest['files'])
    def test_python_optimized_mode_does_not_disable_checks(self):
        result=subprocess.run([sys.executable,'-O',str(ROOT/'regenerate.py'),*self.args('--dry-run','--ram-cap-mib','128')],capture_output=True,text=True)
        self.assertEqual(result.returncode,2); self.assertIn('RAM plan exceeds cap',result.stderr)

if __name__=='__main__': unittest.main()
