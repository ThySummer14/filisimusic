# 087 · The Rooftop Tide Pool / 屋顶的潮池

Original symbolic draft for natural acoustic piano and short pizzicato cello.
Selected version: v2. Nominal duration with tail: 3:23.19.

The folder is isolated. No previous work or live project has been edited.
No audio, DSP, rendering, downloads, installations, or listening has occurred.

## Files

- score.json: selected score, byte-identical to score_v2.json
- score_v0.json, score_v1.json, score_v2.json: three complete 80-bar scores
- exact_diff_v0_to_v1.json, exact_diff_v1_to_v2.json: exact per-bar changes
- matching .patch files: complete unified JSON diffs
- audit_v0.json, audit_v1.json, audit_v2.json: per-version symbolic audits
- verify_symbolic.py, independent_verification.json: independent file-based checks
- generate_score.py: self-contained deterministic standard-library generator
- story_zh.txt: original Chinese story
- music_notes_zh.md: composition, story map, instrument and performance notes
- revision_notes.md: two substantive composition revisions
- hash_manifest.json: SHA-256 and byte size for every other file in this folder

## Reproduction

Run with Python 3 from any directory:

    python generate_score.py
    python verify_symbolic.py

Both scripts write only into their own folder. The independent verifier refreshes
the final hash manifest after verification. There are no third-party packages.

## Score contract

Meter: 6/8, three quarter beats per bar. All event onsets, durations, and bar starts
use absolute quarter beats. BPM is per bar and denotes quarter notes. Instrument,
voice, hand, phrase, and role are explicit. Piano leads throughout; cello supports
the same harmony and always uses short separate pizzicato on a single recorded mf
layer. Actual cello score range is MIDI 37–47, inside the provided bank's 36–47.

The audits do not certify acoustic balance, sampled releases, or aesthetic
quality. These need subsequent integration and listening by the parent workflow.

Every piano event also includes a finger and hand-position range. Actual position
changes require 75 ms plus 12 ms per semitone beyond four, using the larger of
grip-edge and position-edge travel. The v2 audit independently verifies all 79
position changes. The strict musical revision counts are 16 bars and 36 bars.
