#!/usr/bin/env python3
"""Independent file-based verifier. Does not import the composition generator."""
import hashlib
import json
import math
from bisect import bisect_right
from collections import defaultdict
from pathlib import Path

BASE = Path(__file__).resolve().parent

def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def read(name): return json.loads((BASE / name).read_text())

def verify(score):
    problems = []
    bars, notes = score['bars'], score['events']
    starts, seconds, total = [], [], 0.0
    for idx, b in enumerate(bars):
        starts.append(b['start']); seconds.append(total)
        total += 60 * b['beats'] / b['bpm']
        if (b['bar'], b['start'], b['beats'], b['meter_numerator'], b['meter_denominator']) != (idx + 1, 4.5 * idx, 4.5, 9, 8): problems.append('bar grid')
    def time_at(t):
        i = min(len(bars) - 1, max(0, bisect_right(starts, t) - 1))
        return seconds[i] + (t - starts[i]) * 60 / bars[i]['bpm']
    if len(bars) != 64 or score['total_beats'] != 288 or not 180 <= total + score['tail_seconds'] <= 210:
        problems.append('length')
    endpoints = defaultdict(list)
    onsets = defaultdict(list)
    for i, n in enumerate(notes):
        if not all(math.isfinite(n[k]) for k in ('onset', 'duration', 'pitch', 'velocity')): problems.append('nonfinite')
        if n['duration'] <= 0 or n['onset'] < 0 or n['onset'] + n['duration'] > 288: problems.append('bounds')
        if n['hand'] not in ('left', 'right') or n['instrument'] != 'piano' or not n['voice']: problems.append('ownership')
        if not 21 <= n['pitch'] <= 108 or not 1 <= n['velocity'] <= 127: problems.append('piano bounds')
        endpoints[round(n['onset'], 6)].append((1, i))
        endpoints[round(n['onset'] + n['duration'], 6)].append((0, i))
        onsets[n['onset']].append(n)
    active = {}
    maxspans = {'left': 0, 'right': 0}
    maxkeys = {'left': 0, 'right': 0}
    overlap_count = crossing_count = 0
    for t in sorted(endpoints):
        for kind, i in sorted(endpoints[t]):
            if kind == 0: active.pop(i, None)
            else:
                note = notes[i]
                if any(a['pitch'] == note['pitch'] for a in active.values()): overlap_count += 1
                active[i] = note
        pitchsets = {}
        for hand in ('left', 'right'):
            ps = [a['pitch'] for a in active.values() if a['hand'] == hand]
            pitchsets[hand] = ps
            if ps:
                maxspans[hand] = max(maxspans[hand], max(ps) - min(ps))
                maxkeys[hand] = max(maxkeys[hand], len(ps))
        if pitchsets['left'] and pitchsets['right'] and max(pitchsets['left']) >= min(pitchsets['right']): crossing_count += 1
    if overlap_count or crossing_count or max(maxspans.values()) > 12: problems.append('key geometry')
    mel = sorted([n for n in notes if n['voice'] == 'melody'], key=lambda n: n['onset'])
    maxjump = max(abs(a['pitch'] - b['pitch']) for a, b in zip(mel, mel[1:]))
    maxgap = max(time_at(b['onset']) - time_at(a['onset'] + a['duration']) for a, b in zip(mel, mel[1:]))
    if maxjump > 12 or maxgap > .15: problems.append('lead continuity')
    # Verify the intended passing/neighbor category by both approach and exit.
    passing = []
    cm = sorted([n for n in notes if n['voice'] == 'countermelody'], key=lambda n: n['onset'])
    for i, n in enumerate(cm):
        if n.get('harmonic_function') == 'passing_neighbor':
            previous = cm[i - 1] if i else None
            following = cm[i + 1] if i + 1 < len(cm) else None
            pcs = {p % 12 for p in bars[n['bar'] - 1]['harmony']}
            valid = bool(previous and following and previous['bar'] == n['bar'] == following['bar'] and
                         0 < abs(n['pitch'] - previous['pitch']) <= 2 and 0 < abs(following['pitch'] - n['pitch']) <= 2 and following['pitch'] % 12 in pcs)
            passing.append({'bar': n['bar'], 'valid_stepwise_approach_and_resolution': valid})
            if not valid: problems.append('counterpoint nonchord handling')
    # Independent transfer scan uses each hand's complete prior release history.
    transfers = []
    for hand in ('left', 'right'):
        attacks = [(t, [n for n in g if n['hand'] == hand]) for t, g in sorted(onsets.items())]
        attacks = [(t, g) for t, g in attacks if g]
        last_release = 0
        for i, (t, group) in enumerate(attacks):
            if i:
                old_t, old = attacks[i - 1]
                ca = (max(n['pitch'] for n in old) + min(n['pitch'] for n in old)) / 2
                cb = (max(n['pitch'] for n in group) + min(n['pitch'] for n in group)) / 2
                distance = abs(ca - cb)
                if distance > 12:
                    gap = time_at(t) - time_at(last_release)
                    need = .22 if distance > 21 else .18 if distance > 17 else .12
                    transfers.append({'hand': hand, 'beat': t, 'released_seconds': round(gap, 6), 'required_seconds': need})
                    if gap + 1e-7 < need: problems.append('unreleased large transfer')
            last_release = max(last_release, *(n['onset'] + n['duration'] for n in group))
    return {'passed': not problems, 'problems': problems, 'duration_with_tail': round(total + score['tail_seconds'], 6),
            'event_count': len(notes), 'max_held_spans': maxspans, 'max_keys': maxkeys,
            'same_key_overlap_count': overlap_count, 'hand_crossing_count': crossing_count,
            'maximum_successive_melody_jump_semitones': maxjump,
            'maximum_internal_lead_release_gap_seconds': round(maxgap, 6),
            'passing_neighbor_validation': passing, 'large_transfer_count': len(transfers),
            'all_large_transfers_have_release_time': all(t['released_seconds'] + 1e-6 >= t['required_seconds'] for t in transfers)}

scores = {v: read('score_' + v + '.json') for v in ('v0', 'v1', 'v2')}
results = {v: verify(s) for v, s in scores.items()}
diffs = {}
for a, b in (('v0', 'v1'), ('v1', 'v2')):
    d = read('exact_diff_' + a + '_to_' + b + '.json')
    actual = []
    for n in range(1, 65):
        na = [e for e in scores[a]['events'] if e['bar'] == n]
        nb = [e for e in scores[b]['events'] if e['bar'] == n]
        if na != nb or scores[a]['bars'][n - 1] != scores[b]['bars'][n - 1]: actual.append(n)
    diffs[a + '_to_' + b] = {'actual_changed_bars': actual, 'matches_exact_diff': actual == d['changed_bars'],
                             'substantive_note_change_bar_count': len(d['structural_harmonic_or_note_changed_bars'])}
identity = (BASE / 'score.json').read_bytes() == (BASE / 'score_v2.json').read_bytes()
result = {'passed': identity and all(r['passed'] for r in results.values()) and all(d['matches_exact_diff'] and d['substantive_note_change_bar_count'] >= 8 for d in diffs.values()),
          'score_sha256': sha(BASE / 'score.json'), 'selected_equals_v2_byte_for_byte': identity,
          'versions': results, 'revision_checks': diffs,
          'limitations': 'Independent symbolic check only; no audio, rendering, or aesthetic judgment.'}
(BASE / 'independent_verification.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({k: v for k, v in result.items() if k != 'versions'}, ensure_ascii=False, indent=2))
if not result['passed']: raise SystemExit(1)
