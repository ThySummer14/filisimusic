local paths={"PROJECT/revisions/054_ferry_v3.rpp","PROJECT/revisions/054_ferry_v4.rpp"}
local f=assert(io.open("PROJECT/revisions/streamfix_native_settings_v4.tsv","w"))
for pi,path in ipairs(paths) do
 reaper.Main_openProject(path)
 local function emit(scope,key,v) f:write(pi,"\t",scope,"\t",key,"\t",tostring(v),"\n") end
 for _,k in ipairs({"RENDER_BOUNDSFLAG","RENDER_STARTPOS","RENDER_ENDPOS","RENDER_SRATE","RENDER_CHANNELS"}) do emit("project",k,reaper.GetSetProjectInfo(0,k,0,false)) end
 emit("master","D_VOL",reaper.GetMediaTrackInfo_Value(reaper.GetMasterTrack(0),"D_VOL"))
 for ti=0,reaper.CountTracks(0)-1 do
  local tr=reaper.GetTrack(0,ti); local scope="track"..ti
  for _,k in ipairs({"D_VOL","D_PAN","D_PANLAW","D_WIDTH","I_PANMODE","B_MAINSEND"}) do emit(scope,k,reaper.GetMediaTrackInfo_Value(tr,k)) end
  emit(scope,"FX_COUNT",reaper.TrackFX_GetCount(tr))
  for ii=0,reaper.CountTrackMediaItems(tr)-1 do
   local it=reaper.GetTrackMediaItem(tr,ii);local is=scope.."item"..ii
   for _,k in ipairs({"D_POSITION","D_LENGTH","D_VOL","D_FADEINLEN","D_FADEOUTLEN"}) do emit(is,k,reaper.GetMediaItemInfo_Value(it,k)) end
   local take=reaper.GetActiveTake(it)
   for _,k in ipairs({"D_STARTOFFS","D_VOL","D_PAN","D_PLAYRATE"}) do emit(is.."take",k,reaper.GetMediaItemTakeInfo_Value(take,k)) end
  end
 end
end
f:close();reaper.Main_OnCommand(40004,0)
