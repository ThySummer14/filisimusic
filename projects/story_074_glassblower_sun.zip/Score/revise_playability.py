from pathlib import Path
import json,copy
P=Path(__file__).parent;d=json.loads((P/'revisions/score_v2.json').read_text());changes=[]
for e in d['events']:
 if e['voice']=='bass' and e['bar']<=4 and e['duration']>.82:
  changes.append({'bar':e['bar'],'kind':'release_root_before_left_hand_transfer','old_duration':e['duration'],'new_duration':.82});e['duration']=.82
 if e['voice']=='accompaniment' and e['pitch']>=60:
  changes.append({'bar':e['bar'],'kind':'lower_inner_voice_to_keep_melody_register_clear','old_pitch':e['pitch'],'new_pitch':e['pitch']-12});e['pitch']-=12
# Shared final Eb major: LH Eb2/Bb2/Eb3, RH Eb4/G4/Bb4.
d['events']=[e for e in d['events'] if not(e['bar']==64 and e['voice']=='accompaniment')]
d['events'].append({'onset':189,'duration':2.75,'pitch':46,'velocity':42,'voice':'bass','instrument':'piano','bar':64})
d['events'].sort(key=lambda e:(e['onset'],e['pitch']));d['stage']='v3_clear_inner_voice_and_shared_hand_release'
for f in ['score.json','revisions/score_v3.json']:(P/f).write_text(json.dumps(d,ensure_ascii=False,indent=2))
(P/'revisions/pass3.json').write_text(json.dumps({'kind':'substantive_voicing_and_articulation_correction','changes':changes,'final_chord':'LH39,46,51 andRH63,67,70; no held left-hand stretch across19semitones','reason':'Independent review found8 flags including same-key collisions and held hand spans. Preserve melody, compact inner harmony below the singing register, release opening roots before transfer.','human_listening_review':False},indent=2));print(len(changes),'written corrections')
