"""Original lyrical-waltz score. Recurring themes are newly performed and developed; no reused audio loops."""
import pathlib,json,copy,math
P=pathlib.Path(__file__).parent;design=json.loads((P/'theme_design.json').read_text());A=[b['melody'] for b in design['bars']]
A2=[[(79,.5),(83,.5),(86,1),(84,.5),(83,.5)],[(84,1),(83,.5),(79,.5),(76,1)],[(81,.5),(79,.5),(76,1),(72,1)],[(78,.5),(81,.5),(84,1),(81,.5),(78,.5)],[(79,1.5),(83,.5),(86,1)],[(83,1),(81,.5),(79,.5),(78,.5),(76,.5)],[(79,.5),(76,.5),(78,.5),(81,.5),(84,.5),(81,.5)],[(83,1),(79,1.5),(-1,.5)]]
C=[[(71,.5),(74,.5),(79,1),(78,.5),(74,.5)],[(79,1),(76,.5),(74,.5),(72,1)],[(76,.75),(79,.25),(81,1),(79,.5),(76,.5)],[(78,1.5),(76,.5),(74,.5),(-1,.5)],[(74,.5),(79,.5),(83,1),(81,.5),(79,.5)],[(79,1),(76,1),(71,.5),(74,.5)],[(72,.5),(76,.5),(78,1),(76,.5),(74,.5)],[(71,1),(74,.5),(79,1),(-1,.5)]]
C2=[[(79,.75),(78,.25),(74,1),(71,.5),(74,.5)],[(76,.5),(79,.5),(84,1),(83,.5),(79,.5)],[(81,1),(79,.5),(76,.5),(72,.5),(76,.5)],[(78,.5),(81,.5),(84,.5),(81,.5),(78,.5),(-1,.5)],[(83,1),(81,.5),(79,.5),(74,.5),(71,.5)],[(76,1.5),(78,.5),(79,1)],[(76,.5),(72,.5),(74,.5),(78,.5),(81,.5),(78,.5)],[(79,1.5),(74,.5),(71,.5),(-1,.5)]]
B=[[(79,1),(78,.5),(76,.5),(71,1)],[(72,1),(76,1),(79,1)],[(78,1),(76,.5),(74,.5),(69,1)],[(71,.5),(74,.5),(79,1),(81,1)],[(79,1),(75,.5),(74,.5),(72,1)],[(81,1),(79,.5),(77,.5),(75,1)],[(74,1),(77,1),(82,1)],[(75,1),(78,.5),(83,.5),(81,1)]]
B2=[[(83,1.5),(79,.5),(76,1)],[(81,1),(79,.5),(76,.5),(72,1)],[(78,.5),(81,.5),(84,1),(81,.5),(78,.5)],[(79,1),(78,.5),(74,.5),(71,1)],[(75,.75),(79,.25),(84,1),(82,.5),(79,.5)],[(81,.5),(79,.5),(77,1),(75,.5),(72,.5)],[(77,.5),(82,.5),(86,1),(84,.5),(82,.5)],[(83,1),(81,.5),(78,.5),(75,.5),(-1,.5)]]
CODA=[[(79,1),(78,.5),(74,.5),(71,1)],[(76,1),(79,.5),(84,.5),(79,1)],[(76,.5),(79,.5),(81,1),(79,.5),(76,.5)],[(78,1),(76,.5),(74,.5),(69,1)],[(71,.5),(74,.5),(79,1),(83,1)],[(84,1.5),(79,.5),(76,1)],[(81,.5),(78,.5),(74,1),(78,.5),(-1,.5)],[(79,2.5),(-1,.5)]]
H={'G6':[43,59,62,67],'Cmaj7':[48,59,64,67],'Am7':[45,55,60,64],'D7':[50,57,60,66],'GB':[47,55,62,67],'Em7':[40,55,59,62],'Cm7':[48,58,63,67],'F7':[41,57,60,63],'Bb':[46,58,62,65],'B7':[47,57,63,66]};home=['G6','Cmaj7','Am7','D7','GB','Em7','Am7_D7','G6'];dark=['Em7','Am7','D7','G6','Cm7','F7','Bb','B7']
sections=[('A seed in a teacup',4,112,'intro'),('The station becomes a garden',16,116,'theme'),('Six larger pots',24,120,'grow'),('The first crack',16,106,'crisis'),('Many cups on the table',24,116,'share'),('Learning the wind',24,120,'return'),('The crossed-out label',8,108,'coda')]
notes=[];bars=[];pedals=[];beat=0;barno=0
for section,count,tempo,kind in sections:
 for j in range(count):
  barno+=1;k=j%8;prog=home
  if kind=='intro':line=copy.deepcopy(C[k])
  elif kind=='theme':line=copy.deepcopy(A[k] if j<8 else A2[k])
  elif kind=='grow':line=copy.deepcopy([C,C2,A2][j//8][k])
  elif kind=='crisis':line=copy.deepcopy(B[k] if j<8 else B2[k]);prog=dark
  elif kind=='share':line=copy.deepcopy([C,A,C2][j//8][k])
  elif kind=='return':line=copy.deepcopy([A,A2,C2][j//8][k])
  else:line=copy.deepcopy(CODA[k])
  assert abs(sum(v for n,v in line)-3)<1e-8,(kind,j,line)
  hname=prog[k]
  if kind=='coda':hname=['G6','Cmaj7','Am7','D7','GB','Cmaj7','D7','G6'][k]
  split=hname=='Am7_D7';ch=H['Am7' if split else hname];bpm=tempo
  if kind=='coda' and j>=5:bpm=[102,96,88][j-5]
  if j==count-1 and kind!='coda':bpm-=4
  bars.append(dict(bar=barno,start=beat,beats=3,bpm=bpm,section=section,harmony_name=hname,harmony=ch,harmony_change_beat=1 if split else None,role_plan=kind))
  leadvel={'intro':61,'theme':73,'grow':79,'crisis':77,'share':70,'return':84,'coda':66}[kind]
  if kind=='grow':leadvel+=j//8*2
  if kind=='share':leadvel+=j//8*3
  if kind=='crisis':leadvel+=3 if j in (4,5,12,13) else 0
  if kind=='coda':leadvel-=j
  off=0
  for n,l in line:
   if n>=0:notes.append(dict(bar=barno,onset=beat+off,duration=l*.955,pitch=n,velocity=leadvel+(3 if off==0 else 0),voice='melody'))
   off+=l
  bassvel={'intro':37,'theme':43,'grow':47,'crisis':45,'share':40,'return':49,'coda':37}[kind]
  notes.append(dict(bar=barno,onset=beat,duration=.32,pitch=ch[0],velocity=bassvel,voice='bass'))
  if split:
   notes.append(dict(bar=barno,onset=beat+1,duration=.28,pitch=H['D7'][0],velocity=bassvel-2,voice='bass'));ch2=H['D7']
  else:ch2=ch
  # The left hand waits behind the melodic downbeat, then supports the same harmony.
  for z,n in enumerate(ch2[1:]):notes.append(dict(bar=barno,onset=beat+1.10+z*.035,duration=.58,pitch=n,velocity=bassvel-6+z,voice='accompaniment'))
  # Quiet common-tone continuation on beat3 rather than an unrelated bass tune.
  if line[-1][0]>=0 or (kind in ('grow','return') and k!=7):
   ns=ch2[1:3] if kind in ('grow','return') else [ch2[2]]
   for z,n in enumerate(ns):notes.append(dict(bar=barno,onset=beat+2.10+z*.03,duration=.48,pitch=n,velocity=bassvel-9+z,voice='accompaniment'))
  if kind=='return' and j in (8,12,16):
   e=next(e for e in notes if e['bar']==barno and e['voice']=='melody');q=copy.deepcopy(e);q.update(pitch=e['pitch']-12,velocity=e['velocity']-19,voice='melody_octave');notes.append(q)
  # Half pedal, refreshed with the voicing/harmonic change.
  pedals.extend([dict(onset=beat,value=0),dict(onset=beat+.11,value=48),dict(onset=beat+(.96 if split else 1.9),value=0),dict(onset=beat+(1.16 if split else 2.13),value=43),dict(onset=beat+2.86,value=0)])
  beat+=3
pedals=[e for e in pedals if e['onset']<beat-3]+[dict(onset=beat-3,value=0),dict(onset=beat-2.9,value=63),dict(onset=beat+2.5,value=0)]
score=dict(id=53,title='An Orchard Under Glass',title_zh='玻璃之下的果园',stage='v0_original_lyrical_waltz',bars=bars,events=notes,pedals=pedals,total_beats=beat,tail_seconds=4.5,story_relationship='A complete descending-and-answering melody grows through new continuations; dark harmonic detour, shared melodic handovers, and a newly completed return. Moderate triple meter contrasts with52 energetic duple-meter piano.')
(P/'revisions/score_v0.json').write_text(json.dumps(score,indent=2));(P/'score.json').write_text(json.dumps(score,indent=2));(P/'thematic_material.json').write_text(json.dumps({'opening_theme_A':A,'rising_answer_A2':A2,'branching_continuation_C':C,'branching_answer_C2':C2,'dark_detour_B':B,'dark_answer_B2':B2,'new_coda':CODA},indent=2));print('53 draft duration',sum(b['beats']*60/b['bpm'] for b in bars)+4.5,'bars',len(bars))
