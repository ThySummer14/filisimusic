#!/usr/bin/env python3
"""Independent saved-file reader for work095. Does not import its generator."""
import copy, difflib, hashlib, json, math, subprocess, sys, tempfile
from collections import defaultdict
from pathlib import Path
ROOT=Path(__file__).resolve().parent
def load(n):return json.loads((ROOT/n).read_text(encoding='utf-8'))
def save(n,x):(ROOT/n).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def sha(n):return hashlib.sha256((ROOT/n).read_bytes()).hexdigest()
def end(e):return round(e['onset']+e['duration'],6)

def inspect(s):
    errors=[];bars=s['bars'];notes=s['events'];piano=[e for e in notes if e['instrument']=='piano'];cello=[e for e in notes if e['instrument']=='cello']
    def ck(ok,label):
        if not ok:errors.append(label)
    def seconds(t):return sum(min(max(t-b['start'],0),b['beats'])*60/b['bpm'] for b in bars)
    ck(s['id']==95 and s['total_beats']==320 and s['tail_seconds']==4,'identity / extent')
    ck(len(bars)==80 and 195<=seconds(320)+4<=220,'80-bar 3:15–3:40 duration')
    ck(s['instrumentation']==['natural_acoustic_piano','short_pizzicato_cello_single_mf_layer'],'two actual instruments')
    ck([b['bar'] for b in bars if b['key_region']=='C major']==list(range(33,49)),'parallel-major middle')
    chords={'Cm':{0,3,7},'Fm':{5,8,0},'Ab':{8,0,3},'Dm7b5':{2,5,8,0},'G7':{7,11,2,5},'Eb':{3,7,10},'Bb':{10,2,5},'C':{0,4,7},'Am':{9,0,4},'F':{5,9,0},'Dm':{2,5,9},'E7':{4,8,11,2}}
    inv={'C':0,'D':2,'Eb':3,'E':4,'F':5,'G':7,'B':11}
    for i,b in enumerate(bars):
        ck((b['bar'],b['start'],b['beats'],b['meter_numerator'],b['meter_denominator'])==(i+1,i*4,4,4,4),'explicit 4/4 grid')
        ck(80<=b['bpm']<=100 and b['meter']=='4/4','quarter BPM / meter')
        ck(b['phrase_id']==f'P{i//8+1:02d}' and b['phrase_position']==i%8+1,'eight-bar phrase identity')
        hn=b['harmony_name'].split('/');ck({p%12 for p in b['harmony']}==chords[hn[0]],f'named actual chord b{i+1}')
        if len(hn)>1:ck(min(b['harmony'])%12==inv[hn[1]],f'named inversion b{i+1}')
    ck(len({e['event_id'] for e in notes})==len(notes),'unique event IDs')
    ck(notes==sorted(notes,key=lambda e:(e['onset'],e['instrument'],e['hand'],e['pitch'],e['voice'])),'chronological storage')
    plans={(p['bar'],p['hand']):p for p in s['hand_position_plan']};ck(len(plans)==len(s['hand_position_plan'])==160,'both hands for 80 bars')
    for e in notes:
        tag=e['event_id'];b=bars[e['bar']-1]
        ck(all(math.isfinite(e[k]) for k in ('onset','duration','pitch','velocity')),'finite '+tag)
        ck(isinstance(e['pitch'],int) and 21<=e['pitch']<=108 and 1<=e['velocity']<=127,'MIDI '+tag)
        ck(b['start']<=e['onset']<end(e)<=b['start']+4,'bounds '+tag)
        ck(e['target_on_beats']==e['onset'] and abs(e['target_off_beats']-end(e))<1e-6,'absolute beat aliases')
        ck(abs(e['target_on_seconds']-seconds(e['onset']))<1.1e-6 and abs(e['target_off_seconds']-seconds(end(e)))<1.1e-6,'integrated time aliases')
        member=e['pitch']%12 in {p%12 for p in b['harmony']}
        ck(e['harmonic_function']==('chord_tone' if member else 'melodic_nonchord_tone'),'harmonic classification')
        ck(e['written_value_beats']>=e['duration']>0,'written / real gate '+tag)
        if e['instrument']=='piano':
            ck(e['hand'] in ('left','right') and e['pitch']<=84,'piano range')
            ck(seconds(end(e))-seconds(e['onset'])>=.06,'minimum physical key gate')
            plan=plans[(e['bar'],e['hand'])]
            ck(e['hand_position_id']==plan['position_id'] and e['hand_position_range']==plan['range'],'plan identity')
            ck(e['position_keys']==sorted(map(int,plan['pitch_finger_map'])),'plan full keys')
            ck(e['finger']==plan['pitch_finger_map'].get(str(e['pitch'])) and 1<=e['finger']<=5,'finger identity')
            if e['role']=='lead':ck(e['hand']=='right' and e['voice']=='melody','foreground role')
            else:ck(e['hand']=='left' and e['role']=='support' and member and e['pitch']>=48,'higher chord-bound support')
        else:
            ck(e['instrument']=='cello' and e['voice']=='cello_pizzicato' and e['role']=='harmonic_support' and e['hand']=='not_applicable','cello identity')
            ck(member and 36<=e['pitch']<=47 and e['source_pitch_midi']==e['pitch'],'authentic cello range / harmony')
            ck(e['layer']==e['sample_layer']=='mf' and e['velocity_controls']=='amplitude_variation_within_one_recorded_mf_layer','exactly one genuine mf source layer')
            ck(e['articulation']=='pizzicato_short_separate' and e['onset_reference']=='ordinary_trigger' and e['timing_correction_applied_seconds']==0,'separate uncompensated pluck')
            gate=seconds(end(e))-seconds(e['onset']);ck(.18<=gate<=.26 and abs(gate-e['nominal_gate_seconds'])<1e-6,'short cello gate')
    allowance={1:5,2:9,3:11,4:12}
    for key,plan in plans.items():
        es=[e for e in piano if (e['bar'],e['hand'])==key];ps=sorted({e['pitch'] for e in es});fs=[plan['pitch_finger_map'].get(str(q),0) for q in ps]
        ck(plan['active'] and plan['range']==[min(ps),max(ps)] and max(ps)-min(ps)<=12,'whole declared grip '+str(key))
        ck(len(ps)<=5 and len(fs)==len(set(fs)),'unique fingers per grip')
        ck(fs==sorted(fs,reverse=plan['hand']=='left'),'ordered fingering')
        ck(all(b-a<=allowance.get(abs(g-f),0) for a,b,f,g in zip(ps,ps[1:],fs,fs[1:])),'finger interval spacing')
    changes=defaultdict(list);attacks={h:defaultdict(list) for h in ('left','right')}
    for i,e in enumerate(notes):
        changes[e['onset']].append((1,i));changes[end(e)].append((0,i))
        if e['instrument']=='piano':attacks[e['hand']][e['onset']].append(e)
    active={};snapshot={h:{} for h in attacks};maxspan={h:0 for h in attacks};maxkeys={h:0 for h in attacks}
    overlaps=[];collisions=[];crossings=[];foreground=[];silences=[];silent_from=None
    for t,changes_here in sorted(changes.items()):
        had=bool(active)
        # Explicit releases precede attacks at the same beat.
        for kind,i in sorted(changes_here):
            if kind==0:active.pop(i,None)
            else:
                e=notes[i]
                for old in active.values():
                    if e['instrument']==old['instrument'] and e['pitch']==old['pitch']:overlaps.append([old['event_id'],e['event_id']])
                    if e['instrument']==old['instrument']=='piano' and e['hand']==old['hand'] and e['finger']==old['finger']:collisions.append([old['event_id'],e['event_id']])
                active[i]=e
        if had and not active:silent_from=t
        if active and silent_from is not None:
            if t>silent_from:silences.append(seconds(t)-seconds(silent_from))
            silent_from=None
        foreground.append(sum(e['role']=='lead' for e in active.values()))
        hands={h:[e for e in active.values() if e['instrument']=='piano' and e['hand']==h] for h in attacks}
        for h,es in hands.items():
            if es:
                ps=[e['pitch'] for e in es];maxspan[h]=max(maxspan[h],max(ps)-min(ps));maxkeys[h]=max(maxkeys[h],len(ps))
                if t in attacks[h]:snapshot[h][t]=es.copy()
        if all(hands.values()) and max(e['pitch'] for e in hands['left'])>=min(e['pitch'] for e in hands['right']):crossings.append(t)
    ck(not overlaps,'same-key overlap');ck(not collisions,'finger collision');ck(not crossings,'hand crossing')
    ck(max(maxspan.values())<=12 and max(maxkeys.values())<=5,'actual held-hand geometry')
    ck(max(foreground)==1,'one nonoverlapping foreground voice')
    ck(max(silences,default=0)<=.32,'no silence padding')
    transfers=[]
    for hand,bytime in attacks.items():
        groups=sorted(bytime.items());latest_release=0
        for index,(t,new) in enumerate(groups):
            if index:
                oldt,previous=groups[index-1];old=snapshot[hand][oldt]
                oldkeys=[e['pitch'] for e in old];newkeys=[e['pitch'] for e in snapshot[hand][t]]
                oldgrip=[min(oldkeys),max(oldkeys)];newgrip=[min(newkeys),max(newkeys)]
                op=plans[(previous[0]['bar'],hand)];np=plans[(new[0]['bar'],hand)];changed=op['position_id']!=np['position_id']
                edge=max(abs(a-b) for a,b in zip(oldgrip,newgrip))
                held_movement=max(abs(a-b) for a in oldkeys for b in newkeys)
                position_edge=max(abs(a-b) for a,b in zip(op['range'],np['range'])) if changed else 0
                travel=max(edge,held_movement,position_edge);required=.075+.012*max(0,travel-4);available=seconds(t)-seconds(latest_release)
                row={'hand':hand,'from_beat':oldt,'to_beat':t,'old_grip':oldgrip,'new_grip':newgrip,'old_position':op['range'],'new_position':np['range'],
                     'whole_position_changed':changed,'grip_edge_semitones':edge,'actual_held_key_movement_semitones':held_movement,'position_edge_semitones':position_edge,
                     'checked_travel_semitones':travel,'last_prior_key_release_beat':latest_release,'available_seconds':round(available,9),
                     'required_seconds':round(required,9),'margin_seconds':round(available-required,9),'passed':available+1e-7>=required}
                transfers.append(row);ck(row['passed'],f'strict complete release {hand} at beat {t}')
            # Never replace this with previous-onset + shortest gate: an older
            # held note must continue to block the hand until its real release.
            latest_release=max(latest_release,*(end(e) for e in new))
    lead=[e for e in notes if e['role']=='lead']
    for n,b in enumerate(bars,1):
        es=[e for e in lead if e['bar']==n];ss=[e for e in notes if e['bar']==n and e['role']!='lead'];cursor=b['start']
        ck(es and all(e['instrument']=='piano' for e in es),'piano foreground each bar')
        ck(max(e['velocity'] for e in ss)<=min(e['velocity'] for e in es)-10,'foreground velocity hierarchy '+str(n))
        for e in es:ck(abs(e['onset']-cursor)<1e-6,'written rhythm '+str(n));cursor+=e['written_value_beats']
        ck(abs(cursor-b['start']-4)<1e-6,'four written beats '+str(n))
        ce=[e for e in cello if e['bar']==n];lh=[e for e in piano if e['bar']==n and e['hand']=='left']
        ck(bool(ce)==b['cello_active'] and len(ce)<=1,'sparse scored cello activity')
        ck(all(abs(c['onset']-l['onset'])>=.45 for c in ce for l in lh),'cello / LH attack separation')
    gaps=[seconds(b['onset'])-seconds(end(a)) for a,b in zip(cello,cello[1:])]
    ck(min(gaps)>.6 and max(gaps)>=7,'real cello rest space')
    ck(20<=len(cello)<=44,'sparse cello event count')
    ck({e['sample_layer'] for e in cello}=={'mf'},'only mf source layer throughout')
    ck(sum(not b['cello_active'] for b in bars)>=36,'at least 36 fully unplayed cello bars')
    phrases={p['phrase_id']:p for p in s['phrases']};ck(len(phrases)==20,'20 instrument phrase records')
    for pid,p in phrases.items():
        es=[e for e in notes if e['phrase_id']==pid]
        ck(es and all(p['first_bar']<=e['bar']<=p['last_bar'] for e in es),'phrase membership')
        ck(abs(p['target_on_beats']-min(e['onset'] for e in es))<1e-6 and abs(p['target_off_beats']-max(end(e) for e in es))<1e-6,'phrase beat coverage')
        ck(abs(seconds(p['target_on_beats'])-p['target_on_seconds'])<1.1e-6 and abs(seconds(p['target_off_beats'])-p['target_off_seconds'])<1.1e-6,'phrase time coverage')
    signatures=[tuple((round(e['onset']-i*32,6),e['pitch'],e['written_value_beats']) for e in lead if i*8<e['bar']<=i*8+8) for i in range(10)]
    ck(len(set(signatures))==10,'all ten eight-bar sentences distinct')
    middle=[e for e in lead if 33<=e['bar']<=48];ck(any(e['pitch']%12==4 for e in middle) and not any(e['pitch']%12==3 for e in middle),'audible E natural and no E flat in major middle')
    ck(bars[-2]['harmony_name']=='G7' and bars[-1]['harmony_name']=='Cm','dominant to minor tonic ending')
    ck(lead[-1]['pitch']==72 and end(lead[-1])==320,'final C5 reaches final boundary')
    pedals=s['pedals'];ck(pedals==sorted(pedals,key=lambda p:p['onset']),'pedal order')
    ck(all(p['controller']==64 and p['instrument']=='piano' and 0<=p['onset']<=320 and 0<=p['value']<=30 for p in pedals),'light pedal bounds')
    ck(pedals[-1]['onset']==320 and pedals[-1]['value']==0,'final pedal off')
    return {'passed':not errors,'errors':errors,'event_count':len(notes),'bars':80,'total_quarter_beats':320,'duration_with_tail_seconds':round(seconds(320)+4,6),
      'maximum_held_span_semitones':maxspan,'maximum_simultaneous_keys':maxkeys,'same_key_overlap_count':len(overlaps),'finger_collision_count':len(collisions),'hand_crossing_count':len(crossings),
      'maximum_simultaneous_foreground_notes':max(foreground),'piano_pitch_range':[min(e['pitch'] for e in piano),max(e['pitch'] for e in piano)],
      'left_hand_pitch_range':[min(e['pitch'] for e in piano if e['hand']=='left'),max(e['pitch'] for e in piano if e['hand']=='left')],
      'cello_pitch_range':[min(e['pitch'] for e in cello),max(e['pitch'] for e in cello)],'cello_event_count':len(cello),'cello_layers':['mf'],
      'cello_silent_bars':[b['bar'] for b in bars if not b['cello_active']],'minimum_cello_release_gap_seconds':round(min(gaps),9),'maximum_cello_release_gap_seconds':round(max(gaps),9),
      'cello_gate_seconds_range':[min(e['nominal_gate_seconds'] for e in cello),max(e['nominal_gate_seconds'] for e in cello)],
      'maximum_physical_key_silence_seconds':round(max(silences,default=0),9),'minimum_piano_key_gate_seconds':round(min(seconds(end(e))-seconds(e['onset']) for e in piano),9),
      'unique_eight_bar_phrases':len(set(signatures)),'strict_transfer_count':len(transfers),'minimum_transfer_margin_seconds':min(r['margin_seconds'] for r in transfers),'strict_transfers':transfers,
      'limits':'Symbolic note, timing, hand geometry and source-intent checks only. Sample sound, perceived balance and comfort are not certified.'}

def patch_apply(original,ops):
    result=copy.deepcopy(original)
    for op in ops:
        keys=[s.replace('~1','/').replace('~0','~') for s in op['path'].split('/')[1:]]
        if not keys:result=copy.deepcopy(op['value']);continue
        dest=result
        for k in keys[:-1]:dest=dest[int(k)] if isinstance(dest,list) else dest[k]
        key=int(keys[-1]) if isinstance(dest,list) else keys[-1]
        if op['op']=='remove':del dest[key]
        else:dest[key]=copy.deepcopy(op['value'])
    return result
def verify_diff(a,b,d):
    errors=[];expected=[];musical=[];dimensions={'foreground_pitch':[],'written_rhythm':[],'actual_harmony_pitches':[],'texture':[]}
    core=lambda es:[{k:e[k] for k in ('onset','duration','pitch','instrument','voice','hand')} for e in es]
    for n in range(1,81):
        row={'bar':n,'before_bar':a['bars'][n-1],'after_bar':b['bars'][n-1],
          'before_events':[e for e in a['events'] if e['bar']==n],'after_events':[e for e in b['events'] if e['bar']==n],
          'before_pedals':[e for e in a['pedals'] if e['bar']==n],'after_pedals':[e for e in b['pedals'] if e['bar']==n]}
        if any(row['before_'+k]!=row['after_'+k] for k in ('bar','events','pedals')):expected.append(row)
        if core(row['before_events'])!=core(row['after_events']) or row['before_bar']['harmony']!=row['after_bar']['harmony']:musical.append(n)
        for dimension,keys in [('foreground_pitch',('pitch',)),('written_rhythm',('onset','written_value_beats'))]:
            if [tuple(e[k] for k in keys) for e in row['before_events'] if e['role']=='lead']!=[tuple(e[k] for k in keys) for e in row['after_events'] if e['role']=='lead']:dimensions[dimension].append(n)
        if row['before_bar']['harmony']!=row['after_bar']['harmony']:dimensions['actual_harmony_pitches'].append(n)
        if row['before_bar']['texture']!=row['after_bar']['texture']:dimensions['texture'].append(n)
    if expected!=d['changes'] or [r['bar'] for r in expected]!=d['changed_bars']:errors.append('exact per-bar changes')
    if len(musical)<16 or any(len(rows)<4 for rows in dimensions.values()):errors.append('substantive revision dimensions')
    for label,s in [('before',a),('after',b)]:
        if d[label+'_sha256']!=sha(f'score_{s["version"]}.json'):errors.append('version file hash')
        if d['phrase_metadata_'+label]!=s['phrases'] or d['position_plan_'+label]!=s['hand_position_plan']:errors.append('exact metadata')
    reconstructed=patch_apply(a,d['json_patch'])==b
    if not reconstructed:errors.append('JSON patch reproduction')
    before=(ROOT/f'score_{a["version"]}.json').read_text();after=(ROOT/f'score_{b["version"]}.json').read_text()
    exact=''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile=f'score_{a["version"]}.json',tofile=f'score_{b["version"]}.json'))
    text_ok=(ROOT/f'exact_diff_{a["version"]}_to_{b["version"]}.patch').read_text()==exact
    if not text_ok:errors.append('literal unified text patch')
    return {'passed':not errors,'errors':errors,'changed_bars':d['changed_bars'],'strict_musical_changed_bars':musical,'strict_musical_changed_bar_count':len(musical),
      'changed_bars_by_musical_dimension':dimensions,'full_document_patch_reconstructs_next_version':reconstructed,'exact_text_patch_matches':text_ok}

def mutation_tests(final):
    cases={}
    bad=copy.deepcopy(final);e=next(x for x in bad['events'] if x['instrument']=='cello');e['sample_layer']='pp';cases['invented_cello_layer_rejected']=not inspect(bad)['passed']
    bad=copy.deepcopy(final);e=next(x for x in bad['events'] if x['instrument']=='piano' and x['hand']=='right');e['duration']=1.49;e['target_off_beats']=e['onset']+e['duration'];cases['retained_physical_key_rejected']=not inspect(bad)['passed']
    bad=copy.deepcopy(final);e=next(x for x in bad['events'] if x['instrument']=='piano' and x['hand']=='left');e['pitch']=47;cases['left_hand_entering_cello_octave_rejected']=not inspect(bad)['passed']
    return cases
def main():
    scores={v:load(f'score_{v}.json') for v in ('v0','v1','v2')};audits={v:inspect(s) for v,s in scores.items()}
    for v,a in audits.items():save(f'audit_{v}.json',a)
    diffs={f'{a}_to_{b}':verify_diff(scores[a],scores[b],load(f'exact_diff_{a}_to_{b}.json')) for a,b in [('v0','v1'),('v1','v2')]}
    with tempfile.TemporaryDirectory(prefix='.reproduction_',dir=ROOT) as temp:
        subprocess.run([sys.executable,str(ROOT/'generate_score.py'),'--outdir',temp],check=True,capture_output=True)
        reproduction={p.name:(ROOT/p.name).read_bytes()==p.read_bytes() for p in sorted(Path(temp).iterdir()) if p.is_file()}
    save('reproducibility_check.json',{'passed':all(reproduction.values()),'byte_identical_files':reproduction,'method':'Fresh Python process, new directory, no generator import by checker, byte-for-byte saved artifact comparison.'})
    selected=(ROOT/'score.json').read_bytes()==(ROOT/'score_v2.json').read_bytes();mutations=mutation_tests(scores['v2'])
    fields=('passed','errors','event_count','duration_with_tail_seconds','maximum_held_span_semitones','maximum_simultaneous_keys','same_key_overlap_count','finger_collision_count','hand_crossing_count','cello_event_count','strict_transfer_count','minimum_transfer_margin_seconds','unique_eight_bar_phrases','maximum_physical_key_silence_seconds')
    report={'passed':selected and all(a['passed'] for a in audits.values()) and all(d['passed'] for d in diffs.values()) and all(reproduction.values()) and all(mutations.values()),
      'selected_equals_v2_byte_for_byte':selected,'selected_score_sha256':sha('score.json'),'version_summaries':{v:{k:a[k] for k in fields} for v,a in audits.items()},
      'revision_checks':diffs,'mutation_rejections':mutations,'reproducibility_passed':all(reproduction.values()),'scope':'Saved-file symbolic constraints, substantive revisions and deterministic fresh-process reproduction. No audio or listening performed.'}
    save('independent_verification.json',report)
    files={p.name:{'bytes':p.stat().st_size,'sha256':sha(p.name)} for p in sorted(ROOT.iterdir()) if p.is_file() and p.name!='hash_manifest.json'}
    save('hash_manifest.json',{'algorithm':'SHA-256','files':files,'excludes_self':True,'scope':'Every regular file in this isolated symbolic draft directory.'})
    print(json.dumps(report,ensure_ascii=False,indent=2))
    if not report['passed']:raise SystemExit(1)
if __name__=='__main__':main()
