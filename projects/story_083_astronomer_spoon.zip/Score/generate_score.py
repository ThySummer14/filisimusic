#!/usr/bin/env python3
"""Original work 083. Standard library only; symbolic scores, no audio or MIDI."""
from __future__ import annotations
import collections
import copy
import difflib
import hashlib
import json
from pathlib import Path

OUT = Path(__file__).resolve().parent
BAR = 3.5
TAIL = 6

# Harmonic spellings are concert pitch. The list gives a bass and a compact
# right-hand voicing; a voiced sonority is a pitch collection, not a MIDI event.
H = {
    'Eadd9': (40, [59, 64, 66, 68]), 'E': (40, [59, 64, 68]),
    'E/G#': (44, [59, 64, 68]), 'B6/D#': (39, [59, 63, 68]),
    'Amaj7': (45, [61, 64, 68]), 'Bsus': (47, [61, 64, 66]),
    'B7': (47, [57, 63, 66]), 'Badd9': (47, [61, 63, 66]),
    'B': (47, [59, 63, 66]), 'C#m7': (49, [59, 61, 64, 68]),
    'C#m9': (49, [59, 63, 64, 68]), 'G#m7': (44, [59, 63, 66]),
    'F#m7': (42, [57, 61, 64]), 'F#7': (42, [58, 61, 64]),
    'F#sus': (42, [59, 61, 64]), 'Am6': (45, [60, 64, 66]),
    'E/B': (47, [59, 64, 68]), 'G#7': (44, [60, 63, 66]),
    'D#dim7': (39, [57, 60, 66]), 'Cmaj7': (48, [59, 64, 67]),
    'Am7': (45, [60, 64, 67]), 'F#half': (42, [57, 60, 64]),
    'Cmaj7#11': (48, [59, 64, 66]), 'A6': (45, [61, 64, 66]),
    'Dmaj7': (38, [57, 61, 66]), 'F#m9': (42, [57, 61, 68]),
    'D#half': (39, [57, 61, 66]), 'G#7b9': (44, [60, 63, 69]),
    'C#m': (49, [61, 64, 68]), 'Emaj9/D#': (39, [59, 64, 66, 68]),
    'A/E': (40, [57, 61, 64]), 'E6': (40, [59, 61, 68]),
}

# Each unit is an individually composed four-bar sentence, never a repeat-loop.
# Positions are absolute within its 14 quarter-note beats.
UNITS = [
 dict(label='seven_calibrations', title='七项校准', sec='A', bpm=84,
      harm=['Eadd9','B6/D#','Amaj7','Bsus'], lead='CCCC', group='2+2+3',
      co=[.25,1,2,2.75,3.75,4.5,5.5,6.5,7.5,8.5,9.5,10.75,12],
      cp=[64,68,69,68,66,71,70,71,68,69,66,63,64], dyn='mf'),
 dict(label='catalogue_of_brass', title='黄铜器具的名单', sec='A', bpm=84,
      harm=['E/G#','C#m7','F#7','Badd9'], lead='PPPC', group='2+2+3',
      co=[10.75,11.75,12.75],cp=[68,66,63],dyn='pp',
      po=[0,.5,.75,1.5,2,2.5,3,3.5,4.25,5,6,6.5,7,7.5,8.25,9.25],
      pp=[64,68,69,68,66,68,71,69,68,64,63,64,66,70,69,66]),
 dict(label='clock_against_sky', title='钟声追赶天空', sec='A', bpm=84,
      harm=['B','G#m7','C#m9','F#m7'],lead='CCCC',group='2+2+3',
      co=[.25,1.25,2.5,3.5,4.5,5.5,6.25,7.25,8.75,10,11.25,12.25],
      cp=[66,71,69,68,66,63,66,68,64,63,61,66],dyn='mf'),
 dict(label='tightening_the_wrong_screw',title='拧错的螺丝',sec='A',bpm=84,
      harm=['Amaj7','Am6','E/B','B7'],lead='PPCC',group='2+2+3',
      co=[7.25,8.25,9.5,10.75,12.25],cp=[68,66,64,66,63],dyn='mf',
      po=[0,.5,1,1.5,2.25,3,3.5,4,4.5,5.25,6.25],
      pp=[69,68,66,64,61,64,69,67,66,64,60]),
 dict(label='brass_turntable_seizes',title='转台咬死',sec='B',bpm=94,
      harm=['F#7','B7','G#7','C#m7'],lead='PPCC',group='2+3+2',
      co=[7.25,8.25,9.25,10.75,11.5,12.5],cp=[68,66,63,64,63,61],dyn='mf',
      po=[0,.25,.5,1.5,2.5,3,3.5,4,4.25,5.25,6.25],
      pp=[66,70,71,70,66,61,63,66,68,66,63]),
 dict(label='spring_under_floorboards',title='游丝落进地缝',sec='B',bpm=94,
      harm=['D#dim7','G#7b9','C#m','F#7'],lead='CCCC',group='2+3+2',
      co=[.25,1.25,2.25,3.75,4.75,5.75,7,8,9.25,10.75,12.25],
      cp=[66,69,66,63,60,63,64,68,71,70,66],dyn='mf'),
 dict(label='blank_logbook',title='空白的观测表',sec='B',bpm=94,
      harm=['B7','E/B','Am6','B7'],lead='PPPC',group='2+3+2',
      co=[11,12.25],cp=[64,63],dyn='pp',
      po=[0,.25,1,2.5,3.5,4.25,5.5,7,7.5,9.25],
      pp=[71,70,66,63,68,66,64,60,64,66]),
 dict(label='the_small_hole',title='勺柄上的小孔',sec='C',bpm=78,
      harm=['E','Amaj7','F#m7','B7'],lead='CCCC',group='2+2+3',
      co=[.25,1.25,2.5,3.75,5,6.25,7.5,9,10.5,12],
      cp=[64,68,69,68,66,64,61,64,66,63],dyn='pp'),
 dict(label='white_flour_paper',title='白色面粉袋',sec='C',bpm=78,
      harm=['E/G#','Amaj7','F#7','B7'],lead='CCCC',group='2+2+3',
      co=[.25,1.25,2.25,3.75,5,6.25,7.25,8.75,10.25,12],
      cp=[68,66,64,66,69,68,66,70,69,66],dyn='pp'),
 dict(label='distance_four_tiles',title='四块地砖的距离',sec='C',bpm=78,
      harm=['C#m7','F#m7','Badd9','E'],lead='CCCC',group='2+2+3',
      co=[.25,1.25,2.5,3.75,5.25,6.5,7.75,9,10.5,12],
      cp=[64,68,71,68,66,64,63,66,68,64],dyn='pp'),
 dict(label='turn_the_spoon',title='把勺子转半圈',sec='C',bpm=78,
      harm=['Amaj7','F#7','B7','E'],lead='PPCC',group='2+2+3',
      co=[7.25,8.5,10.75,12],cp=[66,63,64,68],dyn='pp',
      po=[0,1,2,3,3.5,4.5,5.75],pp=[69,68,64,61,66,70,69]),
 dict(label='crescent_crosses_paper',title='月牙越过纸面',sec='D',bpm=88,
      harm=['C#m','F#m9','D#half','G#7'],lead='CCCC',group='2+3+2',
      co=[.25,1.25,2.75,3.75,5.25,6.25,7.25,8.75,10,11,12.25],
      cp=[64,63,61,64,68,66,63,66,69,68,63],dyn='mf'),
 dict(label='follow_the_moving_center',title='追上移动的圆心',sec='D',bpm=88,
      harm=['C#m7','F#7','B7','E/B'],lead='PPCC',group='2+3+2',
      co=[7.25,8.25,9.5,10.75,12.25],cp=[66,69,68,66,64],dyn='mf',
      po=[0,.75,1.5,2.25,3,3.5,4.25,5,6.25],pp=[64,63,61,63,64,66,70,69,66]),
 dict(label='greatest_bite',title='最大的缺口',sec='D',bpm=88,
      harm=['F#sus','F#7','Bsus','B7'],lead='CCCC',group='2+3+2',
      co=[.25,1.25,2.75,4,5.25,6.25,7.25,8.5,10,11.25,12.25],
      cp=[66,68,71,70,66,64,66,69,66,64,63],dyn='mf'),
 dict(label='measuring_theme_returns',title='测量的主题回来',sec='R',bpm=88,
      harm=['Eadd9','B6/D#','A6','Badd9'],lead='CCCC',group='2+2+3',
      co=[.25,1,2,2.75,3.75,4.5,5.5,6.5,7.5,8.5,9.5,10.75,12],
      cp=[64,68,69,68,66,71,70,71,68,69,66,63,64],dyn='mf'),
 dict(label='a_shorter_inventory',title='更短的清单',sec='R',bpm=88,
      harm=['E/G#','C#m7','F#m7','B7'],lead='CCCC',group='2+2+3',
      co=[.25,1.25,2.5,3.75,5,6.25,7.5,8.5,10,11.25,12.25],
      cp=[68,71,69,68,64,63,61,64,66,69,66],dyn='mf'),
 dict(label='measure_without_boasting',title='不夸口的测量',sec='R',bpm=88,
      harm=['E/G#','Amaj7','F#m7','Eadd9'],lead='CCCC',group='2+2+3',
      co=[.25,1.25,2.5,3.75,5.25,6.25,7.75,9,10.5,12],
      cp=[68,69,71,69,68,66,64,61,66,64],dyn='mf'),
 dict(label='write_approximately',title='写上大约二字',sec='R',bpm=88,
      harm=['Amaj7','Am6','E/B','B7'],lead='PPCC',group='2+2+3',
      co=[7.25,8.25,9.5,10.75,12],cp=[68,66,64,66,63],dyn='pp',
      po=[0,.5,1.5,2.5,3.5,4.5,5.25,6.25],pp=[69,68,66,64,67,66,64,60]),
 dict(label='return_the_spoon',title='把木勺还回去',sec='K',bpm=74,
      harm=['E','C#m7','F#m7','B7'],lead='CCCC',group='2+2+3',
      co=[.25,1.25,2.25,3.75,5,6.25,7.5,8.5,10,11.25,12.25],
      cp=[64,68,71,69,68,64,61,64,66,69,66],dyn='pp'),
 dict(label='luncheon_final_measure',title='午饭前的最后测量',sec='K',bpm=74,
      harm=['E/G#','Amaj7','B7','E'],lead='PPCC',group='2+2+3',
      co=[7.25,8.25,9.5,10.75,12],cp=[66,69,66,63,64],dyn='pp',
      po=[0,.5,1.5,2.5,3.5,4.5,5.25,6.25],pp=[64,68,71,68,69,68,66,64]),
]

def configuration(version):
    u = copy.deepcopy(UNITS)
    if version >= 1:
        # Revision 1: replace the entire spoon episode's tonal/rhythmic premise,
        # give the piano two real presentations, and alter eclipse development.
        u[7].update(harm=['Cmaj7','Am6','F#half','B7'],group='3+2+2',
            co=[.25,1.75,3,4.5,6,7.5,9,10.5,12],
            cp=[64,67,69,67,64,62,64,66,63])
        u[8].update(harm=['Cmaj7#11','Am7','F#half','B7'],group='3+2+2',lead='PPCC',
            po=[0,1.5,2.5,3.5,5,6],pp=[64,67,69,67,64,62],register=0,
            co=[7.25,8.75,10.5,12],cp=[60,64,66,63])
        u[9].update(harm=['Eadd9','A6','F#m7','Emaj9/D#'],group='3+2+2',
            co=[.25,1.75,3.25,5,6.5,8.25,10.25,12],
            cp=[64,68,66,64,69,68,66,63])
        u[10].update(harm=['A6','Am6','E/B','B7'],group='3+2+2',lead='PPPC',
            po=[0,1.5,2.5,3.5,5,6,7.25,8.5,9.5],
            pp=[64,68,66,64,67,66,64,68,66],register=0,
            co=[10.75,12.25],cp=[64,63])
        u[12].update(harm=['C#m7','Dmaj7','F#half','B7'],
            po=[0,.75,1.5,2.25,3,3.5,4.25,5,6.25],
            pp=[68,67,66,64,63,61,64,66,69],
            cp=[69,66,64,63,66])
        u[14].update(co=[.25,1.25,2.5,3.75,5.25,6.5,7.75,9.25,11,12.25],
            cp=[64,68,69,68,66,71,69,68,66,64])
        u[16].update(group='3+2+2',harm=['E/G#','Amaj7','F#m9','Eadd9'],
            co=[.25,1.75,3.25,5,6.5,8.25,10.25,12],
            cp=[64,68,71,69,68,66,64,66])
    if version >= 2:
        # Revision 2: lengthen the opening breath, change the transfer after
        # the seized screw, and replace eight-bar closure with a shared answer.
        u[0].update(co=[.25,1.25,2.5,3.75,5,6,7.25,8.5,10,11.25,12.25],
            cp=[64,68,69,68,66,71,70,71,68,66,64])
        u[3].update(harm=['Amaj7','Am6','E/B','Badd9'],
            co=[7.25,8.75,10.5,12],cp=[68,64,66,63],
            po=[0,.5,1,1.5,2.5,3,3.5,4.5,5.25,6.25],
            pp=[69,68,66,64,61,64,67,66,64,60])
        u[5]['ff_indices'] = [7,8]
        u[6].update(harm=['B7','E/B','Am6','Badd9'],
            po=[0,.25,1,2.5,3.5,4.75,6,7.25,8.5],
            pp=[71,70,66,63,68,64,60,64,66],
            co=[10.75,12],cp=[64,63])
        u[15].update(lead='PPCC',
            co=[7.25,8.75,10.5,12.25],cp=[61,64,66,63],
            po=[0,.5,1.25,2,3,3.75,5,6.25],
            pp=[64,68,69,68,66,68,64,63])
        u[17].update(harm=['A6','Am6','Eadd9','Badd9'],group='3+2+2',
            co=[7.25,9.25,11.25],cp=[64,68,66],
            po=[0,1.5,2.5,3.5,5,6],pp=[64,68,69,68,66,64])
        u[18].update(harm=['E6','A/E','Eadd9','Eadd9'],lead='CCCP',group='3+2+2',
            co=[.25,3.75,7.5],cp=[64,68,66],
            po=[10.5,11.75,12.75],pp=[64,68,66],register=0)
        u[19].update(harm=['Eadd9','E6','Eadd9','Eadd9'],lead='PCCP',group='3+2+2',
            co=[3.75,7.25],cp=[68,66],po=[0],pp=[64],register=0)
    return u

def rounded(value):
    return round(value,6)

def seconds_at(beat, bars):
    elapsed=0.
    for b in bars:
        if beat >= b['start']+b['beats']:
            elapsed += b['beats']*60/b['bpm']
        else:
            return elapsed + max(0,beat-b['start'])*60/b['bpm']
    return elapsed

def make_score(version):
    units=configuration(version)
    bars=[]; events=[]; pedals=[]; phrases=[]
    for ui,u in enumerate(units):
        for j in range(4):
            bn=ui*4+j+1; bass,voicing=H[u['harm'][j]]
            bars.append(dict(bar=bn,start=rounded((bn-1)*BAR),beats=BAR,
                bpm=u['bpm'],meter='7/8',meter_numerator=7,meter_denominator=8,
                section=u['sec'],section_title_zh=u['title'],grouping=u['group'],
                harmony_name=u['harm'][j],harmony=[bass]+voicing,
                lead_instrument='clarinet' if u['lead'][j]=='C' else 'piano',
                role_plan=('Clarinet sentence over quiet shared harmonic pulse.' if u['lead'][j]=='C'
                           else 'Piano carries the foreground; clarinet rests or answers only at the transfer.'),
                phrase_id=f'S{ui+1:02}'))
    def event(on,dur,pitch,velocity,instrument,voice,role,phrase,hand=None,layer=None,art='separate_attack'):
        bn=min(80,int((on+1e-8)//BAR)+1)
        e=dict(bar=bn,onset=rounded(on),duration=rounded(dur),pitch=pitch,
            velocity=velocity,instrument=instrument,voice=voice,role=role,
            phrase_id=phrase,onset_reference='ordinary_trigger',articulation=art)
        if hand is not None:e['hand']=hand
        if instrument=='clarinet':
            e.update(layer=layer,sample_layer='Iowa_clarinet_'+layer,
                velocity_controls='select_genuine_recorded_layer_then_within_layer_gain')
        else:e['sample_layer']='approved_natural_piano'
        events.append(e)
    for ui,u in enumerate(units):
        origin=ui*14; phrase=f'S{ui+1:02}'
        # One clarinet voice; inter-note gaps are written into every sentence.
        for i,(o,p) in enumerate(zip(u['co'],u['cp'])):
            nxt=u['co'][i+1] if i+1<len(u['co']) else 13.35
            gate=min(2.05,nxt-o-.13)
            if version==2 and ui>=18:gate=min(2.05,nxt-o-.24)
            layer='ff' if i in u.get('ff_indices',[]) else u['dyn']
            vel={'pp':48,'mf':69,'ff':102}[layer]+((i+ui)%3-1)*2
            event(origin+o,gate,p,vel,'clarinet','clarinet_melody','lead',
                  phrase+'_clarinet',layer=layer,art='distinct_breathed_note')
        # Piano foreground is explicitly composed, never improvised by a loop.
        for i,(o,p) in enumerate(zip(u.get('po',[]),u.get('pp',[]))):
            nexto=u['po'][i+1] if i+1<len(u['po']) else min(13.5,((int(o//BAR)+1)*BAR))
            gate=min(.91,max(.14,nexto-o-.07))
            p+=u.get('register',12)
            vel=(51 if u['sec']=='K' else 60 if u['sec']=='C' else 70)+((i+ui)%3-1)*3
            event(origin+o,gate,p,vel,'piano','melody','lead',phrase+'_piano','right',art='light_precise')
        # The accompaniment follows the harmonic sentence and its changing 7/8
        # grouping. Each gesture changes with register, harmony and foreground.
        for j in range(4):
            b=bars[ui*4+j]; start=b['start']; bass,voicing=H[u['harm'][j]]
            c_lead=u['lead'][j]=='C'; sparse=(version==2 and ui>=18)
            pulses={'2+2+3':[0,1,2],'3+2+2':[0,1.5,2.5],'2+3+2':[0,1,2.5]}[u['group']]
            base=32 if u['dyn']=='pp' else 39
            if not c_lead:base+=3
            if sparse:base=30
            event(start,.70 if not sparse else 1.10,bass,base+4,'piano','bass','support',phrase+'_piano','left')
            # A fifth/third in the left hand belongs to the same pulse, not an
            # independent ostinato. It stays within a hand's octave.
            if not sparse:
                candidates=sorted({p+12*k for p in voicing for k in range(-3,1)
                                   if bass+2<=p+12*k<=bass+12})
                comfortable=[p for p in candidates if p<=52]
                second=min(comfortable or candidates,key=lambda p:abs(p-(bass+7)))
                event(start+pulses[2],.67,second,base,'piano','harmonic_pulse','support',phrase+'_piano','left')
            if c_lead:
                ix=(ui+j)%max(1,len(voicing)-1)
                chord=voicing[ix:ix+2]
                if len(chord)<2:chord=voicing[-2:]
                dur=.62 if u['sec']=='B' else .80
                if sparse:chord=voicing[-2:];dur=1.08
                for p in chord:
                    event(start+pulses[1],dur,p,base-2,'piano','shared_harmony','support',phrase+'_piano','right')
            # The final piano sonority is deliberately harmonic punctuation;
            # it adds no fourth melodic note to the E-G#-F# answer.
            if version==2 and ui==19 and j==3:
                for p in [59,64,68]:
                    event(start+.15,2.65,p,32,'piano','closing_harmony','lead',phrase+'_piano','right',art='quiet_final_chord')
            # Pedal never carries into a changed harmony. Deeper pedal appears
            # only in the unhurried spoon/closing scene, then explicitly lifts.
            value=76 if (u['sec']=='C' and j in (0,2)) or (sparse and j in (0,3)) else 42
            pedals.extend([dict(onset=rounded(start+.10),value=value,instrument='piano',controller=64,bar=b['bar']),
                           dict(onset=rounded(start+(3.30 if sparse else 3.18)),value=0,instrument='piano',controller=64,bar=b['bar'])])
        for inst in ['clarinet','piano']:
            pe=[e for e in events if e['phrase_id']==phrase+'_'+inst]
            if pe:
                phrases.append(dict(phrase_id=phrase+'_'+inst,phrase_label=u['label'],title_zh=u['title'],
                    first_bar=ui*4+1,last_bar=ui*4+4,instrument=inst,section=u['sec'],
                    target_on_beats=min(e['onset'] for e in pe),
                    target_off_beats=max(e['onset']+e['duration'] for e in pe),
                    layers_used=sorted({e.get('layer','natural_piano') for e in pe}),
                    foreground_bars=[ui*4+j+1 for j,c in enumerate(u['lead']) if (c=='C')==(inst=='clarinet')],
                    timing_intent=('Connected musical sentence made of distinct ordinary sample attacks, with a written breath after the sentence.' if inst=='clarinet' else 'Shared metrical groups and harmonic support; foreground only in assigned handoffs.')))
    events.sort(key=lambda e:(e['onset'],e['instrument'],e['pitch']))
    for i,e in enumerate(events):e['event_id']=f'w83-v{version}-{i+1:04}'
    for p in phrases:
        p['target_on_seconds']=rounded(seconds_at(p['target_on_beats'],bars))
        p['target_off_seconds']=rounded(seconds_at(p['target_off_beats'],bars))
    cp=[p for p in phrases if p['instrument']=='clarinet']
    for a,b in zip(cp,cp[1:]):
        a['breath_to_next_phrase_seconds']=rounded(b['target_on_seconds']-a['target_off_seconds'])
    return dict(id=83,title='The Astronomer’s Wooden Spoon',title_zh='天文学家的木勺',
        version=f'v{version}',instrumentation=['piano','clarinet'],
        bars=bars,events=events,phrases=phrases,pedals=pedals,total_beats=280.0,tail_seconds=TAIL,
        performance_contract={
            'audio_status':'Symbolic draft only. No audio made, rendered or listened to.',
            'beat_unit':'Absolute quarter-note beats; each 7/8 bar is exactly 3.5 quarter beats.',
            'piano_instrument':'Existing approved natural acoustic piano; no new instrument or download.',
            'clarinet_instrument':'Existing genuine University of Iowa clarinet pp/mf/ff recordings; owner verifies asset mapping.',
            'clarinet_register':[60,71],
            'clarinet_layers':{'pp_velocity':[44,52],'mf_velocity':[64,76],'ff_velocity':[96,108]},
            'clarinet_attack':'Ordinary sample triggers with distinct written attacks. No pre-shift, true legato or sample looping.',
            'clarinet_gate_min_seconds':.28,'clarinet_phrase_breath_min_seconds':.30,
            'clarinet_layer_meaning':'pp/mf/ff mean genuine separate recorded layers. Within-layer gain is not another layer.',
            'piano_hand_span_semitones':12,'piano_same_key_overlap':'Forbidden across both hands.',
            'piano_pedal':'Piano CC64 only: 0 release, 42 half, 76 full; clear each harmony and release at end.',
            'tail_seconds':TAIL,
            'balance':'Clarinet foreground gets quiet compact piano harmony; piano foreground is written explicitly and clarinet waits.',
            'nominal_vs_sample':'All gate/breath checks are symbolic. Owner must verify sample coverage, actual attack and release, sounding overlap and audible balance before any audio is accepted.'})

def audit(s):
    errors=[]; bars=s['bars']; es=s['events']; total=s['total_beats']
    def check(ok,msg):
        if not ok:errors.append(msg)
    check(len(bars)==80,'bar count')
    for i,b in enumerate(bars):
        check(b['start']==i*3.5 and b['beats']==3.5 and b['meter_numerator']==7 and b['meter_denominator']==8,f'7/8 bar {i+1}')
    for e in es:
        check(e['duration']>0 and e['onset']>=0 and e['onset']+e['duration']<=total+1e-8,f'event bounds {e["event_id"]}')
        check(e['bar']==min(80,int((e['onset']+1e-8)//BAR)+1),f'event bar {e["event_id"]}')
    cl=[e for e in es if e['instrument']=='clarinet']; pi=[e for e in es if e['instrument']=='piano']
    gates=[seconds_at(e['onset']+e['duration'],bars)-seconds_at(e['onset'],bars) for e in cl]
    gaps=[seconds_at(b['onset'],bars)-seconds_at(a['onset']+a['duration'],bars) for a,b in zip(cl,cl[1:])]
    check(min(gates)>=.28-1e-6,'clarinet short gate');check(min(gaps)>0,'clarinet overlap')
    for e in cl:
        check(60<=e['pitch']<=71,'clarinet register')
        lo,hi={'pp':(44,52),'mf':(64,76),'ff':(96,108)}[e['layer']]
        check(lo<=e['velocity']<=hi,'clarinet layer/velocity mismatch')
    cps=[p for p in s['phrases'] if p['instrument']=='clarinet']
    breaths=[p['breath_to_next_phrase_seconds'] for p in cps if 'breath_to_next_phrase_seconds' in p]
    check(min(breaths)>=.3-1e-6,'short phrase breath')
    spans={}; poly={}; leaps={}; repeated_key=[]
    for hand in ['left','right']:
        he=[e for e in pi if e['hand']==hand]; times=sorted({e['onset'] for e in he})
        maxspan=0;maxpoly=0; move=[]; prev=None
        for t in times:
            active=[e for e in he if e['onset']<=t+1e-8 and e['onset']+e['duration']>t+1e-8]
            pitches=[e['pitch'] for e in active]
            maxspan=max(maxspan,max(pitches)-min(pitches));maxpoly=max(maxpoly,len(pitches))
            new=[e['pitch'] for e in he if abs(e['onset']-t)<1e-8]
            center=sum(new)/len(new)
            if prev:
                elapsed=seconds_at(t,bars)-seconds_at(prev[0],bars)
                released=seconds_at(t,bars)-seconds_at(prev[2],bars)
                semis=abs(center-prev[1]);move.append((semis,elapsed,released))
                # Measured from release, not merely the preceding onset:
                # over-octave relocations need 0.18 s clear travel time;
                # over-nineteen-semitone relocations need 0.50 s. These are
                # deliberately plain moves between figures, never fast jumps.
                check(semis<=12 or (semis<=19 and released>=.18) or
                      (semis<=28 and released>=.50),f'unprepared {hand} leap {semis} at {t}')
            ending=max(e['onset']+e['duration'] for e in he if abs(e['onset']-t)<1e-8)
            prev=(t,center,ending)
        spans[hand]=maxspan;poly[hand]=maxpoly
        leaps[hand]=dict(maximum_centroid_semitones=rounded(max(x[0] for x in move)),
                         minimum_onset_interval_seconds_for_over_octave=rounded(min([x[1] for x in move if x[0]>12],default=0)),
                         minimum_released_travel_seconds_for_over_octave=rounded(min([x[2] for x in move if x[0]>12],default=0)))
        check(maxspan<=12,f'{hand} held span')
        check(maxpoly<=5,f'{hand} held finger count')
    for p in set(e['pitch'] for e in pi):
        pe=sorted([e for e in pi if e['pitch']==p],key=lambda e:e['onset'])
        for a,b in zip(pe,pe[1:]):
            if a['onset']+a['duration']>b['onset']+1e-8:repeated_key.append((p,a['onset'],b['onset']))
    check(not repeated_key,'same piano key held/restruck overlap')
    foreground_fail=[]
    for b in bars:
        found=[e for e in es if e['instrument']==b['lead_instrument'] and e['role']=='lead' and e['onset']<b['start']+3.5 and e['onset']+e['duration']>b['start']]
        if not found:foreground_fail.append(b['bar'])
    check(not foreground_fail,'missing declared foreground')
    check(all(p['value'] in (0,42,76) and p['instrument']=='piano' for p in s['pedals']),'pedal values')
    check(s['pedals'][-1]['value']==0,'final pedal release')
    runtime=seconds_at(total,bars)+TAIL
    check(195<=runtime<=220,'runtime outside brief')
    fingerprints=[]
    for ui in range(20):
        origin=ui*14
        local=[(rounded(e['onset']-origin),e['duration'],e['pitch'],e['instrument'],e['voice']) for e in es if origin<=e['onset']<origin+14]
        fingerprints.append(hashlib.sha256(json.dumps(local).encode()).hexdigest())
    check(len(set(fingerprints))==20,'identical four-bar loop')
    density={sec:dict(bars=sum(b['section']==sec for b in bars),
        clarinet_notes=sum(e['instrument']=='clarinet' and bars[e['bar']-1]['section']==sec for e in es),
        piano_notes=sum(e['instrument']=='piano' and bars[e['bar']-1]['section']==sec for e in es)) for sec in ['A','B','C','D','R','K']}
    thematic={
        'opening_clarinet':[e['pitch'] for e in cl if 1<=e['bar']<=4],
        'spoon_clarinet':[e['pitch'] for e in cl if 29<=e['bar']<=32],
        'return_clarinet':[e['pitch'] for e in cl if 57<=e['bar']<=60],
        'coda_first_clarinet':[e['pitch'] for e in cl if 73<=e['bar']<=76],
        'last_distributed_answer':[e['pitch'] for e in es if 77<=e['bar']<=79 and e['role']=='lead' and e['voice'] in ('melody','clarinet_melody')]}
    if s['version']=='v2':
        check(thematic['coda_first_clarinet']==[64,68,66],'coda answer not E-G#-F#')
        check(thematic['last_distributed_answer']==[64,68,66],'distributed final answer altered')
        check(sum(e['layer']=='ff' for e in cl)==2,'final ff count')
    return dict(version=s['version'],status='PASS' if not errors else 'FAIL',errors=errors,
        bars=len(bars),total_quarter_beats=total,score_seconds=rounded(runtime-TAIL),
        tail_seconds=TAIL,nominal_runtime_seconds=rounded(runtime),events=len(es),
        instrument_note_counts=dict(collections.Counter(e['instrument'] for e in es)),
        clarinet_range=[min(e['pitch'] for e in cl),max(e['pitch'] for e in cl)],
        clarinet_genuine_layer_note_counts=dict(collections.Counter(e['layer'] for e in cl)),
        clarinet_velocity_ranges={l:[min(e['velocity'] for e in cl if e['layer']==l),max(e['velocity'] for e in cl if e['layer']==l)] for l in sorted({e['layer'] for e in cl})},
        clarinet_min_gate_seconds=rounded(min(gates)),clarinet_max_gate_seconds=rounded(max(gates)),
        clarinet_min_inter_attack_gate_gap_seconds=rounded(min(gaps)),
        clarinet_min_phrase_breath_seconds=rounded(min(breaths)),
        clarinet_phrase_durations_seconds=[rounded(p['target_off_seconds']-p['target_on_seconds']) for p in cps],
        piano_max_held_span_semitones=spans,piano_max_held_notes_per_hand=poly,
        piano_leap_analysis=leaps,piano_same_key_overlap_count=len(repeated_key),
        foreground_bars_without_lead=foreground_fail,
        foreground_bar_counts=dict(collections.Counter(b['lead_instrument'] for b in bars)),
        unique_four_bar_event_fingerprints=len(set(fingerprints)),section_density=density,
        thematic_pitch_evidence=thematic,
        all_pedal_releases_before_next_harmony=all(p['onset']<(p['bar'])*3.5 for p in s['pedals'] if p['value']==0),
        final_pedal_release_beat=s['pedals'][-1]['onset'],
        caveat='Symbolic feasibility only; no samples inspected or audio rendered. Actual sampled releases and musical audibility require owner validation.')

def canonical_event(e):
    return {k:v for k,v in e.items() if k!='event_id'}

def musical_diff(a,b):
    changed=[]
    for x,y in zip(a['bars'],b['bars']):
        n=x['bar']; ae=[canonical_event(e) for e in a['events'] if e['bar']==n];be=[canonical_event(e) for e in b['events'] if e['bar']==n]
        changes={k:{'before':x.get(k),'after':y.get(k)} for k in sorted(set(x)|set(y)) if x.get(k)!=y.get(k)}
        if changes or ae!=be:
            ca=collections.Counter(json.dumps(e,sort_keys=True) for e in ae);cb=collections.Counter(json.dumps(e,sort_keys=True) for e in be)
            changed.append(dict(bar=n,bar_metadata_changes=changes,
                removed_events=[json.loads(e) for e,count in (ca-cb).items() for _ in range(count)],
                added_events=[json.loads(e) for e,count in (cb-ca).items() for _ in range(count)]))
    return dict(from_version=a['version'],to_version=b['version'],
        comparison='Exact symbolic event data excluding only versioned event_id; includes onsets, durations, pitch, velocity, hand, roles and genuine layer.',
        changed_bars=[x['bar'] for x in changed],changed_bar_count=len(changed),
        removed_event_count=sum(len(x['removed_events']) for x in changed),
        added_event_count=sum(len(x['added_events']) for x in changed),changes=changed)

def write_json(path,obj):
    path.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n',encoding='utf8')

def main():
    scores=[make_score(i) for i in range(3)]
    audits=[]
    for i,s in enumerate(scores):
        write_json(OUT/f'score_v{i}.json',s)
        a=audit(s);write_json(OUT/f'audit_v{i}.json',a);audits.append(a)
    diffs=[]
    for i in range(2):
        d=musical_diff(scores[i],scores[i+1]);write_json(OUT/f'diff_v{i}_v{i+1}.json',d)
        diffs.append({k:v for k,v in d.items() if k!='changes'})
        a=(OUT/f'score_v{i}.json').read_text().splitlines(keepends=True)
        b=(OUT/f'score_v{i+1}.json').read_text().splitlines(keepends=True)
        (OUT/f'diff_v{i}_v{i+1}.patch').write_text(''.join(difflib.unified_diff(a,b,fromfile=f'score_v{i}.json',tofile=f'score_v{i+1}.json')),encoding='utf8')
    write_json(OUT/'audit_summary.json',dict(work=83,status='PASS' if all(a['status']=='PASS' for a in audits) else 'FAIL',versions=audits,substantive_diffs=diffs,
        tests_scope='Deterministic symbolic structure, duration, range, dynamics, attacks/breaths, hands, same-key overlaps, roles, pedal and nonidentical sentences. No audio evidence.'))
    # Notes are authored source; they participate in the reproducible manifest.
    names=['generate_score.py','story_zh.txt','music_notes.md','revisions.md']+[f'score_v{i}.json' for i in range(3)]+[f'audit_v{i}.json' for i in range(3)]+['audit_summary.json']+[f'diff_v{i}_v{i+1}.{ext}' for i in range(2) for ext in ['json','patch']]
    hashes={n:hashlib.sha256((OUT/n).read_bytes()).hexdigest() for n in names if (OUT/n).exists()}
    write_json(OUT/'sha256.json',hashes)
    write_json(OUT/'delivery_manifest.json',dict(work=83,title='The Astronomer’s Wooden Spoon',title_zh='天文学家的木勺',
        status='symbolic_only_pending_owner_sample_validation',final_score='score_v2.json',
        final_score_sha256=hashes['score_v2.json'],version_scores=[f'score_v{i}.json' for i in range(3)],
        final_nominal_runtime_seconds=audits[2]['nominal_runtime_seconds'],
        files_sha256=hashes,restrictions_observed=['No downloads','No new instruments','No audio','No render','No installation','No publication'],
        owner_next_step='Validate existing Iowa genuine pp/mf/ff samples, range coverage, nominal-gate behavior and actual release; then integrate only through the already authorized parent workflow.'))
    print(json.dumps(dict(status=[a['status'] for a in audits],errors=[a['errors'] for a in audits],
        score_v2_sha256=hashes['score_v2.json'],runtime=audits[2]['nominal_runtime_seconds'],
        changed_bars=[d['changed_bar_count'] for d in diffs]),ensure_ascii=False))
    if any(a['errors'] for a in audits):raise SystemExit(1)

if __name__=='__main__':main()
