from pathlib import Path
import json,wave,bisect,numpy as np
P=Path(__file__).parent;d=json.loads((P/'ensemble_score.json').read_text());bars=d['bars'];starts=[b['start'] for b in bars];times=[];t=0
for b in bars:times.append(t);t+=b['beats']*60/b['bpm']
def sec(x):
 i=max(0,bisect.bisect_right(starts,x)-1);return times[i]+(x-starts[i])*60/bars[i]['bpm']
e=sorted([x for x in d['events'] if x['instrument']=='flute'],key=lambda x:x['onset']);phr=json.loads((P/'phrases_v2.json').read_text());assert len(e)==4*len(phr);rows=[]
with wave.open(str(P/'revisions/diagnostic_flute_v3.wav'),'rb') as w:
 sr=w.getframerate()
 for k in range(len(phr)-1):
  a=e[k*4+3];b=e[(k+1)*4];begin=sec(a['onset']+a['duration']);end=sec(b['onset'])+.4;w.setpos(round(begin*sr));raw=w.readframes(round((end-begin)*sr));q=np.frombuffer(raw,dtype=np.uint8).reshape(-1,3);v=q[:,0].astype(np.int32)|(q[:,1].astype(np.int32)<<8)|(q[:,2].astype(np.int32)<<16);x=np.where(v&0x800000,v-0x1000000,v).reshape(-1,2).astype(float)/8388608;hop=441;n=len(x)//hop;rms=np.sqrt(np.mean(x[:n*hop].reshape(n,hop,2)**2,axis=(1,2)));quiet=rms<1e-4;run=0;best=0
  for quiet_bin in quiet:
   run=run+1 if quiet_bin else 0;best=max(best,run)
  rows.append({'after_phrase':phr[k]['id'],'before_phrase':phr[k+1]['id'],'actual_native_post_room_quiet_run_seconds':best*.01,'threshold_dbfs':-80,'bin_seconds':.01})
res={'method':'Longest contiguous10ms-RMS interval below-80dBFS in the actual isolated native flute bus including shared room, between phrase gates. This is an objective low-level interval, not a perceptual-silence or listening-quality verdict.','gaps':rows,'minimum_seconds':min(x['actual_native_post_room_quiet_run_seconds'] for x in rows)};(P/'revisions/native_flute_breath_gaps_v3.json').write_text(json.dumps(res,indent=2));print(json.dumps(res,indent=2))
