#!/usr/bin/env python3
"""Original, hand-authored, NON-AUDIO airship passacaglia draft.
Writes three score revisions and mechanical checks only. No external dependency,
MIDI export, instrument loading, download, rendering, or previous-theme input.
Run with Python 3 from any directory. All output remains beside this script.
"""
from pathlib import Path
from collections import defaultdict
from copy import deepcopy
import json

HERE = Path(__file__).resolve().parent
TITLE = 'Repairing the Airship in Its Sleep'
# Each row = chord label, pitch-class voicing in concert MIDI, baseline bass pair,
# revised bass pair. The final inversion is intentional, not a generated loop.
H = {
 'D': ('Dm(add9)', [50,53,57,64], [38,45]),
 'C': ('C(add9)/E', [48,52,55,62], [40,43]),
 'B': ('Bbmaj7', [46,50,53,57], [34,41]),
 'A': ('A7sus4', [45,50,52,55], [33,40]),
 'dA': ('Dm/A', [50,53,57], [45,38]),
 'cG': ('C/G', [48,52,55], [43,48]),
 'bF': ('Bb/F', [46,50,53], [41,46]),
 'aE': ('A7/E', [45,49,52,55], [40,45]),
 'dF': ('Dm/F', [50,53,57], [41,45]),
 'gB': ('Gm/Bb', [43,46,50], [34,43]),
 'Eb': ('Ebmaj7', [51,55,58,62], [39,46]),
 'bD': ('Bb6/D', [46,50,53,55], [38,41]),
 'a9': ('A7(b9)', [45,49,52,55,58], [33,40]),
 'asE': ('Asus4/E', [45,50,52], [40,45]),
 'FA': ('F/A', [48,53,57], [33,41]),
 'G': ('Gm', [43,46,50], [31,38]),
 'bmD': ('Bbmaj7/D', [46,50,53,57], [38,41]),
 'g7': ('Gm7', [43,46,50,53], [31,38]),
 'b6': ('Bb6', [46,50,53,55], [34,41]),
 'g6': ('Gm6', [43,46,50,52], [31,38]),
 'dAlow': ('Dm/A', [50,53,57], [33,38]),
}
# Deliberately written harmonic route, one symbol per bar.
ROUTE = (
 ['D','C','B','A'] +
 ['D','C','B','A','D','C','b6','A'] +
 ['dA','cG','bF','aE','dF','C','gB','A'] +
 ['D','Eb','bD','a9','dF','cG','gB','asE'] +
 ['B','FA','G','dF','bmD','C','g7','A'] +
 ['D','C','b6','A','dF','C','g6','dAlow'] +
 ['D','C','B','A','dF','C','dAlow','D']
)
assert len(ROUTE) == 52
SECTIONS = [
 (1,4,64,'序奏：夜间检修'),
 (5,12,72,'原型：四扇检修窗'),
 (13,20,76,'变奏一：乘客醒在梦里'),
 (21,28,80,'变奏二：错位的螺钉'),
 (29,36,72,'变奏三：给梦留一张空椅'),
 (37,44,68,'变奏四：发动机学会呼吸'),
 (45,52,60,'尾声：天亮以前停下手'),
]
CLARINET_BARS = set(range(13,17)) | set(range(25,31)) | {33,34} | set(range(41,49))
# Four-bar seed and its answer are composed here, not read from existing scores.
# (local quarter-beat onset, concert MIDI pitch, quarter-beat duration)
THEME = [
 [(0,62,.70),(.875,65,.65),(1.75,69,1.05),(3.125,67,.55)],
 [(0,64,.85),(1.125,67,.65),(2.25,65,.65),(3.125,64,.55)],
 [(0,65,.70),(.875,69,.65),(1.75,70,.95),(3.125,69,.55)],
 [(0,67,.85),(1.125,64,.65),(2.25,61,.55),(3.125,62,.55)],
]
# Full melodic route. The last item of every clarinet two-bar phrase is absent,
# leaving a physical breath rather than calling detached samples legato.
MELODY = {
 1: [], 2: [], 3: [(1.75,65,.75),(3,69,.65)],
 4: [(0,67,.85),(1.5,64,.65),(3,61,.5)],
 5: THEME[0], 6: THEME[1], 7: [(0,65,.7),(.875,69,.65),(1.75,70,.8),(3,74,.65)],
 8: [(0,73,.75),(1,69,.7),(2,67,.65),(3.125,64,.55)],
 9: [(0,74,.85),(1.125,69,.65),(2.25,65,.65),(3.125,67,.55)],
 10: [(0,64,.8),(1.125,67,.65),(2.25,72,.8),(3.25,69,.5)],
 11: THEME[2], 12: THEME[3],
 13: THEME[0], 14: [(0,64,.85),(1.125,67,.65),(2.25,64,.65)],
 15: THEME[2], 16: [(0,67,.85),(1.125,64,.65),(2.25,62,.65)],
 17: [(0,65,.7),(.875,69,.65),(1.75,74,1.05),(3.125,72,.55)],
 18: [(0,72,.85),(1.125,67,.65),(2.25,64,.65),(3.125,62,.55)],
 19: [(0,62,.7),(.875,65,.65),(1.75,67,.95),(3.125,70,.55)],
 20: [(0,69,.85),(1.125,67,.65),(2.25,64,.65),(3.125,61,.55)],
 21: [(i*.5,p,.35) for i,p in enumerate([62,65,69,67,65,69,74,69])],
 22: [(i*.5,p,.35) for i,p in enumerate([63,67,70,67,65,67,74,70])],
 23: [(i*.5,p,.35) for i,p in enumerate([62,65,69,70,69,65,62,65])],
 24: [(i*.5,p,.35) for i,p in enumerate([61,64,67,70,69,67,64,61])],
 25: [(0,65,.7),(.875,69,.65),(1.75,67,1),(3.125,62,.55)],
 26: [(0,64,.85),(1.125,67,.65),(2.25,60,.65)],
 27: [(0,62,.7),(.875,65,.65),(1.75,67,.95),(3.125,70,.55)],
 28: [(0,69,.85),(1.125,67,.65),(2.25,64,.65)],
 29: [(0,65,.7),(1,69,.65),(2,70,.85),(3.125,69,.5)],
 30: [(0,65,.85),(1.125,67,.65),(2.25,69,.65)],
 31: [(0,67,.85),(1.125,70,.65),(2.25,74,.8),(3.25,72,.5)],
 32: [(0,65,.85),(1.125,69,.65),(2.25,74,.8),(3.25,69,.5)],
 33: [(0,62,.7),(1,65,.65),(2,69,.85),(3.125,65,.5)],
 34: [(0,64,.85),(1.125,67,.65),(2.25,62,.65)],
 35: [(0,74,.85),(1.125,70,.65),(2.25,67,.65),(3.125,65,.55)],
 36: [(0,64,.85),(1.125,67,.65),(2.25,69,.65),(3.125,74,.55)],
 37: THEME[0], 38: THEME[1],
 39: [(0,65,.8),(1.125,67,.65),(2.25,70,.65),(3.125,69,.55)],
 40: [(0,67,.85),(1.125,64,.65),(2.25,62,.9)],
 41: [(0,62,.75),(1,65,.65),(2,69,.9),(3.25,67,.5)],
 42: [(0,64,.9),(1.25,67,.7),(2.25,64,.7)],
 43: [(0,67,.75),(1,69,.65),(2,70,.9),(3.25,64,.5)],
 44: [(0,65,.9),(1.25,64,.7),(2.25,62,.7)],
 45: [(0,62,1.15),(1.5,65,.75),(2.75,69,.7)],
 46: [(0,67,.95),(1.25,64,.75),(2.5,62,.7)],
 47: [(0,65,1.15),(1.5,69,.75),(2.75,65,.7)],
 48: [(0,67,.95),(1.25,64,.75),(2.5,61,.7)],
 49: [(0,74,1.15),(1.5,69,.85),(2.75,65,.8)],
 50: [(0,64,1.15),(1.5,67,.85),(2.75,74,.8)],
 51: [(0,65,1.1),(1.5,64,.8),(2.75,62,.8)],
 52: [(0,62,3.7)],
}
# A quieter counterweight is an arpeggio inside the harmony, not a second tune.
# Two middle-register pitches for left-hand engine links / right-hand cushions.
MID = {
 'D':(53,57), 'C':(52,55), 'B':(50,53), 'A':(50,55),
 'dA':(53,57), 'cG':(52,55), 'bF':(50,53), 'aE':(52,55),
 'dF':(53,57), 'gB':(50,55), 'Eb':(55,58), 'bD':(53,55),
 'a9':(52,58), 'asE':(50,57), 'FA':(53,57), 'G':(50,55),
 'bmD':(50,53), 'g7':(50,53), 'b6':(53,55), 'g6':(50,52),
 'dAlow':(53,57),
}
CANONICAL_BASS = {
 'D':[38,45],'C':[36,43],'B':[34,41],'A':[33,40],
 'dA':[38,45],'cG':[36,43],'bF':[34,41],'aE':[33,40],
 'dF':[38,45],'gB':[31,38],'Eb':[39,46],'bD':[34,41],
 'a9':[33,40],'asE':[33,40],'FA':[41,48],'G':[31,38],
 'bmD':[34,41],'g7':[31,38],'b6':[34,41],'g6':[31,38],
 'dAlow':[38,45],
}

def section_for(b):
    return next((bpm,name) for a,z,bpm,name in SECTIONS if a<=b<=z)

def append_event(events,b,t,p,d,v,voice,instrument='piano'):
    events.append(dict(bar=b,onset=round((b-1)*4+t,6),duration=round(d,6),
                       pitch=p,velocity=v,voice=voice,instrument=instrument))

def build(version):
    score=dict(id=61,title=TITLE,title_zh='在睡梦中修理飞艇',bars=[],events=[],
               pedals=[dict(onset=0,value=0)],total_beats=208,tail_seconds=4)
    ev=score['events']
    for b,key in enumerate(ROUTE,1):
        bpm,section=section_for(b)
        hn,harmony,ground=H[key]
        if b==52: hn,harmony='Dm',[50,53,57]
        is_cl=b in CLARINET_BARS
        if version==0:
            ground=CANONICAL_BASS[key]
            hn=hn.split('/')[0]
        else:
            ground=list(ground)
        role=('单簧管唯一前景；钢琴左手依次弹低音与短和声托垫，右手休息' if is_cl else
              '钢琴右手唯一旋律；左手依次演奏低音与中音机械连接音')
        if b==52:
            role='钢琴左手低音 D；右手 D–F–A 收束；单簧管与发动机第二击均休止'
        score['bars'].append(dict(bar=b,start=(b-1)*4,beats=4,bpm=bpm,
            section=section,meter_numerator=4,meter_denominator=4,
            harmony_name=hn,harmony=harmony,role_plan=role,
            lead_instrument='clarinet' if is_cl else 'piano'))
        line=deepcopy(MELODY[b])
        # Revision 1: the answer is contracted, then the defect bar exaggerates
        # the semitone displacement before the original motif returns.
        if version>=1:
            if b==9: line=[(0,69,.8),(1.125,65,.65),(2.25,62,.9),(3.5,64,.3)]
            if b==10: line=[(0,67,.8),(1.125,64,.65),(2.25,62,.9),(3.5,64,.3)]
            if b==22: line=[(i*.5,p,.35) for i,p in enumerate([63,67,70,74,70,67,65,63])]
            if b==24: line=[(0,70,.4),(.5,69,.4),(1,67,.4),(1.5,64,.4),(2,61,.75),(3.25,64,.4)]
            if b==36: line=[(0,64,.85),(1.125,67,.65),(2.25,69,.95)]
        # Revision 2: four silences are part of the tune, not just lower volume.
        if version>=2:
            if b==20: line=[(0,69,.85),(1.125,67,.65),(2.25,64,.75)]
            if b==30: line=[(0,65,.9),(1.25,67,.65),(2.25,69,.7)]
            if b==34: line=[(0,64,.9),(1.25,67,.65),(2.25,62,.7)]
            if b==40: line=[(0,67,.9),(1.25,64,.7),(2.5,62,.7)]
            if b==41: line=[(.5,62,.75),(1.5,65,.65),(2.5,69,.85)]
            if b==43: line=[(.5,67,.75),(1.5,69,.65),(2.5,70,.85)]
            if b==45: line=[(.5,62,1.15),(2,65,.75),(3,69,.65)]
            if b==47: line=[(.5,65,1.15),(2,69,.75),(3,65,.65)]
            if b==48: line=[(0,67,.95),(1.25,64,.75),(2.5,62,.7)]
            if b==49: line=[(0,69,1.2),(1.75,65,.9),(3,62,.7)]
            if b==50: line=[(.5,64,1.1),(2,67,1.0)]
            if b==51: line=[(0,65,1.0),(1.5,64,.8),(2.75,62,.8)]
        if is_cl:
            base_v = 75 if version<2 else (78 if 25<=b<=28 else 70 if b<41 else 66)
            for j,(t,p,d) in enumerate(line):
                # A small within-layer contour; never a hidden switch to pp.
                vel=base_v + (3 if j==1 else 1 if j==2 else 0)
                append_event(ev,b,t,p,d,vel,'clarinet','clarinet')
        else:
            base_v = 65 if b<21 else 75 if b<=24 else 66 if b<=40 else 59
            if version>=2 and b>=49: base_v=53 if b<52 else 49
            for j,(t,p,d) in enumerate(line):
                append_event(ev,b,t,p,d,base_v+(3 if j==2 else 0),'melody')
        # v0: ground always on 1 and 3. v1: inversion, shifted second contact,
        # and contrary-direction engine contour. v2: truly omitted contacts.
        positions=[0,2]
        if version>=1:
            if 13<=b<=20: positions=[0,2.25]
            if 21<=b<=28: positions=[0,1.75] if b%2 else [0,2.5]
            if 29<=b<=36: positions=[0,2.75]
            if 37<=b<=44: positions=[0,2.5]
            if b>=45: positions=[0,2.75]
        omit_second = version>=2 and b in {30,32,34,36,38,40,42,44,46,48,49,50,51,52}
        if b==52: omit_second=True
        bass_v = 51 if b<21 else 59 if b<=28 else 48 if b<=44 else 43
        if version>=2 and b>=45: bass_v=39
        for j,p in enumerate(ground):
            if j==1 and omit_second: continue
            t=positions[j]
            # Bass and engine links share the left hand only on piano-led bars.
            dur=.42
            if b==52: dur=3.7
            append_event(ev,b,t,p,dur,bass_v+(2 if j==0 else 0),'bass')
        mid1,mid2=MID[key]
        if b==52:
            for p in [65,69]: append_event(ev,b,0,p,3.7,44,'melody')
            continue
        if is_cl:
            pads=[(.75,.55),(2.75,.45)]
            if version>=1:
                pads=[(.75,.55),(positions[1]+.75,.4)]
            if version>=1 and 29<=b<=36: pads=[(.75,.65),(1.75,.5)]
            if version>=2:
                if 29<=b<=36: pads=[(.75,.65)]
                if 41<=b<=48: pads=[(.75,.6)]
            for t,d in pads:
                for p in [mid1,mid2]:
                    append_event(ev,b,t,p,d,43 if version<2 else 39,'accompaniment')
        else:
            links=[(.75,mid1,.26),(1.5,mid2,.26),(2.75,mid1,.26),(3.5,mid2,.26)]
            if version>=1 and 13<=b<=20:
                links=[(.75,mid1,.26),(1.5,mid2,.26),(3,mid1,.26),(3.625,mid2,.22)]
            if version>=1 and 21<=b<=28:
                links=[(.75,mid1,.26),(3.25,mid2,.26)]
            if version>=1 and 29<=b<=36:
                links=[(.75,mid1,.3),(1.75,mid2,.3),(3.5,mid1,.3)]
            if version>=1 and 37<=b<=44:
                links=[(.75,mid1,.3),(1.5,mid2,.3),(3.25,mid1,.3)]
            if version>=1 and 45<=b<=51:
                links=[(.75,mid1,.35),(1.75,mid2,.35),(3.5,mid1,.3)]
            if version>=2:
                if b in {32,36,38,40}: links=[(.75,mid1,.3),(1.5,mid2,.3)]
                if b==49: links=[(.75,mid1,.35),(2.25,mid2,.35)]
                if b==50: links=[(1.75,mid1,.35)]
                if b==51: links=[(.75,mid1,.35)]
            for t,p,d in links:
                append_event(ev,b,t,p,d,42 if b<21 else 46 if b<=28 else 38,'accompaniment')
    ev.sort(key=lambda n:(n['onset'],n['instrument'],n['pitch']))
    return score

def elapsed_seconds(score, beat):
    result=0.0
    for b in score['bars']:
        if beat<=b['start']: break
        result += min(beat-b['start'],b['beats'])*60/b['bpm']
    return result

def audit(score):
    errors=[]
    required={'id','title','title_zh','bars','events','pedals','total_beats','tail_seconds'}
    if set(score)!=required: errors.append('top-level schema mismatch')
    by_key=defaultdict(list)
    cl=[]
    for e in score['events']:
        b=score['bars'][e['bar']-1]
        if not b['start']<=e['onset']<b['start']+4: errors.append(f"bar mismatch {e}")
        if e['duration']<=0 or e['onset']+e['duration']>b['start']+4+1e-7: errors.append(f"note crosses bar {e}")
        if not 1<=e['velocity']<=127: errors.append('invalid velocity')
        by_key[e['instrument'],e['pitch']].append(e)
        if e['instrument']=='clarinet':
            cl.append(e)
            if not 60<=e['pitch']<=71: errors.append('clarinet range')
            if not 56<=e['velocity']<=95: errors.append('clarinet layer')
            sec=elapsed_seconds(score,e['onset']+e['duration'])-elapsed_seconds(score,e['onset'])
            if sec>1.5+1e-7: errors.append('clarinet duration')
    for k,es in by_key.items():
        es.sort(key=lambda e:e['onset'])
        for a,b in zip(es,es[1:]):
            if a['onset']+a['duration']>b['onset']+1e-7:
                errors.append(f'same-key overlap {k}: bars {a["bar"]}, {b["bar"]}')
    for a,b in zip(cl,cl[1:]):
        if a['onset']+a['duration']>b['onset']+1e-7: errors.append('clarinet polyphony')
    foreground_overlap_count=0
    for a in cl:
        for b in score['events']:
            if b['instrument']=='piano' and b['voice']=='melody' and max(a['onset'],b['onset']) < min(a['onset']+a['duration'],b['onset']+b['duration'])-1e-7:
                foreground_overlap_count+=1
    if foreground_overlap_count: errors.append('competing foreground melodies')
    # Export-compatible hand routing: melody = RH, bass/accompaniment = LH.
    # Final F/A chord tones are therefore explicitly melody voice too.
    lh=[]; rh=[]
    for e in score['events']:
        if e['instrument']!='piano': continue
        hand='LH' if e['voice'] in {'bass','accompaniment'} else 'RH'
        (lh if hand=='LH' else rh).append(e)
    hand_peaks={}
    for label,notes in [('LH',lh),('RH',rh)]:
        peak=0; max_span=0
        for t in sorted({e['onset'] for e in notes}):
            active=[e['pitch'] for e in notes if e['onset']<=t+1e-7 and e['onset']+e['duration']>t+1e-7]
            peak=max(peak,len(active)); span=max(active)-min(active) if active else 0
            max_span=max(max_span,span)
            if span>12: errors.append(f'{label} simultaneous span above octave at {t}: {active}')
        hand_peaks[label]=dict(max_simultaneous_notes=peak,max_simultaneous_span_semitones=max_span)
    breath=[]
    # The explicit two-bar phrases. Gaps are reported in actual seconds.
    for a,z in [(13,14),(15,16),(25,26),(27,28),(29,30),(33,34),(41,42),(43,44),(45,46),(47,48)]:
        notes=[e for e in cl if a<=e['bar']<=z]
        if not notes: continue
        end=max(e['onset']+e['duration'] for e in notes)
        following=[e for e in cl if e['onset']>=end-1e-7 and e['bar']>z]
        next_start=min((e['onset'] for e in following),default=score['total_beats'])
        gap=elapsed_seconds(score,next_start)-elapsed_seconds(score,end)
        if gap<.65: errors.append(f'phrase {a}-{z}: breath gap below .65 sec')
        breath.append(dict(bars=[a,z],next_clarinet_gap_seconds=round(gap,4)))
    duration=elapsed_seconds(score,score['total_beats'])
    section_report=[]
    for a,z,bpm,name in SECTIONS:
        ns=[e for e in score['events'] if a<=e['bar']<=z]
        section_report.append(dict(bars=[a,z],section=name,bpm=bpm,
            start_seconds=round(elapsed_seconds(score,(a-1)*4),4),
            duration_seconds=round((z-a+1)*4*60/bpm,4),notes=len(ns),
            bass_attacks=sum(e['voice']=='bass' for e in ns)))
    return dict(errors=errors,mechanical_checks_only=True,human_listening_performed=False,
        bars=len(score['bars']),total_beats=score['total_beats'],
        music_seconds=round(duration,4),with_tail_seconds=round(duration+score['tail_seconds'],4),
        event_count=len(score['events']),clarinet_note_count=len(cl),
        clarinet_pitch_range=[min(e['pitch'] for e in cl),max(e['pitch'] for e in cl)],
        clarinet_velocity_range=[min(e['velocity'] for e in cl),max(e['velocity'] for e in cl)],
        clarinet_max_note_seconds=round(max(elapsed_seconds(score,e['onset']+e['duration'])-elapsed_seconds(score,e['onset']) for e in cl),4),
        hand_check=hand_peaks,foreground_overlap_count=foreground_overlap_count,
        breath_phrases=breath,sections=section_report)

def signature(e):
    return (e['bar'],e['onset'],e['duration'],e['pitch'],e['velocity'],e['voice'],e['instrument'])

def main():
    scores=[]; reports={}
    for v in range(3):
        score=build(v); result=audit(score)
        if result['errors']: raise RuntimeError(f'v{v}: '+json.dumps(result['errors'],ensure_ascii=False))
        scores.append(score); reports[f'v{v}']=result
        (HERE/f'score_v{v}.json').write_text(json.dumps(score,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    diffs={}
    for v in [1,2]:
        before={signature(e) for e in scores[v-1]['events']}; after={signature(e) for e in scores[v]['events']}
        diffs[f'v{v-1}_to_v{v}']=dict(events_removed_or_changed=len(before-after),events_added_or_changed=len(after-before),
            changed_bars=sorted({e[0] for e in (before-after)|(after-before)}))
    reports['revision_diffs']=diffs
    (HERE/'audit_report.json').write_text(json.dumps(reports,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    # Compact, human-readable source material for the hand-authored seed.
    seed={'concert_pitch':True,'meter':'4/4','theme_bars':THEME,
        'ground_bars':[[38,45],[40,43],[34,41],[33,40]],
        'ground_note_names':['D2 A2','E2 G2','Bb1 F2','A1 E2'],
        'note':'旋律及地基均在此稿手工写定；代码仅展开明确写定的变奏，不读取其他作品的音符。'}
    (HERE/'theme_and_ground.json').write_text(json.dumps(seed,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'result':'all three non-audio drafts generated; structural checks passed',
        'final':reports['v2'],'diffs':diffs},ensure_ascii=False,indent=2))

if __name__=='__main__': main()
