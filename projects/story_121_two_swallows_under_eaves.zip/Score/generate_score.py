"""121 original12/8 two-line piano score; no inherited melodic event pattern."""
from pathlib import Path
import json,sys
P=Path(__file__).resolve().parent;sys.path.insert(0,str(P));from composition_data import *
def write(p,x):p.write_text(json.dumps(x,ensure_ascii=False,separators=(',',':'))+'\n')
def pitch(s):return 12*(int(s[-1])+1)+{'C':0,'D':2,'E':4,'F':5,'G':7,'A':9,'B':11}[s[0]]+s[1:-1].count('#')-s[1:-1].count('b')
def build(level):
 rows=[]
 for sec,bpm,dyn,hs,upper,lower in GROUPS:
  assert len(hs.split())==len(upper)==len(lower),(sec,len(hs.split()),len(upper),len(lower))
  rows.extend(zip([sec]*len(upper),[bpm]*len(upper),[dyn]*len(upper),hs.split(),upper,lower))
 assert len(rows)==60
 events=[];bars=[];pedals=[]
 for n,(sec,bpm,dyn,h,upper,lower) in enumerate(rows,1):
  if level>=1:upper=REV1.get(n,upper);lower=LOW1.get(n,lower)
  if level>=2:upper=REV2.get(n,upper);lower=LOW2.get(n,lower)
  if n>=57:bpm-=3*(n-56)
  start=(n-1)*6;bars.append(dict(bar=n,start=start,beats=6,bpm=bpm,meter='12/8',meter_numerator=12,meter_denominator=8,section=sec,harmony_name=h,harmony=H[h],key_region='E minor; G-major flights and E7 toward A minor'))
  for line,hand,voice in [(upper,'right','upper_wing_theme'),(lower,'left','lower_wing_counterline')]:
   at=0;tokens=line.split()
   for i,tok in enumerate(tokens):
    name,u=tok.split(':');dur=float(u)/2
    if name!='R':
     v=dyn if hand=='right' else dyn-13
     if level>=1 and n in LOW1 and hand=='left' and at>=3:v+=9
     if level>=2 and n in LOW2:
      v=dyn-5 if hand=='left' else dyn-9
     v+=3 if at in [0,1.5,3,4.5] and sec in ['rain_cut','parallel_air'] else -4 if i==len(tokens)-1 else 0
     events.append(dict(bar=n,onset=round(start+at,6),duration=round(dur-.06,6),pitch=pitch(name),velocity=int(v),instrument='piano',voice=voice,hand=hand))
    at+=dur
   assert at==6,(n,hand,at)
  pedals.append(dict(bar=n,onset=start,controller=64,value=0,instrument='piano'))
  if sec=='under_roof':pedals.extend([dict(bar=n,onset=start+.08,controller=64,value=24,instrument='piano'),dict(bar=n,onset=start+2.8,controller=64,value=0,instrument='piano')])
 events.sort(key=lambda e:(e['onset'],e['pitch']))
 for i,e in enumerate(events):e['event_id']=f'121-v{level}-{i}'
 return dict(id=121,title='Two Swallows under the Eaves',title_zh='檐下两只雨燕',version=f'v{level}',bars=bars,events=events,pedals=pedals,total_beats=360,tail_seconds=5,instrument_map={'piano':'piano'},performance_contract='Original two explicitly composed piano lines in12/8. Dotted-quarter flight against duple lower motion, then exchanged thematic focus. Sampled acoustic grand, not a live recording.')
def proj(d,n):return {'bar':d['bars'][n-1],'events':[{k:v for k,v in e.items() if k!='event_id'} for e in d['events'] if e['bar']==n],'pedals':[e for e in d['pedals'] if e['bar']==n]}
for v in range(3):
 d=build(v);write(P/f'score_v{v}.json',d);report=dict(version=f'v{v}',bars=60,events=len(d['events']),duration_seconds=sum(b['beats']*60/b['bpm'] for b in d['bars'])+5,human_listening_review=False);write(P/f'audit_v{v}.json',report)
 if v:
  a=build(v-1);changes=[{'bar':n,'before':proj(a,n),'after':proj(d,n)} for n in range(1,61) if proj(a,n)!=proj(d,n)];write(P/f'exact_diff_v{v-1}_to_v{v}.json',{'count':len(changes),'changed_bars':[x['bar'] for x in changes],'comparison_excludes':['version','event_id'],'changes':changes})
write(P/'score.json',d);write(P/'ensemble_score.json',d);write(P/'piano_score.json',d);print(json.dumps(report))
