#!/usr/bin/env python3
"""Work 66: deterministic composition and non-audio audit, Python stdlib only.
No MIDI, sample loading, synthesis, rendering, REAPER, network, or external packages.
Run from any directory: python3 /path/to/compose.py
"""
from pathlib import Path
from collections import Counter, defaultdict
from math import isclose
import hashlib
import json

OUT = Path(__file__).resolve().parent
S = 2.0 / 3.0  # long:short eighth subdivision = 2:1, actually in event positions

def phrase(*items):
    return [(float(t), int(p), float(d)) for t, p, d in items]

# All melody lines were written for this piece. Values are quarterbeat onset,
# MIDI pitch, written gate. No prior scores/reference songs are loaded.
M = {
 1: phrase((S+1,69,.25),(2,72,.56),(2+S,74,.25),(3,72,.78)),
 2: phrase((0,69,1.22),(1+S,67,.25),(2,65,1.25)),
 3: phrase((0,67,.54),(S,69,.25),(1,70,.9),(2+S,69,.25),(3,67,.72)),
 4: phrase((0,67,.55),(S,64,.25),(1,67,.85),(3+S,69,.24)),
 5: phrase((0,69,.56),(S,72,.25),(1,74,1.28),(2+S,72,.25),(3,69,.78)),
 6: phrase((0,67,.54),(S,69,.25),(1,72,.88),(2+S,74,.25),(3,72,.76)),
 7: phrase((0,74,1.2),(1+S,77,.25),(2,79,.56),(2+S,77,.25),(3,74,.77)),
 8: phrase((0,73,.56),(S,72,.25),(1,70,1.26),(2+S,68,.25),(3,67,.78)),
 9: phrase((0,69,.56),(S,72,.25),(1,74,.84),(2,72,.56),(2+S,69,.25),(3,65,.78)),
10: phrase((0,66,.56),(S,69,.25),(1,72,1.22),(2+S,69,.25),(3,66,.73)),
11: phrase((0,67,.56),(S,70,.25),(1,74,.84),(2,72,.56),(2+S,70,.25),(3,69,.78)),
12: phrase((0,67,.56),(S,64,.25),(1,62,.88),(2+S,64,.25),(3,67,.72)),
13: phrase((0,69,.56),(S,72,.25),(1,74,1.26),(2+S,77,.25),(3,76,.76)),
14: phrase((0,76,.56),(S,79,.25),(1,77,.9),(2+S,76,.25),(3,72,.78)),
15: phrase((0,74,1.26),(1+S,72,.25),(2,69,.55),(2+S,72,.25),(3,77,.78)),
16: phrase((0,76,.56),(S,74,.25),(1,71,.9),(2+S,69,.25),(3,67,.77)),
17: phrase((0,70,.56),(S,74,.25),(1,77,1.22),(2+S,74,.25),(3,72,.75)),
18: phrase((0,70,.55),(S,69,.25),(1,67,.9),(2+S,64,.25),(3,67,.77)),
19: phrase((0,69,.56),(S,72,.25),(1,77,1.72),(3,74,.76)),
20: phrase((0,72,.88),(1+S,70,.25),(2,67,.85)),
# First draft of B is deliberately a connected, four-square minor song.
21: phrase((0,77,1.8),(2,76,.55),(2+S,74,.25),(3,72,.78)),
22: phrase((0,73,1.8),(2,76,.55),(2+S,77,.25),(3,76,.78)),
23: phrase((0,77,.88),(1,76,.88),(2,74,1.74)),
24: phrase((0,74,.88),(1,71,.88),(2,69,1.74)),
25: phrase((0,74,1.8),(2,77,.55),(2+S,76,.25),(3,74,.78)),
26: phrase((0,73,.88),(1,76,.88),(2,79,1.74)),
27: phrase((0,77,.88),(1,76,.88),(2,74,1.74)),
28: phrase((0,72,.88),(1,69,.88),(2,66,1.74)),
29: phrase((0,67,1.8),(2,70,.55),(2+S,74,.25),(3,72,.78)),
30: phrase((0,74,.88),(1,72,.88),(2,70,1.74)),
31: phrase((0,69,1.8),(2,67,.55),(2+S,64,.25),(3,67,.78)),
32: phrase((0,70,.88),(1,69,.88),(2,67,1.30),(3+S,69,.24)),
33: phrase((0,69,.56),(S,72,.25),(1,74,.86),(2+S,72,.25),(3,77,.78)),
34: phrase((0,76,.56),(S,74,.25),(1,72,.86),(2+S,69,.25),(3,72,.77)),
35: phrase((0,74,.56),(S,77,.25),(1,79,1.25),(2+S,81,.25),(3,79,.77)),
36: phrase((0,80,.56),(S,79,.25),(1,77,.9),(2+S,76,.25),(3,74,.77)),
37: phrase((0,72,.56),(S,76,.25),(1,79,.86),(2,77,.55),(2+S,76,.25),(3,72,.78)),
38: phrase((0,74,.56),(S,72,.25),(1,69,.86),(2+S,66,.25),(3,69,.77)),
39: phrase((0,70,.56),(S,74,.25),(1,77,.86),(2,74,.55),(2+S,72,.25),(3,70,.76)),
40: phrase((0,69,.56),(S,67,.25),(1,64,.84),(2+S,67,.25),(3,70,.77)),
41: phrase((0,69,.56),(S,72,.25),(1,77,1.25),(2+S,76,.25),(3,74,.76)),
42: phrase((0,74,.56),(S,77,.25),(1,79,.9),(2+S,77,.25),(3,74,.77)),
43: phrase((0,72,.56),(S,69,.25),(1,65,1.82)),
44: phrase((0,64,.86),(1+S,67,.25),(2,70,.86)),
# C: the conductor answers the quiet traveler; broad, lifted register.
45: phrase((0,77,1.24),(1+S,74,.25),(2,72,1.25)),
46: phrase((0,73,.88),(1+S,70,.25),(2,67,1.24)),
47: phrase((0,69,1.25),(1+S,72,.25),(2,77,1.3)),
48: phrase((0,78,.56),(S,81,.25),(1,78,.85),(2+S,74,.25),(3,72,.77)),
49: phrase((1,74,.9),(2+S,77,.25),(3,79,.72)),
50: phrase((0,76,1.25),(1+S,74,.25),(2,70,1.25)),
51: phrase((0,69,.56),(S,72,.25),(1,77,1.24),(2+S,81,.25),(3,79,.77)),
52: phrase((0,79,.88),(1+S,76,.25),(2,73,1.22)),
53: phrase((0,74,1.23),(1+S,77,.25),(2,81,.55),(2+S,79,.25),(3,77,.76)),
54: phrase((0,79,.55),(S,81,.25),(1,83,1.21),(2+S,81,.25),(3,79,.74)),
55: phrase((0,77,1.2),(1+S,74,.25),(2,70,.87)),
56: phrase((0,69,.55),(S,67,.25),(1,64,1.28),(3+S,69,.24)),
# Initial return and coda; recomposed in revision 2.
57: phrase((0,69,.56),(S,72,.25),(1,74,1.28),(2+S,72,.25),(3,69,.78)),
58: phrase((0,67,.54),(S,69,.25),(1,72,.88),(2+S,74,.25),(3,72,.76)),
59: phrase((0,74,1.2),(1+S,77,.25),(2,79,.56),(2+S,77,.25),(3,74,.77)),
60: phrase((0,73,.56),(S,72,.25),(1,70,1.26),(2+S,68,.25),(3,67,.78)),
61: phrase((0,69,.56),(S,72,.25),(1,74,.84),(2,72,.56),(2+S,69,.25),(3,65,.78)),
62: phrase((0,66,.56),(S,69,.25),(1,72,1.22),(2+S,69,.25),(3,66,.73)),
63: phrase((0,67,.56),(S,70,.25),(1,74,.84),(2,72,.56),(2+S,70,.25),(3,69,.78)),
64: phrase((0,67,.56),(S,64,.25),(1,62,.88),(2+S,64,.25),(3,67,.72)),
65: phrase((0,69,.56),(S,72,.25),(1,76,1.25),(2+S,79,.25),(3,76,.77)),
66: phrase((0,78,.56),(S,76,.25),(1,74,.88),(2+S,72,.25),(3,69,.77)),
67: phrase((0,70,.56),(S,74,.25),(1,77,1.22),(2+S,74,.25),(3,72,.75)),
68: phrase((0,70,.55),(S,69,.25),(1,67,.9),(2+S,64,.25),(3,67,.77)),
69: phrase((0,69,.56),(S,72,.25),(1,77,1.70),(3,74,.77)),
70: phrase((0,74,.88),(1,77,.88),(2,79,1.72)),
71: phrase((0,76,.88),(1,74,.88),(2,70,.88),(3,76,.75)),
72: phrase((0,77,3.5)),
}

# Revision 1: new B material, non-uniform entrances, actual conversational gaps,
# a four-note identifying contour, and a moved harmonic arrival at bar 28.
B1 = {
21: phrase((0,77,.54),(S,74,.24),(1,72,1.05),(3,69,.71)),
22: phrase((S,73,.24),(1,76,.91),(2+S,74,.24),(3,73,.69)),
23: phrase((0,72,.90),(1+S,69,.24),(2,65,.85)),
24: phrase((1,67,.53),(1+S,71,.24),(2,74,.95)),
25: phrase((0,77,.54),(S,74,.24),(1,72,1.02),(3,74,.69)),
26: phrase((S,73,.24),(1,76,.86),(2+S,79,.24),(3,76,.70)),
27: phrase((0,77,.55),(S,76,.24),(1,74,1.04)),
28: phrase((1,69,.54),(1+S,72,.24),(2,74,1.34)),
29: phrase((0,70,.53),(S,74,.24),(1,77,1.04),(3,74,.68)),
30: phrase((S,72,.24),(1,70,.91),(2+S,67,.24),(3,65,.70)),
31: phrase((0,64,1.03),(2,67,.53),(2+S,69,.24),(3,70,.70)),
32: phrase((0,69,.53),(S,67,.24),(1,64,.88),(3+S,69,.24)),
}

# Revision 2: the returning identifying tune now accepts the second person's
# delayed response, then genuinely new continuation and a less declarative coda.
R2 = {
57: phrase((0,69,.55),(S,72,.24),(1,74,1.12),(3,77,.70)),
58: phrase((S,76,.24),(1,72,.9),(2+S,69,.24),(3,72,.71)),
59: phrase((0,74,.55),(S,77,.24),(1,79,1.04),(3,77,.70)),
60: phrase((S,73,.24),(1,70,.92),(2+S,68,.24),(3,67,.71)),
61: phrase((0,69,.55),(S,72,.24),(1,77,.85),(2+S,76,.24),(3,74,.70)),
62: phrase((0,72,.87),(1+S,69,.24),(2,66,.86)),
63: phrase((1,67,.54),(1+S,70,.24),(2,74,.94)),
64: phrase((0,76,.55),(S,74,.24),(1,70,1.08),(3,67,.68)),
65: phrase((0,69,.54),(S,72,.24),(1,76,1.09),(3,79,.70)),
66: phrase((S,78,.24),(1,74,.90),(2+S,72,.24),(3,69,.71)),
67: phrase((0,70,.54),(S,74,.24),(1,77,.86),(2+S,79,.24),(3,77,.70)),
68: phrase((0,76,1.1),(2,72,.54),(2+S,70,.24),(3,67,.70)),
69: phrase((0,69,.55),(S,72,.24),(1,74,1.18)),
70: phrase((1,74,.54),(1+S,77,.24),(2,79,1.13)),
71: phrase((0,76,.88),(1+S,74,.24),(2,70,.86),(3,76,.72)),
72: phrase((0,77,3.35)),
}

# Name: pitch classes, explicit middle-register piano voicing, cello root, fifth.
H = {
 'F6': ([0,2,5,9], [57,60,62],41,36),
 'F6/A': ([0,2,5,9], [53,60,62],45,41),
 'Dm7': ([0,2,5,9], [53,57,60],38,45),
 'Dm9': ([0,2,4,5,9], [53,57,60],38,45),
 'DmMaj7': ([1,2,5,9], [53,57,61],38,45),
 'Gm7': ([2,5,7,10], [53,58,62],43,38),
 'Gm7/C': ([0,2,5,7,10], [53,58,62],36,43),
 'C9': ([0,2,4,7,10], [52,58,62],36,43),
 'C7': ([0,4,7,10], [52,58,60],36,43),
 'Bb6': ([2,5,7,10], [55,58,62],46,41),
 'BbMaj7': ([2,5,9,10], [53,57,62],46,41),
 'Bbm6': ([1,5,7,10], [55,58,61],46,41),
 'D7': ([0,2,6,9], [54,57,60],38,45),
 'Am7': ([0,4,7,9], [52,55,60],45,40),
 'G7': ([2,5,7,11], [53,59,62],43,38),
 'G9': ([2,5,7,9,11], [53,57,59],43,38),
 'A7': ([1,4,7,9], [52,55,61],45,40),
 'E7': ([2,4,8,11], [56,59,62],40,47),
}
HARMONIES = '''F6 Dm7 Gm7 C9
F6 F6/A Bb6 Bbm6 F6 D7 Gm7 C9 F6 Am7 Dm7 G7 Gm7 C7 F6 C9
Dm9 DmMaj7 Dm7 G9 BbMaj7 A7 Dm7 D7 Gm7 Gm7/C C9 C7
F6 F6/A Bb6 E7 Am7 D7 Gm7 C9 F6 Bb6 F6 C9
BbMaj7 Bbm6 F6/A D7 Gm7 C9 F6 A7 Dm7 G7 Gm7 C9
F6 F6/A Bb6 Bbm6 F6 D7 Gm7 C9 Am7 D7 Gm7 C7
F6 Bb6 C9 F6'''.split()
assert len(HARMONIES) == 72

# Each written accompaniment cell is (onset, duration, two/three-note texture).
# The irregular pattern is phrase-specific; it is not an invariant ride pattern.
C = {
 'open': [(0,1.05,2),(2+S,.38,2)],
 'ask': [(0,.42,3),(1+S,.37,2),(3,.46,2)],
 'answer': [(S,.32,2),(2,.64,3)],
 'up': [(0,.44,2),(2,.50,3),(3+S,.22,2)],
 'close': [(0,.50,3),(2,.85,2)],
 'wait': [(0,.72,2),(3,.48,2)],
 'late': [(1,.48,2),(2+S,.43,2)],
 'sing': [(0,1.12,2),(2,.98,2)],
 'one': [(0,1.18,3)],
 'room': [(1,.70,2)],
 'empty': [],
 'final': [(0,1.38,3),(2,1.70,2)],
}
COMP = '''open sing ask wait
ask answer up close ask late ask close ask answer up close ask close one wait
sing sing sing sing sing sing sing sing sing sing sing wait
ask answer up close ask late ask close ask up one wait
sing answer sing up room sing ask wait sing up one wait
ask answer up close ask late ask close ask late ask close
one sing close final'''.split()
assert len(COMP)==72
# Bass entries are deliberately sparser than the piano tune. Every event is an
# anchoring chord tone of the *same bar's* harmony, usually root or fifth;
# F6/A includes its A inversion bass. No walking counter-melody.
CELLS = {
 'a': [(0,.78,0),(2,.72,1)],
 'b': [(0,.78,0),(2+S,.67,1)],
 'c': [(0,.72,0),(1+S,.68,1),(3,.75,0)],
 'd': [(1,.79,0),(3,.73,1)],
 'e': [(0,.93,0)],
 'f': [(0,.82,0),(3,.71,1)],
 'g': [(1,.80,0),(2+S,.72,1)],
 'x': [],
}
BASS = '''e a a f
c a b a c d c e c a b a c f e f
a a a a a a a a a a a f
c a b a c d c e c b e f
e d a c x a c x a b e f
c a b a c d c e c d c e
e d f e'''.split()
assert len(BASS)==72

SECTION_DATA = [
 (1,4,'I｜逐一敲门',100),
 (5,20,'A｜凭节奏认人',102),
 (21,32,'B｜不愿找回旧名',96),
 (33,44,'A′｜误认与追问',102),
 (45,56,'C｜把空拍留给对方',94),
 (57,68,'A″｜共同写下新名',102),
 (69,72,'尾声｜准许下车',None),
]

def section_info(b):
    for lo,hi,name,bpm in SECTION_DATA:
        if lo <= b <= hi:
            return name, bpm if bpm is not None else {69:96,70:92,71:88,72:76}[b]
    raise ValueError(b)

def build(version):
    melodies = dict(M)
    if version >= 1: melodies.update(B1)
    if version >= 2: melodies.update(R2)
    harmonies = list(HARMONIES)
    comp = list(COMP)
    bass = list(BASS)
    if version >= 1:
        # The new minor arrival is a full bar rather than a dominant diversion.
        harmonies[27] = 'Dm7'
        comp[20:32] = ['wait','late','one','room','wait','late','one','room','wait','late','close','wait']
        bass[20:32] = ['e','g','e','g','f','g','e','g','e','g','a','f']
    if version >= 2:
        comp[56:68] = ['wait','late','wait','late','ask','one','room','wait','wait','late','up','close']
        bass[56:68] = ['f','g','f','g','c','e','g','f','f','g','b','e']
        comp[68:72] = ['one','room','close','final']
        bass[68:72] = ['e','g','f','e']
        # C's no-cello bar becomes a genuine solo answer, anticipating the coda.
        comp[51] = 'empty'
    events=[]; bars=[]; pedals=[]
    def ev(b,t,d,p,v,voice,instrument):
        events.append(dict(bar=b,onset=round(4*(b-1)+t,8),duration=round(d,8),pitch=p,velocity=v,voice=voice,instrument=instrument))
    for b in range(1,73):
        start=4*(b-1); section,bpm=section_info(b)
        hn=harmonies[b-1]; pcs,voicing,root,fifth=H[hn]
        harmony=[p for p in range(36,84) if p%12 in pcs]
        solo = not bass[b-1] or bass[b-1]=='x'
        role_plan=(f'钢琴右手主题与选择性同节奏内声；左手中音区{comp[b-1]}和声支撑；'
                   + ('大提琴休止，留出独奏回应。' if solo else f'拨弦大提琴{bass[b-1]}型和弦低音句法支点（含转位），服从同一和声。'))
        bars.append(dict(bar=b,start=start,beats=4,bpm=bpm,section=section,meter_numerator=4,meter_denominator=4,
                         harmony_name=hn,harmony=harmony,role_plan=role_plan,lead_instrument='piano'))
        # Dynamic envelope is phrase-level. Cello velocity is amplitude ONLY.
        base = 76 if 5<=b<=20 else 70 if 21<=b<=32 else 79 if 33<=b<=44 else 74 if 45<=b<=56 else 78 if 57<=b<=68 else 69
        if b in [1,2,3,4]: base=66+b
        if b in [54,65,67]: base+=3
        for k,(t,p,d) in enumerate(melodies[b]):
            # A light long-short hierarchy; never claim random jitter is swing.
            off = abs((t%1)-S)<1e-6
            v=base + (3 if k==0 else 0) - (6 if off else 0) - (2 if k==len(melodies[b])-1 else 0)
            ev(b,t,d,p,v,'melody','piano')
            # Selective RH consonant lower note, no busy permanent chordal block.
            support_allowed = ((k==0 and b in [5,7,13,15,17,19,33,35,37,41,45,47,51,53,54,57,59,61,65,67,69,71,72])
                               or (b in [7,19,35,53,67] and k==2))
            if support_allowed:
                candidates=[q for q in range(max(64,p-9),p-2) if q%12 in pcs]
                if candidates:
                    q=min(candidates,key=lambda q:abs((p-q)-7))
                    ev(b,t,min(d,.96),q,max(43,v-19),'upper_support','piano')
        for j,(t,d,n) in enumerate(C[comp[b-1]]):
            chosen=voicing if n==3 else [voicing[0],voicing[-1]]
            for p in chosen:
                ev(b,t,d,p,(51 if 21<=b<=32 else 55) + (2 if j==0 else -1),'accompaniment','piano')
        # Only one low piano bass pickup, in an actual cello-rest bar. No low LH
        # bass line doubles the cello across the rest of this duo.
        if b==49:
            ev(b,0,.75,43,53,'bass','piano')
        for j,(t,d,which) in enumerate(CELLS[bass[b-1]]):
            p=root if which==0 else fifth
            v=(63 if 21<=b<=32 else 66 if 45<=b<=56 else 68) + (2 if j==0 else -3)
            if b>=69: v=62-j*2
            ev(b,t,d,p,v,'cello_bass','cello')
        # Short, deliberately shallow piano-only pedal windows; cleared before
        # a chord change. Damped pizzicato is not held with any controller.
        for t,d,n in C[comp[b-1]]:
            if d>=.64:
                pedals.extend([dict(onset=round(start+t+.04,8),value=34 if b!=72 else 45),
                               dict(onset=round(start+min(t+d,3.88),8),value=0)])
    pedals.append(dict(onset=288,value=0))
    events.sort(key=lambda e:(e['onset'],e['instrument'],e['pitch'],e['voice']))
    pedals.sort(key=lambda e:e['onset'])
    return dict(id=66,title='The Train of Forgotten Names',title_zh='遗忘姓名的列车',bars=bars,events=events,pedals=pedals,total_beats=288,tail_seconds=4)

def seconds_at(score,beat):
    sec=0.
    for b in score['bars']:
        if beat<=b['start']: break
        sec+= min(b['beats'],beat-b['start'])*60/b['bpm']
    return sec

def intersects(a,b):
    return a['onset']<b['onset']+b['duration']-1e-7 and b['onset']<a['onset']+a['duration']-1e-7

def audit(score):
    errors=[]; evs=score['events']; bs=score['bars']; cello=[e for e in evs if e['instrument']=='cello']
    expected_top={'id','title','title_zh','bars','events','pedals','total_beats','tail_seconds'}
    expected_bar={'bar','start','beats','bpm','section','meter_numerator','meter_denominator','harmony_name','harmony','role_plan','lead_instrument'}
    expected_event={'bar','onset','duration','pitch','velocity','voice','instrument'}
    if set(score)!=expected_top: errors.append('top-level schema')
    for i,b in enumerate(bs):
        if set(b)!=expected_bar or b['bar']!=i+1 or b['start']!=i*4 or b['beats']!=4 or b['lead_instrument']!='piano': errors.append(f'bar schema {i+1}')
    if len(bs)!=72 or score['total_beats']!=288: errors.append('length')
    for e in evs:
        if set(e)!=expected_event: errors.append('event schema')
        b=bs[e['bar']-1]
        if e['onset']<b['start']-1e-7 or e['onset']+e['duration']>b['start']+4+1e-7 or e['duration']<=0: errors.append(f'gate outside bar {e}')
        if not (1<=e['velocity']<=127) or not (0<=e['pitch']<=127): errors.append('MIDI domain')
        if e['instrument']=='cello' and (e['voice']!='cello_bass' or not 36<=e['pitch']<=47 or e['pitch'] not in b['harmony']): errors.append(f'cello range/harmony {e}')
        if e['instrument']=='piano' and e['voice'] not in ['melody','upper_support','bass','accompaniment']: errors.append('piano role')
    # Actual held-key hand spans at every start/end boundary, not score range.
    span_report={}
    for hand,voices,limit in [('right',{'melody','upper_support'},10),('left',{'bass','accompaniment'},12)]:
        relevant=[e for e in evs if e['instrument']=='piano' and e['voice'] in voices]
        times=sorted(set([e['onset'] for e in relevant]+[e['onset']+e['duration'] for e in relevant]))
        maximum=0; max_count=0; witness=None
        for t in times:
            active=[e['pitch'] for e in relevant if e['onset']<=t+1e-7 and e['onset']+e['duration']>t+1e-7]
            span=max(active)-min(active) if active else 0
            if span>maximum: maximum=span; witness={'beat':round(t,8),'pitches':active}
            max_count=max(max_count,len(active))
            if span>limit: errors.append(f'{hand} hand span {span} at {t}')
            if len(active)>5: errors.append(f'{hand} simultaneous keys {len(active)} at {t}')
        span_report[hand]={'max_simultaneous_span_semitones':maximum,'max_simultaneous_keys':max_count,'witness':witness}
    # Same-key collisions include different voices of the same piano.
    collisions=[]
    keyed=defaultdict(list)
    for e in evs: keyed[(e['instrument'],e['pitch'])].append(e)
    for key,group in keyed.items():
        group.sort(key=lambda x:x['onset'])
        for i,a in enumerate(group):
            for b in group[i+1:]:
                if b['onset']>=a['onset']+a['duration']-1e-7: break
                if intersects(a,b): collisions.append({'instrument_pitch':key,'a':a,'b':b})
    if collisions: errors.append(f'{len(collisions)} same-key collisions')
    overlaps=[]
    for a,b in zip(cello,cello[1:]):
        if intersects(a,b): overlaps.append([a,b])
    if overlaps: errors.append('overlapping cello gates')
    cello_secs=[seconds_at(score,e['onset']+e['duration'])-seconds_at(score,e['onset']) for e in cello]
    if min(cello_secs)<.35-1e-5 or max(cello_secs)>.75+1e-5: errors.append('cello gate seconds outside .35–.75')
    cello_gaps=[seconds_at(score,b['onset'])-seconds_at(score,a['onset']+a['duration']) for a,b in zip(cello,cello[1:])]
    melody=[e for e in evs if e['voice']=='melody']
    mel_overlaps=[(a,b) for a,b in zip(melody,melody[1:]) if intersects(a,b)]
    if mel_overlaps: errors.append('melody gate overlap')
    low_double=[(a,b) for a in evs if a['voice']=='bass' for b in cello if intersects(a,b)]
    if low_double: errors.append('redundant low piano bass/cello overlap')
    for p in score['pedals']:
        if set(p)!={'onset','value'} or not 0<=p['value']<=63 or not 0<=p['onset']<=288: errors.append('pedal schema/range')
    # Detect actual swing *onset groups* 0, 2/3, 1 (or translated beat).
    mel_onsets={round(e['onset'],7) for e in melody}
    triplets=[]
    for e in melody:
        t=e['onset']
        if abs(t-round(t))<1e-6 and round(t+S,7) in mel_onsets and round(t+1,7) in mel_onsets:
            triplets.append({'bar':e['bar'],'beat':int(round(t)),'long_short_ratio':2.0})
    if len(triplets)<35: errors.append('insufficient actual swung onset cells')
    durations=Counter(); ranges={}; counts=Counter(e['voice'] for e in evs)
    for voice in counts:
        group=[e for e in evs if e['voice']==voice]
        ranges[voice]={'pitch':[min(e['pitch'] for e in group),max(e['pitch'] for e in group)],'velocity':[min(e['velocity'] for e in group),max(e['velocity'] for e in group)]}
    arrivals=[]
    for bnum in [5,19,27,28,33,43,47,51,57,65,69,72]:
        bar=bs[bnum-1]; lead=next(e for e in melody if e['bar']==bnum)
        bassbar=[e for e in cello if e['bar']==bnum]
        arrivals.append({'bar':bnum,'harmony':bar['harmony_name'],'first_melody_pitch':lead['pitch'],
                         'first_melody_harmonic':lead['pitch'] in bar['harmony'],
                         'cello_pitches':[e['pitch'] for e in bassbar],
                         'piano_comp_cell': 'as written in role_plan'})
    return {
      'status':'PASS' if not errors else 'FAIL','errors':errors,'bars':len(bs),'total_beats':score['total_beats'],
      'score_seconds':round(seconds_at(score,score['total_beats']),6),
      'with_tail_seconds':round(seconds_at(score,score['total_beats'])+score['tail_seconds'],6),
      'counts_by_voice':dict(counts),'ranges':ranges,'hands':span_report,
      'same_key_collisions':len(collisions),'cello_overlaps':len(overlaps),'melody_overlaps':len(mel_overlaps),
      'piano_low_bass_cello_overlaps':len(low_double),
      'cello_gate_seconds':[round(min(cello_secs),6),round(max(cello_secs),6)],
      'cello_min_gap_seconds':round(min(cello_gaps),6),'actual_swing_cells':len(triplets),
      'swing_onset_evidence_first_12':triplets[:12],
      'common_harmony_arrivals':arrivals,
      'pedal_max':max(p['value'] for p in score['pedals']),
      'limitations':['No audio rendered or auditioned.','Held-key hand spans do not claim pedal-resonance spans are playable simultaneous fingering.',
                     'Pizzicato velocity is amplitude-only in the supplied single-mf layer.','Mechanical metrics do not guarantee listening quality.'],
    }

def diff(a,b):
    changed=[]; mel_changed=[]; harm_changed=[]; additions=0; removals=0
    for bar in range(1,73):
        aa=[e for e in a['events'] if e['bar']==bar]; bb=[e for e in b['events'] if e['bar']==bar]
        ca=Counter(json.dumps(e,sort_keys=True) for e in aa); cb=Counter(json.dumps(e,sort_keys=True) for e in bb)
        additions+=sum((cb-ca).values()); removals+=sum((ca-cb).values())
        if aa!=bb: changed.append(bar)
        if [e for e in aa if e['voice']=='melody'] != [e for e in bb if e['voice']=='melody']: mel_changed.append(bar)
        if a['bars'][bar-1]['harmony_name']!=b['bars'][bar-1]['harmony_name']: harm_changed.append(bar)
    return {'event_changed_bars':changed,'melody_changed_bars':mel_changed,'harmony_changed_bars':harm_changed,'added_events':additions,'removed_events':removals}

def write_json(name,value):
    (OUT/name).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')

def main():
    versions=[build(v) for v in range(3)]
    reports=[]
    for v,s in enumerate(versions):
        write_json(f'score_v{v}.json',s)
        report=audit(s); reports.append(report); write_json(f'audit_v{v}.json',report)
    write_json('score.json',versions[2])
    write_json('revision_changes.json',{'v0_to_v1':diff(versions[0],versions[1]),'v1_to_v2':diff(versions[1],versions[2])})
    write_json('form_design.json',{'sections':[{'start_bar':lo,'end_bar':hi,'name':name,'bpm':bpm} for lo,hi,name,bpm in SECTION_DATA],
                'key_center':'F major; relative-minor B and subdominant C','meter':'4/4 throughout','swing_ratio':'2:1, actual onsets at beat + 2/3',
                'cello_layer':'one existing mf pizzicato layer; velocity amplitude only','piano_hands':{'right':['melody','upper_support'],'left':['bass','accompaniment']},
                'melody_origin':'Newly composed explicit note lists; no melodic source material read/imported.',
                'final_harmony_by_bar':[x['harmony_name'] for x in versions[2]['bars']]})
    write_json('build_manifest.json',{'id':66,'final_score':'score_v2.json','script':'compose.py','non_rendering':True,
                  'sha256':{f'score_v{i}.json':hashlib.sha256((OUT/f'score_v{i}.json').read_bytes()).hexdigest() for i in range(3)}})
    print(json.dumps({'status':'PASS' if all(r['status']=='PASS' for r in reports) else 'FAIL',
                     'v0':reports[0],'v1':reports[1],'v2':reports[2]},ensure_ascii=False,indent=2))
    if any(r['status']!='PASS' for r in reports): raise SystemExit(1)

if __name__=='__main__': main()
