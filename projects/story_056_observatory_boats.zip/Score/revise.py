import pathlib,json,copy,collections
P=pathlib.Path(__file__).parent;v1=json.loads((P/'revisions/score_v0.json').read_text());v1['stage']='v1_still_water_and_new_transition'
def replace_bar(bar,line,h,ch,lv,sparse=False):
 b=v1['bars'][bar-1];b.update(harmony_name=h,harmony=ch);beat=b['start'];v1['events'][:]=[e for e in v1['events']if e['bar']!=bar];off=0
 for n,l in line:
  if n>=0:v1['events'].append(dict(bar=bar,onset=beat+off,duration=l*.98,pitch=n,velocity=lv,voice='melody'))
  off+=l
 assert off==6
 for t,n in [(0,ch[0]),(3,ch[0]+12)]:v1['events'].append(dict(bar=bar,onset=beat+t,duration=.32,pitch=n,velocity=lv-28,voice='bass'))
 for t,n in[(.5,ch[1]),(1,ch[2]),(1.5,ch[3]),(2,ch[2]),(2.5,ch[1]),(3.5,ch[2]),(4,ch[3]),(4.5,ch[2]),(5,ch[1]),(5.5,ch[2])]:
  if sparse and t not in(1.5,4.5):continue
  v1['events'].append(dict(bar=bar,onset=beat+t,duration=.43,pitch=n,velocity=lv-40,voice='accompaniment'))
# The extra two folding bars become a fresh connecting sentence, not a repeated theme opening.
replace_bar(21,[(81,1),(78,1),(74,.5),(73,.5),(71,1),(74,1),(78,1)],'D',[38,54,57,62],76)
replace_bar(22,[(80,1.5),(77,.5),(73,1),(68,1),(73,1.5),(-1,.5)],'Cs7',[49,56,59,65],73)
# Four deliberately balanced phrases over a stationary tonic, then a prepared departure.
lines=[[(78,1.5),(81,1.5),(78,1.5),(73,1.5)],[(78,1.5),(81,1.5),(80,1.5),(78,1.5)],[(73,1.5),(78,1.5),(81,1.5),(78,1.5)],[(81,1.5),(80,1.5),(78,1.5),(73,1.5)]]
for bar,line in zip(range(31,35),lines):replace_bar(bar,line,'Fsm',[42,54,57,61],61+(bar-31),True)
replace_bar(35,[(71,1),(74,.5),(78,.5),(81,1),(78,1),(74,1),(71,1)],'Bm',[47,54,59,62],67,True)
replace_bar(36,[(77,1),(80,.5),(83,.5),(85,1),(83,1),(80,1),(77,.5),(-1,.5)],'Cs7',[49,56,59,65],70,True)
(P/'revisions/score_v1.json').write_text(json.dumps(v1,indent=2));(P/'revisions/pass1.json').write_text(json.dumps({'pass':1,'changes':['Write a new two-barD→C#7 transition at the end of the ten-bar folding section, instead of reusing its opening.','Recompose the six-bar perfect-boat episode as four balanced tonic phrases, followed byBm→C#7 departure, coordinating all voices.','The next close-spaced theme now resolves that harmonic tension; the later major transformation is retained.']},indent=2))
v2=copy.deepcopy(v1);v2['stage']='v2_five_plus_three_phrasing_and_compound_breath'
for e in v2['events']:
 b=v2['bars'][e['bar']-1];kind=b['role_plan'];local=e['onset']-b['start']
 if e['voice']=='melody':
  if kind in('boat','uneven','sky'):
   starts={'boat':5,'uneven':37,'sky':45};j=e['bar']-starts[kind];e['velocity']+=[0,2,4,1,-4,2,3,-3][j]
  if kind=='still':e['duration']*=.91
  else:e['duration']*=1.008
 elif e['voice']=='accompaniment'and local in(1.5,4.5):e['velocity']-=1
# Pedal joins each long5+3sentence but clears before its boundary; no independent late bass tag.
for bar in(9,41,49):
 b=v2['bars'][bar-1];cut=b['start']+5.5;v2['pedals']=[e for e in v2['pedals']if not(cut<=e['onset']<b['start']+6)]+[dict(onset=cut,value=0)]
 v2['events']=[e for e in v2['events']if not(e['bar']==bar and e['voice']=='accompaniment'and e['onset']>=cut)]
by=collections.defaultdict(list);omit=set();fix=[]
for i,e in enumerate(v2['events']):by[e['pitch']].append((i,e))
for pitch,seq in by.items():
 seq.sort(key=lambda x:x[1]['onset'])
 for (ia,a),(ib,b)in zip(seq,seq[1:]):
  if ia in omit or ib in omit:continue
  if a['onset']+a['duration']>b['onset']+.001:
   if a['voice']=='melody'and b['voice']=='accompaniment':omit.add(ib);fix.append({'bar':b['bar'],'pitch':pitch,'change':'omit retrigger under melody'})
   elif abs(a['onset']-b['onset'])<.001:omit.add(ib if a['voice']=='melody'else ia);fix.append({'bar':b['bar'],'pitch':pitch,'change':'single shared-key onset'})
   else:a['duration']=max(.025,b['onset']-a['onset']-.02);fix.append({'bar':b['bar'],'pitch':pitch,'change':'release before next articulation'})
v2['events']=[e for i,e in enumerate(v2['events'])if i not in omit];(P/'revisions/score_v2.json').write_text(json.dumps(v2,indent=2));(P/'score.json').write_text(json.dumps(v2,indent=2));(P/'revisions/pass2.json').write_text(json.dumps({'pass':2,'changes':['Give the main5+3bar sentences a five-bar growth-and-arrival arc, followed by a three-bar answering motion.','At each five-bar arrival, clear pedal and late accompaniment together with the melodic breath.','Keep four compound beats fluid while connecting melody touch; the geometrically perfect boats remain more separated.','Review physical-key arbitration across voices.'],'key_corrections':fix},indent=2));print('56v2 ready',len(fix),'key corrections')
