Shared clarinet data and mapping, not a standalone song.
OfficialUniversityofIowa samples may be used for any projects without restrictions per https://theremin.music.uiowa.edu/MIS.html . Credits and individual originalsource URLs/hashes are inprovenance.json. Originals remain unchanged.
Derived WAVnotes preserve source16bitmonoPCM, with documented crop boundaries, no resampling or amplitude normalization. SFZtuning/velocity maps are adaptations. Three actual recorded dynamics, no true legato and no loops. Keep note durations<=1.55seconds or develop a separately tested sustain strategy.
Initial AIFFcompatibility failure and exact WAVcontainer control are documented in the sibling feasibility folder, which is also in the checkpoint archive.
