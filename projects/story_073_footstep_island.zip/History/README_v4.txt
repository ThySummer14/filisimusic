脚步长成的岛 / An Island Made of Footsteps — v4
原创虚构故事与长笛、大提琴拨弦二重奏。88个音乐小节，最终180.7秒。两轮实质谱面改写改变赶路时的内容收缩、折返实验的5/4与3/4分配和工作路线的回归。第三轮按照真实长笛音高/力度层气头提前触发，全部原定收音保留；第四轮实际REAPER总线检查后稍减拨弦支撑，整理尾响。

完整包中的073_footstep_island_v4.rpp是双音频轨工程，包含真实float32演奏源轨与REAPER内置房间效果，可直接播放/再导出。独立MIDI与JSON乐谱可编辑。精简包省略源轨和音频，修改音符后的再生成需要外部Iowa采样银行、sfizz1.2.3、Python3和NumPy，依赖与映射另附。
长笛使用Iowa真实pp/mf颤音录音，单声道16bit，最长实际门控0.9929秒，释放0.12；最终score/MIDI已含单次气头补偿，不可再次提前。大提琴只用一个mf拨弦录音层，原始单声道16bit；力度只改幅度，门控0.45–0.65秒，释放0.10。没有真连奏、循环延音或弓奏模拟。float32/24bit不增加原始录音精度。

音源University of Iowa MIS，Lawrence Fritts主持。长笛Sonja Feig，John Ritz和Michael Cash录音，https://theremin.music.uiowa.edu/MISflute.html 。大提琴Jean Montes，Michael Cash和Andrew Stuck-Marcell录音，https://theremin.music.uiowa.edu/MIScello.html 。官方许可https://theremin.music.uiowa.edu/MIS.html 允许用于任何项目，并不称CC0。样本未重复装入工程。
实际隔离总线用于验证主伴与尾响；某些小节长笛结束后是独立拨弦回答，不把整小节能量比误当作听感遮盖。最长/最短门控、换气、零削波和便携PCM均有记录；没有声称真人演奏或人工听审。
