# Work 66: two substantive score revisions

All three stages are complete 72-bar scores, kept in `score_v0.json`, `score_v1.json`, and `score_v2.json`. `compose.py` reproduces every stage without randomness or external libraries. Revision counts below describe content changes, not evidence of a listening-quality improvement.

## Revision 1: rewrite the minor carriage scene (v0 → v1)

Problem in the first score: B (bars 21–32) used connected, regular two-half-bar melodic lines with the same broad comping throughout. That made the traveler sound as though she was simply singing a second tune; it did not make the conductor's insistence and her pauses musically consequential.

Actual composition changes:
- Rewrote the pitches, durations and entrances of all 12 B melody bars. The new motif is F5–D5–C5 with a separated later response, contrasted with A's A4–C5–D5.
- Bars 22, 24, 26, 28 and 30 now answer later inside the bar. Bars 23 and 27 finish early and leave genuine space.
- Changed bar 28 from D7 to Dm7, making the response a relative-minor arrival rather than immediately converting it into another dominant.
- Rewrote all 12 B accompaniment/bass patterns in relation to those entrances. The cello waits for the same second-beat arrival at bar 28 instead of proceeding with an independent pulse.

Measured event diff: 12 melody bars changed, 98 events added and 105 removed; bar 28 harmony changed. Both the melody and its phrase support were recomposed.

## Revision 2: make the return accept the new rhythm (v1 → v2)

Problem after revision 1: the closing return still mostly restored the original punctual A phrase. It therefore undid the dramatic choice made in the contrasting section; the coda was also overly declarative.

Actual composition changes:
- Rewrote all 16 melody bars 57–72. The opening contour remains identifiable, while answer bars 58, 60 and 66 take their delayed entry from B.
- Newly composed bars 61–68 develop the question, temporarily leave room in bars 62–63, and climb to a shared dominant preparation; they are not a transposition of the original eight-bar passage.
- Rewrote the cello and middle-voice comping of the return around these new phrase placements. The final C9–F6 cadence retains a clear common harmonic arrival.
- Coda bars 69–70 now split the question and its late answer instead of filling both bars with a straight four-beat melody. The ritard is built into the bar tempo map, not only a textual instruction.
- Removed the remaining left-hand comping from bar 52, already a cello-rest bar. This gives the conductor's earlier “listening” moment an exposed single-line response and prepares the logic of the ending.

Measured event diff: 17 event-changed bars including bar 52; 16 melody bars changed; 124 events added and 167 removed. Duration and overall harmonic route remained fixed to isolate the substantial phrase/texture rewrite.

## Final review

The final score remains a piano-led swing duo. It has actual 2:1 eighth-note onsets, a 16-bar first subject, contrasting 12-bar minor and subdominant sections, shortened/developed returns, and a four-bar coda. It is not an iterated 12-bar blues. No rendering or auditioning was performed, so these are compositional judgments for the parent's later audible review.
