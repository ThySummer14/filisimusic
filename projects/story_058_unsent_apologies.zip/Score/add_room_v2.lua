local path='PRODUCTION_ROOT/058_unsent_apologies/revisions/058_duet_v2.rpp'
local tr=reaper.GetMasterTrack(0)
local fx=reaper.TrackFX_AddByName(tr,'ReaVerbate (Cockos)',false,-1)
assert(fx>=0,'Bundled ReaVerbate required for this mix')
for i,v in pairs({[0]=0.06,[1]=1,[2]=0.20,[3]=0.60,[4]=0.70,[5]=0,[6]=1,[7]=0})do reaper.TrackFX_SetParam(tr,fx,i,v)end
reaper.Main_SaveProject(0,false)
local f=assert(io.open('PRODUCTION_ROOT/058_unsent_apologies/revisions/native_room_v2_saved.txt','w'));f:write('Actual REAPER stock ReaVerbate on master: wet0.06, dry1, room0.20, damp0.60, width0.70. Saved own project.');f:close()
reaper.Main_OnCommand(40004,0)
