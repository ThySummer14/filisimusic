# Two substantive revisions

## v0: complete first composition

v0 is a complete 60-bar, 665-note score, not a fragment. It already contains the narrative bridge, original melody, entire return and eight-bar coda. The first four bars of the main phrase use relatively square quarter-note motion. The central monologue is still 4/4 throughout; the return repeats the initial harmonic scheme too literally.

## v0 → v1: make the door motif sing, let the central speech change time

The first melodic bar changes from G4(1)–Bb4(1)–C5(1)–Bb4(1) to G4(1)–Bb4(½)–C5(½)–Bb4(1)–G4(1). This adds a recognizable return to the opening note, gives the door-handle gesture its two quicker taps, and lets the phrase continue down into the following bar. Bars6–8 are also recomposed: the second bar now begins on F rather than Ab, the third moves through G rather than a static succession of chord tones, and the fourth includes the chromatic Ab–A–Bb approach.

The same four-bar thematic changes are applied at37–40 so the complete version has a coherent theme and return. Bars29–36 are entirely rephrased. Their meter plan changes from eight 4/4 bars to 3/4–5/4–4/4–4/4–3/4–5/4–4/4–4/4. The overall thirty-two-beat span stays intact, but individual statements shorten or lengthen, with note values of ¼,½,¾ and whole beats. Left-hand arrivals move from the regular accompaniment pattern to speech-related positions. Bar33 changes G7(b9) to Bdim7, opening a chromatic hinge toward C minor. Bar tempos also become varied.

Exact diff: 102 event records removed; 113 added. Changed melody bars: 5–8, 29–36, 37–40. Complete version grows to 676 events and 301 melody notes. Final duration is 205.545 seconds including tail. See exact_diff_v0_to_v1.json for every removed and added note, every changed bar field and both complete pedal lists.

## v1 → v2: let her action change the return and ending

All sixteen return harmonies change. The opening now goes Cm9–Fm9/Ab–Dbmaj9–Gbmaj9, with the first three melodic bars retained as recognition and bar40 rewritten for the new harmony. The next twelve bars develop the line around Ab minor, E diminished, F minor and the suspended Eb dominant into the coda. This is a changed harmonic destination and phrase trajectory, not an accompaniment transposition under an unchanged loop.

Bars42–44 move through Ab–B–Bb–Ab–F, an answering climb to C, and a Bb-dominant half cadence; the previous tonic answer is deferred. Bars45–48 create the upper-return climax followed by a newly composed descent through the E diminished chord. Bar49 starts at C4 and grows upward as the cloth is stretched. Bars51–52 turn into the coda instead of repeating the old Bb7(b9)–Eb ending.

Bar33 changes its A-natural start to Ab, so the monologue’s accented first note belongs to its B diminished harmony; Bb and C remain brief approaches to B and D. The last two coda harmonies change from repeated Ebmaj9 to Eb6/9 then Eb(add9). Bar59 now descends Eb5–Bb4–G4–F4, handing F smoothly down to the final Eb4, instead of reusing the older D5 descent. Left-hand doubling is adjusted where the melody itself supplies D4 or F4, avoiding same-key overlaps. Fuller return shells underline the change of purpose.

Exact diff: 145 event records removed; 160 added. Changed melody bars: 33,40,42–52,59. Harmony changes: 37–52,59–60. Final complete score contains 691 events. See exact_diff_v1_to_v2.json. Duration remains 205.545 seconds; the second revision changes musical content without expanding the allotted time.

## Mechanical review applied consistently to all versions

The three versions all include explicit safe left-hand release articulation before wide travel. The change history therefore compares complete playable symbolic versions rather than penalizing v0 for an avoidable mechanical issue. Notes sharing a key at the same onset across hands are assigned to the melody hand; sustained same-key collisions are separately audited and rejected. The accompaniment in monologue bar35 avoids prematurely holding the upcoming melodic D4, and final bar59 leaves the melodic F4 free.

Final audits: left held span ≤11 semitones, right ≤0 because it is monophonic; no same-key overlaps; no flagged fast wide transfers. Forty-three left-hand transfers exceed an octave by grip-center distance, all with ≥0.268 seconds of explicit released travel. The maximum melodic leap is six semitones, 99.33% of intervals are ≤5 semitones, and the longest notated silence between melody notes is about 0.1114 seconds. These are evidence for connectedness and physical feasibility, not a substitute for listening.

Every note, harmony sequence and narrative action was written for this work. The work078 file was consulted solely for the JSON schema. No theme, event sequence, audio, orchestration or story was imported.
