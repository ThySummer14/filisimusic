# Symbolic audit — final v2

The checks are performed by generate.py and saved independently for all three full scores. This is a score-level review, not an audio audition or a claim about the installed instrument's actual half-pedal response.

## Form, timing, and scope

- 144 complete 6/8 bars, exactly 432 quarter beats.
- Every handwritten melody bar accounts for six eighth-note units, including explicit rests.
- Music: 202.390 seconds from the actual per-bar tempo map; tail: 6 seconds; expected total: 208.390 seconds (3:28.39).
- Final score: 1,581 note events, all instrument=piano. MIDI range A1–F♯6 (33–90).
- Voice counts: 508 melody, 17 occasional melody octaves, 225 right-hand support, 145 bass, 686 left-hand support.
- No synthesis, audio file, rendering, playback, instrument installation, publication, or REAPER state change was performed in this directory.

## Hands and key ownership

Every onset is checked against all still-held notes belonging to that hand. The maximum simultaneous key-down span is 12 semitones in each hand; no held span exceeds an octave. The left hand holds at most two notes and the right at most four. Pedal-sustained strings do not count as physically held fingers.

Every MIDI key is checked for overlapping key-down durations across all voices and both hands. There are zero same-key overlaps. A later note may re-strike a released, pedaled string, as in ordinary piano playing.

The left-hand wave is turned downward before a low following bass when necessary. This removes the quick 14–17-semitone relocations produced by a naïve repeated arpeggio. The final score has no adjacent attack-group nearest-note distance greater than 12 semitones in either hand. This statistic is a useful screening check, not a substitute for fingering every chord.

One melody-only leap exceeds an octave: bar 120, D6→A4, down 17 semitones. It is the deliberate descent out of the climax, not rapid noodling. The first note also has a lower D5 octave, placing the hand's thumb only a fifth above the next A4. The D6/D5 octave releases after 1.60 of its 2.00 beats under full pedal, leaving 0.40 beat for the relocation. A4 is followed by an explicit eighth rest before the next bar's A3. The former v0/v1 high-register homecoming also contained larger jumps into the coda; the v2 rewrite removes those.

## Phrases and harmonic arrival

All 18 eight-bar groups end on a chord tone of their written final harmony. All nonfinal groups have an explicit rest or comparable release space at their end; the storm ends with more than one quarter beat of clear melodic breathing room. The final tonic uses release into the tail rather than a notated breath before another phrase.

The audit records the actual final harmony, final note, previous harmony, range, note count and remaining breath for every group. Cadence descriptions distinguish open dominants from completed arrivals:

- Bars 8/16/64/88 and 112 hold or establish a dominant; they are not falsely called completed tonic cadences.
- Bars 39–40 and 55–56 carry actual leading-tone melodic resolutions C♯→D and F♯→G.
- Bars 47–48 use F7→B♭, with the tonic melody delayed after D5.
- The revised boat passage reaches F in bar 80 with the melody on its third, then leaves again; it is not the final emotional resolution.
- The broad D-major arrival occurs in 119–120; the quieter A7→D endings at 127–128, 135–136 and 143–144 complete the story at lower altitude.

The melody contains 54 upward-fourth intervals across the piece. They include the identifiable A→D launches, their F/B♭/G-level transformations, and the A3→D4 final theme. The motif count alone does not prove thematic quality; the score and form notes identify how its rhythmic and harmonic role changes.

## Pedal

All pedal values are exactly 0, 42 or 76. 42 is the intended partial pedal and 76 the intended full pedal. Each moving bar includes a clear between its two compound beats, and the final event is CC64=0 at absolute quarter beat 432. The final six seconds are resonance space after that explicit release. The chosen piano must support its own intended continuous-pedal behavior for 42 to sound as a partial pedal.

## Revision evidence

- v0→v1: all 16 melody bars 73–88 change; 6 harmony names change (74, 75, 76, 79, 80, 81); accompaniment changes from flight to water-shaped support.
- v1→v2: all 16 melody bars 121–136 change; 5 harmony names change (123, 125, 126, 130, 134); register, rhythm, inner voices and pedal are recomposed together.
- revision_diff.json includes exact removed and added note events and pedal events, so these are inspectable musical revisions rather than descriptive claims.

All structural checks pass for v0, v1 and v2. Larger phrase-transition leaps remain documented in the earlier versions; the final version has the more integrated register plan. The piano sound and overall acoustic balance still need the owner's normal listening check on the approved performance path.
