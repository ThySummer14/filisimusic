#!/usr/bin/env python3
"""Write a manifest for selected v3, including preserved historical artifacts."""
import hashlib
import json
from pathlib import Path
P = Path(__file__).resolve().parent
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
assert (P/'score.json').read_bytes() == (P/'score_v3.json').read_bytes()
a = json.loads((P/'independent_verification_v3.json').read_text())
assert a['passed'] and a['selected_score_sha256'] == sha(P/'score.json')
files = {}
for p in sorted(P.rglob('*')):
    if not p.is_file() or p.suffix not in ('.json','.py','.md','.txt'): continue
    relative = p.relative_to(P).as_posix()
    if relative in ('hash_manifest.json','hash_manifest_v3.json'): continue
    files[relative] = sha(p)
m = {'algorithm':'SHA-256','selected_score':'score.json','selected_version':'v3',
     'score_sha256':sha(P/'score.json'),'files':files,
     'history':'historical_v2 contains the entire prior package; hash_manifest_v2.json is an exact preserved copy of its manifest.',
     'scope':'Symbolic playability revision only. No audio, external owner copy, or files outside this draft folder were changed.'}
text=json.dumps(m,ensure_ascii=False,indent=2)+'\n'
(P/'hash_manifest_v3.json').write_text(text)
(P/'hash_manifest.json').write_text(text)
assert all(sha(P/n)==h for n,h in files.items())
print('Verified',len(files),'hashes; selected score SHA-256',m['score_sha256'])
