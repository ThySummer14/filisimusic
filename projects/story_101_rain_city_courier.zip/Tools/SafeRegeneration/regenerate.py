#!/usr/bin/env python3
"""Fail-closed, explicit-path regeneration for reviewed Moonlight and small Iowa SFZs."""
import argparse
import hashlib
import json
import math
import os
from pathlib import Path
import shutil
import signal
import struct
import subprocess
import sys
import time
from sfz_support import emit, inspect, require, sha, verify_emitted, verify_native

HERE = Path(__file__).resolve().parent
MIB = 2**20


def json_write(path, value):
    with Path(path).open('x', encoding='utf-8') as f:
        json.dump(value, f, indent=2); f.write('\n')


def verify_bundle():
    manifest = json.loads((HERE / 'bundle_integrity.json').read_text())
    for name, expected in manifest['files'].items():
        require(Path(name).name == name, 'Invalid bundle filename.')
        require(sha(HERE / name) == expected, 'Bundled support file changed: ' + name)
    return manifest


def rss_tree_kib(pid):
    # ps supports both Linux and macOS; include all descendants, not other users' jobs.
    result = subprocess.run(['ps', '-axo', 'pid=,ppid=,rss='], capture_output=True, text=True, check=True, timeout=1)
    entries = [tuple(map(int, line.split())) for line in result.stdout.splitlines() if line.strip()]
    owned = {pid}
    while True:
        found = owned | {p for p, parent, rss in entries if parent in owned}
        if found == owned: break
        owned = found
    return sum(rss for p, parent, rss in entries if p in owned)


class StageInterrupted(KeyboardInterrupt):
    """A caught wrapper signal, re-raised only after its owned stage was cleaned up."""
    def __init__(self, signum):
        self.signum = signum
        super().__init__('Interrupted by ' + signal.Signals(signum).name)


def signal_owned_group(process, signum):
    if process is None:
        return False
    try:
        os.killpg(process.pid, signum)
        return True
    except ProcessLookupError:
        return False


def stop_owned_group(process):
    """Clean the entire new-session stage, even if its leader already exited."""
    if process is None:
        return
    signal_owned_group(process, signal.SIGTERM)
    deadline = time.monotonic() + 0.5
    while time.monotonic() < deadline:
        process.poll()  # Reap the direct child promptly; descendants share its group.
        if not signal_owned_group(process, 0):
            break
        time.sleep(0.02)
    signal_owned_group(process, signal.SIGKILL)
    process.wait(timeout=1)


def run_guarded(command, log_path, cap_mib, timeout, env):
    require(os.name == 'posix' and shutil.which('ps'), 'Execution needs Linux/macOS with ps for the process-tree RAM guard. Dry-run is still available.')
    rss_tree_kib(os.getpid())  # Check the observation route before spawning an engine.
    start, peak, reason = time.monotonic(), 0, None
    process, interrupted, previous, cleaned = None, None, {}, False
    def request_stop(signum, frame):
        nonlocal interrupted
        if interrupted is None:
            interrupted = signum
        # Forward immediately, including while waiting for a ps observation. Do not
        # raise inside Popen: recording first closes the spawn/handler race.
        signal_owned_group(process, signal.SIGTERM)
    for sig in (signal.SIGTERM, signal.SIGINT):
        previous[sig] = signal.signal(sig, request_stop)
    try:
        with Path(log_path).open('x') as log:
            try:
                if interrupted is not None:
                    raise StageInterrupted(interrupted)
                process = subprocess.Popen(command, stdout=log, stderr=subprocess.STDOUT, env=env, start_new_session=True)
                if interrupted is not None:
                    signal_owned_group(process, signal.SIGTERM)
                while process.poll() is None:
                    if interrupted is not None:
                        reason = 'Interrupted by ' + signal.Signals(interrupted).name
                        break
                    peak = max(peak, rss_tree_kib(process.pid))
                    if peak > cap_mib*1024: reason = 'Observed process-tree RSS exceeded cap.'
                    if time.monotonic()-start > timeout: reason = 'Stage exceeded its explicit timeout.'
                    if reason: break
                    time.sleep(0.05)
            except BaseException as exc:
                reason = 'RAM observation failed or execution was interrupted.'
                if interrupted is not None:
                    raise StageInterrupted(interrupted) from exc
                raise
            finally:
                stop_owned_group(process)
                cleaned = True
                if interrupted is not None:
                    reason = 'Interrupted by ' + signal.Signals(interrupted).name
                result = {'command': command, 'exit_code': None if process is None else process.returncode,
                          'peak_observed_tree_rss_kib': peak, 'elapsed_seconds': round(time.monotonic()-start, 3),
                          'stop_reason': reason, 'interruption_signal': interrupted,
                          'owned_stage_process_group': None if process is None else process.pid,
                          'owned_stage_cleanup_completed': True}
                json_write(str(log_path) + '.result.json', result)
            if interrupted is not None:
                raise StageInterrupted(interrupted)
    finally:
        # Covers errors during log setup as well as interruptions during spawning.
        if not cleaned:
            stop_owned_group(process)
        for sig, handler in previous.items():
            signal.signal(sig, handler)
    require(reason is None and process.returncode == 0, 'Stage failed; inspect ' + str(log_path))
    return result


def bind_inputs(plan, library):
    require(sha(plan['source_sfz']) == plan['source_sha256'], 'Original SFZ changed.')
    require(sha(plan['score']) == plan['score_sha256'], 'Score changed.')
    require(sha(library) == plan['library_sha256'], 'Native library changed.')
    for sample in plan['samples']:
        require(sha(sample['sample']) == sample['sha256'], 'Original sample changed: ' + sample['sample'])


def input_provenance(plan, native, subset):
    """Self-contained successful-manifest inputs and actual original-engine bounds."""
    samples = [{'sample_relative_to_original_sfz': os.path.relpath(x['sample'], Path(plan['source_sfz']).parent).replace(os.sep, '/'),
                'sha256': x['sha256']} for x in plan['samples']]
    samples.sort(key=lambda x: x['sample_relative_to_original_sfz'])
    sample_set_hash = hashlib.sha256(json.dumps(samples, sort_keys=True, separators=(',', ':')).encode()).hexdigest()
    return {'score_sha256': plan['score_sha256'], 'original_bank_sfz_sha256': plan['source_sha256'],
            'library_sha256': plan['library_sha256'], 'renderer_sha256': plan['renderer_sha256'],
            'rendered_original_samples': samples, 'rendered_sample_set_sha256': sample_set_hash,
            'sample_hash_scope': 'Every original sample used by this run; not a claim to hash unrendered bank files.',
            'derived_ram_sfz_sha256': sha(subset), 'native_bounds': native,
            'max_seconds': plan['score_info']['max_seconds'], 'enable_details': plan['enable_details']}


def check_float32_output(path, expected_frames):
    # Original renderer writes this exact RIFF header. Check the whole payload in bounded chunks.
    with Path(path).open('rb') as f:
        header = f.read(44)
        require(len(header) == 44 and header[:4] == b'RIFF' and header[8:16] == b'WAVEfmt ', 'Unexpected WAVE container.')
        require(struct.unpack('<IHHIIHH', header[16:36]) == (16, 3, 2, 44100, 44100*8, 8, 32), 'Output is not genuine stereo IEEE float32 at 44100 Hz.')
        require(header[36:40] == b'data' and struct.unpack('<I', header[40:44])[0] == expected_frames*8, 'Incorrect output length.')
        require(Path(path).stat().st_size == 44 + expected_frames*8, 'Truncated output.')
        for chunk in iter(lambda: f.read(1024*1024), b''):
            require(all(math.isfinite(value[0]) for value in struct.iter_unpack('<f', chunk)), 'Non-finite output samples.')


def build_parser():
    ap = argparse.ArgumentParser(description=__doc__)
    for arg in ('score', 'sfz', 'library', 'out'):
        ap.add_argument('--' + arg, required=True, type=Path)
    ap.add_argument('--mode', required=True, choices=('moonlight-subset', 'complete-bank'))
    ap.add_argument('--ram-cap-mib', required=True, type=float, help='Estimated and observed child-process RAM cap in MiB.')
    ap.add_argument('--reserve-mib', type=float, default=128, help='Engine/Python/allocator reserve, minimum 128 MiB.')
    ap.add_argument('--max-seconds', type=float, help='Explicit prefix limit, bound into plan and native proof; omitting renders bars plus tail.')
    ap.add_argument('--enable-details', action='store_true', help='Preserve the original renderer flag when the original render used it.')
    ap.add_argument('--work-dir', type=Path, help='New audit directory; default OUT.regeneration. Never overwrites.')
    ap.add_argument('--timeout-seconds', type=float, default=600, help='Timeout per native-query/render stage.')
    ap.add_argument('--dry-run', action='store_true', help='Inspect headers and hashes, estimate RAM, print plan; no library load or files written.')
    ap.add_argument('--verify-only', action='store_true', help='Prepare and run native coverage verification but do not render audio.')
    return ap


def main(argv=None):
    a = build_parser().parse_args(argv)
    require(not (a.dry_run and a.verify_only), 'Choose dry-run or verify-only, not both.')
    for name in ('score', 'sfz', 'library'):
        path = getattr(a, name).expanduser().resolve()
        require(path.is_file(), 'Missing explicit input: ' + str(path)); setattr(a, name, path)
    a.out = a.out.expanduser().resolve()
    require(a.out.suffix.lower() == '.wav', '--out must name a new WAV file.')
    work = (a.work_dir or a.out.with_suffix('.regeneration')).expanduser().resolve()
    require(work != a.out and work not in (a.score, a.sfz, a.library), 'Work/output paths collide with inputs.')
    require(not work.exists() and not a.out.exists() and not a.out.with_suffix('.render.json').exists(), 'Output, sidecar or work directory exists; use new paths.')
    require(all(math.isfinite(v) and v > 0 for v in (a.ram_cap_mib, a.reserve_mib, a.timeout_seconds)), 'Caps and timeout must be positive and finite.')
    require(a.reserve_mib >= 128, 'The process reserve cannot be less than 128 MiB.')
    bundle = verify_bundle()
    plan = inspect(a.sfz, a.score, a.mode, a.max_seconds)
    # Complete mode is deliberately bounded to small Iowa-type banks. It cannot be used to RAM-load Moonlight.
    require(a.mode != 'complete-bank' or plan['decoded_sample_bytes'] <= 256*MIB, 'Complete-bank mode is limited to 256 MiB decoded samples; large piano banks are forbidden.')
    require(a.mode != 'moonlight-subset' or len(plan['samples']) < plan['all_sample_count'], 'Moonlight mode refuses full-bank sample decoding, even if some duplicate regions were removed.')
    reserve = math.ceil(a.reserve_mib*MIB)
    planned_render = plan['decoded_sample_bytes'] + plan['largest_read_temporary_bytes'] + reserve
    planned_query = plan['query_preload_bytes'] + plan['query_largest_read_temporary_bytes'] + reserve
    require(max(planned_render, planned_query) <= a.ram_cap_mib*MIB,
            f'RAM plan exceeds cap: render={planned_render/MIB:.3f} MiB, query={planned_query/MIB:.3f} MiB, cap={a.ram_cap_mib:.3f} MiB. No engine was loaded.')
    for sample in plan['samples']:
        sample['sha256'] = sha(sample['sample'])
    plan.update({'schema_version': 1, 'selection_version': 'V-1,V,V+1 guarded original-region superset',
                 'library': str(a.library), 'library_sha256': sha(a.library), 'renderer_sha256': sha(HERE/'render_score_sfizz.py'),
                 'enable_details': a.enable_details, 'ram_cap_mib': a.ram_cap_mib, 'reserve_mib': a.reserve_mib,
                 'estimated_render_mib': planned_render/MIB, 'estimated_query_mib': planned_query/MIB,
                 'status': 'STATIC_PLAN_ONLY_NOT_NATIVE_VERIFIED', 'output': str(a.out), 'work_dir': str(work),
                 'limits': 'Planning estimate plus polled RSS guard, not a kernel-enforced peak guarantee. No audio-equivalence claim.'})
    if a.dry_run:
        print(json.dumps(plan, indent=2)); return 0
    # Verify runtime prerequisites without installing anything. Import check does not run the renderer.
    require(os.name == 'posix' and shutil.which('ps'), 'Actual execution requires Linux/macOS with ps; use --dry-run elsewhere.')
    if not a.verify_only:
        import importlib.util
        require(importlib.util.find_spec('numpy') is not None, 'Existing Python environment needs NumPy. Nothing was downloaded or installed.')
    work.mkdir(parents=True, exist_ok=False)
    json_write(work/'plan.json', plan)
    try:
        subset = work/'verified_ram.sfz'; emit(plan, subset); verify_emitted(plan, subset)
        env = dict(os.environ, SFIZZ_LIBRARY=str(a.library), OMP_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1', MKL_NUM_THREADS='1')
        native_path = work/'native_bounds.json'
        native_cmd = [sys.executable, str(HERE/'query_native_bounds.py'), '--sfz', str(a.sfz), '--library', str(a.library), '--out', str(native_path)]
        query_result = run_guarded(native_cmd, work/'native_query.log', a.ram_cap_mib, a.timeout_seconds, env)
        native = json.loads(native_path.read_text())
        require(native.get('ram_hint_recognized_by_engine') is True, 'Engine did not positively recognize the RAM-hint probe.')
        validation = verify_native(plan, subset, native, a.library)
        validation.update({'native_manifest_sha256': sha(native_path), 'score_sha256': plan['score_sha256'],
                           'source_sfz_sha256': plan['source_sha256'], 'plan_sha256': sha(work/'plan.json')})
        json_write(work/'native_validation.json', validation)
        bind_inputs(plan, a.library); verify_bundle()
        if a.verify_only:
            json_write(work/'result.json', {'status': 'NATIVE_COVERAGE_VERIFIED_NOT_RENDERED', 'validation': validation,
                                          'query': query_result, 'work_dir': str(work), 'inputs_and_native_bounds': input_provenance(plan, native, subset)})
            print(json.dumps({'status': 'NATIVE_COVERAGE_VERIFIED_NOT_RENDERED', 'work_dir': str(work)})); return 0
        require(sha(subset) == validation['subset_sha256'], 'Subset changed after verification.')
        temporary_output = work/'render.wav'
        cmd = [sys.executable, str(HERE/'render_score_sfizz.py'), '--score', str(a.score), '--sfz', str(subset), '--out', str(temporary_output)]
        if a.enable_details: cmd.append('--enable-details')
        if a.max_seconds is not None: cmd.extend(['--max-seconds', str(a.max_seconds)])
        render_result = run_guarded(cmd, work/'render.log', a.ram_cap_mib, a.timeout_seconds, env)
        bind_inputs(plan, a.library); verify_bundle()
        require(sha(subset) == validation['subset_sha256'], 'Subset changed during rendering.')
        check_float32_output(temporary_output, plan['score_info']['frames'])
        report = json.loads(temporary_output.with_suffix('.render.json').read_text())
        require(report['frames'] == plan['score_info']['frames'] and report['details_enabled'] == a.enable_details, 'Original renderer report disagrees with plan.')
        output_hash = sha(temporary_output)
        a.out.parent.mkdir(parents=True, exist_ok=True)
        # Exclusive creation prevents accidental replacement of an existing source or another run's result.
        with temporary_output.open('rb') as source, a.out.open('xb') as target:
            shutil.copyfileobj(source, target, 1024*1024)
        require(sha(a.out) == output_hash, 'Final output copy hash mismatch.')
        json_write(a.out.with_suffix('.render.json'), report)
        result = {'status': 'RENDERED_FLOAT32_NATIVE_COVERAGE_VERIFIED', 'output': str(a.out), 'output_sha256': output_hash,
                  'work_dir': str(work), 'query': query_result, 'render': render_result,
                  'inputs_and_native_bounds': input_provenance(plan, native, subset),
                  'native_validation_sha256': sha(work/'native_validation.json'), 'plan_sha256': sha(work/'plan.json'),
                  'audio_equivalence_to_previous_render': 'NOT_TESTED; compare/listen separately. Final master still requires actual REAPER export.'}
        json_write(work/'result.json', result)
        print(json.dumps({k: v for k, v in result.items() if k != 'inputs_and_native_bounds'}, indent=2)); return 0
    except BaseException as exc:
        if not (work/'failure.json').exists():
            json_write(work/'failure.json', {'status': 'FAILED_CLOSED', 'error': str(exc), 'work_dir': str(work), 'output_must_not_be_treated_as_verified': True})
        raise

if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except StageInterrupted as exc:
        print(str(exc) + '; owned stage cleaned up.', file=sys.stderr); raise SystemExit(128 + exc.signum)
    except KeyboardInterrupt:
        print('Interrupted; owned stage cleaned up.', file=sys.stderr); raise SystemExit(130)
    except (ValueError, OSError, KeyError, TypeError) as exc:
        print('REFUSED: ' + str(exc), file=sys.stderr); raise SystemExit(2)
