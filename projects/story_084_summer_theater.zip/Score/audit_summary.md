# Verified source audit

Final work: 084 — Snow at the Summer Theater / 夏日剧场的雪.

- 144 complete 3/8 bars, 216 absolute quarter-note beats.
- v2 contains 892 note events; all are piano, with explicit left/right hand allocation.
- Tempo-integrated music duration: 198.067579 seconds (3:18.068).
- Tail: 6 seconds. Total: 204.067579 seconds (3:24.068).
- Maximum simultaneous held span: left hand 12 semitones, right hand 12 semitones.
- Zero overlapping same-pitch events, including collisions between the two hands.
- All wide transfers meet the audit's released-time allowance: 0.12 seconds above 12 semitones, 0.18 above 17, and 0.22 above 21. The repaired 23-semitone return into bar 97 has 1.037705 seconds available.
- Zero accompaniment pitches outside their current harmony, and zero melody downbeats outside their current harmony. Interior passing and neighboring tones remain permitted.
- All 18 eight-bar phrase entrances and final melody attacks are chord tones against their actual current support. Every phrase has an explicit onward or tonic arrival recorded in audit_v2.json.
- All 18 complete eight-bar melody sentences are distinct in v2. The recurring theme is varied in rhythm, register, mode, continuation, and handedness.
- Maximum interior interval with neither hand holding a key: 0.077143 seconds. Short articulation gaps preserve the dance motion.
- Pedal values are restricted to 0, 42, and 76. Final CC64=0 occurs explicitly at beat 216.
- v0 and v1 are also full-length, valid scores and pass the same checks. Each lasts 203.465974 seconds including the tail; their event counts are 857 and 884.

## Final scene times

1. Bars 1–24: 0:00.000–0:32.615.
2. Bars 25–48: 0:32.615–1:02.519.
3. Bars 49–72: 1:02.519–1:34.815.
4. Bars 73–96: 1:34.815–2:08.977.
5. Bars 97–120: 2:08.977–2:39.903.
6. Bars 121–144: 2:39.903–3:18.068, followed by the tail.

## Review boundaries

These are deterministic score and geometry checks. No audio rendering, listening session, instrument installation, sample acquisition, or publication occurred. The owner should render with the existing approved Moonlight piano for the final musical listening review. Phrase anchors and bounded hands are useful checks; they do not claim to establish artistic success by themselves.

The exact source hashes are in manifest.json. Running generate.py again produces the same score files and audit results.
