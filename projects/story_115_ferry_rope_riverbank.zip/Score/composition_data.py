"""115 original through-composed sarabande-like piano movement;12 eighths per3/2 bar."""
GROUPS=[
('morning','Fm Db Ab/C Bbm C7 Fm Eb Ab Bbm C7',[
'F4:3 C5:1 Db5:2 C5:2 Ab4:2 G4:2','F4:2 Ab4:2 Db5:3 C5:1 Bb4:4','Eb5:2 C5:2 Ab4:2 G4:2 Eb4:4','Db4:3 F4:1 Bb4:2 Ab4:2 F4:4','E4:2 G4:2 C5:3 Bb4:1 G4:4','Ab4:2 F4:2 C4:2 Db4:2 F4:4','G4:3 Bb4:1 Eb5:2 Db5:2 Bb4:4','C5:2 Ab4:2 Eb4:2 F4:2 G4:4','Ab4:2 F4:2 Db4:2 Eb4:2 F4:4','G4:2 E4:2 C4:2 R:6']),
('crossings','Fm C7 Fm Bb7 Eb Ab/C Db C7 Fm Bbm C7 Fm',[
'F4:3 C5:1 Db5:2 C5:2 Ab4:2 G4:2','E4:2 G4:2 C5:2 D5:2 E5:4','F5:3 Eb5:1 C5:2 Ab4:2 F4:4','D4:2 F4:2 Bb4:3 Ab4:1 F4:4','G4:2 Bb4:2 Eb5:3 Db5:1 Bb4:4','C5:2 Ab4:2 Eb4:2 F4:2 G4:4',
'Ab4:3 Db5:1 F5:2 Eb5:2 Db5:4','E5:2 C5:2 G4:3 Bb4:1 C5:4','Ab4:2 C5:2 F5:3 Eb5:1 C5:4','Db5:3 F5:1 Bb5:2 Ab5:2 F5:4','G5:2 E5:2 C5:2 Bb4:2 G4:4','F4:3 Ab4:1 C5:2 Ab4:2 R:4']),
('current','Ab Eb/G Fm C7 Db Bbm Eb7 Ab Cm F7 Bbm Db C7 Fm',[
'Eb5:1 Ab5:1 C6:2 Bb5:2 Ab5:2 G5:2 Eb5:2','G5:2 Bb5:1 Eb6:1 Db6:2 Bb5:2 G5:4','Ab5:1 F5:1 C5:2 Db5:2 Eb5:2 F5:4','E5:2 G5:1 C6:1 Bb5:2 G5:2 E5:4','F5:1 Ab5:1 Db6:2 C6:2 Bb5:2 Ab5:4','F5:2 Db5:1 Bb4:1 Ab4:2 Db5:2 F5:4','G5:1 Bb5:1 Eb6:2 Db6:2 Bb5:2 G5:4',
'Ab5:2 Eb5:2 C5:2 Db5:2 Eb5:4','G4:1 C5:1 Eb5:2 D5:2 C5:2 Bb4:4','A4:2 C5:1 F5:1 Eb5:2 C5:2 A4:4','Bb4:1 Db5:1 F5:2 Ab5:2 Bb5:2 F5:4','Ab5:2 F5:2 Db5:3 Eb5:1 F5:4','G5:1 E5:1 C5:2 Db5:2 E5:2 G5:4','F5:2 C5:2 Ab4:2 G4:2 R:4']),
('ridge','Fm Db Eb Ab/C Bbm C7 Fm Bb7 C7 Fm',[
'F5:1 C6:1 Db6:2 C6:2 Ab5:2 G5:2 F5:2','Ab5:2 Db6:1 F6:1 Eb6:2 Db6:2 C6:4','Bb5:1 G5:1 Eb5:2 F5:2 G5:2 Bb5:4','C6:2 Ab5:2 Eb5:2 F5:2 G5:4','Ab5:1 F5:1 Db5:2 Eb5:2 F5:2 Ab5:4',
'G5:1 C6:1 E6:2 D6:2 C6:2 Bb5:4','Ab5:2 F5:1 C5:1 Db5:2 Eb5:2 F5:4','D5:2 F5:1 Bb5:1 Ab5:2 F5:2 D5:4','E5:2 G5:1 C6:1 Bb5:2 G5:2 E5:4','F5:2 C5:2 Ab4:2 F4:2 R:4']),
('shore','Db Ab/C Bbm C7 Fm Bb C7 F6',[
'F4:3 Ab4:1 Db5:2 C5:2 Ab4:4','Eb5:2 C5:2 Ab4:2 G4:2 Eb4:4','Db4:2 F4:2 Bb4:3 Ab4:1 F4:4','E4:2 G4:2 C5:2 Bb4:2 R:4','Ab4:3 F4:1 C4:2 Db4:2 F4:4','D4:2 F4:2 Bb4:2 A4:2 F4:4','E4:2 G4:2 C5:2 Bb4:2 G4:4','F4:2 A4:2 C5:2 D5:2 C5:2 F4:2'])]
H={'Fm':[41,44,48],'Db':[37,41,44],'Ab/C':[36,44,51],'Bbm':[34,37,41],'C7':[36,40,43,46],'Eb':[39,43,46],'Ab':[44,48,51],'Bb7':[34,38,41,44],'Eb/G':[43,46,51],'Eb7':[39,43,46,49],'Cm':[36,39,43],'F7':[41,45,48,51],'Bb':[34,38,41],'F6':[41,45,48,50],'Fm/Ab':[44,48,53],'Dbmaj7':[37,41,44,48],'Bbm/Db':[37,41,46]}
REV1={23:'C6:2 Ab5:1 Eb5:1 C5:2 Db5:2 Eb5:4',24:'Bb5:2 G5:1 Eb5:1 F5:2 G5:2 Bb5:4',25:'Ab5:3 F5:1 C5:2 Db5:2 Eb5:4',26:'G5:2 E5:2 C5:3 Bb4:1 G4:4',27:'F5:2 Ab5:1 Db6:1 C6:2 Bb5:2 Ab5:4',28:'Db5:2 F5:2 Bb5:3 Ab5:1 F5:4',29:'G5:2 Bb5:1 Eb6:1 Db6:2 Bb5:2 G5:4',30:'C6:2 Ab5:2 Eb5:2 C5:2 R:4'}
HREV1={23:'Ab/C',25:'Fm/Ab',27:'Dbmaj7',28:'Bbm/Db',30:'Ab'}
REV2={39:'G5:2 Bb5:2 Eb6:3 Db6:1 Bb5:4',40:'Ab5:2 Eb5:2 C5:2 Db5:2 Eb5:4',41:'F5:1 Bb5:1 Db6:2 C6:2 Bb5:2 Ab5:4',42:'G5:2 E5:1 C5:1 Bb4:2 C5:2 E5:4',43:'F5:3 C5:1 Db5:2 C5:2 Ab4:2 G4:2',44:'F4:2 Bb4:1 D5:1 F5:2 Ab5:2 Bb5:4',45:'G5:2 E5:2 C5:2 Bb4:2 R:4',46:'F4:2 Ab4:2 C5:2 F5:2 R:4',51:'F4:3 C5:1 Db5:2 C5:2 Ab4:2 G4:2',52:'D4:2 F4:2 Bb4:3 A4:1 F4:4',53:'E4:2 G4:2 C5:2 Bb4:2 R:4',54:'F4:2 A4:2 C5:2 D5:2 C5:2 F3:2'}
HREV2={40:'Ab/C',41:'Bbm/Db',43:'Fm/Ab',46:'Fm',51:'Fm',54:'F6'}
