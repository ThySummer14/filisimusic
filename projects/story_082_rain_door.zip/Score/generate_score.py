#!/usr/bin/env python3
"""Original work 082. Standard-library-only symbolic score and revision audits.

No audio, MIDI rendering, instrument installation, or remote access occurs.
Run with Python 3 in any directory; outputs go next to this script.
"""
import copy
import hashlib
import json
import math
from collections import Counter
from pathlib import Path

OUT = Path(__file__).resolve().parent
PC = {'C':0, 'D':2, 'E':4, 'F':5, 'G':7, 'A':9, 'B':11}

def midi(s):
    return (int(s[-1])+1)*12 + PC[s[0]] + (s[1:-1].count('#')-s[1:-1].count('b'))

def line(s):
    return [(midi(p), float(d)) for p,d in (x.split(':') for x in s.split())]

# Each entry is a deliberately voiced bass and compact left-hand upper shell.
# The low bass releases before the hand travels to the shell.
H = {
 'Ebmaj9': ('Eb2','G3 Bb3 D4'),
 'Eb6/9': ('Eb2','G3 C4 F4'),
 'Eb(add9)': ('Eb2','G3 Bb3 F4'),
 'Eb/G': ('G2','Eb3 Bb3 D4'),
 'Eb6/9/G': ('G2','Eb3 Bb3 C4'),
 'Cm9': ('C3','Eb3 G3 Bb3'),
 'Cm/G': ('G2','Eb3 G3 C4'),
 'Fm9': ('F2','Ab3 C4 Eb4'),
 'Fm9/Ab': ('Ab2','C3 Eb3 G3'),
 'Fm9/Bb': ('Bb2','Ab3 C4 Eb4'),
 'Fm6': ('F2','Ab3 C4 D4'),
 'Bb13': ('Bb2','Ab3 C4 D4'),
 'Bb13sus': ('Bb2','Ab3 C4 Eb4'),
 'Bb7b9': ('Bb2','Ab3 B3 D4'),
 'Abmaj9': ('Ab2','G3 Bb3 C4'),
 'Abmaj7': ('Ab2','Eb3 G3 C4'),
 'Abmaj7/Eb': ('Eb3','G3 Ab3 C4'),
 'Abm6': ('Ab2','Eb3 F3 B3'),
 'F13': ('F2','A3 D4 Eb4'),
 'Bbmaj9/D': ('D3','F3 A3 C4'),
 'G7b9': ('G2','F3 Ab3 B3'),
 'D7b13': ('D3','F#3 Bb3 C4'),
 'Dbmaj9': ('Db3','F3 Ab3 C4'),
 'C9': ('C3','E3 Bb3 D4'),
 'B7': ('B2','D#3 A3 C#4'),
 'A7b9': ('A2','G3 Bb3 C#4'),
 'C13/E': ('E3','Bb3 D4 A4'),
 'Bdim7': ('B2','D3 F3 Ab3'),
 'Gbmaj9': ('Gb2','Bb3 Db4 F4'),
 'Ebdim7': ('Eb3','Gb3 A3 C4'),
 'Ebdim7/Gb': ('Gb2','A3 C4 Eb4'),
 'Edim7': ('E3','G3 Bb3 Db4'),
 'C7b9': ('C3','E3 Bb3 Db4'),
 'Bbm9/Eb': ('Eb3','Ab3 Bb3 Db4'),
}

# Avoid a tall tenth in the one inversion above; the ninth remains in the melody.
H['C13/E'] = ('E3','A3 Bb3 D4')

BASE_HARMONY = [
 'Ebmaj9','Abmaj9','Fm9/Bb','Bb13',
 'Ebmaj9','Cm9','Fm9','Bb13','Eb/G','Abmaj9','Fm9/Bb','Eb6/9',
 'Cm9','F13','Bbmaj9/D','G7b9','Cm9','Abmaj7','Bb7b9','Ebmaj9',
 'Ebmaj9','D7b13','Dbmaj9','C9','B7','Bb13','A7b9','Abmaj9',
 'Cm9','Abmaj7/Eb','C13/E','Fm9','G7b9','Cm/G','Fm6','Bb13sus',
 'Ebmaj9','Cm9','Fm9','Bb13','Eb/G','Abmaj9','Fm9/Bb','Eb6/9',
 'Cm9','F13','Bbmaj9/D','G7b9','Cm9','Abmaj7','Bb7b9','Ebmaj9',
 'Abmaj9','Abm6','Eb/G','C7b9','Fm9','Bb13','Ebmaj9','Ebmaj9',
]

MELODY = [
 'G4:1 Bb4:1 C5:1 Bb4:1',
 'G4:1 F4:1 Eb4:2',
 'F4:1 G4:0.5 Ab4:0.5 G4:1 F4:1',
 'D4:1 F4:1 Ab4:0.5 A4:0.5 Bb4:1',
 'G4:1 Bb4:1 C5:1 Bb4:1',
 'Ab4:1 G4:1 F4:1 Eb4:1',
 'F4:1 Ab4:1 Bb4:1 Ab4:1',
 'G4:1 Ab4:1 Bb4:1 D5:1',
 'Eb5:1 D5:0.5 C5:0.5 Bb4:1 G4:1',
 'Ab4:1 G4:1 F4:0.5 E4:0.5 F4:1',
 'Eb4:1 F4:1 G4:0.5 Ab4:0.5 F4:1',
 'Eb4:2 G4:1 F4:0.5 Eb4:0.5',
 'G4:1 Bb4:0.5 C5:0.5 D5:1 Bb4:1',
 'C5:1 Bb4:0.5 Ab4:0.5 G4:1 F4:1',
 'E4:0.5 F4:0.5 A4:1 C5:1 Bb4:1',
 'Ab4:1 G4:0.5 F4:0.5 Gb4:0.5 G4:0.5 Bb4:1',
 'C5:1 Eb5:0.5 D5:0.5 C5:1 G4:1',
 'Ab4:1 C5:0.5 D5:0.5 Eb5:1 C5:1',
 'B4:1 Bb4:0.5 Ab4:0.5 G4:1 F4:1',
 'Eb4:1 G4:0.5 Bb4:0.5 C5:1 Bb4:1',
 'G4:0.5 A4:0.5 Bb4:1 D5:1 C5:1',
 'F#4:0.5 G4:0.5 A4:1 C5:1 Bb4:1',
 'F4:0.5 Ab4:0.5 C5:1 B4:0.5 Bb4:0.5 Ab4:1',
 'E4:0.5 G4:0.5 Bb4:1 D5:1 C5:1',
 'F#4:1 A4:0.5 Ab4:0.5 F#4:1 D#4:1',
 'F4:1 Ab4:0.5 G4:0.5 F4:1 D4:1',
 'Eb4:0.5 E4:0.5 G4:1 Bb4:1 A4:1',
 'Ab4:1 C5:1 Eb5:0.5 D5:0.5 C5:1',
 'G4:1 F4:1 Eb4:1 D4:1',
 'Eb4:1 G4:1 Ab4:1 G4:1',
 'E4:1 F4:1 G4:1 E4:1',
 'F4:1 Ab4:1 C5:1 Bb4:1',
 'B4:1 Ab4:1 G4:1 F4:1',
 'Eb4:1 G4:1 C5:1 G4:1',
 'Ab4:1 G4:1 F4:1 D4:1',
 'Eb4:1 F4:1 Ab4:1 Bb4:1',
]  # Return is composed from the first two statements before revisions.
MELODY += MELODY[4:20]
MELODY += [
 'C5:1 Bb4:0.5 Ab4:0.5 G4:1 Eb4:1',
 'F4:1 Ab4:0.5 B4:0.5 Bb4:1 Ab4:1',
 'G4:1 Bb4:0.5 C5:0.5 Bb4:1 G4:1',
 'E4:0.5 F4:0.5 G4:1 Bb4:1 Db5:1',
 'C5:1 Ab4:0.5 G4:0.5 F4:1 Ab4:1',
 'G4:0.5 Ab4:0.5 A4:0.5 Bb4:0.5 C5:1 D5:1',
 'Eb5:1 D5:1 Bb4:1 G4:1',
 'Eb4:4',
]

HOOK = {
 5:'G4:1 Bb4:0.5 C5:0.5 Bb4:1 G4:1',
 6:'F4:1 G4:0.5 Ab4:0.5 G4:1 Eb4:1',
 7:'F4:0.5 G4:0.5 Bb4:1 Ab4:1 F4:1',
 8:'F4:0.5 G4:0.5 Ab4:0.5 A4:0.5 Bb4:1 D5:1',
}
MONO = {
 29:'G4:0.75 F4:0.5 Eb4:0.75 D4:1',
 30:'Eb4:1 F4:0.5 G4:0.5 Ab4:1 G4:0.5 F4:0.5 Eb4:1',
 31:'E4:0.5 F4:0.5 A4:1 G4:0.5 F4:0.5 E4:1',
 32:'F4:1 G4:0.5 Ab4:0.5 C5:1 Bb4:1',
 33:'A4:0.75 Bb4:0.25 B4:0.5 C5:0.5 D5:1',
 34:'Eb5:1 D5:0.5 C5:0.5 B4:1 C5:1 G4:1',
 35:'Ab4:1 G4:0.5 F4:0.5 E4:0.5 F4:0.5 D4:1',
 36:'Eb4:1 F4:0.5 G4:0.5 Ab4:0.5 A4:0.5 Bb4:1',
}
RETURN_HARMONY = [
 'Cm9','Fm9/Ab','Dbmaj9','Gbmaj9',
 'Eb/G','Abm6','Fm9','Bb13',
 'Abmaj9','Abm6','Eb/G','Edim7',
 'Fm9','Bb13sus','Eb6/9/G','Bbm9/Eb',
]
RETURN_MELODY = {
 40:'Eb4:0.5 F4:0.5 Gb4:0.5 Ab4:0.5 Bb4:1 Db5:1',
 41:'Eb5:1 D5:0.5 C5:0.5 Bb4:1 G4:1',
 42:'Ab4:1 B4:0.5 Bb4:0.5 Ab4:1 F4:1',
 43:'Eb4:0.5 F4:0.5 Ab4:1 C5:1 Bb4:1',
 44:'Ab4:1 G4:0.5 F4:0.5 D4:1 F4:1',
 45:'G4:1 Bb4:0.5 C5:0.5 Eb5:1 C5:1',
 46:'B4:1 Bb4:0.5 Ab4:0.5 F4:1 Eb4:1',
 47:'G4:0.5 Bb4:0.5 D5:1 C5:1 Bb4:1',
 48:'Bb4:0.75 A4:0.25 G4:1 E4:1 Db4:1',
 49:'C4:0.5 Eb4:0.5 F4:1 Ab4:1 C5:1',
 50:'Bb4:1 Ab4:0.5 G4:0.5 F4:1 D4:1',
 51:'Eb4:1 G4:0.5 Bb4:0.5 C5:1 Bb4:1',
 52:'Ab4:1 F4:0.5 Ab4:0.5 Bb4:1 Db5:1',
}

PHRASES = [
 (1,4,'rain tests the outline'), (5,8,'handle motif, question'),
 (9,12,'first complete answer'), (13,16,'touch the old clamps'),
 (17,20,'the frame becomes a burden'), (21,24,'four objects on the workbench'),
 (25,28,'water reaches the bookbinder'), (29,32,'private argument'),
 (33,36,'the sentence becomes a decision'), (37,40,'carry the frame downstairs'),
 (41,44,'unfasten the painted cloth'), (45,48,'stretch the reverse face over pages'),
 (49,52,'give the rain a new route'), (53,56,'a real threshold'),
 (57,60,'paint the address and leave the door open'),
]

def section(n):
    if n<=4: return '雨先试了试门把 / Introduction'
    if n<=12: return '门里的未完成句 / First statement'
    if n<=20: return '旧画框的重量 / Second statement'
    if n<=28: return '楼下传来翻页声 / Chromatic bridge'
    if n<=36: return '她在画布前说话 / Free monologue'
    if n<=52: return '把画框抬到雨里 / Reharmonized return'
    return '真正的门牌 / Coda'

def tempo(n,version):
    if n<=4: return [68,70,71,70][n-1]
    if n<=12: return 72 if n not in (8,12) else 70
    if n<=20: return 73 if n!=20 else 70
    if n<=28: return 76 if n not in (24,28) else 73
    if n<=36:
        return ([66,71,68,72,65,70,68,71][n-29] if version else 70)
    if n<=44: return 74 if n!=44 else 71
    if n<=52: return 75 if n not in (48,52) else 72
    return [72,72,71,72,70,68,64,58][n-53]

def make_score(version):
    melody = list(MELODY)
    harmony = list(BASE_HARMONY)
    meters = [4]*60
    if version>=1:
        for n,v in HOOK.items():
            melody[n-1]=v
            melody[n+31]=v
        for n,v in MONO.items(): melody[n-1]=v
        meters[28:36]=[3,5,4,4,3,5,4,4]
        harmony[32]='Bdim7'
    if version>=2:
        harmony[36:52]=RETURN_HARMONY
        for n,v in RETURN_MELODY.items(): melody[n-1]=v
        melody[32]='Ab4:0.75 Bb4:0.25 B4:0.5 C5:0.5 D5:1'
        melody[58]='Eb5:1 Bb4:1 G4:1 F4:1'
        harmony[58:60]=['Eb6/9','Eb(add9)']
    score={
        'id':82,'title':'A Door Painted on the Rain','title_zh':'画在雨上的门',
        'version':f'v{version}','bars':[],'events':[],'pedals':[],
        'total_beats':float(sum(meters)),'tail_seconds':5,
        'instrument_policy':'Solo acoustic piano; existing approved Moonlight. Symbolic only.',
        'composition_credit':'New original composition and Chinese story, work082, 2026-10-07.',
        'pedal_values':{'0':'released','42':'partial','76':'full'},
    }
    def add(n,start,off,dur,pitch,vel,voice,hand):
        score['events'].append({'bar':n,'onset':round(start+off,5),
          'duration':round(dur,5),'pitch':pitch,'velocity':vel,
          'voice':voice,'instrument':'piano','hand':hand})
    start=0.0
    for n in range(1,61):
        beats=meters[n-1]
        hn=harmony[n-1]
        root,upper=H[hn]
        bass=midi(root); shell=[midi(p) for p in upper.split()]
        # For compact left-hand voicings keep highest shell note <=F4.
        assert max(shell)-min(shell)<=12
        assert max(shell)<=65
        score['bars'].append({'bar':n,'start':start,'beats':float(beats),
          'bpm':tempo(n,version),'section':section(n),
          'meter_numerator':beats,'meter_denominator':4,
          'harmony_name':hn,'harmony':[bass]+shell,'lead_instrument':'piano',
          'role_plan':('Right-hand sung line; left-hand bass releases before a compact shell. '
                       'Monologue follows speech; no long unmeasured gaps.')})
        notes=line(melody[n-1]); assert abs(sum(d for p,d in notes)-beats)<1e-9,(n,notes)
        energy=(58 if n<=4 else 69 if n<=20 else 73 if n<=28 else 65 if n<=36 else 76 if n<=52 else 65)
        off=0.0
        for j,(p,d) in enumerate(notes):
            # A breath is a short release within the last written value, never an empty bar.
            gap=(.13 if n in [b for a,b,t in PHRASES] and j==len(notes)-1 else .025)
            if n==60: gap=.12
            vel=energy + (2 if j==0 else 0) + (2 if d>=1 and p>=72 else 0) - (3 if j==len(notes)-1 else 0)
            if n>=57: vel-= (n-57)*3
            add(n,start,off,max(.15,d-gap),p,vel,'melody','right')
            off+=d
        # A few left-hand roots are brought up an octave to avoid unnecessary bass travel.
        if n in (29,30,31,32,33,34,35,36):
            if bass<46: bass+=12
        accomp=energy-20
        if n==60:
            # Final complete Eb sonority, sequentially grasped; the last revision changes its color.
            add(n,start,0,0.82,midi('Eb2'),accomp,'bass','left')
            for p in shell:
                add(n,start,1,2.82,p,accomp-2,'accompaniment','left')
        elif 29<=n<=36 and version>=1:
            # Prose-like uneven arrival points; all gestures remain physically connected.
            times={3:[0,1.0,2.1],5:[0,1.25,2.75,4.0],4:[0,1.25,2.6]}[beats]
            add(n,start,0,.72,bass,accomp-2,'bass','left')
            for k,t in enumerate(times[1:]):
                end=times[k+2] if k+2<len(times) else beats
                pitches=shell[:2] if k%2==0 or n==35 else shell[1:]
                for p in pitches:
                    add(n,start,t,max(.2,end-t-.11),p,accomp-3,'accompaniment','left')
        elif n<=4 or n>=53:
            add(n,start,0,.82,bass,accomp,'bass','left')
            for p in shell[:2]: add(n,start,1,.92,p,accomp-3,'accompaniment','left')
            second=shell[:2] if n==59 and version>=2 else shell[1:]
            for p in second: add(n,start,2,1.84,p,accomp-4,'accompaniment','left')
        elif 21<=n<=28:
            add(n,start,0,.73,bass,accomp,'bass','left')
            for p in shell[:2]: add(n,start,.875,.95,p,accomp-2,'accompaniment','left')
            add(n,start,2,.71,shell[-1],accomp-5,'accompaniment','left')
            for p in shell[:2]: add(n,start,2.875,.96,p,accomp-3,'accompaniment','left')
        else:
            add(n,start,0,.82,bass,accomp,'bass','left')
            for p in shell[:2]: add(n,start,1,.92,p,accomp-3,'accompaniment','left')
            # In the return, fuller shells enter at the line's strongest arrival.
            second=shell if version>=2 and 37<=n<=52 else shell[1:]
            for p in second: add(n,start,2,.91,p,accomp-4,'accompaniment','left')
            for p in shell[:2]: add(n,start,3,.86,p,accomp-5,'accompaniment','left')
        score['pedals'] += [
          {'onset':round(start,5),'value':0},
          {'onset':round(start+.055,5),'value':42 if 29<=n<=36 else 76},
          {'onset':round(start+beats*.51,5),'value':42},
          {'onset':round(start+beats-.045,5),'value':0},
        ]
        start+=beats
    # Finger release is distinct from sounding length under the pedal. Give a pianist
    # real travel time before a wide bass/shell move, including at bar boundaries.
    left_groups={}
    for e in score['events']:
        if e['hand']=='left': left_groups.setdefault(e['onset'],[]).append(e)
    ordered=sorted(left_groups.items())
    for (ta,aa),(tb,bb) in zip(ordered,ordered[1:]):
        move=abs(sum(e['pitch'] for e in aa)/len(aa)-sum(e['pitch'] for e in bb)/len(bb))
        if move>12:
            release_at=tb-(.44 if move>19 else .34)
            for e in aa:
                if e['onset']+e['duration']>release_at:
                    e['duration']=round(max(.15,release_at-e['onset']),5)
    # Duplicate same-time/same-key strikes across the hands are reassigned to the melody hand.
    # Any sustained overlap is caught below instead of being silently repaired.
    score['events'].sort(key=lambda x:(x['onset'],x['pitch'],x['voice']))
    melody_keys={(e['onset'],e['pitch']) for e in score['events'] if e['voice']=='melody'}
    score['events']=[e for e in score['events'] if e['voice']=='melody' or (e['onset'],e['pitch']) not in melody_keys]
    score['pedals'].append({'onset':start,'value':0})
    return score

def seconds_between(score,a,b):
    return sum(max(0,min(b,x['start']+x['beats'])-max(a,x['start']))*60/x['bpm'] for x in score['bars'])

def audit(score):
    ev=score['events']; bars=score['bars']
    failures=[]
    span_report={}
    for hand in ('left','right'):
        events=[e for e in ev if e['hand']==hand]
        maxspan=0; maxpoly=0; at=0
        for t in sorted({e['onset'] for e in events}):
            held=[e['pitch'] for e in events if e['onset']<=t+1e-7 and e['onset']+e['duration']>t+1e-7]
            span=max(held)-min(held) if held else 0
            if span>maxspan: maxspan=span; at=t
            maxpoly=max(maxpoly,len(held))
            if span>12: failures.append({'type':'held_hand_span','hand':hand,'onset':t,'span':span})
        span_report[hand]={'max_held_span_semitones':maxspan,'at_beat':at,'max_simultaneous_keys':maxpoly,
          'method':'All notes actually still held at each note onset, including cross-bar and cross-voice notes; pedal resonance is not finger span.'}
    overlaps=[]
    for p in sorted({e['pitch'] for e in ev}):
        key=sorted([e for e in ev if e['pitch']==p],key=lambda x:x['onset'])
        for i,nxt in enumerate(key):
            for prev in key[:i]:
                if prev['onset']+prev['duration']>nxt['onset']+1e-7:
                    overlaps.append({'pitch':p,'previous_bar':prev['bar'],'next_bar':nxt['bar'],
                      'previous_end':prev['onset']+prev['duration'],'next_onset':nxt['onset']})
    failures += [{'type':'same_key_overlap',**x} for x in overlaps]
    # Leaps are judged from the previous released grip to the next grip, not merely bass extremes.
    transfers=[]; risky=[]
    for hand in ('left','right'):
        groups={}
        for e in ev:
            if e['hand']==hand: groups.setdefault(e['onset'],[]).append(e)
        gs=sorted(groups.items())
        for (ta,aa),(tb,bb) in zip(gs,gs[1:]):
            pa=[e['pitch'] for e in aa]; pb=[e['pitch'] for e in bb]
            move=abs(sum(pb)/len(pb)-sum(pa)/len(pa))
            free=max(0,tb-max(e['onset']+e['duration'] for e in aa))
            secs=seconds_between(score,ta,tb)
            item={'hand':hand,'from_bar':aa[0]['bar'],'to_bar':bb[0]['bar'],
              'from_beat':ta,'to_beat':tb,'grip_center_move':round(move,2),
              'seconds_between_attacks':round(secs,3),'released_travel_seconds':round(seconds_between(score,tb-free,tb),3)}
            if move>12: transfers.append(item)
            free_secs=seconds_between(score,tb-free,tb)
            if (move>12 and free_secs<.22) or (move>19 and free_secs<.30): risky.append(item)
    failures += [{'type':'fast_large_hand_transfer',**x} for x in risky]
    melodic=[e for e in ev if e['voice']=='melody']
    intervals=[abs(b['pitch']-a['pitch']) for a,b in zip(melodic,melodic[1:])]
    gaps=[seconds_between(score,a['onset']+a['duration'],b['onset']) for a,b in zip(melodic,melodic[1:])]
    phrase_checks=[]
    for a,b,label in PHRASES:
        p=[e for e in melodic if a<=e['bar']<=b]
        st=bars[a-1]['start']; end=bars[b-1]['start']+bars[b-1]['beats']
        phrase_checks.append({'bars':[a,b],'story_action':label,'notes':len(p),
          'pitch_range':[min(e['pitch'] for e in p),max(e['pitch'] for e in p)],
          'duration_seconds':round(seconds_between(score,st,end),2),
          'largest_melodic_leap_semitones':max([abs(y['pitch']-x['pitch']) for x,y in zip(p,p[1:])] or [0]),
          'last_note_midi':p[-1]['pitch'],'last_harmony':bars[b-1]['harmony_name']})
    cadence_checks=[]
    for n,intent in [(12,'first stable tonic answer'),(20,'tonic with an upward-facing open ending'),
                     (28,'subdominant pause before speech'),(36,'dominant prepares action'),
                     (44,'dominant half cadence keeps the work moving'),(52,'dominant of IV turns toward the real street'),
                     (60,'tonic arrival with a quiet added-nine color')]:
        if score['version']!='v2' and n in (44,52): intent='literal-return tonic answer, later revised'
        if score['version']!='v2' and n==60: intent='tonic arrival with major-seventh color, later revised'
        bar=bars[n-1]; line_notes=[e for e in melodic if e['bar']==n]
        chordpc={p%12 for p in bar['harmony']}; last=line_notes[-1]
        # The cadence melody may supply a deliberately omitted root/extension.
        cadence_checks.append({'bar':n,'harmony':bar['harmony_name'],'melodic_arrival_midi':last['pitch'],
          'arrival_in_voiced_harmony':last['pitch']%12 in chordpc,'intent':intent,
          'unvoiced_chord_tone_note':('F is the consonant fifth of Bb, omitted from the left-hand shell.' if n==44 and score['version']=='v2' else None)})
    if score['pedals'][-1]!={'onset':score['total_beats'],'value':0}: failures.append({'type':'final_pedal_not_released'})
    for e in ev:
        if not 0<=e['onset']<score['total_beats'] or e['onset']+e['duration']>score['total_beats']+1e-6:
            failures.append({'type':'event_outside_score','event':e})
    return {'version':score['version'],'pass':not failures,'failures':failures,
      'bars':len(bars),'events':len(ev),'total_quarter_beats':score['total_beats'],
      'duration_seconds_including_tail':round(seconds_between(score,0,score['total_beats'])+score['tail_seconds'],3),
      'held_hand_span':span_report,'same_key_overlap_count':len(overlaps),
      'large_hand_transfers':transfers,'risky_large_hand_transfers':risky,
      'melody':{'note_count':len(melodic),'max_leap_semitones':max(intervals),
          'fraction_intervals_at_most_five_semitones':round(sum(i<=5 for i in intervals)/len(intervals),4),
          'max_gap_seconds_between_melody_notes':round(max(gaps),4),
          'median_note_duration_beats':sorted(e['duration'] for e in melodic)[len(melodic)//2]},
      'phrase_audit':phrase_checks,'cadence_audit':cadence_checks,
      'limitations':['Symbolic mechanical and score-reading checks only; no audio was generated or auditioned.',
                    'Pedal resonance may exceed hand span; it is not treated as continuously depressed keys.',
                    'Cadence labels describe composed intentions and are not an automatic claim of auditory success.']}

def canonical(e):
    return json.dumps(e,sort_keys=True,separators=(',',':'),ensure_ascii=False)

def compare(a,b):
    aa=Counter(canonical(e) for e in a['events']); bb=Counter(canonical(e) for e in b['events'])
    removed=[json.loads(s) for s,n in (aa-bb).items() for _ in range(n)]
    added=[json.loads(s) for s,n in (bb-aa).items() for _ in range(n)]
    changes=[]
    for x,y in zip(a['bars'],b['bars']):
        changed={k:{'before':x.get(k),'after':y.get(k)} for k in sorted(set(x)|set(y)) if x.get(k)!=y.get(k)}
        if changed: changes.append({'bar':x['bar'],'changes':changed})
    ma={n:[e for e in a['events'] if e['bar']==n and e['voice']=='melody'] for n in range(1,61)}
    mb={n:[e for e in b['events'] if e['bar']==n and e['voice']=='melody'] for n in range(1,61)}
    return {'from':a['version'],'to':b['version'],'removed_event_count':len(removed),
      'added_event_count':len(added),'bars_with_changed_melody':[n for n in ma if ma[n]!=mb[n]],
      'bar_changes':changes,'removed_events':removed,'added_events':added,
      'pedals_before':a['pedals'],'pedals_after':b['pedals']}

def write_json(name,value):
    data=(json.dumps(value,ensure_ascii=False,indent=2)+'\n').encode('utf-8')
    (OUT/name).write_bytes(data)
    return hashlib.sha256(data).hexdigest()

def main():
    assert len(MELODY)==len(BASE_HARMONY)==60
    scores=[make_score(i) for i in range(3)]
    hashes={}
    for i,s in enumerate(scores):
        hashes[f'score_v{i}.json']=write_json(f'score_v{i}.json',s)
        report=audit(s)
        write_json(f'audit_v{i}.json',report)
        if not report['pass']:
            print(json.dumps(report['failures'],indent=2)); raise SystemExit('Audit failed')
    hashes['score.json']=write_json('score.json',scores[-1])
    for i in (0,1): write_json(f'exact_diff_v{i}_to_v{i+1}.json',compare(scores[i],scores[i+1]))
    hashes['generate_score.py']=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    write_json('SHA256.json',hashes)
    print(json.dumps({'hashes':hashes,'audit':[{k:audit(s)[k] for k in ('version','pass','events','duration_seconds_including_tail','melody')} for s in scores]},indent=2))

if __name__=='__main__': main()
