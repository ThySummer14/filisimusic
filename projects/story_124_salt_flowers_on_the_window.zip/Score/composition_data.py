"""Original, fully authored piano/cello nominal duet; no external music data."""
ID=124
TITLE='Salt Flowers on the Window'
TITLE_ZH='窗上的盐花'
INSTRUMENT='cello'
BEATS=4
METER=(4,4)
TAIL=4.5
HARMONIES={'F#m':(42,[6,9,1]),'D':(38,[2,6,9]),'Bm':(47,[11,2,6]),
 'C#7':(37,[1,5,8,11]),'A':(45,[9,1,4]),'Amaj7':(45,[9,1,4,8]),
 'E':(40,[4,8,11]),'E7':(40,[4,8,11,2]),'C#m':(49,[1,4,8]),
 'D#dim':(39,[3,6,9]),'B7':(47,[11,3,6,9]),'G#7':(44,[8,0,3,6]),
 'Dmaj7':(38,[2,6,9,1]),'F#7':(42,[6,10,1,4]),'G':(43,[7,11,2])}
# harmony | explicit RH pitches | explicit LH pitches | cello melody | rhythm
# Six non-square chapters: 13 + 11 + 15 + 12 + 14 + 11 = 76 bars.
PARAGRAPHS=[
('A_a_chart_drawn_in_salt',84,'''\
F#m|C#5 A4 G#4 F#4 G#4 A4|F#2 C#3 A2 E3|A3 E3|b
D|A4 F#4 E4 D4 E4 F#4|F#2 A2 D3 C#3|F#3 A3|d
Bm|F#4 A4 G#4 F#4 E4 D4|B2 D3 F#3 E3|D3 B3|b
C#7|G#4 B4 A4 G#4 F4 D#4|F2 G#2 C#3 B2|G#3 F3|d
F#m|F#4 G#4 A4 C#5 A4 G#4 F#4 E4|A2 B2 C#3 E3|F#3 A3|a
A|E4 F#4 G#4 A4 C#5 B4|C#3 B2 A2 E3|E3 A3|b
E|G#4 B4 E5 B4 A4 G#4|G#2 F#2 E2 B2|B3 G#3|d
C#m|E5 D#5 C#5 G#4 B4 C#5|E3 D#3 C#3 G#2|-|b
Dmaj7|F#4 A4 C#5 D5 C#5 A4 F#4 E4|D3 C#3 A2 F#2|A3 F#3|a
Bm|D4 F#4 B4 F#4 A4 G#4|D3 E3 F#3 A2|B3 D3|b
E7|G#4 A4 B4 D5 B4 A4 G#4 F#4|E3 D3 B2 G#2|G#3 B3|c
A|E4 C#5 B4 A4 G#4 F#4|A2 C#3 E3 D3|E3|d
C#7|F4 G#4 B4 G#4 F4 C#4|C#3 B2 G#2 F2|-|b
'''),
('B_sunlight_reveals_a_false_coast',90,'''\
Amaj7|C#5 E5 G#5 E5 D#5 C#5|C#3 E3 A2 B2|E3 G#3|d
B7|D#5 F#5 A5 F#5 E5 D#5|B2 A2 F#2 D#3|D#3 F#3 A3|b
E|B4 G#4 F#4 E4 F#4 G#4 B4 E5|G#2 B2 E3 D#3|G#3 B3|a
Amaj7|G#5 F#5 E5 C#5 B4 A4|A2 B2 C#3 E3|E3 A3|d
D#dim|F#4 A4 C5 D#5 F#5 E5|D#3 C#3 A2 F#2|A3 F#3 D#3|b
E|E5 D#5 C#5 B4 A4 G#4|E3 D#3 B2 G#2|-|d
C#m|G#4 B4 C#5 E5 D#5 C#5 B4 G#4|C#3 D#3 E3 G#2|E3 G#3|c
F#7|A#4 C#5 E5 C#5 B4 A#4|A#2 C#3 E3 D3|E3 A#3|b
Bm|F#5 E5 D5 B4 C#5 D5|B2 A2 F#2 D3|D3 F#3 B3|d
E7|G#4 B4 D5 E5 B4 A4 G#4 F#4|G#2 A2 B2 D3|G#3 E3|a
A|C#5 B4 A4 E5 D#5 E5|A2 B2 C#3 E3|E3 A3|b
'''),
('C_the_missing_pier',80,'''\
F#m|C#5 A4 G#4 F#4 E4 C#4|A2 G#2 F#2 C#3|A3 F#3|d
D|F#4 E4 D4 A4 G4 F#4|D3 C#3 A2 F#2|F#3 D3|b
G|B4 A4 G4 D5 C5 B4|B2 A2 G2 D3|G3 B3|d
Bm|D5 C#5 B4 F#4 A4 B4|B2 D3 F#3 E3|-|b
E7|G#4 B4 D5 E5 D5 B4 G#4 F#4|E3 D3 B2 G#2|D3 G#3|a
A|A4 G#4 F#4 E4 D4 C#4|C#3 B2 A2 E3|E3 A3|d
Dmaj7|F#4 A4 C#5 D5 E5 F#5|D3 C#3 A2 F#2|F#3 A3|b
C#m|G#5 F#5 E5 C#5 B4 G#4|E3 D#3 C#3 G#2|E3|d
F#m|A4 C#5 E5 F#5 C#5 A4 G#4 F#4|F#2 G#2 A2 C#3|-|a
Bm|D5 F#5 A5 F#5 E5 D5|D3 C#3 B2 F#2|F#3 B3|b
D#dim|A4 F#4 E4 D#4 F#4 A4|F#2 A2 D#3 C#3|A3 F#3|d
G#7|C5 D#5 F#5 G#5 D#5 C5 B4 G#4|G#2 F#2 D#3 C3|F#3 D#3|c
C#m|E5 D#5 C#5 G#4 B4 C#5|E3 D#3 C#3 G#2|G#3 E3|b
C#7|F5 E5 D#5 C#5 B4 G#4|F3 D#3 C#3 G#2|-|d
F#m|A4 G#4 F#4 C#5 A4 G#4|F#2 C#3 A2 E3|A3 F#3|b
'''),
('D_the_tide_enters_the_house',94,'''\
F#m|F#4 A4 C#5 E5 C#5 B4 A4 G#4|A2 C#3 F#3 E3|A3 F#3|c
Bm|B4 D5 F#5 A5 F#5 E5 D5 C#5|B2 D3 F#3 E3|D3 F#3 B3|a
E7|D5 C#5 B4 A4 G#4 F#4 E4 D4|D3 B2 G#2 E3|G#3 B3|c
A|C#5 E5 A5 G#5 E5 D#5 C#5 B4|C#3 B2 A2 E3|E3 A3|a
Dmaj7|A4 C#5 D5 E5 F#5 E5 D5 C#5|F#2 A2 D3 C#3|A3 F#3 D3|c
D#dim|F#5 E5 D#5 C5 A4 G#4 F#4 E4|A2 F#2 D#3 C#3|F#3 A3|a
G#7|D#5 F#5 G#5 B4 C5 D#5 F#5 G#5|C3 D#3 G#2 F#2|D#3 F#3 G#3|c
C#m|G#5 F#5 E5 D#5 C#5 B4 G#4 E4|C#3 E3 G#2 B2|E3 G#3|a
F#7|A#4 C#5 E5 F#5 C#5 B4 A#4 G#4|A#2 C#3 E3 D#3|E3 A#3|c
Bm|F#5 A5 F#5 E5 D5 C#5 B4 A4|D3 C#3 B2 F#2|D3 F#3 B3|a
C#7|B4 C#5 D#5 F5 G#5 F#5 F5 D#5|B2 G#2 F3 D#3|F3 G#3|c
F#m|C#5 E5 F#5 G#5 A5 G#5 F#5 E5|F#2 G#2 A2 C#3|A3 F#3|a
'''),
('E_the_lines_become_doors',86,'''\
Dmaj7|F#5 E5 D5 A4 C#5 D5|D3 C#3 A2 F#2|A3 F#3|b
A|E5 C#5 B4 A4 B4 C#5|C#3 E3 A2 B2|E3 A3|d
B7|F#4 A4 B4 D#5 F#5 E5|D#3 C#3 B2 F#2|D#3 F#3 B3|b
E|G#5 F#5 E5 B4 A4 G#4|G#2 B2 E3 D#3|G#3 E3|d
C#m|E4 G#4 B4 C#5 E5 D#5 C#5 B4|E3 D#3 C#3 G#2|-|a
F#m|C#5 A4 G#4 F#4 A4 C#5|A2 G#2 F#2 C#3|A3 F#3|b
D|F#5 E5 D5 A4 G4 F#4|F#2 A2 D3 C#3|F#3 A3|d
Bm|D5 F#5 B5 A5 F#5 E5 D5 C#5|D3 C#3 B2 F#2|B3 F#3|c
E7|G#4 B4 D5 B4 A4 G#4|E3 D3 B2 G#2|D3 G#3|b
Amaj7|C#5 E5 G#5 E5 D#5 E5|C#3 B2 A2 E3|E3 A3|d
D#dim|F#5 E5 D#5 A4 G#4 F#4|D#3 C#3 A2 F#2|A3 F#3|b
E|B4 G#4 F#4 E4 G#4 B4|G#2 A2 B2 D#3|-|d
A|C#5 B4 A4 E5 C#5 B4|A2 C#3 E3 D3|E3 A3|b
C#7|F5 D#5 C#5 G#4 B4 C#5|F3 D#3 C#3 G#2|G#3 F3|d
'''),
('F_the_window_is_left_clear',78,'''\
F#m|A4 C#5 E5 F#5 C#5 A4 G#4 F#4|A2 G#2 F#2 C#3|A3 F#3|a
D|F#4 A4 D5 A4 G4 F#4|D3 C#3 A2 F#2|F#3 D3|b
Bm|D4 F#4 A4 B4 A4 F#4|B2 D3 F#3 E3|F#3 B3|d
E7|G#4 B4 D5 B4 A4 G#4|G#2 F#2 E2 B2|-|b
Amaj7|E5 C#5 B4 A4 G#4 F#4|A2 B2 C#3 E3|E3 G#3|d
D#dim|F#4 A4 C5 D#5 C5 A4|D#3 C#3 A2 F#2|F#3 A3|b
E|G#4 B4 E5 B4 A4 G#4|E3 D#3 B2 G#2|B3 G#3|d
A|C#5 B4 A4 E4 F#4 G#4|C#3 B2 A2 E3|E3 A3|b
Dmaj7|F#4 A4 C#5 A4 G#4 F#4|D3 C#3 A2 F#2|-|d
C#7|F4 G#4 B4 G#4 F4 D#4|F3 D#3 C#3 G#2|G#3 F3|b
F#m|C#5 A4 G#4 F#4 C#4 F#4|F#2 C#3 A2 F#2|A3 F#3|d
''')]
RHYTHMS={'a':[0,.5,1,1.5,2,2.5,3,3.5], 'b':[0,.75,1.5,2,2.75,3.5],
 'c':[0,.25,.75,1.5,2,2.25,2.75,3.5], 'd':[0,.5,1.25,2,2.5,3.25]}
def pitch(s):
 return 12*(int(s[-1])+1)+{'C':0,'D':2,'E':4,'F':5,'G':7,'A':9,'B':11}[s[0]]+(1 if '#' in s else -1 if 'b' in s else 0)
def build(level):
 bars=[];events=[];pedals=[];phrases=[];n=0
 for section,bpm,txt in PARAGRAPHS:
  first=n+1;rows=[x.split('|') for x in txt.strip().splitlines()]
  for j,(harm,r,l,c,rhythm) in enumerate(rows):
   n+=1;start=(n-1)*4;tempo=bpm
   if n in (13,24,39,51,65):tempo-=4
   if n>=73:tempo-=2*(n-72)
   root,pcs=HARMONIES[harm];rp=list(map(pitch,r.split()));lp=list(map(pitch,l.split()));cp=[] if c=='-' else list(map(pitch,c.split()));rt=RHYTHMS[rhythm][:];lt=[0,1,2,3]
   assert len(rp)==len(rt),(n,r,rhythm)
   # The two revisions change audible pitches, durations and attack locations.
   if level>=1 and n in (3,6,9,11,15,17,20,22,31,41,44,48):
    lp=[lp[0],lp[3],lp[2],lp[1]];lt=[0,.75,2,3.25]
   if level>=1 and n in (2,7,14,21,30,35,42,47,55,60):
    cp=list(reversed(cp))
   if level>=2 and n in (40,42,44,46,48,50):
    # Replace weak-division motion by a written chromatic lower-neighbor pickup.
    rp[1]=rp[0]-1;rp[2]=rp[0];rt[1]=.25;rt[2]=.5
   if level>=2 and n in (53,56,59,62,66,69,72,75):
    # The return is dialogic: short-bow third phrases are extended, not looped.
    center=next((p for p in range(50,60) if p%12 in pcs and p not in cp),next(p for p in range(50,60) if p%12 in pcs))
    cp=(cp[:1] if cp else [center])+[center]+(cp[-1:] if cp else [54])
   bars.append(dict(bar=n,start=start,beats=4,bpm=tempo,meter_numerator=4,meter_denominator=4,section=section,harmony_name=harm,harmony=[root]+[60+x for x in pcs]))
   def add(inst,voice,hand,p,t,d,v,art):events.append(dict(bar=n,onset=round(start+t,6),duration=round(d,6),pitch=p,velocity=v,instrument=inst,voice=voice,hand=hand,articulation=art))
   dyn=59 if section.startswith(('A','F')) else 62 if section.startswith('C') else 77 if section.startswith('D') else 68
   pier_solo=(25,27,29,32,34,37,68,71,74)
   pier_holds=(26,28,30,33,35,38,66,67,70,72,73,75,76)
   if n in pier_solo:
    rt=[0,.75,1.5];rp=rp[:3];lt=[0];lp=lp[:1]
   elif n in pier_holds:
    anchor=4 if len(rp)==8 else 3
    rt=[0,2];rp=[rp[0],rp[anchor]];lt=[.75,2.75];lp=[lp[0],lp[2]]
   if level>=2 and n in (67,70,73,76):
    rt=[0,2,3.25,3.6];rp=[rp[0],rp[1],rp[1]+2,rp[1]]
   for k,(t,p) in enumerate(zip(rt,rp)):
    nextt=rt[k+1] if k+1<len(rt) else 4;gate=min(nextt-t-.045,1.40 if n in pier_holds else .67 if rhythm in ('b','d') else .46)
    if n in pier_solo:gate=min(gate,1.94-t)
    add('piano','salt_cartographer_subject','right',p,t,gate,dyn+(5 if t in (0,2) else -3),'cantabile_detached')
   for k,(t,p) in enumerate(zip(lt,lp)):
    nextt=lt[k+1] if k+1<len(lt) else 4
    add('piano','tide_stair_counterline','left',p,t,min(nextt-t-.06,1.32 if n in pier_solo else .72),dyn-13+(3 if k in (0,2) else 0),'nonlegato')
   ct=[.5,1.75,3] if len(cp)==3 else [.5,2.5] if len(cp)==2 else [.5]
   for k,(t,p) in enumerate(zip(ct,cp)):
    v=52 if section.startswith(('A','C','F')) else 74 if section.startswith('D') else 64
    add('cello','remembered_pier_melody','none',p,t,.76,v-(3 if k else 0),'short_bow')
   pedals.append(dict(bar=n,onset=start,controller=64,value=0,instrument='piano'))
  phrases.append(dict(first_bar=first,last_bar=n,design=section,independent_subjects=['salt_cartographer_subject','tide_stair_counterline','remembered_pier_melody']))
 assert n==76,n
 pedals.append(dict(bar=n,onset=n*4-.01,controller=64,value=0,instrument='piano'))
 return dict(id=ID,title=TITLE,title_zh=TITLE_ZH,version=f'v{level}',bars=bars,events=events,pedals=pedals,total_beats=n*4,tail_seconds=TAIL,instrument_map={'piano':'piano','cello':'arco'},phrase_map=phrases,nominal_onsets_no_sample_compensation=True)
RENDERER_NOTES='Original nominal piano/cello duet. Cello is the Iowa D3–B3 short-bow pp/mf sample set, not pizzicato or synth. Its line favors thirds, sixths and sequential answers rather than root doubling. All gates remain whole; exact next-pitch/layer delays are used only by the independent prediction audit. Do not put sample compensation into the source. Pedal is released throughout for clear contrapuntal dialogue.'
