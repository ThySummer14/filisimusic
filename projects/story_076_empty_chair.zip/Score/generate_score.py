#!/usr/bin/env python3
"""Work 076. Deterministic, Python-standard-library-only, score generation.
No audio, rendering, installation, external I/O, random choices, or inherited motifs.
Usage: python generate_score.py [--output DIR] [--verify]
A token is NOTE:nominal_quarter_beats; r is a rest. Every written row is one bar.
"""
import argparse, collections, copy, difflib, hashlib, json, math, pathlib, re, tempfile
HERE = pathlib.Path(__file__).resolve().parent
TITLE = '空椅子的华尔兹'
# bass, close-position left-hand chord. Bass is released before the chord arrives.
H = {
 'Bb':(46,[50,53,58]), 'Bb/D':(50,[53,58,62]), 'Bb/F':(53,[58,62,65]),
 'F':(41,[48,53,57]), 'F/A':(45,[48,53,57]), 'F7':(41,[51,57,60]),
 'F9':(41,[51,55,57]), 'F7sus4':(41,[51,53,58]),
 'Gm':(43,[50,55,58]), 'Gm/F':(41,[50,55,58]), 'Dm':(50,[53,57,62]),
 'Dm/F':(41,[50,53,57]), 'Dm/A':(45,[50,53,57]),
 'Eb':(51,[55,58,63]), 'Eb/G':(43,[51,55,58]), 'Ebm6':(51,[54,58,60]),
 'Cm7':(48,[51,55,58]), 'Cm/Eb':(51,[55,60,63]),
 'A7':(45,[49,55,57]), 'Adim':(45,[51,54,60]),
 'D7':(50,[54,57,60]), 'D7/A':(45,[54,57,60]),
 'G':(43,[50,55,59]), 'G/B':(47,[50,55,59]), 'G/D':(50,[55,59,62]),
 'D':(50,[54,57,62]), 'D/F#':(42,[50,54,57]),
 'Em':(40,[52,55,59]), 'Em/B':(47,[52,55,59]),
 'Bm':(47,[50,54,59]), 'C':(48,[52,55,60]), 'C/E':(40,[52,55,60]),
 'Cmaj7':(48,[52,55,59]), 'Am7':(45,[52,55,60]),
 'E7':(40,[52,56,59]), 'Edim':(40,[52,55,58]),
}
# Full first draft, bar by bar. Repetition at the thematic return is intentional.
ROWS = [
# 1-4: an empty chair is ceremoniously installed.
('Bb','r:1 D5:1 F5:1'),
('F7','A5:1.5 G5:0.5 F5:1'),
('Eb','G5:1 Eb5:1 Bb4:1'),
('F7','C5:1.5 r:1 F5:0.5'),
# 5-12: first eight-bar song; a high arrival and a long unwinding answer.
('Bb','D5:1.5 F5:0.5 Bb5:1'),
('F/A','A5:2 G5:1'),
('Gm','F5:1.5 D5:0.5 G5:1'),
('Dm/F','F5:2 D5:1'),
('Eb','Eb5:1.5 G5:0.5 Bb5:1'),
('Bb/D','A5:0.5 Bb5:0.5 F5:2'),
('Cm7','G5:1 Eb5:1 C5:1'),
('F7','A4:2 r:0.5 C5:0.5'),
# 13-20: answering eight; modal shadow is comic stage stiffness, not grief.
('Bb','D5:1.5 F5:0.5 Bb5:1'),
('D7','A5:1 F#5:1 D5:1'),
('Gm','G5:2 Bb5:1'),
('Gm/F','A5:1 G5:1 F5:1'),
('Eb','G5:1.5 F5:0.5 Eb5:1'),
('Ebm6','Gb5:1.5 F5:0.5 Eb5:1'),
('Bb/F','D5:1 F5:1 Bb4:1'),
('F7','C5:2 r:0.5 A4:0.5'),
# 21-28: extension; one more expansive circuit around the chair.
('Bb','Bb4:1 D5:1 F5:1'),
('Dm/A','A5:2 F5:1'),
('Gm','Bb5:1 A5:0.5 G5:0.5 F5:1'),
('Eb/G','G5:2 Eb5:1'),
('Cm7','Eb5:1 G5:1 C6:1'),
('F7','A5:1 G5:1 F5:1'),
('Bb','D5:1 C5:1 Bb4:0.5 r:0.5'),
('F7','C5:1 Eb5:1 F5:0.5 r:0.5'),
# 29-40: initial draft's neat but insufficiently theatrical middle.
('Dm','F5:1 A5:1 F5:1'),
('A7','E5:1 C#5:1 E5:1'),
('Dm','D5:1 F5:1 A5:1'),
('Cm7','G5:2 Eb5:1'),
('Bb/D','F5:1 D5:1 Bb4:1'),
('Adim','C5:1 Eb5:1 F#5:1'),
('Gm','G5:1 D5:1 Bb4:1'),
('D7','A4:1 C5:1 F#5:1'),
('Gm','G5:2 D5:1'),
('Cm7','Eb5:1 C5:1 G4:1'),
('D7/A','A4:1 D5:1 F#5:1'),
('D7','A5:2 r:1'),
# 41-64: first-draft trio is already complete, later given more independent syntax.
('G','B4:1 D5:1 G5:1'),
('D/F#','F#5:2 E5:1'),
('Em','D5:1 B4:1 E5:1'),
('Bm','D5:2 B4:1'),
('C','C5:1 E5:1 G5:1'),
('G/B','F#5:1 G5:1 D5:1'),
('Am7','E5:1 C5:1 A4:1'),
('D7','F#4:2 r:0.5 A4:0.5'),
('G','B4:1 D5:1 G5:1'),
('D','A5:2 F#5:1'),
('Em','G5:1 B5:1 G5:1'),
('Bm','F#5:2 D5:1'),
('C','E5:1 G5:1 C6:1'),
('G/B','B5:1 A5:1 G5:1'),
('Am7','E5:1 C5:1 A4:1'),
('D7','A4:2 r:1'),
('Em','B4:1 E5:1 G5:1'),
('Cmaj7','E5:2 D5:1'),
('A7','C#5:1 E5:1 G5:1'),
('D7','F#5:2 A5:1'),
('G','G5:2 D5:1'),
('C','E5:1 G5:1 E5:1'),
('Gm','D5:1 Bb4:1 G4:1'),
('F7','A4:2 r:1'),
# 65-68: chair is moved; one incomplete turn and a new entrance.
('Eb','G5:1 Eb5:1 Bb4:1'),
('Edim','E5:1 G5:1 Bb5:1'),
('F7sus4','Bb5:1 G5:1 F5:1'),
('F7','A4:2 r:0.5 C5:0.5'),
# 69-88: first draft repeats the familiar opening then a compact closing answer.
('Bb','D5:1.5 F5:0.5 Bb5:1'),
('F/A','A5:2 G5:1'),
('Gm','F5:1.5 D5:0.5 G5:1'),
('Dm/F','F5:2 D5:1'),
('Eb','Eb5:1.5 G5:0.5 Bb5:1'),
('Bb/D','A5:0.5 Bb5:0.5 F5:2'),
('Cm7','G5:1 Eb5:1 C5:1'),
('F7','A4:2 r:0.5 C5:0.5'),
('Bb','D5:1.5 F5:0.5 Bb5:1'),
('D7','A5:1 F#5:1 D5:1'),
('Gm','G5:2 Bb5:1'),
('Gm/F','A5:1 G5:1 F5:1'),
('Eb','G5:1.5 F5:0.5 Eb5:1'),
('Ebm6','Gb5:1.5 F5:0.5 Eb5:1'),
('Bb/F','D5:1 F5:1 Bb4:1'),
('F7','C5:2 r:0.5 A4:0.5'),
('Cm7','Eb5:1 G5:1 C6:1'),
('F7','A5:1 G5:1 F5:1'),
('Bb','D5:1 C5:1 Bb4:1'),
('Bb','F5:2 r:1'),
# 89-96: a first-draft conventional cadence, replaced in revision two.
('Eb','G5:1 F5:1 Eb5:1'),
('Bb/D','F5:1 D5:1 Bb4:1'),
('Cm7','Eb5:1 C5:1 G4:1'),
('F7','A4:1 C5:1 F5:1'),
('Bb','D5:1 F5:1 Bb5:1'),
('F7','A5:1 G5:1 F5:1'),
('Bb','D5:1 C5:1 Bb4:1'),
('Bb','Bb4:3'),
]
# Revision one: write actual collisions into B, and give the trio its own tune.
REV1 = {
29:('Dm','r:0.5 F5:1 A5:1 r:0.5'),
30:('A7','G5:0.5 F5:0.5 E5:1.5 r:0.5'),
31:('Dm','F5:1.5 E5:0.5 D5:1'),
32:('Cm7','Eb5:2 r:0.5 G5:0.5'),
33:('Bb/D','F5:1.5 Bb5:1 r:0.5'),
34:('Adim','A5:0.5 G5:0.5 F#5:1.5 r:0.5'),
35:('Gm','G5:1.5 A5:0.5 Bb5:1'),
36:('D7','A5:2 r:0.5 F#5:0.5'),
37:('Gm','G5:1.5 D5:0.5 Bb4:1'),
38:('Cm7','C5:0.5 D5:0.5 Eb5:1 G5:1'),
39:('D7/A','F#5:1 E5:0.5 D5:0.5 C5:1'),
40:('D7','A4:1.75 r:1.25'),
41:('G','B4:2 A4:1'),
42:('D/F#','A4:1 C5:0.5 B4:0.5 A4:1'),
43:('Em','G4:1.5 B4:0.5 E5:1'),
44:('Bm','D5:2.5 r:0.5'),
45:('C','E5:1 F#5:0.5 G5:0.5 E5:1'),
46:('G/B','D5:1.5 B4:0.5 C5:1'),
47:('Am7','C5:1 B4:1 A4:1'),
48:('D7','F#4:2 r:0.5 A4:0.5'),
49:('G','B4:1 D5:0.5 E5:0.5 G5:1'),
50:('D','F#5:2 A5:1'),
51:('Em','G5:1.5 F#5:0.5 E5:1'),
52:('Bm','D5:2.5 r:0.5'),
53:('C','E5:1 G5:0.5 A5:0.5 C6:1'),
54:('G/B','B5:1.5 A5:0.5 G5:1'),
55:('Am7','E5:1 D5:0.5 C5:0.5 B4:1'),
56:('D7','A4:1.75 r:0.75 D5:0.5'),
57:('Em','E5:2 B4:1'),
58:('Cmaj7','B4:1 C5:0.5 D5:0.5 E5:1'),
59:('A7','C#5:2 E5:1'),
60:('D7','F#5:1 E5:0.5 D5:0.5 A4:1'),
61:('G','B4:1 D5:1 G5:1'),
62:('C','E5:1.5 D5:0.5 C5:1'),
63:('Gm','D5:1.5 Bb4:0.5 G4:1'),
64:('F7','A4:1.75 r:1.25'),
}
# Revision two: the chair's move has consequences in the return and ending.
REV2 = {
65:('Eb','r:1.5 G5:0.5 F5:0.5 Eb5:0.5'),
66:('Edim','E5:0.5 F5:0.5 G5:1 Bb5:1'),
67:('F7sus4','Bb5:1.5 G5:0.5 F5:1'),
68:('F7','A4:1.5 r:1 C5:0.5'),
# First eight bars of A remain unmistakable. The answer turns to the real front.
77:('Bb/D','D5:1.5 F5:0.5 Bb5:1'),
78:('Eb','G5:1.5 F5:0.5 Eb5:1'),
79:('Cm7','G5:1 C6:1 Bb5:1'),
80:('F7','A5:2 F5:1'),
81:('Dm','F5:1.5 A5:0.5 D6:1'),
82:('Gm','Bb5:1.5 A5:0.5 G5:1'),
83:('Cm7','G5:1 Eb5:1 C5:1'),
84:('F7','C5:1 A4:1 r:1'),
85:('Bb','D5:1.5 F5:0.5 Bb5:1'),
86:('Eb','G5:1 F5:1 Eb5:1'),
87:('F7','C5:1 A4:1 r:1'),
88:('Bb','Bb4:2.25 r:0.75'),
89:('Eb','r:1 G5:1 F5:1'),
90:('Bb/D','D5:1.5 F5:0.5 Bb5:1'),
91:('Cm7','G5:2 Eb5:1'),
92:('F7','C5:1.5 A4:0.75 r:0.75'),
93:('Bb','D5:1.5 F5:0.5 Bb5:1'),
94:('F9','G5:1 F5:1 Eb5:1'),
95:('Bb/F','D5:1.25 C5:0.5 Bb4:0.75 r:0.5'),
96:('Bb','Bb4:2.6 r:0.4'),
}
SECTIONS = [
(1,4,'摆椅子','第一排观众被摆在舞池中央；四小节邀请语。'),
(5,28,'向空椅行礼','长线主旋律；左手轻巧三拍圆舞曲，跟随每次呼吸。'),
(29,40,'每个人都朝前','转向冲突；错开的半拍和双小节重心使旧路线难以维持。'),
(41,64,'小满看平面图','G大调中段；低一些的旋律和宽松伴奏把方向说清楚。'),
(65,68,'椅子挪到门边','一次真实停顿，方向改变；全班等小满数拍再进入。'),
(69,88,'同一支舞的新转向','保留熟悉的开头，改写答句、高潮和终止，路线不再闭合。'),
(89,96,'观看权与掌声','错开的入场被收入短尾声；干净结束，老师最后只拍掌。'),
]
NOTE_NAMES = {'C':0,'D':2,'E':4,'F':5,'G':7,'A':9,'B':11}
def pitch(s):
 m=re.fullmatch(r'([A-G])([b#]?)(-?\d+)',s)
 assert m,s
 return 12*(int(m[3])+1)+NOTE_NAMES[m[1]]+({'':0,'b':-1,'#':1}[m[2]])
def tokens(s):
 out=[]; t=0.
 for token in s.split():
  n,d=token.split(':'); d=float(d)
  if n!='r': out.append((t,d,pitch(n)))
  t+=d
 assert abs(t-3)<1e-9,(s,t)
 return out

def section(n):
 return next((name,role) for lo,hi,name,role in SECTIONS if lo<=n<=hi)
def bpm(n,v):
 if n<=4:return [88,94,94,88][n-1]
 if n<=28:
  b=102 if n<=12 else 104 if n<=20 else 106
  return {12:98,20:98,27:100,28:100}.get(n,b)
 if n<=40:return {32:104,36:104,40:92}.get(n,108)
 if n<=64:return {44:94,48:94,52:98,56:94,60:100,63:94,64:86}.get(n,98 if n<=48 else 102)
 if n<=68:return [82,92,94,88][n-65] if v>=2 else 94
 if n<=88:return {76:98,84:98,87:100,88:90}.get(n,104 if n<=76 else 108)
 return [98,100,98,92,94,88,80,70][n-89] if v>=2 else [100,100,100,98,96,92,86,76][n-89]
def event(n,on,dur,p,vel,voice):
 return {'bar':n,'onset':round((n-1)*3+on,6),'duration':round(dur,6),
         'pitch':p,'velocity':int(vel),'voice':voice,'instrument':'piano',
         'hand':'right' if voice in ('melody','upper_support') else 'left'}
def generate(v):
 rows=copy.deepcopy(ROWS)
 if v>=1:
  for n,r in REV1.items():rows[n-1]=r
 if v>=2:
  for n,r in REV2.items():rows[n-1]=r
 bars=[];events=[];pedals=[]
 assert len(rows)==96
 for n,(harm,mel) in enumerate(rows,1):
  start=float((n-1)*3); name,role=section(n); bass,chord=H[harm]
  bars.append({'bar':n,'start':start,'beats':3.0,'bpm':bpm(n,v),'section':name,
   'meter_numerator':3,'meter_denominator':4,'harmony_name':harm,'harmony':chord,
   'role_plan':role,'lead_instrument':'piano'})
  notes=tokens(mel)
  # Dynamics follow phrases rather than random per-note humanization.
  base=57 if n<=4 else 67 if n<=28 else 66 if n<=40 else 60 if n<=64 else 55 if n<=68 else 70 if n<=88 else 56
  arc=[0,1,2,0,2,4,0,-3][(n-5)%8]
  for idx,(on,d,p) in enumerate(notes):
   gate=.955 if d<=.5 else .975
   if 29<=n<=40 and v>=1:gate=.88 if d<=1 else .945
   velocity=base+arc+(2 if idx==0 else -1)+(2 if p>=82 else 0)
   if n>=93:velocity-=2*(n-93)
   events.append(event(n,on,max(.10,d*gate),p,velocity,'melody'))
  # In v1 the trio drops the third-beat chord, gaining room and a different gait.
  if 41<=n<=64 and v>=1:
   pattern=[(0,.78,[bass],'bass',39),(1.08,1.62,chord,'accompaniment',31)]
  elif 29<=n<=40 and v>=1:
   # Three real quarter beats remain audible; no second tune in the bass.
   pattern=[(0,.64,[bass],'bass',42),(1.08,.42,chord,'accompaniment',32),(2.03,.48,chord,'accompaniment',30)]
  else:
   pattern=[(0,.76,[bass],'bass',40),(1.06,.64,chord,'accompaniment',32),(2.03,.61,chord,'accompaniment',29)]
  if n<=4:
   pattern=[(0,.80,[bass],'bass',33),(1.08,1.44,chord,'accompaniment',27)]
  # Shared phrase breaths are composed, not a MIDI-density optimization.
  breath_bars={12,20,27,28,40,44,48,52,56,64,68,76,84,88,92,95,96}
  if v>=1 and n in breath_bars:
   pattern=[(o,min(d,max(.14,2.12-o)),ps,vo,vel) for o,d,ps,vo,vel in pattern if o<2.0]
  if v>=2 and n==65:
   pattern=[(1.5,.44,[bass],'bass',34),(2.10,.55,chord,'accompaniment',28)]
  if v>=2 and n in (84,87):
   pattern=[(0,.70,[bass],'bass',37),(1.04,.66,chord,'accompaniment',29)]
  if v>=2 and n==89:
   pattern=[(1,.75,[bass],'bass',32),(2.04,.58,chord,'accompaniment',27)]
  if v>=2 and n==96:
   # Compact final left-hand spread: Bb2-F3-Bb3, exactly an octave.
   pattern=[(0,2.62,[46,53,58],'accompaniment',34)]
  for on,d,ps,vo,vel in pattern:
   for p in ps:events.append(event(n,on,d,p,vel+(3 if 69<=n<=83 else 0),vo))
  # Only cadential color, no independent upper/bass competing melodies.
  if v>=2 and n in (53,54,79,81,82):
   on,d,top=notes[-1]
   choices=[p+12*k for p in chord for k in range(4) if 3<=top-(p+12*k)<=9]
   candidate=max(choices)
   events.append(event(n,on,d*.88,candidate,45,'upper_support'))
  if n==96:
   for p in (74,77):events.append(event(n,0,2.535 if v>=2 else 2.85,p,46 if p==74 else 44,'upper_support'))
  # Moonlight semantics: values 64+ are full, 23..63 partial/half.
  value=72 if (5<=n<=28 or 69<=n<=83) else 48
  if 29<=n<=40:value=40 if v>=1 else 70
  if n in (4,12,20,28,40,48,56,64,68,76,84,88,92,95):value=45
  down=.07;up=2.82
  if v>=1 and n in breath_bars:up=2.16
  if v>=2 and n in (84,87):up=1.78
  if v>=2 and n==65:down=1.57;up=2.77;value=35
  if v>=2 and n==89:down=1.07;up=2.78;value=45
  if n==96:down=.07;up=2.70 if v>=2 else 2.91;value=76
  pedals += [{'onset':start,'value':0},{'onset':round(start+down,6),'value':value},{'onset':round(start+up,6),'value':0}]
 events.sort(key=lambda e:(e['onset'],e['pitch'],e['voice']))
 pedals.sort(key=lambda p:p['onset'])
 return {'id':76,'title':'Waltz for an Empty Chair','title_zh':TITLE,
  'bars':bars,'events':events,'pedals':pedals,'total_beats':288.0,'tail_seconds':3.5}

def audit(s):
 errors=[]; max_spans={};overlaps=[]
 bypitch=collections.defaultdict(list)
 for e in s['events']:
  bypitch[e['pitch']].append(e)
  if not(e['duration']>0 and 1<=e['velocity']<=127 and 0<=e['pitch']<=127):errors.append(['invalid_event',e])
  if not(0<=e['onset']<s['total_beats'] and e['onset']+e['duration']<=s['total_beats']+1e-9):errors.append(['event_outside',e])
 for p,ee in bypitch.items():
  ee.sort(key=lambda e:e['onset']); end=-1
  for e in ee:
   if e['onset']<end-1e-9:overlaps.append({'pitch':p,'onset':e['onset'],'previous_end':end})
   end=max(end,e['onset']+e['duration'])
 for hand in ('left','right'):
  ee=[e for e in s['events'] if e['hand']==hand]
  maxspan=0;worst=None;maxkeys=0
  for t in sorted(set(e['onset'] for e in ee)):
   active=[e for e in ee if e['onset']<=t+1e-9 and e['onset']+e['duration']>t+1e-9]
   pp=sorted(set(e['pitch'] for e in active)); span=pp[-1]-pp[0] if pp else 0
   maxkeys=max(maxkeys,len(pp))
   if span>maxspan:maxspan=span;worst={'beat':t,'pitches':pp}
   if span>12:errors.append(['hand_span',hand,t,pp])
  max_spans[hand]={'maximum_simultaneous_semitones':maxspan,'maximum_simultaneous_keys':maxkeys,'example':worst}
 seconds=sum(60*b['beats']/b['bpm'] for b in s['bars'])
 # Exact fingerprints measure only nominal note content, not quality/listening.
 fingerprints=[]
 for b in s['bars']:
  fp=tuple((round(e['onset']-b['start'],5),e['duration'],e['pitch'],e['voice']) for e in s['events'] if e['bar']==b['bar'])
  fingerprints.append(fp)
 matches=[]
 for i in range(len(fingerprints)-3):
  for j in range(i+4,len(fingerprints)-3):
   if fingerprints[i:i+4]==fingerprints[j:j+4]:matches.append([i+1,j+1])
 for b in s['bars']:
  if b['start']!=(b['bar']-1)*3 or b['beats']!=3:errors.append(['bar_grid',b['bar']])
 full=sum(p['value']>=64 for p in s['pedals']);partial=sum(23<=p['value']<=63 for p in s['pedals'])
 return {'status':'PASS' if not errors and not overlaps else 'FAIL','scope':'Symbolic score checks only; no render, human listening, perceived quality, or instrument calibration is asserted.',
  'bars':len(s['bars']),'meter':'3/4 throughout','quarter_beats':s['total_beats'],
  'tempo_integrated_seconds':round(seconds,6),'tail_seconds':s['tail_seconds'],'estimated_total_seconds':round(seconds+s['tail_seconds'],6),
  'events':len(s['events']),'pitch_range':[min(e['pitch'] for e in s['events']),max(e['pitch'] for e in s['events'])],
  'hands':max_spans,'same_key_overlap_count':len(overlaps),'same_key_overlaps':overlaps,
  'pedal':{'full_sustain_downs_64_127':full,'partial_downs_23_63':partial,'release_events':sum(p['value']==0 for p in s['pedals']),'final_value':s['pedals'][-1]['value'],'note':'Hand spans concern physically held keys, not sympathetically sustained notes.'},
  'exact_four_bar_block_matches':matches,'repeat_interpretation':'The original A opening deliberately returns; repetition here is thematic, not evidence of padding or a quality score.',
  'errors':errors}

def dump(obj):return json.dumps(obj,ensure_ascii=False,indent=2)+'\n'
def changes(a,b):
 out=[]
 for n in range(1,97):
  old={'bar':a['bars'][n-1],'events':[e for e in a['events'] if e['bar']==n],
       'pedals':[p for p in a['pedals'] if (n-1)*3<=p['onset']<n*3]}
  new={'bar':b['bars'][n-1],'events':[e for e in b['events'] if e['bar']==n],
       'pedals':[p for p in b['pedals'] if (n-1)*3<=p['onset']<n*3]}
  if old!=new:out.append({'bar_number':n,'before':old,'after':new})
 return out

def outputs():
 ss=[generate(v) for v in range(3)]; files={}
 for v,s in enumerate(ss):
  files[f'score_v{v}.json']=dump(s);files[f'audit_v{v}.json']=dump(audit(s))
  assert audit(s)['status']=='PASS',audit(s)
 files['score.json']=files['score_v2.json']
 for a,b in ((0,1),(1,2)):
  files[f'revision_v{a}_to_v{b}.diff']=''.join(difflib.unified_diff(files[f'score_v{a}.json'].splitlines(True),files[f'score_v{b}.json'].splitlines(True),fromfile=f'score_v{a}.json',tofile=f'score_v{b}.json'))
  files[f'revision_v{a}_to_v{b}_exact.json']=dump(changes(ss[a],ss[b]))
 manifest={name:hashlib.sha256(data.encode()).hexdigest() for name,data in sorted(files.items())}
 files['score_hashes.json']=dump(manifest)
 return files

def main():
 parser=argparse.ArgumentParser();parser.add_argument('--output',type=pathlib.Path,default=HERE);parser.add_argument('--verify',action='store_true');args=parser.parse_args()
 files=outputs()
 if args.verify:
  mismatch=[name for name,data in files.items() if not(args.output/name).exists() or (args.output/name).read_text(encoding='utf-8')!=data]
  report={'status':'PASS' if not mismatch else 'FAIL','method':'All score versions, aliases, exact diffs, symbolic audits and hashes regenerated in memory with Python standard library and compared byte for byte.','files_checked':len(files),'mismatched_files':mismatch,'randomness':'None','external_dependencies':[],'audio_rendered':False}
  (args.output/'reproducibility.json').write_text(dump(report),encoding='utf-8')
  print(dump(report));assert not mismatch
 else:
  args.output.mkdir(parents=True,exist_ok=True)
  for name,data in files.items():(args.output/name).write_text(data,encoding='utf-8')
  print(dump(audit(generate(2))))
if __name__=='__main__':main()
