# 072 — 风换了主人 / The Wind Changed Hands

Original non-rendering woodwind-duet rondo draft for the 50-piece story collection.

Use `score_v2.json` as the final written-score candidate. Only the existing sampled flute and clarinet are specified. No piano, extra sounds, audio, REAPER project, renderer, download, installation or browser work was used.

## Main deliverables

- `story_zh.md`: original Chinese fiction, about 1,200 characters. A weather keeper retires, an apprentice opens autumn during summer, and they learn to sort useful breezes. The ending grants one deliberate spoon of autumn.
- `score_v0.json`, `score_v1.json`, `score_v2.json`: three complete 96-bar scores in the requested schema, with phrase/layer/target timing annotations.
- `generate_score.py`: deterministic Python standard-library generator and structural auditor. Run `python generate_score.py` in this directory.
- `theme_harmony_notes.md`: complete form, original A theme, episode identities, harmony, role assignments, breath and integration notes.
- `revisions.md`, `revision_diff.json`: two substantive revisions with exact changed-bar accounting.
- `technical_audit.md`, `technical_audit.json`, `audit_v0.json`, `audit_v1.json`, `audit_v2.json`: written-score checks and explicit limitations.
- `phrase_plan_v0.json`, `phrase_plan_v1.json`, `phrase_plan_v2.json`: per-instrument phrase IDs, layer and target windows/breaths.
- `score_v2_full.txt`, `score_v2_events.csv`: readable full-score transcription and event list.
- `verify_score.py`, `independent_validation.json`: independent JSON-only boundary verification.
- `generated_sha256.json`, `reproducibility_check.json`, `delivery_manifest.json`: reproducibility and handoff inventory.

## Essential integration facts

96 bars, 3/4, 288 quarter beats; A–B–A–C–A–coda. Written duration 172.959 seconds, or 176.959 seconds with a four-second tail (approximately 2:57).

Flute MIDI 72–83; clarinet MIDI 60–71. Only pp 21–55 / mf 56–95; one actual sample layer per instrument phrase. Both voices are monophonic and use short articulated notes.

Flute `onset` is the intended voiced/pitched arrival. This draft has NOT applied the existing 50–209 ms compensation; the parent must apply it once. Clarinet `onset` is an ordinary trigger. Provide pre-roll for the first flute trigger, preferably 0.5 seconds; do not clamp a negative compensated trigger to zero. The duration above excludes pre-roll.

The literal A melody returns at bars 33–40. At 69–76 it returns an octave lower in clarinet, then the continuation and ending change. Each bar declares its single foreground instrument; the other is sparse consonant pp support or rests. Bars 67–68 are clarinet alone.

All three versions pass written-score audits. Tests do not guarantee subjective musical quality. No listening or sample-validation claim is made; the parent owns rendering, balance, release-envelope assessment and listening.
