#!/usr/bin/env python3
"""078: fully specified original piano score. Standard library; deterministic; no audio.
Run: python generate_score.py. Durations and tempos use QUARTER-note units.
"""
from pathlib import Path
import collections, copy, difflib, hashlib, json, math

OUT = Path(__file__).resolve().parent
BEATS = 4.5
# MIDI note spellings follow D-flat/B-flat minor; written spellings here are intentional.
N = {'Db4':61,'Eb4':63,'F4':65,'Gb4':66,'Ab4':68,'Bb4':70,'C5':72,
     'Db5':73,'Eb5':75,'F5':77,'Gb5':78,'Ab5':80,'A5':81,'Bb5':82,
     'C6':84,'Db6':85,'Eb6':87}
# The first value is the low arrival. Others are a coordinated left-hand broken chord.
H = {
 'Dbmaj9':(37,[44,49,53,56],[49,53,56,63]),
 'Dbmaj7':(37,[44,49,53,60],[49,53,56,60]),
 'Db6add9':(37,[44,49,53,58],[49,53,56,58,63]),
 'Ab/C':(36,[44,48,51,56],[48,51,56]),
 'Bbm7':(34,[41,46,49,53],[46,49,53,56]),
 'Bbm9':(34,[41,46,49,56],[46,49,53,56,60]),
 'Bbm':(34,[41,46,49,53],[46,49,53]),
 'Gbmaj7':(42,[49,54,58,61],[54,58,61,65]),
 'Gbmaj9':(42,[49,54,58,61],[54,58,61,65,68]),
 'Gb/Db':(37,[44,49,54,58],[49,54,58]),
 'Ebm7':(39,[46,51,54,58],[51,54,58,61]),
 'Ebm9':(39,[46,51,54,58],[51,54,58,61,65]),
 'Ab7':(44,[51,56,60,63],[56,60,63,66]),
 'Ab7sus':(44,[51,56,61,63],[56,61,63,66]),
 'Db/F':(41,[49,53,56,61],[49,53,56]),
 'Db/Ab':(44,[49,53,56,61],[49,53,56]),
 'Fm7':(41,[48,53,56,60],[53,56,60,63]),
 'F7/A':(45,[53,57,60,63],[53,57,60,63]),
 'F7':(41,[48,53,57,60],[53,57,60,63]),
 'F7sus':(41,[48,53,58,60],[53,58,60,63]),
 'Cdim7':(36,[42,48,51,57],[48,51,54,57]),
}
# A dash is a composed breath, rather than a missing generator event.
def line(text):
    out=[]
    for token in text.split():
        pitch, duration=token.split(':')
        out.append((None if pitch=='-' else N[pitch],float(duration)))
    assert math.isclose(sum(x[1] for x in out),BEATS), text
    return out

MELODIES = [
'Ab4:1.5 Db5:2 Eb5:1', 'F5:1 Eb5:0.5 C5:1.5 Bb4:1.5',
'Db5:1.5 F5:1.5 Ab5:1.5', 'Gb5:2 F5:0.5 Eb5:1 Db5:1',
'Eb5:1.5 Gb5:2 F5:1', 'Eb5:0.5 C5:1 Bb4:1.5 Eb5:1.5',
'F5:2.5 Eb5:0.5 Db5:1.5', 'C5:1.5 Eb5:1 Bb4:0.5 Ab4:1.5',
'F5:2 Eb5:0.5 Db5:1 Ab4:1', 'Db5:1 F5:0.5 Ab5:3',
'Gb5:2.5 F5:0.5 Eb5:1.5', 'Eb5:1 C5:0.5 Bb4:1 Ab4:2',
'Db5:1.5 F5:1 Ab5:2', 'Bb5:2 Ab5:1 Gb5:1.5',
'F5:1 Eb5:0.5 Gb5:2 F5:1', 'Eb5:2 C5:1 Bb4:0.5 Ab4:1',
'F5:1.5 Ab5:2 F5:1', 'Eb5:1 C5:0.5 Eb5:1.5 Ab5:1.5',
'F5:2.5 Db5:0.5 C5:1.5', 'Db5:0.5 Eb5:1 Gb5:2 Bb5:1',
'Ab5:1.5 Gb5:1.5 F5:1.5', 'F5:2 Eb5:0.5 Db5:2',
'C5:0.5 Eb5:1 Gb5:1.5 F5:1.5', 'Eb5:1 Db5:3 -:0.5',
# Revised middle: the three turns rotate the Db/F/Eb interval identity.
'F5:1.5 Db5:2 C5:1', 'C5:1.5 Eb5:1 F5:2',
'Bb4:1 Db5:0.5 F5:3', 'Gb5:2 F5:0.5 Eb5:2',
'Bb5:1.5 Ab5:0.5 Gb5:1 F5:1.5', 'Ab5:2 F5:0.5 Eb5:2',
'Gb5:1 Eb5:0.5 C5:1.5 Eb5:1.5', 'F5:3 Eb5:0.5 C5:1',
'Db5:1.5 F5:1.5 Gb5:1.5', 'Ab5:1.5 Gb5:2 F5:1',
'C5:0.5 F5:1 Bb5:1.5 Ab5:1.5', 'A5:2.5 Gb5:0.5 F5:1.5',
'Bb5:3 Ab5:0.5 F5:1', 'Ab5:0.5 Bb5:1 Db6:2 Bb5:1',
'Ab5:2 F5:0.5 Eb5:2', 'Gb5:1.5 Ab5:2 C6:1',
'Db6:2 C6:0.5 Bb5:2', 'Bb5:1 Ab5:0.5 Gb5:1 Db6:2',
'Eb6:1.5 Db6:1 Bb5:2', 'C6:2 Ab5:0.5 Gb5:2',
'F5:1.5 Ab5:0.5 Db6:2 C6:0.5', 'Bb5:2.5 Ab5:0.5 Gb5:1.5',
'Eb5:0.5 Gb5:1 C6:1.5 Bb5:1.5', 'Ab5:3 F5:1 Eb5:0.5',
'F5:2 Eb5:0.5 Db5:1 Ab4:1', 'Db5:1 F5:0.5 Ab5:3',
'Gb5:1.5 Bb5:1 Ab5:2', 'Gb5:1 Eb5:0.5 C5:3',
'Db5:1.5 F5:1 Ab5:2', 'Bb5:1.5 Ab5:1 Gb5:2',
'F5:1 Eb5:0.5 Db5:1.5 Bb4:1.5', 'C5:2 Eb5:1 Bb4:0.5 Ab4:1',
# Final revision: the light becomes a root, and the melody descends into its register.
'F5:1.5 Db5:2 Bb4:1', 'Bb4:1 Db5:0.5 F5:1.5 Eb5:1.5',
'F5:1 Eb5:0.5 Db5:2 Ab4:1', 'Gb5:1.5 F5:0.5 Eb5:1 Db5:1.5',
'Db5:2.5 F5:0.5 Eb5:1.5', 'Gb5:1.5 Eb5:1.5 Db5:1.5',
'Bb4:1.5 Ab4:1.5 Gb4:1.5', 'F4:1.5 Eb4:0.5 Db4:2.5',
]
HARMONIES = (
'Dbmaj7 Ab/C Bbm7 Gbmaj9 Ebm7 Ab7 Db/F Ab7 '
'Dbmaj9 Bbm7 Gbmaj7 Ab7 Db/F Gbmaj9 Ebm7 Ab7 '
'Dbmaj7 Fm7 Bbm9 Gbmaj7 Ebm9 Db/Ab Ab7 Dbmaj9 '
'Bbm9 F7/A Bbm Ebm9 Gbmaj7 Db/F Cdim7 F7 Bbm Ebm7 F7sus F7 '
'Bbm9 Gbmaj9 Db/Ab Ab7 Dbmaj9 Gbmaj7 Ebm9 Ab7 Db/F Gbmaj9 Ab7 Dbmaj9 '
'Dbmaj7 Bbm7 Gbmaj9 Ab7 Db/F Gbmaj7 Ebm9 Ab7 '
'Bbm7 Gbmaj9 Db/F Ebm9 Db/Ab Ab7sus Gb/Db Db6add9'
).split()
assert len(MELODIES)==len(HARMONIES)==64

# Differentiated compound-meter support. Index 0 is not a downbeat chord block.
PATTERNS = [
 [0,1,2,3,1,0,1,2], [0,1,2,1,3,2,1,0],
 [0,2,1,3,2,1,0,2], [0,1,3,2,1,2,3,1],
 [0,1,2,3,2,1,0,1], [0,2,3,1,2,3,1,2],
 [0,1,2,1,0,1,2,3], [0,2,1,2,3,2,1,0],
]
PATTERN_SEQUENCE = [0,1,4,2,0,6,3,7, 0,4,2,6,3,5,1,7,
  4,6,0,3,5,2,7,1, 6,2,4,1,5,3,7,6,0,5,3,2,
  3,5,2,6,4,3,5,7,0,2,6,1, 0,4,5,7,3,2,6,1, 4,2,0,6,3,7,4,0]

def section(b):
    if b<=8:return '灯沉入旧田埂'
    if b<=24:return '三圈光，第一轮采收'
    if b<=36:return '双籽认出两盏灯'
    if b<=48:return '九盏灯接成活的弧线'
    if b<=56:return '幼根随灯上浮'
    return '巡航艇下的新树行'

# Deliberate phrase rubato, all numbers are QUARTER-note BPM, not dotted-quarter BPM.
TEMPOS = [82,84,85,84,86,85,82,80,
 88,90,91,89,90,92,89,85, 89,90,92,92,90,89,86,82,
 85,86,87,84,87,88,86,83,88,90,89,85,
 93,95,96,94,96,96,97,94,95,94,91,88,
 90,91,92,89,90,89,87,84, 84,85,84,82,81,80,76,68]

V0_MIDDLE = [
'F5:1.5 Ab5:1.5 F5:1.5','Eb5:1.5 C5:1.5 Ab4:1.5',
'Db5:1.5 F5:1.5 Ab5:1.5','Gb5:1.5 F5:1.5 Eb5:1.5',
'F5:1.5 Ab5:1.5 Bb5:1.5','Ab5:1.5 F5:1.5 Db5:1.5',
'Eb5:1.5 Gb5:1.5 F5:1.5','Eb5:1.5 C5:1.5 Ab4:1.5',
'Db5:1.5 F5:1.5 Ab5:1.5','Bb5:1.5 Ab5:1.5 Gb5:1.5',
'F5:1.5 Eb5:1.5 Db5:1.5','C5:1.5 Eb5:1.5 F5:1.5']
V0_MIDDLE_H = 'Bbm7 Ab/C Bbm7 Gbmaj7 Db/F Gbmaj7 Ebm7 Ab7 Bbm7 Gbmaj7 Ebm7 F7'.split()
V1_CODA = [
'F5:1.5 Ab5:2 F5:1','Gb5:1.5 Bb5:2 Ab5:1',
'F5:1.5 Eb5:1.5 Db5:1.5','Eb5:1.5 Gb5:1.5 F5:1.5',
'Ab5:3 F5:1.5','Gb5:1.5 Eb5:1.5 C5:1.5',
'Db5:1.5 F5:1.5 Ab5:1.5','Db6:4.5']
V1_CODA_H = 'Dbmaj9 Gbmaj7 Db/F Ebm7 Db/Ab Ab7 Ab7 Dbmaj9'.split()


def build(version):
    melodies=list(MELODIES); harmonies=list(HARMONIES); tempos=list(TEMPOS)
    if version==0:
        melodies[24:36]=V0_MIDDLE; harmonies[24:36]=V0_MIDDLE_H
        tempos[24:36]=[86]*12
    if version<2:
        melodies[56:64]=V1_CODA; harmonies[56:64]=V1_CODA_H
        tempos[56:64]=[85,85,84,84,82,80,78,72]
    bars=[]; events=[]; pedals=[{'onset':0.0,'value':0}]
    def add(b,t,d,p,v,voice):
        events.append({'bar':b,'onset':round((b-1)*BEATS+t,4),
                       'duration':round(d,4),'pitch':p,'velocity':int(v),
                       'voice':voice,'instrument':'piano'})
    for b in range(1,65):
        start=(b-1)*BEATS; h=harmonies[b-1]; bass,pool,chord=H[h]
        pool=list(pool)
        # The root-bearing ending sits below middle C, away from the melodic landing.
        if version==2 and b>=61:
            if b==61: bass,pool=37,[44,49,53,56]
            if b==62: bass,pool=32,[39,44,49,51]
            if b==63: bass,pool=37,[44,49,54,58]
            if b==64: bass,pool=37,[44,49,53,58]
        bars.append({'bar':b,'start':start,'beats':BEATS,'bpm':tempos[b-1],
            'section':section(b),'meter_numerator':9,'meter_denominator':8,
            'harmony_name':h,'harmony':chord,
            'role_plan':'9/8复合拍3+3+3；右手长线旋律，稀疏内声；左手分解和声与句首低音同步，无独立低音对旋律。',
            'lead_instrument':'piano'})
        phrase_base = 72 if b<=8 else 77 if b<=24 else 75 if b<=36 else 85 if b<=48 else 78 if b<=56 else 72
        phrase_step=[-2,0,1,0,2,1,0,-3][(b-1)%8]
        t=0.0
        for j,(p,length) in enumerate(line(melodies[b-1])):
            if p is not None:
                # Maximum melody articulation gap .07 beat, except one explicit half-beat breath.
                gap=.04 if length>=1 else .035
                if b in (8,16,24,32,48,56):gap=.065
                vel=phrase_base+phrase_step + (2 if j==0 else -1) + (1 if p>=82 else 0)
                if version==2 and b>=63:vel=69 if b==63 else 66
                add(b,t,length-gap,p,vel,'melody')
                # Sustained harmonic color is subordinate, not parallel melody doubling.
                support_bars={3,7,10,14,17,20,22,27,29,33,37,38,41,42,43,45,46,49,51,53,57,60}
                if b in support_bars and j==0 and p>=73 and length>=1:
                    pcs={q%12 for q in chord}
                    choices=[q for q in range(p-10,p-3) if q>=64 and q%12 in pcs]
                    if choices:add(b,t,min(.92,length-.12),choices[-1],vel-19,'upper_support')
            t+=length
        leftbase=47 if b<=8 else 49 if b<=24 else 48 if b<=36 else 55 if b<=48 else 49 if b<=56 else 45
        leftbase+=[0,1,-1,1,0,-1,1,-2][(b-1)%8]
        bassdur=.78 if b<57 else .72
        add(b,0,bassdur,bass,leftbase+5,'bass')
        pat=PATTERNS[PATTERN_SEQUENCE[b-1]]
        if version==0 and 25<=b<=36:pat=PATTERNS[0]
        for k,idx in enumerate(pat,1):
            t=k*.5
            if version==2 and b==64 and t>=3:continue
            p=pool[idx]
            # Nine moving eighths, with a gentle compound-pulse touch at 1.5 and 3.
            vel=leftbase+([0,-3,1,-4,-2,0,-4,-2][k-1])
            dur=.465 if b not in (8,24,36,48,56) else .445
            # Release before a cross-bar relocation; pedal can carry the resonance.
            if k==8 and b<64:dur=.34
            add(b,t,dur,p,vel,'accompaniment')
        if version==2 and b==64:
            # Actual terminal root, not an identical key stacked over the ostinato.
            for p in (37,44,49):add(b,3,1.45,p,43 if p>37 else 48,'bass' if p==37 else 'accompaniment')
        # Full pedal means >=64 in Moonlight. 23–63 is intentionally partial only.
        partial = h in {'Ab7','F7','F7/A','Cdim7'} or 25<=b<=36
        value=55 if partial else 78
        pedals.append({'onset':round(start+.04,4),'value':value})
        pedals.append({'onset':round(start+4.42,4),'value':0})
    events.sort(key=lambda e:(e['onset'],e['pitch'],e['voice']))
    pedals.sort(key=lambda e:e['onset'])
    pedals.append({'onset':288.0,'value':0})
    return {'id':78,'title':'Lanterns in the Deep Orchard','title_zh':'深果园的提灯',
            'bars':bars,'events':events,'pedals':pedals,'total_beats':288.0,'tail_seconds':5}


def audit(score):
    ev=score['events']; errs=[]; max_spans={}; overlaps=[]
    for p,notes in sorted(_group(ev,lambda e:e['pitch']).items()):
        for a,b in zip(sorted(notes,key=lambda e:e['onset']),sorted(notes,key=lambda e:e['onset'])[1:]):
            if a['onset']+a['duration']>b['onset']+1e-8:overlaps.append([p,a['onset'],b['onset']])
    for hand,voices in {'left':{'bass','accompaniment'},'right':{'melody','upper_support'}}.items():
        notes=[e for e in ev if e['voice'] in voices]; worst={'span':0,'beat':0,'pitches':[]}
        for t in sorted({e['onset'] for e in notes}):
            pitches=[e['pitch'] for e in notes if e['onset']<=t+1e-8<e['onset']+e['duration']-1e-8]
            span=max(pitches)-min(pitches) if pitches else 0
            if span>worst['span']:worst={'span':span,'beat':t,'pitches':pitches}
        max_spans[hand]=worst
    event_seconds=sum(b['beats']*60/b['bpm'] for b in score['bars'])
    sorted_onsets=sorted({e['onset'] for e in ev})
    max_onset_gap=max(b-a for a,b in zip(sorted_onsets,sorted_onsets[1:]))
    timeline=sorted((e['onset'],e['onset']+e['duration']) for e in ev)
    cursor=0; holes=[]
    for start,end in timeline:
        if start>cursor+1e-7:holes.append({'start':round(cursor,4),'beats':round(start-cursor,4)})
        cursor=max(cursor,end)
    melodic=[e for e in ev if e['voice']=='melody']
    repeated_full=[]
    sigs={}
    for b in score['bars']:
        sig=tuple((round(e['onset']-b['start'],3),e['duration'],e['pitch'],e['voice']) for e in ev if e['bar']==b['bar'])
        if sig in sigs:repeated_full.append([sigs[sig],b['bar']])
        else:sigs[sig]=b['bar']
    if overlaps:errs.append('Identical-key overlap')
    if any(x['span']>12 for x in max_spans.values()):errs.append('Physical hand span over 12')
    if any(e['onset']<0 or e['duration']<=0 or e['onset']+e['duration']>288 for e in ev):errs.append('Invalid note bounds')
    if any(e['instrument']!='piano' for e in ev):errs.append('Non-piano event')
    return {'passed':not errs,'errors':errs,'bars':64,'meter':'9/8; 4.5 absolute quarter beats per bar',
       'tempo_unit':'quarter-note BPM','score_seconds':round(event_seconds,4),
       'seconds_including_5_second_tail':round(event_seconds+5,4),
       'note_count':len(ev),'voice_counts':dict(collections.Counter(e['voice'] for e in ev)),
       'pitch_range':[min(e['pitch'] for e in ev),max(e['pitch'] for e in ev)],
       'velocity_range':[min(e['velocity'] for e in ev),max(e['velocity'] for e in ev)],
       'identical_key_overlap_count':len(overlaps),'identical_key_overlaps':overlaps,
       'max_simultaneous_finger_span_semitones':max_spans,
       'max_inter_onset_gap_beats':max_onset_gap,
       'maximum_unpedaled_all_voice_rest_beats':max((x['beats'] for x in holes),default=0),
       'melody_events_at_least_1_45_beats':sum(e['duration']>=1.45 for e in melodic),
       'melody_note_count':len(melodic),
       'exact_repeated_whole_bar_note_signatures':repeated_full,
       'pedal_values':sorted({x['value'] for x in score['pedals']}),
       'pedal_interpretation':{'0':'off','55':'intentional partial (23–63)','78':'full (>=64)'},
       'limits':'Static composition audit only. Physical spans exclude pedal-held sympathetic resonance. No playback, audio rendering or listening audit was performed.'}

def _group(items,fn):
    groups=collections.defaultdict(list)
    for x in items:groups[fn(x)].append(x)
    return groups


def compact_lines(score):
    rows=[]
    for b in score['bars']:
        n=b['bar']; start=b['start']
        rows.append(f"BAR {n:02d} | {b['harmony_name']} | q={b['bpm']} | {b['section']}")
        for e in score['events']:
            if e['bar']==n:rows.append(f"  {e['voice']:13} t={e['onset']-start:4.2f} d={e['duration']:5.3f} key={e['pitch']:2d} vel={e['velocity']:2d}")
    return [x+'\n' for x in rows]


def main():
    scores=[]; audits={}
    for version in range(3):
        score=build(version); scores.append(score)
        text=json.dumps(score,ensure_ascii=False,indent=2)+'\n'
        (OUT/f'score_v{version}.json').write_text(text)
        audits[f'v{version}']=audit(score)
        assert audits[f'v{version}']['passed'], audits[f'v{version}']
        (OUT/f'score_v{version}_events.txt').write_text(''.join(compact_lines(score)))
    (OUT/'score.json').write_bytes((OUT/'score_v2.json').read_bytes())
    changes={}
    for a,b in [(0,1),(1,2)]:
        old=(OUT/f'score_v{a}.json').read_text().splitlines(True); new=(OUT/f'score_v{b}.json').read_text().splitlines(True)
        (OUT/f'exact_diff_v{a}_v{b}.patch').write_text(''.join(difflib.unified_diff(old,new,fromfile=f'score_v{a}.json',tofile=f'score_v{b}.json')))
        (OUT/f'musical_diff_v{a}_v{b}.patch').write_text(''.join(difflib.unified_diff(compact_lines(scores[a]),compact_lines(scores[b]),fromfile=f'v{a} events',tofile=f'v{b} events')))
        changed=[]
        for n in range(1,65):
            x=[e for e in scores[a]['events'] if e['bar']==n]; y=[e for e in scores[b]['events'] if e['bar']==n]
            if x!=y or scores[a]['bars'][n-1]!=scores[b]['bars'][n-1]:changed.append(n)
        changes[f'v{a}_to_v{b}']={'changed_bars':changed,'before_notes':len(scores[a]['events']),'after_notes':len(scores[b]['events'])}
    audits['rewrites']=changes
    audits['score_json_equals_v2']=(OUT/'score.json').read_bytes()==(OUT/'score_v2.json').read_bytes()
    audits['score_sha256']=hashlib.sha256((OUT/'score.json').read_bytes()).hexdigest()
    story=(OUT/'story_zh.txt').read_text()
    audits['story_nonwhitespace_characters']=len(''.join(story.split()))
    audits['story_han_characters']=sum('\u4e00'<=c<='\u9fff' for c in story)
    (OUT/'practical_audit.json').write_text(json.dumps(audits,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(audits,ensure_ascii=False,indent=2))

if __name__=='__main__':main()
