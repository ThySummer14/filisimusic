from copy import deepcopy

def pitch(s):
 return 12*(int(s[-1])+1)+{'C':0,'D':2,'E':4,'F':5,'G':7,'A':9,'B':11}[s[0]]+s[1:-1].count('#')-s[1:-1].count('b')
def decode(line):
 result=[];t=0
 for token in line.split():
  name,units=token.split(':');dur=float(units)/2
  if name!='R':result.append((pitch(name),t,dur))
  t+=dur
 return result,t
class Writer:
 def __init__(self):self.bars=[];self.events=[];self.pedals=[];self.start=0;self.n=0
 def bar(self,name,bpm,beats,h,ch):
  self.n+=1;self.beats=beats;self.bpm=bpm;self.ch=ch
  numerator,denominator=(int(beats*2),8) if beats in (2.5,3.5) else ((6,8) if METER=='6/8' else (int(beats),4))
  self.bars.append(dict(bar=self.n,start=self.start,beats=beats,bpm=bpm,meter_numerator=numerator,meter_denominator=denominator,section=name,harmony_name=h,harmony=ch))
 def add(self,p,t,d,v=72,inst='piano',voice='theme',hand='right',art='detached'):
  if d>0 and t<self.beats:
   self.events.append(dict(bar=self.n,onset=round(self.start+t,6),duration=round(min(d,self.beats-t),6),pitch=int(p),velocity=max(1,min(127,int(v))),instrument=inst,voice=voice,hand=hand if inst=='piano' else 'none',articulation=art))
 def line(self,line,v=80,hand='right',transpose=0):
  notes,total=decode(line);assert abs(total-self.beats)<1e-7,(self.n,total,self.beats,line)
  for p,t,d in notes:self.add(p+transpose,t,max(.11,d-.09),v+(3 if t==0 else 0),hand=hand)
  return notes
 def release(self,amount=0,length=.7):
  self.pedals.append(dict(bar=self.n,onset=self.start,controller=64,value=0,instrument='piano'))
  if amount:
   self.pedals.extend([dict(bar=self.n,onset=self.start+.05,controller=64,value=amount,instrument='piano'),dict(bar=self.n,onset=self.start+length,controller=64,value=0,instrument='piano')])
  self.start+=self.beats
 def result(self,level):
  self.pedals.append(dict(bar=self.n,onset=self.start-.01,controller=64,value=0,instrument='piano'))
  return dict(id=ID,title=TITLE,title_zh=TITLE_ZH,version=f'v{level}',bars=self.bars,events=self.events,pedals=self.pedals,total_beats=self.start,tail_seconds=5,instrument_map=INSTRUMENT_MAP)
def material(level):
 n=0
 for section,bpm,beats,texture,hs,phrase_names in BLOCKS:
  lines=[]
  for pn in phrase_names.split():lines+=P[pn].split('|')
  harmonies=hs.split();assert len(lines)==len(harmonies),(section,len(lines),len(harmonies))
  for h,line in zip(harmonies,lines):
   n+=1
   for lv,rev in [(1,REV1),(2,REV2)]:
    if level>=lv and n in rev:h,line=rev[n]
   yield n,section,bpm,beats,texture,h,line
ID=135;TITLE='Stones Before the Tide';TITLE_ZH='涨潮前的石阶';METER='7/8';INSTRUMENT_MAP={'piano':'piano','clarinet':'clarinet','cello':'arco'}
RENDERER_NOTES='Main 7/8 grouped 2+2+3 eighths; bars33–48 and73–80 4/4. Cello short-bow only, D3–B3; clarinet C4–B4. Three instruments alternate foreground, not a continuous stacked trio.'
H={'Dm':[38,53,57],'Bb':[46,53,62],'C':[36,52,55],'A7':[45,55,61],'F':[41,57,60],'Gm':[43,58,62],'Dm/A':[45,53,62],'Eb':[39,55,58],'D':[38,54,57],'G':[43,55,59],'Em':[40,55,59],'Dadd9':[38,52,57],'Asus':[45,55,62],'Gm6':[43,52,58]}
CEL={'Dm':[50,53],'Bb':[58,53],'C':[52,55],'A7':[57,55],'F':[53,57],'Gm':[55,58],'Dm/A':[57,53],'Eb':[51,55],'D':[50,54],'G':[55,59],'Em':[52,55],'Dadd9':[50,54],'Asus':[57,55],'Gm6':[55,58]}
P={
'edge':'D5:1 A5:1 F5:1 E5:1 D5:1 F5:2|F5:1 Bb5:1 A5:1 F5:1 D5:1 C5:2|E5:1 G5:1 C6:1 B5:1 G5:1 E5:2|C#5:2 R:5',
'step':'D5:2 F5:1 A5:1 G5:1 F5:2|D5:1 F5:1 Bb5:2 A5:1 F5:2|E5:1 G5:1 C6:2 B5:1 G5:2|A5:2 G5:1 E5:1 C#5:1 R:2',
'look':'A5:1 F5:1 D5:1 C5:1 A4:1 D5:2|Bb4:1 D5:1 G5:2 F5:1 D5:2|C#5:1 E5:1 A5:2 G5:1 E5:2|F5:2 D5:1 A4:1 F4:1 R:2',
'spray':'A5:1 D6:1 F6:1 E6:1 D6:1 A5:2|Bb5:1 F6:1 D6:1 Bb5:1 A5:1 F5:2|G5:1 C6:1 E6:1 D6:1 C6:1 G5:2|A5:1 C#6:1 E6:1 D6:1 C#6:1 A5:2',
'island':'F5:2 A5:1 C6:1 A5:2 F5:2|G5:2 E5:1 C5:1 E5:2 G5:2|F5:2 D5:1 Bb4:1 D5:2 F5:2|E5:2 C#5:1 A4:1 G4:2 R:2',
'island2':'A5:2 F5:1 C5:1 F5:2 A5:2|Bb5:1 G5:1 D5:2 F5:1 G5:1 Bb5:2|C6:2 G5:1 E5:1 D5:2 C5:2|C#5:2 E5:1 A5:1 G5:2 R:2',
'return':'F5:1 A5:1 D6:2 C6:1 A5:2|Bb5:1 A5:1 F5:1 D5:1 C5:1 Bb4:2|G5:1 E5:1 C5:2 D5:1 E5:2|C#5:1 A4:1 E4:1 G4:1 A4:1 C#5:2',
'higher':'D6:1 A5:1 F5:1 A5:1 D6:1 F6:2|Eb6:1 Bb5:1 G5:1 Bb5:1 Eb6:1 D6:2|C6:1 G5:1 E5:1 G5:1 C6:1 E6:2|C#6:1 A5:1 G5:1 E5:1 C#5:1 R:2',
'listen':'R:2 A4:2 D5:2 R:2|R:4 F5:2 Bb5:2|G5:2 E5:2 R:4|C#5:2 E5:2 R:4',
'path':'D5:1 F5:1 A5:1 C6:1 A5:1 F5:2|G5:1 Bb5:1 D6:2 C6:1 Bb5:2|E5:1 G5:1 C6:1 E6:1 D6:1 C6:2|A5:1 G5:1 E5:1 C#5:1 A4:1 R:2',
'sun':'D5:1 F#5:1 A5:1 B5:1 A5:1 F#5:2|G5:1 B5:1 D6:1 E6:1 D6:1 B5:2|E5:1 G5:1 B5:1 A5:1 G5:1 E5:2|C#5:1 E5:1 A5:1 G5:1 E5:1 C#5:2',
'last':'D6:2 A5:1 F#5:1 E5:1 D5:2|B5:2 G5:1 D5:1 B4:1 G4:2|A5:1 G5:1 E5:2 C#5:1 A4:2|D5:1 A4:1 F#4:1 E4:1 D4:1 R:2'
}
BLOCKS=[
('Already_at_water',128,3.5,'edge','Dm Bb C A7 Dm Bb C A7','edge step'),
('Unequal_stones',108,3.5,'steps','Dm Bb C A7 Dm Gm A7 Dm','step look'),
('Salt_on_sleeve',114,3.5,'spray','Dm Bb C A7 Dm Bb C A7','spray spray'),
('Look_back',104,3.5,'wind','Dm Gm A7 Dm Dm Gm A7 Dm','look look'),
('Wide_rock',92,4,'island','F C Bb A7 F Gm C A7','island island2'),
('Pool_inside_rock',98,4,'bow','F C Bb A7 F Gm C A7','island island2'),
('Route_has_changed',118,3.5,'return','Dm Bb C A7 Dm Bb C A7','return return'),
('Water_below',124,3.5,'higher','Dm Eb C A7 Dm Eb C A7','higher higher'),
('Count_the_steps',112,3.5,'steps','Dm Gm C A7 Dm Gm C A7','path path'),
('Listen_once',86,4,'listen','Dm Bb C A7 Dm Bb C A7','listen listen'),
('Move_while_clear',126,3.5,'drive','Dm Bb C A7 Dm Gm C A7','spray path'),
('Reach_dry_ground',118,3.5,'sun','D G Em A7 D G Em A7','sun sun'),
('Turn_toward_sea',106,3.5,'last','D G Em A7 D G A7 Dadd9','sun last')]
REV1={49:('Dm/A','A5:1 F5:1 D5:1 A4:1 D5:1 F5:2'),50:('Gm6','Bb5:1 G5:1 E5:1 D5:1 Bb4:1 G4:2'),51:('C','G5:1 C6:1 E6:1 D6:1 C6:1 G5:2'),52:('Asus','A5:1 D6:1 C6:1 A5:1 G5:1 E5:2'),53:('Dm','F5:2 A5:1 D6:1 C6:1 A5:2'),54:('Eb','G5:1 Bb5:1 Eb6:2 D6:1 Bb5:2'),55:('Gm','D6:1 Bb5:1 G5:1 F5:1 D5:1 Bb4:2'),56:('A7','C#5:1 E5:1 A5:1 G5:1 E5:1 R:2')}
REV2={89:('D','F#5:1 A5:1 D6:2 C#6:1 A5:2'),90:('G','B5:1 A5:1 G5:1 D5:1 B4:1 G4:2'),91:('Em','G5:1 B5:1 E6:1 D6:1 B5:1 G5:2'),92:('A7','A5:2 G5:1 E5:1 C#5:1 R:2'),93:('Dadd9','F#5:1 E5:1 D5:1 A4:1 D5:1 E5:2'),94:('G','G5:1 B5:1 D6:2 B5:1 G5:2'),95:('Asus','A5:1 D6:1 C6:1 A5:1 G5:1 E5:2'),96:('A7','C#5:1 E5:1 G5:1 A5:1 G5:1 R:2')}
def build(level):
 w=Writer()
 for n,section,bpm,beats,style,h,line in material(level):
  ch=H[h];w.bar(section,bpm,beats,h,ch);v={'edge':98,'steps':78,'spray':96,'wind':67,'island':62,'bow':70,'return':88,'higher':102,'listen':48,'drive':104,'sun':91,'last':86}[style];notes,total=decode(line)
  if style=='wind':
   for q,t in zip([notes[0][0],notes[-1][0]],[.2,2.1]):w.add(60+q%12,t,.95,69,inst='clarinet',voice='survey_the_water')
   w.add(ch[1]+12,1.3,.45,54,voice='foot_on_stone',hand='right')
  elif style=='bow':
   for q,t in zip(CEL[h],[.25,2.25]):w.add(q,t,.88,65,inst='cello',voice='pool_reflection',art='short_bow')
   for j,t in enumerate([0,1.5,3]):w.add(ch[(j%2)+1]+12,t,.6,57,voice='piano_reflection',hand='right')
  else:w.line(line,v)
  if style in ('steps','edge','spray','return','higher','drive','sun','last'):
   ts=[0,1,2] if style not in ('steps','last') else [0,2]
   if level>=1 and 49<=n<=56:ts=[.5,1.5,2.75]
   if level>=2 and 89<=n<=96:ts=[0,1.75]
   for j,t in enumerate(ts):w.add(ch[0] if j%2==0 else ch[1],t,.28,v-24,voice='two_two_three_step',hand='left')
  elif style in ('wind','island','bow'):
   w.add(ch[0],0,.55,49,voice='rock_underfoot',hand='left')
   if style=='island':w.add(ch[1],2.5,.65,45,voice='still_pool',hand='left')
  if style in ('spray','drive') and n%4==0:w.add(CEL[h][0],.3,.86,77,inst='cello',voice='wave_impact',art='short_bow')
  if style in ('return','higher') and n%4==2:
   for q,t in zip([ch[2],ch[1]],[.2,2.1]):w.add(60+q%12,t,.95,79,inst='clarinet',voice='route_signal')
  if style=='listen' and n%4==1:w.add(CEL[h][0],.3,.82,42,inst='cello',voice='far_wave',art='short_bow')
  if level>=2 and 89<=n<=96:
   if n%2:
    for q,t in zip([ch[2],ch[1]],[.2,2.1]):w.add(60+q%12,t,.92,73,inst='clarinet',voice='dry_ground_call')
   else:w.add(CEL[h][1],1.25,.88,70,inst='cello',voice='ground_reply',art='short_bow')
  w.release(35 if style in ('island','bow') else 0,1.1)
 return w.result(level)
