66《遗忘姓名的列车》｜非音频稿交付

建议集成：score_v2.json。
位置：本目录066_forgotten_names_draft。
72小节，钢琴主导+拨弦大提琴的小型摇摆二重奏；含尾音约2:59.35。

文件
- story_zh.txt：完整原创中文故事；春宁选择新名字，列车长承担放行责任。
- score_v0.json / score_v1.json / score_v2.json：两次实质修改的三个完整阶段。
- score.json：与v2完全相同的便捷副本。
- compose.py：可复现生成与审计；Python标准库，无外部依赖或随机种子。
- verify_score.py：独立读回审计，不导入生成脚本。
- composition_notes_zh.txt：主题、和声、段落、角色与集成限制。
- thematic_material.json / form_design.json：最终主题实例与完整和声/曲式信息。
- revision_log.md / revision_changes.json：两次实质修改的理由及事件差异。
- AUDIT.txt / audit_v0.json / audit_v1.json / audit_v2.json：技术审核。
- validation_readback.json / reproducibility_check.json：独立读回与重复运行验证。
- build_manifest.json：最终选择及SHA-256。

集成要点
只使用现有钢琴与单mf层拨弦大提琴。大提琴MIDI36–47，velocity只是幅度，
无长弓、无额外层。按实际onset保留2:1摇摆，不要量化回均匀八分音符。
melody/upper_support属于钢琴右手，bass/accompaniment属于钢琴左手。
cellobass不可移到钢琴。pedals只进钢琴轨，最高45/127。
大提琴最低声部已承担低音功能；请勿另加钢琴低音倍增。
final bar72保持原有慢速收束与4秒尾音。

还未完成的事项
没有实际音频制作或试听。父任务负责REAPER集成、真实音源核对、
声部平衡、尾音与音乐效果听审、最终发布。
