"""Original acoustic trio: paired5/8+7/8 gestures become a shared12/8 span."""
import pathlib, json, copy
P = pathlib.Path(__file__).parent
(P / 'revisions').mkdir(exist_ok=True)
A = [[(72, 0.5), (75, 0.5), (79, 0.5), (80, 0.5), (79, 0.5), (77, 0.5), (75, 1), (74, 0.5), (72, 0.5), (74, 0.5), (75, 0.5)], [(80, 1), (79, 0.5), (77, 0.5), (75, 1), (72, 0.5), (75, 0.5), (77, 0.5), (79, 0.5), (80, 0.5), (-1, 0.5)], [(77, 0.5), (80, 0.5), (85, 1), (84, 0.5), (80, 0.5), (77, 1), (73, 1), (75, 0.5), (77, 0.5)], [(83, 0.5), (81, 0.5), (79, 0.5), (77, 0.5), (74, 1), (71, 1), (74, 0.5), (77, 0.5), (79, 0.5), (-1, 0.5)], [(79, 1), (75, 0.5), (72, 0.5), (67, 1), (72, 0.5), (75, 0.5), (79, 1), (77, 0.5), (75, 0.5)], [(79, 0.5), (82, 0.5), (87, 1), (86, 0.5), (82, 0.5), (79, 1), (75, 1), (77, 0.5), (79, 0.5)], [(77, 0.5), (80, 0.5), (84, 1), (82, 1), (80, 0.5), (77, 0.5), (75, 1), (72, 0.5), (-1, 0.5)], [(74, 0.5), (77, 0.5), (79, 1), (83, 0.5), (81, 0.5), (79, 1), (77, 1), (74, 0.5), (-1, 0.5)]]
W = [[(67, 1), (63, 0.5), (60, 0.5), (62, 1), (63, 1), (67, 1), (65, 0.5), (-1, 0.5)], [(70, 1), (67, 1), (63, 0.5), (65, 0.5), (67, 1), (70, 1), (68, 0.5), (-1, 0.5)], [(68, 1), (65, 0.5), (63, 0.5), (60, 1), (63, 1), (65, 1), (67, 0.5), (-1, 0.5)], [(71, 1), (69, 0.5), (67, 0.5), (65, 1), (62, 1), (65, 0.5), (67, 0.5), (71, 0.5), (-1, 0.5)], [(67, 0.5), (68, 0.5), (70, 1), (67, 1), (63, 1), (60, 1), (62, 0.5), (-1, 0.5)], [(68, 1), (67, 0.5), (65, 0.5), (63, 1), (60, 1), (63, 0.5), (65, 0.5), (68, 0.5), (-1, 0.5)], [(65, 0.5), (68, 0.5), (61, 1), (65, 1), (68, 1), (70, 1), (68, 0.5), (-1, 0.5)], [(67, 1), (65, 0.5), (62, 0.5), (71, 1), (69, 0.5), (67, 0.5), (65, 1), (62, 0.5), (-1, 0.5)]]
B = [[(63, 0.5), (67, 0.5), (68, 1), (67, 1), (63, 1), (62, 0.5), (60, 0.5), (63, 1)], [(68, 1.5), (67, 0.5), (65, 1), (63, 1), (60, 1), (63, 0.5), (-1, 0.5)], [(65, 1), (68, 0.5), (70, 0.5), (68, 1), (65, 1), (61, 1), (65, 0.5), (-1, 0.5)], [(67, 1), (71, 1), (69, 0.5), (67, 0.5), (65, 1), (62, 1), (65, 0.5), (-1, 0.5)], [(67, 1.5), (65, 0.5), (63, 1), (60, 1), (63, 0.5), (67, 0.5), (70, 1)], [(70, 1), (67, 1), (63, 0.5), (65, 0.5), (67, 1), (70, 0.5), (68, 0.5), (67, 1)], [(68, 0.5), (67, 0.5), (65, 1), (63, 0.5), (60, 0.5), (65, 1), (68, 1), (67, 0.5), (-1, 0.5)], [(71, 0.5), (69, 0.5), (67, 1), (65, 1), (62, 1), (65, 1), (67, 0.5), (-1, 0.5)]]
Q = [[(80, 1), (79, 0.5), (77, 0.5), (75, 1), (72, 1), (75, 1), (77, 0.5), (-1, 0.5)], [(77, 1), (80, 0.5), (84, 0.5), (82, 1), (80, 1), (77, 1), (75, 0.5), (-1, 0.5)], [(77, 0.5), (80, 0.5), (85, 1), (84, 1), (80, 1), (77, 1), (73, 0.5), (-1, 0.5)], [(83, 1), (79, 1), (77, 0.5), (74, 0.5), (71, 1), (74, 1), (77, 0.5), (-1, 0.5)], [(79, 0.5), (77, 0.5), (75, 1), (72, 1), (67, 1), (72, 1), (75, 0.5), (-1, 0.5)], [(77, 1), (75, 0.5), (72, 0.5), (68, 1), (72, 1), (77, 1), (80, 0.5), (-1, 0.5)], [(79, 1), (77, 0.5), (74, 0.5), (71, 1), (74, 1), (77, 1), (71, 0.5), (-1, 0.5)], [(74, 0.5), (72, 0.5), (67, 1), (72, 3), (-1, 1)]]
T = [[(77, 0.5), (80, 0.5), (84, 1), (80, 1), (77, 1), (75, 0.5), (72, 0.5), (77, 1)], [(74, 0.5), (77, 0.5), (83, 1), (81, 0.5), (79, 0.5), (77, 1), (74, 1), (71, 0.5), (-1, 0.5)]]
H = {'Cm': (36, 43, [48, 51, 55]), 'Ab': (44, 39, [48, 51, 56]), 'Db': (37, 44, [49, 53, 56]), 'G7': (43, 38, [53, 55, 59]), 'CmG': (43, 36, [48, 51, 55]), 'Eb': (39, 46, [51, 55, 58]), 'Fm': (41, 36, [48, 53, 56])}
east = ['Cm', 'Ab', 'Db', 'G7', 'CmG', 'Eb', 'Fm', 'G7']
west = ['Cm', 'Eb', 'Fm', 'G7', 'Cm', 'Ab', 'Db', 'G7']
coda = ['Ab', 'Fm', 'Db', 'G7', 'CmG', 'Fm', 'G7', 'Cm']
sections = [('Lights on opposite cliffs', 3, 132, 'intro', 'mixed'), ('Five planks from the east', 10, 132, 'east', 'mixed'), ('Seven steps from the west', 10, 132, 'west', 'mixed'), ('The seam breaks over water', 8, 112, 'gap', 'mixed'), ('One span holds both rhythms', 16, 126, 'bridge', 'compound'), ('Each shadow finds its door', 10, 132, 'owners', 'reverse'), ('Breakfast across the river', 8, 110, 'coda', 'compound')]
notes = []
bars = []
pedals = []
beat = 0
barno = 0
cellno = 0
for sec, count, tempo, kind, meterkind in sections:
    for j in range(count):
        cellno += 1
        k = j % 8
        bpm = tempo
        if kind == 'intro':
            idx = [0, 2, 3][j]
            line = copy.deepcopy(A[idx])
            h = ['Cm', 'Db', 'G7'][j]
            lead = 'piano'
            lv = 70 + j * 4
        elif kind == 'east':
            line = copy.deepcopy(A[k] if j < 8 else T[j - 8])
            h = east[k] if j < 8 else ['Fm', 'G7'][j - 8]
            lead = 'piano'
            lv = 88
        elif kind == 'west':
            line = copy.deepcopy(W[k] if j < 8 else W[j - 8])
            h = west[k] if j < 8 else ['Cm', 'G7'][j - 8]
            lead = 'clarinet'
            lv = 76
        elif kind == 'gap':
            line = copy.deepcopy(W[k])
            h = west[k]
            lead = 'clarinet' if j < 4 else 'piano'
            lv = 68 if lead == 'clarinet' else 78
            line = [(n + 12 if n >= 0 and lead == 'piano' else n, l) for n, l in line]
        elif kind == 'bridge':
            line = copy.deepcopy(B[k] if j < 8 else A[k])
            h = east[k]
            lead = 'clarinet' if j < 8 else 'piano'
            lv = 84 if lead == 'clarinet' else 96
        elif kind == 'owners':
            line = copy.deepcopy(A[k] if j < 8 else T[j - 8])
            h = east[k] if j < 8 else ['Fm', 'G7'][j - 8]
            lead = 'piano'
            lv = 90
        else:
            line = copy.deepcopy(Q[j])
            h = coda[j]
            lead = 'piano'
            lv = 76 - j
            bPM = [110, 110, 108, 108, 104, 100, 92, 84]
            bpm = bPM[j]
        assert abs(sum((l for n, l in line)) - 6) < 1e-08, (kind, j)
        root, fifth, ch = H[h]
        cell_start = beat
        cell_bars = []
        meters = [(12, 8, 6)] if meterkind == 'compound' else [(5, 8, 2.5), (7, 8, 3.5)] if meterkind == 'mixed' else [(7, 8, 3.5), (5, 8, 2.5)]
        for num, den, beats in meters:
            barno += 1
            b = dict(bar=barno, start=beat, beats=beats, bpm=bpm, meter_numerator=num, meter_denominator=den, section=sec, harmony_name=h, harmony=ch, cello_root=root, cello_fifth=fifth, role_plan=kind, lead_instrument=lead, cell=cellno, grouping='3+2' if num == 5 else '2+2+3' if num == 7 else '3+3+3+3')
            bars.append(b)
            cell_bars.append(b)
            beat += beats
            times = [0, 3] if num == 12 else [0, 1.5] if num == 5 else [0, 1, 2]
            for n, t in enumerate(times):
                dur = min(0.85, times[n + 1] - t - 0.08 if n + 1 < len(times) else beats - t - 0.12)
                notes.append(dict(bar=barno, onset=b['start'] + t, duration=dur, pitch=root if n % 2 == 0 else fifth, velocity=53 + (6 if kind in ('east', 'owners', 'bridge') else 0) - (3 if n else 0), voice='cello_bass', instrument='cello'))
            pv = 43 if lead == 'piano' else 31
            pts = [0.5, 2, 3.5, 5] if num == 12 else [0.5, 1.75] if num == 5 else [0.5, 1.5, 2.75]
            for t in pts:
                for pitch in ch:
                    notes.append(dict(bar=barno, onset=b['start'] + t, duration=0.28 if lead == 'piano' else 0.45, pitch=pitch, velocity=pv - (3 if t > 1 else 0), voice='accompaniment', instrument='piano'))
            for t, v in [(0, 0), (0.1, 37 if lead == 'piano' else 48), (beats - 0.08, 0)]:
                pedals.append(dict(onset=b['start'] + t, value=v))
        off = 0
        for pitch, dur in line:
            b = next((x for x in reversed(cell_bars) if cell_start + off >= x['start']), cell_bars[0])
            if pitch >= 0:
                if lead == 'clarinet':
                    assert 60 <= pitch <= 71
                notes.append(dict(bar=b['bar'], onset=cell_start + off, duration=dur * (0.93 if lead == 'clarinet' else 0.965), pitch=pitch, velocity=lv + (2 if off == 0 else 0), voice='melody', instrument=lead))
            off += dur
        if lead == 'clarinet' and line[-1][0] < 0:
            t = 6 - line[-1][1]
            b = cell_bars[-1]
            for off, pitch in [(t, ch[1] + 12), (t + 0.25, ch[2] + 12)]:
                notes.append(dict(bar=b['bar'], onset=cell_start + off, duration=0.2, pitch=pitch, velocity=47, voice='reply', instrument='piano'))
        if kind == 'coda' and j == 7:
            notes.append(dict(bar=barno, onset=cell_start + 2, duration=1.2, pitch=60, velocity=63, voice='cadence', instrument='clarinet'))
pedals = [e for e in pedals if e['onset'] < beat - 6] + [dict(onset=beat - 6, value=0), dict(onset=beat - 5.9, value=52), dict(onset=beat + 2, value=0)]
d = dict(id=59, title='A Bridge for Migrating Shadows', title_zh='给迁徙的影子架桥', stage='v0_original_mixed_meter_trio', bars=bars, events=notes, pedals=pedals, total_beats=beat, tail_seconds=4.5, story_relationship='Two lengths form a single melodic cell. Piano and clarinet alternate leading the same harmonic route, while natural pizzicato cello holds the landings.12/8unifies the pulse before a7+5return and a decisive C-minor ending.', instrument_limits='ClarinetC4–B4 genuine recordedmf/fforppwhere selected; no real legato. CelloC2–B2 single recordedmf pizzicato; velocity only changes gain, documented pitch tuning.')
(P / 'revisions/ensemble_v0.json').write_text(json.dumps(d, indent=2))
(P / 'ensemble_score.json').write_text(json.dumps(d, indent=2))
(P / 'thematic_material.json').write_text(json.dumps(dict(A=A, W=W, B=B, Q=Q, T=T), indent=2))
print(len(bars), 'bars', sum((b['beats'] * 60 / b['bpm'] for b in bars)) + 4.5, 'seconds', len(notes), 'notes')
