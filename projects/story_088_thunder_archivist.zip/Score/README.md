# 088 — The Archivist of Thunder / 雷声保管员

Complete symbolic composition package. Selected version: v2.

72 bars, 4/4, mainly G minor, contrasting B-flat-major region. Natural acoustic piano leads, with University of Iowa short separate arco cello answers using genuine pp/mf layers. Duration: 3:27.325 including a 6-second tail.

## Main files

- score.json — selected score, byte-identical to score_v2.json
- score_v0.json / score_v1.json / score_v2.json — complete compositional versions
- generate_score.py — deterministic Python standard-library score generator
- verify_symbolic.py — separate verifier that reads disk files without importing the generator
- audit_v0.json / audit_v1.json / audit_v2.json — generator-side checks
- independent_verification.json — separate checks for all versions and exact revision reconstruction
- exact_diff_v0_to_v1.json / exact_diff_v1_to_v2.json — complete before/after change bodies
- corresponding .patch files — exact unified text diffs
- story_zh.txt — original Chinese story
- music_notes_zh.md — form, story relationship, source/playability limits and final metrics
- revision_notes.md — two substantive compositional revisions in Chinese
- reproducibility_check.json — unchanged generated outputs after a second generation run
- hash_manifest.json — SHA-256 and byte count for every other regular file in this folder

## Reproduce

Run python generate_score.py, then python verify_symbolic.py. Both require only the Python standard library. The generator writes only into this folder. The verifier writes independent_verification.json. The delivery hash manifest is frozen after all deliverable files have been finalized.

Event onset/duration and bar start/beats are absolute quarter-note beats. Every event identifies its instrument, voice, hand and phrase; all piano events include explicit finger/position information; all cello events identify the actual selected recorded layer and original sampled pitch. Pedal events belong only to piano.

All three versions pass. The two revisions change 12 and 16 musical bars respectively. v2 has 700 notes, including 77 cello notes. Strict travel checking covers 129 left-hand and 77 right-hand transfers. Maximum held hand spans are LH 11 semitones and RH 0. No same-key overlap, crossing or finger collision. Final cello pitch range 50–58 stays inside the authorized source coverage 50–59; recorded layer counts are mf 59 and pp 18. Cello gates are 0.472174–0.790000 seconds; shortest inter-bow gate gap is 0.180000 seconds.

This folder contains no audio, rendered MIDI, source samples, downloads or installations. No audio was heard or assessed. Recorded onset/release, real sound quality, balance and pedal response remain integration checks for the parent task. Files outside this draft directory were not changed.
