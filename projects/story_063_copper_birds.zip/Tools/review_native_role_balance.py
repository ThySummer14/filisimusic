"""Compare actual native solo-bus PCM energy by written lead role; no listening verdict."""
from pathlib import Path
import argparse,json,wave,numpy as np
p=argparse.ArgumentParser();p.add_argument('score');p.add_argument('--bus',action='append',required=True,help='instrument=PCM WAV');p.add_argument('--out',required=True);p.add_argument('--support',default='piano');a=p.parse_args();s=json.loads(Path(a.score).read_text());files={k:wave.open(v,'rb') for k,v in (x.split('=',1) for x in a.bus)};rows=[];time=0
for b in s['bars']:
 end=time+b['beats']*60/b['bpm'];levels={}
 for key,w in files.items():
  sr=w.getframerate();start=min(round(time*sr),w.getnframes());w.setpos(start);raw=w.readframes(min(round(end*sr),w.getnframes())-start);assert w.getsampwidth()==3
  q=np.frombuffer(raw,dtype=np.uint8).reshape(-1,3);v=q[:,0].astype(np.int32)|(q[:,1].astype(np.int32)<<8)|(q[:,2].astype(np.int32)<<16);v=np.where(v&0x800000,v-0x1000000,v).astype(float)/8388608
  levels[key]=float(20*np.log10(max(np.sqrt(np.mean(v*v)),1e-12)))
 rows.append(dict(bar=b['bar'],section=b['section'],lead=b.get('lead_instrument'),bus_rms_dbfs=levels));time=end
for w in files.values():w.close()
r={'method':'Actual REAPER isolated-bus PCM through native pan/width/panlaw and master processing. Energy is not perceived loudness, musical quality or human listening.','bars':rows}
Path(a.out).write_text(json.dumps(r,ensure_ascii=False,indent=2));print(json.dumps({'clarinet_lead_median_difference_db':float(np.median([x['bus_rms_dbfs']['clarinet']-x['bus_rms_dbfs'][a.support] for x in rows if x['lead']=='clarinet']))},indent=2))
