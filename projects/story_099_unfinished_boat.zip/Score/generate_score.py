"""Work099: new piano/cello barcarolle data and shared score-construction utilities. No audio."""
from pathlib import Path
import argparse, difflib, hashlib, json
from composition_data import LINES,HARM_ROWS,H,WIND,V1,V1_H,V2,V2_H,LABELS,SECTIONS,section,bpm
ROOT=Path(__file__).resolve().parent
PC={'C':0,'D':2,'E':4,'F':5,'G':7,'A':9,'B':11}
def midi(s):return 12*(int(s[-1])+1)+PC[s[0]]+s[1:-1].count('#')-s[1:-1].count('b')
def seconds(bars,t):return sum(min(max(t-b['start'],0),b['beats'])*60/b['bpm'] for b in bars)
def fingermap(keys,hand):
 fs={1:[3],2:[1,5],3:[1,3,5],4:[1,2,4,5],5:[1,2,3,4,5]}[len(keys)]
 if len(keys)==4:
  widest=max(range(3),key=lambda i:keys[i+1]-keys[i]);fs=([1,3,4,5],[1,2,4,5],[1,2,3,5])[widest]
 return dict(zip(keys,fs if hand=='right' else [6-f for f in fs]))
def build(version):
 level=int(version[1:]);lines=[s.strip() for row in LINES for s in row.split('|')];harm=[s for row in HARM_ROWS for s in row.split()];assert len(lines)==len(harm)==80
 for lv,changes,chords in [(1,V1,V1_H),(2,V2,V2_H)]:
  if level>=lv:
   for n,x in changes.items():lines[n-1]=x
   for n,x in chords.items():harm[n-1]=x
 bars=[];events=[];plans=[];pedals=[]
 for n in range(1,81):
  start=(n-1)*3.;_,_,sect,title,key=section(n);wind=n in WIND;inst='cello' if wind else 'piano';pid=f'P{(n-1)//4+1:02d}_{inst}';h=harm[n-1];ch=H[h]
  texture='rocking_two_dotted_quarters'
  if wind:texture='cello_line_over_quiet_shell'
  if level>=1 and 25<=n<=40:texture='major_section_inner_reply'
  if level>=2 and 49<=n<=64:texture='changed_return_spacing'
  if n>=65:texture='final_packing_cadence'
  b={'bar':n,'start':start,'beats':3.,'bpm':bpm(n),'meter':'6/8','meter_numerator':6,'meter_denominator':8,'section':sect,'section_title_zh':title,'key_region':key,'harmony_name':h,'harmony':ch,'lead_instrument':inst,'lead_hand':None if wind else 'right','phrase_id':f'P{(n-1)//4+1:02d}','phrase_position':(n-1)%4+1,'texture':texture,'metrical_grouping':'3+3 eighth notes','role_plan':'One foreground at a time; cello bow phrases and piano melody share the same chord-bound support.'};bars.append(b)
  def add(p,at,dur,vel,instrument,voice,hand,role,written):
   e={'bar':n,'onset':round(start+at,6),'duration':round(dur,6),'pitch':p,'velocity':vel,'instrument':instrument,'voice':voice,'hand':hand,'role':role,'phrase_id':pid if role=='lead' else f'P{(n-1)//4+1:02d}_piano','phrase_label':LABELS[(n-1)//8],'harmony_name':h,'harmonic_function':'chord_tone' if p%12 in {k%12 for k in ch} else 'melodic_nonchord_tone','written_value_beats':written};events.append(e);return e
  ps=[midi(s) for s in lines[n-1].split()]
  energy=66 if n<=24 else 72 if n<=40 else 69 if n<=48 else 77 if n<=64 else 61
  if wind:
   assert len(ps)==2
   layer='pp' if n<=12 or n>=69 else 'mf';velocity=(48 if layer=='pp' else 78)+(n%3)-1
   for i,pitch in enumerate(ps):
    at=.15 if i==0 else 1.65;dur=.95
    e=add(pitch,at,dur,velocity+(1 if i==0 else -1),'cello','breathing_melody','not_applicable','lead',dur);e.update(layer=layer,sample_layer=layer,articulation='separate_short_recorded_cello_bows',onset_reference='ordinary_trigger',nominal_gate_seconds=dur*60/bpm(n),timing_correction_applied_seconds=0.,source_pitch_midi=pitch)
  else:
   ds={3:[1,1,1],4:[.5,1,.5,1],5:[.5,.5,.5,.5,1],6:[.5]*6}[len(ps)]
   if level>=2 and n in V2 and len(ps)==4:ds=[1,.5,1,.5]
   at=0
   for i,(pitch,w) in enumerate(zip(ps,ds)):
    gap=.12 if i<len(ps)-1 else .26;e=add(pitch,at,w-gap,energy+[1,-2,2,0,-1][i%5],'piano','melody','right','lead',w);e['articulation']='light_connected_piano_phrase';at+=w
  quiet=(34 if wind else energy-24);shell=[ch[0],ch[-1]];inner=ch[1:-1] or [ch[1]]
  gestures=[(0,1.05,shell),(1.5,.82,inner)] if wind else [(0,.90,shell),(1.5,.90,ch)]
  if level>=1 and 25<=n<=40:gestures=[(0,.70,[ch[0]]),(.9,.4,inner),(1.5,.7,shell),(2.4,.3,inner)]
  if level>=2 and 49<=n<=64:gestures=[(0,.80,shell),(1.65,.70,ch)]
  if n>=65:gestures=[(0,1.05,shell),(1.5,.80,inner)]
  if n==80:gestures=[(0,3.,ch)]
  for at,dur,keys in gestures:
   for pitch in keys:
    e=add(pitch,at,dur,quiet,'piano','harmonic_support','left','support',min(dur+.1,3.-at));e['articulation']='light_shared_harmony'
  for hand in ['left','right']:
   ns=[e for e in events if e['bar']==n and e['hand']==hand];keys=sorted({e['pitch'] for e in ns});pos={'bar':n,'hand':hand,'position_id':f'b{n:03d}_{hand}','active':bool(keys),'range':[keys[0],keys[-1]] if keys else None,'pitch_finger_map':{}}
   if keys:
    assert len(keys)<=5 and keys[-1]-keys[0]<=12,(version,n,hand,keys);fm=fingermap(keys,hand);pos['pitch_finger_map']={str(k):v for k,v in fm.items()}
    for e in ns:e.update(finger=fm[e['pitch']],hand_position_id=pos['position_id'],hand_position_range=pos['range'],position_keys=keys)
   plans.append(pos)
  pedals.extend([{'bar':n,'onset':start,'controller':64,'value':0,'instrument':'piano'},{'bar':n,'onset':start+.08,'controller':64,'value':26,'instrument':'piano'},{'bar':n,'onset':start+2.7,'controller':64,'value':0,'instrument':'piano'}])
 pedals.append({'bar':80,'onset':240.,'controller':64,'value':0,'instrument':'piano'});hp={(p['bar'],p['hand']):p for p in plans}
 for hand in ['left','right']:
  times=sorted({e['onset'] for e in events if e['hand']==hand})
  for a,z in zip(times,times[1:]):
   old=[e for e in events if e['hand']==hand and e['onset']==a];new=[e for e in events if e['hand']==hand and e['onset']==z];ok=[e['pitch'] for e in old];nk=[e['pitch'] for e in new];op=hp[(old[0]['bar'],hand)];np=hp[(new[0]['bar'],hand)];travel=max(abs(min(ok)-min(nk)),abs(max(ok)-max(nk)),max(abs(x-y) for x in ok for y in nk),max(abs(x-y) for x,y in zip(op['range'],np['range'])) if op['position_id']!=np['position_id'] else 0);required=.075+.012*max(0,travel-4)+.014;limit=seconds(bars,z)-required
   for e in old:
    if seconds(bars,e['onset']+e['duration'])>limit:e['duration']=round((limit-seconds(bars,e['onset']))*bars[e['bar']-1]['bpm']/60,6);e['release_adjustment']='Actual complete hand release for conservative grip/key travel plus14ms margin.'
    assert e['duration']*60/bars[e['bar']-1]['bpm']>=.06,(version,'short physical gate',e)
 events.sort(key=lambda e:(e['onset'],e['instrument'],e['hand'],e['pitch'],e['voice']));counter={}
 for e in events:
  k=(e['bar'],e['instrument'],e['voice']);counter[k]=counter.get(k,0)+1;e['event_id']=f'w99-b{e["bar"]:03d}-{e["instrument"]}-{e["voice"]}-{counter[k]:02d}';e.update(target_on_beats=e['onset'],target_off_beats=round(e['onset']+e['duration'],6),target_on_seconds=round(seconds(bars,e['onset']),9),target_off_seconds=round(seconds(bars,e['onset']+e['duration']),9))
 phrases=[]
 for pid in sorted({e['phrase_id'] for e in events}):
  ns=[e for e in events if e['phrase_id']==pid];a=min(e['onset'] for e in ns);z=max(e['onset']+e['duration'] for e in ns);first=min(e['bar'] for e in ns);last=max(e['bar'] for e in ns);inst=ns[0]['instrument'];phrases.append({'phrase_id':pid,'instrument':inst,'first_bar':first,'last_bar':last,'phrase_label':LABELS[(first-1)//8],'target_on_beats':a,'target_off_beats':round(z,6),'target_on_seconds':round(seconds(bars,a),9),'target_off_seconds':round(seconds(bars,z),9),'role':'breathing_lead' if inst=='cello' else 'lead_or_support','layers_used':sorted({e['layer'] for e in ns if 'layer' in e})})
 return {'id':99,'title':'The Shipwright’s Unfinished Boat','title_zh':'造船匠没有完工的船','version':version,'instrumentation':['natural_acoustic_piano','sampled_cello_short_bows_pp_mf'],'bars':bars,'events':events,'phrases':phrases,'pedals':pedals,'total_beats':240.,'tail_seconds':6,'hand_position_plan':plans,'performance_contract':{'beat_unit':'quarter-note beats;6/8=3','cello':'Original D3–B3 short bows, pp1–55/mf56–127. Owner applies measured coarse onset advance once with a shared preroll. Gate after alignment<=1.15sec, no sampled legato or loops.','piano':'Conservative actual held-key and grip-edge transfers; pedal never substitutes for release.','limits':'Symbolic constraints are not acoustic or listening approval.'}}
def dumps(x):return json.dumps(x,ensure_ascii=False,indent=2)+'\n'
def patch(a,b,path=''):
 if a==b:return []
 if isinstance(a,dict) and isinstance(b,dict):
  out=[]
  for k in sorted(set(a)|set(b)):
   p=path+'/'+k.replace('~','~0').replace('/','~1')
   if k not in b:out.append({'op':'remove','path':p})
   elif k not in a:out.append({'op':'add','path':p,'value':b[k]})
   else:out+=patch(a[k],b[k],p)
  return out
 return [{'op':'replace','path':path,'value':b}]
def emit_diff(root,a,b):
 before=dumps(a);after=dumps(b);changes=[]
 for n in range(1,81):
  row={'bar':n,'before_bar':a['bars'][n-1],'after_bar':b['bars'][n-1],'before_events':[e for e in a['events'] if e['bar']==n],'after_events':[e for e in b['events'] if e['bar']==n],'before_pedals':[e for e in a['pedals'] if e['bar']==n],'after_pedals':[e for e in b['pedals'] if e['bar']==n]}
  if any(row['before_'+k]!=row['after_'+k] for k in ['bar','events','pedals']):changes.append(row)
 av,bv=a['version'],b['version'];d={'from_version':av,'to_version':bv,'before_sha256':hashlib.sha256(before.encode()).hexdigest(),'after_sha256':hashlib.sha256(after.encode()).hexdigest(),'changed_bars':[x['bar'] for x in changes],'changes':changes,'phrase_metadata_before':a['phrases'],'phrase_metadata_after':b['phrases'],'position_plan_before':a['hand_position_plan'],'position_plan_after':b['hand_position_plan'],'json_patch':patch(a,b)};(root/f'exact_diff_{av}_to_{bv}.json').write_text(dumps(d));(root/f'exact_diff_{av}_to_{bv}.patch').write_text(''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile=f'score_{av}.json',tofile=f'score_{bv}.json')))
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--outdir',default=str(ROOT));root=Path(ap.parse_args().outdir);root.mkdir(parents=True,exist_ok=True);scores=[build(v) for v in ['v0','v1','v2']]
 for s in scores:(root/f'score_{s["version"]}.json').write_text(dumps(s))
 (root/'score.json').write_text(dumps(scores[-1]));emit_diff(root,scores[0],scores[1]);emit_diff(root,scores[1],scores[2])
if __name__=='__main__':main()
