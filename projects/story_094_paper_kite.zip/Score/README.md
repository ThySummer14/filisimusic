# 094 纸鸢的星图 / The Paper Kite Constellation

原创虚构故事及天然声学钢琴＋长笛符号稿。最终版为 score.json（与 score_v2.json 相同）。降B大调谐谑曲，G小调中段，2/4；176 小节，352 个四分音符拍，含 4 秒尾响约 3:13.64。

- story_zh.txt：完整虚构故事。
- music_notes_zh.md：结构、主题、和声实际 MIDI、演奏、采样层与补偿契约。
- revision_notes.md：两轮实质修改及音乐原因。
- score_v0.json、score_v1.json、score_v2.json：三版完整谱。
- exact_diff_*.json 与 .patch：可重建的完整 JSON patch、逐小节事件及精确文本差异。
- generate_score.py：确定性标准库生成器，不含音频处理。
- verify_symbolic.py：独立落盘读取、演奏约束及精确重建检查。
- audit_v*.json：三版逐项结果，包括全部严格握形转移与逐句长笛时长审计。
- independent_verification.json、reproducibility_check.json：总验证及新进程逐字节复现结果。
- hash_manifest.json：本目录各正式文件的 SHA-256 清单（不包含清单本身）。

运行 python generate_score.py，再运行 python verify_symbolic.py 可重新生成并检查。所有节拍单位都是四分音符；不要把 2/4 小节误读为四拍。长笛 ordinary_trigger 没有预先补偿，音频集成阶段只提前一次。

本交付只包含符号谱与文字，没有音频、DSP、下载、安装或试听。本次通过的符号审计不等于成品音频已经验收。
