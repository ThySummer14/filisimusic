from pathlib import Path
import json,copy
P=Path(__file__).parent
H={'Dm':[38,45,53],'G':[43,50,59],'C':[48,52,55],'F':[41,48,57],'Em':[40,47,55],'Am':[45,48,52],'Bb':[46,50,53],'A7':[45,49,55]}
A=[[62,65,69,67],[64,67,65,62],[65,69,71,69],[67,65,64,62],[64,65,67,69],[71,69,67,64],[65,64,62,60],[62,65,64,62]]
OP=[[67,69,65,62],[62,65,67,64],[69,71,69,65],[64,62,65,67],[69,67,65,64],[65,62,60,64],[67,65,64,60],[62,64,65,62]]
W=[[65,69,70,69],[67,65,62,60],[65,67,69,70],[69,65,64,60],[67,70,69,65],[64,67,69,67],[65,64,62,61],[62,64,65,64]]
M=[[62,65,64,62],[60,64,67,65],[62,64,65,69],[67,65,62,60],[65,69,67,64],[62,65,64,60],[64,67,69,67],[65,64,62,62]]
S=[[67,65,69,62],[64,62,65,67],[69,67,71,65],[67,64,65,62],[65,62,64,67],[69,65,67,71],[69,67,65,64],[65,64,62,62]]
intro=[[62,65,69,67],[64,67,65,62],[60,64,67,65],[62,65,64,62]]
coda=[[67,65,64,62],[60,64,67,65],[64,65,67,64],[62,62,62,62]]
AH=['Dm','G','Em','Dm','C','G','F','Dm'];OH=['G','Dm','Em','C','Am','F','G','Dm'];WH=['F','Bb','F','C','G','Em','A7','Dm'];MH=['Dm','C','F','Am','G','Dm','C','Dm'];SH=['G','Dm','Em','C','F','G','A7','Dm']
for version in range(3):
 parts=[('First confident transcription',intro,['Dm','G','C','Dm'],84,'intro'),('Marks on the south bank',A,AH,96,'main'),('The opposite bank',OP if version else A,OH if version else AH,96,'opposite'),('A beautiful wrong welcome',W if version else A,WH if version else AH,104,'welcome'),('Record where the water goes',M if version==2 else A,MH if version==2 else AH,88,'measure'),('Two-sided signs',S if version==2 else A,SH if version==2 else AH,100,'signs'),('Write which bank you stand on',coda if version==2 else intro,['G','C','A7','Dm'],80,'coda')]
 d={'id':77,'title':'The Rivers Second Alphabet','title_zh':'河流的第二套字母','stage':f'v{version}','bars':[],'events':[],'pedals':[],'phrases':[],'tail_seconds':5};unit=0;bar=0;start=0
 for section,melodies,harmonies,bpm,kind in parts:
  for k,(mel,hn) in enumerate(zip(melodies,harmonies)):
   unit+=1;split=kind in ['opposite','signs'];lens=[4,2] if split else [6];h=H[hn];localbars=[];offset=0
   lead='piano' if kind=='intro' or (kind=='measure' and k%2==1) else 'clarinet'
   for length in lens:
    bar+=1;localbars.append((offset,bar));d['bars'].append({'bar':bar,'start':start+offset,'beats':length,'bpm':bpm,'meter_numerator':length,'meter_denominator':4,'section':section,'harmony_name':hn,'harmony':h,'lead_instrument':lead,'role_plan':'One foreground line; piano shared harmony, separate response only after clarinet.'});offset+=length
   def bnum(off):return localbars[-1][1] if split and off>=4 else localbars[0][1]
   def add(off,dur,pitch,vel,voice,inst='piano'):
    e={'onset':start+off,'duration':dur,'pitch':pitch,'velocity':vel,'voice':voice,'instrument':inst,'bar':bnum(off)}
    if inst=='clarinet':e.update(phrase_id=f'C{unit:02}',layer='pp' if vel<=55 else 'mf',onset_reference='ordinary_trigger')
    d['events'].append(e)
   # Piano supplies harmonic grounding, never an independent bass tune.
   add(0,.85,h[0],38 if lead=='clarinet' else 44,'bass')
   for off in [1.5,3.5]:
    for n in h[1:]:add(off,1.15,n,32 if lead=='clarinet' else 38,'accompaniment')
   if lead=='piano':
    for j,n in enumerate(mel):add([0,1.5,3,4.5][j],1.15,n+12,65+[0,-3,2,-5][j],'piano_melody')
   else:
    layer='pp' if kind in ['measure','coda'] else 'mf';base=49 if layer=='pp' else 70
    onset=[.25,1.65,3.05,4.45] if kind not in ['opposite','signs'] else [.35,1.85,3.35,4.85]
    duration=[.95,.9,.95,.9]
    if kind=='welcome':onset=[0,1.0,2.75,4.25];duration=[.72,1.0,.9,.85]
    if kind=='coda' and k==3:onset=[.2];duration=[1.6];mel=[62]
    for j,n in enumerate(mel):add(onset[j],duration[j],n,base+[2,-3,1,-4][j],'clarinet','clarinet')
    # Last unit of each phrase allows a short piano completion after wind releases.
    if k%4==3 and kind!='coda':add(5.65,.28,mel[-1]+12,52,'piano_answer')
    d['phrases'].append({'phrase_id':f'C{unit:02}','instrument':'clarinet','first_bar':localbars[0][1],'last_bar':localbars[-1][1],'layer':layer,'target_on_beats':start+onset[0],'target_off_beats':start+onset[-1]+duration[-1]})
   d['pedals'] += [{'onset':start,'value':0},{'onset':start+.1,'value':28 if lead=='clarinet' else 40},{'onset':start+5.5,'value':0}];start+=6
 d['total_beats']=start;d['events'].sort(key=lambda e:(e['onset'],e['instrument'],e['pitch']));assert unit==48 and start==288
 (P/f'revisions/ensemble_v{version}.json').write_text(json.dumps(d,ensure_ascii=False,indent=2))
 if version==2:
  (P/'ensemble_score.json').write_text(json.dumps(d,ensure_ascii=False,indent=2))
  for inst in ['piano','clarinet']:(P/f'{inst}_score.json').write_text(json.dumps({**d,'events':[e for e in d['events'] if e['instrument']==inst],'pedals':d['pedals'] if inst=='piano' else []},ensure_ascii=False,indent=2))
(P/'revisions/pass1.json').write_text(json.dumps({'kind':'substantive_composition_revision','changes':['Opposite-bank section replaces copied south-bank tune with inverted/reordered arrival contours and a distinct G/Dm/Em/C route.','False-welcome section introduces a separately composed F/Bb gesture, uneven entrances and A7 pivot; no literal copied melody.']},indent=2))
(P/'revisions/pass2.json').write_text(json.dumps({'kind':'substantive_composition_revision','changes':['Compose new measurement dialogue alternating piano foreground with quiet real-pp clarinet.','Rewrite two-sided signs and coda, retaining recognizable intervals while changing reading direction and resolving the final note to D.','Use4/4+2/4 notation in the opposite-bank and sign sections without changing each six-quarter paragraph length.']},indent=2))
print('bars',bar,'events',len(d['events']),'seconds',sum(b['beats']*60/b['bpm'] for b in d['bars'])+5)
