"""Original oscillator instruments; serial, bounded-memory multitrack REAPER renderer.
Requires Python + NumPy + SciPy, FFmpeg, and an installed REAPER. No samples/plugins.
"""
import os
for k in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS'):os.environ[k]='1'
from pathlib import Path
import numpy as np
from scipy import signal
from scipy.io import wavfile
import json,math,struct,subprocess,sys,hashlib,shutil,time
SR=48000
REAPER=os.environ.get('REAPER_BIN',shutil.which('reaper') or 'reaper')

def envelope(t,d,a,r):
    return np.minimum(t/max(a,.001),1)*np.clip((d+r-t)/max(r,.001),0,1)

def voice(p,d,k,v,rng):
    tail={'pad':1.8,'strings':.75,'piano':.9,'epiano':.6,'bell':1.25,'guitar':.55,'flute':.23,'lead':.3,'pluck':.35,'bass':.12}.get(k,.2)
    dur={'kick':.38,'snare':.23,'hat':.095,'rim':.075,'tom':.4,'cymbal':1.35}.get(k,d+tail)
    t=np.arange(round(dur*SR),dtype=np.float64)/SR
    if k in ('kick','snare','hat','rim','tom','cymbal'):
        noise=rng.standard_normal(len(t))
        if k=='kick':x=(np.sin(2*np.pi*(43*t+2.5*(1-np.exp(-t/.027))))*np.exp(-t*14)+.025*noise*np.exp(-t*180))*.9
        elif k=='snare':
            hp=signal.sosfilt(signal.butter(2,1800,fs=SR,btype='highpass',output='sos'),noise)
            x=(.5*hp+.26*np.sin(2*np.pi*186*t))*np.exp(-t*27)
        elif k in ('hat','cymbal'):
            hp=signal.sosfilt(signal.butter(2,6700,fs=SR,btype='highpass',output='sos'),noise)
            x=hp*np.exp(-t*(57 if k=='hat' else 5))*(.28 if k=='hat' else .16)
        elif k=='rim':x=(np.sin(2*np.pi*830*t)+.6*np.sin(2*np.pi*1240*t))*np.exp(-t*70)*.24
        else:x=np.sin(2*np.pi*(95*t+1.3*(1-np.exp(-t/.06))))*np.exp(-t*12)*.6
        x*=np.minimum(t/.0015,1);x[-min(250,len(x)):]*=np.linspace(1,0,min(250,len(x)))
    else:
        f=440*2**((p-69)/12);ph=2*np.pi*f*t
        if k=='piano':
            x=np.zeros_like(t)
            for h,a in [(1,.68),(2,.28),(3,.13),(4,.07),(6,.025)]:x+=a*np.sin(ph*h*(1+.00005*h*h))*np.exp(-t*(.65+.45*h))
            x*=envelope(t,d,.004,tail)
        elif k=='epiano':x=(.75*np.sin(ph+1.4*np.exp(-t*6)*np.sin(2*ph))+.15*np.sin(2.002*ph)*np.exp(-t*4))*np.exp(-t*.65)*envelope(t,d,.006,tail)
        elif k=='bass':x=(np.sin(ph)+.18*np.sin(2*ph)+.05*np.sin(3*ph))*np.exp(-t*.65)*envelope(t,d,.007,tail)
        elif k=='pluck':x=(np.sin(ph)+.42*np.sin(ph*2)+.17*np.sin(ph*3)+.07*np.sin(ph*5))*np.exp(-t*6)*envelope(t,d,.0025,tail)
        elif k=='flute':x=(.82*np.sin(ph+.011*np.sin(2*np.pi*4.6*t))+.11*np.sin(2*ph)+.03*np.sin(3*ph))*envelope(t,d,.04,tail)
        elif k=='bell':x=(np.sin(ph)*np.exp(-t*1.2)+.25*np.sin(ph*2.76)*np.exp(-t*3)+.09*np.sin(ph*5.4)*np.exp(-t*5))*envelope(t,d,.002,tail)
        elif k=='guitar':
            x=sum(a*np.sin(ph*h+.025*np.sin(2*np.pi*5*t)) for h,a in [(1,.65),(2,.3),(3,.18),(4,.08),(5,.04)])
            x=np.tanh(x*1.4)*np.exp(-t*1.1)*envelope(t,d,.008,tail)
        elif k=='lead':x=(.65*np.sin(ph)+.22*np.sin(ph*2)+.1*np.sin(ph*3)+.05*np.sin(ph*4))*envelope(t,d,.012,tail)
        elif k=='strings':x=(.53*np.sin(ph+.017*np.sin(2*np.pi*5.1*t))+.22*np.sin(ph*2.001)+.1*np.sin(ph*3)+.05*np.sin(ph*4))*envelope(t,d,.18,tail)
        else:x=(.58*np.sin(ph)+.22*np.sin(ph*1.0018)+.12*np.sin(ph*2)+.06*np.sin(ph*3))*envelope(t,d,.4,tail)
    return (x*v).astype(np.float32)

def vlq(v):
    a=[v&127];v>>=7
    while v:a.insert(0,(v&127)|128);v>>=7
    return bytes(a)
def midi(track,bpm,meter,path):
    ch=9 if track['kind'] in ('kick','snare','hat','rim','tom','cymbal') else 0
    tl=[]
    for b,p,d,v in track['events']:
        tl.extend([(round(b*480),bytes([0x90+ch,int(p),max(1,min(127,round(v*110)))])),(round((b+d)*480),bytes([0x80+ch,int(p),0]))])
    tl.sort(key=lambda e:(e[0],e[1][0]));tempo=round(60000000/bpm)
    data=b'\0\xff\x51\x03'+tempo.to_bytes(3,'big')+b'\0\xff\x58\x04'+bytes([meter,2,24,8]);last=0
    for tick,e in tl:data+=vlq(tick-last)+e;last=tick
    data+=b'\0\xff\x2f\0';path.write_bytes(b'MThd'+struct.pack('>IHHH',6,0,1,480)+b'MTrk'+struct.pack('>I',len(data))+data)

def render(scorepath,out,do_reaper=True):
    score=json.loads(Path(scorepath).read_text());out=Path(out);out.mkdir(parents=True,exist_ok=True)
    for d in ('stems','midi','exports'): (out/d).mkdir(exist_ok=True)
    bpm=score['bpm'];meter=score['meter'];seconds=score['bars']*meter*60/bpm+2.5;N=round(seconds*SR)
    mix=np.zeros((N,2),np.float32);tracks=[];issues=[]
    for ti,tr in enumerate(score['tracks']):
        rng=np.random.default_rng(1007+ti);a=np.zeros((N,2),np.float32);pan=tr.get('pan',0);gain=tr.get('gain',.3)
        for b,p,d,v in tr['events']:
            if not (0<=p<=127 and b>=0 and d>0 and 0<v<=1):issues.append([tr['name'],b,p,d,v]);continue
            pos=round(b*60/bpm*SR);x=voice(p,d*60/bpm,tr['kind'],v,rng);n=min(len(x),N-pos)
            if n<=0:continue
            a[pos:pos+n,0]+=x[:n]*math.sqrt((1-pan)/2);a[pos:pos+n,1]+=x[:n]*math.sqrt((1+pan)/2)
        if tr['kind'] not in ('bass','kick','hat','rim','tom'):
            # Feedforward stereo early reflections; one scratch buffer at a time.
            wet=.12 if tr['kind'] not in ('pad','strings') else .23
            for delay,g in [(.067,.44),(.113,.31),(.179,.24),(.293,.18),(.431,.12),(.617,.08)]:
                n=round(delay*SR);a[n:]+=a[:-n,::-1].copy()*(wet*g)
        a[:240]*=np.linspace(0,1,240,dtype=np.float32)[:,None];a[-48000:]*=np.linspace(1,0,48000,dtype=np.float32)[:,None]
        fn=f'{ti+1:02d}_{tr["kind"]}';wavfile.write(out/'stems'/f'{fn}.wav',SR,a)
        midi(tr,bpm,meter,out/'midi'/f'{fn}.mid');mix+=a*gain
        tracks.append(dict(name=tr['name'],kind=tr['kind'],file=fn,gain=gain,events=len(tr['events']),peak=float(np.max(np.abs(a)))))
        del a
    peak=float(np.max(np.abs(mix)));rms=float(np.sqrt(np.mean(mix**2)))
    # Style-appropriate headroom, with no compression/limiter or equal-LUFS forcing.
    target={'ambient':-5,'chamber':-8.0,'chamber_music':-3,'piano_ballad':-3,'jazz_waltz':-2.5,'bossa_nova':-2.5,'pentatonic':-3}.get(score['id'],-1.8)
    master=10**(target/20)/max(peak,1e-9);mix*=master
    wavfile.write(out/'exports'/'DSP_reference.wav',SR,mix)
    rpp=['<REAPER_PROJECT 0.1 "7.82/linux-x86_64" 1',f'  TEMPO {bpm} {meter} 4', '  SAMPLERATE 48000 0 0',f'  MASTER_VOLUME {master:.12f}',f'  RENDER_FILE "exports/{score["id"]}_REAPER.wav"','  RENDER_FMT 0 2 48000','  RENDER_RANGE 1 0 '+str(seconds)+' 16 1000','  RENDER_STEMS 0','  RENDER_DITHER 0','  <RENDER_CFG','    ZXZhdxgAAA==','  >']
    for i,s in enumerate(score['sections']):rpp.append(f'  MARKER {i+1} {s["bar"]*meter*60/bpm:.8f} "{s["label"]}" 0')
    for tr in tracks:
        rpp+=['  <TRACK',f'    NAME "{tr["name"]}"',f'    VOLPAN {tr["gain"]} 0 1 -1','    MAINSEND 1','    <ITEM','      POSITION 0',f'      LENGTH {seconds:.8f}','      VOLPAN 1 0 1 -1',f'      NAME "{tr["name"]}"','      <SOURCE WAVE',f'        FILE "stems/{tr["file"]}.wav"','      >','    >','  >']
    rpp+=['>'];project=out/f'{score["id"]}.rpp';project.write_text('\n'.join(rpp)+'\n');copy_score_source(scorepath, out)
    report=dict(id=score['id'],title=score['title'],duration_seconds=seconds,tracks=tracks,invalid_events=issues,master_gain=master,peak_dbfs=20*math.log10(max(np.max(abs(mix)),1e-12)),rms_dbfs=20*math.log10(max(np.sqrt(np.mean(mix**2)),1e-12)),end_peak=float(np.max(abs(mix[-480:]))),renderer='DSP reference only',auditory_audition=False)
    if do_reaper:
        start=time.time()
        with (out/'reaper_render.log').open('w') as log:
            p=subprocess.run([REAPER,'-newinst','-nosplash','-ignoreerrors','-renderproject',str(project.resolve())],stdout=log,stderr=subprocess.STDOUT,timeout=180)
        actual=out/'exports'/f'{score["id"]}_REAPER.wav'
        if p.returncode!=0 or not actual.exists():raise RuntimeError(f'REAPER did not produce export: {out}, code {p.returncode}')
        rate,rendered=wavfile.read(actual);rendered=rendered.astype(np.float32)/2147483648
        report.update(renderer='REAPER 7.82 actual multitrack project offline render',reaper_return_code=p.returncode,reaper_render_wall_seconds=time.time()-start,reaper_max_error=float(np.max(abs(rendered-mix))),render_frames=len(rendered),sample_rate=rate,output_sha256=hashlib.sha256(actual.read_bytes()).hexdigest())
        if report['reaper_max_error']>1e-5:raise RuntimeError(f'Reference discrepancy {report["reaper_max_error"]}')
        del rendered
        subprocess.run(['ffmpeg','-y','-v','error','-threads','1','-i',str(actual),'-codec:a','libmp3lame','-b:a','192k',str(out/'exports'/f'{score["id"]}.mp3')],check=True)
        q=subprocess.run(['ffmpeg','-hide_banner','-nostats','-threads','1','-i',str(actual),'-af','loudnorm=print_format=json','-f','null','-'],capture_output=True,text=True)
        try:report['loudness']=json.loads(q.stderr[q.stderr.rfind('{'):q.stderr.rfind('}')+1])
        except:report['loudness_error']=q.stderr[-1000:]
    (out/'technical_report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print(json.dumps({k:v for k,v in report.items() if k!='tracks'},ensure_ascii=False),flush=True)
    return report
def copy_score_source(scorepath, out):
    destination = Path(out) / 'score.json'
    if Path(scorepath).resolve() != destination.resolve():
        shutil.copy2(scorepath, destination)

if __name__=='__main__':render(sys.argv[1],sys.argv[2], '--no-reaper' not in sys.argv)
