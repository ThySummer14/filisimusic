IOWA FLUTE WITH VIBRATO | TWO RECORDED DYNAMICS | C5–B5

Ready instrument: Iowa_flute_vibrato_C5_B5_two_layers.sfz
Keep the SFZ beside the Samples directory. MIDI range is exactly 72–83;
MIDI numbering is authoritative because software octave labels differ.

Use pp velocities 21–55 and mf velocities 56–95. For convenience, 1–20
reuse pp and 96–127 reuse mf; these do not represent extra recorded layers.
The two genuine recorded dynamics retain their original relative levels.
No per-note normalization, processed room sound, or external samples added.

Use written held-note durations at most 1.60 seconds. This limit is computed
from the shortest voiced sample (pp D#5: 1.83 seconds), its small playback
tuning adjustment, and a 200 ms guard. Actual WAV crops are 2.18–2.74 seconds
and include pre-onset and release-tail context. There are no sustain loops.
Use breath-separated phrases. Low-level breath/attack precedes the coarse
voiced onset by approximately 50–209 ms, depending on the source note.
This is a natural acoustic articulation, not a tight synthetic onset.

Every note was independently identified across three body windows; all 1,224
short-time pitch estimates round to the expected MIDI note. Three-window
central estimates differ by at most 9.78 cents. SFZ centering offsets are
no larger than 17.82 cents in magnitude. Natural vibrato and drift remain,
with measured variation up to 53.38 cents peak-to-peak. The 0.01-cent metadata
format is not a claim of perfect intonation or matching estimator accuracy.

The WAV files preserve every selected source integer PCM sample exactly.
Only the container and byte order change; tuning is playback metadata.
SFZ playback uses a 2 ms attack and 120 ms release envelope. There are no
round robins, release-trigger recordings, true sampled legato, or ff takes.

Reproduce with installed Python 3.12 + NumPy (nothing needs installation):
  python analyze_scales.py
  python build_mapping.py
  python verify_mapping.py

The analysis and build scripts enforce one CPU, a 150 MiB address-space
ceiling and a 90 CPU-second limit. Analysis used about 53.3 MiB peak RSS
and under one second; the builder used about 19.3 MiB. This directory
occupies less than the allowed 20 MB including the two original scales.
The downloader uses only the standard library, HEAD size checks, bounded
streaming reads and a 7,000,000-byte aggregate cap. It deliberately refuses
to overwrite already downloaded sources. Do not redownload for reproduction.

All 24 written WAV crops were byte-verified. No acoustic render or listening
test was performed by this preparation worker. The authorized parent owns
the separately bounded sfizz/REAPER acoustic proof.

See SOURCE_LICENSE.txt and provenance.json for truthful recording credit
and the official source permission. This source is not labeled CC0.
