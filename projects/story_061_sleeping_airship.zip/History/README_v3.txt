在睡梦中修理飞艇 / Repairing the Airship in Sleep — v3
原创虚构故事与钢琴、单簧管变奏二重奏，3分00.8秒。

打开061_sleeping_airship_v3.rpp。完整包包含两条float32音轨，REAPER可直接播放及导出；这是自包含的音频轨工程，另有三轨MIDI和结构化演奏谱。不是自包含虚拟乐器工程。轻房间使用REAPER自带ReaVerbate。本Linux7.82版本已原生重开导出核验；其他平台可能需重新匹配插件，不承诺跨平台PCM一致。输出在Renders/。

重新改音符：Score/compose_airship.py生成三个原始谱面版本，Score/prepare_scores.py从score_v2.json分出piano_score.json与clarinet_score.json；Score/export_midi.py导出三轨MIDI。Tools/render_score_sfizz.py分别读取钢琴谱和单簧管谱。钢琴选外部Moonlight推荐SFZ并加--enable-details；单簧管选随附Iowa_clarinet_C4_B4_trio_articulated.sfz（放到外部Samples目录旁）。将两条源轨写到Media/piano_float32.wav和Media/clarinet_float32.wav。修改曲式长度时也需调整母带范围。旧Score目录的README和草稿说明保留非渲染创作阶段的原始状态，不代表本交付缺少音频。

钢琴：Moonlight-SalamanderV6.2，Alexander Holm录音，Chisato Yamauchi/Accurate-Salamander重制，Hiroharu Narikawa等调律；CC BY3.0 https://creativecommons.org/licenses/by/3.0/ 。官方来源 https://www.ir.isas.jaxa.jp/~cyamauch/AccurateSalamander/ 。原始README和版本hash随包。
单簧管：University of Iowa MIS，Christine Bellomy演奏，Lawrence Fritts主持，John Ritz与Eric Durian录音技术。来源 https://theremin.music.uiowa.edu/MISBbclarinet.html ，官方许可 https://theremin.music.uiowa.edu/MIS.html 允许用于任何项目而无使用限制，并非另称CC0。原始数据16bit44.1kHzmono，分音切片、容器转换、细小音高校准及SHA记录在InstrumentMapping目录。此曲只使用真实mf录音层；最长单音1.15秒，有真实换气，无连奏过渡或循环延音。float32源轨与24bit母带不意味着原始录音获得额外精度。

两轮实质谱面修订：改写地基、旋律回答与故障段；再删除真实低音敲击、调整交接、呼吸和末句。第三轮是技术混音完善：实际REAPER分轨总线复核后把单簧管gain3调至3.8，让早期主奏更明确；缩短冗余尾静默。宽度和声像律以原生API回读为准。能量、琴键与时序检查不等于音乐质量或真人听审。录音使用采样，并非现场真人演奏。故事纯属原创虚构。
