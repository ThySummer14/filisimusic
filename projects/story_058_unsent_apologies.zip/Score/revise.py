import pathlib,json,copy,collections
P=pathlib.Path(__file__).parent;v1=json.loads((P/'revisions/ensemble_v0.json').read_text());v1['stage']='v1_extended_questions_and_new_harmonic_decision'
def melody(bar,line,vel):
 b=v1['bars'][bar-1];v1['events'][:]=[e for e in v1['events']if not(e['bar']==bar and e['instrument']=='clarinet')];off=0
 for n,l in line:
  if n>=0:v1['events'].append(dict(bar=bar,onset=b['start']+off,duration=l*.93,pitch=n,velocity=vel,voice='clarinet_melody',instrument='clarinet'))
  off+=l
 assert off==4
# Four new continuations deepen the question rather than duplicate the first four bars.
X=[[(67,.5),(68,.5),(70,1),(67,.5),(65,.5),(63,.5),(-1,.5)],[(63,1),(62,.5),(60,.5),(63,1),(67,.5),(-1,.5)],[(68,.5),(67,.5),(65,1),(63,.5),(60,.5),(63,.5),(-1,.5)],[(62,.5),(65,.5),(67,.5),(68,.5),(65,1),(62,.5),(-1,.5)]]
for bar,line in zip(range(11,15),X):melody(bar,line,49)
# A newFminor/C7color marks the visitor's decision; all accompanying pitches follow.
changes={23:('Fm',[41,53,56,60]),24:('C7',[36,52,58,64]),25:('Fm',[41,53,56,60]),26:('Ab',[44,51,56,60])}
for bar,(h,ch)in changes.items():
 b=v1['bars'][bar-1];old=b['harmony'];b.update(harmony_name=h,harmony=ch)
 for e in v1['events']:
  if e['bar']==bar and e['instrument']=='piano':
   ix=old.index(e['pitch']);e['pitch']=ch[ix]
melody(24,[(64,.5),(67,.5),(70,1),(67,.5),(65,.5),(64,.5),(-1,.5)],53)
melody(26,[(65,1),(63,.5),(65,.5),(68,1),(67,.5),(-1,.5)],51)
# The closing clarinet phrase truly reachesEb before piano leaves the added ninth unresolved.
melody(61,[(67,.75),(65,.25),(63,1),(63,1.5),(-1,.5)],43)
(P/'revisions/ensemble_v1.json').write_text(json.dumps(v1,indent=2));(P/'revisions/pass1.json').write_text(json.dumps({'pass':1,'changes':['Write four new melodic continuation bars for the first twelve-bar paragraph, rather than repeat its first question.','Reharmonize the visitor passage throughFm→C7→Fm→Ab and rewrite the clarinet to agree with those chord tones.','Give the closing clarinet a realEbarrival; piano alone retains the open ninth, separating the decision to send from the unknown reply.']},indent=2))
v2=copy.deepcopy(v1);v2['stage']='v2_breaths_layer_coherence_and_joint_piano_responses'
for e in v2['events']:
 b=v2['bars'][e['bar']-1];kind=b['role_plan']
 if e['instrument']=='clarinet':
  # Stay within one recorded dynamic region for each local phrase, avoiding accidental55/56layer jumps.
  base={'museum':47,'scarf':66,'stamp':49,'post':79,'room':69,'drawer':45,'coda':42}[kind]
  phase={'museum':3,'scarf':15,'stamp':23,'post':33,'room':41,'drawer':53,'coda':59}[kind];arc=[0,2,3,-2,1,4,2,-3][(e['bar']-phase)%8];e['velocity']=base+arc+(1 if abs(e['onset']-b['start'])<.001 else 0)
  e['duration']=min(e['duration'],1.50*b['bpm']/60)
  assert 60<=e['pitch']<=71 and e['duration']*60/b['bpm']<=1.55
 else:
  if kind in('museum','stamp','drawer','coda')and e['voice']=='accompaniment':e['velocity']-=3
  if e['voice']=='reply':e['velocity']-=2
# Align piano replies with the ACTUAL end-of-bar clarinet rests after melody rewrites.
for b in v2['bars']:
 ms=[e for e in v2['events']if e['bar']==b['bar']and e['instrument']=='clarinet']
 if not ms:continue
 end=max(e['onset']+e['duration']for e in ms)
 for e in v2['events']:
  if e['bar']==b['bar']and e['voice']=='reply':e['onset']=max(e['onset'],end+.025);e['duration']=min(e['duration'],b['start']+3.95-e['onset'])
v2['events']=[e for e in v2['events']if e['duration']>.015]
# Only piano physical-key ownership is reconciled: different real instruments may legitimately share pitches.
by=collections.defaultdict(list);omit=set();fix=[]
for i,e in enumerate(v2['events']):
 if e['instrument']=='piano':by[e['pitch']].append((i,e))
for pitch,seq in by.items():
 seq.sort(key=lambda x:x[1]['onset'])
 for (ia,a),(ib,b)in zip(seq,seq[1:]):
  if ia in omit or ib in omit:continue
  if a['onset']+a['duration']>b['onset']+.001:
   if abs(a['onset']-b['onset'])<.001:omit.add(ib);fix.append({'bar':b['bar'],'pitch':pitch,'change':'single piano onset'})
   else:a['duration']=max(.025,b['onset']-a['onset']-.02);fix.append({'bar':b['bar'],'pitch':pitch,'change':'piano release before reply'})
v2['events']=[e for i,e in enumerate(v2['events'])if i not in omit]
(P/'revisions/ensemble_v2.json').write_text(json.dumps(v2,indent=2));(P/'ensemble_score.json').write_text(json.dumps(v2,indent=2))
for instrument in ['piano','clarinet']:
 d=copy.deepcopy(v2);d['events']=[e for e in d['events']if e['instrument']==instrument]
 if instrument=='clarinet':d['pedals']=[]
 (P/f'revisions/{instrument}_score_v2.json').write_text(json.dumps(d,indent=2));(P/f'{instrument}_score.json').write_text(json.dumps(d,indent=2))
(P/'revisions/pass2.json').write_text(json.dumps({'pass':2,'changes':['Keep each local clarinet phrase within its realppor mf sample region, avoiding an accidental first-note timbre jump at velocity55/56.','Constrain every clarinet note to the verified short-sample duration; preserve small articulated gaps and longer phrase breaths.','Make piano replies follow the actual clarinet release rather than a stale template rest.','Subdue piano middle chords in the quieter narrative passages and reconcile piano-only key ownership.'],'key_corrections':fix,'actual_clarinet_layers_in_piece':['pp','mf'],'ff_bank_layer_available_but_not_forced_into_this_quiet_piece':True},indent=2));print('58v2 ready',len(fix),'piano key corrections')
