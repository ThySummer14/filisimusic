# 095 闭馆后的蓝色长椅 / The Blue Bench After Closing

完整原创虚构故事与原创钢琴＋大提琴拨弦符号曲。C 小调，C 大调中段，4/4 哈巴涅拉色彩室内舞曲；80 小节，320 四分音符拍，含 4 秒尾响约 3:25.29。人物与情节均为虚构，没有声称作者亲历。

最终采用 score.json，它与 score_v2.json 逐字节相同。

- story_zh.txt：完整故事，结尾落在封盒的具体动作。
- music_notes_zh.md：曲式、音型、乐器配合、真实 mf 源与演奏约束。
- revision_notes.md：两轮实际作曲改写的原因和范围。
- score_v0.json、score_v1.json、score_v2.json：三个完整版本。
- exact_diff_*.json 与 .patch：可重建完整下一版的 JSON patch、逐小节记录和精确文本差异。
- generate_score.py：仅用 Python 标准库的确定性生成器。
- verify_symbolic.py：独立落盘读谱、严格物理释放与握形检查、版本差异验证及新进程复现。
- audit_v*.json：三版完整审计，含每一次严格手部转移记录。
- independent_verification.json、reproducibility_check.json：最终验证摘要与逐文件复现。
- hash_manifest.json：本目录每个正式文件的 SHA-256，清单本身除外。

重建与检查：先运行 python generate_score.py，再运行 python verify_symbolic.py。所有节拍单位都是四分音符，速度也以四分音符计。生成器没有随机过程，不读取其他作品的主题。

大提琴只用 MIDI36–47 的一层真实 mf 拨弦录音。本谱力度变化只控制该层振幅。钢琴左手全部在其上方；前景只有钢琴右手。每次移手使用实际持键与完整握形的最大位移，75ms 基础空隙，每超过四半音加 12ms；不得用踏板替代键释放。

本交付没有音频、DSP、样本下载、安装或试听。符号验证通过不等于成品声音已验收；后续需验证真实拨弦攻击、释放尾音及自然声部平衡。
