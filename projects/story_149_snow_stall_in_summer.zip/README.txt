夏天的雪摊 / The Snow Stall in Summer — v3

本站提供精简可重建工程；完整含分轨 REAPER 工程另存于作者的私人文件库，本下载不含其音频素材，也不提供完整工程的公开下载链接。

本作品已完成真实采样音源和 REAPER 技术渲染、独立来源与便携 PCM 比对；完整主观听审仍未完成。AI 辅助原创作曲及虚构故事，真实原声乐器采样，不是现场真人演奏。技术核验不代表听感认可。

本包包含原名义谱、实际渲染输入谱、原 MIDI、相对路径 REAPER 工程、音源出处与安全重建工具。不含原始第三方音库、音频分轨或软件二进制。直接打开工程会缺少 Media，需先按下列步骤重建。含键域分轨的作品另保留 Score/prepare_key_domain_parts.py；用 --original-sfz 显式提供新位置的完整银行，重建高键映射后再交给安全重建器。不可拿旧裁剪映射替代新验证。原乐谱/修订中的‘未渲染’措辞属于作曲阶段历史记录；当前交付状态见此页和 metadata.json。

1. 阅读 Tools/SafeRegeneration/README.md；该目录是唯一支持的重建入口。需自行取得许可允许的原始外部音库、兼容 sfizz、Python 和 NumPy。本包不自动下载或安装。
2. 按 Score/RenderInputs/manifest.json 逐项选择精确 JSON 乐谱、原始完整 SFZ、mode、enable_details 和明确内存预算。先使用 --dry-run；新编辑乐谱必须重新进行原生覆盖验证。MIDI 修改要先同步到 JSON 乐谱。
3. 工具逐条生成源音轨，不自动生成最终母带。将音轨对应至项目 Media 下的相对路径，再由 REAPER 打开与导出。之后需要重新技术核验与听审；旧证明不覆盖修改后的作品。

音源归属、许可、原始精度及演奏限制见 metadata.json 与 InstrumentMapping/；CC BY 3.0 音源署名/链接必须保留。Iowa 使用机构的项目使用许可，未改称 CC0。

PUBLIC_PACKAGE_REPORT.json 记录本公开派生包的边界。仅删除内部执行日志/机器路径/不支持的旧脚本；音乐事件、MIDI、渲染输入及安全工具逐字节保留。
