#!/usr/bin/env python3
"""Read public sfizz C API/OSC metadata. No render_block call; no audio output.
Original-bank queries use a 256-frame streaming preload, never the RAM hint.
The generated oscillator probe measures integer-MIDI velocity conversion only.
"""
import argparse
import ctypes as C
import json
from pathlib import Path
import struct
from sfz_support import parse, read_text, require, sha


def query(sfz, library, probe_dir):
    require(not any('hint_ram_based' in r['ops'] for r in parse(read_text(sfz))), 'Original query input must not request RAM decoding.')
    sfz_hash, lib_hash = sha(sfz), sha(library)
    lib = C.CDLL(str(library))
    ptr, I, F = C.c_void_p, C.c_int, C.c_float
    class Arg(C.Union):
        _fields_ = [('i', C.c_int32), ('h', C.c_int64), ('f', F), ('d', C.c_double), ('s', C.c_char_p), ('b', ptr), ('m', C.c_uint8*4)]
    Receive = C.CFUNCTYPE(None, ptr, I, C.c_char_p, C.c_char_p, C.POINTER(Arg))
    responses, errors = {}, []
    @Receive
    def receive(data, delay, path, signature, args):
        try:
            sig = signature.decode()
            require(all(t in 'ifs' for t in sig), 'Unexpected OSC response signature: ' + sig)
            responses[path.decode()] = [args[j].i if t == 'i' else args[j].f if t == 'f' else args[j].s.decode() for j, t in enumerate(sig)]
        except Exception as exc:
            errors.append(str(exc))
    declarations = [
        ('sfizz_create_synth', ptr, []), ('sfizz_free', None, [ptr]),
        ('sfizz_set_sample_rate', None, [ptr, F]), ('sfizz_set_samples_per_block', None, [ptr, I]),
        ('sfizz_set_num_voices', None, [ptr, I]), ('sfizz_load_file', C.c_bool, [ptr, C.c_char_p]),
        ('sfizz_set_preload_size', None, [ptr, C.c_uint]), ('sfizz_get_preload_size', C.c_uint, [ptr]),
        ('sfizz_create_client', ptr, [ptr]), ('sfizz_delete_client', None, [ptr]),
        ('sfizz_set_receive_callback', None, [ptr, Receive]),
        ('sfizz_send_message', None, [ptr, ptr, I, C.c_char_p, C.c_char_p, C.POINTER(Arg)]),
        ('sfizz_send_note_on', None, [ptr, I, I, I]), ('sfizz_all_sound_off', None, [ptr]),
        ('sfizz_get_num_regions', I, [ptr]), ('sfizz_get_num_active_voices', I, [ptr]),
        ('sfizz_get_unknown_opcodes', C.c_char_p, [ptr]),
    ]
    for name, rest, args in declarations:
        fn = getattr(lib, name); fn.restype = rest; fn.argtypes = args
    def create(path):
        synth = lib.sfizz_create_synth(); require(synth, 'Synth creation failed.')
        try:
            lib.sfizz_set_sample_rate(synth, 44100); lib.sfizz_set_samples_per_block(synth, 512)
            lib.sfizz_set_num_voices(synth, 64)
            lib.sfizz_set_preload_size(synth, 256)
            require(lib.sfizz_get_preload_size(synth) == 256, 'Query preload not accepted; refusing original-bank load.')
            require(lib.sfizz_load_file(synth, str(path).encode()), 'SFZ load failed: ' + str(path))
            unknown = lib.sfizz_get_unknown_opcodes(synth)
            require(not unknown or not unknown.strip(), 'Engine reports unsupported SFZ opcodes: ' + repr(unknown))
            client = lib.sfizz_create_client(None); require(client, 'OSC client creation failed.')
            lib.sfizz_set_receive_callback(client, receive)
            return synth, client
        except Exception:
            lib.sfizz_free(synth); raise
    def ask(synth, client, path, required=True):
        responses.pop(path, None)
        lib.sfizz_send_message(synth, client, 0, path.encode(), b'', None)
        require(not errors, 'OSC callback failed: ' + repr(errors))
        if required:
            require(path in responses, 'Engine does not support required OSC query: ' + path)
        return responses.get(path)
    synth, client = create(sfz)
    try:
        regions = []
        for i in range(lib.sfizz_get_num_regions(synth)):
            row = {'index': i}
            for key in ('key_range', 'vel_range', 'sample', 'trigger'):
                row[key] = ask(synth, client, f'/region{i}/{key}')
            regions.append(row)
    finally:
        lib.sfizz_delete_client(client); lib.sfizz_free(synth)
    probe = Path(probe_dir) / 'velocity_normalization_probe.sfz'
    with probe.open('x', encoding='utf-8') as f:
        f.write('<control> hint_ram_based=1\n<region> sample=*sine key=60 amp_veltrack=0\n')
    synth, client = create(probe)
    try:
        velocities = {}
        for velocity in range(1, 128):
            lib.sfizz_all_sound_off(synth)
            require(lib.sfizz_get_num_active_voices(synth) == 0, 'Probe voice reset failed.')
            responses.clear(); lib.sfizz_send_note_on(synth, 0, 60, velocity)
            values = [v[0] for i in range(64) if (v := ask(synth, client, f'/voice{i}/trigger_value', required=False)) is not None]
            require(len(values) == 1, 'Unexpected velocity-probe voice count.')
            value = values[0]
            velocities[str(velocity)] = {'value': value, 'float32_hex': struct.pack('<f', value).hex()}
    finally:
        lib.sfizz_delete_client(client); lib.sfizz_free(synth)
    require(sfz_hash == sha(sfz) and lib_hash == sha(library), 'Query inputs changed during inspection.')
    return {'method': 'Documented public C API/OSC: original region bounds plus every integer MIDI velocity; no audio rendering.',
            'sfz_sha256': sfz_hash, 'library_sha256': lib_hash, 'query_preload_frames': 256,
            'ram_hint_recognized_by_engine': True, 'regions': regions, 'integer_velocity_to_actual_trigger_value': velocities}


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--sfz', required=True, type=Path); ap.add_argument('--library', required=True, type=Path)
    ap.add_argument('--out', required=True, type=Path)
    args = ap.parse_args()
    require(not args.out.exists(), 'Native manifest already exists.')
    result = query(args.sfz.resolve(), args.library.resolve(), args.out.parent)
    with args.out.open('x', encoding='utf-8') as f:
        json.dump(result, f, indent=2); f.write('\n')

if __name__ == '__main__':
    main()
