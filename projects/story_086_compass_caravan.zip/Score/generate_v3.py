#!/usr/bin/env python3
"""Preserved-v2 -> v3 playability revision. Standard library; no sound rendering.

Only left-hand support pitches, onsets, and releases change. The lead, form,
meters, harmonies, tempo map, pedal map, and duration remain exactly as v2.
"""
import copy
import hashlib
import json
import math
from collections import defaultdict
from pathlib import Path
import generate_score as original

OUT = Path(__file__).resolve().parent
EXPECTED_V2 = 'fcea470fcb7c1e5e0b3f092dd10a329ca6b993b18a5c0fd1abb70406812cb2c5'
MARGIN = .030

def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def dump(name, value): (OUT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')
def time_at(s, beat): return original.seconds_at(s, beat)
def beat_at(s, second):
    elapsed = 0
    for b in s['bars']:
        length = b['beats'] * 60 / b['bpm']
        if second <= elapsed + length + 1e-9:
            return b['start'] + (second - elapsed) * b['bpm'] / 60
        elapsed += length
    return s['total_beats']

def groups(s, hand):
    g = defaultdict(list)
    for e in s['events']:
        if e['hand'] == hand: g[e['onset']].append(e)
    return sorted(g.items())

def required_seconds(edge_move):
    return .075 + .012 * (edge_move - 4) if edge_move > 4 else 0

def left_hand_travel(s):
    attacks = groups(s, 'left')
    records = []
    prior = []
    for (ta, old), (tb, new) in zip(attacks, attacks[1:]):
        prior.extend(old)
        # The previous attack grip includes any earlier key still held there.
        source = [e for e in prior if e['onset'] <= ta and e['onset'] + e['duration'] > ta + 1e-8]
        a0, a1 = min(e['pitch'] for e in source), max(e['pitch'] for e in source)
        b0, b1 = min(e['pitch'] for e in new), max(e['pitch'] for e in new)
        move = max(abs(b0 - a0), abs(b1 - a1))
        if move > 4:
            released = max(e['onset'] + e['duration'] for e in prior)
            gap = time_at(s, tb) - time_at(s, released)
            need = required_seconds(move)
            records.append({'hand': 'left', 'from_bar': old[0]['bar'], 'to_bar': new[0]['bar'],
                            'from_beat': ta, 'to_beat': tb, 'source_grip_edges': [a0, a1],
                            'target_grip_edges': [b0, b1], 'movement_semitones': move,
                            'all_prior_keys_released_at_beat': round(released, 6),
                            'released_seconds': round(gap, 9), 'required_seconds': round(need, 9),
                            'margin_seconds': round(gap - need, 9), 'passed': gap + 1e-7 >= need})
    return records

def right_hand_positions(s):
    # Each entire RH bar fits an octave. A planned stable position permits ordinary
    # finger changes inside that span. We explicitly find bar positions whose real
    # translations are <= four semitones, the no-large-translation part of the rule.
    # This does not change notes, hand ownership, or held-key duration.
    ranges = []
    for b in s['bars']:
        ps = [e['pitch'] for e in s['events'] if e['hand'] == 'right' and e['bar'] == b['bar']]
        lo, hi = min(ps), max(ps)
        assert hi - lo <= 12
        ranges.append((lo, hi))
    layer = {p: (0.0, [p]) for p in range(ranges[0][1] - 12, ranges[0][0] + 1)}
    for lo, hi in ranges[1:]:
        next_layer = {}
        for pos in range(hi - 12, lo + 1):
            candidates = [(cost + abs(pos - prev) + .001 * abs(pos - lo), path + [pos])
                          for prev, (cost, path) in layer.items() if abs(pos - prev) <= 4]
            if candidates: next_layer[pos] = min(candidates, key=lambda x: (x[0], x[1]))
        assert next_layer, 'RH cannot retain the requested unchanged line with the stated position model'
        layer = next_layer
    _, path = min(layer.values(), key=lambda x: (x[0], x[1]))
    plan = []
    for i, (position, (lo, hi)) in enumerate(zip(path, ranges)):
        movement = abs(position - path[i - 1]) if i else 0
        plan.append({'bar': i + 1, 'hand_window': [position, position + 12], 'actual_pitch_range': [lo, hi],
                     'position_translation_semitones': movement, 'required_large_translation_seconds': required_seconds(movement)})
    return {'scope': 'Explicit octave-width right-hand position for each complete bar, including the final inner chord. Single-note finger intervals inside this window are not whole-hand translations.',
            'notes_unchanged_from_v2': True, 'maximum_position_translation_semitones': max(x['position_translation_semitones'] for x in plan),
            'position_width_semitones': 12, 'plan': plan}

def make_v3(v2):
    s = copy.deepcopy(v2)
    s['version'] = 'v3'
    # Lower the short eighth-note LH pickups in the active sections. The same
    # harmony tone now lies near the following bass rather than above the grip.
    for e in s['events']:
        rel = e['onset'] - s['bars'][e['bar'] - 1]['start']
        if e['hand'] == 'left' and e['voice'] == 'accompaniment' and abs(rel - 4) < 1e-8:
            e['pitch'] -= 12
    # The three-note tenor answers arrive a quarter beat earlier. Their final
    # note keeps a meaningful gate, while the hand can leave for the next bass.
    for number in range(41, 57):
        ns = [e for e in s['events'] if e['bar'] == number and e['voice'] == 'countermelody']
        if len(ns) == 4:
            for e in ns:
                rel = e['onset'] - s['bars'][number - 1]['start']
                if abs(rel - 1.5) < 1e-8: e['duration'] = 1.20
                else:
                    e['onset'] = round(e['onset'] - .25, 6)
                    if abs(rel - 4) < 1e-8: e['duration'] = .33
    s['events'].sort(key=lambda e: (e['onset'], e['pitch'], e['voice']))
    # Size every remaining release gap using grip edges and a 30ms safety margin.
    # No event moves to the other hand; no pedal sustain enters this calculation.
    prior = []
    for (ta, old), (tb, new) in zip(groups(s, 'left'), groups(s, 'left')[1:]):
        prior.extend(old)
        source = [e for e in prior if e['onset'] <= ta and e['onset'] + e['duration'] > ta + 1e-8]
        a0, a1 = min(e['pitch'] for e in source), max(e['pitch'] for e in source)
        b0, b1 = min(e['pitch'] for e in new), max(e['pitch'] for e in new)
        movement = max(abs(a0 - b0), abs(a1 - b1))
        if movement <= 4: continue
        deadline_seconds = time_at(s, tb) - required_seconds(movement) - MARGIN
        deadline = beat_at(s, deadline_seconds)
        for e in prior:
            if e['onset'] + e['duration'] > deadline:
                dur = math.floor((deadline - e['onset']) * 1000000) / 1000000
                assert dur >= .15, ('Support needs a musical redesign, not a vanishing note', e, dur)
                e['duration'] = dur
    # Immutable features are checked as content, not merely counts or labels.
    assert [e for e in s['events'] if e['hand'] == 'right'] == [e for e in v2['events'] if e['hand'] == 'right']
    for key in ('bars', 'pedals', 'total_beats', 'tail_seconds', 'id', 'title', 'title_zh'):
        assert s[key] == v2[key]
    return s

def main():
    assert sha(OUT / 'score_v2.json') == EXPECTED_V2
    v2 = json.loads((OUT / 'score_v2.json').read_text())
    s = make_v3(v2)
    base = original.audit(s)
    strict_old = left_hand_travel(v2)
    strict_new = left_hand_travel(s)
    rh = right_hand_positions(s)
    base['previous_checker_limit'] = 'The historical center-distance thresholds were insufficient for some LH transfers; the following grip-edge check supersedes that old travel criterion.'
    base['strict_left_hand_travel'] = {'criterion': 'For actual whole-grip edge displacement d > 4 semitones, required released travel = 0.075 + 0.012*(d-4) seconds. Releases of all earlier keys are included. Pedal is excluded.',
        'construction_margin_seconds': MARGIN, 'checked_transfers': len(strict_new),
        'failed_transfer_count': sum(not t['passed'] for t in strict_new),
        'minimum_margin_seconds': min(t['margin_seconds'] for t in strict_new), 'transfers': strict_new}
    base['right_hand_position_plan'] = rh
    base['v2_rechecked_with_strict_rule'] = {'checked_transfers': len(strict_old),
        'failed_transfer_count': sum(not t['passed'] for t in strict_old), 'failures': [t for t in strict_old if not t['passed']]}
    base['preserved_from_v2'] = {'all_right_hand_events_exact': True, 'bars_harmony_form_tempo_exact': True,
                                 'pedals_exact': True, 'total_duration_exact': True}
    base['passed'] = base['passed'] and all(t['passed'] for t in strict_new)
    dump('score_v3.json', s)
    dump('score.json', s)
    dump('audit_v3.json', base)
    dump('exact_diff_v2_to_v3.json', original.differences(v2, s))
    dump('right_hand_position_plan_v3.json', rh)
    print(json.dumps({'passed': base['passed'], 'score_sha256': sha(OUT / 'score.json'),
                      'old_strict_failures': base['v2_rechecked_with_strict_rule']['failed_transfer_count'],
                      'new_strict_failures': base['strict_left_hand_travel']['failed_transfer_count'],
                      'min_margin_seconds': base['strict_left_hand_travel']['minimum_margin_seconds'],
                      'rh_max_position_shift': rh['maximum_position_translation_semitones']}, indent=2))
    if not base['passed']: raise SystemExit(1)

if __name__ == '__main__': main()
