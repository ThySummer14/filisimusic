# Technical audit — work 72

All three complete written scores pass the generator audit and a separate JSON-only validator. No audio was rendered or heard. The audit is about event structure and stated timing; it does not certify subjective musical quality.

## Full-score results

| Version | Bars | Events | Duration + 4 s tail | Flute max nominal gate | Clarinet max nominal gate |
|---|---:|---:|---:|---:|---:|
| v0 | 96 | 390 | 176.959140 s | 1.032258 s | 0.709677 s |
| v1 | 96 | 392 | 176.959140 s | 1.032258 s | 0.709677 s |
| v2 | 96 | 382 | 176.959140 s | 0.709677 s | 1.032258 s |

## v2 instrument and phrase boundaries

| Check | Flute | Clarinet |
|---|---:|---:|
| Event count | 172 | 210 |
| Lowest MIDI pitch | 72 | 60 |
| Highest MIDI pitch | 83 | 71 |
| Lowest velocity | 32 | 30 |
| Highest velocity | 79 | 79 |
| Longest nominal gate (seconds) | 0.70967742 | 1.032258064 |
| Shortest adjacent note gap (seconds) | 0.222222222 | 0.222222222 |
| Shortest phrase breath (seconds) | 1.033333333 | 1.033333334 |

- Both instruments are monophonic, with 24 instrument-specific phrases each (48 phrase annotations).
- All events are either actual pp (21–55) or mf (56–95); each instrument uses one layer per phrase. No ff events.
- Flute nominal gates are below 1.35 s; clarinet gates are below 1.50 s. All versions additionally pass flute nominal gate + 209 ms ≤ 1.35 s.
- In v2 the flute worst-case advanced gate is 0.918677420 s. Its shortest target-time note gap is 0.222222222 s, exceeding 209 ms by 13.222 ms.
- Flute shortest phrase breath is 1.033333333 s before compensation (requirement ≥0.85 s), or 0.824333333 s after a conservative 209 ms advance of the following phrase.
- Clarinet shortest phrase breath is 1.033333334 s (requirement ≥0.60 s).
- The first flute target is 0.000 s. A 209 ms advance would produce a −0.209 s trigger without pre-roll. Recommended global pre-roll is 0.5 s, leaving the first trigger at +0.291 s. Offset both voices together; never clamp the first flute trigger.
- The above durations exclude pre-roll and include the requested four-second final tail window.

## Foreground and harmonic support

- 253 lead events and 129 support events. Exactly one foreground instrument is designated in every bar.
- All support is pp, sparse, and contained inside a foreground note. No support events play a separate melody over a lead rest.
- Zero overlapping pitch-class dissonances under the conservative allowed set {0,3,4,7,8,9}; no fourth-above-bass exemption is used.
- Maximum within-phrase lead leap: flute 5 semitones; clarinet 7 semitones.
- Bars 67–68 contain only clarinet, giving the future owner a solo preview before the final A return.
- No pedals, sustain loops, legato mechanism, overlapping same-voice gates, audio loops, extra instruments or long-held accompaniment pads.

## Formal checks and revisions

- A melody at bars 1–8 equals 33–40 in pitch, onset and duration.
- A melody at bars 1–8 equals 69–76 after octave-normalizing the clarinet part. This is an intentional audible identity, not a uniqueness metric failure.
- v0→v1: 29 changed bars, including 25 with changed foreground notes.
- v1→v2: 27 changed bars, including 26 with changed foreground notes.
- 96 consecutive 3/4 bars / 288 quarter beats. Tempo integration independently confirms 172.959139785 s before the tail and 176.959139785 s with it.

## Exact integration semantics

`onset` and `duration` use absolute quarter beats and quarter-beat lengths, respectively. Each event adds `target_on_beats`, `target_off_beats`, `target_on_seconds` and `target_off_seconds`.

For flute, onset means intended pitched arrival, and `onset_reference` is `pitched_arrival`. No compensation is applied in these files. For clarinet, onset is the ordinary trigger and `onset_reference` is `ordinary_trigger`.

Instrument-specific phrase IDs are `P01_flute` … `P24_flute` and `P01_clarinet` … `P24_clarinet`. They are not interchangeable across instruments: the same four-bar phrase may use mf flute / pp clarinet, or pp flute / mf clarinet. The per-event `layer` is the sample layer, not just a prose dynamic mark.

## Reproducibility and limits

`generate_score.py` uses only the Python standard library and hard-coded original material. It uses no random numbers, external files, time stamps, renderer, shell subcommands or network. Reconstructing all three scores independently produces identical serialized content; SHA-256 values are saved. `verify_score.py` separately reads only the JSON scores and checks timing, registers, layers, breaths, support intervals and opening pre-roll.

The checks cannot establish beautiful phrasing, perceived instrument balance, exact sample length, attack alignment, acoustic note overlap or the quality of a rendered ending. In particular, the parent must apply its actual pitch/layer flute correction once and check real release tails and audible breathing.
