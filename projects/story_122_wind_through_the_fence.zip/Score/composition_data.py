"""An original nominal piano/flute score. Pitches and bar order are authored here.
Pitch names use scientific pitch notation. No random generator or imported music.
"""
from copy import deepcopy
ID=122
TITLE='Wind Through the Gap in the Fence'
TITLE_ZH='篱笆缺口的风'
INSTRUMENT='flute'
BEATS=3
METER=(6,8)
TAIL=4.0
HARMONIES={
 'C':(48,[0,4,7]),'Csus':(48,[0,5,7]),'C7':(48,[0,4,7,10]),
 'F':(41,[5,9,0]),'F6':(41,[5,9,0,2]),'Bb':(46,[10,2,5]),
 'Gm':(43,[7,10,2]),'G':(43,[7,11,2]),'G7':(43,[7,11,2,5]),
 'Dm':(50,[2,5,9]),'Am':(45,[9,0,4]),'Eb':(51,[3,7,10]),
 'Fm':(41,[5,8,0]),'Ab':(44,[8,0,3]),'D7':(50,[2,6,9,0]),
}
# Each line: harmony | six independently authored RH pitches | four LH pitches |
# flute pitches (a dash is a written breath) | RH rhythm. All notes are nominal.
# Seven unequal paragraphs: 11 + 12 + 15 + 13 + 17 + 14 + 10 measures.
PARAGRAPHS=[
('A_a_gap_left_for_the_wind',80,'''\
C|G4 C5 E5 D5 C5 B4|C3 G3 E3 G3|G5 E5|a
C7|E5 D5 C5 Bb4 G4 A4|E3 G3 Bb3 G3|D5 C5|b
F|A4 C5 D5 C5 A4 G4|F3 C4 A3 G3|F5 A5|c
Gm|Bb4 A4 G4 D5 C5 Bb4|G3 D3 Bb3 A3|G5|a
C|G4 E5 D5 C5 G4 E4|E3 G3 C3 D3|-|d
Bb|F4 Bb4 D5 F5 Eb5 D5|D3 F3 Bb3 A3|F5 D5|b
F|C5 A4 G4 F4 G4 A4|A3 C4 F3 E3|C5|a
Dm|A4 F4 E4 D4 F4 A4|D3 A3 F3 E3|-|c
Gm|D5 C5 Bb4 G4 A4 Bb4|Bb3 A3 G3 F3|D5 G5|d
F|C5 D5 C5 A4 G4 F4|A3 G3 F3 C3|A5 G5|b
C|E4 G4 C5 G4 E4 D4|C3 E3 G3 E3|E5|a
'''),
('B_the_paper_bird_takes_the_wrong_turn',84,'''\
C|C5 E5 G5 E5 D5 C5|E3 G3 C4 B3|C5 G5|c
Gm|D5 F5 E5 D5 Bb4 A4|G3 Bb3 D3 F3|Bb5 A5|b
Bb|Bb4 D5 F5 D5 C5 Bb4|D3 F3 Bb3 G3|F5|a
F|A4 G4 F4 C5 A4 G4|C3 G3 A3 C4|-|d
Dm|F5 E5 D5 A4 C5 D5|F3 A3 D3 E3|F5 E5|c
Am|E5 D5 C5 A4 G4 E4|C3 E3 A3 G3|C5|b
F|F4 A4 C5 A4 G4 F4|A3 G3 F3 E3|-|a
Bb|D5 F5 Bb5 F5 D5 C5|Bb3 A3 F3 D3|D5 F5|d
Eb|G5 F5 Eb5 Bb4 C5 D5|Eb3 Bb3 G3 F3|G5 Bb5|b
Gm|D5 Bb4 A4 G4 F4 D4|D3 F3 Bb3 A3|G5|a
F|A4 C5 F5 C5 D5 A4|F3 G3 A3 C4|F5 A5|c
Csus|G4 C5 D5 F5 E5 D5|C3 D3 F3 G3|G5|d
'''),
('C_rain_names_each_post',78,'''\
Fm|C5 Ab4 G4 F4 G4 Ab4|F3 C3 Ab3 G3|C5|d
Ab|Eb5 C5 Bb4 Ab4 G4 Eb4|C3 Eb3 Ab3 G3|Eb5 C5|a
Eb|G4 Bb4 Eb5 Bb4 Ab4 G4|Eb3 G3 Bb3 Ab3|Bb5 G5|b
Bb|F4 D5 C5 Bb4 A4 F4|D3 F3 Bb3 A3|-|c
Fm|Ab4 C5 F5 C5 Bb4 Ab4|Ab3 G3 F3 Eb3|F5 Ab5|a
Ab|C5 Eb5 Ab5 Eb5 D5 C5|Eb3 F3 Ab3 Bb3|C5|b
Eb|Bb4 G4 F4 Eb4 F4 G4|G3 F3 Eb3 Bb2|-|d
Gm|D5 Bb4 A4 G4 Bb4 D5|G3 A3 Bb3 D3|D5 Bb5|a
Dm|F5 E5 D5 A4 G4 F4|F3 E3 D3 A2|A5 F5|c
Gm|Bb4 A4 G4 D5 C5 Bb4|Bb3 A3 G3 D3|G5|b
Eb|Eb5 F5 G5 Bb5 Ab5 G5|Eb3 G3 Bb3 A3|-|a
Fm|Ab5 G5 F5 C5 Eb5 F5|C3 Eb3 Ab3 G3|Ab5 F5|d
Bb|D5 Eb5 F5 Bb5 A5 F5|Bb3 A3 F3 D3|D5 F5|b
G7|B4 D5 F5 D5 C5 B4|G3 F3 D3 B2|G5|c
C|E5 D5 C5 G4 A4 G4|E3 D3 C3 G2|E5 C5|a
'''),
('D_the_child_refuses_the_shortcut',88,'''\
Am|A4 E5 D5 C5 E5 G5|A3 G3 E3 C3|E5|c
Dm|F5 A5 G5 F5 E5 D5|F3 E3 D3 A2|A5 F5|b
D7|D5 F#5 A5 F#5 E5 D5|D3 A3 F#3 E3|F#5 A5|a
Gm|Bb4 D5 G5 D5 C5 Bb4|G3 F3 D3 Bb2|-|d
Eb|Eb5 G5 Bb5 G5 F5 Eb5|Bb3 G3 Eb3 F3|G5 Bb5|c
Bb|D5 F5 Bb5 F5 Eb5 D5|D3 C3 Bb2 F3|F5|a
F|C5 D5 E5 F5 E5 C5|A3 G3 F3 C3|-|b
C7|E5 G5 Bb5 G5 F5 E5|E3 F3 G3 Bb3|Bb5 G5|c
F|A5 G5 F5 C5 D5 E5|F3 A3 C4 B3|A5 F5|d
Dm|F5 E5 D5 A4 F4 E4|A3 G3 F3 D3|D5|b
Bb|D5 F5 G5 F5 Eb5 D5|Bb2 D3 F3 A3|-|a
G7|B4 C5 D5 F5 E5 D5|B2 D3 G3 F3|F5 D5|c
C|E5 G5 C6 G5 E5 D5|C3 E3 G3 B3|G5 E5|b
'''),
('E_two_hands_hold_the_broken_crosspiece',92,'''\
C7|G5 E5 D5 C5 E5 G5|C3 G3 E3 Bb3|Bb5 G5|c
Bb|F5 D5 C5 Bb4 D5 F5|D3 Bb3 F3 A3|F5 D5|b
F|A4 C5 E5 F5 A5 G5|F3 A3 C4 G3|C5 F5|a
Gm|G5 F5 D5 Bb4 A4 G4|Bb3 G3 D3 F3|-|c
Am|E5 C5 A4 E4 G4 A4|A3 E3 C3 G3|E5 A5|d
Dm|D5 F5 A5 F5 E5 D5|D3 F3 A3 G3|F5|b
G7|F5 E5 D5 B4 A4 G4|B3 A3 G3 D3|-|c
C|E5 G5 C6 G5 F5 E5|E3 D3 C3 G3|G5 E5|a
Ab|Eb5 G5 Ab5 C6 Bb5 Ab5|Ab3 G3 Eb3 C3|Ab5 C5|b
Fm|C6 Bb5 Ab5 F5 G5 Ab5|F3 Ab3 C4 Eb3|F5 Ab5|d
Eb|Bb5 Ab5 G5 Eb5 F5 G5|G3 Eb3 Bb2 F3|G5|c
Bb|F5 Eb5 D5 Bb4 C5 D5|Bb3 F3 D3 C3|-|a
D7|A4 C5 D5 F#5 E5 D5|F#3 E3 D3 A3|F#5 A5|b
Gm|D5 G5 Bb5 G5 F5 D5|G3 Bb3 D3 F3|G5 D5|c
G7|B5 A5 G5 F5 E5 D5|B3 A3 G3 F3|F5|d
Csus|F5 E5 D5 C5 G4 A4|F3 D3 C3 G3|-|b
C|E5 D5 C5 G4 E4 G4|E3 D3 C3 G2|E5 C5|a
'''),
('F_the_neighbor_brings_no_nails',84,'''\
F|A4 F4 G4 C5 A4 G4|F3 A3 C4 G3|F5 A5|d
C|G4 C5 D5 E5 G5 E5|E3 D3 C3 G3|G5|a
Bb|D5 Bb4 C5 F5 D5 C5|Bb3 A3 F3 D3|-|b
Gm|Bb4 G4 A4 D5 C5 Bb4|G3 D3 Bb2 F3|D5 G5|c
Dm|A4 D5 E5 F5 A5 F5|F3 E3 D3 A3|A5 F5|a
Am|E5 C5 D5 A4 G4 E4|A3 G3 E3 C3|E5|d
F|C5 A4 G4 F4 A4 C5|A3 G3 F3 C3|-|b
Bb|F5 D5 C5 Bb4 D5 F5|D3 F3 Bb3 A3|D5 F5|a
Eb|G5 Eb5 F5 Bb4 Ab4 G4|Eb3 G3 Bb3 Ab3|G5 Bb5|c
Gm|D5 Bb4 C5 G4 A4 Bb4|D3 F3 G3 Bb3|G5|d
F|A4 C5 D5 F5 E5 C5|F3 G3 A3 C4|-|b
C7|E5 G5 Bb5 G5 E5 D5|E3 G3 Bb3 A3|Bb5 G5|a
F|C5 A4 G4 F4 G4 A4|A3 G3 F3 C3|A5 F5|c
C|G4 E5 D5 C5 E4 G4|C3 D3 E3 G3|E5|d
'''),
('G_a_gate_that_opens_in_both_directions',76,'''\
C|G4 C5 E5 G5 E5 D5|E3 G3 C4 B3|C5 G5|a
Bb|F5 D5 C5 Bb4 A4 F4|D3 F3 Bb3 A3|F5|b
F|A4 C5 D5 C5 A4 G4|F3 C3 A3 G3|-|d
Dm|F4 A4 C5 A4 G4 F4|D3 A3 F3 E3|D5 F5|c
Gm|Bb4 A4 G4 D5 C5 Bb4|Bb3 A3 G3 D3|G5|b
F|A4 G4 F4 C5 A4 G4|A3 G3 F3 C3|-|a
Csus|F4 G4 C5 G4 F4 D4|C3 D3 F3 G3|F5 D5|d
C|E4 G4 C5 G4 E4 D4|E3 D3 C3 G2|E5 C5|a
F|A4 G4 F4 C5 A4 G4|F3 C3 A3 G3|-|b
C|G4 C5 E5 C5 G4 C4|C3 G3 E3 C3|C5|d
''')]

RHYTHMS={'a':[0,.5,1,1.5,2,2.5],'b':[0,.5,1,1.5,2.25,2.75],
 'c':[0,.25,.75,1.5,2,2.5],'d':[0,.75,1.25,1.5,2,2.5]}
def pitch(s):
 base={'C':0,'D':2,'E':4,'F':5,'G':7,'A':9,'B':11}[s[0]]
 return 12*(int(s[-1])+1)+base+(1 if '#' in s else -1 if 'b' in s else 0)
def build(level):
 bars=[];events=[];pedals=[];phrase_map=[];n=0
 for section,bpm,txt in PARAGRAPHS:
  first=n+1
  rows=[x.split('|') for x in txt.strip().splitlines()]
  for j,(harm,upper,lower,wind,pattern) in enumerate(rows):
   n+=1;start=(n-1)*BEATS
   # Only written tempo changes: each paragraph leans toward its final question.
   tempo=bpm+(2 if section.startswith(('B','D','E')) and j>=len(rows)//2 else 0)
   if n in (11,23,38,51,68,82,90,91,92):tempo-=4 if n<90 else (n-89)*2
   root,pcs=HARMONIES[harm]
   bars.append(dict(bar=n,start=start,beats=BEATS,bpm=tempo,meter_numerator=6,meter_denominator=8,section=section,harmony_name=harm,harmony=[root]+[60+x for x in pcs]))
   upper=list(map(pitch,upper.split()));lower=list(map(pitch,lower.split()))
   # v1: the answering LH line is rewritten across complete unequal paragraphs.
   if level>=1 and n in (12,13,14,16,18,19,20,21,39,40,42,43,45,47,49,50):
    lower=[lower[0],lower[3],lower[2],lower[1]]
   if level>=1 and n in (6,17,30,44,58,70,83,88):
    # A real upper-register answer, not a transposition of the entire piece.
    upper[-2:]=[upper[3]+(2 if upper[3]%12 in (0,2,5,7,9,10) else 1),upper[3]]
   rt=RHYTHMS[pattern][:]
   # v2: hinge-bars acquire a sixteenth flick; following notes retain their time.
   if level>=2 and n in (53,55,57,59,61,63,65,67):
    rt=[0,.25,.5,1,1.5,2,2.5]
    upper=[upper[0],upper[0]-2,upper[1],upper[2],upper[3],upper[4],upper[5]]
   if level>=2 and n in (84,86,89,91):
    upper[-2:]=[upper[3]-2,upper[3]]
   lt=[0,.75,1.5,2.25]
   if level>=1 and n in (12,14,16,19,21,39,42,45,49):lt=[0,1,1.5,2.5]
   def add(inst,vo,hand,p,t,d,v,art):
    events.append(dict(bar=n,onset=round(start+t,6),duration=round(d,6),pitch=p,velocity=v,instrument=inst,voice=vo,hand=hand,articulation=art))
   dyn=58 if section.startswith(('A','G')) else 62 if section.startswith(('C','F')) else 73 if section.startswith('E') else 67
   air_handoffs=(24,26,28,75,77)
   shadow_holds=(25,29,74,76,78)
   if level>=2 and n in air_handoffs:
    # The beginning of the bird motif stops at the fence: a full second
    # half-bar is given to flute, not filled with accompaniment figures.
    rt=[0,.5,1];upper=upper[:3];lt=[0];lower=lower[:1]
   elif level>=2 and n in shadow_holds:
    rt=[0,1.5];upper=[upper[0],upper[3]]
    lt=[.75,2.25];lower=[lower[0],lower[2]]
   elif level>=2 and n==27:
    rt=[0,1.5];upper=[upper[0],upper[3]];lt=[.75,2.25];lower=[lower[0],lower[2]]
   for k,(t,p) in enumerate(zip(rt,upper)):
    following=rt[k+1] if k+1<len(rt) else 3
    dur=min(following-t-.045,1.20 if level>=2 and n in shadow_holds else .62 if pattern=='d' else .47)
    if level>=2 and n in air_handoffs:dur=min(dur,1.44-t)
    add('piano','paper_bird_subject','right',p,t,dur,dyn+(5 if t in (0,1.5) else -3)+(2 if k==len(rt)-1 else 0),'cantabile_detached')
   for k,(t,p) in enumerate(zip(lt,lower)):
    following=lt[k+1] if k+1<len(lt) else 3
    dur=min(following-t-.055,1.10 if level>=2 and n in air_handoffs else .61)
    add('piano','fence_post_countermelody','left',p,t,dur,dyn-10+(4 if k in (0,2) else 0),'nonlegato')
   ww=[] if wind=='-' else list(map(pitch,wind.split()))
   if level>=2 and n in (24,29,33,40,48,74,79,87):
    # The breath answer rises or falls by a real phrase extension within C5–B5.
    ww=[ww[0] if ww else 79, 72+pcs[-1]]
   if level>=2:
    ww={24:[72,80],25:[75,72],26:[82,79],27:[77],28:[77,80],29:[75,72],74:[76,72],75:[77,81],76:[74,77],77:[79,82],78:[79]}.get(n,ww)
   for k,p in enumerate(ww):
    wt=.5 if k==0 else 2
    gate=1.16 if len(ww)==1 else .78
    v=51 if section.startswith(('A','C','G')) else 70 if section.startswith('E') else 61
    add('flute','wind_at_the_missing_board','none',p,wt,gate,v-(3 if k else 0),'separated_vibrato')
   pedals.append(dict(bar=n,onset=start,controller=64,value=0,instrument='piano'))
  phrase_map.append(dict(first_bar=first,last_bar=n,design=section,independent_subjects=['paper_bird_subject','fence_post_countermelody','wind_at_the_missing_board']))
 assert n==92,n
 pedals.append(dict(bar=n,onset=BEATS*n-.01,controller=64,value=0,instrument='piano'))
 return dict(id=ID,title=TITLE,title_zh=TITLE_ZH,version=f'v{level}',bars=bars,events=events,pedals=pedals,total_beats=BEATS*n,tail_seconds=TAIL,instrument_map={'piano':'piano','flute':'flute'},phrase_map=phrase_map,nominal_onsets_no_sample_compensation=True)
RENDERER_NOTES='Nominal score only. Use real acoustic piano and verified Iowa C5–B5 pp/mf flute. Do not edit source onsets for sample delay. Initial flute entrance is a written eighth-note rest. Whole wind gates and next-trigger gaps are independently audited using the embedded exact mapping values. No sustain pedal is requested; the two piano lines remain separately articulated.'
