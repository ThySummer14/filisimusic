from pathlib import Path
import json,subprocess,re,os,hashlib,wave
P=Path(__file__).parent;R=P.parent;V=P/'revisions';O=Path('DELIVERABLES')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def run(cmd,log):subprocess.run(['python',str(R/'tools/run_bounded.py'),'--seconds','60','--rss-mb','400','--lock-wait-seconds','90','--log',str(log),'--',*map(str,cmd)],check=True)
def native(p,log):run([R/'tools/reaper_linux_x86_64/REAPER/reaper','-cfgfile',R/'runtime_test/reaper.ini','-nosplash','-renderproject',p],log)
expected=[{'D_VOL':3.2,'D_PAN':-.10,'D_WIDTH':.8,'D_PANLAW':1,'I_PANMODE':5},{'D_VOL':7.2,'D_PAN':.16,'D_WIDTH':1,'D_PANLAW':1,'I_PANMODE':5}];got={}
for l in (V/'verified_final_native.tsv').read_text().splitlines():
 i,k,val=l.split('\t');got[(int(i),k)]=float(val)
for i,e in enumerate(expected,1):
 for k,v in e.items():assert abs(got[(i,k)]-v)<1e-8
(V/'verified_final_native.json').write_text(json.dumps({'actual_API_readback':True,'save_and_reopen_verified':True,'intent':expected},indent=2));proof=json.loads((V/'source_completeness_final.json').read_text());assert all(x['full_file_and_PCM_exact'] for x in proof.values())
project=V/'080_kites_v4.rpp';master=V/'080_kites_v4.wav';
if not master.exists():native(project,V/'native_master_render.log')
run(['python',R/'tools/qa_pcm.py',master,'--score',P/'ensemble_score.json'],V/'native_master_qa.log');qa=json.loads(master.with_suffix('.qa.json').read_text());assert qa['clipped_samples']==0
stage=P/'standalone_v4';(stage/'Media').mkdir(parents=True,exist_ok=True);text=project.read_text();stems={};base='080_quarry_kites_v4'
for instrument in ['piano','flute']:
 source=V/(instrument+'_v3.wav');stems[instrument]=str(source);target=stage/'Media'/(instrument+'_float32.wav')
 if not target.exists():os.link(source,target)
 assert sha(source)==sha(target)
 old_path='FILE "'+source.name+'"';assert old_path in text
 text=text.replace(old_path,'FILE "Media/'+instrument+'_float32.wav"')
text=re.sub(r'(?m)^\s*RENDER_FILE .*$', '  RENDER_FILE "Renders"',text);text=re.sub(r'(?m)^\s*RENDER_PATTERN .*\n','',text);text=text.replace('  RENDER_FMT','  RENDER_PATTERN "$project"\n  RENDER_FMT',1);portable=stage/(base+'.rpp');portable.write_text(text);native(portable,V/'portable_reopen_render.log')
with wave.open(str(master),'rb') as w:x=w.readframes(w.getnframes());params=w.getparams()
with wave.open(str(stage/'Renders'/(base+'.wav')),'rb') as w:y=w.readframes(w.getnframes());assert params==w.getparams() and x==y
(V/'portable_project_verification.json').write_text(json.dumps({'actual_reaper_reopen_and_export':True,'all_media_paths_relative':True,'pcm_identical_to_canonical':True,'pcm_sha256':hashlib.sha256(x).hexdigest(),'separate_source_completeness':'source_completeness_final.json'},indent=2));del x,y
mp3=O/'080_静采石场上空的风筝_v4.mp3';assert not mp3.exists();run(['ffmpeg','-hide_banner','-loglevel','error','-threads','1','-i',master,'-codec:a','libmp3lame','-b:a','192k',mp3],V/'mp3_encode.log');run(['ffmpeg','-hide_banner','-loglevel','error','-threads','1','-i',mp3,'-f','null','-'],V/'mp3_decode.log')
j={'work_id':80,'piece_dir':str(P),'title_zh':'静采石场上空的风筝','version':'v4','master':str(master),'project':str(project),'portable_project':str(portable),'stage':str(stage),'stems':stems,'mp3':str(mp3),'artifact_base':base,'master_sha256':sha(master),'mp3_sha256':sha(mp3),'source_completeness':str(V/'source_completeness_final.json'),'portable_verification':str(V/'portable_project_verification.json'),'native_settings':str(V/'verified_final_native.json'),'full_human_listening_pending':True,'packaging_pending':True};(P/'verified_final_job.json').write_text(json.dumps(j,ensure_ascii=False,indent=2));print('Verified80',qa['duration'],qa['peak_dbfs'])
