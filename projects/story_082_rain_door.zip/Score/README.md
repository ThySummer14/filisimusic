# Work 082 — A Door Painted on the Rain / 画在雨上的门

Original, symbolic-only solo-piano ballad for the existing approved Moonlight instrument. 60 bars, 240 quarter-note beats, about 3:25.5 including a five-second tail. This package contains no audio and performs no instrument acquisition, render, installation or publication.

## Files

- score.json — final score; byte-identical to score_v2.json
- score_v0.json, score_v1.json, score_v2.json — three complete compositional versions
- generate_score.py — deterministic standard-library Python generator, score writer, exact diffs and audits
- story_zh.md — original Chinese story and action-to-music mapping
- form_and_performance.md — form, timeline, harmony, piano articulation, pedal and interpretation notes
- revision_notes.md — substantive musical revision descriptions and exact changed-bar/count summaries
- exact_diff_v0_to_v1.json, exact_diff_v1_to_v2.json — full removed/added event records and changed bar metadata
- audit_v0.json, audit_v1.json, audit_v2.json — actual held-hand-span, all-active same-key, wide-transfer release-time, phrase and cadence checks
- SHA256.json — exact SHA-256 hashes of all three scores, final score and generator

Run `python generate_score.py` to regenerate the four scores, three audits, two diffs and hash manifest. It uses one process, no imports outside the Python standard library, and no random numbers. Text notes are editorial source files and are preserved.

## Final review state

All symbolic audits pass. Largest held left-hand span is 11 semitones; right-hand melody is monophonic. There are no overlapping same-key note lifetimes. The score reserves genuine finger-release travel time before wide left-hand moves. Fifteen four-bar phrases and seven major cadence points are reported explicitly. The 301-note melody has a maximum leap of six semitones and stays connected throughout.

This is a score-stage deliverable. The owner handles sampling, native APIs, REAPER project assembly, playback and any listening-based revision. No audible result is claimed here.
