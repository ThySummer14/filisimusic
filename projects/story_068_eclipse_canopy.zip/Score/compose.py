#!/usr/bin/env python3
"""Original, non-rendered piano/flute score. Python standard library only.
Score flute onsets are intended PITCHED arrivals, not sampler trigger times.
Run: python3 compose.py ; python3 verify_score.py
"""
from pathlib import Path
from collections import Counter
from copy import deepcopy
import hashlib, json
ROOT=Path(__file__).resolve().parent

# Concrete, narrow left-hand voicings; no bass line independent of harmony.
CHORDS={
'D':([2,6,9],[50,54,57],[62,66,69]),
'D6':([2,6,9,11],[50,54,57,59],[62,66,69]),
'Dadd9':([2,4,6,9],[50,52,54,57],[62,66,69]),
'D/F#':([2,6,9],[42,45,50,54],[62,66,69]),
'A':([9,1,4],[45,49,52,57],[61,64,69]),
'A7':([9,1,4,7],[45,49,52,55],[61,64,67]),
'Aadd9':([9,1,4,11],[45,49,52,59],[61,64,69]),
'A/C#':([9,1,4],[49,52,57],[61,64,69]),
'Bm':([11,2,6],[47,50,54],[62,66,71]),
'Bm7':([11,2,6,9],[47,50,54,57],[62,66,69]),
'G':([7,11,2],[43,47,50],[62,67,71]),
'G6':([7,11,2,4],[43,47,50,52],[62,64,67]),
'Gmaj7':([7,11,2,6],[43,47,50,54],[62,66,67]),
'Gmaj9':([7,11,2,6,9],[43,47,50,54],[62,66,69]),
'Em7':([4,7,11,2],[40,43,47,50],[62,64,67]),
'Em9':([4,7,11,2,6],[40,43,47,50],[62,66,67]),
'F#7':([6,10,1,4],[42,46,49,52],[61,64,66]),
'F#sus4':([6,11,1],[42,47,49,54],[61,66,71]),
'Cadd9':([0,2,4,7],[48,50,52,55],[60,64,67]),
}
# Form is 80 x 4/4, with eight purposeful tempo areas, not a metric exercise.
FORM=[(1,4,112,'I｜暮丝张开'),(5,16,112,'II｜为中央缝太阳'),
      (17,28,108,'III｜棚外传来的数数声'),(29,40,120,'IV｜影子跑过广场'),
      (41,48,100,'V｜剪开金色圆心'),(49,64,116,'VI｜把圆心缝成边缘'),
      (65,72,108,'VII｜棚下终于数得齐'),(73,80,108,'VIII｜留给太阳的空口')]
HARMONIES=[
'D','A/C#','Bm7','A7',                                  # 1–4
'D','Bm7','G','A7','D/F#','Em7','G','A7','Bm7','Gmaj7','Em7','A7', # 5–16
'D6','Aadd9','Bm7','G','Em7','A7','G6','D/F#','Bm7','Gmaj7','Em7','A7', #17–28
'Bm','F#7','Bm7','Em7','G','D/F#','Em7','F#7','Bm','G','Em7','F#7', #29–40
'Bm','F#sus4','Gmaj7','D/F#','Em7','Cadd9','A7','A7', #41–48
'D','Bm7','G','A7','D/F#','Em7','G','A7','Bm7','Gmaj7','Em7','A7', #49–60 baseline
'D','G','A7','D',                                      #61–64
'Gmaj9','G6','Em7','A7','Dadd9','Bm7','Em9','A7',      #65–72
'D','A/C#','Bm7','G','Em7','A7','D','D'               #73–80
]
# Hand-composed, explicit rhythm/pitch pairs. None are imported from another work.
# A pair is (MIDI pitch or None for a rest, duration in quarter beats).
M0={
1:[(74,1.5),(None,.5),(69,1),(None,1)],
2:[(73,1),(76,1),(69,1.5),(None,.5)],
3:[(71,1),(74,.5),(78,.5),(76,1),(74,1)],
4:[(73,1.5),(69,1),(None,.5),(71,.5),(73,.5)],
5:[(74,1),(78,.5),(76,.5),(71,1),(69,1)],
6:[(66,.5),(69,.5),(71,1),(74,1.5),(None,.5)],
7:[(71,1.5),(74,.5),(79,1),(78,.5),(76,.5)],
8:[(73,1),(76,1),(69,1.5),(None,.5)],
9:[(78,1),(76,.5),(74,.5),(69,1),(66,1)],
10:[(67,.5),(71,.5),(76,1),(74,1),(71,1)],
11:[(74,1),(79,1.5),(78,.5),(76,.5),(74,.5)],
12:[(73,1.5),(71,.5),(69,1),(None,1)],
13:[(78,.5),(76,.5),(74,1),(71,1),(74,1)],
14:[(79,1),(78,.5),(76,.5),(74,1),(71,1)],
15:[(76,1),(79,.5),(78,.5),(76,1),(74,1)],
16:[(73,1.5),(69,1.5),(None,1)],
29:[(71,1),(74,.5),(73,.5),(71,1),(66,1)],
30:[(70,1),(73,1),(76,1),(73,1)],
31:[(74,1),(78,.5),(76,.5),(74,1),(71,1)],
32:[(76,1),(79,1),(78,1),(76,1)],
33:[(79,1),(78,.5),(76,.5),(74,1),(71,1)],
34:[(78,1),(74,1),(69,1),(66,1)],
35:[(76,1),(74,.5),(71,.5),(67,1),(71,1)],
36:[(73,1),(76,1),(70,1),(66,1)],
37:[(71,1),(74,.5),(78,.5),(81,1),(78,1)],
38:[(79,1),(74,1),(71,1),(74,1)],
39:[(76,1),(79,.5),(78,.5),(76,1),(74,1)],
40:[(73,1),(70,1),(66,1),(None,1)],
41:[(71,1),(74,1),(78,1),(74,1)],
42:[(73,1),(71,1),(66,1),(None,1)],
43:[(71,1),(74,1),(78,1),(79,1)],
44:[(78,1),(74,1),(69,1),(66,1)],
45:[(67,1),(71,1),(76,1),(74,1)],
46:[(72,1),(76,1),(79,1),(76,1)],
47:[(73,1),(76,1),(79,1),(76,1)],
48:[(73,1),(71,1),(69,1),(None,1)],
61:[(74,1),(78,1),(81,1),(78,1)],
62:[(79,1),(74,1),(71,1),(74,1)],
63:[(76,1),(73,1),(69,1),(73,1)],
64:[(74,2),(None,2)],
73:[(74,1),(78,.5),(76,.5),(71,1),(69,1)],
74:[(73,1),(76,1),(69,1.5),(None,.5)],
75:[(74,1),(78,1),(71,1),(74,1)],
76:[(79,1),(78,.5),(76,.5),(74,1),(71,1)],
77:[(76,1),(79,1),(74,1),(71,1)],
78:[(73,1),(76,1),(69,1),(73,1)],
79:[(74,2),(69,1),(66,1)],
80:[(74,4)]
}
for b in range(49,61): M0[b]=deepcopy(M0[b-44])
# Revision 1: pressure gains direction and asymmetry, then an actual musical cut.
REV1={
29:[(71,.5),(74,.5),(78,1),(76,.5),(74,.5),(71,1)],
30:[(70,.5),(73,.5),(76,.5),(78,.5),(76,1),(73,1)],
31:[(74,1.5),(78,.5),(81,1),(78,.5),(76,.5)],
32:[(76,.5),(79,.5),(78,1),(76,.5),(74,.5),(71,1)],
33:[(79,1.5),(78,.5),(74,1),(71,.5),(74,.5)],
34:[(78,.5),(76,.5),(74,1.5),(69,.5),(66,1)],
35:[(67,.5),(71,.5),(76,1),(79,1),(78,.5),(76,.5)],
36:[(76,1),(73,.5),(70,.5),(66,1.5),(None,.5)],
37:[(71,.5),(74,.5),(78,.5),(81,.5),(83,1),(81,.5),(78,.5)],
38:[(79,1.5),(78,.5),(74,.5),(71,.5),(74,1)],
39:[(76,.5),(79,.5),(78,.5),(76,.5),(74,1),(71,1)],
40:[(73,1),(70,.5),(66,.5),(None,2)],
41:[(71,1.5),(74,.5),(78,1),(None,1)],
42:[(73,1),(71,1),(None,2)],
43:[(71,1.5),(74,.5),(78,1.5),(None,.5)],
44:[(78,1),(74,1),(69,1),(None,1)],
45:[(67,1.5),(71,.5),(76,1),(74,1)],
46:[(72,1.5),(76,.5),(79,1),(None,1)],
47:[(73,1),(76,1),(79,.5),(76,.5),(73,1)],
48:[(69,1.5),(None,.5),(71,.5),(73,.5),(76,.5),(73,.5)]
}
# Revision 2: transformed return expands the original falling end outward;
# no whole-bar copy of the principal melody survives in 49–64 or 73–80.
REV2={
49:[(74,1),(78,.5),(76,.5),(79,1),(81,1)],
50:[(78,.5),(74,.5),(71,1.5),(74,.5),(78,1)],
51:[(79,1.5),(78,.5),(74,1),(76,1)],
52:[(76,.5),(73,.5),(69,1),(73,1.5),(None,.5)],
53:[(78,1),(81,.5),(79,.5),(78,1),(74,1)],
54:[(76,.5),(79,.5),(78,1),(76,1.5),(74,.5)],
55:[(71,1),(74,.5),(79,.5),(81,1),(79,1)],
56:[(76,1.5),(73,.5),(69,1),(73,.5),(76,.5)],
57:[(78,1.5),(81,.5),(83,1),(81,1)],
58:[(79,.5),(78,.5),(74,1),(71,1.5),(74,.5)],
59:[(76,1),(79,.5),(78,.5),(74,1),(71,1)],
60:[(73,1.5),(76,.5),(79,1),(81,1)],
61:[(78,1),(76,.5),(74,.5),(71,1.5),(None,.5)],
62:[(76,.5),(79,.5),(81,1),(79,1),(76,1)],
63:[(73,1),(76,1.5),(74,.5),(73,.5),(71,.5)],
64:[(74,1.5),(78,.5),(74,1),(None,1)],
73:[(74,1.5),(78,.5),(76,1),(74,1)],
74:[(73,.5),(76,.5),(81,1.5),(76,.5),(73,1)],
75:[(74,1),(78,.5),(81,.5),(78,1.5),(None,.5)],
76:[(79,1.5),(74,.5),(71,1),(74,1)],
77:[(76,1.5),(79,.5),(78,1),(76,.5),(74,.5)],
78:[(73,1.5),(76,.5),(69,1),(None,1)],
79:[(74,1.5),(78,.5),(76,1),(73,1)],
80:[(74,3.75),(None,.25)]
}
# Each phrase is single-layer. Sample sustain is NOT assumed.
FLUTE=[
('F01',17,'pp',[74,78,76],[0,2,4],[1.5,1.5,2.1],[45,51,46],'棚外第一声数数，从主主题的上行三度中分出自己的回答'),
('F02',19,'pp',[78,81,79],[0,2.25,4],[1.75,1.25,2],[47,52,48],'第二位扶杆者接上，末音落在棚沿之外'),
('F03',21,'pp',[76,79,76],[0,2,4],[1.5,1.45,2.15],[46,53,47],'叫到同一组人，意识到人数不在庆典名单里'),
('F04',23,'mf',[79,76,78],[0,2.25,4],[1.65,1.25,1.9],[66,62,68],'提问变得明确，句末不作强终止'),
('F05',25,'mf',[83,81,79],[0,1.9,4],[1.35,1.55,2.05],[77,72,67],'从高处数到低处，棚外的人终于成为视线中心'),
('F06',27,'mf',[76,79,81],[0,2.25,4],[1.75,1.25,2.1],[65,73,78],'提出尚未解决的需要，停在属和声上'),
('F07',65,'mf',[83,81,79],[0,2,4],[1.5,1.5,2],[83,77,71],'扩展后的棚下重新点人数；与F05同方向，但节奏和和声已变'),
('F08',67,'mf',[79,83,81],[0,2.25,4],[1.7,1.25,2.1],[72,82,75],'原来站外面的人加入同一声数数，向上回答'),
('F09',69,'pp',[78,76,74],[0,2,4],[1.5,1.5,2.15],[52,48,43],'光回来了，安静看见中央没有缝回去的空口'),
('F10',71,'pp',[76,78,81],[0,2.25,4],[1.75,1.25,2.1],[44,49,54],'以新的二度起步替代F06的三度，给钢琴留下最后的主音')
]

def dump(name,obj):
 (ROOT/name).write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')

def build(version):
 melody=deepcopy(M0)
 if version>=1: melody.update(deepcopy(REV1))
 if version>=2: melody.update(deepcopy(REV2))
 harmony=list(HARMONIES)
 if version>=2:
  # Same home key, but the return first points away from the closed emblem.
  for bar,ch in {49:'D6',51:'G6',53:'Bm7',54:'Em9',55:'Gmaj9',57:'Bm7',58:'Gmaj7',59:'Em7',60:'A7',61:'Bm7',62:'Em7',63:'A7',64:'Dadd9',79:'A7',80:'Dadd9'}.items(): harmony[bar-1]=ch
 bars=[];events=[];pedals=[];phrases=[];intentions=[]
 def add(bar,off,dur,pitch,vel,voice,instrument='piano'):
  events.append(dict(bar=bar,onset=round((bar-1)*4+off,6),duration=round(dur,6),pitch=pitch,velocity=int(vel),voice=voice,instrument=instrument))
 for bar in range(1,81):
  start=(bar-1)*4; beat=4
  _,_,bpm,section=next(f for f in FORM if f[0]<=bar<=f[1])
  fl=17<=bar<=28 or 65<=bar<=72
  ch=harmony[bar-1]; pcs,lh,rh=CHORDS[ch]
  role=('长笛为唯一前景；右手低于长笛的静态和弦，左手和声根基，禁止独立钢琴旋律。' if fl else '钢琴右手单线主题为前景；左手和弦内脉动或稀疏支撑，长笛休止。')
  if 41<=bar<=44: role+='剪刀落下前后逐步留空，不填满呼吸。'
  bars.append(dict(bar=bar,start=start,beats=beat,bpm=bpm,section=section,meter_numerator=4,meter_denominator=4,harmony_name=ch,harmony=[p for p in range(36,85) if p%12 in pcs],role_plan=role,lead_instrument='flute' if fl else 'piano'))
  if not fl:
   seq=melody[bar]; assert abs(sum(d for _,d in seq)-4)<1e-6,bar
   off=0
   base=72 if bar<17 else 83 if bar<41 else 65 if bar<49 else 85 if bar<65 else 70
   for j,(p,d) in enumerate(seq):
    if p is not None:
     # Small composed accents follow phrase contour; no random humanization.
     vel=base+([3,0,2,-2][j%4])+(2 if p>=79 else 0)
     gate=d*(.9 if d<=.5 else .94)
     if bar==80: vel=64;gate=3.65
     add(bar,off,gate,p,vel,'melody')
    off+=d
  # Lower notes are always one left hand; the score does not hide a second tune.
  if fl and version>=1:
   # 4 LH notes per bar, in two chordal gestures; sparse chord support in RH.
   for off in [0,2]:
    for p in lh[:2]: add(bar,off,1.45,p,40 if bar<65 else 43,'bass' if p==lh[0] else 'accompaniment')
   for off in [0,2]:
    for p in rh[:2]: add(bar,off,1.45,p,42 if bar<65 else 44,'upper_support')
  elif (41<=bar<=44 and version>=1):
   # The decisive silence is a cut in texture, not a long fermata.
   if bar==42:
    add(bar,0,1.5,lh[0],42,'bass')
   else:
    for off in ([0] if bar==44 else [0,2]):
     add(bar,off,.9,lh[0],43,'bass')
     if bar!=41 or off==0: add(bar,off+.5,.35,lh[2],39,'accompaniment')
  elif (45<=bar<=48 and version>=1):
   pattern=[0,2,1,2,0,1,2,1]
   for j,k in enumerate(pattern):
    if bar==48 and j in [2,3]:continue
    add(bar,j*.5,.38,lh[k],46+(j%4==0)*3,'bass' if j in [0,4] else 'accompaniment')
  elif bar>=77 and version>=2:
   if bar<79:
    for j,k in enumerate([0,1,2,1]):add(bar,j,.73,lh[k],44+(j==0)*3,'bass' if j==0 else 'accompaniment')
   elif bar==79:
    for off in [0,2]:
     for p in lh[:2]:add(bar,off,1.4,p,42,'bass' if p==lh[0] else 'accompaniment')
   else:
    add(bar,0,3.6,38,47,'bass');add(bar,0,3.6,50,43,'accompaniment')
    for p in [62,66,69]:add(bar,0,3.6,p,42,'upper_support')
  else:
   # Rotation changes contour with the phrase, but remains accompaniment.
   patterns=[[0,1,2,1,0,2,1,2],[0,2,1,2,0,1,2,1],[0,1,2,1,2,1,0,1],[0,2,1,0,1,2,1,0]]
   pat=patterns[(bar-1)%4]
   if fl: base=37
   elif bar<17:base=48
   elif bar<41:base=55
   elif bar<49:base=47
   elif bar<65:base=56
   else:base=46
   for j,k in enumerate(pat):
    if bar in [4,8,12,16,40,64,72] and j>=6:continue
    if bar==1 and j in [1,3,5,7]:continue
    add(bar,j*.5,.39 if bpm>=116 else .41,lh[k],base+(3 if j in [0,4] else 0)-(2 if j%2 else 0),'bass' if j in [0,4] else 'accompaniment')
   if fl:
    for off in [0,2]:
     for p in rh[:2]:add(bar,off,1.5,p,41,'upper_support')
  # Sustain controller is bounded; pedal lifts before every harmony change.
  pedals.append(dict(onset=start,value=0))
  if not (41<=bar<=44 and version>=1):
   if not fl and bar<=64:
    pedals.extend([dict(onset=start+.04,value=28),dict(onset=start+1.86,value=0),dict(onset=start+2.04,value=25),dict(onset=start+3.76,value=0)])
   else:pedals.extend([dict(onset=start+.04,value=25 if fl else 31),dict(onset=start+3.76,value=0)])
 # Intended timing in seconds uses the full tempo map, not a global BPM.
 def sec(q):
  out=0.
  for b in bars:
   n=max(0,min(q-b['start'],b['beats']));out+=n*60/b['bpm']
  return out
 for pid,bar,layer,pitches,offsets,gates,vels,intent in FLUTE:
  if version==0:
   offsets=[0,2,4];gates=[1.5,1.5,1.9]
  if version<2 and pid in ['F09','F10']:
   pitches=[78,81,78] if pid=='F09' else [76,79,81]
  notes=[]
  for i,(p,off,dur,vel) in enumerate(zip(pitches,offsets,gates,vels)):
   b=bar+int(off//4);boff=off%4
   add(b,boff,dur,p,vel,'flute','flute')
   q=(bar-1)*4+off;ts=sec(q);end=sec(q+dur)
   eventid=f'{pid}-N{i+1}'
   row=dict(phrase_id=pid,event_id=eventid,bar=b,pitch=p,velocity=vel,layer=layer,target_arrival_quarterbeats=q,target_pitched_arrival_seconds=round(ts,9),nominal_noteoff_quarterbeats=q+dur,nominal_noteoff_seconds=round(end,9),nominal_gate_seconds=round(end-ts,9),alignment='与钢琴和声起点同时出现有音高声部' if i in [0,2] else '同一句内的独立吐音；钢琴不另起旋律',intent=intent,advance_policy='积分时按实测音高/力度层延迟提前触发；保留此处绝对note-off。不使用统一提前量。此文件未做任何提前补偿。')
   intentions.append(row);notes.append(eventid)
  first=(bar-1)*4+offsets[0];last=(bar-1)*4+offsets[-1]+gates[-1]
  phrases.append(dict(phrase_id=pid,bars=[bar,bar+1],layer=layer,event_ids=notes,target_start_quarterbeats=first,nominal_end_quarterbeats=last,target_start_seconds=round(sec(first),9),nominal_end_seconds=round(sec(last),9),intent=intent))
 for i,p in enumerate(phrases):
  p['gap_to_next_phrase_seconds']=round(phrases[i+1]['target_start_seconds']-p['nominal_end_seconds'],9) if i+1<len(phrases) else None
 events.sort(key=lambda e:(e['onset'],0 if e['instrument']=='piano' else 1,e['pitch'],e['voice']))
 pedals.sort(key=lambda p:p['onset'])
 score=dict(id=68,title='The Seamstress of the Eclipse',title_zh='缝起日食的人',bars=bars,events=events,pedals=pedals,total_beats=320,tail_seconds=4)
 return score,phrases,intentions,sec(320)


def event_changes(a,b):
 encode=lambda e:json.dumps(e,sort_keys=True)
 aa=Counter(encode(e) for e in a['events']);bb=Counter(encode(e) for e in b['events'])
 changed=[]
 for i in range(1,81):
  ea=[e for e in a['events'] if e['bar']==i];eb=[e for e in b['events'] if e['bar']==i]
  if ea!=eb or a['bars'][i-1]!=b['bars'][i-1]:changed.append(i)
 return dict(changed_bars=changed,removed_events=sum((aa-bb).values()),added_events=sum((bb-aa).values()))

if __name__=='__main__':
 results=[]
 for v in range(3):
  score,phrases,intentions,secs=build(v)
  dump(f'score_v{v}.json',score);dump(f'phrases_v{v}.json',phrases)
  results.append(score)
  if v==2:dump('score.json',score);dump('flute_entry_intentions.json',intentions)
 revisions=[dict(revision='v0 → v1',purpose='重写29–48小节；长笛段钢琴左手改为稀疏和声；重排长笛呼吸/吐音空间',**event_changes(results[0],results[1])),dict(revision='v1 → v2',purpose='重写49–64与73–80；改变回归和声与终止；F09/F10改为下降后向主音交接',**event_changes(results[1],results[2]))]
 dump('revision_changes.json',revisions)
 dump('form_design.json',dict(meter='4/4',total_bars=80,total_beats=320,score_duration_seconds=round(secs,9),with_tail_seconds=round(secs+4,9),sections=[dict(first_bar=a,last_bar=b,bpm=c,title=d,duration_seconds=round((b-a+1)*4*60/c,9)) for a,b,c,d in FORM]))
 dump('thematic_material.json',dict(original_material=True,reused_melody_sources=[],primary_seed=dict(bars=[5,6],pitches=[74,78,76,71,69,66,69,71,74],description='上行大三度后退一度，再跨到较低的B、A；下一小节从F#重新抬起。不是六短两长针脚。'),choice=dict(bars=[41,48],description='动机先被休止截断；46小节Cadd9带来D大调外的C自然，表示剪开既定图案；48小节短上行把行动交还左手。'),changed_return=dict(bars=[49,64],description='首句原来的B-A下落改为G-A向外展开；61不作D终止而落Bm7，经Em7-A7才在64抵达Dadd9。'),coda=dict(bars=[73,80],description='把主题的推进逐层减去；79由A7托住D悬留后落C#，80才落D。留下有入口的棚子。'),harmony_principle='D大调为家，Bm为影；F#7推动暗部；选择段唯一Cadd9转色；回归增加六度/九度但终止仍清楚。',flute_principle='每个两小节句只有三个较长的独立吐音；一整句只用pp或mf一层；全曲没有真连奏、延音循环或ff标称。'))
 manifest=dict(work_id=68,status='ORIGINAL_NON_RENDERED_SCORE_ONLY',orchestration='acoustic piano + sampled flute',orchestration_revision='原小提琴构想因素材受阻，明确改编为现有原声钢琴采样与长笛采样；本包没有小提琴录音或小提琴音轨。',score='score_v2.json',entry_intentions='flute_entry_intentions.json',tempo_adjusted_duration_seconds=round(secs,9),tail_seconds=4,audio_rendered=False,performer_listening_claim=False,files={f'score_v{i}.json':hashlib.sha256((ROOT/f'score_v{i}.json').read_bytes()).hexdigest() for i in range(3)})
 dump('build_manifest.json',manifest)
 print(json.dumps(dict(work_id=68,seconds_with_tail=round(secs+4,6),event_counts=[len(s['events']) for s in results],revisions=revisions),ensure_ascii=False,indent=2))
