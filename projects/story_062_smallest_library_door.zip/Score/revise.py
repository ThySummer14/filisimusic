from pathlib import Path
import json,copy
P=Path(__file__).parent;d=json.loads((P/'revisions/score_v0.json').read_text())
# First revision keeps the lower-register lead audible in the same acoustic space.
for e in d['events']:
 if e['voice']=='upper_support':e['pitch']-=12
# New eight-bar coda answers the old motif rather than repeating the repair climax.
C=[[(74,1),(70,.5),(67,.5),(69,.5),(70,.5),(74,1)],[(75,1),(74,.5),(70,.5),(67,1),(63,1)],[(72,.5),(75,.5),(79,1),(75,.5),(72,.5),(67,1)],[(66,1),(69,.5),(74,.5),(72,1),(-1,1)],[(71,.5),(74,.5),(79,1),(78,.5),(76,.5),(74,1)],[(75,1),(72,.5),(67,.5),(69,1),(72,1)],[(74,.5),(78,.5),(81,1),(78,.5),(74,.5),(66,1)],[(67,2.5),(-1,1.5)]]
for j,line in enumerate(C):
 b=d['bars'][88+j];d['events']=[e for e in d['events'] if not(e['bar']==b['bar'] and e['voice']=='melody')];off=0
 for n,l in line:
  if n>=0:d['events'].append(dict(bar=b['bar'],onset=b['start']+off,duration=l*.92,pitch=n,velocity=72,voice='melody'))
  off+=l
 assert off==4
# The last twelve-bar broken-spring segment acquires a two-bar new hinge response.
for bar,line in [(63,[(69,.5),(72,.5),(74,1),(72,.5),(69,.5),(66,1)]),(64,[(66,1.5),(69,.5),(74,1),(-1,1)])]:
 b=d['bars'][bar-1];b.update(harmony_name='D7',harmony=[38,60,66]);d['events']=[e for e in d['events'] if e['bar']!=bar];off=0
 for n,l in line:
  if n>=0:d['events'].append(dict(bar=bar,onset=b['start']+off,duration=l*.88,pitch=n,velocity=68,voice='melody'))
  off+=l
 d['events'].append(dict(bar=bar,onset=b['start'],duration=.5,pitch=38,velocity=43,voice='bass'))
 for n in [57,60]:d['events'].append(dict(bar=bar,onset=b['start']+1,duration=.4,pitch=n,velocity=35,voice='accompaniment'))
d['stage']='v1_new_coda_and_repair_hinge';(P/'revisions/score_v1.json').write_text(json.dumps(d,indent=2));(P/'revisions/pass1.json').write_text(json.dumps({'round':1,'kind':'substantive_form_and_orchestration_revision','changes':['Replace repeated climax material in the8-bar coda with a new lower, quieter answer and a sharedG-major close.','Write a new two-barD-dominant hinge out of the broken-spring segment, connecting fragmented questions to the returningGminor theme.','Bring upper supporting dyads down an octave during lower-hand leadership, keeping the layers in a closer shared register.']},indent=2))
removed=[]
for b in d['bars']:
 notes=[e for e in d['events'] if e['bar']==b['bar'] and e['voice'] in ['melody','lower_melody']];end=max((e['onset']+e['duration'] for e in notes),default=b['start']);breath=end<b['start']+3.2;arc=[-2,1,3,-4][b['phrase_position']%4]
 for e in [e for e in d['events'] if e['bar']==b['bar']]:
  off=e['onset']-b['start']
  if e['voice'] in ['melody','lower_melody']:
   e['velocity']+=arc
   if off%1!=0:e['velocity']-=3
   if b['role_plan']=='lower':e['duration']*=1.03
  else:
   e['velocity']+=arc//2
   if breath and off>=3:e['remove']=True;removed.append((b['bar'],e['pitch']))
 if breath:
  for x in d['pedals']:
   if b['start']<=x['onset']<b['start']+4 and x['value']>0:x['value']=18
# Simultaneous same-piano key ownership: melody owns a unison, accompaniment yields.
lead=[e for e in d['events'] if e['voice'] in ['melody','lower_melody']]
key_yields=[]
for e in d['events']:
 if e['voice'] in ['melody','lower_melody']:continue
 for m in lead:
  if e['pitch']==m['pitch'] and max(e['onset'],m['onset'])<min(e['onset']+e['duration'],m['onset']+m['duration'])-1e-8:e['remove']=True;key_yields.append([e['bar'],e['pitch']]);break
d['events']=[e for e in d['events'] if not e.pop('remove',False)];d['events'].sort(key=lambda e:(e['onset'],e['pitch']));d['stage']='v2_turn_taking_phrase_arcs_and_key_ownership'
for f in ['score.json','revisions/score_v2.json']:(P/f).write_text(json.dumps(d,indent=2))
(P/'revisions/pass2.json').write_text(json.dumps({'round':2,'kind':'substantive_performance_revision','changes':['Give each four-bar sentence a restrained opening, central lift and softened answer; offbeat notes remain lighter than structural notes.','At actual written melodic breaths, withdraw the last supporting pulse and reduce pedal rather than filling every gap.','Keep lower-hand melody connected and the upper-hand dyads subordinate; shared piano keys belong to the current melodic lead.'],'removed_late_support':removed,'unison_support_yields':key_yields,'human_listening_review':False},indent=2));print('v2 notes',len(d['events']),'unison yields',len(key_yields))
