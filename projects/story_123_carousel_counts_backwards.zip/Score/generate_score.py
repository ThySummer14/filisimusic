"""123 original five-beat piano miniature expanded into a complete early-crest form."""
from pathlib import Path
import json,sys
P=Path(__file__).resolve().parent;sys.path.insert(0,str(P));from composition_data import *
def write(p,x):p.write_text(json.dumps(x,ensure_ascii=False,separators=(',',':'))+'\n')
def pitch(s):return 12*(int(s[-1])+1)+{'C':0,'D':2,'E':4,'F':5,'G':7,'A':9,'B':11}[s[0]]+s[1:-1].count('#')-s[1:-1].count('b')
def build(level):
 rows=[]
 for sec,bpm,dyn,hs,lines in GROUPS:
  assert len(hs.split())==len(lines),(sec,len(hs.split()),len(lines))
  rows.extend(zip([sec]*len(lines),[bpm]*len(lines),[dyn]*len(lines),hs.split(),lines))
 assert len(rows)==80
 events=[];bars=[];pedals=[]
 for n,(sec,bpm,dyn,h,line) in enumerate(rows,1):
  if level>=1:line=REV1.get(n,line)
  if level>=2:line=REV2.get(n,line)
  start=(n-1)*5
  if n>=77:bpm-=2*(n-76)
  bars.append(dict(bar=n,start=start,beats=5,bpm=bpm,meter='5/4',meter_numerator=5,meter_denominator=4,section=sec,harmony_name=h,harmony=H[h],key_region='E-flat major, C/F-minor shadows, an early bright crest'))
  def add(p,t,d,v,voice,hand):
   assert 0<=t<t+d<=5.00001,(n,t,d)
   events.append(dict(bar=n,onset=round(start+t,6),duration=round(d,6),pitch=p,velocity=int(v),instrument='piano',voice=voice,hand=hand))
  at=0;tokens=line.split()
  for i,tok in enumerate(tokens):
   name,u=tok.split(':');dur=float(u)/2
   if name!='R':add(pitch(name),at,dur-.07,dyn+(3 if at==0 else -3 if i==len(tokens)-1 else 0),'carousel_five_step_theme','right')
   at+=dur
  assert at==5,(n,at,line)
  ch=H[h]
  if level>=2 and n in BASS2:
   at=0
   for tok in BASS2[n].split():
    name,u=tok.split(':');dur=float(u)/2
    if name!='R':add(pitch(name),at,dur-.07,dyn-6,'count_backwards_countermelody','left')
    at+=dur
   assert at==5
  elif level>=1 and n in BASS1:
   add(ch[0],0,.52,dyn-17,'three_plus_two_footing','left')
   for t,q in zip([3.05,3.4,3.75],BASS1[n]):add(q,t,.24,dyn-8,'reply_inside_upper_rest','left')
  elif sec in ['counting_the_seats','one_light_left']:
   add(ch[0],0,.8,dyn-17,'remaining_lamp_pulse','left')
   for q in ch[1:3]:add(q,3,.55,dyn-19,'remaining_lamp_pulse','left')
  else:
   add(ch[0],0,.48,dyn-17,'three_plus_two_footing','left')
   for q in ch[1:3]:add(q,1.5,.32,dyn-22,'inside_three_beat_group','left')
   add(ch[0],3,.46,dyn-15,'three_plus_two_footing','left');add(ch[2],4,.32,dyn-20,'inside_two_beat_group','left')
  pedals.append(dict(bar=n,onset=start,controller=64,value=0,instrument='piano'))
 events.sort(key=lambda e:(e['onset'],e['pitch']))
 for i,e in enumerate(events):e['event_id']=f'123-v{level}-{i}'
 return dict(id=123,title='The Carousel Counts Backwards',title_zh='旋转木马向后数',version=f'v{level}',bars=bars,events=events,pedals=pedals,total_beats=400,tail_seconds=5,instrument_map={'piano':'piano'},performance_contract='Original5/4 piano composition with3+2 harmonic footing, an early crest, written call-response rests and a late lower countermelody. No copied audio loop or live-performance claim.')
def proj(d,n):return {'bar':d['bars'][n-1],'events':[{k:v for k,v in e.items() if k!='event_id'} for e in d['events'] if e['bar']==n],'pedals':[e for e in d['pedals'] if e['bar']==n]}
for v in range(3):
 d=build(v);write(P/f'score_v{v}.json',d);report=dict(version=f'v{v}',bars=80,events=len(d['events']),duration_seconds=sum(b['beats']*60/b['bpm'] for b in d['bars'])+5,human_listening_review=False);write(P/f'audit_v{v}.json',report)
 if v:
  a=build(v-1);changes=[{'bar':n,'before':proj(a,n),'after':proj(d,n)} for n in range(1,81) if proj(a,n)!=proj(d,n)];write(P/f'exact_diff_v{v-1}_to_v{v}.json',{'count':len(changes),'changed_bars':[x['bar'] for x in changes],'comparison_excludes':['version','event_id'],'changes':changes})
write(P/'score.json',d);write(P/'ensemble_score.json',d);write(P/'piano_score.json',d);print(json.dumps(report))
