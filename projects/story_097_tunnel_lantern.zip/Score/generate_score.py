"""Original work097. Authored bar-by-bar piano lines; no audio or sample access."""
from pathlib import Path
import argparse, copy, difflib, hashlib, json
ROOT=Path(__file__).resolve().parent
PC={'C':0,'D':2,'E':4,'F':5,'G':7,'A':9,'B':11}
def midi(s):return 12*(int(s[-1])+1)+PC[s[0]]+s[1:-1].count('#')-s[1:-1].count('b')
LINES=[
 'E4 G4 A4 B4 A4 G4 E4 | D5 B4 A4 G4 A4 B4 G4 | E5 D5 C5 B4 G4 | F#4 A4 B4 D#5 B4 A4 F#4 | G4 B4 D5 E5 D5 B4 G4 | C5 B4 A4 E4 A4 B4 C5 | D#5 F#5 E5 D#5 B4 | E5 B4 G4 E4',
 'G4 B4 E5 D5 B4 G4 E4 | A4 B4 D5 F#5 D5 B4 A4 | G5 E5 D5 B4 D5 E5 G5 | F#5 E5 C5 A4 C5 E5 F#5 | E5 D5 C5 G4 C5 D5 E5 | F#4 A4 C5 D5 C5 A4 F#4 | B4 D#5 F#5 E5 D#5 B4 F#4 | G4 A4 B4 E5 B4 G4 E4',
 'B4 E5 F#5 G5 F#5 E5 B4 | A4 C5 E5 G5 E5 C5 A4 | B4 D5 E5 F#5 E5 D5 B4 | C5 E5 G5 F#5 E5 C5 B4 | D5 F#5 A5 G5 F#5 D5 B4 | E5 G5 A5 B5 A5 G5 E5 | F#5 E5 D#5 B4 A4 | B4 D#5 F#5 E5 D#5 B4',
 'E5 B4 A4 G4 A4 B4 E5 | D5 C5 B4 G4 B4 C5 D5 | C5 A4 G4 E4 G4 A4 C5 | B4 D#5 E5 F#5 E5 D#5 B4 | E5 G5 F#5 E5 D5 | C5 E5 D5 C5 A4 | A4 B4 D#5 F#5 D#5 B4 A4 | G4 B4 E5 B4 G4',
 'G4 B4 D5 E5 D5 | F#5 E5 D5 A4 D5 | E5 D5 B4 G4 | G4 C5 E5 D5 C5 | A4 C5 E5 D5 C5 | F#4 A4 C5 D5 C5 | B4 D5 G5 F#5 D5 | E5 D5 B4 G4',
 'B4 D5 E5 G5 E5 | A4 D5 F#5 E5 D5 | G5 F#5 E5 B4 | C5 E5 G5 E5 D5 | E5 D5 C5 A4 | F#4 A4 C5 D5 | D#5 E5 F#5 B4 | E5 D5 B4 G4',
 'E4 G4 B4 A4 G4 E4 F#4 | G4 A4 B4 D5 B4 A4 G4 | C5 B4 A4 E4 G4 A4 C5 | D#5 B4 A4 F#4 A4 B4 D#5 | E5 F#5 G5 B5 G5 F#5 E5 | D5 E5 F#5 A5 F#5 E5 D5 | E5 G5 F#5 E5 B4 | D#5 F#5 A5 F#5 D#5 B4',
 'G5 F#5 E5 D5 B4 | F#5 E5 D5 B4 A4 | E5 D5 C5 B4 G4 | A4 C5 E5 D5 C5 A4 | B4 D5 F#5 E5 D5 B4 | A4 B4 D#5 E5 D#5 B4 A4 | G4 B4 E5 F#5 E5 B4 G4 | F#4 A4 B4 D#5 B4 A4 F#4',
 'E5 G5 F#5 E5 B4 | D5 G5 F#5 D5 B4 | E5 G5 A5 G5 E5 C5 | D#5 F#5 A5 F#5 D#5 B4 | E5 G5 B5 A5 G5 E5 | D5 F#5 A5 G5 F#5 D5 | C5 E5 G5 E5 D5 C5 | B4 D#5 F#5 E5 D#5 B4',
 'G5 E5 D5 B4 G4 | F#5 D5 B4 A4 | E5 G5 F#5 E5 D5 | C5 E5 D5 C5 A4 | B4 D5 F#5 E5 D5 B4 | A4 C5 D#5 E5 D#5 C5 A4 | G4 B4 E5 B4 G4 | F#4 A4 B4 D#5 B4 F#4',
 'E5 B4 G4 E4 | D5 B4 G4 D4 | C5 B4 G4 E4 | B4 A4 F#4 D#4 | E4 G4 B4 A4 G4 | A4 C5 E5 C5 A4 | F#4 A4 B4 D#5 B4 | E5 D5 B4 G4',
 'G4 B4 E5 D5 B4 | A4 D5 F#5 D5 A4 | E5 D5 C5 G4 | C5 B4 A4 E4 | A4 B4 D#5 F#5 D#5 | G4 B4 E5 B4 G4 | D#5 F#5 E5 D#5 B4 | E5 B4 G4 E4',
]
HARM_ROWS=[
 'Em G C B7 Em/G Am B7 Em',
 'Em D/F# G D7 C D7 B7 Em',
 'Em Am G C D Em B7 B7',
 'Em G Am B7 Em C B7 Em',
 'G D/F# Em C Am D7 G/B G',
 'G D Em C Am D7 B7 Em',
 'Em G Am B7 Em D C B7',
 'Em D C Am G B7 Em B7',
 'Em G C B7 Em D C B7',
 'Em D Em C G B7 Em B7',
 'Em G C B7 Em/G Am B7 Em',
 'Em D/F# C Am B7 Em B7 Em',
]
H={
 'Em':[40,43,47],'Em/G':[43,47,52],'Em/B':[47,52,55],
 'Em(add9)':[52,54,55,59],'G':[43,47,50],'G/B':[47,50,55],
 'C':[48,52,55],'C/G':[43,48,52],'Cmaj7':[48,52,55,59],
 'Am':[45,48,52],'Am/C':[48,52,57],
 'D':[50,54,57],'D/F#':[42,45,50],'D7':[50,54,57,60],
 'B7':[47,51,54,57],'B7/D#':[39,42,45,47],'Bsus4':[47,52,54],
}
V1={
17:'E5 G5 F#5 E5 B4',18:'C5 E5 G5 E5 D5 C5',19:'D5 B4 A4 B4 D5 E5 D5',20:'E5 G5 E5 D5 C5',
21:'F#5 A5 G5 F#5 D5',22:'G5 B5 A5 G5 E5',23:'E5 D#5 B4 A4 B4 D#5 E5',24:'F#5 D#5 B4 A4 F#4',
25:'G4 B4 E5 D5 B4',26:'B4 D5 G5 F#5 D5 B4',27:'A4 C5 E5 D5 C5',28:'D#5 F#5 E5 D#5 B4',
29:'B4 E5 G5 F#5 E5 D5 B4',30:'E5 D5 C5 A4 C5 D5 E5',31:'D#5 B4 A4 B4 D#5 E5 D#5',32:'G4 B4 E5 D5 B4 G4',
49:'G4 B4 E5 B4 A4 G4 E4',50:'B4 D5 F#5 D5 B4 A4 G4',51:'C5 E5 D5 C5 A4',52:'B4 D#5 F#5 E5 D#5 B4',
53:'G5 B5 A5 G5 F#5 E5',54:'F#5 A5 G5 F#5 E5 D5',55:'E5 G5 E5 D5 C5',56:'F#5 A5 F#5 E5 D#5 B4',
}
V1_H={18:'Am/C',19:'G/B',20:'Cmaj7',21:'D/F#',22:'Em/G',24:'B7/D#',26:'G/B',27:'Am/C',29:'Em/B',30:'C/G',49:'Em/G',50:'G/B',52:'B7/D#',53:'Em/B',54:'D/F#',55:'Cmaj7'}
V2={
65:'E5 G5 F#5 E5 D5 B4 E5',66:'D5 G5 F#5 E5 D5 B4',67:'E5 G5 A5 G5 E5',68:'D#5 F#5 E5 D#5 B4 A4',
69:'G5 B5 A5 G5 F#5 E5',70:'F#5 A5 G5 F#5 E5 D5',71:'E5 G5 E5 D5 C5',72:'D#5 F#5 A5 F#5 E5 D#5',
73:'B5 A5 G5 E5 G5 A5 B5',74:'A5 G5 F#5 D5 F#5 G5 A5',75:'G5 F#5 E5 D5 B4',76:'E5 D5 C5 A4 C5 D5 E5',
77:'D5 F#5 E5 D5 B4',78:'D#5 E5 F#5 E5 D#5 B4',79:'E5 D5 B4 G4 B4 D5 E5',80:'D#5 B4 A4 F#4 A4 B4 D#5',
81:'E5 D5 B4 G4',82:'D5 B4 A4 G4',83:'C5 B4 G4 E4',84:'B4 A4 F#4 D#4',
85:'G4 B4 A4 G4 E4',86:'C5 B4 A4 E4 A4',87:'A4 B4 D#5 F#5 D#5 B4 A4',88:'G4 B4 E5 B4 G4',
93:'D#5 F#5 E5 D#5 B4',94:'B4 G4 E4 G4 B4',95:'D#5 B4 A4 F#4 B4',96:'G4 F#4 E4',
}
V2_H={65:'Em(add9)',66:'G/B',67:'Cmaj7',69:'Em/B',70:'D/F#',71:'C/G',73:'Em/B',74:'D/F#',76:'Am/C',77:'G/B',79:'Em/G',81:'Em/B',82:'G/B',85:'Em/G',86:'Am/C',88:'Em/B',94:'Em/G'}
LABELS=['从车棚驶出','把灯转回前方','隧道里加快的回声','在出口靠边','照见石缝','把小零件放进掌心','屏幕上已经离岸','沿桥下换路','拐上缓坡','灯光重新落到前轮','收低速度','在门口卸下手电']
SECTIONS=[(1,16,'A','歪向路面的车灯','E minor'),(17,32,'B','穿过短隧道','E minor'),(33,48,'C','停下找那颗螺母','G major'),(49,64,'D','渡船已走的消息','E minor'),(65,80,'A2','沿桥换路','E minor'),(81,96,'Coda','把手电取下来','E minor')]
def section(n):return next(s for s in SECTIONS if s[0]<=n<=s[1])
def bpm(n):
 if n<=16:return 104 if n%8 else 98
 if n<=32:return 112 if n%8 else 106
 if n<=48:return 84 if n%8 else 80
 if n<=64:return 114 if n%8 else 108
 if n<=80:return 110 if n%8 else 104
 return [100,100,102,98,98,96,96,94,96,94,94,92,92,90,88,84][n-81]
def durations(count,beats,n,level):
 if beats==4:
  return {3:[1,1,2],4:[1,1,1,1],5:[1,.5,.5,1,1],6:[.5,.5,1,.5,.5,1],7:[.5,.5,.5,.5,1,.5,.5]}[count]
 pats={3:[1,1,1.5],4:[1,.5,1,1],5:[.5,.5,1,.5,1],6:[.5,.5,.5,.5,.5,1],7:[.5]*7}
 result=pats[count][:]
 if count==5 and (n+level)%2:result=[1,.5,.5,1,.5]
 return result
def seconds(bars,t):return sum(min(max(t-b['start'],0),b['beats'])*60/b['bpm'] for b in bars)
def fingermap(keys,hand):
 fs={1:[3],2:[1,5],3:[1,3,5],4:[1,2,4,5],5:[1,2,3,4,5]}[len(keys)]
 if len(keys)==4:
  widest=max(range(3),key=lambda i:keys[i+1]-keys[i]);fs=([1,3,4,5],[1,2,4,5],[1,2,3,5])[widest]
 return dict(zip(keys,fs if hand=='right' else [6-f for f in fs]))
def build(version):
 level=int(version[1:]);lines=[x.strip() for row in LINES for x in row.split('|')];harm=[x for row in HARM_ROWS for x in row.split()]
 assert len(lines)==len(harm)==96
 for lv,changes,chords in [(1,V1,V1_H),(2,V2,V2_H)]:
  if level>=lv:
   for n,line in changes.items():lines[n-1]=line
   for n,h in chords.items():harm[n-1]=h
 bars=[];events=[];pedals=[];plans=[];start=0.
 for n in range(1,97):
  _,_,sect,title,key=section(n);beats=4. if 33<=n<=48 else 3.5;meter=(4,4) if beats==4 else (7,8);h=harm[n-1];ch=H[h];pid=f'P{(n-1)//8+1:02d}_piano'
  texture='three_two_two_shared_pulse' if beats==3.5 else 'stationary_four_beat_answer'
  if level>=1 and (17<=n<=32 or 49<=n<=56):texture='moving_inner_response'
  if level>=2 and 65<=n<=88:texture='reordered_return_support'
  if n>=89:texture='settling_cadence'
  b={'bar':n,'start':start,'beats':beats,'bpm':bpm(n),'meter':f'{meter[0]}/{meter[1]}','meter_numerator':meter[0],'meter_denominator':meter[1],'section':sect,'section_title_zh':title,'key_region':key,'harmony_name':h,'harmony':ch,'lead_instrument':'piano','lead_hand':'right','phrase_id':pid,'phrase_position':(n-1)%8+1,'texture':texture,'metrical_grouping':'3+2+2 eighths' if beats==3.5 else 'four quarter beats','role_plan':'One singing right-hand melody; left-hand chord tones reinforce the same phrase and harmony.'};bars.append(b)
  def add(p,t,d,v,voice,hand,role,written):
   e={'bar':n,'onset':round(start+t,6),'duration':round(d,6),'pitch':p,'velocity':v,'instrument':'piano','voice':voice,'hand':hand,'role':role,'phrase_id':pid,'phrase_label':LABELS[(n-1)//8],'harmony_name':h,'harmonic_function':'chord_tone' if p%12 in {x%12 for x in ch} else 'melodic_nonchord_tone','written_value_beats':written};events.append(e);return e
  ps=[midi(x) for x in lines[n-1].split()];ds=durations(len(ps),beats,n,2 if level>=2 and n in V2 else 1 if level>=1 and n in V1 else 0);assert sum(ds)==beats
  energy=70 if n<=16 else 77 if n<=32 else 64 if n<=48 else 81 if n<=64 else 85 if n<=80 else 66 if n<=88 else 59
  t=0
  for i,(pitch,w) in enumerate(zip(ps,ds)):
   gap=.10 if i<len(ps)-1 else .28
   if n==96 and i==len(ps)-1:gap=0
   e=add(pitch,t,w-gap,energy+[2,-1,1,0,-2,1,-1][i%7],'melody','right','lead',w);e['articulation']='flowing_piano_line_with_real_key_release';t+=w
  quiet=energy-25;shell=[ch[0],ch[-1]];inner=ch[1:-1] or [ch[1]]
  if texture=='stationary_four_beat_answer':gestures=[(0,1.05,shell),(1.5,.56,inner),(2.5,.8,ch)]
  elif texture=='moving_inner_response':gestures=[(0,.56,[ch[0]]),(1,.30,inner),(1.75,.38,shell),(2.75,.32,ch[1:])]
  elif texture=='reordered_return_support':gestures=[(0,.64,shell),(1.5,.40,inner),(2.25,.62,ch)]
  elif texture=='settling_cadence':gestures=[(0,1.14,shell),(1.75,.78,ch)]
  else:gestures=[(0,.70,[ch[0]]),(1.5,.40,ch[1:]),(2.5,.50,shell)]
  if n==96:gestures=[(0,beats,ch)]
  for at,dur,keys in gestures:
   for pitch in keys:
    e=add(pitch,at,dur,quiet+(1 if len(keys)==1 else 0),'harmonic_support','left','support',min(dur+.1,beats-at));e['articulation']='shared_harmonic_pulse'
  for hand in ['left','right']:
   ns=[e for e in events if e['bar']==n and e['hand']==hand];keys=sorted({e['pitch'] for e in ns});assert len(keys)<=5 and keys[-1]-keys[0]<=12,(version,n,hand,keys)
   fm=fingermap(keys,hand);pos={'bar':n,'hand':hand,'active':True,'position_id':f'b{n:03d}_{hand}','range':[keys[0],keys[-1]],'pitch_finger_map':{str(k):v for k,v in fm.items()}};plans.append(pos)
   for e in ns:e.update(finger=fm[e['pitch']],hand_position_id=pos['position_id'],hand_position_range=pos['range'],position_keys=keys)
  pedals.extend([{'bar':n,'onset':start,'controller':64,'value':0,'instrument':'piano'},{'bar':n,'onset':start+.08,'controller':64,'value':28 if beats==3.5 else 30,'instrument':'piano'},{'bar':n,'onset':start+beats-.32,'controller':64,'value':0,'instrument':'piano'}]);start+=beats
 pedals.append({'bar':96,'onset':start,'controller':64,'value':0,'instrument':'piano'})
 hp={(p['bar'],p['hand']):p for p in plans}
 for hand in ['left','right']:
  times=sorted({e['onset'] for e in events if e['hand']==hand})
  for a,z in zip(times,times[1:]):
   old=[e for e in events if e['hand']==hand and e['onset']==a];new=[e for e in events if e['hand']==hand and e['onset']==z];ok=[e['pitch'] for e in old];nk=[e['pitch'] for e in new];op=hp[(old[0]['bar'],hand)];np=hp[(new[0]['bar'],hand)]
   travel=max(abs(min(ok)-min(nk)),abs(max(ok)-max(nk)),max(abs(x-y) for x in ok for y in nk),max(abs(x-y) for x,y in zip(op['range'],np['range'])) if op['position_id']!=np['position_id'] else 0);required=.075+.012*max(0,travel-4)+.014;limit=seconds(bars,z)-required
   for e in old:
    if seconds(bars,e['onset']+e['duration'])>limit:
     e['duration']=round((limit-seconds(bars,e['onset']))*bars[e['bar']-1]['bpm']/60,6);e['release_adjustment']='Whole-grip and actual held-key travel, with14ms extra release margin.'
    assert e['duration']*60/bars[e['bar']-1]['bpm']>=.06,(version,'short gate',e)
 events.sort(key=lambda e:(e['onset'],e['instrument'],e['hand'],e['pitch'],e['voice']));counter={}
 for e in events:
  k=(e['bar'],e['voice']);counter[k]=counter.get(k,0)+1;e['event_id']=f'w97-b{e["bar"]:03d}-{e["voice"]}-{counter[k]:02d}';e.update(target_on_beats=e['onset'],target_off_beats=round(e['onset']+e['duration'],6),target_on_seconds=round(seconds(bars,e['onset']),9),target_off_seconds=round(seconds(bars,e['onset']+e['duration']),9))
 phrases=[]
 for i in range(12):
  pid=f'P{i+1:02d}_piano';ns=[e for e in events if e['phrase_id']==pid];a=min(e['onset'] for e in ns);z=max(e['onset']+e['duration'] for e in ns);phrases.append({'phrase_id':pid,'instrument':'piano','first_bar':i*8+1,'last_bar':i*8+8,'phrase_label':LABELS[i],'target_on_beats':a,'target_off_beats':round(z,6),'target_on_seconds':round(seconds(bars,a),9),'target_off_seconds':round(seconds(bars,z),9)})
 return {'id':97,'title':'The Flashlight at the Tunnel Exit','title_zh':'隧道尽头的手电','version':version,'instrumentation':['natural_acoustic_piano'],'bars':bars,'events':events,'phrases':phrases,'pedals':pedals,'total_beats':start,'tail_seconds':6,'hand_position_plan':plans,'performance_contract':{'beat_unit':'quarter-note beats;7/8=3.5,4/4=4','source_status':'Original symbolic piano score; audio separately validated','pedal':'Low CC64 resonance intent; no assertion of a particular acoustic half-pedal depth','hand_geometry':'Every actual held-key/grip transition audited; pedal does not release a finger','limits':'Symbolic checks are not listening or performer-comfort approval'}}
def dumps(x):return json.dumps(x,ensure_ascii=False,indent=2)+'\n'
def patch(a,b,path=''):
 if a==b:return []
 if isinstance(a,dict) and isinstance(b,dict):
  out=[]
  for k in sorted(set(a)|set(b)):
   p=path+'/'+k.replace('~','~0').replace('/','~1')
   if k not in b:out.append({'op':'remove','path':p})
   elif k not in a:out.append({'op':'add','path':p,'value':b[k]})
   else:out+=patch(a[k],b[k],p)
  return out
 return [{'op':'replace','path':path,'value':b}]
def emit_diff(root,a,b):
 before=dumps(a);after=dumps(b);changes=[]
 for n in range(1,97):
  row={'bar':n,'before_bar':a['bars'][n-1],'after_bar':b['bars'][n-1],'before_events':[e for e in a['events'] if e['bar']==n],'after_events':[e for e in b['events'] if e['bar']==n],'before_pedals':[e for e in a['pedals'] if e['bar']==n],'after_pedals':[e for e in b['pedals'] if e['bar']==n]}
  if any(row['before_'+k]!=row['after_'+k] for k in ['bar','events','pedals']):changes.append(row)
 av,bv=a['version'],b['version'];d={'from_version':av,'to_version':bv,'before_sha256':hashlib.sha256(before.encode()).hexdigest(),'after_sha256':hashlib.sha256(after.encode()).hexdigest(),'changed_bars':[x['bar'] for x in changes],'changes':changes,'phrase_metadata_before':a['phrases'],'phrase_metadata_after':b['phrases'],'position_plan_before':a['hand_position_plan'],'position_plan_after':b['hand_position_plan'],'json_patch':patch(a,b)};(root/f'exact_diff_{av}_to_{bv}.json').write_text(dumps(d));(root/f'exact_diff_{av}_to_{bv}.patch').write_text(''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile=f'score_{av}.json',tofile=f'score_{bv}.json')))
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--outdir',default=str(ROOT));root=Path(ap.parse_args().outdir);root.mkdir(parents=True,exist_ok=True);scores=[build(v) for v in ['v0','v1','v2']]
 for s in scores:(root/f'score_{s["version"]}.json').write_text(dumps(s))
 (root/'score.json').write_text(dumps(scores[-1]));emit_diff(root,scores[0],scores[1]);emit_diff(root,scores[1],scores[2])
if __name__=='__main__':main()
