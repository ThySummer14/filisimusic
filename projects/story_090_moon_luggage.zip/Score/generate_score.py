#!/usr/bin/env python3
"""Original work 090, symbolic only. Standard library; deterministic; no media access."""
from pathlib import Path
from collections import defaultdict, Counter
import copy, json, hashlib, difflib, bisect
ROOT=Path(__file__).resolve().parent
H={
 'Db':([49,53,56],[61,65,68]), 'Db/F':([41,49,53],[61,65,68]),
 'Db/Ab':([44,49,53],[61,65,68]), 'Db6':([49,53,56],[61,65,70]),
 'Gb':([42,46,49],[61,66,70]), 'Gb/Bb':([46,49,54],[61,66,70]),
 'Ab':([44,48,51],[60,63,68]), 'Ab/C':([48,51,56],[60,63,68]),
 'Ab7':([44,48,54],[60,63,66]), 'Bbm':([46,49,53],[61,65,70]),
 'Fm':([41,44,48],[60,65,68]), 'F7':([41,45,51],[60,63,69]),
 'Ebm':([39,46,51],[63,66,70]), 'Ebm/Gb':([42,46,51],[63,66,70]),
 'Gbm':([42,45,49],[61,66,69]), 'Cb':([47,51,54],[59,63,66]),
 'Abm':([44,47,51],[59,63,68]), 'Db7':([49,53,56],[59,65,68]),
}
# Explicit authored sentences. Each token is sounding concert MIDI / written
# quarter-note beats; '-' is an intentional written rest, never generated padding.
SENTENCES=[
 ('A','标签朝外','2/4',100,'Db major',[
 'Db|P|73/.5 77/.5 75/1','Db/Ab|P|68/.5 73/1.5','Gb|P|78/.75 77/.25 75/.5 73/.5','Ab7|P|72/1 75/.75 -/.25',
 'Db/F|P|77/.5 80/.5 78/1','Ebm|P|75/.75 78/.25 77/.5 75/.5','Ab7|P|72/.5 75/.5 73/.5 72/.5','Db|P|73/1.5 -/.5']),
 ('A','行李牌上的月亮','2/4',100,'Db major',[
 'Db|C|61/.75 65/1.25','Ab/C|C|63/1 68/1','Db/F|C|65/.75 63/1.25','Db|C|61/1.5 -/.5',
 'Gb|C|66/.75 70/1.25','Bbm|C|68/1 65/1','Ab7|C|63/1 60/1','Db|C|61/1.5 -/.5']),
 ('A','松开的绑带','2/4',102,'Db major',[
 'Db6|P|77/.75 80/.25 78/.5 77/.5','Gb|P|78/1 73/.5 75/.5','Ebm|P|78/.5 82/.5 80/1','Ab7|P|75/1.5 -/.5',
 'Fm|P|77/.5 75/.5 72/1','Bbm|P|73/.75 77/.25 80/1','Ebm|P|78/.5 75/.5 73/.5 75/.5','Ab|P|72/1.5 -/.5']),
 ('A','同色的两个箱子','2/4',102,'Db major / Bb minor',[
 'Db|C|65/1 68/1','Bbm|C|70/.75 68/1.25','Ebm|C|66/1 63/1','Ab7|C|60/1.5 -/.5',
 'Db/F|C|61/.75 65/1.25','Gb|C|66/.75 70/1.25','F7|C|69/1 65/1','Bbm|C|65/1.5 -/.5']),
 ('B','小车卡住门沿','2/4',104,'Bb minor',[
 'Bbm|P|77/.5 73/.5 77/1','F7|P|75/.75 72/.25 69/1','Bbm|P|70/.5 73/.5 77/.5 75/.5','Ebm|P|78/1.5 -/.5',
 'Gb|P|78/.75 77/.25 73/1','Gbm|P|78/.5 81/.5 78/1','Db/Ab|P|77/.5 73/.5 68/1','Ab7|P|72/1 -/1']),
 ('B','电梯先到站','2/4',100,'Db major with minor iv',[
 'Ebm|C|63/1 66/1','Ab7|C|63/.75 60/1.25','Db/F|C|65/1 68/1','Gb|C|66/1.5 -/.5',
 'Gbm|C|66/.75 69/1.25','Db/Ab|C|68/1 65/1','Ab7|C|63/.75 66/1.25','Ab|C|68/1.25 -/.75']),
 ('B','留下签收的号码','2/4',98,'Db major to Gb major',[
 'Bbm|P|77/.5 80/.5 77/1','Ebm|P|78/.75 75/.25 70/1','Ab7|P|72/.5 75/.5 78/.5 75/.5','Db|P|73/1.5 -/.5',
 'Gb|C|66/1 70/1','Abm|C|68/1 63/1','Db7|C|65/.75 68/1.25','Gb|C|66/1.5 -/.5']),
 ('T','绕到宽的通道','3/4',90,'Gb major',[
 'Gb|P|78/1.5 82/1 80/.5','Db/F|P|77/2 73/1','Ebm|P|75/1 78/1.5 77/.5','Bbm|P|77/2 -/1',
 'Cb|P|78/1 75/1 71/1','Gb/Bb|P|73/1.5 78/1.5','Abm|P|80/1 78/1 75/1','Db7|P|77/2 -/1']),
 ('T','箱子的把手换一边','3/4',92,'Gb major',[
 'Gb|C|66/1.5 70/1.5','Ebm|C|66/2 63/1','Abm|C|68/1.5 66/1.5','Db7|C|65/2 -/1',
 'Bbm|C|65/1.5 70/1.5','Cb|C|66/1 63/2','Db7|C|65/1.5 68/1.5','Gb|C|66/2 -/1']),
 ('T','值班室的长窗','3/4',92,'Bb minor / Gb major',[
 'Bbm|P|77/1.5 82/1 80/.5','Fm|P|80/1 77/2','Gb|P|78/1 82/1 85/1','Db/F|P|80/2 -/1',
 'Ebm|P|82/1.5 78/1 75/.5','Ab7|P|78/1 75/1 72/1','Db|P|73/1.5 77/1.5','Gb|P|78/2 -/1']),
 ('T','登记表压在提手下','3/4',90,'Gb major to Db major',[
 'Cb|C|66/1.5 63/1.5','Abm|C|68/2 66/1','Gb/Bb|C|70/1.5 66/1.5','Gb|C|66/2 -/1',
 'Ebm|C|63/1.5 66/1.5','Ab7|C|68/1.5 66/1.5','Db/Ab|C|65/1 63/1 61/1','Ab7|C|60/2 -/1']),
 ('D','从货梯口重新出发','2/4',104,'Db major',[
 'Db|P|73/.75 77/.25 80/1','Gb|P|78/.5 73/.5 78/1','Ebm|P|75/.5 78/.5 82/1','Ab7|P|80/1 78/.75 -/.25',
 'Db/F|P|77/.75 80/.25 85/1','Bbm|P|82/1 80/.5 77/.5','Ebm|P|78/.5 75/.5 78/.5 80/.5','Ab7|P|84/1.5 -/.5']),
 ('D','月亮终于过了闸口','2/4',106,'Db major',[
 'Db|C|65/.75 68/1.25','Gb|C|66/1 70/1','Ebm|C|66/.75 63/1.25','Ab7|C|68/1.5 -/.5',
 'Bbm|C|70/1.5 68/.5','Gb|C|70/1 66/1','Ab7|C|63/.75 60/1.25','Db|C|61/1.5 -/.5']),
 ('R','按新的方向推车','2/4',102,'Db major',[
 'Db6|P|73/.5 77/.5 80/1','Gb|P|78/.75 77/.25 73/1','Bbm|P|77/.5 82/.5 80/1','Ab7|P|78/1 75/.75 -/.25',
 'Db/F|P|77/1 73/.5 68/.5','Ebm|P|70/.5 75/.5 78/1','Ab7|P|75/.75 72/.25 73/.5 75/.5','Db|P|77/1.5 -/.5']),
 ('R','行李牌藏进口袋','2/4',102,'Db major',[
 'Gb|C|66/.75 70/1.25','Db/F|C|68/1 65/1','Ebm|C|66/1 63/1','Ab7|C|60/1.5 -/.5',
 'Bbm|C|65/.75 70/1.25','Gb|C|66/.75 70/1.25','Ab7|C|68/1 63/1','Db6|C|65/1.5 -/.5']),
 ('R','少一件的车身','2/4',100,'Db major with minor iv',[
 'Bbm|P|77/.75 73/.25 70/1','Ebm|P|75/.5 78/.5 75/1','Gbm|P|78/.75 81/.25 78/1','Db/Ab|P|77/1 73/.75 -/.25',
 'Gb|P|78/.5 77/.5 73/1','Db/F|P|77/.75 80/.25 77/1','Ebm|P|75/.5 73/.5 70/.5 66/.5','Ab7|P|68/1.5 -/.5']),
 ('R','交接短信上的句号','2/4',100,'Db major',[
 'Db|C|61/1 65/1','Gb|C|66/.75 70/1.25','Ab7|C|68/1 63/1','Db|C|65/1.5 -/.5',
 'Ebm|P|75/.75 78/.25 77/1','Ab7|P|75/.5 72/.5 68/1','Db/Ab|P|73/.5 77/.5 75/1','Db|P|73/1.5 -/.5']),
 ('Z','空绑带扣上','2/4',96,'Db major',[
 'Gb|P|78/1 77/.5 73/.5','Db/F|P|77/.75 75/.25 73/1','Ebm|C|63/1 66/1','Ab7|C|63/1.5 -/.5',
 'Db/Ab|P|73/.5 77/.5 75/1','Ab7|P|72/1 75/.5 -/.5','Db|P|77/.75 75/.25 73/1','Db|P|73/1.8 -/.2']),
]
# First revision gives the trio actual long-breathed dimensions and a subdominant
# harmonic route, replacing these complete early statements in bars 57--72.
EARLY_TRIO=[
 ['Db|P|73/1 77/1 75/1','Ab|P|72/1 75/1 68/1','Bbm|P|73/1 77/1 75/1','Ab7|P|72/1.5 -/1.5','Gb|P|73/1 78/1 77/1','Db/F|P|77/1 75/1 73/1','Ebm|P|75/1 78/1 75/1','Ab7|P|72/1.5 -/1.5'],
 ['Db|C|61/1 65/1 63/1','Ab/C|C|63/1 68/1 60/1','Bbm|C|65/1 70/1 68/1','Ab7|C|63/1.5 -/1.5','Gb|C|66/1 70/1 66/1','Db/F|C|65/1 68/1 65/1','Ebm|C|63/1 66/1 63/1','Ab7|C|60/1.5 -/1.5']]
EARLY_RETURN=[
 ['Db|P|73/.5 77/.5 75/1','Db/Ab|P|68/.5 73/1.5','Gb|P|78/.75 77/.25 75/.5 73/.5','Ab7|P|72/1 75/.75 -/.25','Db/F|P|77/.5 80/.5 78/1','Ebm|P|75/.75 78/.25 77/.5 75/.5','Ab7|P|72/.5 75/.5 73/.5 72/.5','Db|P|73/1.5 -/.5'],
 ['Db|C|61/.75 65/1.25','Ab/C|C|63/1 68/1','Db/F|C|65/.75 63/1.25','Db|C|61/1.5 -/.5','Gb|C|66/.75 70/1.25','Bbm|C|68/1 65/1','Ab7|C|63/1 60/1','Db|C|61/1.5 -/.5'],
 ['Db6|P|77/.75 80/.25 78/.5 77/.5','Gb|P|78/1 73/.5 75/.5','Ebm|P|78/.5 82/.5 80/1','Ab7|P|75/1.5 -/.5','Fm|P|77/.5 75/.5 72/1','Bbm|P|73/.75 77/.25 80/1','Ebm|P|78/.5 75/.5 73/.5 75/.5','Ab|P|72/1.5 -/.5'],
 ['Db|C|65/1 68/1','Bbm|C|70/.75 68/1.25','Ebm|C|66/1 63/1','Ab7|C|60/1.5 -/.5','Db/F|P|73/.5 77/.5 80/1','Gb|P|78/1 73/1','Ab7|P|75/.5 72/.5 68/1','Db|P|73/1.5 -/.5'],
 ['Db|P|73/.5 77/.5 75/1','Ab|P|72/.5 75/.5 68/1','Db/F|C|65/1 68/1','Gb|C|66/1.5 -/.5','Ebm|P|75/.5 78/.5 75/1','Ab7|P|72/.5 75/.5 72/1','Db|P|77/.5 75/.5 73/1','Db|P|73/1.8 -/.2']]

def save(name,data):
 (ROOT/name).write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def hash_file(name): return hashlib.sha256((ROOT/name).read_bytes()).hexdigest()
def parse(notes):
 return [(None if p=='-' else int(p),float(d)) for p,d in (t.split('/') for t in notes.split())]
def rhythm_position(pitches):
 # Explicit five-key map selected from nearby diatonic keys, augmented only by
 # a scored chromatic key. Simultaneous fingers are always distinct.
 used=sorted(set(pitches)); assert len(used)<=5 and max(used)-min(used)<=12, used
 pool=[p for p in range(min(used)-5,max(used)+6) if p%12 in (1,3,5,6,8,10,0)]
 while len(used)<5:
  candidates=[p for p in pool if p not in used and max(used+[p])-min(used+[p])<=12]
  p=min(candidates,key=lambda x:(max(used+[x])-min(used+[x]),abs(x-sum(used)/len(used)),x));used.append(p);used.sort()
 return used

def compose(version):
 bars=[];plans=[];start=0.; elapsed=0.
 for qi,(section,label,meter,tempo,key,source) in enumerate(SENTENCES):
  rows=list(source)
  if version==0 and qi in (7,8):rows=EARLY_TRIO[qi-7]
  if version<2 and qi in (13,14,15,16,17):rows=EARLY_RETURN[qi-13]
  for j,row in enumerate(rows):
   hn,lead,tokens=row.split('|'); beats=float(meter[0]); bpm=tempo+[0,1,0,-1,1,1,0,-2][j]
   if qi==17:bpm=[98,98,96,96,96,94,92,88][j]
   n=len(bars)+1; notes=parse(tokens); assert abs(sum(d for p,d in notes)-beats)<1e-9,(n,notes)
   b={'bar':n,'start':start,'beats':beats,'bpm':bpm,'meter':meter,'meter_numerator':int(beats),'meter_denominator':4,'section':section,'section_title_zh':{'A':'晚班转车','B':'门口的交接','T':'宽通道','D':'货梯路线','R':'改道后的进行曲','Z':'空绑带'}[section],'harmony_name':hn,'harmony':H[hn][0]+H[hn][1],'lead_instrument':'piano' if lead=='P' else 'clarinet','key_region':key if version or qi not in (7,8) else 'Db major','phrase_id':f'P{qi+1:02d}','macro_phrase_id':f'P{qi+1:02d}','macro_phrase_length_bars':8,'phrase_position':j+1,'phrase_label':label,'time_start_seconds':round(elapsed,9),'role_plan':'Piano cantabile over harmonic LH; clarinet rests.' if lead=='P' else 'Clarinet owns melody; piano provides soft chordal support with no countermelody.'}
   bars.append(b);plans.append(notes);start+=beats;elapsed+=beats*60/bpm
 starts=[b['start'] for b in bars]; cumulative=[0.]
 for b in bars:cumulative.append(cumulative[-1]+b['beats']*60/b['bpm'])
 def sec(t):
  i=min(len(bars)-1,max(0,bisect.bisect_right(starts,t)-1));b=bars[i]
  return cumulative[i]+(t-b['start'])*60/b['bpm']
 events=[];pedals=[];counts=defaultdict(int)
 def add(b,on,dur,p,vel,inst,hand,voice,role,position=None,written=None):
  key=(b['bar'],inst,voice);counts[key]+=1;pid=b['phrase_id']+'_piano' if inst=='piano' else b['phrase_id']+('_clarinet_a' if b['phrase_position']<=4 else '_clarinet_b')
  layer='natural' if inst=='piano' else ('pp' if vel<=55 else 'mf' if vel<=95 else 'ff')
  e={'event_id':f'w90-b{b["bar"]:03d}-{inst}-{voice}-{counts[key]:02d}','bar':b['bar'],'onset':round(b['start']+on,8),'duration':round(dur,8),'pitch':p,'velocity':vel,'instrument':inst,'voice':voice,'hand':hand,'role':role,'phrase_id':pid,'phrase_label':b['phrase_label'],'harmony_name':b['harmony_name'],'layer':layer,'sample_layer':'approved_natural_piano' if inst=='piano' else layer,'onset_reference':'ordinary_trigger','harmonic_function':'chord_tone' if p%12 in {x%12 for x in b['harmony']} else 'passing_or_neighbor_melodic_tension','articulation':'cantabile_finger_release' if inst=='piano' and role=='lead' else 'soft_separated_chord' if inst=='piano' else 'naturally_separated_breathed_tone'}
  if written is not None:e['written_value_beats']=written
  if inst=='piano':
   ks=position; e.update(hand_position_id=('R' if hand=='right' else 'L')+'_'.join(map(str,ks)),hand_position_keys=ks,hand_position_range=[ks[0],ks[-1]],finger=(list(range(1,len(ks)+1)) if hand=='right' else [5,3,1])[ks.index(p)],fingering_intent='Explicit named keys; right fingers ascend 1–5, left triad fingers 5/3/1. Whole-hand movement occurs only after actual release.')
  else:e.update(source_pitch_midi=p,source_family='University of Iowa clarinet',velocity_controls='recorded_layer_selection_and_within_layer_amplitude_intent',sample_transition='none',timing_intent='Unshifted natural sample trigger. Nominal gate and breath only; actual sample envelope checked by owner.')
  events.append(e);return e
 for b,melody in zip(bars,plans):
  n=b['bar'];q=(n-1)//8;j=(n-1)%8;trip=b['beats']==3;lh,rh=H[b['harmony_name']];c=b['lead_instrument']=='clarinet';secbeat=60/b['bpm'];energy={'A':0,'B':2,'T':-5,'D':10,'R':1,'Z':-7}[b['section']]
  # Eight distinct sentence accompaniment profiles: bass/dyad march, held
  # harmony, lifted second beat, and sparse bridges. The trio uses whole-bar
  # harmonic arcs rather than a copied two-beat pattern.
  mode=(q+j//2)%4
  if trip:
   pats=[[(0,[0,2],1.65),(2.2,[1],.44)],[(0,[0,1,2],2.25)],[(0,[0],1.1),(1.5,[1,2],.92)],[(.15,[0,2],2.35)]]
  else:
   pats=[[(0,[0],.55),(1,[1,2],.54)],[(0,[0,2],1.43)],[(0,[0,1,2],.64),(1.25,[2],.42)],[(0,[0],.66),(.9,[1,2],.72)]]
  pattern=pats[mode]
  if n in (40,48,56,88):pattern=[(0,[0,2],.7)]
  if n==144:lh=[37,44,49];pattern=[(0,[0,1,2],1.7)]
  for on,ixs,dur in pattern:
   for ix in ixs:add(b,on,dur,lh[ix],max(29,44+energy-(4 if c else 0)+(2 if ix==0 else 0)), 'piano','left','harmonic_foundation','support',lh)
  if c:
   # One or two chordal arrivals, never an independent melodic line.
   supportmode=(q+j)%3
   pos=rhythm_position(rh)
   if trip:sp=[(.12,1.7)] if supportmode!=2 else [(.15,.82),(1.7,.78)]
   else:sp=[(.12,1.27)] if supportmode else [(.12,.55),(1.15,.45)]
   if n in (48,56,88):sp=[(.12,.7)]
   for on,dur in sp:
    for p in rh[1:] if supportmode==1 else rh[:2]:add(b,on,dur,p,37+energy,'piano','right','chordal_support','support',pos)
  pos=rhythm_position([p for p,d in melody if p is not None]) if not c else None
  t=0.
  for k,(p,written) in enumerate(melody):
   if p is None:t+=written;continue
   if c:
    assert 60<=p<=71
    # Rhythms normally allow a 90 ms separation. The one half-beat pickup at
    # the climax is explicitly lengthened to a 0.30 s gate and receives its
    # release space by delaying the following bar's first breath/attack.
    gate=min(1.40,max(.30,written*secbeat-.09))
    if j in (3,7) and k==max(z for z,(x,y) in enumerate(melody) if x is not None):gate=min(gate,written*secbeat-.25)
    vel=(51 if trip else 70)+energy+[0,2,-2,1][k%4]
    if n in (101,102):vel=99 if k==0 else 89
    if b['section']=='Z':vel=51
    add(b,t,gate/secbeat,p,vel,'clarinet','not_applicable','cantabile_melody','lead',None,written)
   else:
    release=.055 if written<=.5 else .075
    dur=max(.10,written-release/secbeat)
    if j in (3,7):dur=min(dur,b['beats']-t-.18/secbeat)
    vel=67+energy+[0,3,-2,1][k%4]+(3 if j in (2,5) else 0)
    add(b,t,dur,p,vel,'piano','right','melody','lead',pos,written)
   t+=written
  if n==144:
   lead=[e for e in events if e['bar']==144 and e['role']=='lead'][0]
   pos=rhythm_position([65,68,73]);lead.update(hand_position_keys=pos,hand_position_range=[min(pos),max(pos)],hand_position_id='R'+'_'.join(map(str,pos)),finger=pos.index(73)+1)
   for p in (65,68):add(b,0,lead['duration'],p,47,'piano','right','cadential_harmony','support',pos)
  # Pedal re-articulates each bar. Numeric values express musical intent only.
  if trip or mode==1 or n==144:
   pedals.extend([{'bar':n,'onset':round(b['start']+.10,8),'value':58 if trip else 45,'instrument':'piano','controller':64,'phrase_id':b['phrase_id']+'_piano','kind':'resonance_intent'},{'bar':n,'onset':round(b['start']+b['beats']-.12,8),'value':0,'instrument':'piano','controller':64,'phrase_id':b['phrase_id']+'_piano','kind':'release'}])
 # Finalize actual hand release before every named transfer, conservatively
 # including both grip-edge and position-edge travel. This only adjusts key
 # gates; no pedal time is used as held time, no onset or pitch is shifted.
 release_adjustments=[]
 for hand in ('left','right'):
  ns=[e for e in events if e['instrument']=='piano' and e['hand']==hand];groups=defaultdict(list)
  for e in ns:groups[e['onset']].append(e)
  gg=sorted(groups.items())
  for (oldon,old),(on,new) in zip(gg,gg[1:]):
   same=old[0]['hand_position_id']==new[0]['hand_position_id'];og=[min(e['pitch'] for e in old),max(e['pitch'] for e in old)];ng=[min(e['pitch'] for e in new),max(e['pitch'] for e in new)];gp=max(abs(x-y) for x,y in zip(og,ng));pm=max(abs(x-y) for x,y in zip(old[0]['hand_position_range'],new[0]['hand_position_range']))
   if same and (hand=='right' or gp<=4):continue
   need=.075+.012*max(0,max(gp,pm)-4)+.010
   for e in ns:
    if e['onset']>=on:continue
    end=e['onset']+e['duration'];gap=sec(on)-sec(end)
    if gap<need:
     # All transfers here happen inside a bar or at its boundary; convert
     # required release to that preceding event's local tempo.
     eb=bars[e['bar']-1];newdur=(sec(on)-need-sec(e['onset']))*eb['bpm']/60
     assert newdur>.045,(hand,on,e,newdur)
     e['duration']=round(newdur,8);e['released_transfer_allowance_seconds']=round(need,6);release_adjustments.append(e['event_id'])
 # Only half-beat clarinet note occurs at b101 end. Earlier v0--v2 versions
 # contain the same climax. Give b102 its actual 65 ms air gap, preserving
 # the written pulse with a tiny delayed attack and shortened first gate.
 cs=sorted([e for e in events if e['instrument']=='clarinet'],key=lambda e:e['onset'])
 for a,e in zip(cs,cs[1:]):
  gap=sec(e['onset'])-sec(a['onset']+a['duration'])
  if gap<.065-1e-8:
   shift=(.065-gap)*bars[e['bar']-1]['bpm']/60;e['onset']=round(e['onset']+shift,8);e['duration']=round(e['duration']-shift,8);e['timing_intent']+=' Authored delayed re-entry after breath; this is musical timing, not sample compensation.'
 for e in events:
  e.update(target_on_beats=e['onset'],target_off_beats=round(e['onset']+e['duration'],8),target_on_seconds=round(sec(e['onset']),9),target_off_seconds=round(sec(e['onset']+e['duration']),9))
  if e['instrument']=='clarinet':e['nominal_gate_seconds']=round(sec(e['onset']+e['duration'])-sec(e['onset']),9)
 for e in pedals:e['target_on_seconds']=round(sec(e['onset']),9)
 events.sort(key=lambda e:(e['onset'],e['instrument'],e['pitch'],e['event_id']));pedals.sort(key=lambda e:e['onset'])
 phrases=[]
 for pid in sorted({e['phrase_id'] for e in events}):
  es=[e for e in events if e['phrase_id']==pid];a=min(e['onset'] for e in es);z=max(e['onset']+e['duration'] for e in es);first=min(e['bar'] for e in es);last=max(e['bar'] for e in es)
  phrases.append({'phrase_id':pid,'instrument':es[0]['instrument'],'phrase_label':es[0]['phrase_label'],'first_bar':first,'last_bar':last,'section':bars[first-1]['section'],'layer':es[0]['layer'] if len({e['layer'] for e in es})==1 else 'mixed_recorded_layers','role':'lead_and_support' if len({e['role'] for e in es})>1 else es[0]['role'],'layers_used':sorted({e['layer'] for e in es}),'roles_used':sorted({e['role'] for e in es}),'voices_used':sorted({e['voice'] for e in es}),'target_on_beats':a,'target_off_beats':round(z,8),'target_on_seconds':round(sec(a),9),'target_off_seconds':round(sec(z),9),'timing_intent':'Eight-bar harmonic sentence, divided into genuine four-bar breaths for clarinet.'})
 return {'id':90,'title':'The Moon’s Lost Luggage','title_zh':'月亮遗失的行李','version':f'v{version}','instrumentation':['natural_acoustic_piano','Iowa_clarinet_C4_B4_pp_mf_ff'],'bars':bars,'events':events,'phrases':phrases,'pedals':pedals,'total_beats':start,'tail_seconds':5.,'music_seconds':round(sec(start),9),'total_seconds_with_tail':round(sec(start)+5,9),'cadences':[{'bar':b['bar'],'harmony':b['harmony_name'],'function':'sentence punctuation' if b['bar']!=144 else 'closed Db tonic with fastened empty strap'} for b in bars if b['phrase_position']==8],'performance_contract':{'audio_status':'Symbolic composition only. No audio, DSP, source access, downloads, installations or listening.','beat_unit':'Absolute quarter-note beats. 2/4 = 2 beats; 3/4 = 3 beats. bpm is quarter-note tempo.','piano_source':'Existing approved natural grand.','piano_hand_span_semitones':12,'piano_fingering':'Each event names exact position keys, position bounds and finger. RH fingers 1–5 ascend; LH triads use 5/3/1. No same-key overlap or crossing.','piano_travel_rule':'Every actual position change and LH whole-grip edge movement over four semitones requires 75 ms +12 ms per additional semitone after the real release of all prior keys. Travel uses max(actual grip-edge, declared position-edge). RH motion in unchanged named positions uses explicit fingers.','pedal':'Piano CC64 only. Resonance never counts as hand holding. Exact zero releases before harmonic changes.','clarinet_source':'University of Iowa clarinet, genuinely recorded C4–B4 (MIDI 60–71), pp/mf/ff only. No pitch transposition.','clarinet_layers':{'pp':'velocity 1–55','mf':'velocity 56–95','ff':'velocity 96–127; two locally earned climax arrivals only'},'clarinet_gate_seconds':[.30,1.5],'clarinet_min_inter_note_gap_seconds':.065,'clarinet_breath':'At least 0.25 seconds between distinct four-bar breath groups.','clarinet_articulation':'Natural separate or breathed ordinary triggers. No sampled legato, artificial articulation or sample pre-shift.','balance':'One melodic lead per bar. Clarinet sentences have sparse soft piano chords; piano sentences keep clarinet silent.','verification_limit':'Nominal pitch/gate/position/role contracts only. Actual source attack, release, tone, loudness and rendered balance require later owner verification.'}}

def exact_diff(a,b):
 changes=[];musical=[]
 for ab,bb in zip(a['bars'],b['bars']):
  n=ab['bar'];ae=[e for e in a['events'] if e['bar']==n];be=[e for e in b['events'] if e['bar']==n];ap=[e for e in a['pedals'] if e['bar']==n];bp=[e for e in b['pedals'] if e['bar']==n]
  if (ab,ae,ap)!=(bb,be,bp):changes.append({'bar':n,'before_bar':ab,'after_bar':bb,'before_events':ae,'after_events':be,'before_pedals':ap,'after_pedals':bp})
  core=lambda es:[{k:e[k] for k in ('onset','duration','pitch','instrument','voice','hand')} for e in es]
  if core(ae)!=core(be) or ab['harmony']!=bb['harmony']:musical.append(n)
 top={k:v for k,v in b.items() if k not in ('bars','events','pedals') and a.get(k)!=v}
 return {'before_version':a['version'],'after_version':b['version'],'before_sha256':hash_file('score_'+a['version']+'.json'),'after_sha256':hash_file('score_'+b['version']+'.json'),'changed_bars':[c['bar'] for c in changes],'strict_musical_changed_bars':musical,'top_level_replacements':top,'changes':changes}

def main():
 scores=[compose(v) for v in range(3)]
 for v,s in enumerate(scores):save(f'score_v{v}.json',s)
 (ROOT/'score.json').write_bytes((ROOT/'score_v2.json').read_bytes())
 for a,b in zip(scores,scores[1:]):
  stem=f'exact_diff_{a["version"]}_to_{b["version"]}';save(stem+'.json',exact_diff(a,b))
  an='score_'+a['version']+'.json';bn='score_'+b['version']+'.json';patch=''.join(difflib.unified_diff((ROOT/an).read_text().splitlines(True),(ROOT/bn).read_text().splitlines(True),fromfile=an,tofile=bn));(ROOT/(stem+'.patch')).write_text(patch,encoding='utf-8')
 for v,s in enumerate(scores):print(s['version'],len(s['bars']),len(s['events']),s['total_seconds_with_tail'])
if __name__=='__main__':main()
