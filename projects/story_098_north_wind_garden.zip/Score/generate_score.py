"""Original five-eighth piano/flute score. No audio, libraries or network."""
from pathlib import Path
import argparse, difflib, hashlib, json
ROOT=Path(__file__).resolve().parent
PC={'C':0,'D':2,'E':4,'F':5,'G':7,'A':9,'B':11}
def midi(s):return 12*(int(s[-1])+1)+PC[s[0]]+s[1:-1].count('#')-s[1:-1].count('b')
LINES=[
 'D5 E5 G5 E5 D5 | B4 D5 E5 G5 E5 | C5 E5 G5 F#5 E5 | D5 F#5 A5 G5 F#5 | E5 G5 B5 A5 G5 | C5 B4 A4 C5 E5 | F#5 E5 D5 C5 A4 | B4 D5 G5 D5 B4',
 'G4 B4 D5 E5 D5 | A4 C5 E5 D5 C5 | B4 D5 F#5 E5 D5 | G4 C5 E5 D5 C5 | A4 B4 D5 E5 D5 | F#4 A4 C5 D5 C5 | B4 D5 G5 F#5 D5 | E5 D5 B4 G4',
 'D5 G5 | E5 B5 | G5 E5 | D5 | B4 D5 E5 G5 E5 | C5 E5 G5 E5 C5 | F#5 E5 D5 A4 D5 | B4 D5 G5 D5 B4',
 'E5 G5 | F#5 A5 | E5 D5 | B5 | D5 G5 A5 G5 E5 | C5 E5 G5 F#5 E5 | D5 F#5 A5 F#5 D5 | B4 D5 G5 B4',
 'E5 G5 | F#5 A5 | G5 B5 | F#5 | B4 E5 G5 F#5 E5 | C5 E5 G5 E5 C5 | A4 C5 E5 D5 C5 | B4 D#5 F#5 D#5 B4',
 'G5 E5 | F#5 D5 | E5 C5 | D#5 | E5 D5 B4 G4 B4 | D5 B4 A4 G4 | C5 B4 A4 E4 A4 | F#4 A4 B4 D#5 B4',
 'B5 G5 | A5 F#5 | G5 E5 | F#5 | G4 B4 E5 D5 B4 | A4 C5 E5 D5 C5 | D#5 F#5 E5 D#5 B4 | E5 B4 G4 E4',
 'D5 E5 G5 A5 G5 | E5 G5 B5 A5 G5 | F#5 A5 B5 A5 F#5 | G5 E5 D5 B4 | E5 G5 A5 G5 E5 | F#5 E5 D5 A4 | C5 E5 G5 F#5 E5 | D5 F#5 G5 F#5 D5',
 'D5 E5 | G5 B5 | A5 F#5 | G5 | B4 D5 G5 F#5 D5 | C5 E5 G5 E5 C5 | F#5 E5 D5 C5 A4 | B4 D5 G5 D5 B4',
 'D5 G5 | E5 B5 | G5 E5 | D5 | E5 G5 B5 A5 G5 | D5 F#5 A5 G5 F#5 | C5 E5 G5 F#5 E5 | B4 D5 G5 F#5 D5',
 'G5 A5 B5 A5 G5 | F#5 A5 D6 A5 F#5 | E5 G5 B5 G5 E5 | D5 F#5 A5 F#5 D5 | E5 G5 | F#5 A5 | E5 D5 | B5',
 'D5 E5 G5 E5 D5 | C5 E5 A5 G5 E5 | B4 D5 G5 F#5 D5 | A4 C5 E5 D5 C5 | E5 G5 B5 A5 G5 | D5 F#5 A5 G5 F#5 | C5 E5 G5 E5 D5 | B4 D5 G5 D5 B4',
 'D5 B4 G4 B4 D5 | C5 E5 D5 C5 A4 | B4 D5 E5 D5 B4 | A4 C5 D5 C5 A4 | E5 G5 | F#5 D5 | E5 C5 | D5',
 'B4 D5 G5 D5 B4 | A4 C5 E5 C5 A4 | F#4 A4 D5 C5 A4 | G4 B4 D5 B4 G4 | D5 G5 | E5 D5 | B5 A5 | G5',
]
HARM_ROWS=[
 'G Em C D7 Em Am D7 G',
 'G Am D C Em D7 G/B G',
 'G Em C D G C D7 G',
 'Em D C G G C D7 G',
 'Em D Em B7 Em C Am B7',
 'Em D C B7 Em G Am B7',
 'Em D C B7 Em Am B7 Em',
 'G Em D G C D C D7',
 'G Em D G G C D7 G',
 'G Em C D Em D C G',
 'G D Em D C D C G',
 'G Am G Am Em D C G',
 'G Am Em D C D7 Am D7',
 'G Am D7 G G C D7 G',
]
H={'G':[43,47,50],'G/B':[47,50,55],'G/D':[50,55,59],'Em':[40,43,47],'Em/G':[43,47,52],'Em/B':[47,52,55],'C':[48,52,55],'C/G':[43,48,52],'Cmaj7':[48,52,55,59],'Am':[45,48,52],'Am/C':[48,52,57],'D':[50,54,57],'D/F#':[42,45,50],'D7':[50,54,57,60],'B7':[47,51,54,57],'B7/D#':[39,42,45,47]}
WIND=set(list(range(17,21))+list(range(25,29))+list(range(33,37))+list(range(41,45))+list(range(49,53))+list(range(65,69))+list(range(73,77))+list(range(85,89))+list(range(101,105))+list(range(109,113)))
V1={
33:'G5 E5',34:'A5 F#5',35:'B5 G5',36:'D#5',37:'G4 B4 E5 F#5 E5',38:'E5 G5 E5 D5 C5',39:'C5 E5 D5 C5 A4',40:'D#5 F#5 E5 D#5 B4',
41:'B5 G5',42:'A5 F#5',43:'G5 E5',44:'D#5',45:'B4 E5 G5 E5 D5',46:'D5 G5 F#5 D5 B4',47:'A4 C5 E5 C5 A4',48:'D#5 B4 A4 F#4 B4',
49:'G5 B5',50:'F#5 A5',51:'E5 G5',52:'D#5',53:'B4 E5 G5 F#5 E5',54:'C5 E5 D5 C5 A4',55:'D#5 F#5 E5 D#5 B4',56:'G4 B4 E5 B4 G4',
}
V1_H={33:'Em/G',34:'D/F#',35:'Em/B',37:'Em/G',38:'Cmaj7',39:'Am/C',40:'B7/D#',41:'Em/B',42:'D/F#',43:'Cmaj7',45:'Em/G',46:'G/B',47:'Am/C',49:'Em/B',50:'D/F#',51:'C/G',53:'Em/G',54:'Am/C',55:'B7/D#'}
V2={
73:'G5 D5',74:'B5 E5',75:'E5 G5',76:'F#5',77:'G5 B5 A5 G5 E5',78:'F#5 A5 G5 F#5 D5',79:'E5 G5 F#5 E5 C5',80:'D5 G5 F#5 D5 B4',
81:'B5 A5 G5 E5 G5',82:'A5 D6 B5 A5 F#5',83:'G5 B5 A5 G5 E5',84:'F#5 A5 G5 F#5 D5',85:'G5 E5',86:'A5 F#5',87:'D5 E5',88:'G5',
89:'G4 B4 D5 E5 D5',90:'C5 E5 G5 E5 C5',91:'D5 G5 F#5 D5 B4',92:'C5 E5 D5 C5 A4',93:'G5 E5 D5 B4',94:'F#5 D5 A4 D5 F#5',95:'E5 D5 C5 G4',96:'D5 B4 G4',
105:'G4 B4 D5 B4 G4',106:'A4 C5 E5 D5 C5',107:'F#4 A4 D5 C5 A4',108:'G4 B4 D5 B4 G4',109:'G5 D5',110:'E5 C5',111:'A5 F#5',112:'G5',
}
V2_H={73:'G/B',74:'Em/B',75:'Cmaj7',77:'Em/B',78:'D/F#',79:'C/G',80:'G/B',81:'G/D',82:'D/F#',83:'Em/B',85:'C/G',87:'Cmaj7',89:'G/B',90:'Am/C',91:'G/D',92:'Am/C',93:'Em/G',94:'D/F#',95:'C/G',105:'G/B',106:'Am/C',107:'D/F#',108:'G/D',110:'C/G'}
LABELS=['给育苗盘留出号码','沿墙挪开第一排','把标签递到另一只手','玻璃间的空位置','字迹开始洇开','重新辨认幼叶','分别放回托盘','推车转过门槛','两人换一下位置','回头再数一遍','把朝窗的一面转回来','摆好留下的那排','等最后一个人下楼','将门上的纸压平']
SECTIONS=[(1,16,'A','露台上编号','G major'),(17,32,'B','分开两条搬运路线','G major'),(33,56,'C','湿掉的标签','E minor'),(57,72,'D','推车转过门槛','G major'),(73,96,'A2','核对后再摆放','G major'),(97,112,'Coda','留下的那一排','G major')]
def section(n):return next(x for x in SECTIONS if x[0]<=n<=x[1])
def bpm(n):
 if n<=16:return 80 if n%8 else 76
 if n<=32:return 82 if n%4 else 78
 if n<=56:return 78 if n%4 else 76
 if n<=72:return 84 if n not in WIND and n%8 else 80
 if n<=96:return 82 if n%8 else 78
 return 78 if n<109 else 76
def seconds(bars,t):return sum(min(max(t-b['start'],0),b['beats'])*60/b['bpm'] for b in bars)
def fingermap(keys,hand):
 fs={1:[3],2:[1,5],3:[1,3,5],4:[1,2,4,5],5:[1,2,3,4,5]}[len(keys)]
 if len(keys)==4:
  widest=max(range(3),key=lambda i:keys[i+1]-keys[i]);fs=([1,3,4,5],[1,2,4,5],[1,2,3,5])[widest]
 return dict(zip(keys,fs if hand=='right' else [6-f for f in fs]))
def build(version):
 level=int(version[1:]);lines=[s.strip() for row in LINES for s in row.split('|')];harm=[s for row in HARM_ROWS for s in row.split()];assert len(lines)==len(harm)==112
 for lv,changes,chords in [(1,V1,V1_H),(2,V2,V2_H)]:
  if level>=lv:
   for n,x in changes.items():lines[n-1]=x
   for n,x in chords.items():harm[n-1]=x
 bars=[];events=[];plans=[];pedals=[]
 for n in range(1,113):
  start=(n-1)*2.5;_,_,sect,title,key=section(n);wind=n in WIND;inst='flute' if wind else 'piano';pid=f'P{(n-1)//4+1:02d}_{inst}';h=harm[n-1];ch=H[h]
  texture='two_three_light_steps'
  if wind:texture='flute_line_over_quiet_shell'
  if level>=1 and 33<=n<=56:texture='checking_labels_inner_exchange'
  if level>=2 and 73<=n<=96:texture='changed_return_spacing'
  if n>=97:texture='last_trays_settled'
  b={'bar':n,'start':start,'beats':2.5,'bpm':bpm(n),'meter':'5/8','meter_numerator':5,'meter_denominator':8,'section':sect,'section_title_zh':title,'key_region':key,'harmony_name':h,'harmony':ch,'lead_instrument':inst,'lead_hand':None if wind else 'right','phrase_id':f'P{(n-1)//4+1:02d}','phrase_position':(n-1)%4+1,'texture':texture,'metrical_grouping':'2+3 eighth notes','role_plan':'One foreground at a time; flute breath and piano melody share the same chord-bound support.'};bars.append(b)
  def add(p,at,dur,vel,instrument,voice,hand,role,written):
   e={'bar':n,'onset':round(start+at,6),'duration':round(dur,6),'pitch':p,'velocity':vel,'instrument':instrument,'voice':voice,'hand':hand,'role':role,'phrase_id':pid if role=='lead' else f'P{(n-1)//4+1:02d}_piano','phrase_label':LABELS[(n-1)//8],'harmony_name':h,'harmonic_function':'chord_tone' if p%12 in {k%12 for k in ch} else 'melodic_nonchord_tone','written_value_beats':written};events.append(e);return e
  ps=[midi(s) for s in lines[n-1].split()]
  energy=68 if n<=32 else 65 if n<=56 else 74 if n<=72 else 79 if n<=96 else 62
  if wind:
   assert 1<=len(ps)<=2
   layer='pp' if n<=20 or 41<=n<=44 or n>=101 else 'mf';velocity=(48 if layer=='pp' else 78)+(n%3)-1
   for i,pitch in enumerate(ps):
    at=.2 if i==0 else 1.8;dur=1.7 if len(ps)==1 else 1.15 if i==0 else .5
    e=add(pitch,at,dur,velocity+(1 if i==0 else -1),'flute','breathing_melody','not_applicable','lead',dur);e.update(layer=layer,sample_layer=layer,articulation='separate_breathed_flute_with_recorded_vibrato',onset_reference='ordinary_trigger',nominal_gate_seconds=dur*60/bpm(n),timing_correction_applied_seconds=0.,source_pitch_midi=pitch)
  else:
   ds={3:[1,.5,1],4:[.5,.5,.5,1],5:[.5]*5}[len(ps)]
   if level>=2 and n in V2 and len(ps)==4:ds=[1,.5,.5,.5]
   at=0
   for i,(pitch,w) in enumerate(zip(ps,ds)):
    gap=.12 if i<len(ps)-1 else .26;e=add(pitch,at,w-gap,energy+[1,-2,2,0,-1][i%5],'piano','melody','right','lead',w);e['articulation']='light_connected_piano_phrase';at+=w
  quiet=(37 if wind else energy-24);shell=[ch[0],ch[-1]];inner=ch[1:-1] or [ch[1]]
  gestures=[(0,.68,shell),(1.5,.48,inner)] if wind else [(0,.55,[ch[0]]),(1,.40,ch[1:]),(1.75,.44,shell)]
  if level>=1 and 33<=n<=56:gestures=[(0,.64,shell),(.95,.34,inner),(1.70,.42,ch)]
  if level>=2 and 73<=n<=96:gestures=[(.1,.62,shell),(1.25,.36,inner),(1.95,.28,ch[1:])]
  if n>=97:gestures=[(0,.9,shell),(1.5,.55,inner)]
  if n==112:gestures=[(0,2.5,ch)]
  for at,dur,keys in gestures:
   for pitch in keys:
    e=add(pitch,at,dur,quiet,'piano','harmonic_support','left','support',min(dur+.1,2.5-at));e['articulation']='light_shared_harmony'
  for hand in ['left','right']:
   ns=[e for e in events if e['bar']==n and e['hand']==hand];keys=sorted({e['pitch'] for e in ns});pos={'bar':n,'hand':hand,'position_id':f'b{n:03d}_{hand}','active':bool(keys),'range':[keys[0],keys[-1]] if keys else None,'pitch_finger_map':{}}
   if keys:
    assert len(keys)<=5 and keys[-1]-keys[0]<=12,(version,n,hand,keys);fm=fingermap(keys,hand);pos['pitch_finger_map']={str(k):v for k,v in fm.items()}
    for e in ns:e.update(finger=fm[e['pitch']],hand_position_id=pos['position_id'],hand_position_range=pos['range'],position_keys=keys)
   plans.append(pos)
  pedals.extend([{'bar':n,'onset':start,'controller':64,'value':0,'instrument':'piano'},{'bar':n,'onset':start+.08,'controller':64,'value':26,'instrument':'piano'},{'bar':n,'onset':start+2.2,'controller':64,'value':0,'instrument':'piano'}])
 pedals.append({'bar':112,'onset':280.,'controller':64,'value':0,'instrument':'piano'});hp={(p['bar'],p['hand']):p for p in plans}
 for hand in ['left','right']:
  times=sorted({e['onset'] for e in events if e['hand']==hand})
  for a,z in zip(times,times[1:]):
   old=[e for e in events if e['hand']==hand and e['onset']==a];new=[e for e in events if e['hand']==hand and e['onset']==z];ok=[e['pitch'] for e in old];nk=[e['pitch'] for e in new];op=hp[(old[0]['bar'],hand)];np=hp[(new[0]['bar'],hand)];travel=max(abs(min(ok)-min(nk)),abs(max(ok)-max(nk)),max(abs(x-y) for x in ok for y in nk),max(abs(x-y) for x,y in zip(op['range'],np['range'])) if op['position_id']!=np['position_id'] else 0);required=.075+.012*max(0,travel-4)+.014;limit=seconds(bars,z)-required
   for e in old:
    if seconds(bars,e['onset']+e['duration'])>limit:e['duration']=round((limit-seconds(bars,e['onset']))*bars[e['bar']-1]['bpm']/60,6);e['release_adjustment']='Actual complete hand release for conservative grip/key travel plus14ms margin.'
    assert e['duration']*60/bars[e['bar']-1]['bpm']>=.06,(version,'short physical gate',e)
 events.sort(key=lambda e:(e['onset'],e['instrument'],e['hand'],e['pitch'],e['voice']));counter={}
 for e in events:
  k=(e['bar'],e['instrument'],e['voice']);counter[k]=counter.get(k,0)+1;e['event_id']=f'w98-b{e["bar"]:03d}-{e["instrument"]}-{e["voice"]}-{counter[k]:02d}';e.update(target_on_beats=e['onset'],target_off_beats=round(e['onset']+e['duration'],6),target_on_seconds=round(seconds(bars,e['onset']),9),target_off_seconds=round(seconds(bars,e['onset']+e['duration']),9))
 phrases=[]
 for pid in sorted({e['phrase_id'] for e in events}):
  ns=[e for e in events if e['phrase_id']==pid];a=min(e['onset'] for e in ns);z=max(e['onset']+e['duration'] for e in ns);first=min(e['bar'] for e in ns);last=max(e['bar'] for e in ns);inst=ns[0]['instrument'];phrases.append({'phrase_id':pid,'instrument':inst,'first_bar':first,'last_bar':last,'phrase_label':LABELS[(first-1)//8],'target_on_beats':a,'target_off_beats':round(z,6),'target_on_seconds':round(seconds(bars,a),9),'target_off_seconds':round(seconds(bars,z),9),'role':'breathing_lead' if inst=='flute' else 'lead_or_support','layers_used':sorted({e['layer'] for e in ns if 'layer' in e})})
 return {'id':98,'title':'A Garden for the North Wind','title_zh':'北风花园','version':version,'instrumentation':['natural_acoustic_piano','sampled_flute_pp_mf'],'bars':bars,'events':events,'phrases':phrases,'pedals':pedals,'total_beats':280.,'tail_seconds':6,'hand_position_plan':plans,'performance_contract':{'beat_unit':'quarter-note beats;5/8=2.5','flute':'Original C5–B5 pp/mf only, ordinary triggers. Owner adds measured attack alignment exactly once with a shared preroll. No sampled legato or loops.','piano':'Conservative actual held-key and grip-edge transfers; pedal never substitutes for release.','limits':'Symbolic constraints are not acoustic or listening approval.'}}
def dumps(x):return json.dumps(x,ensure_ascii=False,indent=2)+'\n'
def patch(a,b,path=''):
 if a==b:return []
 if isinstance(a,dict) and isinstance(b,dict):
  out=[]
  for k in sorted(set(a)|set(b)):
   p=path+'/'+k.replace('~','~0').replace('/','~1')
   if k not in b:out.append({'op':'remove','path':p})
   elif k not in a:out.append({'op':'add','path':p,'value':b[k]})
   else:out+=patch(a[k],b[k],p)
  return out
 return [{'op':'replace','path':path,'value':b}]
def emit_diff(root,a,b):
 before=dumps(a);after=dumps(b);changes=[]
 for n in range(1,113):
  row={'bar':n,'before_bar':a['bars'][n-1],'after_bar':b['bars'][n-1],'before_events':[e for e in a['events'] if e['bar']==n],'after_events':[e for e in b['events'] if e['bar']==n],'before_pedals':[e for e in a['pedals'] if e['bar']==n],'after_pedals':[e for e in b['pedals'] if e['bar']==n]}
  if any(row['before_'+k]!=row['after_'+k] for k in ['bar','events','pedals']):changes.append(row)
 av,bv=a['version'],b['version'];d={'from_version':av,'to_version':bv,'before_sha256':hashlib.sha256(before.encode()).hexdigest(),'after_sha256':hashlib.sha256(after.encode()).hexdigest(),'changed_bars':[x['bar'] for x in changes],'changes':changes,'phrase_metadata_before':a['phrases'],'phrase_metadata_after':b['phrases'],'position_plan_before':a['hand_position_plan'],'position_plan_after':b['hand_position_plan'],'json_patch':patch(a,b)};(root/f'exact_diff_{av}_to_{bv}.json').write_text(dumps(d));(root/f'exact_diff_{av}_to_{bv}.patch').write_text(''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile=f'score_{av}.json',tofile=f'score_{bv}.json')))
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--outdir',default=str(ROOT));root=Path(ap.parse_args().outdir);root.mkdir(parents=True,exist_ok=True);scores=[build(v) for v in ['v0','v1','v2']]
 for s in scores:(root/f'score_{s["version"]}.json').write_text(dumps(s))
 (root/'score.json').write_text(dumps(scores[-1]));emit_diff(root,scores[0],scores[1]);emit_diff(root,scores[1],scores[2])
if __name__=='__main__':main()
