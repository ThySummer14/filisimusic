from pathlib import Path
import json,copy
P=Path(__file__).parent
H={'Eb':[39,46,55],'Bb':[46,53,62],'Cm':[48,55,63],'Ab':[44,51,60],'Fm':[41,48,56],'G':[43,50,59],'G7':[43,53,59],'Db':[49,56,65],'Bbd':[46,53,56],'EbG':[43,51,58],'AbC':[48,56,63]}
# Literal newly written melodic sentences. All pitches are MIDI concert pitch.
A=[[63,67,70,68,67,65],[67,70,75,74,72,70],[68,72,75,77,75,72],[70,68,67,65,63,None],[65,68,72,70,68,67],[65,67,68,70,72,70],[67,70,74,75,74,70],[72,70,68,67,65,None],[67,70,75,77,79,77],[75,74,72,70,68,67],[65,68,70,74,72,70],[67,65,63,None,None,None]]
B=[[72,75,79,77,75,74],[72,71,74,77,75,71],[72,75,80,79,77,75],[74,72,71,68,67,None],[68,72,77,79,80,77],[75,73,72,68,65,68],[71,74,77,79,77,74],[75,74,72,71,67,None],[79,80,79,77,75,74],[77,75,73,72,68,65],[74,77,80,79,77,74],[75,72,71,67,None,None]]
C=[[63,65,67,65,63,62],[60,63,67,65,63,60],[61,65,68,67,65,63],[62,65,68,67,65,None],[63,67,68,70,68,67],[65,68,72,70,68,65],[67,70,74,72,70,67],[68,67,65,63,None,None],[63,67,70,75,74,72],[70,68,67,65,63,65],[67,68,70,74,72,70],[67,65,63,None,None,None]]
RETURN=[[63,67,70,68,67,65],[67,70,75,77,75,74],[72,75,79,77,75,72],[70,68,67,65,63,None],[65,68,72,75,74,72],[70,72,75,77,79,77],[75,74,72,70,68,67],[68,70,72,70,68,None],[67,70,75,79,82,79],[77,75,74,72,70,68],[67,68,70,74,72,70],[67,65,63,None,None,None]]
CODA=[[75,72,70,68,67,65],[67,70,75,74,72,70],[68,72,75,72,68,65],[67,65,63,None,None,None],[65,68,70,72,70,68],[67,70,74,72,70,65],[67,65,63,None,None,None],[63,None,None,None,None,None]]
AH=['Eb','Cm','Ab','EbG','Fm','Ab','Bb','Bbd','Eb','Ab','Bb','Eb']
BH=['Cm','G7','Ab','G','Fm','Db','G7','Cm','Ab','Fm','G7','Cm']
CH=['Eb','Cm','Db','Bbd','EbG','Fm','Bb','Ab','Eb','Fm','Bb','Eb']
RH=['Eb','Cm','Ab','EbG','Fm','Ab','Bb','Fm','Eb','Ab','Bb','Eb']
KH=['Cm','EbG','Ab','Eb','Fm','Bb','Eb','Eb']
intro=[[67,None,70,None,75,None],[72,None,70,None,67,None],[68,None,65,None,62,None],[63,None,None,None,None,None]]
broken=[[75,None,72,None,67,None],[71,None,68,None,65,None],[67,None,63,None,None,None],[62,None,65,None,None,None]]
for version in range(3):
 parts=[('Cup at the furnace',intro,['Eb','Cm','Bbd','Eb'],58,'intro'),('Carrying one sunrise',A,AH,64,'song'),('Praise thins the light',B if version else A,BH if version else AH,72,'pressure'),('A grain at the bottom',broken if version else intro,['Cm','G7','Eb','Bbd'],48,'break'),('Is it still warm',C if version==2 else A,CH if version==2 else AH,58,'conversation'),('Tomorrow through a mirror',RETURN if version==2 else A,RH if version==2 else AH,68,'return'),('A cup that may be praised',CODA if version==2 else A[:8],KH if version==2 else AH[:8],56,'coda')]
 d={'id':74,'title':'The Glassblower and the Quiet Sun','title_zh':'吹玻璃的人与安静的太阳','stage':f'v{version}','bars':[],'events':[],'pedals':[],'total_beats':192,'tail_seconds':5};on=0;bar=0
 for section,melodies,harmonies,bpm,role in parts:
  for k,(mel,hname) in enumerate(zip(melodies,harmonies)):
   bar+=1;tempo=bpm-(4 if role=='coda' and k>=6 else 0);h=H[hname];d['bars'].append({'bar':bar,'start':on,'beats':3,'bpm':tempo,'meter_numerator':6,'meter_denominator':8,'section':section,'harmony_name':hname,'harmony':h,'role_plan':role})
   arc=[-4,0,3,-5][k%4];v=(76 if role=='pressure' else 72 if role=='return' else 64)+arc
   if role in ['intro','break']:v=55+arc
   if role=='coda':v=60-k*2
   def add(off,dur,pitch,vel,voice):d['events'].append({'onset':on+off,'duration':dur,'pitch':pitch,'velocity':int(vel),'voice':voice,'instrument':'piano','bar':bar})
   # Repeated half-beat slots join into one intentional held tone; silence remains silence.
   for j,note in enumerate(mel):
    if note is None:continue
    following=next((m for m in range(j+1,6) if mel[m] is not None),6)
    dur=(following-j)*.5-.07
    if role not in ['intro','break'] and j<5 and following==j+1:dur=.46
    add(j*.5,dur,note,v+([0,-3,-1,-4,1,-3][j]),'melody')
   if role=='coda' and k==7:
    # Last melody/root is a single quiet, shared arrival; no competing bass phrase.
    for n in [h[0],h[0]+12]:add(0,2.75,n,42,'bass')
    for n in [55,58]:add(0,2.75,n,43,'accompaniment')
    for n in [67,70]:add(0,2.75,n,46,'upper_support')
   else:
    rootdur=.72 if role not in ['break','intro'] else 1.35
    add(0,rootdur,h[0],max(32,v-21),'bass')
    if role not in ['break']:
     # Root releases before compact upper pair, keeping a practical left-hand span.
     pair=[h[1],h[2]]
     for n in pair:add(1,.68,n,max(30,v-24),'accompaniment')
     if k%4!=3 and role not in ['intro']:
      for n in pair:add(2,.63,n,max(30,v-27),'accompaniment')
   ped=0 if role=='break' else 28 if role=='conversation' else 42
   d['pedals'] += [{'onset':on,'value':0},{'onset':on+.08,'value':ped},{'onset':on+2.88,'value':0}];on+=3
 d['events'].sort(key=lambda e:(e['onset'],e['pitch']));assert on==192 and bar==64
 (P/f'revisions/score_v{version}.json').write_text(json.dumps(d,ensure_ascii=False,indent=2))
 if version==2:(P/'score.json').write_text(json.dumps(d,ensure_ascii=False,indent=2))
(P/'revisions/pass1.json').write_text(json.dumps({'kind':'substantive_composition_revision','changes':['Recompose12-bar praise section as C-minor upward pressure with G7/Db detour, instead of A theme recirculation.','Replace four-bar extinguishing passage with widely spaced descending single tones and an unsettled Bb diminished-color hinge.']},indent=2))
(P/'revisions/pass2.json').write_text(json.dumps({'kind':'substantive_composition_revision','changes':['Compose12-bar conversation with lower tessitura and new chromatic/diatonic response.','Rewrite12-bar return, preserving initial identity but delaying highest Bb5 until the mirror succeeds.','Compose independent8-bar coda, reduce shared support, and close both hands together on Eb major.']},indent=2))
print('64bars,',len(d['events']),'events;duration',sum(b['beats']*60/b['bpm'] for b in d['bars'])+5)
