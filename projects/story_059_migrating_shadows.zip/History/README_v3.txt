给迁徙的影子架桥 / A Bridge for Migrating Shadows — v3
原创虚构故事与原创三重奏，约3分13秒。钢琴代表河东五块木板，单簧管回答河西七步；桥接合时合为12/8，归途中顺序倒转，尾声共同落在C小调。

完整包包含三条实际float32音轨，可在REAPER打开059_migrating_shadows_v3.rpp播放和混音。另有可编辑MIDI与JSON乐谱。音轨工程自包含；改变音符后重新生成需要外部音源和官方sfizz1.2.3，未把巨大共享音源重复打包。共享房间为REAPER自带ReaVerbate，本Linux7.82原生回开导出经过验证；其他平台可能需要重新匹配插件，不保证跨平台PCM一致。

钢琴：Moonlight-SalamanderV6.2。Alexander Holm原录音，Chisato Yamauchi/Accurate-Salamander重制，Hiroharu Narikawa等调律。CC BY3.0 https://creativecommons.org/licenses/by/3.0/ 。官方来源 https://www.ir.isas.jaxa.jp/~cyamauch/AccurateSalamander/ 。原README和版本hash随包。
单簧管：University of Iowa MIS；Christine Bellomy演奏，Lawrence Fritts，John Ritz和Eric Durian录音技术。来源 https://theremin.music.uiowa.edu/MISBbclarinet.html 。本曲使用mf真实录音层，短句分离发音，没有真实连奏过渡或循环延音。
大提琴：University of Iowa MIS；Jean Montes演奏，Lawrence Fritts，Michael Cash和Andrew Stuck-Marcell录音技术。来源 https://theremin.music.uiowa.edu/MIScello.html 。本曲仅C2–B2、拨弦、一个mf录音层，力度控制只是音量变化。录音音高偏差按稳定段测量校准，原PCM保留；自然衰减中的音高漂移仍存在。
Iowa官方使用许可 https://theremin.music.uiowa.edu/MIS.html 允许下载并用于任何项目，无限制。这里没有将其另称为CC0。两个管弦音源实际都是16bit44.1kHzmono，切片/转换及音高标定见各Mapping目录；float32演奏轨不等于高精度原始录音。

生成：Tools/render_score_sfizz.py读取Score/piano_score.json（加--enable-details）、clarinet_score.json、cello_score.json。各自选择外部Moonlight推荐SFZ、Iowa_clarinet_C4_B4_trio_articulated.sfz、Iowa_cello_pizz_C2_B2_trio.sfz。Mapping内SFZ需放在对应外部Samples目录旁。输出Media/*_float32.wav。原始MIDI包含混合拍号与速度，母带工程是固定时序音轨。

修订：第一轮改写西岸和声接点与共同终止；第二轮调整句弧、呼吸、回答时点和钢琴手部关系；第三轮纠正生成器声像律/宽度字段、用原生API设置回读并重新平衡。历史v2保留。三个乐器真实REAPER总线分轨的能量分析用于排查主伴层次，不代表人工听感评价。未宣称真人演奏或人工听审。
