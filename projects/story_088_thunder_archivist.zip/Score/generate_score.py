#!/usr/bin/env python3
"""Work 088. Deterministic, standard-library-only symbolic composition.
No audio/source access, rendering, network, DSP, installation, or listening.
All melodic bars and cello answers are authored explicitly. Absolute beats.
"""
from pathlib import Path
from collections import defaultdict, Counter
from bisect import bisect_right
import copy, json, hashlib, difflib, statistics
ROOT=Path(__file__).resolve().parent
PC={'C':0,'C#':1,'Db':1,'D':2,'D#':3,'Eb':3,'E':4,'F':5,'F#':6,'Gb':6,'G':7,'G#':8,'Ab':8,'A':9,'Bb':10,'B':11}
def p(s): return PC[s[:-1]]+12*(int(s[-1])+1)
def write(n,d): (ROOT/n).write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def sha(n): return hashlib.sha256((ROOT/n).read_bytes()).hexdigest()
# Harmony, left-hand voicing. The voicing stays below the singing right hand.
H={
 'Gm':([43,46,50],[43,46,50]), 'Gm/Bb':([46,50,55],[46,50,55]),
 'Gm(add9)':([43,46,50,57],[43,46,50]), 'Gm7':([43,46,50,53],[43,46,53]),
 'Cm':([36,39,43],[39,43,48]), 'Cm/Eb':([39,43,48],[39,43,48]),
 'Cm7':([36,39,43,46],[39,43,46]), 'Eb':([39,43,46],[39,43,46]),
 'Ebmaj7':([39,43,46,50],[39,46,50]), 'Bb':([34,38,41],[38,41,46]),
 'Bb/D':([38,41,46],[38,41,46]), 'Bbmaj7':([34,38,41,45],[38,41,45]),
 'F':([41,45,48],[41,45,48]), 'F/A':([45,48,53],[45,48,53]),
 'F7':([41,45,48,51],[41,45,51]), 'Dm':([38,41,45],[38,41,45]),
 'Dm/A':([45,50,53],[45,50,53]), 'Dm7':([38,41,45,48],[38,41,48]),
 'Aø7':([45,48,51,55],[43,48,51]), 'D7':([38,42,45,48],[38,42,48]),
 'D7/F#':([42,45,48,50],[42,45,50]), 'Dsus4':([38,43,45],[38,43,45]),
 'D':([38,42,45],[38,42,45]),
}
# One melody per bar, written quarter-note values; '_' is an intentional rest.
V0=[
 ('Gm', 'G4:.5 Bb4:.5 A4:1 D5:1 C5:.5 Bb4:.5'),
 ('Eb', 'G4:1 Bb4:.5 C5:.5 D5:1 Bb4:1'),
 ('Cm', 'C5:.5 Eb5:.5 D5:1 C5:1 G4:.5 A4:.5'),
 ('D7', 'A4:1 F#4:.5 A4:.5 D5:1 _:.5 A4:.5'),
 ('Gm/Bb', 'Bb4:.5 D5:.5 C5:1 Bb4:.5 A4:.5 G4:1'),
 ('F', 'A4:1 C5:.5 D5:.5 F5:1 E5:.5 D5:.5'),
 ('Ebmaj7', 'D5:.5 Eb5:.5 G5:1 F5:.5 Eb5:.5 D5:1'),
 ('D7', 'C5:1 A4:.5 F#4:.5 A4:1 _:.5 D5:.5'),
 ('Gm', 'D5:.5 Bb4:.5 A4:1 G4:1 Bb4:.5 D5:.5'),
 ('Bb/D', 'F5:1 D5:.5 C5:.5 Bb4:1 A4:1'),
 ('Cm7', 'G4:.5 Bb4:.5 C5:.5 D5:.5 Eb5:1 D5:1'),
 ('D7/F#', 'C5:.5 A4:.5 F#4:1 A4:1 _:.5 C5:.5'),
 ('Gm7', 'Bb4:.5 D5:.5 F5:1 D5:.5 C5:.5 Bb4:1'),
 ('Eb', 'G5:1 F5:.5 Eb5:.5 D5:1 Bb4:1'),
 ('D7', 'A4:.5 C5:.5 D5:1 C5:.5 A4:.5 F#4:.5 A4:.5'),
 ('Gm', 'G4:2 Bb4:.5 A4:.5 G4:.5 _:.5'),
 ('Gm', 'G4:.5 Bb4:.5 A4:1 D5:.5 Eb5:.5 D5:1'),
 ('Cm/Eb', 'Eb5:1 D5:.5 C5:.5 G4:1 Bb4:1'),
 ('F7', 'A4:.5 C5:.5 Eb5:.5 D5:.5 C5:1 F5:1'),
 ('Bb', 'F5:1 D5:1 Bb4:1 _:.5 C5:.5'),
 ('Ebmaj7', 'D5:.5 Eb5:.5 G5:1 F5:1 D5:1'),
 ('Aø7', 'C5:1 Eb5:.5 D5:.5 C5:.5 Bb4:.5 A4:1'),
 ('D7', 'A4:.5 C5:.5 D5:1 F#5:.5 E5:.5 D5:1'),
 ('D7', 'C5:1 A4:1 F#4:1 _:.5 A4:.5'),
 ('Gm', 'G4:1 Bb4:1 D5:1 C5:1'),
 ('Eb', 'Bb4:1 Eb5:1 D5:1 Bb4:1'),
 ('Cm', 'C5:1 Eb5:1 G5:1 Eb5:1'),
 ('D7', 'D5:1 C5:1 A4:1 F#4:.5 _:.5'),
 ('Gm/Bb', 'Bb4:1 D5:1 G5:1 F5:1'),
 ('F', 'E5:1 F5:1 C5:1 A4:1'),
 ('Aø7', 'C5:1 Eb5:1 D5:1 C5:1'),
 ('D7', 'A4:1 F#4:1 A4:1 _:.5 D5:.5'),
 ('Gm7', 'D5:1 F5:1 Bb5:1 A5:1'),
 ('Eb', 'G5:1 Eb5:1 D5:1 Bb4:1'),
 ('Cm7', 'C5:1 Eb5:1 G5:1 F5:1'),
 ('F7', 'Eb5:1 C5:1 A4:1 _:.5 C5:.5'),
 ('Bb', 'D5:1 F5:1 Eb5:.5 D5:.5 C5:1'),
 ('Dm', 'A4:1 _:.5 F4:.5 A4:1 _ :1'.replace('_ :','_:')),
 ('Ebmaj7', 'G4:1 Bb4:.5 D5:.5 Eb5:1 D5:1'),
 ('Bb/D', 'D5:1 C5:.5 Bb4:.5 _ :2'.replace('_ :','_:')),
 ('Cm7', 'Eb5:1 D5:.5 C5:.5 Bb4:1 G4:1'),
 ('F', 'A4:1 C5:1 _ :2'.replace('_ :','_:')),
 ('Bbmaj7', 'D5:.5 F5:.5 A5:1 G5:.5 F5:.5 D5:1'),
 ('Bb', 'C5:1 Bb4:1 _ :2'.replace('_ :','_:')),
 ('Eb', 'G4:1 Bb4:1 Eb5:1 D5:1'),
 ('Cm7', 'C5:1 G4:1 _ :2'.replace('_ :','_:')),
 ('Dsus4', 'A4:1 C5:.5 D5:.5 G5:1 F5:1'),
 ('D7', 'F#5:1 D5:1 C5:1 _:.5 A4:.5'),
 ('Gm', 'G4:.5 Bb4:.5 A4:.5 Bb4:.5 D5:1 C5:1'),
 ('Cm', 'Eb5:1 D5:.5 C5:.5 Bb4:.5 G4:.5 C5:1'),
 ('Aø7', 'C5:.5 Eb5:.5 G5:1 F5:.5 Eb5:.5 D5:1'),
 ('D7', 'C5:1 A4:.5 C5:.5 D5:1 _:.5 F#5:.5'),
 ('Gm/Bb', 'G5:1 F5:.5 D5:.5 Bb4:1 D5:1'),
 ('Ebmaj7', 'Eb5:.5 G5:.5 Bb5:1 A5:.5 G5:.5 F5:1'),
 ('Dsus4', 'G5:.5 F5:.5 D5:1 C5:.5 A4:.5 D5:1'),
 ('D7', 'F#5:1 E5:.5 D5:.5 C5:1 A4:.5 _:.5'),
 ('Gm', 'G4:.5 Bb4:.5 A4:1 D5:1 C5:.5 Bb4:.5'),
 ('Eb', 'G4:1 Bb4:.5 C5:.5 D5:1 Bb4:1'),
 ('Cm', 'C5:.5 Eb5:.5 D5:1 C5:1 G4:.5 A4:.5'),
 ('D7', 'A4:1 F#4:.5 A4:.5 D5:1 _:.5 A4:.5'),
 ('Gm/Bb', 'Bb4:.5 D5:.5 C5:1 Bb4:.5 A4:.5 G4:1'),
 ('F', 'A4:1 C5:.5 D5:.5 F5:1 E5:.5 D5:.5'),
 ('Ebmaj7', 'D5:.5 Eb5:.5 G5:1 F5:.5 Eb5:.5 D5:1'),
 ('D7', 'C5:1 A4:.5 F#4:.5 A4:1 _:.5 D5:.5'),
 ('Gm7', 'Bb4:1 D5:.5 F5:.5 G5:1 F5:1'),
 ('Cm/Eb', 'Eb5:1 G5:1 F5:.5 Eb5:.5 D5:1'),
 ('D7', 'C5:.5 A4:.5 D5:1 F#5:1 E5:.5 D5:.5'),
 ('Gm', 'D5:1 Bb4:1 G4:1 _:.5 Bb4:.5'),
 ('Eb', 'G4:1 Bb4:1 Eb5:1 D5:1'),
 ('Cm', 'C5:1 Bb4:.5 G4:.5 C5:1 Eb5:1'),
 ('D7', 'D5:1 C5:.5 A4:.5 F#4:1 A4:1'),
 ('Gm', 'G4:4'),
]
# Revision 1 makes the mistaken early cue audible as displacement and interruption,
# with a three-bar rebuilding sequence, rather than simply louder quarters.
V1={
25:('Gm','_:1 G4:.5 Bb4:.5 A4:.5 D5:.5 C5:1'),
26:('Cm/Eb','Eb5:.5 D5:.5 C5:1 G4:.5 Bb4:.5 C5:1'),
27:('Aø7','Eb5:.5 G5:.5 F5:.5 Eb5:.5 C5:1 A4:.5 C5:.5'),
28:('D7','D5:.5 C5:.5 A4:.5 F#4:.5 A4:1 _:.5 C5:.5'),
29:('Gm/Bb','Bb4:.5 D5:.5 C5:.5 Bb4:.5 G4:1 D5:.5 F5:.5'),
30:('Ebmaj7','G5:.75 F5:.25 Eb5:.5 D5:.5 Bb4:1 D5:1'),
31:('Cm7','Eb5:.5 D5:.5 C5:.5 Bb4:.5 G4:1 Bb4:.5 C5:.5'),
32:('D7','D5:1 A4:.5 C5:.5 F#5:.5 E5:.5 D5:.5 _:.5'),
33:('Gm','D5:.5 G5:.5 Bb5:1 A5:.5 G5:.5 F5:1'),
34:('Cm/Eb','Eb5:.5 G5:.5 F5:.5 Eb5:.5 D5:1 C5:1'),
35:('F7','C5:.5 Eb5:.5 F5:1 A5:.5 G5:.5 F5:1'),
36:('F7','Eb5:.5 C5:.5 A4:1 C5:1 _ :1'.replace('_ :','_:')),
}
# Revision 2 preserves the opening cell, then changes its landing and the final
# harmonic sentence. The last bow is allowed a separate, uncrowded answer.
V2={
57:('Gm','G4:.5 Bb4:.5 A4:1 D5:.5 F5:.5 G5:1'),
58:('Ebmaj7','G5:1 F5:.5 Eb5:.5 D5:.5 Bb4:.5 D5:1'),
59:('Cm7','Eb5:.5 D5:.5 C5:1 Bb4:.5 G4:.5 C5:1'),
60:('D7','D5:.75 C5:.25 A4:.5 F#4:.5 A4:1 _:.5 D5:.5'),
61:('Gm/Bb','Bb4:.5 D5:.5 G5:1 F5:.5 D5:.5 Bb4:1'),
62:('Bb/D','D5:.5 F5:.5 Bb5:1 A5:.5 F5:.5 D5:1'),
63:('Ebmaj7','Eb5:.5 G5:.5 F5:.5 Eb5:.5 D5:1 Bb4:1'),
64:('D7','A4:.5 C5:.5 D5:1 F#5:1 _:.5 D5:.5'),
65:('Gm7','G5:1 F5:.5 D5:.5 Bb4:.5 D5:.5 F5:1'),
66:('Cm/Eb','G5:.5 F5:.5 Eb5:1 D5:.5 C5:.5 Bb4:1'),
67:('Dsus4','A4:.5 C5:.5 D5:1 G5:.5 F5:.5 D5:1'),
68:('D7','F#5:1 E5:.5 D5:.5 C5:1 A4:.5 _:.5'),
69:('Gm/Bb','Bb4:.5 D5:.5 C5:1 Bb4:1 G4:1'),
70:('Cm7','G4:1 Bb4:.5 C5:.5 Eb5:1 D5:.5 C5:.5'),
71:('D7','A4:1 C5:.5 D5:.5 F#4:1 _:.5 A4:.5'),
72:('Gm','Bb4:.5 A4:.5 G4:3'),
}
# Short answering sentences: (beat-in-bar, note, nominal gate seconds).
# pp/mf are the actual recorded layers, not inferred velocity layers.
CELLO={
3:[(2.5,'G3',.58),(3.5,'Eb3',.52)],4:[(1,'F#3',.66),(2.25,'A3',.61)],
7:[(2.5,'G3',.60)],8:[(0,'F#3',.65),(1.5,'D3',.72)],
11:[(2,'Eb3',.58),(3,'G3',.55)],12:[(1,'A3',.62),(2.25,'F#3',.59)],
15:[(2.5,'A3',.52)],16:[(0,'G3',.70),(1.5,'D3',.67)],
19:[(2,'A3',.57),(3.25,'F3',.53)],20:[(1,'D3',.68),(2.5,'F3',.59)],
23:[(2.5,'F#3',.58)],24:[(0,'A3',.60),(1.5,'D3',.70)],
27:[(2,'G3',.52),(3.25,'Eb3',.54)],28:[(1,'F#3',.61),(2.5,'A3',.55)],
31:[(2.5,'Eb3',.52)],32:[(0,'D3',.60),(1.25,'F#3',.55),(2.5,'A3',.51)],
35:[(2,'G3',.54),(3.25,'Eb3',.51)],36:[(1,'F3',.59),(2.5,'A3',.63)],
38:[(1.25,'F3',.68),(2.75,'A3',.71)],40:[(1.25,'F3',.72),(2.75,'D3',.73)],
42:[(1.25,'F3',.68),(2.75,'A3',.68)],44:[(1.25,'Bb3',.72),(2.75,'F3',.68)],
46:[(1.25,'G3',.73),(2.75,'Eb3',.69)],48:[(1.25,'F#3',.68),(2.75,'A3',.62)],
51:[(2.25,'Eb3',.55),(3.25,'G3',.53)],52:[(1,'F#3',.62),(2.5,'D3',.58)],
55:[(2.25,'G3',.57),(3.25,'A3',.53)],56:[(1,'F#3',.61),(2.5,'A3',.57)],
59:[(2.5,'G3',.56),(3.5,'Eb3',.51)],60:[(1,'F#3',.62),(2.25,'A3',.55)],
63:[(2.5,'G3',.58)],64:[(0,'F#3',.61),(1.5,'D3',.66)],
67:[(2,'A3',.54),(3.25,'F#3',.52)],68:[(1,'G3',.65),(2.5,'D3',.67)],
70:[(2.5,'Eb3',.62)],71:[(1,'F#3',.70),(2.5,'A3',.70)],72:[(2,'G3',.79)],
}
V1_CELLO={25:[(0,'G3',.57)],27:[(2.25,'Eb3',.53),(3.25,'G3',.52)],
31:[(2,'Eb3',.54),(3.25,'G3',.52)],32:[(.5,'D3',.54),(1.75,'F#3',.53),(3,'A3',.51)],33:[(2.5,'Bb3',.54)],
34:[(1,'G3',.55),(2.5,'Eb3',.57)],35:[(2.25,'A3',.54),(3.25,'F3',.53)]}
V2_CELLO={62:[(2.5,'F3',.56)],63:[(1,'G3',.58),(2.5,'Bb3',.56)],
64:[(1,'A3',.59),(2.5,'F#3',.60)],67:[(2.25,'G3',.56),(3.25,'A3',.53)],
68:[(1,'F#3',.62),(2.5,'D3',.66)],69:[(2.5,'Bb3',.63)],
70:[(1,'G3',.65),(2.5,'Eb3',.66)],71:[(1.25,'F#3',.70),(2.75,'A3',.69)],72:[(2,'G3',.79)]}
SECTIONS=[(1,16,'A','贴着红条的纸盒'),(17,24,'A2','第一遍走台'),(25,36,'B','提前的一拍'),(37,48,'C','关掉头顶的返送'),(49,56,'D','让演员走完四步'),(57,68,'A3','最后一次合成'),(69,72,'E','盒盖上的新铅笔字')]
NAMES=['S-17 红条','隔着玻璃的手势','右门的脚步','第一次落点','换页时的预备','等待口令','提前的一拍','重排那一小段','错标的长尾','监听小喇叭','轻声数拍','从椅背到门框','四步的长度','留给合门的一格','同一张标签','新的下句','台口的最后一遍','铅笔补注']
TEMPOS=[84,86,87,86,88,89,92,93,91,77,78,80,87,90,91,90,88,80]
DYNAMICS=[67,71,73,71,75,77,81,83,84,51,53,56,71,79,85,86,80,63]

def section(n): return next((s,t) for lo,hi,s,t in SECTIONS if lo<=n<=hi)
def timing(bars):
 starts=[];times=[];run=0
 for b in bars:
  starts.append(b['start']); times.append(run);run+=b['beats']*60/b['bpm']
 def at(beat):
  i=min(len(bars)-1,max(0,bisect_right(starts,beat)-1));return times[i]+(beat-starts[i])*60/bars[i]['bpm']
 def beat(sec):
  i=min(len(bars)-1,max(0,bisect_right(times,sec)-1));return starts[i]+(sec-times[i])*bars[i]['bpm']/60
 return at,beat,run

def fingers(events,at,beat):
 # Five-key natural/harmonic/melodic minor positions. Choosing a different set
 # is a declared repositioning, even when the outside keys happen to coincide.
 scales=[{0,2,3,5,7,9,10},{0,2,3,6,7,9,10},{0,2,4,6,7,9,10}]
 positions=sorted({tuple(k[i:i+5]) for pcs in scales for k in [[x for x in range(48,94) if x%12 in pcs]] for i in range(len(k)-4)})
 rh=sorted([e for e in events if e['hand']=='right'],key=lambda e:e['onset']);i=0;old=None
 while i<len(rh):
  options=[]
  for pos in positions:
   if rh[i]['pitch'] not in pos: continue
   count=0
   for e in rh[i:]:
    if e['pitch'] not in pos:break
    count+=1
   movement=0 if old is None else max(abs(pos[0]-old[0]),abs(pos[-1]-old[-1]))
   options.append((count,-movement,-abs(rh[i]['pitch']-pos[2]),pos))
  count,_,_,pos=max(options)
  for e in rh[i:i+count]:
   e.update(hand_position_id='R'+'_'.join(map(str,pos)),hand_position_keys=list(pos),hand_position_range=[pos[0],pos[-1]],finger=pos.index(e['pitch'])+1,fingering_intent='Five ordered keys, fingers 1–5 from low to high; no undeclared thumb-under or hand transfer.')
  old=pos;i+=count
 for e in events:
  if e['hand']!='left':continue
  keys=H[e['harmony_name']][1]
  e.update(hand_position_id='L'+'_'.join(map(str,keys)),hand_position_keys=keys,hand_position_range=[keys[0],keys[-1]],finger={keys[0]:5,keys[1]:3,keys[2]:1}[e['pitch']],fingering_intent='Named three-key grip: fingers 5, 3, 1 low to high. Every actual grip-edge movement over four semitones gets a released transfer.')
 # Strict actual-grip checks on every LH attack; explicit fixed-finger exemption
 # only for RH motion inside an unchanged five-key position.
 for hand in ('left','right'):
  ns=sorted([e for e in events if e['hand']==hand],key=lambda e:e['onset']);groups=defaultdict(list)
  for e in ns:groups[e['onset']].append(e)
  attacks=sorted(groups.items())
  for (aon,aa),(on,bb) in zip(attacks,attacks[1:]):
   og=[min(e['pitch'] for e in aa),max(e['pitch'] for e in aa)];ng=[min(e['pitch'] for e in bb),max(e['pitch'] for e in bb)]
   gp=max(abs(x-y) for x,y in zip(og,ng));op=aa[0]['hand_position_range'];np=bb[0]['hand_position_range'];pm=max(abs(x-y) for x,y in zip(op,np));changed=aa[0]['hand_position_id']!=bb[0]['hand_position_id']
   transfer=changed or (hand=='left' and gp>4)
   if not transfer:continue
   travel=max(gp,pm);need=.075+.012*max(0,travel-4);limit=beat(at(on)-need-.008)
   for prev in ns:
    if prev['onset']<on and prev['onset']+prev['duration']>limit:
     new=limit-prev['onset'];assert at(prev['onset']+new)-at(prev['onset'])>.10,(hand,prev['bar'],new)
     prev['duration']=round(new,6);prev['release_reason']='Full held grip released before measured edge transfer.'
   for e in bb:e['hand_shift_before']={'actual_grip_edge_travel_semitones':gp,'position_edge_travel_semitones':pm,'required_release_seconds':round(need,6),'safety_margin_seconds':.008}

def make(v):
 sheet=copy.deepcopy(V0);cello=copy.deepcopy(CELLO)
 if v>=1:
  for n,data in V1.items():sheet[n-1]=data
  cello.update(V1_CELLO)
 if v>=2:
  for n,data in V2.items():sheet[n-1]=data
  cello.update(V2_CELLO)
 bars=[];events=[];pedals=[]
 for n,(hn,line) in enumerate(sheet,1):
  q=(n-1)//4;pos=(n-1)%4;bpm=TEMPOS[q]+[0,1,0,-1][pos]
  if n>=69:bpm=[81,78,74,66][n-69]
  sec,title=section(n);harm,grip=H[hn];start=float(4*(n-1));quiet=37<=n<=48
  lead='cello' if n in (38,40,42,44,46) else 'piano'
  bars.append({'bar':n,'start':start,'beats':4.,'bpm':bpm,'meter':'4/4','meter_numerator':4,'meter_denominator':4,'section':sec,'section_title_zh':title,'harmony_name':hn,'harmony':harm,'lead_instrument':lead,'key_region':'Bb major' if 37<=n<=46 else 'G minor','phrase_id':f'P{q+1:02}','phrase_position':pos+1,'macro_phrase_id':f'P{q+1:02}','macro_phrase_length_bars':4,'role_plan':'大提琴以分弓小句接过句尾，钢琴低声部完整让开。' if lead=='cello' else '钢琴右手主唱；左手按同一和声推进；大提琴分弓应答处低声部留空。'})
  counts=Counter()
  def add(on,dur,pitch,vel,inst,voice,hand,role,**kw):
   counts[inst,voice]+=1
   e={'event_id':f'w88-b{n:02}-{inst}-{voice}-{counts[inst,voice]:02}','bar':n,'onset':round(start+on,6),'duration':round(dur,6),'pitch':pitch,'velocity':vel,'instrument':inst,'voice':voice,'hand':hand,'role':role,'phrase_id':f'P{q+1:02}_{inst}','phrase_label':NAMES[q],'harmony_name':hn,'onset_reference':'ordinary_trigger'};e.update(kw);events.append(e)
  loc=0.;tokens=[(t.split(':')[0],float(t.split(':')[1])) for t in line.split()]
  assert abs(sum(x[1] for x in tokens)-4)<1e-8,(n,line)
  for j,(note,value) in enumerate(tokens):
   if note!='_':
    gate=value-(.09 if pos==3 else .05)
    if n==72:gate=value-.12
    vel=DYNAMICS[q]+[0,2,-2,3,-1,1][j%6]
    add(loc,gate,p(note),vel,'piano','melody','right','lead' if lead=='piano' else 'upper_response',layer='natural',sample_layer='approved_natural_piano',written_value_beats=value,articulation='cantabile_finger_release',harmonic_function='chord_tone' if p(note)%12 in {x%12 for x in harm} else 'passing_or_neighbor_melodic_tension')
   loc+=value
  for j,(on,note,seconds) in enumerate(cello.get(n,[])):
   layer='pp' if quiet or n>=69 else 'mf'
   add(on,seconds*bpm/60,p(note),(49 if layer=='pp' else 70)+[0,3,-2][j%3],'cello','short_bowed_answer','not_applicable','lead_answer' if lead=='cello' else 'answer',layer=layer,sample_layer=layer,source_family='University of Iowa cello arco',source_pitch_midi=p(note),nominal_gate_seconds=seconds,articulation='arco_short_separate_bows',bow_direction='down' if j%2==0 else 'up',velocity_controls='within_recorded_layer_amplitude_intent',timing_intent='Separate arco trigger and release; no sustain loops or sampled legato, no continuous-bow transition claim.',harmonic_function='chord_tone' if p(note)%12 in {x%12 for x in harm} else 'passing_or_neighbor_melodic_tension')
  # Rhythmic, harmonically matched LH. Never leaps between distant registers.
  if lead=='cello':plans=[]
  elif quiet:plans=[(0,.9,[0,2]),(2,.7,[1])]
  elif n>=69:plans=[(0,.95,[0,2]),(2,.85,[1])]
  elif 25<=n<=36 and v>=1:plans=[(0,.44,[0]),(.75,.36,[1]),(1.5,.36,[2]),(2,.44,[0,1]),(2.75,.36,[2]),(3.5,.30,[1])]
  elif 57<=n<=68 and v>=2:plans=[(0,.62,[0,2]),(1,.37,[1]),(1.5,.32,[2]),(2,.58,[0]),(3,.32,[1]),(3.5,.28,[1])]
  elif pos in (0,2):plans=[(0,.62,[0]),(.75,.38,[1]),(1.5,.36,[2]),(2,.62,[0,1]),(3,.4,[2])]
  else:plans=[(0,.72,[0,2]),(1.5,.38,[1]),(2,.60,[0]),(3,.40,[1,2])]
  if n==72:plans=[(0,.65,[0,2]),(3.25,.63,[0,1,2])]
  if v>=1 and n==25:plans=[(1,.42,[0]),(1.75,.36,[1]),(2.5,.42,[2]),(3.25,.36,[1])]
  # Absolute seconds and global filtering below account for adjacent bars.
  for on,dur,indices in plans:
   for k in indices:add(on,dur,grip[k],max(28,DYNAMICS[q]-25)+(2 if k==0 else 0),'piano','accompaniment','left','support',layer='natural',sample_layer='approved_natural_piano',harmonic_function='chord_tone',articulation='light_detached_flow')
  for on,off in [(0.06,1.78),(2.06,3.78)]:
   if lead=='cello':continue
   pedals.extend([{'bar':n,'onset':start+on,'value':36 if quiet else 48,'instrument':'piano','controller':64,'phrase_id':f'P{q+1:02}_piano','kind':'partial_intent'},{'bar':n,'onset':start+off,'value':0,'instrument':'piano','controller':64,'phrase_id':f'P{q+1:02}_piano','kind':'release'}])
 at,beat,music=timing(bars)
 # Give each separate cello phrase space in the lower register. This is a
 # temporal scoring rule, not an EQ promise or measured sample-tail claim.
 cs=sorted([e for e in events if e['instrument']=='cello'],key=lambda e:e['onset'])
 for c in cs:c['duration']=round(beat(at(c['onset'])+c['nominal_gate_seconds'])-c['onset'],6)
 for a,b in zip(cs,cs[1:]):
  max_gate=at(b['onset'])-at(a['onset'])-.18
  if a['nominal_gate_seconds']>max_gate:
   assert max_gate>=.4,(a["bar"],a["onset"],b["bar"],b["onset"],max_gate)
   a['duration']=round(beat(at(a['onset'])+max_gate)-a['onset'],6)
   a['nominal_gate_seconds']=round(max_gate,9)
   a['release_reason']='Shorter individual bow gives the following answer a 180 ms bow-change gap.'
 def close(e,c): return at(e['onset'])<at(c['onset']+c['duration'])+.18 and at(e['onset']+e['duration'])>at(c['onset'])-.22
 events=[e for e in events if e['hand']!='left' or not any(close(e,c) for c in cs)]
 clean=[]
 for down,up in zip(pedals[::2],pedals[1::2]):
  d,u=down['onset'],up['onset']
  # Pedal must not carry bass into, through, or immediately after an answer.
  if any(at(d)>=at(c['onset'])-.24 and at(d)<at(c['onset']+c['duration'])+.18 for c in cs):continue
  future=[at(c['onset'])-.24 for c in cs if at(c['onset'])>at(d)]
  if future:u=min(u,beat(min(future)))
  if u-d>.08:
   up['onset']=round(u,6);clean.extend([down,up])
 pedals=sorted(clean,key=lambda e:e['onset'])
 fingers(events,at,beat)
 events.sort(key=lambda e:(e['onset'],e['instrument'],e['pitch'],e['event_id']))
 for b in bars:b['time_start_seconds']=round(at(b['start']),9)
 for e in events:
  e.update(target_on_beats=e['onset'],target_off_beats=round(e['onset']+e['duration'],6),target_on_seconds=round(at(e['onset']),9),target_off_seconds=round(at(e['onset']+e['duration']),9))
 for e in pedals:e['target_on_seconds']=round(at(e['onset']),9)
 phrases=[]
 for q in range(18):
  for inst in ('piano','cello'):
   ns=[e for e in events if e['phrase_id']==f'P{q+1:02}_{inst}']
   if not ns:continue
   lo=min(e['onset'] for e in ns);hi=max(e['onset']+e['duration'] for e in ns)
   phrases.append({'phrase_id':f'P{q+1:02}_{inst}','instrument':inst,'phrase_label':NAMES[q],'first_bar':4*q+1,'last_bar':4*q+4,'section':section(4*q+1)[0],'layer':'natural' if inst=='piano' else ('pp' if 9<=q<=11 or q==17 else 'mf'),'layers_used':sorted({e['layer'] for e in ns}),'roles_used':sorted({e['role'] for e in ns}),'voices_used':sorted({e['voice'] for e in ns}),'target_on_beats':lo,'target_off_beats':round(hi,6),'target_on_seconds':round(at(lo),9),'target_off_seconds':round(at(hi),9),'timing_intent':'Four-bar musical sentence; attacks, separate key releases and bowed gaps are explicit.'})
 return {'id':88,'title':'The Archivist of Thunder','title_zh':'雷声保管员','version':f'v{v}','instrumentation':['natural_acoustic_piano','University_of_Iowa_short_arco_cello_pp_mf'],'bars':bars,'events':events,'phrases':phrases,'pedals':pedals,'cadences':[{'bar':n,'kind':kind} for n,kind in [(8,'half'),(16,'authentic_G_minor'),(24,'half'),(36,'Bb_dominant'),(44,'Bb_authentic'),(48,'G_minor_dominant'),(56,'half'),(68,'expanded_dominant'),(72,'G_minor_final')]],'total_beats':288.,'tail_seconds':6.,'music_seconds':round(music,9),'total_seconds_with_tail':round(music+6,9),'performance_contract':{'audio_status':'Symbolic only; no audio, source access, rendering, downloads, installations or listening.','beat_unit':'Absolute quarter-note beats; 4/4 bar = 4 beats.','piano_hand_span_semitones':12,'piano_fingering':'RH explicitly named five-key position, fingers 1–5; LH named three-key grip, fingers 5/3/1. No same-key overlaps or hand crossings. Pedal is resonance, not held-key time.','piano_travel_rule':'Every named position change and every LH actual grip-edge move over 4 semitones releases all prior keys for 75 ms + 12 ms per extra semitone; conservative travel uses max(actual grip edges, position edges). RH movement in one unchanged five-key position uses explicitly assigned fingers.','cello_source':'University of Iowa arco; original recorded notes MIDI 50–59 only.','cello_recorded_layers':['pp','mf'],'cello_gate_seconds':[.4,.85],'cello_min_release_gap_seconds':.15,'cello_articulation':'Short separate bowed notes. No sustain loops, sampled legato, violin claim, or continuous bow transitions. Bow-direction tags are performance intent, not separate source articulations.','lower_register_clearance':'LH keys rest at least 220 ms before cello and 180 ms after. Piano pedal releases at least 240 ms before cello.','layer_controls':'Every cello event selects its actual pp or mf recording; velocity is within-layer amplitude intent.','lead_balance':'Piano owns the principal melody. Five quiet even bars hand the response to cello with LH absent.','verification_limit':'Nominal timing, pitch, fingering and source-contract audit only. Real recorded attack/release, tone, balance and playable sampled result require later source and audio verification.'}}

def audit(s):
 errors=[];bs=s['bars'];ev=s['events'];at,_,total=timing(bs)
 def ck(c,m):
  if not c:errors.append(m)
 ck(len(bs)==72 and s['total_beats']==288,'grid total');ck(195<=total+s['tail_seconds']<=220,'duration')
 ck(len({e['event_id'] for e in ev})==len(ev),'unique IDs')
 for i,b in enumerate(bs):ck((b['start'],b['beats'])==(i*4,4),'bar grid')
 for e in ev:
  ck(e['duration']>0 and 0<=e['onset']<e['onset']+e['duration']<=288,'event bounds')
  if e['hand']=='left':ck(e['pitch']%12 in {x%12 for x in bs[e['bar']-1]['harmony']},'LH same harmony')
 cello=sorted([e for e in ev if e['instrument']=='cello'],key=lambda e:e['onset']);gates=[at(e['onset']+e['duration'])-at(e['onset']) for e in cello];gaps=[at(b['onset'])-at(a['onset']+a['duration']) for a,b in zip(cello,cello[1:])]
 ck(all(50<=e['pitch']<=59 and e['layer']==e['sample_layer'] and e['layer'] in ('pp','mf') for e in cello),'cello source contract');ck(min(gates)>=.4 and max(gates)<=.85,'bow gates');ck(min(gaps)>=.15,'bow gaps')
 pn=[e for e in ev if e['instrument']=='piano'];maxspan={h:0 for h in ('left','right')};trans=[];collisions=[];crossings=[]
 for t in sorted({e['onset'] for e in pn}):
  active=[e for e in pn if e['onset']<=t<e['onset']+e['duration']-1e-8]
  if len({e['pitch'] for e in active})<len(active):collisions.append(t)
  hands={h:[e['pitch'] for e in active if e['hand']==h] for h in ('left','right')}
  for h,ps in hands.items():
   if ps:maxspan[h]=max(maxspan[h],max(ps)-min(ps))
  if hands['left'] and hands['right'] and max(hands['left'])>=min(hands['right']):crossings.append(t)
 ck(not collisions and not crossings,'collisions/crossings');ck(max(maxspan.values())<=12,'held span')
 for h in ('left','right'):
  ns=[e for e in pn if e['hand']==h];groups=defaultdict(list)
  for e in ns:groups[e['onset']].append(e)
  for (_,aa),(on,bb) in zip(sorted(groups.items()),sorted(groups.items())[1:]):
   gp=max(abs(min(x['pitch'] for x in aa)-min(x['pitch'] for x in bb)),abs(max(x['pitch'] for x in aa)-max(x['pitch'] for x in bb)))
   pm=max(abs(x-y) for x,y in zip(aa[0]['hand_position_range'],bb[0]['hand_position_range']));changed=aa[0]['hand_position_id']!=bb[0]['hand_position_id']
   if not(changed or (h=='left' and gp>4)):continue
   need=.075+.012*max(0,max(gp,pm)-4);last=max(e['onset']+e['duration'] for e in ns if e['onset']<on);avail=at(on)-at(last);ok=avail+1e-6>=need
   trans.append({'hand':h,'onset':on,'actual_grip_edge_travel_semitones':gp,'position_edge_travel_semitones':pm,'required_release_seconds':round(need,6),'available_release_seconds':round(avail,6),'passed':ok});ck(ok,'grip transfer')
 lead=[e for e in pn if e['voice']=='melody'];sections={}
 for lo,hi,name,_ in SECTIONS:
  ns=[e for e in lead if lo<=e['bar']<=hi];sections[name]={'melody_events':len(ns),'mean_melody_velocity':round(statistics.mean(e['velocity'] for e in ns),2),'average_written_value':round(statistics.mean(e['written_value_beats'] for e in ns),3)}
 return {'passed':not errors,'errors':errors,'event_count':len(ev),'music_seconds':round(total,6),'duration_with_tail_seconds':round(total+s['tail_seconds'],6),'cello_events':len(cello),'cello_range':[min(e['pitch'] for e in cello),max(e['pitch'] for e in cello)],'cello_layers':dict(Counter(e['layer'] for e in cello)),'cello_gate_seconds':[round(min(gates),6),round(max(gates),6)],'minimum_bow_release_gap_seconds':round(min(gaps),6),'maximum_held_span_semitones':maxspan,'same_key_overlap_count':len(collisions),'hand_crossing_count':len(crossings),'grip_transfer_count':len(trans),'grip_transfers':trans,'section_melody_profile':sections,'scope':'Generator-side symbolic checks. Independent verifier is separate.'}

def exact_diff(a,b):
 changes=[]
 for bar in range(1,73):
  ab,bb=a['bars'][bar-1],b['bars'][bar-1];ae=[e for e in a['events'] if e['bar']==bar];be=[e for e in b['events'] if e['bar']==bar];ap=[p for p in a['pedals'] if p['bar']==bar];bp=[p for p in b['pedals'] if p['bar']==bar]
  if (ab,ae,ap)!=(bb,be,bp):changes.append({'bar':bar,'before_bar':ab,'after_bar':bb,'before_events':ae,'after_events':be,'before_pedals':ap,'after_pedals':bp})
 return {'from':a['version'],'to':b['version'],'before_sha256':sha('score_'+a['version']+'.json'),'after_sha256':sha('score_'+b['version']+'.json'),'changed_bars':[x['bar'] for x in changes],'changes':changes,'phrase_metadata_before':a['phrases'],'phrase_metadata_after':b['phrases'],'cadences_before':a['cadences'],'cadences_after':b['cadences'],'top_level_version_before':a['version'],'top_level_version_after':b['version']}

def main():
 scores=[]
 for v in range(3):
  s=make(v);write(f'score_v{v}.json',s);a=audit(s);write(f'audit_v{v}.json',a);assert a['passed'],a['errors'];scores.append(s)
 (ROOT/'score.json').write_bytes((ROOT/'score_v2.json').read_bytes())
 for a,b in zip(scores,scores[1:]):
  name=f'exact_diff_{a["version"]}_to_{b["version"]}';write(name+'.json',exact_diff(a,b));before=(ROOT/f'score_{a["version"]}.json').read_text().splitlines(True);after=(ROOT/f'score_{b["version"]}.json').read_text().splitlines(True)
  (ROOT/(name+'.patch')).write_text(''.join(difflib.unified_diff(before,after,fromfile=f'score_{a["version"]}.json',tofile=f'score_{b["version"]}.json')),encoding='utf-8')
 print(json.dumps({'duration_seconds':scores[-1]['total_seconds_with_tail'],'versions':[{'version':s['version'],'events':len(s['events'])} for s in scores],'selected_sha256':sha('score.json')},indent=2))
if __name__=='__main__':main()
