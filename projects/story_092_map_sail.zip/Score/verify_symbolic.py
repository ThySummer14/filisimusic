#!/usr/bin/env python3
"""Independent disk audit, without importing the score generator.
Reads actual saved key gates, finger maps and revisions. Standard library only.
"""
import copy
import hashlib
import json
import math
import subprocess
import sys
import tempfile
from collections import defaultdict
from pathlib import Path

ROOT=Path(__file__).resolve().parent
def load(name):return json.loads((ROOT/name).read_text(encoding='utf-8'))
def save(name,x):(ROOT/name).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def sha(name):return hashlib.sha256((ROOT/name).read_bytes()).hexdigest()
def end(e):return round(e['onset']+e['duration'],6)

def inspect(s):
    errors=[];bars=s['bars'];notes=s['events'];piano=[e for e in notes if e['instrument']=='piano'];flute=[e for e in notes if e['instrument']=='flute']
    def check(ok,msg):
        if not ok:errors.append(msg)
    def sec(t):return sum(min(max(t-b['start'],0),b['beats'])*60/b['bpm'] for b in bars)
    check(s['id']==92 and s['total_beats']==480 and s['tail_seconds']==6,'identity and absolute endpoint')
    check(s['instrumentation']==['natural_acoustic_piano','University_of_Iowa_flute_pp_mf'],'instrumentation')
    check(len(bars)==80 and 200<=sec(480)+6<=225,'complete duration 3:20–3:45')
    check(abs(s['music_seconds']-sec(480))<1e-7 and abs(s['total_seconds_with_tail']-sec(480)-6)<1e-7,'duration metadata')
    for i,b in enumerate(bars):
        n=i+1
        check((b['bar'],b['start'],b['beats'],b['meter_numerator'],b['meter_denominator'])==(n,i*6,6,12,8),f'bar grid {n}')
        check(108<=b['bpm']<=156 and math.isfinite(b['bpm']),f'tempo {n}')
        check(b['phrase_id']==f'P{i//4+1:02d}',f'bar phrase {n}')
        check(abs(b['time_start_seconds']-sec(b['start']))<1e-7,f'bar time {n}')
        if 33<=n<=48:check(108<=b['bpm']<=116 and b['lead_instrument']=='flute','actual quieter region')
        elif n<=76:check(140<=b['bpm']<=156,'energetic quarter-note tempo')
    check(len({e['event_id'] for e in notes})==len(notes),'unique event IDs')
    check(notes==sorted(notes,key=lambda e:(e['onset'],e['instrument'],e['hand'],e['pitch'],e['voice'])),'saved event order')
    plans={(p['bar'],p['hand']):p for p in s['hand_position_plan']}
    check(len(plans)==len(s['hand_position_plan'])==160,'one real position per bar and hand')
    for e in notes:
        check(all(math.isfinite(e[k]) for k in ('onset','duration','pitch','velocity')),f'finite event {e["event_id"]}')
        check(isinstance(e['pitch'],int) and 21<=e['pitch']<=108 and 1<=e['velocity']<=127,'MIDI bounds')
        b=bars[e['bar']-1]
        check(b['start']<=e['onset']<end(e)<=b['start']+6,'event within actual bar')
        check(e['target_on_beats']==e['onset'] and abs(e['target_off_beats']-end(e))<1e-7,'absolute beat aliases')
        check(abs(e['target_on_seconds']-sec(e['onset']))<1e-7 and abs(e['target_off_seconds']-sec(end(e)))<1e-7,'seconds integrate quarter BPM')
        chord=e['pitch']%12 in {q%12 for q in b['harmony']}
        check(e['harmonic_function']==('chord_tone' if chord else 'melodic_nonchord_tone'),'honest harmonic labels')
        check(e['onset_reference']=='ordinary_trigger','no anticipatory attack compensation')
        check(e['phrase_id']==b['phrase_id']+'_'+e['instrument'],'explicit instrument phrase identity')
        if e['instrument']=='piano':
            check(e['hand'] in ('left','right') and e['layer']==e['sample_layer']=='not_applicable','piano hand and layer')
            p=plans[(e['bar'],e['hand'])]
            check(e['hand_position_id']==p['position_id'] and e['hand_position_range']==p['range'],'position identity')
            check(e['position_keys']==sorted(int(k) for k in p['pitch_finger_map']),'real declared position keys')
            check(p['pitch_finger_map'].get(str(e['pitch']))==e['finger'] and 1<=e['finger']<=5,'finger identity')
            check(e['written_value_beats']>=e['duration']>0,'piano key gate fits written value')
            if e['role']=='support':check(chord,'harmonic accompaniment has actual chord tones')
            if e['voice']=='melody':check(e['hand']=='right' and e['role']=='lead','piano lead ownership')
        elif e['instrument']=='flute':
            check(e['hand']=='not_applicable' and e['source_pitch_midi']==e['pitch'] and 72<=e['pitch']<=83,'recorded flute source pitch C5–B5')
            check(e['layer']==e['sample_layer'] and e['layer'] in ('pp','mf'),'true explicitly selected pp/mf layer')
            actual=sec(end(e))-sec(e['onset'])
            check(.6-1e-7<=actual<=1.5+1e-7,'flute physical gate 0.6–1.5 seconds')
            check(abs(actual-e['nominal_gate_seconds'])<1e-7,'flute nominal gate honest')
            check(e['articulation']=='separate_breath_shaped_note' and 'no held sample loop' in e['release_reason'],'separate flute source triggers and releases')
            check(e['role']==('lead' if 33<=e['bar']<=48 else 'answer'),'flute foreground plan')
        else:check(False,'unapproved instrument')
    for key,p in plans.items():
        ns=[e for e in piano if (e['bar'],e['hand'])==key];ps=sorted({e['pitch'] for e in ns});fs=[p['pitch_finger_map'][str(k)] for k in ps]
        check(p['active'] and p['range']==[min(ps),max(ps)] and max(ps)-min(ps)<=12,f'real octave-contained grip {key}')
        check(len(ps)<=5 and len(fs)==len(set(fs)),'distinct fixed pitch-to-finger assignments')
        check(fs==sorted(fs,reverse=p['hand']=='left'),'uncrossed ordered fingers')
        for (a,f),(b,g) in zip(zip(ps,fs),list(zip(ps,fs))[1:]):
            check(b-a<=4*abs(g-f),f'no implausible adjacent-finger stretch {key}')
    # Simultaneous physical keys, independent of pedal resonance.
    changes=defaultdict(list);attacks={h:defaultdict(list) for h in ('left','right')}
    for i,e in enumerate(notes):
        changes[e['onset']].append((1,i));changes[end(e)].append((0,i))
        if e['instrument']=='piano':attacks[e['hand']][e['onset']].append(e)
    held={};maxspan={h:0 for h in attacks};maxkeys={h:0 for h in attacks};physical={h:{} for h in attacks}
    collisions=[];crossings=[];finger_collisions=[];foreground_collisions=[];maxforeground=0;silent=[];lastoff=None;maxflute=0
    for t in sorted(changes):
        was=bool(held)
        for kind,i in sorted(changes[t]):
            if kind==0:held.pop(i,None)
            else:
                e=notes[i]
                for old in held.values():
                    if old['instrument']==e['instrument'] and old['pitch']==e['pitch']:collisions.append([old['event_id'],e['event_id']])
                    if old['instrument']==e['instrument']=='piano' and old['hand']==e['hand'] and old['finger']==e['finger']:finger_collisions.append([old['event_id'],e['event_id']])
                held[i]=e
        if was and not held:lastoff=t
        if held and lastoff is not None:
            if t>lastoff:silent.append(sec(t)-sec(lastoff))
            lastoff=None
        fore=[e for e in held.values() if e['role'] in ('lead','answer')]
        maxforeground=max(maxforeground,len(fore))
        if len(fore)>1:foreground_collisions.append(t)
        maxflute=max(maxflute,sum(e['instrument']=='flute' for e in held.values()))
        hands={h:[e for e in held.values() if e['instrument']=='piano' and e['hand']==h] for h in attacks}
        for h,ns in hands.items():
            if ns:
                ps=[e['pitch'] for e in ns];maxspan[h]=max(maxspan[h],max(ps)-min(ps));maxkeys[h]=max(maxkeys[h],len(ps))
                if t in attacks[h]:physical[h][t]=[min(ps),max(ps)]
        if all(hands.values()) and max(e['pitch'] for e in hands['left'])>=min(e['pitch'] for e in hands['right']):crossings.append(t)
    check(not collisions and not crossings and not finger_collisions,'no same-key overlaps, crossings or finger collisions')
    check(max(maxspan.values())<=12 and max(maxkeys.values())<=5,'physical held geometry')
    check(maxforeground==1 and not foreground_collisions and maxflute==1,'single foreground and monophonic flute')
    check(max(silent,default=0)<.5,'no padding by dead air')
    transfers=[];within=[]
    for hand,groupsdict in attacks.items():
        groups=sorted(groupsdict.items());latest=0
        for i,(t,group) in enumerate(groups):
            if i:
                old_t,prev=groups[i-1];old=physical[hand][old_t];new=physical[hand][t]
                oldp=plans[(prev[0]['bar'],hand)];newp=plans[(group[0]['bar'],hand)]
                edge=max(abs(a-b) for a,b in zip(old,new));pedge=max(abs(a-b) for a,b in zip(oldp['range'],newp['range']))
                changed=oldp['position_id']!=newp['position_id']
                if changed:
                    travel=max(edge,pedge);required=.075+.012*max(0,travel-4);available=sec(t)-sec(latest)
                    row={'hand':hand,'from_beat':old_t,'to_beat':t,'old_grip':old,'new_grip':new,'old_position':oldp['range'],'new_position':newp['range'],
                      'whole_position_changed':True,'grip_edge_semitones':edge,'position_edge_semitones':pedge,'checked_travel_semitones':travel,
                      'last_prior_key_release_beat':latest,'available_seconds':round(available,9),'required_seconds':round(required,9),
                      'margin_seconds':round(available-required,9),'passed':available+1e-7>=required}
                    transfers.append(row);check(row['passed'],f'whole-hand release transfer {hand} at {t}')
                elif edge>4:
                    # The same verified, uncrossed pitch-to-finger assignment
                    # is independent evidence that this is finger motion
                    # through a fixed close arpeggio or melody position.
                    check(oldp==newp,'within-position map must truly be identical')
                    within.append({'hand':hand,'from_beat':old_t,'to_beat':t,'position_id':newp['position_id'],'edge_semitones':edge,
                      'from_pitches':[e['pitch'] for e in prev],'to_pitches':[e['pitch'] for e in group],
                      'from_fingers':[e['finger'] for e in prev],'to_fingers':[e['finger'] for e in group],
                      'method':'Ordered separate fingers in the same independently checked close position; no whole-hand translation.'})
            latest=max(latest,*(end(e) for e in group))
    flute_gates=[sec(end(e))-sec(e['onset']) for e in flute];breathgaps=[]
    check(len(s['breaths'])==len(flute),'release/breath record for every flute note')
    for i,(e,b) in enumerate(zip(flute,s['breaths'])):
        nxt=flute[i+1] if i+1<len(flute) else None
        check(b['after_event_id']==e['event_id'] and b['before_event_id']==(nxt['event_id'] if nxt else None),'actual adjacent flute events')
        check(b['start']==end(e) and b['end']==(nxt['onset'] if nxt else 480),'complete explicit release interval')
        check(abs(b['start_seconds']-sec(b['start']))<1e-7 and abs(b['end_seconds']-sec(b['end']))<1e-7,'breath timing')
        gap=sec(b['end'])-sec(b['start']);breathgaps.append(gap);check(gap>=.15-1e-7,'at least 150ms explicit flute release/breath')
    check({e['layer'] for e in flute}=={'pp','mf'},'both real source layers requested')
    check(all(e['layer']=='pp' for e in flute if 33<=e['bar']<=48),'quiet source layer')
    lead=[e for e in piano if e['voice']=='melody'];leadbars={e['bar'] for e in lead}
    check(leadbars==set(range(1,81))-set(range(33,49)),'piano lead relinquishes complete contrasting region')
    check({e['bar'] for e in flute if e['role']=='lead'}==set(range(33,49)),'flute leads sixteen quiet bars')
    answerbars=sorted({e['bar'] for e in flute if e['role']=='answer'})
    for n in answerbars:
        p=[e for e in lead if e['bar']==n];f=[e for e in flute if e['bar']==n]
        check(max(end(e) for e in p)<min(e['onset'] for e in f),'true piano-to-flute handoff')
    for n in range(1,81):
        p=[e for e in piano if e['bar']==n];l=[e for e in p if e['role']=='lead'];sup=[e for e in p if e['hand']=='left']
        if l:check(max(e['velocity'] for e in sup)<=min(e['velocity'] for e in l)-18,'piano melody above accompaniment')
        if 33<=n<=48:check(max(e['velocity'] for e in p)<=44,'actual quiet piano support')
    phrases={p['phrase_id']:p for p in s['phrases']};check(len(phrases)==len(s['phrases']),'unique phrase metadata')
    for pid,p in phrases.items():
        es=[e for e in notes if e['phrase_id']==pid]
        check(es and all(p['first_bar']<=e['bar']<=p['last_bar'] for e in es),'phrase membership')
        check(p['target_on_beats']==min(e['onset'] for e in es) and p['target_off_beats']==max(end(e) for e in es),'real phrase endpoints')
        check(abs(p['target_on_seconds']-sec(p['target_on_beats']))<1e-7 and abs(p['target_off_seconds']-sec(p['target_off_beats']))<1e-7,'phrase time integration')
    signatures=[tuple((e['onset']-i*24,e['pitch'],e['duration'],e['instrument']) for e in notes if i*4<e['bar']<=i*4+4 and e['role'] in ('lead','answer')) for i in range(20)]
    check(len(set(signatures))==20,'twenty distinct developed four-bar foreground phrases')
    check(max(e['pitch'] for e in lead)==88 and min(e['bar'] for e in lead if e['pitch']==88)==75,'E6 earned at bar 75 only')
    check(bars[-2]['harmony_name']=='B7/F#' and bars[-1]['harmony_name']=='Em','dominant-tonic close')
    check(lead[-1]['pitch']==64 and end(lead[-1])==480,'final E4 held to final boundary')
    ped=s['pedals'];check(ped==sorted(ped,key=lambda e:e['onset']),'pedal order')
    check(all(p['instrument']=='piano' and p['controller']==64 and 0<=p['onset']<=480 and 0<=p['value']<=127 for p in ped),'pedal bounds')
    check(ped[-1]['onset']==480 and ped[-1]['value']==0,'final pedal release')
    return {'passed':not errors,'errors':errors,'event_count':len(notes),'piano_event_count':len(piano),'flute_event_count':len(flute),
      'bars':80,'total_quarter_beats':480,'duration_with_tail_seconds':round(sec(480)+6,9),
      'maximum_held_span_semitones':maxspan,'maximum_simultaneous_keys':maxkeys,'same_key_overlap_count':len(collisions),
      'hand_crossing_count':len(crossings),'finger_collision_count':len(finger_collisions),'foreground_collision_count':len(foreground_collisions),
      'maximum_simultaneous_foreground_notes':maxforeground,'maximum_physical_silence_seconds':round(max(silent,default=0),9),
      'strict_transfer_count':len(transfers),'minimum_transfer_margin_seconds':min(x['margin_seconds'] for x in transfers),'strict_transfers':transfers,
      'within_position_finger_movements_above_four_semitones':within,'minimum_flute_gate_seconds':round(min(flute_gates),9),'maximum_flute_gate_seconds':round(max(flute_gates),9),
      'minimum_flute_breath_gap_seconds':round(min(breathgaps),9),'flute_source_layers':sorted({e['layer'] for e in flute}),
      'flute_pitch_range':[min(e['pitch'] for e in flute),max(e['pitch'] for e in flute)],'piano_pitch_range':[min(e['pitch'] for e in piano),max(e['pitch'] for e in piano)],
      'quiet_flute_foreground_bars':list(range(33,49)),'true_answer_bars':answerbars,'unique_four_bar_foreground_phrases':len(set(signatures)),
      'limits':'Symbolic saved-key geometry, explicit finger positions and source-layer/gate intent only. No listening approval, audio-source quality claim or assertion of human comfort.'}

def patch_apply(original,patch):
    target=copy.deepcopy(original)
    for p in patch:
        keys=[x.replace('~1','/').replace('~0','~') for x in p['path'].split('/')[1:]]
        if not keys:target=copy.deepcopy(p['value']);continue
        obj=target
        for k in keys[:-1]:obj=obj[int(k)] if isinstance(obj,list) else obj[k]
        key=int(keys[-1]) if isinstance(obj,list) else keys[-1]
        if p['op']=='remove':del obj[key]
        else:obj[key]=copy.deepcopy(p['value'])
    return target

def verify_diff(a,b,d):
    errors=[];expected=[];musical=[]
    core=lambda ns:[{k:e[k] for k in ('onset','duration','pitch','instrument','voice','hand','role','layer')} for e in ns]
    for n in range(1,81):
        row={'bar':n,'before_bar':a['bars'][n-1],'after_bar':b['bars'][n-1]}
        for field in ('events','pedals','breaths'):
            row['before_'+field]=[e for e in a[field] if e['bar']==n];row['after_'+field]=[e for e in b[field] if e['bar']==n]
        if any(row['before_'+k]!=row['after_'+k] for k in ('bar','events','pedals','breaths')):expected.append(row)
        if core(row['before_events'])!=core(row['after_events']) or row['before_bar']['harmony']!=row['after_bar']['harmony']:musical.append(n)
    if d['changes']!=expected or d['changed_bars']!=[r['bar'] for r in expected]:errors.append('literal per-bar diff mismatch')
    if len(musical)<16:errors.append('fewer than sixteen materially revised bars')
    for label,s in [('before',a),('after',b)]:
        if d[label+'_sha256']!=sha(f'score_{s["version"]}.json'):errors.append('saved score hash mismatch')
        if d['phrase_metadata_'+label]!=s['phrases'] or d['position_plan_'+label]!=s['hand_position_plan']:errors.append('phrase/position diff mismatch')
    same=patch_apply(a,d['json_patch'])==b
    if not same:errors.append('full-document JSON patch mismatch')
    return {'passed':not errors,'errors':errors,'changed_bars':d['changed_bars'],'strict_musical_changed_bars':musical,
      'strict_musical_changed_bar_count':len(musical),'full_document_patch_reconstructs_next_version':same}

def main():
    scores={v:load(f'score_{v}.json') for v in ('v0','v1','v2')};audits={v:inspect(s) for v,s in scores.items()}
    for v,r in audits.items():save(f'audit_{v}.json',r)
    diffs={f'{a}_to_{b}':verify_diff(scores[a],scores[b],load(f'exact_diff_{a}_to_{b}.json')) for a,b in [('v0','v1'),('v1','v2')]}
    same=(ROOT/'score.json').read_bytes()==(ROOT/'score_v2.json').read_bytes()
    with tempfile.TemporaryDirectory(prefix='.reproduction_',dir=ROOT) as tmp:
        subprocess.run([sys.executable,str(ROOT/'generate_score.py'),'--outdir',tmp],check=True,capture_output=True)
        reproduction={p.name:(ROOT/p.name).read_bytes()==p.read_bytes() for p in sorted(Path(tmp).iterdir()) if p.is_file()}
    save('reproducibility_check.json',{'passed':all(reproduction.values()),'byte_identical_files':reproduction,
      'method':'Fresh standard-library Python process, temporary directory inside isolated draft; byte-for-byte comparison.'})
    keys=('passed','errors','event_count','piano_event_count','flute_event_count','duration_with_tail_seconds','maximum_held_span_semitones','maximum_simultaneous_keys',
      'same_key_overlap_count','hand_crossing_count','finger_collision_count','foreground_collision_count','maximum_physical_silence_seconds',
      'strict_transfer_count','minimum_transfer_margin_seconds','minimum_flute_gate_seconds','maximum_flute_gate_seconds','minimum_flute_breath_gap_seconds',
      'flute_pitch_range','piano_pitch_range','unique_four_bar_foreground_phrases')
    result={'passed':same and all(r['passed'] for r in audits.values()) and all(r['passed'] for r in diffs.values()) and all(reproduction.values()),
      'selected_equals_v2_byte_for_byte':same,'selected_score_sha256':sha('score.json'),'version_summaries':{v:{k:r[k] for k in keys} for v,r in audits.items()},
      'revision_checks':diffs,'reproducibility_passed':all(reproduction.values()),
      'scope':'Independent saved-file symbolic checks plus fresh-process byte reproducibility. No audio, DSP or listening.'}
    save('independent_verification.json',result)
    files={p.name:{'bytes':p.stat().st_size,'sha256':sha(p.name)} for p in sorted(ROOT.iterdir()) if p.is_file() and p.name!='hash_manifest.json'}
    save('hash_manifest.json',{'algorithm':'SHA-256','files':files,'excludes_self':True,'scope':'Every regular deliverable file in this isolated draft folder.'})
    print(json.dumps(result,ensure_ascii=False,indent=2))
    if not result['passed']:raise SystemExit(1)
if __name__=='__main__':main()
