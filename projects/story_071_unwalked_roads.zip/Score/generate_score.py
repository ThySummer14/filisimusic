#!/usr/bin/env python3
"""Work 71: deterministic original piano score; Python standard library only.
No audio, plugins, rendering, random state, or external dependencies.
"""
from pathlib import Path
import json, math, hashlib, csv
from collections import Counter

OUT = Path(__file__).resolve().parent
TITLE = '未走之路的地图'

# Every line is a newly composed 7/8 bar. Durations are quarter-note beats.
A = [
'D4:.5 F#4:.5 A4:1 F#4:.5 E4:.5 D4:.5',
'E4:.5 F#4:.5 G4:.5 F#4:.5 E4:1 C#4:.5',
'F#4:1 A4:.5 B4:.5 A4:.5 F#4:.5 E4:.5',
'G4:.5 E4:.5 D4:1 C#4:.5 E4:1',
'D4:.5 F#4:.5 A4:.5 D5:.5 C#5:.5 B4:.5 A4:.5',
'B4:.5 A4:.5 G4:1 F#4:.5 E4:1',
'F#4:.5 E4:.5 D4:.5 E4:.5 F#4:.5 G4:.5 A4:.5',
'E4:1 C#4:.5 E4:.5 D4:1.5',
'F#4:.5 A4:.5 D5:1 A4:.5 G4:.5 F#4:.5',
'E4:.5 G4:.5 B4:.5 A4:.5 G4:1 F#4:.5',
'G4:.5 B4:.5 D5:.5 B4:.5 A4:.5 G4:.5 F#4:.5',
'E4:1 F#4:.5 E4:.5 C#4:.5 B3:.5 C#4:.5',
'D4:.5 F#4:.5 A4:.5 B4:.5 C#5:.5 D5:1',
'C#5:.5 B4:.5 A4:1 G4:.5 F#4:.5 E4:.5',
'F#4:.5 E4:.5 D4:1 E4:.5 C#4:1',
'D4:2 r:.5 A4:.5 B4:.5',
'D5:.5 A4:.5 F#4:.5 E4:.5 D4:1 F#4:.5',
'G4:.5 A4:.5 B4:1 A4:.5 G4:1',
'E4:.5 F#4:.5 G4:.5 A4:.5 B4:.5 A4:.5 G4:.5',
'F#4:1 E4:.5 C#4:.5 E4:1 r:.5',
'F#4:.5 A4:.5 D5:.5 C5:.5 B4:.5 A4:.5 G4:.5',
'E4:.5 G4:.5 C5:1 B4:.5 G4:.5 E4:.5',
'F#4:.5 G4:.5 A4:1 B4:.5 A4:1',
'G4:.5 E4:.5 C#4:.5 E4:.5 A4:1 r:.5',
]
B = [
'G4:.5 C5:1 B4:.5 G4:.5 E4:1',
'F4:.5 A4:1 G4:.5 F4:.5 D4:1',
'E4:.5 G4:.5 C5:.5 E5:.5 D5:.5 C5:1',
'B4:1 G4:.5 A4:.5 B4:.5 G4:.5 r:.5',
'A4:.5 C5:1 B4:.5 A4:.5 G4:1',
'F4:.5 A4:.5 D5:.5 C5:.5 A4:.5 F4:1',
'E4:.5 G4:1 A4:.5 G4:.5 E4:1',
'D4:.5 F#4:1 A4:.5 F#4:.5 E4:1',
'G4:.5 B4:1 D5:.5 B4:.5 G4:1',
'E5:.5 D5:.5 C5:.5 B4:.5 A4:.5 G4:1',
'F#4:.5 A4:.5 B4:.5 A4:.5 G4:.5 F#4:1',
'E4:1 C#4:.5 E4:1 A4:.5 r:.5',
]
C = [
'F#4:1 D5:1.5 C#5:1',
'B4:.5 A4:.5 G4:1.5 F#4:1',
'E4:1 F#4:.5 G4:1 B4:1',
'A4:1 E4:1.5 C#4:1',
'D4:1 F#4:1.5 A4:1',
'B4:.5 C#5:.5 D5:1.5 B4:1',
'G4:1 F#4:.5 E4:1 D4:1',
'C#4:1 E4:1.5 A4:1',
'F#4:1 A4:.5 D5:1 C#5:1',
'B4:1 G4:1.5 E4:1',
'A4:.5 B4:.5 C#5:.5 D5:.5 E5:.5 C#5:1',
'D5:2.5 r:1',
]
RETURN = [
'D5:.5 A4:1 F#4:.5 E4:.5 D4:1',
'E4:.5 G4:1 B4:.5 A4:.5 G4:1',
'F#4:.5 A4:.5 B4:.5 D5:.5 C#5:.5 B4:1',
'A4:1 G4:.5 E4:1 C#4:1',
'D4:.5 F#4:.5 A4:.5 D5:1 C5:.5 B4:.5',
'G4:.5 C5:1 B4:.5 G4:.5 E4:1',
'F#4:1 A4:.5 B4:.5 A4:.5 G4:.5 E4:.5',
'D4:2 r:.5 F#4:.5 A4:.5',
'B4:.5 A4:1 G4:.5 F#4:.5 E4:1',
'F#4:1 D5:1.5 C#5:1',
'B4:.5 D5:.5 E5:.5 D5:.5 B4:.5 G4:1',
'A4:1 E5:.5 C#5:1 A4:1',
'F#4:.5 A4:.5 D5:.5 E5:.5 F#5:.5 E5:1',
'D5:1 C5:.5 B4:1 A4:1',
'G4:.5 F#4:.5 E4:.5 C#4:.5 E4:.5 A4:1',
'D5:2.5 r:1',
]
CODA = [
'A4:.5 F#4:.5 D4:1 E4:.5 F#4:1',
'G4:.5 B4:1 A4:.5 G4:.5 E4:1',
'F#4:.5 A4:.5 D5:.5 C5:.5 B4:.5 G4:1',
'E4:1 G4:.5 C5:1 B4:.5 G4:.5',
'F#4:1 A4:.5 D5:1 A4:1',
'G4:.5 E4:.5 C#4:1 E4:.5 A4:1',
'F#4:.5 E4:.5 D4:1 A4:.5 F#4:1',
'D4:3.5',
]

CHORDS = {
'D': [50,54,57], 'A': [45,49,52], 'Bm': [47,50,54],
'G': [43,47,50], 'A7': [45,49,52,55], 'Em': [52,55,59],
'Em7': [52,55,59], 'D7': [50,54,57,60], 'C': [48,52,55],
'Dm': [50,53,57], 'Am': [45,48,52], 'C/E': [40,48,52],
'Gmaj7': [43,47,50,54], 'D/F#': [42,50,54],
'D/A': [45,50,54,57], 'D_close': [38,45,50],
}
HA = ['D','A','Bm','A7','D','G','A7','D',
      'D','Em','G','A','Bm','G','A7','D',
      'D','G','Em','A','D7','C','A7','A7']
HB = ['C','Dm','C','G','Am','Dm','C/E','D','G','C','D','A7']
HC = ['Bm','Gmaj7','Em','A','D/F#','G','Em7','A','D','Em','A7','D']
HR = ['D','Em','Bm','A7','D7','C','A7','D','G','Bm','G','A7','D','C','A7','D']
HK = ['D','G','D7','C','D/A','A7','D','D_close']

NOTEPCS = {'C':0,'D':2,'E':4,'F':5,'G':7,'A':9,'B':11}
def midi(s):
    if s == 'r': return None
    return (int(s[-1])+1)*12 + NOTEPCS[s[0]] + (1 if '#' in s else 0)
def parse(s):
    ans = [(midi(x.split(':')[0]), float(x.split(':')[1])) for x in s.split()]
    assert sum(d for p,d in ans) == 3.5, s
    return ans

def section(n):
    for last, name in [(8,'白纸与岔口'),(24,'大路没走，小路出现'),(36,'蜂箱边的小集'),(48,'水塔长坡'),(64,'把走过的路补上'),(72,'路牌下面的午饭')]:
        if n <= last: return name

def tempo(n):
    if n<=8:return 84
    if n<=24:return 90
    if n<=36:return 96
    if n<=48:return 84
    if n<=64:return 92
    return {65:84,66:84,67:82,68:82,69:80,70:80,71:76,72:72}[n]

def groups(n,v):
    if v>=1 and 25<=n<=36: return [1.5,1,1]  # 3+2+2 eighths
    if v>=1 and 37<=n<=48: return [1,1.5,1]  # 2+3+2 eighths
    if v==2 and n in [49,50,54,57,66]: return [1.5,1,1]
    if v==2 and n in [58,60]: return [1,1.5,1]
    return [1,1,1.5]


def build(version):
    # v0 is a deliberately literal first draft, kept as an honest revision baseline.
    lines = A + A[8:20] + A[:12] + A[:16] + A[:8]
    harmony = HA + HA[8:20] + HA[:12] + HA[:16] + HA[:8]
    if version>=1:
        lines[24:48] = B+C
        harmony[24:48] = HB+HC
    if version>=2:
        lines[48:72] = RETURN+CODA
        harmony[48:72] = HR+HK
    assert len(lines)==len(harmony)==72
    score = {'id':71,'title':'Map of the Unwalked Roads','title_zh':TITLE,
             'bars':[],'events':[],'pedals':[{'onset':0,'value':0}],
             'total_beats':252,'tail_seconds':4}
    def event(n,t,d,p,vel,voice):
        score['events'].append({'bar':n,'onset':round((n-1)*3.5+t,6),
                               'duration':round(d,6),'pitch':p,'velocity':int(vel),
                               'voice':voice,'instrument':'piano'})
    for n,(line,h) in enumerate(zip(lines,harmony),1):
        ch=CHORDS[h]; gs=groups(n,version)
        starts=[0,gs[0],gs[0]+gs[1]]
        is_b=version>=1 and 25<=n<=36
        is_c=version>=1 and 37<=n<=48
        is_return=version==2 and 49<=n<=64
        last=version==2 and n==72
        cadence=n in (8,16,24,36,48,56,64,70,71,72)
        support_kind='空拍上的短和弦，低音不作独立旋律'
        if is_c: support_kind='与长音同向的根音及紧密和弦；第二组延长'
        if is_b: support_kind='根音与短和弦按3+2+2分组；跟随右手的停顿'
        if is_return: support_kind='主路脉冲吸收岔路分组；和声与右手共同走向终止'
        if last: support_kind='双手同落D大调，低音D2—A2—D3，完整结束'
        score['bars'].append({'bar':n,'start':(n-1)*3.5,'beats':3.5,'bpm':tempo(n),
            'section':section(n),'meter_numerator':7,'meter_denominator':8,
            'harmony_name':('D' if h=='D_close' else h),'harmony':ch,
            'role_plan':f"右手唱单一主旋律，少量同拍和声；左手{support_kind}。八分音符分组"+
                '+'.join(str(int(g*2)) for g in gs)+'。',
            'lead_instrument':'piano'})
        phrase = [0,2,3,0,3,5,2,-3][(n-1)%8]
        base=70 if n<=8 else 75
        if is_b: base=77
        if is_c: base=67+(n-37)//4*2
        if is_return: base=75+(2 if n>=57 else 0)
        if n>=65: base=72-(n-65)
        cursor=0
        mel=parse(line)
        for j,(p,d) in enumerate(mel):
            if p is not None:
                factor=0.79 if is_b else (0.97 if is_c else 0.92)
                if is_return and n in (49,50,54,57):factor=0.88
                if last:factor=0.96
                actual=max(0.18,d*factor)
                vel=base+phrase+(3 if cursor in starts else -1)
                if p>=78:vel+=2
                event(n,cursor,actual,p,vel,'melody')
                # No independently moving right-hand counterline. Supports are selected
                # from this bar's chord and share the melody's onset and release.
                want=(d>=1 and n%2==1) or (is_c and d>=1.5) or (is_return and d>=1.5)
                if want and not last:
                    pcs={x%12 for x in ch}
                    opts=[q for q in range(max(60,p-7),p-2) if q%12 in pcs]
                    if opts:
                        q=opts[-1]
                        event(n,cursor,actual,q,base-19+phrase//2,'upper_support')
            cursor+=d
        if last:
            event(n,0,3.36,66,56,'upper_support')
            event(n,0,3.36,69,52,'upper_support')
            event(n,0,3.36,38,56,'bass')
            event(n,0,3.36,45,44,'accompaniment')
            event(n,0,3.36,50,47,'accompaniment')
            continue
        # A literal accompaniment to the active harmony. Compact voicing <= octave.
        # The root is never re-triggered while held; groups have explicit gaps.
        leftbase=base-21
        root=ch[0]
        lowdur=gs[0]*(0.87 if is_c else 0.65)
        event(n,0,lowdur,root,leftbase+6,'bass')
        upper=ch[1:]
        if is_c:
            # Sustained compact harmony, not a second tune.
            for q in upper[-2:]:event(n,starts[1],gs[1]*0.87,q,leftbase-2,'accompaniment')
            event(n,starts[2],gs[2]*0.82,root,leftbase+1,'bass')
            if n not in (40,44,48):
                event(n,starts[2],gs[2]*0.82,upper[-1],leftbase-4,'accompaniment')
        elif is_b:
            for q in upper[-2:]:event(n,starts[1],0.48,q,leftbase-2,'accompaniment')
            # Rest at the end of four-bar questions is intentional.
            if n not in (28,36):
                event(n,starts[2],0.61,root,leftbase+2,'bass')
                event(n,starts[2],0.61,upper[-1],leftbase-4,'accompaniment')
        else:
            # Two short harmonic punctuation patterns, rotated with phrase direction.
            if n%4 in (1,2):
                event(n,starts[1],min(gs[1]*0.68,0.85),upper[-1],leftbase-2,'accompaniment')
                for q in upper[:2]:event(n,starts[2],gs[2]*(0.79 if cadence else 0.66),q,leftbase-3,'accompaniment')
            else:
                for q in upper[-2:]:event(n,starts[1],gs[1]*0.64,q,leftbase-2,'accompaniment')
                if n not in (16,24,64):event(n,starts[2],gs[2]*0.68,root,leftbase+1,'bass')
            if version==2 and n in (53,61,69):
                # Structural tonic arrivals have a fuller, coordinated third group.
                event(n,starts[2],gs[2]*0.66,root,leftbase+3,'bass')
    score['events'].sort(key=lambda e:(e['onset'],e['pitch'],e['voice']))
    score['pedals'].append({'onset':252,'value':0})
    return score

def fingerprint(s,n):
    start=s['bars'][n-1]['start']
    return tuple((round(e['onset']-start,6),e['pitch'],e['duration']) for e in s['events'] if e['bar']==n and e['voice']=='melody')

def audit(s):
    errors=[]
    beats=0.; seconds=0.
    for b in s['bars']:
        if b['start']!=beats:errors.append(f"bar {b['bar']}: noncontiguous start")
        if b['beats']!=b['meter_numerator']*4/b['meter_denominator']:errors.append('meter mismatch')
        beats+=b['beats'];seconds+=60*b['beats']/b['bpm']
    if beats!=s['total_beats']:errors.append('total-beat mismatch')
    if len(s['bars'])!=72:errors.append('bar count mismatch')
    for e in s['events']:
        b=s['bars'][e['bar']-1]
        if not (b['start']<=e['onset']<b['start']+b['beats']):errors.append(f'onset outside bar: {e}')
        if e['duration']<=0 or e['onset']+e['duration']>b['start']+b['beats']+1e-8:errors.append(f'duration outside bar: {e}')
        if not (0<=e['pitch']<=127 and 1<=e['velocity']<=127):errors.append('MIDI range error')
        if e['voice'] not in ['melody','upper_support','bass','accompaniment'] or e['instrument']!='piano':errors.append('schema voice/instrument error')
        if e['voice'] in ('bass','accompaniment') and e['pitch'] not in b['harmony']:errors.append(f'LH not chord member: {e}')
    pitches={}
    for e in s['events']:pitches.setdefault(e['pitch'],[]).append(e)
    overlap=[]
    for p,es in pitches.items():
        es.sort(key=lambda e:e['onset'])
        for i,a in enumerate(es):
            for b in es[i+1:]:
                if b['onset']>=a['onset']+a['duration']-1e-8:break
                overlap.append({'pitch':p,'first':a,'second':b})
    if overlap:errors.append(f'{len(overlap)} overlapping identical-key pairs')
    timeline=sorted({e['onset'] for e in s['events']}|{round(e['onset']+e['duration'],6) for e in s['events']})
    maxspan={'right':0,'left':0}; maxcount={'right':0,'left':0};maxpoly=0; worst=[];crossings=[]
    for t in timeline:
        active=[e for e in s['events'] if e['onset']<=t+1e-8 and e['onset']+e['duration']>t+1e-8]
        maxpoly=max(maxpoly,len(active))
        hands={h:[e for e in active if (e['voice'] in ('melody','upper_support'))==(h=='right')] for h in ('right','left')}
        for h,es in hands.items():
            ps=[e['pitch'] for e in es]
            span=max(ps)-min(ps) if ps else 0
            maxspan[h]=max(maxspan[h],span);maxcount[h]=max(maxcount[h],len(es))
            if span>12:worst.append({'beat':t,'hand':h,'pitches':ps})
        if hands['right'] and hands['left'] and min(e['pitch'] for e in hands['right'])<max(e['pitch'] for e in hands['left']):
            crossings.append(t)
    if worst:errors.append('simultaneous hand span > octave')
    if crossings:errors.append('hand crossing')
    if any(not 0<=x['value']<=63 for x in s['pedals']):errors.append('pedal value outside schema')
    melody=[e for e in s['events'] if e['voice']=='melody']
    melody.sort(key=lambda e:e['onset'])
    maxleap=max(abs(b['pitch']-a['pitch']) for a,b in zip(melody,melody[1:]))
    maxrest=max(b['onset']-(a['onset']+a['duration']) for a,b in zip(melody,melody[1:]))
    for a,b in zip(melody,melody[1:]):
        if b['onset']<a['onset']+a['duration']-1e-8:errors.append('melody voice overlap')
    fs=[fingerprint(s,n) for n in range(1,73)]
    onset_pitch_fs=[tuple((onset,pitch) for onset,pitch,duration in f) for f in fs]
    duplicate_phrases=[]
    for i in range(len(fs)-3):
        for j in range(i+4,len(fs)-3):
            if onset_pitch_fs[i:i+4]==onset_pitch_fs[j:j+4]:duplicate_phrases.append([i+1,j+1])
    tempo_sections=[]
    for b in s['bars']:
        if not tempo_sections or tempo_sections[-1]['bpm']!=b['bpm']:
            tempo_sections.append({'first_bar':b['bar'],'last_bar':b['bar'],'bpm':b['bpm'],'seconds':60*b['beats']/b['bpm']})
        else:
            tempo_sections[-1]['last_bar']=b['bar'];tempo_sections[-1]['seconds']+=60*b['beats']/b['bpm']
    for d in tempo_sections:d['seconds']=round(d['seconds'],9)
    return {'technical_pass':not errors,'errors':errors,'bar_count':72,'event_count':len(s['events']),
      'events_by_voice':dict(Counter(e['voice'] for e in s['events'])),
      'total_beats':beats,'integrated_score_seconds':round(seconds,9),
      'tail_seconds':s['tail_seconds'],'duration_with_tail_seconds':round(seconds+s['tail_seconds'],9),
      'tempo_integration':tempo_sections,
      'pitch_range':[min(e['pitch'] for e in s['events']),max(e['pitch'] for e in s['events'])],
      'velocity_range':[min(e['velocity'] for e in s['events']),max(e['velocity'] for e in s['events'])],
      'max_simultaneous_hand_span_semitones':maxspan,'max_simultaneous_hand_notes':maxcount,
      'max_total_key_down_polyphony':maxpoly,'identical_key_overlap_count':len(overlap),
      'identical_key_overlap_details':overlap,'octave_span_violation_details':worst,'hand_crossing_count':len(crossings),
      'max_melody_adjacent_leap_semitones':maxleap,'max_melody_gap_beats':round(maxrest,6),
      'distinct_melody_bars_including_gate_lengths':len(set(fs)),
      'distinct_melody_bars_by_onset_and_pitch':len(set(onset_pitch_fs)),
      'exact_repeated_four_bar_melody_blocks_ignoring_gate_lengths':duplicate_phrases,
      'left_hand_nonchord_notes':0 if not any('LH not chord' in e for e in errors) else 'ERROR',
      'pedal_values':sorted({p['value'] for p in s['pedals']}),
      'audio_rendered':False,'listening_performed':False,
      'limitations':'This is a deterministic technical score audit, not a listening result or a musical-quality guarantee. It checks simultaneous written key-down spans, not anatomical fingerings, voicing balance, acoustic release tails, or a specific piano engine.'}

def save_json(path,obj):
    path.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')

def main():
    scores=[]; audits=[]
    for v in range(3):
        s=build(v);a=audit(s);scores.append(s);audits.append(a)
        save_json(OUT/f'score_v{v}.json',s);save_json(OUT/f'audit_v{v}.json',a)
    changes=[]
    for va,vb in [(0,1),(1,2)]:
        x,y=scores[va],scores[vb]
        changes.append({'from':f'v{va}','to':f'v{vb}',
            'melody_changed_bars':[n for n in range(1,73) if fingerprint(x,n)!=fingerprint(y,n)],
            'harmony_changed_bars':[n for n in range(1,73) if x['bars'][n-1]['harmony']!=y['bars'][n-1]['harmony']],
            'role_plan_changed_bars':[n for n in range(1,73) if x['bars'][n-1]['role_plan']!=y['bars'][n-1]['role_plan']],
            'event_count_before':len(x['events']),'event_count_after':len(y['events'])})
    save_json(OUT/'revision_diff.json',changes)
    with (OUT/'score_v2_events.csv').open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=['bar','onset','duration','pitch','velocity','voice','instrument']);w.writeheader();w.writerows(scores[2]['events'])
    # Human-readable note-duration table, including intentional rests.
    final_lines=A+B+C+RETURN+CODA
    out=['作品71《未走之路的地图》v2逐小节旋律表','记法：音名:四分音符拍数，r为休止；每小节7/8=3.5拍。','']
    for b,l in zip(scores[2]['bars'],final_lines):
        out.append(f"{b['bar']:02d} | {b['section']} | q={b['bpm']} | {b['harmony_name']} | {l}")
    (OUT/'score_v2_melody.txt').write_text('\n'.join(out)+'\n',encoding='utf-8')
    artifacts=['score_v0.json','score_v1.json','score_v2.json','audit_v0.json','audit_v1.json','audit_v2.json','revision_diff.json','score_v2_events.csv','score_v2_melody.txt']
    save_json(OUT/'generated_sha256.json',{p:hashlib.sha256((OUT/p).read_bytes()).hexdigest() for p in artifacts})
    for v,a in enumerate(audits):print(f"v{v}: pass={a['technical_pass']} events={a['event_count']} seconds+tail={a['duration_with_tail_seconds']} maxspan={a['max_simultaneous_hand_span_semitones']} overlaps={a['identical_key_overlap_count']}")
    if not all(a['technical_pass'] for a in audits):raise SystemExit(1)
if __name__=='__main__':main()
