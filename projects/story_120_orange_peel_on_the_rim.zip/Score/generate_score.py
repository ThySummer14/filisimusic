"""Original wind-led syncopated chamber dance. Technical JSON export conventions reused."""
from pathlib import Path
import json,sys,bisect
P=Path(__file__).resolve().parent;sys.path.insert(0,str(P));from composition_data import *
def write(p,x):p.write_text(json.dumps(x,ensure_ascii=False,separators=(',',':'))+'\n')
def pitch(s):return 12*(int(s[-1])+1)+{'C':0,'D':2,'E':4,'F':5,'G':7,'A':9,'B':11}[s[0]]+s[1:-1].count('#')-s[1:-1].count('b')
def build(level):
 rows=[(sec,bpm,dyn,row) for sec,bpm,dyn,rr in GROUPS for row in rr];assert len(rows)==92
 events=[];bars=[];pedals=[]
 for n,(sec,bpm,dyn,row) in enumerate(rows,1):
  if level>=1:row=REV1.get(n,row)
  if level>=2:row=REV2.get(n,row)
  h,wind,bass=row;start=(n-1)*4;ch=H[h]
  if n>=90:bpm-=3*(n-89)
  bars.append(dict(bar=n,start=start,beats=4,bpm=bpm,meter='4/4',meter_numerator=4,meter_denominator=4,section=sec,harmony_name=h,harmony=ch,key_region='G major and E minor; borrowed C minor and secondary dominants'))
  def add(p,t,d,v,inst,voice,hand='none'):
   assert 0<=t<t+d<=4.00001,(n,t,d)
   events.append(dict(bar=n,onset=round(start+t,6),duration=round(d,6),pitch=int(p),velocity=int(v),instrument=inst,voice=voice,hand=hand))
  ww=list(map(pitch,wind.split()));bb=list(map(pitch,bass.split()))
  # Three unequal-spaced wind attacks keep the phrase singable at every tempo.
  ons=[.25,1.5,2.875];gates=[.82,.82,.82]
  if sec=='glass':ons=[.25,1.75,3.0];gates=[1.1,.85,.78]
  if level>=1 and n in REV1:ons=[0,1.375,2.75];gates=[.86,.86,.86]
  if level>=2 and n in REV2:ons=[.125,1.5,2.875];gates=[.95,.95,.85]
  # Breath lengths and rests follow the sentence, not a continuous three-note loop.
  if n in [2,7,14,18,24,42,44,47,69,73,77,83,85,88]:
   ww=[ww[0],ww[-1]];ons=[.25,2.5];gates=[1.35,1.15]
  if n in [11,45,67,87]:ww=[ww[-1]];ons=[1.0];gates=[1.45]
  if level>=2 and n in [48,52,61]:
   ww=list(map(pitch,{48:'G4 B4 A4 G4',52:'B4 A4 G4 D4',61:'G4 A4 B4 G4'}[n].split()));ons=[.125,1.125,2.125,3.125];gates=[.65,.65,.65,.65]
  if n in FILLS:ww=ww[:1];ons=[.25];gates=[.95]
  if sec=='last_scent' and n==92:ons=[0,1.4,2.8];gates=[1.05,1.0,1.15]
  for i,(p,t,d) in enumerate(zip(ww,ons,gates)):add(p,t,d,dyn+(3 if i==0 and sec=='spark' else -4 if i==2 else 0),'clarinet','orange_peel_subject')
  low_ons=[0,1.5,2.5];low_gate=[.55,.42,.52]
  if sec=='glass':low_ons=[0,2,3.5];low_gate=[.72,.6,.4]
  if level>=1 and n in REV1:low_ons=[.5,2.0,3.5];low_gate=[.42,.55,.35]
  if level>=2 and n in REV2:low_ons=[0,1.875,3.25];low_gate=[.5,.45,.55]
  for i,(p,t,d) in enumerate(zip(bb,low_ons,low_gate)):add(p,t,d,dyn-21+(3 if i==2 else 0),'piano','syncopated_lower_reply','left')
  # A quiet third/seventh shell occupies the wind's lower register, never its loudness.
  # Its offbeat attacks interlock with the written bass; later piano fills take over the foreground.
  shell=[ch[1],ch[2]]
  while min(shell)<60:shell=[p+12 for p in shell]
  while max(shell)>76:shell=[p-12 for p in shell]
  comp=[(1,.24),(2.25,.30),(3.5,.23)]
  if sec=='glass':comp=[(1.25,.32),(2.875,.28)]
  if sec=='bitter':comp=[(.75,.22),(2.25,.22),(3.75,.19)]
  if level>=1 and n in REV1:comp=[(1.0,.28),(2.875,.24)]
  if level>=2 and n in REV2:comp=[(.875,.25),(2.5,.25),(3.75,.19)]
  if n in FILLS:
   fill=list(map(pitch,FILLS[n].split()))
   if n==54:fill=list(map(pitch,'G#5 B5 G#5 E5'.split()))
   if n==90:fill=list(map(pitch,'G5 Eb5 D5 C5'.split()))
   for i,p in enumerate(fill):add(p,1.75+i*.5,.35,dyn-1-i,'piano','piano_carries_the_sentence','right')
  else:
   for t,d in comp:
    for p in shell:add(p,t,d,dyn-22 if sec!='spark' else dyn-18,'piano','offbeat_harmonic_shell','right')
  pedals.append(dict(bar=n,onset=start,controller=64,value=0,instrument='piano'))
 events.sort(key=lambda e:(e['onset'],e['instrument'],e['pitch']))
 for i,e in enumerate(events):e['event_id']=f'120-v{level}-{i}'
 return dict(id=120,title='Orange Peel on the Rim',title_zh='橙皮留在杯沿',version=f'v{level}',bars=bars,events=events,pedals=pedals,total_beats=368,tail_seconds=5,instrument_map={'piano':'piano','clarinet':'clarinet'},performance_contract='Original clarinet-led 4/4 chamber dance with unequal spaced melodic cells, explicit bass replies, and quiet offbeat piano shells. Bossa-related rhythmic vocabulary; no percussion loop or live-performance claim.')
def proj(d,n):return {'bar':d['bars'][n-1],'events':[{k:v for k,v in e.items() if k!='event_id'} for e in d['events'] if e['bar']==n],'pedals':[e for e in d['pedals'] if e['bar']==n]}
for v in range(3):
 d=build(v);write(P/f'score_v{v}.json',d);report=dict(version=f'v{v}',bars=len(d['bars']),events=len(d['events']),duration_seconds=sum(b['beats']*60/b['bpm'] for b in d['bars'])+5,human_listening_review=False);write(P/f'audit_v{v}.json',report)
 if v:
  a=build(v-1);changes=[{'bar':n,'before':proj(a,n),'after':proj(d,n)} for n in range(1,93) if proj(a,n)!=proj(d,n)];write(P/f'exact_diff_v{v-1}_to_v{v}.json',{'count':len(changes),'changed_bars':[x['bar'] for x in changes],'comparison_excludes':['version','event_id'],'changes':changes})
write(P/'score.json',d);write(P/'ensemble_score.json',d)
for inst in ['piano','clarinet']:write(P/f'{inst}_score.json',{**d,'events':[e for e in d['events'] if e['instrument']==inst],'pedals':d['pedals'] if inst=='piano' else []})
print(json.dumps(report))
