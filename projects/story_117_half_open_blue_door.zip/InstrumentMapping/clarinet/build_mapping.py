import pathlib,json,aifc,wave,hashlib,math
P=pathlib.Path(__file__).parent;(P/'Samples').mkdir(exist_ok=True);a=json.loads((P/'scale_analysis.json').read_text());rows=[];sfz='<global> ampeg_attack=0.003 ampeg_release=0.10 loop_mode=no_loop amp_veltrack=35\n'
for layer in a:
 with aifc.open(str(P/layer['source_file']),'rb')as f:sr=f.getframerate();raw=f.readframes(f.getnframes());n=len(raw)//2
 lo,hi={'pp':(1,55),'mf':(56,95),'ff':(96,127)}[layer['layer']]
 sfz+=f'<group> lovel={lo} hivel={hi}\n'
 for j,note in enumerate(layer['notes']):
  start=max(0,note['active_start_frame']-round(.04*sr));end=min(n,note['active_end_frame']+round(.12*sr));b=raw[start*2:end*2];data=bytearray(len(b));data[0::2]=b[1::2];data[1::2]=b[0::2];name=f"clarinet_{layer['layer']}_{note['midi']}.wav";dest=P/'Samples'/name
  with wave.open(str(dest),'wb')as w:w.setnchannels(1);w.setsampwidth(2);w.setframerate(sr);w.writeframes(data)
  tune=round(-note['deviation_cents'],2);sfz+=f"<region> key={note['midi']} pitch_keycenter={note['midi']} tune={tune} sample=Samples/{name}\n";rows.append(dict(layer=layer['layer'],midi=note['midi'],source=layer['source_file'],source_start_frame=start,source_end_frame=end,derived_file='Samples/'+name,sha256=hashlib.sha256(dest.read_bytes()).hexdigest(),duration=(end-start)/sr,tune_cents=tune))
(P/'Iowa_clarinet_C4_B4_three_layers.sfz').write_text(sfz);(P/'mapping_manifest.json').write_text(json.dumps({'operation':'Lossless selection of original mono16bitPCM into WAV; no resampling or per-note normalization. Preserve40ms before threshold onset and120ms after active region. Sample tuning correction isSFZplaybackmetadata, based on measured central-tone estimate.','dynamics':'Three genuine recordedpp/mf/fflayers selected by note velocity; amplitude velocity tracking reduced to35% to avoid multiplying the recorded dynamic gap too aggressively. No crossfadelegato, no looped sustain, no recorded release layer.','recommended_max_note_seconds':1.55,'reason':'Shortest detected stable region1.74sec; phrased shorter notes avoid ending unexpectedly.','files':rows},indent=2));print(len(rows),'mapped mono16bitnotes',sum((P/x['derived_file']).stat().st_size for x in rows),'derivedbytes')
# Sixnotes across three actual timbre layers, entirely inside the verifiedC4–B4range.
d=dict(title='Iowa three-layer clarinet mapping technical proof',bars=[dict(bar=1,start=0,beats=6,bpm=60,section='Recordedpp thenmf thenff'),dict(bar=2,start=6,beats=6,bpm=60,section='Upper range and repeated layer contrast')],events=[dict(bar=1 if j<3 else 2,onset=j*2,duration=1.35,pitch=[60,63,67,71,65,70][j],velocity=[45,75,110,45,75,110][j],voice='clarinet')for j in range(6)],pedals=[],total_beats=12,tail_seconds=2.5,disclosure='Technical instrument test, not a composition. Actualthree dynamics, monorecording, shorter articulated notes, no sampled legato.');(P/'test_score.json').write_text(json.dumps(d,indent=2));(P/'test.rpp').write_text(f'''<REAPER_PROJECT 0.1 7.82 1
  SAMPLERATE 44100 0 0
  TEMPO 60 4 4 0
  MASTER_VOLUME 1
  RENDER_FILE "{P}/three_layer_proof.wav"
  RENDER_FMT 0 2 44100
  RENDER_1X 0
  RENDER_RANGE 0 0 14.5 0 1000
  RENDER_STEMS 0
  RENDER_DITHER 0
  <RENDER_CFG
    ZXZhdxgAAA==
  >
  <TRACK
    NAME "Three recorded dynamics | mono | no real legato"
    VOLPAN 5 0 1 -1
    MAINSEND 1
    <ITEM
      POSITION 0
      LENGTH 14.5
      VOLPAN 1 0 1 -1
      <SOURCE WAVE
        FILE "three_layer_float32.wav"
      >
    >
  >
>
''')
