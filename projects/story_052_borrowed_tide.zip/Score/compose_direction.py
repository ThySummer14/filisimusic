import pathlib,json,copy,math,collections
P=pathlib.Path(__file__).parent
A=[[(74,.5),(77,.5),(81,1),(79,.5),(77,.5),(76,.5),(77,.5)],[(74,1),(77,.5),(82,.5),(81,.5),(79,.5),(77,1)],[(81,.5),(84,.5),(81,1),(79,.5),(77,.5),(76,.5),(77,.5)],[(76,1),(79,.5),(84,.5),(83,.5),(81,.5),(79,1)],[(82,.5),(81,.5),(79,1),(74,.5),(79,.5),(81,.5),(82,.5)],[(86,1),(84,.5),(82,.5),(77,.5),(79,.5),(81,.5),(82,.5)],[(85,.5),(83,.5),(81,1),(80,.5),(81,.5),(85,.5),(81,.5)],[(86,1.5),(81,.5),(77,.75),(76,.25),(74,.5),(-1,.5)]]
D=[[(77,.5),(81,.5),(86,1),(84,.5),(81,.5),(79,.5),(77,.5)],[(77,1),(82,.5),(86,.5),(84,.5),(82,.5),(81,.5),(77,.5)],[(84,.5),(86,.5),(89,1),(88,.5),(86,.5),(84,.5),(81,.5)],[(84,1),(83,.5),(81,.5),(79,.5),(76,.5),(79,1)],[(86,.5),(84,.5),(82,1),(81,.5),(79,.5),(77,.5),(79,.5)],[(82,.75),(86,.25),(89,1),(86,.5),(84,.5),(82,1)],[(88,.5),(85,.5),(81,.5),(80,.5),(81,.5),(83,.5),(85,.5),(88,.5)],[(86,1),(84,.5),(81,.5),(77,1),(74,.5),(-1,.5)]]
BR=[[(79,.5),(82,.5),(86,1),(84,.5),(82,.5),(81,.5),(79,.5)],[(79,1),(82,.5),(87,.5),(86,.5),(84,.5),(82,1)],[(77,.5),(82,.5),(86,1),(84,.5),(82,.5),(81,.5),(77,.5)],[(76,1),(79,.5),(84,.5),(83,.5),(81,.5),(79,1)],[(82,.5),(86,.5),(89,1),(86,.5),(84,.5),(82,.5),(81,.5)],[(82,1),(86,.5),(89,.5),(88,.5),(86,.5),(84,.5),(82,.5)],[(85,.5),(88,.5),(93,1),(91,.5),(88,.5),(85,.5),(83,.5)],[(81,1),(80,.5),(81,.5),(85,1),(-1,.5),(81,.5)]]
H={'Dm':[50,57,62,65],'Bb':[46,53,58,62],'F':[48,53,57,60],'C':[48,55,60,64],'Gm':[43,50,55,58],'Eb':[46,51,55,58],'A':[45,52,57,61]}
progression=['Dm','Bb','F','C','Gm','Bb','A','Dm'];bridge=['Gm','Eb','Bb','C','Gm','Bb','A','A']
sections=[('Tide gathering',4),('Departure theme',8),('Shared motion',8),('The harbor opens',8),('All boats depart',8)]
notes=[];pedals=[];bars=[];beat=0;barno=0
for si,(title,count) in enumerate(sections):
 for j in range(count):
  barno+=1;key=(bridge if si==3 else progression)[j%8];ch=H[key]
  if si==0:
   fragments=[[(74,.5),(77,.5),(81,1),(-1,.5),(77,.5),(76,.5),(77,.5)],[(74,1),(77,.5),(82,.5),(81,.5),(79,.5),(77,1)],[(81,.5),(84,.5),(81,1),(79,.5),(77,.5),(76,.5),(77,.5)],[(76,1),(79,.5),(84,.5),(83,.5),(81,.5),(79,.5),(-1,.5)]];line=fragments[j]
  else:line=copy.deepcopy(A[j] if si==1 else D[j] if si==2 else BR[j] if si==3 else A[j])
  if si==4 and j in (1,3,5):
   # Three genuinely new answers in the return, leading toward the ending.
   line={1:[(82,1),(81,.5),(77,.5),(74,.5),(77,.5),(82,1)],3:[(84,1),(79,.5),(76,.5),(79,1),(83,.5),(84,.5)],5:[(86,1),(89,.5),(86,.5),(84,.5),(82,.5),(81,.5),(82,.5)]}[j]
  if si==4 and j==7:line=[(86,1.5),(81,.5),(77,.5),(74,1.5)]
  assert sum(d for _,d in line)==4,(si,j)
  bpm=144 if barno<35 else (138 if barno==35 else 128)
  bars.append(dict(bar=barno,start=beat,beats=4,bpm=bpm,section=title,harmony_name=key,harmony=ch))
  off=0
  for k,(n,dur) in enumerate(line):
   if n>=0:notes.append(dict(bar=barno,onset=beat+off,duration=dur*.95,pitch=n,velocity=[68,83,90,85,96][si],voice='melody'))
   off+=dur
  # Stable left-hand support: one root and coordinated harmonic pulse, no second competing theme.
  rootdur=3.72 if si!=3 else 1.8
  notes.append(dict(bar=barno,onset=beat,duration=rootdur,pitch=ch[0],velocity=[42,53,58,53,65][si],voice='bass'))
  arp=[ch[1],ch[2],ch[3],ch[2],ch[1],ch[2],ch[3]]
  for k,n in enumerate(arp):
   onset=.5+k*.5
   # The same phrase-ending breath is respected by both hands.
   if j==count-1 and onset>=3.5 and si!=4:continue
   notes.append(dict(bar=barno,onset=beat+onset,duration=.43,pitch=n,velocity=[37,44,48,43,54][si]+(2 if k%2==0 else 0),voice='accompaniment'))
  if si==4 and j in (0,4):
   # Under the lead's accented downbeat, a quiet chord supports the common arrival.
   for n in ch[1:]:notes.append(dict(bar=barno,onset=beat+.015,duration=.8,pitch=n,velocity=49,voice='arrival_chord'))
  pedals += [dict(onset=beat,value=0),dict(onset=beat+.12,value=58),dict(onset=beat+1.95,value=0),dict(onset=beat+2.08,value=48),dict(onset=beat+3.85,value=0)]
  beat+=4
score=dict(id=52,title='The Clockmaker’s Borrowed Tide',title_zh='向潮水借来的钟',stage='direction_v0',purpose='Original60-second direction segment, not completed full composition',bars=bars,events=notes,pedals=pedals,total_beats=beat,tail_seconds=3)
(P/'revisions/score_v0.json').write_text(json.dumps(score,indent=2));
# Formal review1: ensure accompaniment yields to melody and harmonic arrival.
v=copy.deepcopy(score);v['stage']='direction_v1_coordinated_phrasing';issues=[]
by=collections.defaultdict(list)
for e in v['events']:by[e['pitch']].append(e)
for pitch,es in by.items():
 es.sort(key=lambda e:e['onset'])
 for a,b in zip(es,es[1:]):
  if a['onset']+a['duration']>b['onset']:
   a['duration']=max(.04,b['onset']-a['onset']-.03);issues.append({'pitch':pitch,'bar':b['bar'],'change':'release common key before its coordinated next strike'})
for e in v['events']:
 b=v['bars'][e['bar']-1];pos=e['onset']-b['start']
 if e['voice']=='melody':
  e['velocity']+=3 if pos==0 else (1 if pos==2 else -3)
  # Avoid per-note gaps within sung phrases; only intentional phrase ends breathe.
  e['duration']/=.95;e['duration']*=.985 if e['duration']<1.5 else .95
 if e['voice']=='bass' and b['bar']%4==0:e['velocity']-=4
 if e['voice']=='accompaniment' and pos>=3:e['velocity']-=3
 # Bridge is an intentional dynamic pullback before a collective rise.
 if b['section']=='The harbor opens':e['velocity']+=int((b['bar']-21)*.8)-7
 e['velocity']=max(25,min(106,e['velocity']))
# Last final sonority breathes; stop the accompaniment rather than continue automatic movement.
v['events']=[e for e in v['events'] if not(e['bar']==36 and e['voice']=='accompaniment' and e['onset']-140>2)]
for e in v['events']:
 if e['bar']==36 and e['voice']=='bass':e['duration']=5
v['pedals']=[e for e in v['pedals'] if e['onset']<140]+[dict(onset=140,value=0),dict(onset=140.12,value=65),dict(onset=147,value=0)]
(P/'revisions/score_v1.json').write_text(json.dumps(v,indent=2));(P/'score.json').write_text(json.dumps(v,indent=2))
review={'pass':1,'musical_goal':'A memorable lead and accompanying bass share harmony, pulse, phrase direction and cadences.','same_key_issues_corrected':issues,'changes':['Main melody lengthened inside phrases instead of isolated high notes.','Bass and accompaniment share phrase-ending breaths and yield under the sung line.','Bridge dynamically pulls back then grows toward the return; not just uniformly louder.','Last bar stops automatic arpeggios and arrives with the melody.'],'duration_seconds':sum(b['beats']*60/b['bpm'] for b in bars)+3,'narrative':'The harbor departure scene, in which the borrowed tide and clock first move together.'}
(P/'revisions/pass1.json').write_text(json.dumps(review,indent=2));
# Harmony relationship map is inspectable; important beats identify chord tones or intentional approach notes.
relations=[]
for b in bars:
 melody=[e for e in v['events'] if e['bar']==b['bar'] and e['voice']=='melody'];pcs={n%12 for n in b['harmony']};down=next(e for e in melody if abs(e['onset']-b['start'])<.1);relations.append({'bar':b['bar'],'harmony':b['harmony_name'],'bass_root':b['harmony'][0],'melody_downbeat':down['pitch'],'downbeat_is_chord_tone':down['pitch']%12 in pcs,'phrase_end':b['bar'] in [4,12,20,28,36]})
(P/'main_accompaniment_relationship.json').write_text(json.dumps(relations,indent=2));print('Duration',review['duration_seconds'],'nonchord downbeats',[r for r in relations if not r['downbeat_is_chord_tone']]);print('Notes',len(v['events']))
