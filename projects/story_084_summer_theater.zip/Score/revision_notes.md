# Two substantive revisions

All three versions are complete 144-bar scores. The revisions alter composition and the division of playing roles, not merely loudness or pedal.

## v0 → v1: move the performance toward the snow

**Bars 41–48:** v0 repeats the opening F-major sentence and closes on F. v1 replaces the whole sentence: Dm–C/E–F–F/A–Bb–Gm–C7–C7, a rising melody with new shorter subdivisions, an earned C6 apex, and an open dominant. The performers are now reacting to the shrinking audience instead of simply completing another opening loop. The actual harmonic direction prepares the D-minor scene.

**Bars 65–72:** v0 repeats the D-minor statement and stops on Dm. v1 retains the recognizable minor head, then writes a new F#5–E5–D5 turn over D7, proceeding through Gm–C7–F7 to Bb. This is the bridge that allows the lowered stage action to begin in B-flat without sounding like an inserted sketch.

**Bars 73–96:** v0 has the melody above the left-hand broken figures. v1 moves the melodic line down one octave to the left hand and rewrites the accompaniment as quiet right-hand dyads and tones. Bar 96 hands its final melodic G4 back to the right hand, so the left hand can travel to F2 in time for bar 97. This is a structural change of register and responsibility throughout an entire scene.

Exact changed bars: 41–48 and 66–96. Bar 65 retains the minor head unchanged. The exact previous and replacement bar data, note events, and pedal events appear in diff_v0_v1.json.

## v1 → v2: shorten the show in the composition itself

**Bars 105–112:** v1 is another high statement of the original F-major phrase. v2 writes a downward-folding answer beginning in D minor, using A7 and the renewed C/E–F path, then Bb–Gm–C7. Shorter subdivisions carry the dancer from the started large gesture into the smaller one. Both melody and harmony change.

**Bars 113–120:** v1 uses the opening scene's second sentence in its original leisurely direction. v2 recalls the small theme immediately, moves through D minor, and makes the would-be F cadence fall on Dm in bar 119. C7 in bar 120 reopens the ending. The tempo also yields four BPM in these eight bars. The canceled circuit has a form-level effect: the high-register development ends early.

**Bars 129–136:** v1 states the full opening melody again. v2 condenses its head into three bars and supplies a five-bar response. F–Bb/F–F/A moves the support differently under the familiar gesture, and Dm–Gm–C7–F/C–C7 keeps the bow preparation unresolved.

**Bars 137–144:** v1 repeats the opening sentence once more. v2 composes a new final sentence, F6–Bb/F–F/A–Gm–C7sus–C7–F–F, with a rise to F5 and a specific descending bow. F4 arrives in bar 143 and remains the last melodic note in bar 144. This supplies a complete consequence to the earlier interruptions.

Exact changed bars: 105–120 and 129–143. Bar 144 retains the shared final chord unchanged. The exact previous and replacement bar data, note events, and pedal events appear in diff_v1_v2.json.

## Physical correction found by the audit

The first generated left-hand scene tried to leave G4 late in bar 96 and attack F2 at the next bar, with only about 0.05 seconds of released time. That was rejected. The final G4 is now assigned to the right hand. The left hand releases its E4 earlier, and the new low entrance has a real preparation interval. This correction is included in both handed-over versions, v1 and v2; it is not disguised by pedal or described as an impossible span.

## Verification scope

All three delivered versions pass the symbolic audits. No audio was produced or auditioned by this worker. The meaningful differences are documented above and preserved exactly in JSON rather than described as changes that did not occur. Original melodic material is authored in generate.py; no prior work's theme was imported.
