from pathlib import Path
import aifc,numpy as np,json,math,hashlib
P=Path(__file__).parent;out=[]
def pitch(y,sr,center):
 lo=round((center-.06)*sr);hi=round((center+.06)*sr);x=y[lo:hi].astype(float);x-=x.mean();w=np.hanning(len(x));n=1<<(2*len(x)-1).bit_length();f=np.fft.rfft(x*w,n);ac=np.fft.irfft(f*f.conj(),n);wf=np.fft.rfft(w,n);overlap=np.fft.irfft(wf*wf.conj(),n);ac=ac[:500]/np.maximum(overlap[:500],1e-12);ac/=ac[0]
 lower=int(sr/260);upper=int(sr/138);peaks=[k for k in range(lower+1,upper) if ac[k-1]<ac[k]>=ac[k+1]];assert peaks;best=max(ac[k] for k in peaks);candidates=[k for k in peaks if ac[k]>=.92*best and ac[k]>.35];assert candidates;k=max(candidates,key=lambda k:ac[k]);delta=.5*(ac[k-1]-ac[k+1])/(ac[k-1]-2*ac[k]+ac[k+1]);hz=sr/(k+delta);midi=69+12*math.log2(hz/440);return {'hz':hz,'midi_float':midi,'nearest_midi':round(midi),'periodicity':float(ac[k]),'center_seconds':center}
for layer in ['pp','mf']:
 f=P/f'Cello.arco.{layer}.sulD.D3B3.aiff'
 with aifc.open(str(f),'rb') as w:
  sr=w.getframerate();ch=w.getnchannels();sw=w.getsampwidth();raw=w.readframes(w.getnframes())
 assert sr==44100 and ch==1 and sw==2;y=np.frombuffer(raw,dtype='>i2').astype(np.float32)/32768;hop=441;blocks=np.pad(y,(0,(-len(y))%hop)).reshape(-1,hop);rms=np.std(blocks,axis=1);noise=float(np.quantile(rms,.15));threshold=max(float(rms.max())*.025,noise*8,.00004);mask=rms>threshold;spans=[];start=last=None
 for i,v in enumerate(mask):
  if v:
   if start is None:start=i
   last=i
  elif start is not None and i-last>=12:
   if last-start>=25:spans.append((start*hop,(last+1)*hop))
   start=last=None
 if start is not None and last-start>=25:spans.append((start*hop,min(len(y),(last+1)*hop)))
 assert len(spans)==10,(layer,len(spans),spans)
 notes=[]
 for j,(lo,hi) in enumerate(spans):
  expected=50+j;dur=(hi-lo)/sr;print('segment',layer,expected,lo/sr,hi/sr,flush=True);measure=[pitch(y,sr,lo/sr+dur*x) for x in [.2,.5,.8]];assert all(abs(x['midi_float']-expected)<1.2 for x in measure),(layer,expected,measure)
  center=float(np.mean([x['midi_float'] for x in measure]));cents=(center-expected)*100
  voiced=None
  for t in np.arange(lo/sr+.07,min(hi/sr-.07,lo/sr+.7),.01):
   try:q=pitch(y,sr,float(t))
   except AssertionError:continue
   if abs(q['midi_float']-expected)<1.2 and q['periodicity']>.55:voiced=float(t);break
  assert voiced is not None
  notes.append({'midi':expected,'active_start_frame':lo,'active_end_frame':hi,'active_seconds':dur,'pitch_windows':measure,'center_deviation_cents':cents,'window_center_spread_cents':(max(x['midi_float'] for x in measure)-min(x['midi_float'] for x in measure))*100,'coarse_voiced_start_frame':round(voiced*sr)})
 out.append({'layer':layer,'source_file':f.name,'source_sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'sample_rate':sr,'channels':ch,'bits':sw*8,'duration_seconds':len(y)/sr,'noise_rms':noise,'segmentation_threshold':threshold,'detected_notes':10,'notes':notes});print(layer,'durations',[round(n['active_seconds'],2) for n in notes],'cents',[round(n['center_deviation_cents'],1) for n in notes])
(P/'scale_analysis.json').write_text(json.dumps(out,indent=2))
