"""Original flowing6/8 piano ballad. The two bank themes share harmonic goals and cadence shape."""
import pathlib,json,copy
P=pathlib.Path(__file__).parent
A=[[(74,.75),(73,.25),(71,.5),(66,.5),(69,.5),(71,.5)],[(74,1),(71,.5),(67,.5),(69,.5),(71,.5)],[(66,.5),(69,.5),(74,.5),(76,.5),(78,1)],[(76,1),(73,.5),(71,.5),(69,.5),(-1,.5)],[(67,.5),(71,.5),(76,1),(74,.5),(71,.5)],[(78,.75),(76,.25),(74,.5),(71,.5),(69,.5),(66,.5)],[(70,.5),(73,.5),(76,.5),(78,.5),(76,.5),(73,.5)],[(74,.5),(73,.5),(71,1.5),(-1,.5)]]
A2=[[(78,.5),(76,.5),(74,1),(73,.5),(71,.5)],[(79,.75),(78,.25),(74,.5),(71,.5),(74,.5),(79,.5)],[(81,1),(78,.5),(76,.5),(74,1)],[(76,1),(73,.5),(76,.5),(81,.5),(-1,.5)],[(83,.5),(81,.5),(79,1),(76,.5),(74,.5)],[(78,1),(74,.5),(71,.5),(66,.5),(69,.5)],[(73,.75),(70,.25),(66,.5),(70,.5),(73,.5),(76,.5)],[(74,.5),(73,.5),(71,1.5),(-1,.5)]]
B=[[(71,.5),(74,.5),(79,1),(78,.5),(74,.5)],[(78,.75),(76,.25),(74,.5),(69,.5),(71,.5),(73,.5)],[(79,1),(76,.5),(74,.5),(71,1)],[(76,1),(73,.5),(70,.5),(66,1)],[(71,.5),(74,.5),(78,1),(76,.5),(74,.5)],[(74,.75),(71,.25),(67,.5),(71,.5),(74,.5),(79,.5)],[(79,.5),(76,.5),(71,.5),(70,.5),(73,.5),(76,.5)],[(74,1),(71,.5),(73,.5),(74,.5),(71,.5)]]
B2=[[(79,1),(78,.5),(74,.5),(71,.5),(74,.5)],[(78,.5),(81,.5),(86,1),(83,.5),(81,.5)],[(79,1.5),(76,.5),(74,1)],[(78,.5),(76,.5),(73,1),(70,.5),(-1,.5)],[(74,.75),(78,.25),(83,1),(81,.5),(78,.5)],[(79,.5),(78,.5),(74,1),(71,.5),(67,.5)],[(71,.5),(76,.5),(79,.5),(78,.5),(76,.5),(73,.5)],[(74,1),(73,.5),(71,1),(-1,.5)]]
C=[[(78,.5),(81,.5),(83,.5),(81,.5),(78,.5),(74,.5)],[(79,.5),(83,.5),(86,.5),(83,.5),(81,.5),(79,.5)],[(78,.5),(81,.5),(86,1),(84,.5),(81,.5)],[(85,.5),(83,.5),(81,.5),(76,.5),(73,.5),(76,.5)],[(79,.5),(83,.5),(86,.5),(83,.5),(79,.5),(76,.5)],[(78,1),(76,.5),(74,.5),(71,1)],[(82,.5),(80,.5),(78,.5),(76,.5),(73,.5),(70,.5)],[(83,.5),(81,.5),(78,.5),(74,.5),(73,.5),(-1,.5)]]
CODA=[[(74,1),(71,.5),(67,.5),(69,.5),(71,.5)],[(78,.5),(76,.5),(74,1),(69,1)],[(76,1),(74,.5),(71,.5),(67,1)],[(73,1),(70,.5),(66,1),(-1,.5)],[(71,.5),(74,.5),(78,1),(74,.5),(71,.5)],[(74,1),(71,.5),(67,.5),(71,1)],[(70,.5),(73,.5),(76,.5),(78,.5),(73,.5),(-1,.5)],[(74,.5),(73,.5),(71,1.5),(-1,.5)]]
H={'Bm':[47,54,59,62],'G':[43,55,59,62],'DA':[45,54,57,62],'A9':[45,52,59,61],'Em7':[40,55,59,62],'BmD':[50,54,59,62],'Fs7':[42,52,58,61],'DFs':[42,54,57,62],'Bopen':[47,54,59,61]};home=['Bm','G','DA','A9','Em7','BmD','Fs7','Bm'];west=['G','DFs','Em7','Fs7','Bm','G','Em7_Fs7','Bm'];coda=['G','DA','Em7','Fs7','Bm','G','Fs7','Bopen']
sections=[('Snow on the last pier',4,84,'intro'),('Letters for the east bank',16,88,'east'),('Across the unlit river',16,96,'current'),('Letters for the west bank',16,82,'west'),('A name in the pocket',16,92,'snow'),('One boat, both shores',16,88,'reunion'),('The coat stays aboard',8,80,'coda')]
notes=[];bars=[];pedals=[];beat=0;barno=0
for section,count,tempo,kind in sections:
 for j in range(count):
  barno+=1;k=j%8
  if kind=='intro':line=copy.deepcopy(A[k]);prog=home
  elif kind=='east':line=copy.deepcopy(A[k] if j<8 else A2[k]);prog=home
  elif kind=='current':line=copy.deepcopy(C[k] if j<8 else A2[k]);prog=home
  elif kind=='west':line=copy.deepcopy(B[k] if j<8 else B2[k]);prog=west
  elif kind=='snow':line=copy.deepcopy(A2[k] if j<8 else C[k]);prog=home
  elif kind=='reunion':line=copy.deepcopy(B2[k] if j<8 else A[k]);prog=west if j<8 else home
  else:line=copy.deepcopy(CODA[k]);prog=coda
  assert abs(sum(d for n,d in line)-3)<1e-8,(kind,j,line)
  hname=prog[k];split=hname=='Em7_Fs7';ch=H['Em7' if split else hname];ch2=H['Fs7'] if split else ch;bpm=tempo
  if kind=='coda' and j>=5:bpm=[76,70,64][j-5]
  if j==count-1 and kind!='coda':bpm-=4
  bars.append(dict(bar=barno,start=beat,beats=3,bpm=bpm,meter_numerator=6,meter_denominator=8,section=section,harmony_name=hname,harmony=ch,harmony_change_beat=1.5 if split else None,role_plan=kind))
  lv={'intro':61,'east':71,'current':81,'west':68,'snow':83,'reunion':77,'coda':63}[kind]
  if kind=='intro':lv+=j*2
  if kind=='coda':lv-=j
  off=0
  for n,l in line:
   if n>=0:notes.append(dict(bar=barno,onset=beat+off,duration=l*.982,pitch=n,velocity=lv+(3 if off in (0,1.5) else 0),voice='melody'))
   off+=l
  bv={'intro':39,'east':44,'current':49,'west':40,'snow':48,'reunion':45,'coda':35}[kind]
  notes.append(dict(bar=barno,onset=beat,duration=.32,pitch=ch[0],velocity=bv,voice='bass'))
  second_bass=ch2[0]+12 if split else ch[1]
  notes.append(dict(bar=barno,onset=beat+1.5,duration=.28,pitch=second_bass,velocity=bv-5,voice='bass'))
  # Paired dotted-quarter pulses anchor the same harmony as the sung line.
  pattern=[(.5,ch[1]),(1,ch[2]),(2,ch2[3]),(2.5,ch2[2])]
  for t,n in pattern:
   if k==7 and t>=2.5:continue
   if kind=='coda' and j==7 and t>=2:continue
   notes.append(dict(bar=barno,onset=beat+t,duration=.42,pitch=n,velocity=bv-9,voice='accompaniment'))
  if kind=='reunion' and j in (0,4,8,12):
   e=next(e for e in notes if e['bar']==barno and e['voice']=='melody');q=copy.deepcopy(e);q.update(pitch=e['pitch']-12,velocity=e['velocity']-20,voice='melody_octave');notes.append(q)
  pedals.extend([dict(onset=beat,value=0),dict(onset=beat+.10,value=52),dict(onset=beat+1.44,value=0),dict(onset=beat+1.60,value=46),dict(onset=beat+2.86,value=0)])
  beat+=3
pedals=[e for e in pedals if e['onset']<beat-3]+[dict(onset=beat-3,value=0),dict(onset=beat-2.9,value=63),dict(onset=beat+2,value=0)]
d=dict(id=54,title='The Last Ferry Carries Snow',title_zh='末班渡船载着雪',stage='v0_original_flowing_ballad',bars=bars,events=notes,pedals=pedals,total_beats=beat,tail_seconds=4.2,story_relationship='Two bank themes are related questions and answers, supported by the same rocking harmonic pulse. Their cadence shapes converge when the letters cross the river. Piano-only production; no violin sample is claimed.')
(P/'revisions/score_v0.json').write_text(json.dumps(d,indent=2));(P/'score.json').write_text(json.dumps(d,indent=2));(P/'thematic_material.json').write_text(json.dumps({'east_A':A,'east_answer_A2':A2,'west_B':B,'west_answer_B2':B2,'current_development_C':C,'new_coda':CODA},indent=2));print('54 draft',len(bars),'bars',sum(b['beats']*60/b['bpm']for b in bars)+4.2,'seconds')
