The River’s Second Alphabet / 河流的第二套字母 — v5
原创完整器乐作品与虚构故事。未声称真人演奏或完整人工听审。

FULL包：打开 077_river_alphabet_v5.rpp，Media/ 已含实际 float32 音频轨，能直接在 REAPER 播放与导出；有房间效果时使用工程内的 REAPER 自带效果。输出至相对 Renders/。这是独立音频轨工程，另附可编辑 MIDI/事件乐谱，不是把完整外部采样器和音库内嵌的 MIDI 工程。

COMPACT包：没有 Media 音频与试听 MP3，不能直接播放。更改乐谱后，需原始外部音库、已有兼容 sfizz、Python及NumPy。阅读 Tools/SafeRegeneration/README.md，使用 regenerate.py，按 Score/RenderInputs/manifest.json 指定精确JSON乐谱、原始完整SFZ、模式、details开关及明确内存预算。新乐谱必须重新检查原生音符覆盖；不能沿用旧裁剪映射。MIDI编辑也需先同步为JSON乐谱。

真实音源署名、原始采样精度、许可及映射见 InstrumentMapping/ 与 metadata.json。共享采样数据和软件二进制未重复打入此包，也不自动下载或安装。Iowa小音库如有，仍需另行取得对应派生样本和映射；未声称真连奏。

独立完整音源参考比对、原生REAPER设置核对和便携工程完整PCM比对是三个不同验收。仅同PCM不能证明音源完整。详见 Audit/。History/SymbolicDraftNotes 保留的是作曲阶段记录，早于后续真实渲染。

故事全文：story_zh.txt。曲式与修订说明：MUSIC_AND_FORM_ZH.txt。修订与方向短段不计作新增作品。
