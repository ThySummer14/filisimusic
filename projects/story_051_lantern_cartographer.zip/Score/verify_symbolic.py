#!/usr/bin/env python3
"""Independent symbolic/MIDI round-trip checks. Does not invoke any renderer."""
from pathlib import Path
from collections import Counter
import hashlib, importlib.util, json, struct, sys

sys.dont_write_bytecode=True

P=Path(__file__).resolve().parent

def read_vlq(data,pos):
    value=0
    while True:
        n=data[pos];pos+=1;value=(value<<7)|(n&127)
        if not n&128:return value,pos

def read_midi(path):
    data=path.read_bytes()
    assert data[:4]==b'MThd'
    length,fmt,count,ppq=struct.unpack('>IHHH',data[4:14])
    assert (length,fmt,count,ppq)==(6,1,2,960)
    pos=14;out=[]
    for track in range(count):
        assert data[pos:pos+4]==b'MTrk'
        size=struct.unpack('>I',data[pos+4:pos+8])[0]
        chunk=data[pos+8:pos+8+size];pos+=8+size
        t=0;i=0;running=None;messages=[]
        while i<len(chunk):
            delta,i=read_vlq(chunk,i);t+=delta
            status=chunk[i]
            if status&128:i+=1
            else:status=running
            assert status is not None
            if status==255:
                kind=chunk[i];i+=1;size,i=read_vlq(chunk,i)
                payload=chunk[i:i+size];i+=size
                messages.append((t,'meta',kind,list(payload)))
                if kind==47:assert i==len(chunk)
                continue
            running=status
            n=1 if status&240 in (192,208) else 2
            payload=list(chunk[i:i+n]);i+=n
            messages.append((t,status,payload))
        out.append(messages)
    assert pos==len(data)
    return out

def main():
    spec=importlib.util.spec_from_file_location('lantern_composer',P/'compose_full.py')
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    reports={}
    for version in ('v6a','v6b','v6c'):
        score=json.loads((P/f'score_{version}.json').read_text())
        assert score==module.make_score(version),'Generator is not reproducible'
        meta,notes=read_midi(P/f'051_full_{version}.mid')
        ons=Counter((m[0],m[2][0],m[2][1]) for m in notes if m[1]==144)
        offs=Counter((m[0],m[2][0]) for m in notes if m[1]==128)
        cc64=[(m[0],m[2][1]) for m in notes if m[1]==176 and m[2][0]==64]
        expected_on=Counter((round(e['onset']*960),e['pitch'],e['velocity']) for e in score['events'])
        expected_off=Counter((round((e['onset']+e['duration'])*960),e['pitch']) for e in score['events'])
        assert ons==expected_on and offs==expected_off
        assert cc64==[(round(e['onset']*960),e['value']) for e in score['pedals']]
        actual_tempos=[(m[0],int.from_bytes(bytes(m[3]),'big')) for m in meta if m[1]=='meta' and m[2]==81]
        expected_tempos=[(round(b['start']*960),round(60000000/b['bpm'])) for b in score['bars']]
        assert actual_tempos==expected_tempos
        meters=[(m[0],m[3][0],2**m[3][1]) for m in meta if m[1]=='meta' and m[2]==88]
        assert meters==[(0,5,4),(280*960,4,4)]
        initial_cc={m[2][0]:m[2][1] for m in notes if m[0]==0 and m[1]==176}
        expected_cc={7:100,10:64,20:62,21:20,22:18,23:50,24:0,64:0,72:0,90:0,99:0}
        assert initial_cc==expected_cc
        # Equal-tick MIDI note offs must precede pedal changes and note ons.
        order={128:0,176:1,144:2}
        groups={}
        for m in notes:
            if m[0]>0 and m[1] in order:groups.setdefault(m[0],[]).append(order[m[1]])
        assert all(v==sorted(v) for v in groups.values())
        held=set()
        for m in notes:
            if m[1]==144:
                assert m[2][0] not in held,('MIDI overlapping key',m)
                held.add(m[2][0])
            elif m[1]==128:
                assert m[2][0] in held,('MIDI unmatched note-off',m)
                held.remove(m[2][0])
        assert not held
        assert all(m[1]!='meta' or m[2]!=47 or not held for m in notes)
        quant_error=max(abs(round(v*960)/960-v) for e in score['events'] for v in [e['onset'],e['onset']+e['duration']])
        reports[version]={'score_reproduction_exact':True,'notes_roundtrip_exact_after_ppq_quantization':True,
            'cc64_roundtrip_exact':True,'tempo_map_roundtrip_exact':True,'initial_cc':initial_cc,
            'meters':meters,'note_count':sum(ons.values()),'no_stuck_or_overlapping_midi_keys':True,
            'max_note_time_quantization_error_beats':quant_error,'symbolic_qa':module.qa(score)}
    # Verify the exact per-bar change sets contain the actual complete before/after.
    for a,b in [('v6a','v6b'),('v6b','v6c')]:
        x=json.loads((P/f'exact_diff_{a}_to_{b}.json').read_text())
        assert x==module.exact_diff(module.make_score(a),module.make_score(b))
    assert (P/'score.json').read_bytes()==(P/'score_v6c.json').read_bytes()
    provenance=json.loads((P/'source_provenance.json').read_text())
    for item in provenance['read_only_inputs']:
        assert hashlib.sha256(Path(item['path']).read_bytes()).hexdigest()==item['sha256']
    result={'result':'PASS','render_or_audio_process_invoked':False,'source_inputs_match_recorded_hashes':True,
            'exact_revision_diffs_verified':True,'score_alias_matches_v6c':True,'versions':reports,
            'limits':'No audio was generated or auditioned. These checks cannot certify melodic appeal, perceived cooperation, acoustic balance, or human fingering.'}
    (P/'verification_report.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print('PASS: all three complete scores reproduce exactly; MIDI notes, tempo, meter and CC round-trip; source input hashes match.')

if __name__=='__main__':main()
