#!/usr/bin/env python3
"""#051 full symbolic rewrite. Standard library only; never renders or installs.

Run from any directory. Writes only beside this script. v6a, v6b and v6c are
complete scores, not excerpts. No randomization. MIDI uses the source engine's
off -> CC -> on ordering and its exact tempo-map interpretation.
"""
from pathlib import Path
from collections import Counter, defaultdict
from copy import deepcopy
import bisect, difflib, hashlib, json, math, struct

P = Path(__file__).resolve().parent

def line(s):
    """Compact, auditable MIDI-pitch:quarter-note-duration melody notation."""
    return [(int(n), float(d)) for token in s.split() for n, d in [token.split(':')]]

# #051's own v5 thematic study, preserved deliberately. Its characteristic
# A-Bb-F opening is a semitone followed by a perfect fifth. This is not #052.
A = list(map(line, [
    '69:.5 70:.5 77:1.5 76:.5 74:1 72:1',
    '74:1 72:.5 70:.5 69:1 67:1 65:1',
    '69:.5 72:.5 77:2 76:.5 74:.5 72:1',
    '76:1.5 74:.5 72:1 67:1 -1:1',
    '74:.5 77:.5 79:1.5 77:.5 74:1 70:1',
    '77:1 76:.5 74:.5 72:1 69:1 65:1',
    '73:.5 76:.5 79:1 76:1 73:.5 70:.5 69:1',
    '74:1.5 72:.5 69:1 74:1.5 -1:.5',
]))
REFLECTION = list(map(line, [
    '69:.5 70:.5 77:1 76:.5 74:.5 72:1 74:1',
    '77:1 74:.5 72:.5 70:1 69:1 67:1',
    '72:1 74:.5 76:.5 77:1.5 76:.5 72:1',
    '76:.5 79:.5 81:1 79:1 76:1 72:.5 -1:.5',
    '74:1 77:.5 79:.5 82:1 79:1 77:1',
    '77:1 76:.5 74:.5 72:1 69:1 65:1',
    '76:.5 73:.5 70:1 69:1 73:1 76:1',
    '74:1 72:.5 69:.5 65:1 69:1 73:.5 -1:.5',
]))
BRIGHT = list(map(line, [
    '69:.5 70:.5 77:1 76:.5 77:.5 81:1 77:1',
    '74:.5 75:.5 82:1 81:.5 79:.5 77:1 74:1',
    '79:.5 77:.5 74:1 70:.5 74:.5 77:1 79:1',
    '76:.5 77:.5 82:1 79:1 77:.5 76:.5 74:1',
    '73:.5 76:.5 79:1 82:.5 81:.5 79:1 76:1',
    '78:.5 79:.5 86:1 84:.5 81:.5 78:1 74:1',
    '82:1 81:.5 79:.5 77:1 74:1 70:1',
    '76:.5 73:.5 70:1 69:1 73:.5 76:.5 -1:1',
]))
# The original v4 D-Eb-Bb fingerprint is restored in a harmonically supported
# tenor phrase: Bb/D makes Bb a chord member, with Eb a brief neighbour.
DARK = list(map(line, [
    '50:.5 51:.5 58:1.5 57:.5 55:1 53:1',
    '55:1 53:.5 51:.5 50:1 53:1 58:1',
    '62:1 60:.5 58:.5 57:1 55:1 53:1',
    '52:1 55:.5 57:.5 61:1 58:.5 57:.5 52:.5 -1:.5',
    '50:1 53:.5 57:.5 58:1 57:1 53:1',
    '55:.5 57:.5 58:1 62:1 60:1 58:1',
    '55:1 52:1 49:1 52:.5 55:.5 57:1',
    '50:2 53:1 57:1 60:.5 -1:.5',
]))
COURT = list(map(line, [
    '65:1 69:.5 72:.5 74:1 72:1 69:1',
    '70:1 69:.5 67:.5 65:1 62:1 65:1',
    '67:.5 69:.5 72:1.5 74:.5 76:1 72:1',
    '74:1 72:.5 70:.5 69:1 67:1 64:.5 -1:.5',
    '65:.5 67:.5 69:1 72:1 77:1 76:1',
    '74:1 72:.5 70:.5 69:1 65:1 67:1',
    '70:1 69:1 67:.5 65:.5 64:1 67:1',
    '69:1.5 67:.5 65:2 69:.5 -1:.5',
]))
RETURN = list(map(line, [
    '69:.5 70:.5 77:1.5 76:.5 74:1 72:1',
    '74:1 72:.5 70:.5 69:1 67:1 65:1',
    '69:1 72:.5 77:.5 79:1 77:1 74:1',
    '76:1 74:.5 72:.5 67:1 69:1 72:.5 -1:.5',
    '74:1 77:.5 79:.5 77:1 74:1 70:1',
    '69:1 72:.5 74:.5 77:1 76:1 74:1',
    '73:1 76:.5 79:.5 76:1 73:1 69:1',
    '74:2 72:.5 69:.5 65:1 69:.5 -1:.5',
]))
JOINED = list(map(line, [
    '77:1 81:.5 84:.5 81:1 79:1 77:1',
    '82:1 81:.5 79:.5 77:1 74:1 70:1',
    '77:.5 79:.5 81:1.5 79:.5 77:1 74:1',
    '79:1 76:.5 74:.5 72:1 76:1 79:.5 -1:.5',
    '79:1 77:.5 74:.5 70:1 74:1 77:1',
    '77:1 74:.5 72:.5 70:1 69:1 65:1',
    '76:.5 79:.5 81:1 79:.5 76:.5 73:1 69:1',
    '74:1.5 77:.5 76:1 74:1.5 -1:.5',
]))
CODA = list(map(line, [
    '69:.5 70:.5 77:1 74:1 72:1',
    '74:1 72:.5 70:.5 69:1 65:1',
    '67:.5 69:.5 74:1 72:1 70:1',
    '69:1 67:.5 65:.5 64:1 61:1',
    '62:.5 63:.5 70:1 69:1 65:.5 -1:.5',
    '67:1 65:.5 64:.5 62:1 61:1',
    '64:1 67:.5 69:.5 73:1 76:.75 -1:.25',
    '74:3 -1:1',
]))

# A complete earlier draft and two substantive composed revisions are retained.
COURT_A = list(map(line, [
    '69:.5 70:.5 77:1.5 76:.5 72:1 69:1',
    '74:1 72:.5 70:.5 69:1 67:1 65:1',
    '69:.5 72:.5 77:2 76:.5 74:.5 72:1',
    '76:1.5 74:.5 72:1 67:1 -1:1',
    '72:.5 77:.5 79:1.5 77:.5 74:1 72:1',
    '77:1 76:.5 74:.5 72:1 69:1 65:1',
    '76:1 74:1 72:1 67:1 64:1',
    '65:1.5 67:.5 69:1 65:1.5 -1:.5',
]))
JOINED_C = list(map(line, [
    '69:.5 70:.5 77:1 79:1 81:1 77:1',
    '74:1 77:.5 82:.5 81:1 77:1 74:1',
    '77:1 81:.5 84:.5 86:1 84:1 81:1',
    '79:1 76:.5 74:.5 72:1 76:1 79:.5 -1:.5',
    '79:.5 77:.5 74:1 70:1 74:1 77:1',
    '77:1.5 74:.5 72:1 70:1 69:1',
    '76:1 73:.5 70:.5 69:1 73:1 76:1',
    '77:1 76:.5 74:.5 72:1 69:.5 74:1 -1:.5',
]))
CODA_C = list(map(line, [
    '69:.5 70:.5 77:1.5 74:.5 72:1',
    '74:1 72:.5 70:.5 69:1 65:1',
    '67:.5 69:.5 74:1.5 72:.5 70:1',
    '69:1 67:.5 65:.5 64:1 61:1',
    '62:.5 63:.5 70:1.5 69:.5 65:1',
    '67:1 65:.5 64:.5 62:1 60:.5 -1:.5',
    '64:1 62:.5 61:.5 64:1 69:.75 -1:.25',
    '74:3 -1:1',
]))

# arp is a single-hand route; block is a compact left-hand chord; upper is
# exclusively right-hand accompaniment while the left hand carries the tune.
H = {
 'Dm':    ([38,45,50,53,57], [50,53,57], [69,74,77]),
 'Bb':    ([46,53,58,62,65], [50,53,58], [70,74,77]),
 'F/A':   ([45,48,53,57,60], [53,57,60], [69,72,77]),
 'F':     ([41,48,53,57,60], [53,57,60], [69,72,77]),
 'F/C':   ([48,53,57,60,65], [53,57,60], [69,72,77]),
 'C':     ([48,55,60,64,67], [52,55,60], [67,72,76]),
 'C/E':   ([40,48,52,55,60], [52,55,60], [67,72,76]),
 'Gm':    ([43,50,55,58,62], [50,55,58], [67,70,74]),
 'Dm/F':  ([41,45,50,53,57], [50,53,57], [69,74,77]),
 'A7':    ([45,52,57,61,67], [49,52,55], [67,73,76]),
 'A7sus': ([45,52,57,62,67], [50,52,55], [67,74,76]),
 'Eø':    ([40,46,52,55,58], [50,55,58], [67,70,74]),
 'D7/F#': ([42,50,54,57,60], [50,54,60], [69,72,78]),
 'Bb/D':  ([38,46,50,53,58], [50,53,58], [70,74,77]),
 'Eb/Bb': ([46,51,55,58,63], [51,55,58], [67,70,75]),
}
PROGRESSIONS = [
 ['Dm','Bb','F/A','C','Gm','Dm/F','A7','Dm'],
 ['Dm','Bb','F/A','C','Gm','Dm/F','A7','A7'],
 ['Dm','Bb','Gm','Eø','A7','D7/F#','Gm','A7'],
 ['Bb/D','Eb/Bb','Gm','A7','Dm','Bb','A7','Dm'],
 ['F','Bb','F/A','C','F','Dm/F','C/E','F'],
 ['Dm','Bb','F/A','C','Gm','Dm/F','A7','Dm'],
 ['Dm','Bb','F/A','C','Gm','Bb','A7','Dm'],
 ['Dm','Bb','Gm','A7','Bb/D','Gm','A7','Dm'],
]
SECTIONS = [
 ('Measured streets', '准确的街道', 'A: the lantern gesture becomes one eight-bar sentence'),
 ('The reflected lane', '倒影中的窄巷', 'A1: the line turns and extends toward an unresolved dominant'),
 ('Too much light', '越明亮，入口越隐去', 'Development: sequence and register rise together, then both hands stop'),
 ('The fifth footstep', '第五步与熄灭的灯', 'Tenor lead: upper chords support the same arrival points'),
 ('A place at the table', '院落里留出的座位', 'B: a new F-major continuation, broader and warmer'),
 ('The patient line', '耐心而完整的线', 'A2: recognisable return, with the courtyard shaping its ending'),
 ('A map with room', '容得下人的地图', 'A+B: shared culmination and a complete descent'),
 ('Room for a door', '留给门的空白', '4/4 coda: the fifth beat disappears; the final fourth beat is empty'),
]
BPMS = [
 [94,96,96,94,98,96,94,90],
 [100,100,102,100,102,100,98,94],
 [106,108,110,110,112,112,106,96],
 [80,82,84,80,82,84,80,78],
 [86,88,88,86,90,88,86,84],
 [94,96,96,94,98,96,94,90],
 [100,102,104,102,100,98,94,88],
 [84,84,82,80,78,76,72,66],
]
VELOCITIES = [
 [69,70,72,69,75,72,72,66], [73,74,76,76,79,75,75,70],
 [78,80,82,84,85,88,82,76], [66,65,67,64,67,69,65,62],
 [68,69,72,69,74,71,68,65], [73,74,75,72,77,75,73,69],
 [78,81,83,79,77,75,74,70], [66,64,63,61,60,57,55,52],
]

def transpose(seq, n):
    return [[(p+n if p >= 0 else p, d) for p,d in bar] for bar in seq]

def melody_plan(version):
    dark = deepcopy(DARK)
    if version == 'v6a':
        # Initial full draft only gave the left hand the first four dark bars.
        dark[4:] = transpose(dark[4:], 12)
    return sum([deepcopy(A), deepcopy(REFLECTION), deepcopy(BRIGHT), dark,
                deepcopy(COURT_A if version == 'v6a' else COURT), deepcopy(RETURN),
                deepcopy(JOINED_C if version == 'v6c' else JOINED),
                deepcopy(CODA_C if version == 'v6c' else CODA)], [])

def make_score(version):
    melodies = melody_plan(version)
    bars, events, pedals = [], [], []
    beat = 0.0
    for j, melody in enumerate(melodies):
        sec, k = divmod(j, 8)
        barno, beats = j+1, (4 if sec == 7 else 5)
        assert abs(sum(d for _,d in melody)-beats)<1e-9, (barno, melody)
        hname = PROGRESSIONS[sec][k]
        arp, block, upper = deepcopy(H[hname])
        left_lead = sec == 3 and (version != 'v6a' or k < 4)
        level = VELOCITIES[sec][k]
        bpm = BPMS[sec][k]
        # The last revision gives the true narrative culmination a little room.
        if version == 'v6c' and j in (50,51):
            bpm -= 2
        b = dict(bar=barno,start=beat,beats=beats,bpm=bpm,
                 meter_numerator=beats,meter_denominator=4,
                 grouping='3+2' if beats==5 else '2+2',
                 section=SECTIONS[sec][0],section_zh=SECTIONS[sec][1],
                 harmony_name=hname,harmony=[arp[0]]+block,
                 lead_hand='LH' if left_lead else 'RH',
                 phrase_role=['statement','continuation','rise','breath',
                              'extension','descent','cadence preparation','arrival'][k])
        if version == 'v6c' and barno==63:
            b['harmony_name']='A7sus4 → A7'
            b['harmonic_segments']=[{'offset':0,'name':'A7sus4','pitches':[45,50,52,55]},
                                    {'offset':1.5,'name':'A7','pitches':[45,49,52,55]}]
        bars.append(b)
        serial = defaultdict(int)
        def add(off,dur,pitch,vel,voice,hand,role):
            if dur <= 0: return
            serial[voice]+=1
            events.append(dict(event_id=f'b{barno:02d}_{voice}_{serial[voice]:02d}',
                bar=barno,onset=round(beat+off,6),duration=round(dur,6),pitch=int(pitch),
                velocity=max(1,min(127,int(vel))),voice=voice,hand=hand,role=role))
        off = 0.0
        for ix,(pitch,dur) in enumerate(melody):
            if pitch>=0:
                # Phrase dynamics follow direction and metric purpose, not pitch alone.
                stress = 2 if off==0 else (1 if off==3 and beats==5 else 0)
                contour = (1 if ix>0 and pitch>melody[ix-1][0] and dur>=1 else 0)
                ending = -3 if k in (3,7) and off>=3 else 0
                release = .035 if dur<=.5 else .045
                if k in (3,7) and off+dur==beats: release=.09
                if barno==64: release=.035
                add(off,dur-release,pitch,level+stress+contour+ending,
                    'melody','LH' if left_lead else 'RH','lead')
            off+=dur
        # A real breath comes from every voice, not a detached low-register flourish.
        phrase_end = k in (3,7)
        cutoff = beats - (.65 if phrase_end else .04)
        if version=='v6c' and melody[-1][0]<0:
            cutoff=beats-melody[-1][1]-.02
        if barno==24: cutoff=4.0
        if barno==64: cutoff=3.0
        if left_lead:
            # Stable upper chords occupy a single hand span. No answering tune.
            for t,duration,vel in [(0,2.65,level-28),(3,1.6,level-31)]:
                duration=min(duration,cutoff-t)
                if version=='v6c' and k in (3,7): duration=min(duration,1.25)
                for n in upper:
                    add(t,duration,n,vel,'upper_support','RH','support')
        elif sec==4:
            # Courtyard: a gently breathing chordal texture replaces the walking arp.
            add(0,.7,arp[0],level-25,'bass','LH','support')
            for t,duration,vel in [(1,1.75,level-30),(3,1.40,level-32)]:
                for n in block:
                    add(t,min(duration,cutoff-t),n,vel,'accompaniment','LH','support')
            if k not in (3,7):
                add(4.5,.40,arp[1],level-31,'accompaniment','LH','support')
        elif sec==7:
            if barno==64:
                for n in [38,45,50]: add(0,2.9,n,level-20,'bass','LH','support')
                for n in [65,69]: add(0,2.9,n,level-23,'inner_support','RH','support')
            else:
                add(0,.58,arp[0],level-25,'bass','LH','support')
                # Lower the coda support when the melody comes into the middle register.
                low_block=[n-12 if n>=min(p for p,d in melody if p>=0) else n for n in block]
                low_block=sorted(set(low_block))
                if max(low_block)-min(low_block)>12:
                    low_block=[n-12 if n>min(low_block)+12 else n for n in low_block]
                if version=='v6c' and barno==63:
                    for n in [50,52,55]: add(.75,.69,n,level-27,'accompaniment','LH','support')
                    for n in [49,52,55]: add(1.5,1.95,n,level-29,'accompaniment','LH','support')
                else:
                    for t,duration in [(.75,1.15),(2.25,1.2)]:
                        for n in low_block:
                            add(t,min(duration,cutoff-t),n,level-28-(2 if t>2 else 0),
                                'accompaniment','LH','support')
        else:
            # One harmonic route, normally in quavers, with the same 3+2 goals.
            # The bass is part of this route, never an independent second theme.
            slots=[(0,0),(.5,1),(1,2),(1.5,3),(2,2),(2.5,1),
                   (3,2),(3.5,3),(4,2),(4.5,1)]
            # Supporting figures breathe with a two-bar question/answer. Their
            # thinning is part of v6c's phrasing revision, not stochastic variation.
            held_support={}
            if version=='v6c' and sec in (0,1,5) and k in (1,5):
                slots=[x for x in slots if x[0]!=1.5]
                held_support[1]=.90
            if version=='v6c' and sec==6 and k in (2,5):
                slots=[x for x in slots if x[0]!=3.5]
                held_support[3]=.90
            for t,idx in slots:
                if t>=cutoff: continue
                n=arp[idx]
                if t==4.5 and j<63:
                    nextroot=H[PROGRESSIONS[(j+1)//8][(j+1)%8]][0][0]
                    candidates=[a+o for a in arp for o in (-12,0,12)
                                if 36<=a+o<=62 and abs(a+o-nextroot)<=12 and abs(a+o-arp[2])<=12]
                    if candidates: n=min(candidates,key=lambda x:abs(x-n))
                gap = 25 if t in (0,3) else 32
                if version=='v6c' and sec==6:
                    gap += 2  # keep the new apex a melody, not a thick chord crest
                add(t,min(held_support.get(t,.44),cutoff-t),n,level-gap,
                    'bass' if t==0 else 'accompaniment','LH','support')
            # v6c aligns the last group's support with the actual melodic descent.
            # This is selective voice-leading, not an extra density layer.
            if version=='v6c' and barno in (51,53,54,56):
                replacements={51:{3:57,3.5:53,4:48},
                              53:{3:58,3.5:55,4:50},
                              54:{3:58,3.5:53,4:50},
                              56:{3:57,3.5:53,4:50}}
                for e in events:
                    if e['bar']==barno and e['hand']=='LH':
                        t=round(e['onset']-beat,4)
                        if t in replacements[barno]: e['pitch']=replacements[barno][t]
        # CC64 is continuous in the actual Salamander SFZ (release curve 11).
        # 40-52 are purposeful half-pedal values; they are not boolean sustain.
        depth = [46,46,40,42,50,46,48,44][sec]
        if barno==64:
            pedal_spec=[(0,0),(.10,52),(3,0)]
        elif version=='v6c' and barno==63:
            pedal_spec=[(0,0),(.10,42),(1.43,0),(1.57,42),(3.65,0)]
        else:
            split = 3 if beats==5 else 2.2
            end = min(beats-.10,cutoff+.02)
            pedal_spec=[(0,0),(.10,depth),(split-.08,0),
                        (split+.10,depth-4),(end,0)]
            if sec==4:
                pedal_spec=[(0,0),(.10,depth),(2.85,0),(3.10,depth-4),(end,0)]
        for t,value in pedal_spec:
            if t < beats and (t<=cutoff+.03 or value==0):
                pedals.append(dict(onset=round(beat+t,6),value=value,bar=barno))
        beat+=beats
    # Enforce physical key ownership on a single piano channel before export.
    # A support note at an already-owned melodic pitch is omitted, never reassigned.
    removed=[]
    for e in list(events):
        if e['role']=='lead': continue
        conflict=[m for m in events if m['role']=='lead' and m['pitch']==e['pitch']
                  and m['onset']<e['onset']+e['duration']-1e-7
                  and e['onset']<m['onset']+m['duration']-1e-7]
        if conflict:
            removed.append({'removed':e,'lead_ids':[m['event_id'] for m in conflict]})
            events.remove(e)
    events.sort(key=lambda e:(e['onset'],e['pitch'],e['event_id']))
    pedals.sort(key=lambda e:(e['onset'],e['value']))
    return dict(id=51,title='The Lantern Cartographer',title_zh='提灯绘图师',
        stage=version+'_full_symbolic_rewrite_unheard',revision_of='Existing work #051; not a new composition count',
        approval_status='Symbolic draft only. No rendering or listening performed. v5 was not user-approved.',
        bars=bars,events=events,pedals=pedals,total_beats=beat,tail_seconds=4.8,
        source_identity='Original #051 v4 D-Eb-Bb motif and v5 A-Bb-F thematic study; no #052 melody or accompaniment reused.',
        controller_contract={
            'event_time_unit':'quarter-note beats, absolute',
            'tempo_rule':'piecewise constant per bar; durations crossing a boundary use both tempos',
            'piano_channel':0,'pedal_field':'pedals -> MIDI CC64 without rescaling',
            'details_flag_required_for_source_renderer':True,
            'source_renderer_enable_details_initializes':{'20':62,'21':20,'22':18,'23':50},
            'sfz_defaults_retained':{'7':100,'10':64,'24':0,'72':0,'90':0,'99':0},
            'source_renderer_event_order':'note-off (0), CC (1), note-on (2) at equal sample time',
            'no_other_controller_automation':True,
            'engine_dependency':'Existing corrected Accurate/Moonlight-Salamander SFZ; continuous CC64 curve 11, sustain_cc=90. Generic GM playback will not reproduce half-pedal behaviour.',
            'metadata_warning':'controller_contract is documentation, not an extra CC field consumed by the source renderer.'},
        ownership_omissions=removed)

def seconds_function(d):
    starts=[b['start'] for b in d['bars']]; times=[]; t=0.0
    for b in d['bars']: times.append(t); t+=b['beats']*60/b['bpm']
    def sec(beat):
        i=max(0,bisect.bisect_right(starts,beat)-1)
        return times[i]+(beat-starts[i])*60/d['bars'][i]['bpm']
    return sec,t

def qa(d):
    events=d['events']; sec,total=seconds_function(d)
    collisions=[]
    for pitch in range(128):
        ns=sorted([e for e in events if e['pitch']==pitch],key=lambda e:e['onset'])
        for i,e in enumerate(ns):
            for f in ns[i+1:]:
                if f['onset']>=e['onset']+e['duration']-1e-7: break
                collisions.append([e['event_id'],f['event_id']])
    spans={}; fast_relocations=[]
    for hand in ('LH','RH'):
        hs=[e for e in events if e['hand']==hand]
        maximum=0; worst=None
        for t in sorted({e['onset'] for e in hs}):
            active=[e['pitch'] for e in hs if e['onset']<=t<e['onset']+e['duration']-1e-7]
            span=max(active)-min(active)
            if span>maximum: maximum=span;worst={'beat':t,'pitches':active}
        spans[hand]={'max_simultaneously_held_span_semitones':maximum,'example':worst}
        attacks=defaultdict(list)
        for e in hs: attacks[e['onset']].append(e['pitch'])
        times=sorted(attacks)
        for a,b in zip(times,times[1:]):
            dt=sec(b)-sec(a)
            distance=min(abs(x-y) for x in attacks[a] for y in attacks[b])
            if dt<=.35 and distance>12:
                fast_relocations.append({'hand':hand,'from_beat':a,'to_beat':b,'seconds':dt,'distance_semitones':distance})
    per_section=[]
    for s in range(8):
        bs=d['bars'][s*8:s*8+8]; es=[e for e in events if s*8<e['bar']<s*8+9]
        leads=[e for e in es if e['role']=='lead']; sup=[e for e in es if e['role']=='support']
        joint=sum(any(abs(e['onset']-f['onset'])<1e-6 for f in sup) for e in leads)
        per_section.append({'bars':f'{s*8+1}-{s*8+8}','section':SECTIONS[s][0],
            'start_seconds':round(sec(bs[0]['start']),3),'end_seconds':round(sec(bs[-1]['start']+bs[-1]['beats']),3),
            'notes':len(es),'lead_notes':len(leads),'support_notes':len(sup),
            'lead_attacks_with_simultaneous_support':joint,
            'lead_velocity_mean':round(sum(e['velocity'] for e in leads)/len(leads),2),
            'support_velocity_mean':round(sum(e['velocity'] for e in sup)/len(sup),2)})
    bybar=defaultdict(list)
    for e in events:
        if e['role']=='lead': bybar[e['bar']].append((round(e['onset']-d['bars'][e['bar']-1]['start'],6),e['pitch'],e['duration']))
    repeated=Counter(tuple(v) for v in bybar.values())
    report={'stage':d['stage'],'bars':len(d['bars']),'total_beats':d['total_beats'],
        'score_seconds':round(total,6),'tail_seconds':d['tail_seconds'],
        'expected_full_duration_seconds':round(total+d['tail_seconds'],6),
        'note_count':len(events),'pitch_range':[min(e['pitch'] for e in events),max(e['pitch'] for e in events)],
        'pedal_points':len(d['pedals']),'same_key_overlaps':collisions,
        'hand_spans':spans,'fast_relocations_over_octave_within_350ms':fast_relocations,
        'exact_repeated_melody_bar_excess':sum(n-1 for n in repeated.values() if n>1),
        'last_noteoff_beat':max(e['onset']+e['duration'] for e in events),
        'last_pedal_event':d['pedals'][-1],'sections':per_section,
        'scope':'Symbolic, structural and mechanical diagnostics only. These do not establish musical quality, tone, balance by ear, or audio correctness.'}
    assert not collisions, collisions
    assert all(x['max_simultaneously_held_span_semitones']<=12 for x in spans.values()),spans
    assert not fast_relocations,fast_relocations
    assert 200<=total+d['tail_seconds']<=225
    assert d['pedals'][0]['onset']==0 and d['pedals'][0]['value']==0
    assert d['pedals'][-1]['value']==0
    assert all(0<=e['velocity']<=127 and 21<=e['pitch']<=108 and e['duration']>0 for e in events)
    return report

def vlq(v):
    b=[v&127]; v>>=7
    while v: b.insert(0,128|(v&127)); v>>=7
    return bytes(b)

def midi(d):
    ppq=960; meta=[]; notes=[]; prev_meter=None; prev_sec=None
    for b in d['bars']:
        tick=round(b['start']*ppq)
        meta.append((tick,0,b'\xff\x51\x03'+round(60000000/b['bpm']).to_bytes(3,'big')))
        meter=b['meter_numerator']
        if meter!=prev_meter: meta.append((tick,1,b'\xff\x58\x04'+bytes([meter,2,24,8])))
        if b['section']!=prev_sec:
            t=b['section'].encode('utf8');meta.append((tick,2,b'\xff\x06'+vlq(len(t))+t))
        prev_meter=meter; prev_sec=b['section']
    notes.append((0,-2,b'\xc0\x00'))
    for cc,v in [(7,100),(10,64),(20,62),(21,20),(22,18),(23,50),(24,0),(72,0),(90,0),(99,0)]:
        notes.append((0,-1,bytes([0xb0,cc,v])))
    for e in d['events']:
        notes.append((round(e['onset']*ppq),2,bytes([0x90,e['pitch'],e['velocity']])))
        notes.append((round((e['onset']+e['duration'])*ppq),0,bytes([0x80,e['pitch'],0])))
    for e in d['pedals']: notes.append((round(e['onset']*ppq),1,bytes([0xb0,64,e['value']])))
    end=round((d['total_beats']+d['tail_seconds']*d['bars'][-1]['bpm']/60)*ppq)
    for tr in (meta,notes):tr.append((end,9,b'\xff\x2f\x00'))
    def track(ev):
        out=bytearray();last=0
        for tick,order,data in sorted(ev,key=lambda x:(x[0],x[1])):
            out+=vlq(tick-last)+data;last=tick
        return b'MTrk'+struct.pack('>I',len(out))+out
    return b'MThd'+struct.pack('>IHHH',6,1,2,ppq)+track(meta)+track(notes)

def dump(path,value):
    path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf8')

def exact_diff(old,new):
    result={'from':old['stage'],'to':new['stage'],'changed_bars':[]}
    for before,after in zip(old['bars'],new['bars']):
        b=before['bar'];a_events=[e for e in old['events'] if e['bar']==b];b_events=[e for e in new['events'] if e['bar']==b]
        a_pedals=[e for e in old['pedals'] if e['bar']==b];b_pedals=[e for e in new['pedals'] if e['bar']==b]
        if before!=after or a_events!=b_events or a_pedals!=b_pedals:
            result['changed_bars'].append({'bar':b,'before':{'bar':before,'events':a_events,'pedals':a_pedals},
                                                   'after':{'bar':after,'events':b_events,'pedals':b_pedals}})
    return result

def main():
    scores={}; reports={}
    for version in ('v6a','v6b','v6c'):
        d=make_score(version); r=qa(d);scores[version]=d;reports[version]=r
        dump(P/f'score_{version}.json',d);dump(P/f'qa_{version}.json',r)
        (P/f'051_full_{version}.mid').write_bytes(midi(d))
    dump(P/'score.json',scores['v6c'])
    for a,b in [('v6a','v6b'),('v6b','v6c')]:
        dump(P/f'exact_diff_{a}_to_{b}.json',exact_diff(scores[a],scores[b]))
        old=(P/f'score_{a}.json').read_text().splitlines(keepends=True)
        new=(P/f'score_{b}.json').read_text().splitlines(keepends=True)
        (P/f'score_{a}_to_{b}.diff').write_text(''.join(difflib.unified_diff(old,new,fromfile=f'score_{a}.json',tofile=f'score_{b}.json')))
    dump(P/'form.json',{'composition_id':51,'new_composition_count':0,'form':[
        dict(reports['v6c']['sections'][s],story=SECTIONS[s][1],musical_function=SECTIONS[s][2]) for s in range(8)]})
    dump(P/'thematic_plan.json',{'primary_motif':{'pitches':[69,70,77],'intervals':[1,7],'source':'#051 v5 study'},
         'dark_motif':{'pitches':[50,51,58],'intervals':[1,7],'source':'#051 v4 D-Eb-Bb, tenor register'},
         'court_melody':COURT,'all_final_lead_bars':melody_plan('v6c'),
         'protected_reference_melodies_used':False,'piece_052_music_used':False})
    names=['C','C#','D','Eb','E','F','F#','G','Ab','A','Bb','B']
    def note_name(n):return 'rest' if n<0 else names[n%12]+str(n//12-1)
    lead_lines=['#051 The Lantern Cartographer — v6c symbolic lead sheet',
                'Concert pitch. C4 = MIDI 60. Durations after / are quarter-note beats.',
                'The indicated hand carries the melody; the other hand supports it.', '']
    for b,mel in zip(scores['v6c']['bars'],melody_plan('v6c')):
        if (b['bar']-1)%8==0:lead_lines+=['',b['section']]
        lead_lines.append(f"{b['bar']:02d} | {b['beats']}/4 | q={b['bpm']} | {b['harmony_name']:<12} | {b['lead_hand']} | "+
                          '  '.join(f'{note_name(n)}/{dur:g}' for n,dur in mel))
    (P/'lead_sheet.txt').write_text('\n'.join(lead_lines)+'\n',encoding='utf8')
    files=[f for f in P.iterdir() if f.is_file() and f.name!='manifest.json']
    dump(P/'manifest.json',{'composition_id':51,'stage':'symbolic_full_rewrite_draft_v6',
        'rendered':False,'listened':False,'published':False,'originals_modified':False,
        'files':{f.name:{'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()} for f in sorted(files)}})
    print(json.dumps({v:{'duration_seconds':r['expected_full_duration_seconds'],'notes':r['note_count'],
                          'same_key_overlaps':len(r['same_key_overlaps']), 'hand_spans':r['hand_spans']}
                      for v,r in reports.items()},ensure_ascii=False,indent=2))

if __name__=='__main__':main()
