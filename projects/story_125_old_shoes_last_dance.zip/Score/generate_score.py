"""Rebuild all nominal versions and exact diffs, then run independent checks."""
from pathlib import Path
from collections import Counter
import json,hashlib,importlib.util
P=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('data',P/'composition_data.py');d=importlib.util.module_from_spec(spec);spec.loader.exec_module(d)
def dump(name,value):(P/name).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
def clean(e):return {k:v for k,v in e.items() if k not in ('event_id','version')}
def enc(x):return json.dumps(x,sort_keys=True,ensure_ascii=False,separators=(',',':'))
scores=[]
for v in range(3):
 s=d.build(v);s['events'].sort(key=lambda e:(e['onset'],e['instrument'],e['pitch']))
 for i,e in enumerate(s['events']):e['event_id']=f'125-v{v}-{i:05d}'
 dump(f'score_v{v}.json',s);scores.append(s)
for a,b in [(0,1),(1,2)]:
 old,new=scores[a],scores[b];evidence=[]
 for i in range(1,93):
  aa=[clean(e) for e in old['events'] if e['bar']==i];bb=[clean(e) for e in new['events'] if e['bar']==i]
  if aa!=bb or old['bars'][i-1]!=new['bars'][i-1]:
   ca,cb=Counter(map(enc,aa)),Counter(map(enc,bb))
   evidence.append(dict(bar=i,before=dict(bar=old['bars'][i-1],events=aa),after=dict(bar=new['bars'][i-1],events=bb),notes_removed=sum((ca-cb).values()),notes_added=sum((cb-ca).values())))
 dump(f'exact_diff_v{a}_to_v{b}.json',dict(event_ids_excluded=True,changed_bars=[x['bar'] for x in evidence],bar_count=len(evidence),evidence=evidence))
(P/'score.json').write_bytes((P/'score_v2.json').read_bytes())
spec=importlib.util.spec_from_file_location('verify',P/'independent_verify.py');v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v);report=v.run()
ready=dict(id=125,title=d.TITLE,title_zh=d.TITLE_ZH,status='nominal_score_ready',final_score='score_v2.json',sha256=report['final_score_sha256'],duration_seconds=report['final']['duration_seconds'],versions=['v0','v1','v2'],self_contained_rebuild='python3 generate_score.py',independent_verification='python3 independent_verify.py',actual_revision_changes=report['actual_revisions'],nominal_onsets_no_sample_compensation=True,audio_rendered=False,human_listening_review=False,renderer_notes=d.RENDERER_NOTES)
dump('READY_FOR_REVIEW.json',ready)
files=[p for p in P.iterdir() if p.is_file() and p.suffix in ('.py','.json','.txt','.md') and p.name not in ('hashes.json','library_receipt.json','library_roundtrip_verification.json','local_zip_verification.json')]
dump('hashes.json',{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(files)})
print(json.dumps(ready,ensure_ascii=False))
