黎明时的铜鸟 / Copper Birds at Daybreak — v4
原创虚构故事与单簧管、大提琴拨弦二重奏，2分55.4秒。

打开063_copper_birds_v4.rpp。完整包包含两条float32音轨，可在REAPER中直接播放和混音；另有三轨MIDI及可编辑JSON谱面。不是自包含虚拟乐器工程。没有钢琴、弓奏弦乐或打击乐轨。轻房间为REAPER自带ReaVerbate，实际Linux7.82重开导出经过核验；其他平台可能需重新匹配插件，不承诺跨平台PCM一致。输出在Renders/。

音符再生成：Score/compose.py产生v0/v1/v2谱面，Score/prepare_scores.py分轨，Score/revise_pizzicato_body.py产生最终v3演奏谱并保留历史；Score/export_midi.py导出三轨MIDI。Tools/render_score_sfizz.py分别读取clarinet_score.json、cello_score.json；选择外部Iowa单簧管Iowa_clarinet_C4_B4_trio_articulated.sfz与大提琴Iowa_cello_pizz_C2_B2_mf.sfz，SFZ须放在各自外部Samples目录旁。输出Media/clarinet_float32.wav和Media/cello_float32.wav。旧AUDIT和草稿说明保留非音频创作阶段状态，最终演奏时值以ensemble_score.json和pass3为准。

两种源录音都是16bit44.1kHzmono。官方sfizz生成float32源轨，再由真实REAPER导出24bit母带，并不增加源录音的真实精度。
单簧管：University of Iowa MIS；Christine Bellomy演奏，Lawrence Fritts主持，John Ritz与Eric Durian录音技术。来源 https://theremin.music.uiowa.edu/MISBbclarinet.html 。只用真实mf录音层，实音C4–B4，短句与换气，没有真实连奏过渡或循环延音。
大提琴：University of Iowa MIS；Jean Montes演奏，Lawrence Fritts主持，Michael Cash与Andrew Stuck-Marcell录音技术。来源 https://theremin.music.uiowa.edu/MIScello.html 。仅C2–B2、一个mf拨弦录音层；速度/力度变化是演奏时序与幅度变化，不是额外录制的弱强层。原录音音高校准有逐音测量及三窗口证据，自然衰减中的小幅漂移仍保留。
两者的官方许可 https://theremin.music.uiowa.edu/MIS.html 允许下载并用于任何项目，无使用限制；不另称CC0。原始来源、SHA、切片边界和调律记录见InstrumentMapping。原始共享采样和sfizz二进制不重复打包。

三轮实质修订分别为：改写中段不等长短句及低音应答；改写回归、尾声和错开的终止；把过短的大提琴门限延展到约0.55秒以内的自然拨弦主体，并留出下一次弹拨的间隙。第四轮为实际REAPER总线关系、总电平与冗余尾静默整理。完整人耳听审仍待进行；程序检查不能代替音乐评价。样本演奏不是现场真人合奏，故事为虚构。
