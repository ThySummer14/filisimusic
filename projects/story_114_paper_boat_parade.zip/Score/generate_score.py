"""114 original comic march: dotted lower pulse, shrinking commands and wind replies."""
from pathlib import Path
import json,sys,bisect
P=Path(__file__).resolve().parent;sys.path.insert(0,str(P));from composition_data import *
PARAM={'opening':('纸帽下的第一声',112,86),'boats':('一艘接一艘',120,78),'captains':('两位小船长',128,87),'short_orders':('越来越短的口令',136,94),'bank':('岸边的低声商量',92,44),'parade':('纸帽队伍重新出发',124,89),'coda':('终点的小看台',116,75)}
def write(p,x):p.write_text(json.dumps(x,ensure_ascii=False,separators=(',',':'))+'\n')
def pitch(s):return 12*(int(s[-1])+1)+{'C':0,'D':2,'E':4,'F':5,'G':7,'A':9,'B':11}[s[0]]+s[1:-1].count('#')-s[1:-1].count('b')
def build(level):
 rows=[]
 for sec,hs,ls in GROUPS:assert len(hs.split())==len(ls);rows.extend((sec,h,l) for h,l in zip(hs.split(),ls))
 assert len(rows)==96
 bars=[];events=[];pedals=[]
 for n,(sec,h,line) in enumerate(rows,1):
  for lv,rd,hd in [(1,REV1,HREV1),(2,REV2,HREV2)]:
   if level>=lv:line=rd.get(n,line);h=hd.get(n,h)
  label,bpm,dyn=PARAM[sec];ch=H[h];start=(n-1)*4
  if n in [8,24,40,64,76,88]:bpm-=4
  if n in [95,96]:bpm-=4*(n-94)
  bars.append(dict(bar=n,start=start,beats=4,bpm=bpm,meter='4/4',meter_numerator=4,meter_denominator=4,section=sec,section_title_zh=label,harmony_name=h,harmony=ch,key_region='G minor' if sec=='captains' else 'Eb/Bb major' if sec=='bank' else 'Bb major',phrase_end=n in [46,51,55,58,62,64]))
  def add(p,t,d,v,inst,voice,hand='none'):
   assert 0<=t<t+d<=4.00001,(n,t,d)
   events.append(dict(bar=n,onset=round(start+t,6),duration=round(d,6),pitch=p,velocity=int(v),instrument=inst,voice=voice,hand=hand))
  at=0;mel=[]
  for i,tok in enumerate(line.split()):
   name,u=tok.split(':');dur=float(u)/2
   if name!='R':
    p=pitch(name);mel.append(p);add(p,at,dur-.07,dyn+(4 if at==0 and sec!='bank' else 0)-(4 if i==len(line.split())-1 else 0),'piano','march_call','right')
   at+=dur
  assert at==4
  root=ch[0];upper=[ch[1],ch[2]]
  while max(upper)>=min(mel):upper=[p-12 for p in upper]
  while root>=min(mel):root-=12
  if sec=='bank':
   if n%2:add(root,0,.9,30,'piano','quiet_bank_support','left')
  else:
   bass=[(0,root,.52),(2,root,.5)];times=[.75,2.75]
   if n%4==3:bass=[(0,root,.48),(2,ch[2] if ch[2]<min(mel) else ch[2]-12,.4)]
   if level>=1 and sec=='short_orders':
    bass=[(0,root,.5)];times=[1.25,2.75] if n not in [46,51,55,58,62,64] else [.75]
   if level>=2 and sec=='parade':bass=[(0,root,.55),(2.5,root,.35)];times=[1,3.25]
   if n in [8,24,40,64,88,94]:bass=[(0,root,.55)];times=[.75]
   for t,p,dur in bass:add(p,t,dur,dyn-22,'piano','dotted_bass_step','left')
   for t in times:
    for p in upper:add(p,t,.16,dyn-28,'piano','short_upper_step','left')
  avail=[p for p in range(60,72) if p%12 in {x%12 for x in ch}];assert avail
  wind=[]
  if sec=='bank':wind=[(3.1,avail[0],.50,48)]
  elif sec=='opening' and n in [2,4,6,8]:wind=[(2.5,avail[-1],.56,69)]
  elif sec=='boats' and n%4==2:wind=[(1.1,avail[0],.48,66),(2.8,avail[-1],.45,66)]
  elif sec=='captains' and n%4 in [1,3]:wind=[(.5,avail[-1],.53,73),(2.6,avail[0],.48,73)]
  elif sec=='short_orders' and n in [46,51,55,58,62,64]:wind=[(2.7,avail[-1],.43,78)]
  elif sec=='parade' and n%4==0:wind=[(2.5,avail[0],.55,74)]
  elif sec=='coda' and n in [89,91,93,96]:wind=[(.5,avail[-1],.60,65)]
  if level>=2 and sec=='parade':wind=[(.5,avail[0],.54,73),(2.4,avail[-1],.52,73)] if n%4 in [1,3] else [(2.4,avail[0],.52,73)] if n%4==0 else []
  for t,p,body,v in wind:add(p,t,body*bpm/60,v,'clarinet','woodwind_countercall')
  pedals.append(dict(bar=n,onset=start,controller=64,value=0,instrument='piano'))
  if sec=='bank':pedals.extend([dict(bar=n,onset=start+.07,controller=64,value=22,instrument='piano'),dict(bar=n,onset=start+1.6,controller=64,value=0,instrument='piano')])
 events.sort(key=lambda e:(e['onset'],e['instrument'],e['pitch']))
 for i,e in enumerate(events):e['event_id']=f'114-v{level}-{i}'
 return dict(id=114,title='The Paper-Boat Parade',title_zh='纸船阅兵',version=f'v{level}',bars=bars,events=events,pedals=pedals,total_beats=384,tail_seconds=5,instrument_map={'piano':'piano','clarinet':'clarinet'},performance_contract='Original comic acoustic march, real piano and clarinet samples. No drum/brass imitation or human-listening claim.')
def proj(d,n):return {'bar':d['bars'][n-1],'events':[{k:v for k,v in e.items() if k!='event_id'} for e in d['events'] if e['bar']==n],'pedals':[e for e in d['pedals'] if e['bar']==n]}
for v in range(3):
 d=build(v);write(P/f'score_v{v}.json',d);report={'version':f'v{v}','bars':96,'events':len(d['events']),'duration_seconds':sum(b['beats']*60/b['bpm'] for b in d['bars'])+5,'human_listening_review':False};write(P/f'audit_v{v}.json',report)
 if v:
  a=build(v-1);changes=[{'bar':n,'before':proj(a,n),'after':proj(d,n)} for n in range(1,97) if proj(a,n)!=proj(d,n)];write(P/f'exact_diff_v{v-1}_to_v{v}.json',{'count':len(changes),'changed_bars':[x['bar'] for x in changes],'comparison_excludes':['version','event_id'],'changes':changes});text=[]
  for x in changes:
   text.append(f"BAR {x['bar']}\n")
   for side in ['before','after']:
    q=x[side];text.append(side+' '+q['bar']['harmony_name']+' '+str([(e['instrument'],e['voice'],e['onset'],e['pitch'],e['duration'],e['velocity']) for e in q['events']])+'\n')
  (P/f'exact_diff_v{v-1}_to_v{v}.patch').write_text(''.join(text))
for name in ['score.json','ensemble_score.json']:write(P/name,d)
for inst in ['piano','clarinet']:write(P/f'{inst}_score.json',{**d,'events':[e for e in d['events'] if e['instrument']==inst],'pedals':d['pedals'] if inst=='piano' else []})
starts=[b['start'] for b in d['bars']];times=[];t=0
for b in d['bars']:times.append(t);t+=b['beats']*60/b['bpm']
def sec(t):
 i=max(0,bisect.bisect_right(starts,t)-1);return times[i]+(t-starts[i])*60/d['bars'][i]['bpm']
w=sorted([e for e in d['events'] if e['instrument']=='clarinet'],key=lambda e:e['onset']);gaps=[sec(b['onset'])-sec(a['onset']+a['duration']) for a,b in zip(w,w[1:])];assert min(gaps)>=.14;print(json.dumps({**report,'clarinet_min_gap_seconds':min(gaps)}))
