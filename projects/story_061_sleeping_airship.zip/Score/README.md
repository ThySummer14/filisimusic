# 61《在睡梦中修理飞艇》非渲染谱面交接

建议整合：score_v2.json。包含 52 小节、208 拍、逐段速度，音乐约 2:57.83，加 4 秒尾音预留约 3:01.83。钢琴 + 单簧管；无大提琴。

文件：
- 故事与作曲设计.md：原创故事、主题、地基、逐段音乐逻辑及待验证项
- 两轮非音频修订.md：v0→v1→v2 的两轮实质修改
- score_v0.json / score_v1.json / score_v2.json：可比较的原稿与两轮修订
- compose_airship.py：标准库 Python，可复现三个版本；只生成文本数据，不生成声音
- theme_and_ground.json：手写原创种子
- audit_report.json：逐版机械检查、真实秒数、换气、两手分工与事件差异
- build_log.json：本次生成结果

接口：
- piano 的 melody → 右手；bass / accompaniment → 左手，所有版本遵循这一固定映射
- clarinet 使用 instrument=clarinet、voice=clarinet
- 每小节提供 lead_instrument=piano 或 clarinet；role_plan 写明声部任务
- 52 小节的右手 D–F–A 三音都写入 melody；没有隐藏在 accompaniment 的右手和弦
- 单簧管实音 MIDI 60–70；mf 录制层，velocity 66–81，最长写入音 1.15 秒；不声称真实连奏
- 踏板只发 value=0；无同键重叠；没有钢琴旋律与单簧管旋律同时争前景

边界：没有制作 MIDI、音频、REAPER 工程；没有安装软件或下载音源。本文中的主伴关系和换气是谱面事实；声音自然度、实际平衡与旋律记忆度仍须整合后聆听。
