#!/usr/bin/env python3
"""The Harbor of Folded Wings — reproducible, original symbolic piano score.

Standard library only. No audio, MIDI, synthesis, downloads, or external melodies.
All times in the exported score are absolute quarter-note beats; each 6/8 bar is 3.
Run: python generate.py
"""
from __future__ import annotations

import copy
import hashlib
import json
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parent

# bass, lower fifth/connecting tone, upper root/structural tone, upper third.
# They are deliberately actual piano registers, not pitch classes later sprayed
# over octaves. Some inversions therefore have a different bass-to-fifth shape.
H = {
    'Dm': ([38,45,50,53], [2,5,9]),
    'Dm/C': ([36,45,50,53], [0,2,5,9]),
    'Bb': ([34,41,46,50], [10,2,5]),
    'Bbmaj7': ([34,41,46,50], [10,2,5,9]),
    'Bb/D': ([38,41,46,50], [10,2,5]),
    'F/A': ([33,41,45,48], [5,9,0]),
    'F': ([41,48,53,57], [5,9,0]),
    'F6': ([41,48,53,57], [5,9,0,2]),
    'F7': ([41,48,51,57], [5,9,0,3]),
    'C/E': ([40,48,52,55], [0,4,7]),
    'C': ([36,43,48,52], [0,4,7]),
    'C7': ([36,43,46,52], [0,4,7,10]),
    'Gm': ([43,50,55,58], [7,10,2]),
    'Gm/Bb': ([34,43,50,55], [7,10,2]),
    'Gm/D': ([38,46,50,55], [7,10,2]),
    'A7': ([33,40,45,49], [9,1,4,7]),
    'A7sus': ([33,40,45,50], [9,2,4,7]),
    'D7': ([38,45,48,54], [2,6,9,0]),
    'Eb': ([39,46,51,55], [3,7,10]),
    'Eo7': ([40,46,50,55], [4,7,10,2]),
    'E7': ([40,47,52,56], [4,8,11,2]),
    'Am': ([33,40,45,48], [9,0,4]),
    'Am/C': ([36,45,48,52], [9,0,4]),
    'D': ([38,45,50,54], [2,6,9]),
    'Dadd9': ([38,45,50,54], [2,4,6,9]),
    'D/F#': ([42,45,50,54], [2,6,9]),
    'G': ([43,50,55,59], [7,11,2]),
    'G/B': ([35,43,50,55], [7,11,2]),
    'Bm': ([35,42,47,50], [11,2,6]),
    'Bm/A': ([33,42,47,50], [11,2,6,9]),
    'Em': ([40,47,52,55], [4,7,11]),
    'A': ([33,40,45,49], [9,1,4]),
    'A/C#': ([37,45,49,52], [9,1,4]),
    'F#7': ([42,49,52,58], [6,10,1,4]),
}

# Token durations are eighth-note units, six per bar. R is a real rest.
# Each phrase is explicitly composed. Eight-bar syntax is a notational grouping,
# not an accompaniment or melody loop copied across the work.
PHRASES = [
('试翼铃', 124, 'launch', 69, '''
Dm       | R:1 A4:1 D5:2 F5:1 E5:1
Dm/C     | D5:3 A4:2 C5:1
Bbmaj7   | D5:2 F5:1 A5:2 G5:1
F/A      | F5:3 C5:2 A4:1
Gm       | Bb4:1 D5:2 G5:1 F5:1 D5:1
Bb       | F5:3 D5:2 Bb4:1
A7sus    | D5:3 E5:2 G5:1
A7       | E5:2 C#5:1 A4:2 R:1
'''),
('一次向上·前句', 132, 'flight', 79, '''
Dm       | A4:1 D5:2 F5:1 E5:1 D5:1
C/E      | C5:3 A4:2 G4:1
Gm       | Bb4:2 D5:1 G5:2 F5:1
A7       | E5:3 C#5:2 A4:1
Dm       | D5:3 F5:1 E5:1 D5:1
F/A      | C5:2 A4:1 G4:2 A4:1
Gm       | Bb4:3 A4:2 G4:1
A7       | E4:2 G4:1 A4:2 R:1
'''),
('一次向上·后句', 133, 'flight', 82, '''
Dm       | A4:1 D5:2 F5:1 A5:2
Dm/C     | G5:3 F5:2 E5:1
Bb       | D5:2 Bb4:1 C5:2 D5:1
C/E      | E5:3 G5:2 E5:1
F        | F5:4 E5:1 D5:1
Bb       | D5:2 C5:1 Bb4:2 A4:1
C7       | G4:2 Bb4:1 E5:2 C5:1
F        | F5:5 R:1
'''),
('风里的试跑·展句', 136, 'flight', 85, '''
F        | C5:1 F5:2 A5:1 G5:1 F5:1
C/E      | E5:2 G5:1 C6:2 Bb5:1
Dm       | A5:3 F5:1 E5:1 D5:1
Am/C     | E5:2 A5:1 G5:2 E5:1
Bb       | F5:1 Bb5:2 A5:1 G5:1 F5:1
F/A      | A5:3 G5:1 F5:1 E5:1
Gm       | D5:2 F5:1 G5:2 Bb5:1
C        | G5:3 E5:2 R:1
'''),
('风里的试跑·折回', 134, 'flight', 81, '''
F/A      | C5:1 F5:2 A5:2 G5:1
Bb       | F5:3 D5:2 C5:1
Gm       | Bb4:2 D5:1 G5:3
Eo7      | G5:1 F5:1 E5:1 D5:2 Bb4:1
Dm       | A4:1 D5:2 F5:2 E5:1
Gm       | D5:2 Bb4:1 A4:2 G4:1
A7       | E5:2 D5:1 C#5:3
Dm       | D5:5 R:1
'''),
('旧船台·量水线', 116, 'bench', 67, '''
Bb       | F4:2 Bb4:1 D5:3
F/A      | C5:4 A4:2
Gm       | G4:3 Bb4:2 A4:1
Dm       | F4:2 A4:1 D5:3
Eb       | Eb5:3 D5:2 Bb4:1
Bb/D     | F4:1 Bb4:2 D5:3
F7       | Eb5:3 D5:1 C5:1 A4:1
Bb       | D5:4 Bb4:1 R:1
'''),
('旧船台·木屑与刻度', 119, 'bench', 72, '''
Gm       | D4:1 G4:2 Bb4:1 A4:1 G4:1
Dm       | F4:3 A4:3
Eb       | Bb4:2 G4:1 F4:1 G4:2
Bb/D     | Bb4:3 D5:2 C5:1
Gm       | D5:3 Bb4:2 A4:1
Eo7      | G4:2 Bb4:1 D5:2 E5:1
D7       | F#5:2 E5:1 D5:2 F#5:1
Gm       | G5:4 D5:1 R:1
'''),
('横风·旗索绷紧', 138, 'storm', 88, '''
Dm       | A4:1 D5:1 F5:1 A5:2 G5:1
Bb       | F5:1 D5:1 Bb4:1 D5:2 F5:1
Gm       | G5:2 F5:1 D5:1 Bb4:1 D5:1
Eo7      | E5:2 G5:1 Bb5:2 A5:1
Dm       | A5:1 F5:1 D5:1 F5:2 E5:1
Bb       | D5:1 F5:1 Bb5:1 A5:2 G5:1
Gm       | D5:2 G5:1 Bb5:2 A5:1
A7       | G5:2 E5:1 C#5:2 R:1
'''),
('横风·最后一次试车', 140, 'storm', 92, '''
Dm       | A4:1 D5:1 F5:1 A5:1 G5:1 F5:1
Dm/C     | E5:1 F5:1 G5:1 A5:2 C6:1
Bb       | Bb5:3 A5:1 G5:1 F5:1
Gm/D     | G5:2 Bb5:1 D6:2 C6:1
Eo7      | Bb5:1 A5:1 G5:1 E5:2 D5:1
A7sus    | E5:1 A5:2 G5:1 F5:1 E5:1
A7       | D5:2 C#5:2 A4:2
Dm       | D5:4 R:2
'''),
('改向·落下量尺', 122, 'build', 70, '''
Gm       | D5:3 Bb4:2 A4:1
Bb/D     | F4:1 Bb4:2 D5:2 C5:1
Eb       | Bb4:1 Eb5:2 G5:2 F5:1
Bb       | D5:4 C5:1 Bb4:1
Gm       | A4:1 D5:2 F5:1 D5:1 Bb4:1
Dm       | A4:3 F4:2 A4:1
C7       | Bb4:2 C5:1 E5:2 D5:1
F        | C5:3 A4:2 R:1
'''),
('改向·肋骨成为船肋', 126, 'build', 77, '''
F        | C5:1 F5:2 A5:1 F5:1 C5:1
Bb       | D5:3 F5:2 D5:1
Gm       | Bb4:1 D5:2 G5:1 D5:1 Bb4:1
Dm       | A4:3 D5:2 F5:1
Bb       | F5:1 D5:1 Bb4:1 D5:2 F5:1
Gm       | G5:2 F5:1 D5:2 Bb4:1
Eo7      | E5:3 D5:2 Bb4:1
A7       | C#5:2 E5:1 A4:2 R:1
'''),
('潮汐上升·第一道浪', 134, 'wave', 83, '''
Dm       | A4:1 D5:2 F5:1 E5:1 D5:1
Dm/C     | C5:3 A4:2 C5:1
Bb       | D5:2 F5:1 A5:2 G5:1
A7       | E5:3 C#5:2 A4:1
Dm       | D5:3 F5:1 A5:2
Gm       | G5:2 F5:1 D5:2 Bb4:1
A7       | E5:2 D5:1 C#5:2 E5:1
Dm       | D5:5 R:1
'''),
('潮汐上升·接过缆绳', 137, 'wave', 87, '''
F        | C5:1 F5:2 A5:1 C6:2
C/E      | Bb5:3 G5:2 E5:1
Dm       | F5:2 A5:1 D6:2 C6:1
Bb       | Bb5:3 A5:2 F5:1
F/A      | A5:2 G5:1 F5:2 E5:1
Gm       | D5:2 F5:1 G5:2 Bb5:1
C7       | G5:2 E5:1 Bb5:2 G5:1
F        | A5:2 F5:3 R:1
'''),
('出坞·穿过防波堤', 140, 'climax', 95, '''
D        | A4:1 D5:2 F#5:1 A5:2
A/C#     | G5:3 E5:2 C#5:1
Bm       | F#5:1 B5:2 D6:2 C#6:1
D/F#     | A5:3 F#5:1 E5:1 D5:1
G        | D5:1 G5:2 B5:1 A5:1 G5:1
D/F#     | A5:3 F#5:2 D5:1
E7       | E5:1 G#5:2 B5:1 A5:1 G#5:1
A7       | A5:3 E5:2 R:1
'''),
('出坞·有水的航道', 138, 'climax', 98, '''
D        | A5:1 D6:2 F#6:1 E6:1 D6:1
Bm       | C#6:2 B5:1 A5:2 F#5:1
G        | G5:1 B5:2 D6:2 B5:1
D/F#     | A5:3 F#5:2 E5:1
Em       | G5:2 F#5:1 E5:2 D5:1
G        | B5:3 A5:2 G5:1
A7       | E5:2 G5:1 C#6:2 A5:1
D        | D6:4 A4:1 R:1
'''),
('低处也很辽阔·前句', 125, 'home', 80, '''
D        | A3:1 D4:2 F#4:3
A/C#     | E4:3 C#4:2 A3:1
G/B      | D4:2 G4:1 B4:2 A4:1
D/F#     | F#4:4 E4:1 D4:1
Em       | E4:1 A4:2 G4:2 E4:1
G        | D4:3 G4:2 B4:1
A7       | A4:2 G4:1 E4:2 C#4:1
D        | D4:5 R:1
'''),
('低处也很辽阔·后句', 123, 'home', 78, '''
D        | A3:1 D4:2 F#4:1 A4:2
Bm/A     | F#4:3 D4:2 B3:1
G        | B3:1 E4:2 G4:2 F#4:1
D/F#     | A4:3 F#4:2 E4:1
Em       | G4:2 F#4:1 E4:3
G/B      | D4:2 G4:1 B4:2 A4:1
A7       | G4:2 E4:1 C#4:2 A3:1
D        | D4:5 R:1
'''),
('水线上的出发线', 114, 'coda', 66, '''
G        | D4:1 G4:2 B4:2 A4:1
D/F#     | F#4:3 D4:3
Em       | E4:1 A4:2 G4:2 E4:1
A7       | C#4:3 E4:2 A3:1
D        | D4:3 F#4:2 E4:1
G        | D4:3 B3:2 G3:1
A7       | A3:2 C#4:2 E4:2
D        | D4:6
'''),
]

# Complete earlier compositional versions. v0's boat sequence still uses the
# flight accompaniment and a square sequential ascent. v1 introduces the water
# trajectory/harmonic detour; v2 completes the consequential low-register return.
V0_BUILD = '''
Gm | D5:1 G5:2 Bb5:1 A5:1 G5:1
Dm | F5:3 D5:2 A4:1
Bb | F5:1 Bb5:2 D6:1 C6:1 Bb5:1
F | A5:3 F5:2 C5:1
Gm | D5:1 G5:2 Bb5:1 A5:1 G5:1
Dm | F5:3 A5:2 F5:1
Eo7 | E5:2 G5:1 Bb5:2 A5:1
A7 | E5:3 C#5:2 R:1
Dm | A4:1 D5:2 F5:1 A5:2
Bb | Bb5:3 A5:2 F5:1
Gm | G5:2 Bb5:1 D6:2 C6:1
Dm | A5:3 F5:2 D5:1
Bb | F5:1 Bb5:2 D6:1 C6:1 Bb5:1
Gm | G5:3 D5:2 Bb4:1
Eo7 | E5:2 G5:1 Bb5:2 G5:1
A7 | A5:4 E5:1 R:1
'''
EARLY_HOME = '''
D | A4:1 D5:2 F#5:1 E5:1 D5:1
A/C# | C#5:3 A4:2 E5:1
Bm | F#5:2 B5:1 D6:2 C#6:1
D/F# | A5:3 F#5:2 D5:1
G | D5:1 G5:2 B5:1 A5:1 G5:1
D/F# | F#5:3 E5:2 D5:1
A7 | E5:2 G5:1 C#6:2 A5:1
D | D6:5 R:1
D | A4:1 D5:2 F#5:1 A5:2
Bm | B5:3 A5:2 F#5:1
G | G5:1 B5:2 D6:2 C#6:1
D/F# | A5:3 F#5:2 E5:1
Em | G5:2 F#5:1 E5:3
G | B5:3 A5:2 G5:1
A7 | E5:2 G5:1 C#6:2 A5:1
D | D6:5 R:1
'''


def pitch(token):
    if token == 'R':
        return None
    pc = {'C':0,'D':2,'E':4,'F':5,'G':7,'A':9,'B':11}[token[0]]
    modifier = 1 if '#' in token else -1 if 'b' in token else 0
    return (int(token[-1])+1)*12 + pc + modifier


def rows(text):
    out = []
    for line in text.strip().splitlines():
        harmony, melody = (s.strip() for s in line.split('|'))
        ns = [(pitch(n), int(d)) for n,d in (t.split(':') for t in melody.split())]
        assert sum(d for _,d in ns) == 6, line
        assert harmony in H, harmony
        out.append({'harmony':harmony, 'melody':ns, 'notation':melody})
    return out


def compose_rows(version):
    result = []
    for phrase_index, (section,bpm,texture,velocity,source) in enumerate(PHRASES):
        phrase = rows(source)
        assert len(phrase) == 8
        for i,row in enumerate(phrase):
            row.update(section=section, bpm=bpm, texture=texture, velocity=velocity,
                       phrase=phrase_index+1, phrase_position=i)
            result.append(row)
    assert len(result) == 144
    if version == 0:
        for idx,row in enumerate(rows(V0_BUILD), 72):
            result[idx].update(row)
            result[idx]['texture'] = 'flight'
    if version < 2:
        for idx,row in enumerate(rows(EARLY_HOME),120):
            result[idx].update(row)
            result[idx]['texture'] = 'flight'
    return result


def add(events, bar, t, dur, p, vel, voice, hand):
    events.append(dict(bar=bar,onset=round((bar-1)*3+t,5),
                       duration=round(dur,5),pitch=p,velocity=max(30,min(112,vel)),
                       voice=voice,instrument='piano',hand=hand))


def overlaps(a,b):
    return a['onset'] < b['onset']+b['duration']-1e-7 and b['onset'] < a['onset']+a['duration']-1e-7


def score(version):
    rr = compose_rows(version)
    bars, events, pedals = [], [], []
    phrase_tempo = [0,0,1,2,1,0,-1,-5]
    for index,r in enumerate(rr):
        n=index+1
        start=index*3.0
        arp,pcs=H[r['harmony']]
        pos=r['phrase_position']
        bpm=r['bpm']+phrase_tempo[pos]
        if n>=140:
            bpm={140:111,141:108,142:104,143:98,144:88}[n]
        bars.append(dict(bar=n,start=start,beats=3.0,bpm=bpm,section=r['section'],
                         meter_numerator=6,meter_denominator=8,
                         harmony_name=r['harmony'], harmony=arp,
                         role_plan='右手歌唱主线；左手低音与分解支撑同属一只手；内声避让旋律；6/8按3+3组织。',
                         lead_instrument='piano'))
        # Physical melody durations leave controlled release gaps. Phrase ends
        # include explicit rests rather than asking pedal to create phrasing.
        local=[]
        cursor=0.0
        for j,(p,units) in enumerate(r['melody']):
            length=units*.5
            if p is not None:
                close=pos==7 and j>=len(r['melody'])-2
                shape= (2 if cursor in (0,1.5) else 0)+(2 if p>=81 else 0)-(3 if close else 0)
                dur=length-(.065 if length<=.5 else .045)
                if n==120 and cursor==0:
                    # Release the climactic octave under full pedal, allowing
                    # the thumb to relocate D5→A4 before the low homecoming.
                    dur=1.60
                add(events,n,cursor,dur,p,r['velocity']+shape,'melody','right')
                local.append(events[-1])
            cursor += length

        # The low homecoming is orchestrated as a complete register change:
        # accompaniment stays below its current melody, with no hand collision.
        low_mel=min(e['pitch'] for e in local)
        aa=list(arp)
        for k in range(1,4):
            while aa[k] > low_mel-3:
                aa[k]-=12
        base=max(43,r['velocity']-26)
        tex=r['texture']
        if n==144:
            for p in (38,45):
                add(events,n,0,2.82,p,base,'bass','left')
        elif tex=='bench':
            # Two breath-sized gestures, not an incessant arpeggio: the lowest
            # note releases before the upper two-note reply.
            add(events,n,0,.92,aa[0],base+3,'bass','left')
            add(events,n,.5,.43,aa[1],base-3,'left_support','left')
            tail=aa[1]
            next_bass=H[rr[index+1]['harmony']][0][0]
            if tail-next_bass>12:
                tail-=12
            reply=[aa[2],aa[3]]
            destination=tail if pos not in (3,7) else next_bass
            if min(reply)-destination>12:
                reply=[p-12 for p in reply]
            for p in sorted(set(reply)):
                add(events,n,1.5,.87,p,base,'left_support','left')
            if pos not in (3,7):
                add(events,n,2.5,.42,tail,base-4,'left_support','left')
        elif tex=='launch':
            add(events,n,0,.89,aa[0],base+5,'bass','left')
            add(events,n,.5,.44,aa[1],base,'left_support','left')
            add(events,n,1,.44,aa[2],base+1,'left_support','left')
            tail=aa[1]
            if index+1<len(rr) and tail-H[rr[index+1]['harmony']][0][0]>12:
                tail-=12
            reply=[aa[2],aa[3]]
            if min(reply)-tail>12:
                reply=[p-12 for p in reply]
            for p in sorted(set(reply)):
                add(events,n,1.5,.87,p,base+1,'left_support','left')
            add(events,n,2.5,.42,tail,base-3,'left_support','left')
        else:
            if tex in ('build','wave','climax','home','coda'):
                seq=[aa[0],aa[1],aa[2],aa[3],aa[2],aa[1]]
            elif tex=='storm':
                seq=[aa[0],aa[2],aa[1],aa[3],aa[2],aa[1]]
            else:
                seq=[aa[0],aa[1],aa[3],aa[1],aa[2],aa[1]]
            # Anticipate the next bass position. For example, G2–D3–G3–
            # B-flat3 would otherwise end on D3 immediately before a low A1.
            # Folding the last three notes downward creates a playable wave
            # and a useful bass approach rather than a gratuitous 17th jump.
            if abs(seq[1]-seq[0])>12:
                seq[1],seq[2]=seq[2],seq[1]
            if index+1<len(rr):
                next_bass=H[rr[index+1]['harmony']][0][0]
                if seq[-1]-next_bass>12:
                    seq[-1]-=12
                    for k in (4,3):
                        if seq[k]-seq[k+1]>12:
                            seq[k]-=12
            # In the quiet coda the last subdivisions fall away gradually.
            used=range(6) if n<140 else (0,1,3,4) if n<143 else (0,2,3)
            for i in used:
                duration=.86 if i==0 else .435
                if i==0 and abs(seq[1]-seq[0])>12:
                    duration=.435
                add(events,n,i*.5,duration,seq[i],base+(4 if i==0 else 1 if i==3 else -3),
                    'bass' if i==0 else 'left_support','left')

        # A small number of inner notes support long syllables. Each stops
        # before its sung note ends; none creates an independent counter-line.
        for e in local:
            relative=e['onset']-start
            long=e['duration']>=.95
            add_inner=long and (relative in (0,1.5) or tex in ('home','coda'))
            if not add_inner:
                continue
            candidate=[p for p in range(max(48,e['pitch']-10),e['pitch']-2) if p%12 in pcs]
            if not candidate:
                continue
            support=candidate[-1:]
            if n==144:
                support=[54,57]
            elif tex in ('climax','home') and pos in (3,7) and len(candidate)>1:
                support=candidate[-2:]
            for p in support:
                dur=min(.72,e['duration']-.04) if n!=144 else 2.72
                proposed=dict(onset=e['onset'],duration=dur,pitch=p)
                if any(x['pitch']==p and overlaps(proposed,x) for x in events):
                    continue
                add(events,n,relative,dur,p,r['velocity']-24,'right_support','right')

        # Octaves are a temporary climax color; 12 semitones is the maximum
        # actual held span, and the final returning theme does not require them.
        if tex=='climax' and (n>=113 or pos in (2,6)):
            for e in local:
                if e['duration']<.95:
                    continue
                p=e['pitch']-12
                proposed=dict(onset=e['onset'],duration=e['duration'],pitch=p)
                if any(x['pitch']==p and overlaps(proposed,x) for x in events):
                    continue
                add(events,n,e['onset']-start,e['duration'],p,e['velocity']-11,'melody_octave','right')

        # Honest half/full pedal values. Every moving-harmony pulse is cleared;
        # lower-register return uses the shallower value for intelligibility.
        depth=42 if tex in ('home','coda','bench') else 76
        pedals.extend([dict(onset=start,value=0),dict(onset=start+.045,value=depth)])
        if n!=144:
            pedals.extend([dict(onset=start+1.455,value=0),
                           dict(onset=start+1.545,value=42 if tex!='climax' else 76)])
    pedals.append(dict(onset=432.0,value=0))
    events.sort(key=lambda e:(e['onset'],e['hand'],e['pitch'],e['voice']))
    return dict(id=81,title='The Harbor of Folded Wings',title_zh='折翼港',
                version=f'v{version}',bars=bars,events=events,pedals=pedals,
                total_beats=432.0,tail_seconds=6)


def audit(s):
    es=s['events']
    issues=[]
    if len(s['bars'])!=144 or s['total_beats']!=432:
        issues.append('Incorrect form length')
    for e in es:
        if e['instrument']!='piano' or e['hand'] not in ('left','right'):
            issues.append(['schema',e])
        if not (0<=e['onset']<432 and 0<e['duration'] and e['onset']+e['duration']<=432):
            issues.append(['time',e])
    collisions=[]
    for p in range(128):
        group=sorted([e for e in es if e['pitch']==p],key=lambda e:e['onset'])
        for i,a in enumerate(group):
            for b in group[i+1:]:
                if b['onset']>=a['onset']+a['duration']-1e-7:
                    break
                if overlaps(a,b):
                    collisions.append(dict(pitch=p,bar=b['bar'],voices=[a['voice'],b['voice']]))
    hand_stats={}
    leap_exceptions=[]
    for hand in ('left','right'):
        ee=[e for e in es if e['hand']==hand]
        maxspan=0
        maxtime=0
        maxheld=0
        times=sorted(set(e['onset'] for e in ee))
        groups=[]
        for t in times:
            active=[e for e in ee if e['onset']<=t+1e-7 and e['onset']+e['duration']>t+1e-7]
            span=max(e['pitch'] for e in active)-min(e['pitch'] for e in active)
            maxheld=max(maxheld,len(active))
            if span>maxspan:
                maxspan,maxtime=span,t
            if span>12:
                issues.append(dict(kind='held_span',hand=hand,beat=t,span=span))
            attacks=sorted(e['pitch'] for e in ee if abs(e['onset']-t)<1e-7)
            groups.append((t,attacks))
        maxattackdistance=0
        for (t0,pp),(t1,qq) in zip(groups,groups[1:]):
            distance=min(abs(p-q) for p in pp for q in qq)
            maxattackdistance=max(maxattackdistance,distance)
            if distance>12:
                leap_exceptions.append(dict(hand=hand,from_beat=t0,to_beat=t1,
                                            semitones=distance,time_available_beats=round(t1-t0,3),
                                            note='Arm relocation between released positions; review contextual gap.'))
        hand_stats[hand]=dict(max_held_span_semitones=maxspan,at_beat=maxtime,
                              max_simultaneously_held_notes=maxheld,
                              max_nearest_attack_distance_semitones=maxattackdistance)
    phrase_reports=[]
    for end in range(8,145,8):
        melody=[e for e in es if e['voice']=='melody' and end-7<=e['bar']<=end]
        last=melody[-1]
        harmony=s['bars'][end-1]['harmony_name']
        chordtone=last['pitch']%12 in H[harmony][1]
        if not chordtone:
            issues.append(dict(kind='phrase_end_nonchord_tone',bar=end))
        remaining=end*3-(last['onset']+last['duration'])
        phrase_reports.append(dict(start_bar=end-7,end_bar=end,
                                   melody_notes=len(melody),pitch_range=[min(e['pitch'] for e in melody),max(e['pitch'] for e in melody)],
                                   final_harmony=harmony,final_pitch=last['pitch'],
                                   final_note_is_chord_tone=chordtone,
                                   breath_after_last_note_beats=round(remaining,3)))
    # Phrase-level cadence inventory distinguishes a genuine root resolution
    # from a tonic prolongation or an open dominant, rather than calling every
    # eighth bar a perfect cadence.
    cadence_types={8:'D minor: open dominant',16:'D minor: open dominant',
       24:'F major: V7–I, melody on tonic',32:'F major: open V',
       40:'D minor: V7–i, leading tone resolves in melody',
       48:'B-flat: V7–I, tonic delayed until the last short syllable',
       56:'G minor: V7–i, leading tone resolves in melody',
       64:'D minor: open dominant',72:'D minor: V7–i',
       80:'F major: V7–I with melody on third' if s['version']!='v0' else 'D minor: open dominant',
       88:'D minor: ii half-diminished–V7, withheld tonic',
       96:'D minor: V7–i',104:'F major: V7–I',112:'D major: V/V–V7',
       120:'D major: V7–I, tonic then fifth in melody',
       128:'D major: V7–I, melody on tonic',136:'D major: V7–I, melody on tonic',
       144:'D major: V7–I, final low tonic'}
    for p in phrase_reports:
        end=p['end_bar']
        p['cadence_intention']=cadence_types[end]
        p['approach_harmony']=s['bars'][end-2]['harmony_name']
    seconds=sum(3*60/b['bpm'] for b in s['bars'])
    melody=[e for e in es if e['voice']=='melody']
    fourths=[dict(from_bar=a['bar'],to_bar=b['bar'],pitches=[a['pitch'],b['pitch']])
             for a,b in zip(melody,melody[1:]) if b['pitch']-a['pitch']==5]
    melody_leaps=[dict(from_bar=a['bar'],to_bar=b['bar'],pitches=[a['pitch'],b['pitch']],
                      semitones=b['pitch']-a['pitch'],
                      onset_separation_beats=round(b['onset']-a['onset'],3),
                      released_gap_beats=round(b['onset']-a['onset']-a['duration'],3))
                  for a,b in zip(melody,melody[1:]) if abs(b['pitch']-a['pitch'])>12]
    if collisions:
        issues.append(dict(kind='same_key_overlap',count=len(collisions)))
    if set(p['value'] for p in s['pedals'])!={0,42,76} or s['pedals'][-1]!={'onset':432.0,'value':0}:
        issues.append('Pedal contract failed')
    report=dict(version=s['version'],pass_structural_checks=not issues,issues=issues,
                bars=144,meter='6/8',quarter_beats=432,event_count=len(es),
                music_seconds=round(seconds,3),tail_seconds=6,
                total_expected_seconds=round(seconds+6,3),
                pitch_range=[min(e['pitch'] for e in es),max(e['pitch'] for e in es)],
                hand_stats=hand_stats,same_key_overlaps=collisions,
                contextual_leaps_over_octave=leap_exceptions,
                melodic_leaps_over_octave=melody_leaps,
                rising_fourths_in_melody_count=len(fourths),rising_fourth_examples=fourths[:12],
                pedal_values=sorted(set(p['value'] for p in s['pedals'])),final_pedal_clear=True,
                phrases=phrase_reports,
                limitations=['Symbolic held spans measure key-down, not fingers stretched by sustained pedal.',
                             'The nearest simultaneous attack distance is a screening measure, not a fingering proof.',
                             'Cadence labels are explicit compositional intentions checked against exported notes/harmony.',
                             'No audio audition, render, Moonlight parameter change, or REAPER operation was performed here.'])
    return report


def canonical(x):
    return json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':'))


def diff(a,b):
    changes=[]
    for bar in range(1,145):
        aa=[e for e in a['events'] if e['bar']==bar]
        bb=[e for e in b['events'] if e['bar']==bar]
        ah=a['bars'][bar-1]['harmony_name']
        bh=b['bars'][bar-1]['harmony_name']
        if aa!=bb or ah!=bh:
            removed=list((Counter(canonical(e) for e in aa)-Counter(canonical(e) for e in bb)).elements())
            added=list((Counter(canonical(e) for e in bb)-Counter(canonical(e) for e in aa)).elements())
            def m(es):
                return [dict(onset=e['onset'],duration=e['duration'],pitch=e['pitch']) for e in es if e['voice']=='melody']
            changes.append(dict(bar=bar,harmony_before=ah,harmony_after=bh,
                                melody_before=m(aa),melody_after=m(bb),
                                removed_events=[json.loads(x) for x in removed],
                                added_events=[json.loads(x) for x in added]))
    pa=Counter(canonical(p) for p in a['pedals'])
    pb=Counter(canonical(p) for p in b['pedals'])
    return dict(from_version=a['version'],to_version=b['version'],changed_bars=[c['bar'] for c in changes],
                harmony_changed_bars=[c['bar'] for c in changes if c['harmony_before']!=c['harmony_after']],
                melody_changed_bars=[c['bar'] for c in changes if c['melody_before']!=c['melody_after']],
                removed_pedals=[json.loads(x) for x in (pa-pb).elements()],
                added_pedals=[json.loads(x) for x in (pb-pa).elements()],bar_changes=changes)


def write_json(name,x):
    (ROOT/name).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')


def main():
    scores=[score(i) for i in range(3)]
    audits=[]
    for s in scores:
        write_json(f"score_{s['version']}.json",s)
        a=audit(s)
        audits.append(a)
        write_json(f"audit_{s['version']}.json",a)
        if not a['pass_structural_checks']:
            raise RuntimeError(f"{s['version']} audit failed: {a['issues']}")
    write_json('score.json',scores[2])
    revisions=[diff(scores[0],scores[1]),diff(scores[1],scores[2])]
    write_json('revision_diff.json',revisions)
    form=[]
    elapsed=0.0
    bounds=[(1,8),(9,24),(25,40),(41,56),(57,72),(73,88),(89,104),(105,120),(121,136),(137,144)]
    for lo,hi in bounds:
        seconds=sum(180/b['bpm'] for b in scores[2]['bars'][lo-1:hi])
        form.append(dict(start_bar=lo,end_bar=hi,start_seconds=round(elapsed,3),
                         end_seconds=round(elapsed+seconds,3),
                         section=scores[2]['bars'][lo-1]['section'],
                         tempo_quarter_range=[min(b['bpm'] for b in scores[2]['bars'][lo-1:hi]),max(b['bpm'] for b in scores[2]['bars'][lo-1:hi])]))
        elapsed+=seconds
    write_json('form.json',form)
    manifest={p.name:hashlib.sha256(p.read_bytes()).hexdigest()
              for p in sorted(ROOT.glob('score*.json'))}
    write_json('score_sha256.json',manifest)
    notation=[]
    for n,r in enumerate(compose_rows(2),1):
        notation.append(f"{n:03d} | {r['harmony']:<7} | {r['notation']:<41} | {r['section']}")
    (ROOT/'melody_v2.txt').write_text('Durations: eighth-note units; R: rest; six units per bar.\n'+ '\n'.join(notation)+'\n',encoding='utf-8')
    print(json.dumps(dict(output=str(ROOT),events=[len(s['events']) for s in scores],
                          seconds=audits[2]['total_expected_seconds'],
                          v2_hands=audits[2]['hand_stats'],
                          contextual_leaps=audits[2]['contextual_leaps_over_octave'],
                          revisions=[{k:d[k] for k in ('from_version','to_version','changed_bars','harmony_changed_bars','melody_changed_bars')} for d in revisions]),
                     ensure_ascii=False,indent=2))


if __name__=='__main__':
    main()
