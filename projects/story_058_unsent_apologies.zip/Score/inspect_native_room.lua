local root='PRODUCTION_ROOT/058_unsent_apologies'
local function run()
 reaper.InsertTrackAtIndex(0,true)
 local tr=reaper.GetTrack(0,0)
 reaper.GetSetMediaTrackInfo_String(tr,'P_NAME','Native room-effect inspection only',true)
 local fx=reaper.TrackFX_AddByName(tr,'ReaVerbate (Cockos)',false,-1)
 assert(fx>=0,'Bundled ReaVerbate not available')
 local f=assert(io.open(root..'/revisions/native_room_parameters.tsv','w'))
 for i=0,reaper.TrackFX_GetNumParams(tr,fx)-1 do
  local ok,name=reaper.TrackFX_GetParamName(tr,fx,i,'')
  local value,min,max=reaper.TrackFX_GetParam(tr,fx,i)
  f:write(i..'\t'..name..'\t'..value..'\t'..min..'\t'..max..'\t'..reaper.TrackFX_GetParamNormalized(tr,fx,i)..'\n')
 end
 f:close();reaper.Main_SaveProjectEx(0,root..'/revisions/native_room_inspection.rpp',0)
 reaper.Main_OnCommand(40004,0)
end
local ok,err=xpcall(run,debug.traceback)
if not ok then local f=io.open(root..'/revisions/native_room_error.txt','w');f:write(err);f:close();reaper.Main_SaveProjectEx(0,root..'/revisions/native_room_failed.rpp',0);reaper.Main_OnCommand(40004,0)end
