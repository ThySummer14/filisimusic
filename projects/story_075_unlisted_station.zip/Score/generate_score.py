#!/usr/bin/env python3
"""075: original, hand-composed solo piano. Python standard library only.
Rebuild all compositional stages, exact diffs, and mechanical audits with:
    python3 generate_score.py
No random source, audio, dependencies, reference-score import, or rendering.
Melody rows below were written for this story, not sampled from existing music.
A token is pitch:quarter-beat-duration; R is an explicitly composed rest.
"""
from pathlib import Path
import json, math, difflib, hashlib, collections
ROOT=Path(__file__).resolve().parent
PCS={'C':0,'D':2,'E':4,'F':5,'G':7,'A':9,'B':11}
def pitch(name):
    if name=='R': return None
    head=name[:-1]; octave=int(name[-1]); n=PCS[head[0]]
    if len(head)>1: n+= {'#':1,'b':-1}[head[1]]
    return 12*(octave+1)+n
# Harmonic descriptions are labels, never instructions to strike every listed note.
H={
 'Em':(40,[52,55,59]), 'Em/D':(38,[52,55,59]), 'Em/G':(43,[52,55,59]),
 'C':(36,[48,52,55]), 'Cmaj7':(36,[48,52,55,59]), 'C/E':(40,[48,52,55]),
 'Am':(45,[48,52,57]), 'Am/C':(48,[52,57,60]),
 'B7':(47,[51,54,57,59]), 'B7/F#':(42,[51,54,57,59]),
 'B7sus4':(47,[52,54,57,59]), 'G':(43,[50,55,59]), 'G/B':(47,[50,55,59]),
 'D':(38,[50,54,57]), 'D/F#':(42,[50,54,57]), 'D7':(38,[48,50,54,57]),
 'Dsus4':(38,[50,55,57]), 'F#dim':(42,[48,54,57]),
 'C/D':(38,[48,52,55]), 'A7':(45,[49,52,55]), 'A':(45,[49,52,57]),
 'E':(40,[52,56,59]), 'E/G#':(44,[52,56,59]), 'E/B':(47,[52,56,59]),
 'C#m':(49,[52,56,61]), 'F#m':(42,[49,54,57]), 'F#m/A':(45,[49,54,57]),
 'F#m7':(42,[49,52,54,57]), 'Aadd9':(45,[49,52,57,59]),
}
# Handwritten opening: a cut-off departure-call, then an 8th-note engine answers.
INTRO=[
 ('Em','R:1 B4:0.5 E5:0.5 G5:1 F#5:0.5 R:0.5'),
 ('Em/D','E5:1.5 B4:0.5 D5:0.5 E5:0.5 R:1'),
 ('Cmaj7','G5:1 E5:0.5 D5:0.5 B4:1 E5:0.5 G5:0.5'),
 ('B7','F#5:1 D#5:0.5 F#5:0.5 A5:1 R:1'),
 ('Em','B4:0.5 E5:0.5 G5:1 F#5:0.5 E5:0.5 B4:1'),
 ('Am','C5:1 E5:0.5 A5:0.5 G5:1 E5:0.5 D5:0.5'),
 ('C','E5:0.5 G5:0.5 A5:0.5 G5:0.5 E5:1 D5:0.5 C5:0.5'),
 ('B7','B4:0.5 D#5:0.5 F#5:1 A5:0.5 F#5:0.5 R:1'),
]
# The main theme has an 8-bar breath and a 24-bar journey; it is not a loop.
JOURNEY=[
 ('Em','E5:1 G5:0.5 F#5:0.5 B5:1.5 A5:0.5'),
 ('Cmaj7','G5:1.5 F#5:0.5 E5:1 D5:0.5 E5:0.5'),
 ('G/B','B5:1 A5:0.5 G5:0.5 D6:1 B5:0.5 A5:0.5'),
 ('D','F#5:1.5 E5:0.5 D5:1 A5:1'),
 ('Am','C6:1 B5:0.5 A5:0.5 E5:1 G5:0.5 A5:0.5'),
 ('Em/G','B5:1.5 G5:0.5 F#5:0.5 E5:0.5 G5:1'),
 ('F#dim','A5:0.5 G5:0.5 F#5:1 C5:0.5 D5:0.5 F#5:0.5 A5:0.5'),
 ('B7','G5:0.5 F#5:0.5 D#5:1 B4:1 R:1'),
 ('Em','G5:1 B5:0.5 A5:0.5 E6:1 D6:0.5 B5:0.5'),
 ('C','C6:1.5 B5:0.5 G5:1 E5:0.5 G5:0.5'),
 ('Am/C','A5:0.5 B5:0.5 C6:1 B5:0.5 A5:0.5 E5:1'),
 ('D/F#','F#5:1 A5:0.5 G5:0.5 F#5:1 E5:0.5 D5:0.5'),
 ('G','B5:1 A5:0.5 G5:0.5 D6:1.5 C6:0.5'),
 ('C/E','B5:0.5 A5:0.5 G5:1 E5:1 G5:0.5 E5:0.5'),
 ('B7sus4','F#5:0.5 G5:0.5 A5:1 F#5:0.5 E5:0.5 D#5:0.5 F#5:0.5'),
 ('B7','B5:2 A5:0.5 F#5:0.5 R:1'),
 ('Em','G5:0.5 F#5:0.5 E5:1 B5:1 A5:0.5 G5:0.5'),
 ('Em/D','F#5:0.5 E5:0.5 D5:1 G5:0.5 F#5:0.5 E5:1'),
 ('Cmaj7','E5:1 B5:1 G5:0.5 A5:0.5 B5:1'),
 ('G/B','D6:1 B5:0.5 A5:0.5 G5:1 D5:1'),
 ('Am','E5:0.5 G5:0.5 A5:1 C6:1 B5:0.5 A5:0.5'),
 ('F#dim','C6:0.5 A5:0.5 F#5:1 E5:0.5 D5:0.5 C5:1'),
 ('B7','D#5:0.5 F#5:0.5 A5:0.5 B5:0.5 D#6:1 F#5:1'),
 ('Em','G5:0.5 F#5:0.5 E5:2 R:1'),
]
# v0's first statement: deliberately more square, replaced rather than merely sped up.
V0_MAIN8=[
 ('Em','E5:1 G5:1 B5:1 A5:1'), ('C','G5:1 E5:1 G5:1 E5:1'),
 ('G/B','D6:1 B5:1 A5:1 G5:1'), ('D','F#5:1 E5:1 D5:1 R:1'),
 ('Am','A5:1 C6:1 B5:1 A5:1'), ('Em/G','G5:1 E5:1 B5:1 G5:1'),
 ('B7','F#5:0.5 A5:0.5 F#5:1 D#5:1 B4:1'), ('Em','E5:3 R:1'),
]
# Junction: motivic contraction, offset entries, and only three short 16th-note runs.
JUNCTION=[
 ('C','R:0.5 E5:0.5 G5:0.5 F#5:0.5 E5:0.5 D5:0.5 C5:1'),
 ('D','R:0.5 F#5:0.5 A5:0.5 G5:0.5 F#5:1 D5:0.5 A4:0.5'),
 ('Em','B4:0.5 E5:0.5 G5:0.5 B5:0.5 A5:0.5 G5:0.5 F#5:0.5 E5:0.5'),
 ('B7','D#5:1 F#5:0.5 A5:0.5 B5:1 R:1'),
 ('C','E5:0.25 F#5:0.25 G5:0.25 A5:0.25 B5:1 G5:1 E5:1'),
 ('C/D','D5:0.5 E5:0.5 G5:1 A5:0.5 G5:0.5 E5:1'),
 ('G/B','D5:1 G5:0.5 A5:0.5 B5:1 D6:0.5 B5:0.5'),
 ('Am','C6:1 A5:0.5 G5:0.5 E5:1 R:1'),
 ('Em/G','B5:0.5 G5:0.5 E5:0.5 F#5:0.5 G5:1 B5:1'),
 ('F#dim','C6:0.5 A5:0.5 F#5:0.5 E5:0.5 D5:1 C5:1'),
 ('B7/F#','D#5:0.25 E5:0.25 F#5:0.25 G5:0.25 A5:1 B5:0.5 A5:0.5 F#5:1'),
 ('B7','D#6:1 B5:0.5 A5:0.5 F#5:1 R:1'),
 ('Em','E5:0.5 F#5:0.5 G5:0.5 B5:0.5 E6:1 D6:0.5 B5:0.5'),
 ('D7','A5:0.25 B5:0.25 C6:0.25 D6:0.25 F#5:1 A5:0.5 G5:0.5 F#5:1'),
 ('Cmaj7','E5:1 G5:0.5 F#5:0.5 E5:1 B4:1'),
 ('D7','D5:1 F#5:0.5 A5:0.5 C6:0.5 A5:0.5 R:1'),
]
# Tree theme: G-B-A-D reverses the departure motive's gravitational pull.
# Its first six-bar sentence is answered by six, then an eight-bar practical-work scene.
TREE=[
 ('G','G5:1.5 B5:0.5 A5:1 D5:1'),
 ('D/F#','F#5:2 E5:0.5 D5:0.5 A4:1'),
 ('Em','B4:1 E5:1 G5:1.5 F#5:0.5'),
 ('Cmaj7','E5:1 G5:1 B5:1 A5:1'),
 ('Am','C6:1.5 B5:0.5 A5:1 E5:1'),
 ('D7','F#5:1 A5:1 D5:1 R:1'),
 ('G/B','B5:1.5 D6:0.5 C6:1 G5:1'),
 ('C','E5:1 G5:0.5 A5:0.5 G5:1 E5:1'),
 ('Am/C','A5:2 G5:0.5 E5:0.5 C5:1'),
 ('G','D5:1 G5:1 B5:1 D6:1'),
 ('D7','C6:1 A5:0.5 G5:0.5 F#5:1 A5:1'),
 ('G','G5:2 D5:1 R:1'),
 ('C','E5:1 G5:0.5 A5:0.5 C6:1 B5:0.5 A5:0.5'),
 ('D','F#5:1 A5:1 D6:1 C6:0.5 A5:0.5'),
 ('G/B','B5:1 D6:0.5 B5:0.5 A5:1 G5:1'),
 ('Em','G5:1 B5:1 E6:1.5 D6:0.5'),
 ('Am','C6:1 B5:0.5 A5:0.5 G5:1 E5:1'),
 ('D7','F#5:1 A5:0.5 C6:0.5 B5:0.5 A5:0.5 F#5:1'),
 ('G','G5:2 B5:0.5 A5:0.5 G5:0.5 E5:0.5'),
 ('B7','F#5:1 D#5:1 B4:1 R:1'),
]
TREE_V0=[
 ('G','G5:2 B5:1 A5:1'), ('D','F#5:2 D5:2'),
 ('Em','E5:2 G5:1 B5:1'), ('C','G5:2 E5:1 R:1'),
 ('Am','A5:2 C6:1 B5:1'), ('D','A5:1 F#5:1 D5:1 R:1'),
 ('G/B','B5:2 A5:1 G5:1'), ('C','E5:2 G5:2'),
 ('Am','A5:1 G5:1 E5:1 C5:1'), ('D7','F#5:2 A5:2'),
 ('G','G5:2 D5:1 B4:1'), ('B7','D#5:1 F#5:1 B4:1 R:1'),
]
RETURN=[
 ('Em','E5:0.5 G5:0.5 F#5:1 B5:1 A5:0.5 G5:0.5'),
 ('Cmaj7','B5:1 G5:0.5 E5:0.5 G5:1 A5:0.5 B5:0.5'),
 ('Am','C6:1 A5:0.5 G5:0.5 E5:1 C5:0.5 E5:0.5'),
 ('B7','F#5:0.5 A5:0.5 B5:1 D#6:1 R:1'),
 ('Em','E6:1 B5:0.5 A5:0.5 G5:1 F#5:0.5 E5:0.5'),
 ('G/B','D5:0.5 G5:0.5 B5:1 A5:0.5 G5:0.5 D6:1'),
 ('A7','C#6:1 B5:0.5 A5:0.5 G5:1 E5:1'),
 ('D','F#5:1 A5:0.5 G5:0.5 F#5:1 R:1'),
 ('F#m','F#5:0.5 A5:0.5 C#6:1 B5:0.5 A5:0.5 F#5:1'),
 ('A','E5:0.5 A5:0.5 C#6:1 E6:1 C#6:0.5 B5:0.5'),
 ('B7sus4','E6:1 B5:0.5 A5:0.5 F#5:0.5 E5:0.5 F#5:1'),
 ('B7','D#6:1 B5:0.5 A5:0.5 F#5:1 R:1'),
]
# v1 final section, before the station really earns its arrival.
ARRIVAL_V1=[
 ('E','E5:1 G#5:0.5 F#5:0.5 B5:1 A5:1'),
 ('A','A5:1 G#5:1 E5:1 C#5:1'),
 ('C#m','G#5:1 B5:0.5 C#6:0.5 E6:1 D#6:1'),
 ('B7','D#6:1 B5:1 A5:1 F#5:1'),
 ('F#m','A5:1 C#6:1 B5:1 A5:1'),
 ('A','E6:1 C#6:1 B5:1 A5:1'),
 ('B7','F#5:0.5 A5:0.5 B5:1 D#6:1 B5:1'),
 ('E','G#5:2 E5:1 R:1'),
 ('E/G#','B5:1 G#5:1 E5:1 G#5:1'),
 ('A','C#6:1 B5:1 A5:1 E5:1'),
 ('F#m','A5:1 F#5:1 C#6:1 B5:1'),
 ('B7','D#6:2 B5:1 A5:1'),
 ('E','G#5:1 B5:1 E6:1 D#6:1'),
 ('A','C#6:1 A5:1 E5:1 A5:1'),
 ('B7','B5:1 A5:0.5 F#5:0.5 D#5:1 F#5:1'),
 ('E','G#5:1 F#5:0.5 E5:0.5 E5:1 R:1'),
]
# v2 rewrites all 20 bars: arrival theme, tree-theme graft, interrupted cadence,
# four-bar completion. Its brief F#6 approach resolves to the earned E6 arrival.
ARRIVAL=[
 ('E','E5:1 G#5:0.5 F#5:0.5 B5:1.5 A5:0.5'),
 ('Aadd9','G#5:1.5 F#5:0.5 E5:1 C#5:0.5 E5:0.5'),
 ('E/G#','B5:1 A5:0.5 G#5:0.5 E6:1 D#6:0.5 B5:0.5'),
 ('B7','A5:1 F#5:0.5 E5:0.5 D#5:1 B5:1'),
 ('F#m','C#6:1 B5:0.5 A5:0.5 E5:1 F#5:0.5 A5:0.5'),
 ('C#m','G#5:1 B5:0.5 C#6:0.5 E6:1.5 D#6:0.5'),
 ('A','C#6:0.5 B5:0.5 A5:1 G#5:0.5 F#5:0.5 E5:1'),
 ('B7','F#5:1 D#5:0.5 F#5:0.5 B5:1 R:1'),
 ('E','G#5:1.5 B5:0.5 A5:1 E5:1'),
 ('A','C#6:1.5 E6:0.5 D#6:1 A5:1'),
 ('F#m7','C#6:1 B5:0.5 A5:0.5 F#5:1 E5:1'),
 ('B7','D#5:1 F#5:0.5 A5:0.5 B5:1 D#6:1'),
 ('E','E6:1.5 D#6:0.5 B5:0.5 A5:0.5 G#5:1'),
 ('A','C#6:1 B5:0.5 A5:0.5 E6:1 C#6:0.5 B5:0.5'),
 ('B7','A5:0.5 G#5:0.5 F#5:1 D#6:1 B5:1'),
 ('C#m','C#6:2 G#5:1 R:1'),
 ('F#m','A5:1 C#6:0.5 B5:0.5 A5:1 F#5:1'),
 ('A','E6:1 C#6:0.5 B5:0.5 A5:0.5 G#5:0.5 F#5:0.5 E5:0.5'),
 ('B7','D#5:0.5 F#5:0.5 A5:1 B5:0.5 D#6:0.5 F#6:0.5 D#6:0.5'),
 ('E','E6:2 B5:1 R:1'),
]
CODA_V1=[
 ('A','C#6:1 B5:1 A5:1 E5:1'), ('E/G#','G#5:1 B5:1 E5:2'),
 ('F#m','F#5:1 A5:1 C#6:1 B5:1'), ('B7','A5:1 F#5:1 D#5:1 R:1'),
 ('E','E5:2 G#5:1 B5:1'), ('A','C#6:1 B5:1 A5:2'),
 ('B7','F#5:1 D#5:1 B4:1 R:1'), ('E','E5:4'),
]
CODA=[
 ('A','C#6:1.5 B5:0.5 A5:1 E5:1'),
 ('E/G#','G#5:1 B5:0.5 A5:0.5 G#5:1 E5:1'),
 ('F#m7','A5:1 C#6:0.5 B5:0.5 A5:1 F#5:1'),
 ('B7','D#5:1 F#5:0.5 A5:0.5 B5:1 R:1'),
 ('E/B','E6:1.5 D#6:0.5 B5:1 G#5:1'),
 ('A','C#6:1 B5:0.5 A5:0.5 E5:1 C#5:1'),
 ('B7','D#5:0.5 F#5:0.5 A5:1 F#5:0.5 D#5:0.5 B4:0.5 R:0.5'),
 ('E','E5:4'),
]

def row_events(row):
    elapsed=0.; result=[]
    for token in row.split():
        p,d=token.split(':'); d=float(d)
        result.append((elapsed,d,pitch(p))); elapsed+=d
    assert abs(elapsed-4)<1e-9,(row,elapsed)
    return result

def arrangement(version):
    main=JOURNEY if version else V0_MAIN8+JOURNEY[8:]
    tree=TREE if version else TREE_V0
    returning=RETURN if version else RETURN[:8]
    arrival=ARRIVAL if version==2 else ARRIVAL_V1
    coda=CODA if version==2 else CODA_V1
    blocks=[('intro','缺站的里程牌',INTRO,132,58),
            ('journey','沿旧线向东',main,138,78),
            ('junction','岔道与刹车',JUNCTION,142,85),
            ('tree','接活的榉树',tree,108,66),
            ('return','运来泥土与站牌',returning,136,83),
            ('arrival','第一班停靠列车',arrival,144,94),
            ('coda','站名写回时刻表',coda,120,76)]
    return blocks

def generate(version):
    bars=[]; events=[]; pedals=[]; cursor=0.; barno=1
    def add(on,d,p,v,voice,bar):
        if p is None or d<=0: return
        events.append({'bar':bar,'onset':round(on,5),'duration':round(d,5),
            'pitch':int(p),'velocity':int(max(25,min(110,v))),
            'voice':voice,'instrument':'piano'})
    for kind,label,rows,bpm,dyn in arrangement(version):
        for i,(h,melrow) in enumerate(rows):
            if kind=='coda': tempo=[132,128,124,120,112,104,88,72][i]
            elif kind=='tree' and i==len(rows)-1: tempo=112
            elif kind=='junction' and i>=14: tempo=[134,126][i-14]
            elif kind=='intro' and i<2: tempo=126
            else: tempo=bpm
            root,ch=H[h]; phrase=i%8
            # Explicit contour: arrival has two waves, not a monotonically rising velocity ramp.
            contour=[-3,0,3,0,2,5,2,-4][phrase]
            if kind=='tree': contour=[-3,-1,1,2,3,-3][i%6]
            if kind=='arrival': contour=[-2,0,3,-1,2,4,0,-4,0,2,1,4,6,3,1,-5,1,5,7,2][i]
            if kind=='coda': contour=[2,0,-2,-1,-4,-7,-10,-13][i]
            base=dyn+contour
            bars.append({'bar':barno,'start':cursor,'beats':4.,'bpm':tempo,
                'section':label,'meter_numerator':4,'meter_denominator':4,
                'harmony_name':h,'harmony':ch,'role_plan':{
                 'intro':'右手动机留下未完句；左手从断续单音渐成八分音符推进。',
                 'journey':'右手二十四小节长线歌唱；左手低音与分解和弦为同一推进动作。',
                 'junction':'右手短动机换位和少量十六分转折；左手在共同句尾刹车。',
                 'tree':'右手六加六加八小节的新主题；左手稀疏滚动和弦，踏板随和声换。',
                 'return':'种树主题的上行三度进入列车节奏，分层增加而非只提速。',
                 'arrival':'主旋律大调改写，并嫁接树主题；右手同拍内声，不设第二条竞争旋律。',
                 'coda':'车轮分解逐渐化成整拍和弦；全曲动机在低一八度的明确主和弦上落定。'}[kind],
                'lead_instrument':'piano'})
            raw=row_events(melrow)
            if kind=='tree': raw=[(off,length,None if p is None else p-12) for off,length,p in raw]
            # Release both hands at terminal rests of a composed phrase.
            breath_start=4.
            if raw[-1][2] is None: breath_start=raw[-1][0]
            for n,(off,length,p) in enumerate(raw):
                if p is None: continue
                if kind=='coda' and i==7: duration=3.95
                else:
                    gap=0.04 if length<=0.5 else (0.08 if length<=1 else 0.11)
                    duration=length-gap
                # Human-readable phrasing without random timing or machine-like accent at every beat.
                v=base+(2 if off==0 else 0)+(1 if length>=1.5 else 0)- (3 if length==0.25 else 0)
                if kind=='junction' and off%1: v-=2
                add(cursor+off,duration,p,v,'melody',barno)
                # Voice the main line in thirds/sixths only on selected harmonic arrivals.
                support=(kind in ('arrival','return') and length>=0.75 and off in (0.,2.))
                support|=(kind=='journey' and i>=8 and i%4!=3 and length>=1 and off==0)
                support|=(kind=='tree' and i in (3,6,9,12,15,18) and off==0)
                support|=(kind=='coda' and off==0)
                if version==0 and kind in ('tree','arrival'): support=False
                if support:
                    chordpcs={n%12 for n in ch}
                    candidates=[q for q in range(max(60,p-9),p-2) if q%12 in chordpcs]
                    if candidates:
                        q=min(candidates,key=lambda x:abs((p-x)-5))
                        # Support duration never crosses the next melody attack: no false counterpoint.
                        add(cursor+off,min(duration,0.88 if kind!='coda' else duration),q,v-16,'upper_support',barno)
            if kind=='coda' and i==7 and version==2:
                add(cursor,3.95,68,base-16,'upper_support',barno)
            # Left hand: a single composite train figure, never an autonomous bass tune.
            chordpcs={n%12 for n in ch}
            low=[q for q in range(root+3,min(root+17,62)) if q%12 in chordpcs]
            if len(low)<3: low=[q for q in range(root+1,62) if q%12 in chordpcs]
            lower=low[0]; mid=low[len(low)//2]; upper=low[-1]
            if kind=='tree':
                slots=[(0,root,1.0,'bass'),(.75,lower,.61,'accompaniment'),
                       (1.5,mid,.46,'accompaniment'),(2,upper,.78,'accompaniment'),
                       (3,mid,.65,'accompaniment')]
                if i in (4,10,14,16,17,18): slots.append((3.5,lower,.42,'accompaniment'))
                if version==0: slots=[(0,root,.88,'bass'),(1,lower,.8,'accompaniment'),(2,mid,.8,'accompaniment'),(3,lower,.7,'accompaniment')]
            elif kind=='coda':
                if i<3:
                    slots=[(0,root,.43,'bass'),(.5,lower,.43,'accompaniment'),(1,mid,.43,'accompaniment'),
                           (1.5,upper,.43,'accompaniment'),(2,root,.6,'bass'),(3,mid,.8,'accompaniment')]
                elif i<7:
                    slots=[(0,root,.9,'bass'),(1,lower,.72,'accompaniment'),(2,mid,.85,'accompaniment'),(3,lower,.72,'accompaniment')]
                else:
                    slots=[(0,40,3.95,'bass'),(0,47,3.95,'accompaniment'),(0,52,3.95,'accompaniment')]
            elif kind=='intro' and i<2:
                slots=[(0,root,.43,'bass'),(.5,lower,.43,'accompaniment'),(2,mid,.43,'accompaniment'),(2.5,lower,.43,'accompaniment')]
            else:
                # Three different broken-chord trajectories alternate with phrase rhetoric,
                # but different harmony, melody, accents and breaths define each bar.
                if i%3==0: seq=[root,lower,mid,upper,root,mid,upper,lower]
                elif i%3==1: seq=[root,mid,lower,upper,root,lower,upper,mid]
                else: seq=[root,lower,upper,mid,root,upper,mid,lower]
                slots=[(j/2,q,.43,'bass' if j in (0,4) else 'accompaniment') for j,q in enumerate(seq)]
                # Brief 16th pickup resides in ONE hand, with no independent bass line.
                if kind=='return' and i in (8,10):
                    slots=slots[:7]+[(3.5,lower,.21,'accompaniment'),(3.75,mid,.21,'accompaniment')]
            for off,p,d,voice in slots:
                if off>=breath_start: continue
                d=min(d,breath_start-off-0.045)
                # Keep a shared physical piano key in one hand, including the middle's lower register.
                occupied={e['pitch'] for e in events if e['voice'] in ('melody','upper_support') and e['onset']<cursor+off+d and e['onset']+e['duration']>cursor+off}
                if p in occupied:
                    alternatives=[q for q in low if q not in occupied and q!=root]
                    if not alternatives: continue
                    p=min(alternatives,key=lambda q:abs(q-p))
                v=base-24+(7 if voice=='bass' else 0)+(2 if off in (1.5,3) else 0)
                if kind=='tree': v-=3
                add(cursor+off,d,p,v,voice,barno)
            # Sustain clears every half-bar; positive MIDI CC64 values exceed the usual 64 threshold.
            # No reverb, synthetic instrument, or audio treatment is specified here.
            # Every breath gets a release; arrival is played with stronger fingers, not blur.
            if kind=='tree':
                pedal_points=[(0.,0),(.06,78),(1.92,0),(2.04,74),(min(3.90,breath_start-.06),0)]
            elif kind=='coda' and i==7:
                pedal_points=[(0.,0),(.07,90),(3.98,0)]
            else:
                value=68 if kind in ('journey','junction','return') else 74
                pedal_points=[(0.,0),(.04,value),(1.86,0),(2.04,value),(min(3.90,breath_start-.06),0)]
            for off,value in pedal_points:
                if off>=breath_start and value: continue
                pedals.append({'onset':round(cursor+max(0,off),5),'value':value})
            cursor+=4.; barno+=1
    # Supports may not overlap ANY new attack of the same key. Truncate only this optional voice.
    melodies=[e for e in events if e['voice']=='melody']
    for s in events:
        if s['voice']!='upper_support': continue
        for e in melodies:
            if e['pitch']!=s['pitch']: continue
            if e['onset']<s['onset']+s['duration'] and e['onset']+e['duration']>s['onset']:
                if e['onset']<=s['onset']: s['duration']=0
                else: s['duration']=max(0,e['onset']-s['onset']-.03)
    events=[e for e in events if e['duration']>.03]
    events.sort(key=lambda e:(e['onset'],e['pitch'],e['voice']))
    # At any timestamp, a release wins over a redundant depression.
    pp={}
    for x in pedals: pp[x['onset']]=min(pp.get(x['onset'],127),x['value'])
    pedals=[{'onset':k,'value':v} for k,v in sorted(pp.items())]
    pedals.append({'onset':cursor,'value':0})
    return {'id':75,'title':'The Station Outside the Timetable','title_zh':'时刻表之外的车站',
        'bars':bars,'events':events,'pedals':pedals,'total_beats':cursor,'tail_seconds':4}

def audit(s):
    ev=s['events']; overlaps=[]; spans={'left':0,'right':0}; worst={}; notes_by_pitch=collections.defaultdict(list)
    for e in ev: notes_by_pitch[e['pitch']].append(e)
    for p,ee in notes_by_pitch.items():
        ee.sort(key=lambda x:x['onset'])
        for a,b in zip(ee,ee[1:]):
            if a['onset']+a['duration']>b['onset']+1e-7:
                overlaps.append({'pitch':p,'first':a,'second':b})
    for hand,vs in [('left',{'bass','accompaniment'}),('right',{'melody','upper_support'})]:
        he=[e for e in ev if e['voice'] in vs]
        for t in sorted(set(e['onset'] for e in he)):
            live=[e for e in he if e['onset']<=t+1e-7 and e['onset']+e['duration']>t+1e-7]
            span=max(e['pitch'] for e in live)-min(e['pitch'] for e in live)
            if span>spans[hand]: spans[hand]=span;worst[hand]={'time':t,'pitches':[e['pitch'] for e in live]}
    duration=sum(b['beats']*60/b['bpm'] for b in s['bars'])+s['tail_seconds']
    sections=[]
    for name,g in __import__('itertools').groupby(s['bars'],key=lambda b:b['section']):
        bb=list(g); sections.append({'section':name,'first_bar':bb[0]['bar'],'last_bar':bb[-1]['bar'],'seconds':round(sum(b['beats']*60/b['bpm'] for b in bb),3)})
    signatures=[]
    for b in s['bars']:
        es=[e for e in ev if e['bar']==b['bar']]
        signatures.append(tuple((round(e['onset']-b['start'],3),e['duration'],e['pitch'],e['voice']) for e in es))
    repeated_windows=[]
    for n in (2,4,8):
        dic=collections.defaultdict(list)
        for i in range(len(signatures)-n+1):dic[tuple(signatures[i:i+n])].append(i+1)
        repeated_windows.extend({'bars_per_window':n,'starts':ii} for ii in dic.values() if len(ii)>1)
    melody=[e for e in ev if e['voice']=='melody']
    a={'bar_count':len(s['bars']),'events':len(ev),'total_beats':s['total_beats'],
       'duration_including_4s_tail_seconds':round(duration,3),'duration_mm_ss':f'{int(duration//60)}:{duration%60:05.2f}',
       'pitch_range':[min(e['pitch'] for e in ev),max(e['pitch'] for e in ev)],
       'melody_range':[min(e['pitch'] for e in melody),max(e['pitch'] for e in melody)],
       'velocity_range':[min(e['velocity'] for e in ev),max(e['velocity'] for e in ev)],
       'voices':dict(collections.Counter(e['voice'] for e in ev)),
       'identical_key_overlaps':overlaps,'maximum_simultaneous_hand_spans':spans,'worst_span_evidence':worst,
       'events_outside_form':[e for e in ev if e['onset']<0 or e['onset']+e['duration']>s['total_beats']+1e-8],
       'invalid_events':[e for e in ev if e['duration']<=0 or not 0<e['velocity']<128 or e['instrument']!='piano'],
       'exact_repeated_multi_bar_windows_ignoring_velocity':repeated_windows,'sections':sections,
       'sixteenth_melody_events':len([e for e in melody if e['duration']<.25]),
       'quality_caveat':'These are structural and mechanical checks, not a listening evaluation or a claim of artistic quality.'}
    a['pass']=not overlaps and max(spans.values())<=12 and not a['events_outside_form'] and not a['invalid_events']
    return a

def write_json(path,data):path.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')

def main():
    scores=[]; audits=[]
    for v in range(3):
        s=generate(v); a=audit(s)
        assert a['pass'],json.dumps(a,ensure_ascii=False)
        write_json(ROOT/f'score_v{v}.json',s);write_json(ROOT/f'audit_v{v}.json',a)
        scores.append(s);audits.append(a)
    write_json(ROOT/'score.json',scores[-1]);write_json(ROOT/'audit.json',audits[-1])
    summaries=[]
    for v in range(2):
        f0=ROOT/f'score_v{v}.json'; f1=ROOT/f'score_v{v+1}.json'
        diff=''.join(difflib.unified_diff(f0.read_text().splitlines(True),f1.read_text().splitlines(True),fromfile=f0.name,tofile=f1.name))
        (ROOT/f'score_v{v}_to_v{v+1}.diff').write_text(diff,encoding='utf-8')
        a,b=scores[v],scores[v+1]
        canon=lambda e:(e['bar'],e['onset'],e['duration'],e['pitch'],e['velocity'],e['voice'])
        ea=set(map(canon,a['events']));eb=set(map(canon,b['events']))
        summaries.append({'from':v,'to':v+1,'bars_before':len(a['bars']),'bars_after':len(b['bars']),
            'events_removed_or_rewritten':len(ea-eb),'events_added_or_rewritten':len(eb-ea),
            'duration_before':audits[v]['duration_including_4s_tail_seconds'],
            'duration_after':audits[v+1]['duration_including_4s_tail_seconds'],
            'exact_diff':f'score_v{v}_to_v{v+1}.diff'})
    write_json(ROOT/'revision_diff_audit.json',summaries)
    checksums={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(ROOT.glob('score*.json')) if p.name!='score_sha256.json'}
    write_json(ROOT/'score_sha256.json',checksums)
    print(json.dumps({'final':audits[-1],'revisions':summaries},ensure_ascii=False,indent=2))
if __name__=='__main__':main()
