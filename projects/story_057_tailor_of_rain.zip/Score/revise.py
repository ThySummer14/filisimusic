import pathlib,json,copy,collections
P=pathlib.Path(__file__).parent;v1=json.loads((P/'revisions/score_v0.json').read_text());v1['stage']='v1_prologue_and_unpicking_harmonic_arrival'
intro=[[(69,.25),(72,.25),(71,.25),(72,.25),(76,.25),(74,.25),(72,.5),(-1,2)],[(69,.25),(74,.25),(73,.25),(74,.25),(77,.25),(76,.25),(74,.5),(-1,2)],[(67,.5),(72,.5),(76,1),(74,.5),(72,.5),(67,1)],[(68,.5),(71,.5),(76,1),(74,.5),(71,.5),(68,1)],[(74,.5),(72,.5),(69,1),(65,1),(62,1)],[(68,.5),(71,.5),(74,1),(76,1),(71,.5),(-1,.5)]]
v1['events']=[e for e in v1['events']if not(e['bar']<=6 and e['voice']=='melody')]
for j,line in enumerate(intro):
 off=0
 for n,l in line:
  if n>=0:v1['events'].append(dict(bar=j+1,onset=j*4+off,duration=l*.91,pitch=n,velocity=63+j,voice='melody'))
  off+=l
# End the introduction as Dm->E7, so the first completeA-minor phrase has a prepared arrival.
for bar,h,ch in [(5,'Dm',[38,53,57,62]),(6,'E7',[40,56,59,62])]:
 b=v1['bars'][bar-1];b.update(harmony_name=h,harmony=ch);v1['events']=[e for e in v1['events']if not(e['bar']==bar and e['voice']!='melody')]
 for t,n in [(0,ch[0]),(2,ch[0]+12)]:v1['events'].append(dict(bar=bar,onset=b['start']+t,duration=.28,pitch=n,velocity=38,voice='bass'))
 for t in [1,3]:
  for n in ch[1:]:v1['events'].append(dict(bar=bar,onset=b['start']+t,duration=.36,pitch=n,velocity=31,voice='accompaniment'))
# B7->E7 secondary dominant now has a melody spelling its own harmony, not unrelated held tensions.
b=v1['bars'][62];v1['events']=[e for e in v1['events']if not(e['bar']==63 and e['voice']=='melody')];off=0
for n,l in [(66,.5),(69,.5),(71,1),(75,1),(73,.5),(71,.5)]:v1['events'].append(dict(bar=63,onset=b['start']+off,duration=l*.96,pitch=n,velocity=73));v1['events'][-1]['voice']='melody';off+=l
(P/'revisions/score_v1.json').write_text(json.dumps(v1,indent=2));(P/'revisions/pass1.json').write_text(json.dumps({'pass':1,'changes':['Recompose the6-bar introduction as two partial stitch gestures and a newly continuous preparation, rather than duplicate six bars of the main tune.','Replace its last two harmonies withDm→E7, coordinating melody, roots and inner chords beforeA-minor arrival.','Rewritebar63 overB7 to spell the secondary dominant beforeE7, removing arbitrary sustained altered-note clashes.']},indent=2))
v2=copy.deepcopy(v1);v2['stage']='v2_stitch_phrasing_and_shared_breath'
for e in v2['events']:
 b=v2['bars'][e['bar']-1];local=e['onset']-b['start']
 if e['voice']=='melody':
  if local<1.5 and abs(local*4-round(local*4))<.001:e['velocity']+=[-3,0,-4,1,3,0][round(local*4)]
  e['velocity']+=[0,2,3,-2,1,4,0,-4][(e['bar']-7)%8]
 elif e['voice']=='accompaniment'and b['role_plan']=='rain':e['velocity']-=3
# Shared release before taking the seam apart.
b=v2['bars'][45];cut=b['start']+3.5
v2['pedals']=[e for e in v2['pedals']if not(cut<=e['onset']<b['start']+4)]+[dict(onset=cut,value=0)]
for e in v2['events']:
 if e['bar']==46:e['duration']=min(e['duration'],max(.03,cut-e['onset']))
# Physical-key arbitration prioritizes the sung melody without rewriting its pitch.
by=collections.defaultdict(list);omit=set();fix=[]
for i,e in enumerate(v2['events']):by[e['pitch']].append((i,e))
for pitch,seq in by.items():
 seq.sort(key=lambda x:x[1]['onset'])
 for (ia,a),(ib,b) in zip(seq,seq[1:]):
  if ia in omit or ib in omit:continue
  if a['onset']+a['duration']>b['onset']+.001:
   if a['voice']=='melody'and b['voice']=='accompaniment':omit.add(ib);fix.append({'bar':b['bar'],'pitch':pitch,'change':'omit chord retrigger under melody'})
   elif abs(a['onset']-b['onset'])<.001:omit.add(ib if a['voice']=='melody'else ia);fix.append({'bar':b['bar'],'pitch':pitch,'change':'single shared-key onset'})
   else:a['duration']=max(.025,b['onset']-a['onset']-.02);fix.append({'bar':b['bar'],'pitch':pitch,'change':'release before melody'})
v2['events']=[e for i,e in enumerate(v2['events'])if i not in omit];(P/'revisions/score_v2.json').write_text(json.dumps(v2,indent=2));(P/'score.json').write_text(json.dumps(v2,indent=2));(P/'revisions/pass2.json').write_text(json.dumps({'pass':2,'changes':['Shape the six-note stitch pattern with a small rising contour of touch, not identical repeated velocities.','Give the return tune priority over lighter middle chords.','Make the final breath before unpicking shared by pedal and note releases.','Review physical-key ownership across all voices.'],'key_corrections':fix},indent=2));print('57v2 ready',len(fix),'key corrections')
