import pathlib,json,copy
P=pathlib.Path(__file__).parent;before=P/'revisions/score_v2_before_hand_review.json'
if not before.exists():before.write_text((P/'revisions/score_v2.json').read_text())
v=json.loads(before.read_text());changed=[]
for b in v['bars']:
 if b.get('harmony_change_beat')==1:
  for e in v['events']:
   if e['bar']==b['bar'] and e['voice']=='bass' and abs(e['onset']-b['start']-1)<.001:
    old=e['duration'];e['duration']=.075;changed.append({'bar':b['bar'],'old_key_hold_beats':old,'new_key_hold_beats':.075,'reason':'releaseD3 before left-hand D7 upper voicing rather than demand a held major tenth'})
  for e in v['pedals']:
   if abs(e['onset']-(b['start']+1.2))<.001 and e['value']>0:e['onset']=b['start']+1.025
(P/'revisions/score_v2.json').write_text(json.dumps(v,indent=2));(P/'score.json').write_text(json.dumps(v,indent=2));(P/'revisions/hand_review_corrections.json').write_text(json.dumps({'changes':changed,'pedal_adjustment':'Repedal just after the changed root and before releasing its finger, retaining resonance while the hand moves to its voicing.'},indent=2));print('Changed midbar key holds',len(changed))
