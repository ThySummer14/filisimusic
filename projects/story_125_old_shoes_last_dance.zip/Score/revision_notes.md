# 125《旧鞋的最后一支舞》— original nominal composition

This is a newly composed 92-bar work for acoustic piano and concert-pitch low clarinet. No existing melody, song, recorded performance, audio, or external sample was used to compose it. The export schema alone was inspected in piece 122. The real-instrument rendering belongs to the collection render owner. These files make no listening or rendered-audio claim.

## The musical argument

The opening's five-note piano gesture leads into the clarinet E4–A4 / C#4–E4–A4, followed by F#4–A4 and G#4–E4. The fourth upward and the falling major third make the shoe-memory idea recognizable. The piano supplies the small eighth/sixteenth polonaise steps and a separate upper answering line. The clarinet's range is deliberately C4–B4; its short phrases contain actual release spaces rather than mechanically chopped fast notes.

The A-major dance is not a repeated eight-bar loop. Its first statement is 5+4+6 bars. The missing mirror suspends the rhythmic premise for 5+7 bars, retaining long piano notes and very few clarinet entries. The 6+8-bar piano invention uses sixteenths that never move to the wind. An 11-bar minor-mode soliloquy turns C# and F# into C and F; B7 then pulls toward E7. The return changes the old dance's answers and divides into 7+9 bars. The next 5+7 bars let the piano move forward while the clarinet increasingly rests. The final 3+5 bars give the shoes a last voice before the piano ends alone.

Tempi: 84 / 88 / 76 / 90 / 72 / 88 / 94 / 74 quarter notes per minute. Literal 3/4 throughout. Musical span 198.339755 seconds; four seconds are reserved for the acoustic release, making 202.339755 seconds in the nominal contract.

## Revision 1: v0 → v1

The first draft's mirror episode, bars 20–31, continued the dance pulse too obediently. The revision replaces all twelve bars with long and displaced piano statements, four completely silent clarinet bars, and open/spare bass entries. The changed-bar list is exactly 20–31. It removes 157 event records and adds 52 after matching full event content without IDs. This is a change of density, gate length, rests, and leadership, not a dynamics-only edit.

The complete original and replacement bar objects and event arrays are in exact_diff_v0_to_v1.json. The independent verifier reconstructs both sides from the saved scores and verifies the multiset differences.

## Revision 2: v1 → v2

Bars 57–72 now answer the original statement instead of merely repeating it. Offbeat piano replies, a descending bass-facing contour in bar 58, a downward clarinet response in bar 59, and the displaced response in bar 64 redistribute the voices. Bar 68 adds a deliberate F#5 appoggiatura resolving to E5. The A7 turn in bar 69 leads to D before the E7–A cadence. The altered reprise remains recognizably related to the original E–A gesture, but its timing, contour, and response order change.

Bars 85–92 now break the farewell into isolated recollections. The wind hands its final E4 to the piano's C#5–B4–A4 descent in bar 91; bar 92 ends on the upper A, without a final wind note. This changes the narrative from a conventional joint cadence to a remembered voice followed by the dancer's continuing motion.

Exactly 24 bars change: 57–72 and 85–92. There are 153 removed and 141 added event records, excluding event IDs. Full before/after records are in exact_diff_v1_to_v2.json.

## Dissonance and chromatic color

- Bar 16: clarinet D4 at quarter 45 is an accented appoggiatura over A/E. It resolves downward by semitone to C#4 at quarter 46. Both actual events are annotated and checked.
- Bar 68 in v2: piano F#5 at quarter 201 resolves down a whole tone to E5 at quarter 202 over A/E. Its second F# at 202.5 is an unaccented returning neighbor.
- D-minor and Dm6 borrow F-natural; A-minor and Fmaj7 introduce C-natural; Am/G, G, C, and A7 retain G-natural. These are intended modal or dominant harmonies, not notes removed by an automatic diatonic filter.
- B7 uses D# and resolves to E or E7, notably bars 35–36, 55–56, and 78–79. C#7 in bar 40 includes F-natural as the sounding E# chord third, then resolves to F# minor in bar 41.
- Dmaj7 retains C# as a major-seventh color. Aadd9 retains B, including the suspended farewell in bar 89. These pitches belong to explicitly named sonorities; they do not masquerade as failed passing-note resolutions.

The independent check scans all three quarter-note accents in every bar, including held notes. Every accented nonchord observation in the final score has an actual stepwise target in the same voice. This verifies the stated harmonic mechanism; it is not a substitute for hearing the acoustic realization.

## Verified contrasts and playability

Final sections range from 1.799 to 6.832 note events/second. Mean piano gates range from .235 seconds in the forward-moving section to .921 seconds in the minor soliloquy. Sparse sections use 1–2 LH notes and 1–2 RH notes in many bars; fast sections use up to ten RH attacks with an independent bass. The piano is written as two moving single-note lines, so no unsupported chord stretch or same-key cross-voice overlap is hidden in a chord generator. There are no active hand crossings and no repeated transposition-equivalent eight-bar RH blocks in v2.

The final clarinet has 128 notes, concert MIDI 60–71, velocities 48–70, complete nominal gates .414894–1.125 seconds, a minimum release-to-next-onset gap .191489 seconds, and an initial half-quarter rest. The renderer must use the genuine acoustic pp/mf recordings and must not advance clarinet attacks. No onset sample compensation is encoded in the score.

Run python3 generate_score.py to reproduce v0, v1, v2, exact diffs, validation files, readiness, and hashes. Run python3 independent_verify.py for the JSON-only second check. All revision evidence excludes event IDs; score.json is byte-identical to score_v2.json.
