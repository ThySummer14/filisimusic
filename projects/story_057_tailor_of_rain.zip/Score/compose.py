"""Original lightly ragged piano narrative: six quick stitches, two longer answers."""
import pathlib,json,copy
P=pathlib.Path(__file__).parent;(P/'revisions').mkdir(exist_ok=True)
def stitch(ns,a,b):return [(n,.25)for n in ns]+[(a,1.5),(b,1)]
A=[stitch([69,72,71,72,76,74],72,69),stitch([69,74,73,74,77,76],74,65),stitch([67,72,71,72,76,74],72,67),stitch([68,71,70,71,76,74],71,68),stitch([69,72,71,72,77,76],77,74),stitch([74,77,76,77,81,79],77,74),stitch([76,74,71,68,71,74],76,71),[(72,.5),(71,.5),(69,1),(64,.5),(68,.5),(69,.75),(-1,.25)]]
A2=[stitch([76,77,76,74,72,71],72,76),stitch([77,79,77,76,74,72],74,69),stitch([79,81,79,76,74,72],76,79),stitch([80,79,77,76,74,71],76,68),stitch([81,83,81,79,77,76],77,72),stitch([81,79,77,76,74,72],74,69),stitch([80,79,77,76,74,71],68,71),[(81,.75),(79,.25),(76,.5),(72,.5),(71,.5),(69,.5),(72,.75),(-1,.25)]]
B=[[(72,1),(69,.5),(64,.5),(65,1),(64,1)],[(69,.5),(65,.5),(62,1),(64,1),(65,1)],[(64,1.5),(67,.5),(72,1),(71,.5),(-1,.5)],[(68,1),(71,.5),(74,.5),(76,1),(71,.5),(-1,.5)],[(72,.5),(69,.5),(65,1),(67,.5),(69,.5),(72,1)],[(74,1),(72,.5),(69,.5),(65,1),(62,1)],[(68,.5),(71,.5),(74,1),(77,.5),(76,.5),(71,1)],[(72,1),(71,1),(69,1.5),(-1,.5)]]
U=[[(69,1),(72,1),(74,.25),(76,.25),(72,.25),(71,.25),(72,.25),(69,.75)],[(65,1),(74,1),(76,.25),(77,.25),(74,.25),(73,.25),(74,.25),(69,.75)],[(67,1),(72,1),(74,.25),(76,.25),(72,.25),(71,.25),(72,.25),(67,.75)],[(68,1),(71,1),(74,.25),(76,.25),(71,.25),(70,.25),(71,.25),(68,.75)],[(74,1),(77,1),(76,.25),(77,.25),(72,.25),(71,.25),(72,.25),(69,.75)],[(74,1),(77,1),(79,.25),(81,.25),(77,.25),(76,.25),(77,.25),(74,.75)],[(71,1),(76,1),(74,.25),(71,.25),(68,.25),(71,.25),(74,.25),(76,.75)],[(72,.5),(71,.5),(69,1),(64,1),(69,.75),(-1,.25)]]
T=[[(69,.5),(72,.5),(74,1),(72,1),(69,.5),(-1,.5)],[(68,.5),(71,.5),(74,1),(76,1),(71,.5),(-1,.5)]]
C=[[(77,.5),(76,.5),(72,1),(69,1),(65,1)],[(74,.75),(72,.25),(69,1),(65,1),(62,1)],[(72,.5),(76,.5),(79,1),(76,.5),(74,.5),(72,1)],[(71,1),(68,.5),(64,.5),(68,1),(71,1)],[(69,.25),(72,.25),(71,.25),(72,.25),(76,.25),(74,.25),(72,1.5),(69,1)],[(74,1),(77,.5),(76,.5),(74,1),(69,1)],[(68,.5),(71,.5),(74,1),(76,1),(71,1)],[(72,.5),(71,.5),(69,2),(-1,1)]]
H={'Am':[45,52,57,60],'Dm':[38,53,57,62],'C':[48,55,60,64],'E7':[40,56,59,62],'F':[41,53,57,60],'B7':[47,54,57,63]};home=['Am','Dm','C','E7','F','Dm','E7','Am'];codap=['F','Dm','C','E7','Am','Dm','E7','Am']
sections=[('Six short stitches',6,112,'intro'),('A coat for the rain',18,116,'coat'),('Drought in the sleeve',12,108,'dry'),('More patches, less rain',10,120,'patch'),('Taking the seam apart',18,104,'unpick'),('The street gets wet',16,120,'rain'),('A dry box for seeds',10,106,'coda')]
notes=[];bars=[];pedals=[];beat=0;barno=0
for sec,count,tempo,kind in sections:
 for j in range(count):
  barno+=1;k=j%8;prog=home
  if kind=='intro':line=copy.deepcopy(A[k]);h=home[k]
  elif kind=='coat':line=copy.deepcopy(A[k]if j<8 else A2[k]if j<16 else T[j-16]);h=home[k]if j<16 else ['Dm','E7'][j-16]
  elif kind=='dry':line=copy.deepcopy(B[k]);h=home[k]
  elif kind=='patch':line=copy.deepcopy(A2[k]if j<8 else T[j-8]);h=home[k]if j<8 else 'E7'
  elif kind=='unpick':line=copy.deepcopy(U[k]if j<8 else B[k]if j<16 else T[j-16]);h=home[k]if j<16 else ['B7','E7'][j-16]
  elif kind=='rain':line=copy.deepcopy(A2[k]if j<8 else A[k]);h=home[k]
  else:
   line=copy.deepcopy(C[k]if j<8 else [[(72,.5),(71,.5),(69,1),(64,1),(-1,1)],[(69,2),(-1,2)]][j-8]);h=codap[k]if j<8 else 'Am'
  assert abs(sum(l for n,l in line)-4)<1e-9,(kind,j,line)
  ch=H[h];bpm=tempo
  if kind=='coda'and j>=7:bpm=[100,92,80][j-7]
  bars.append(dict(bar=barno,start=beat,beats=4,bpm=bpm,meter_numerator=4,meter_denominator=4,section=sec,harmony_name=h,harmony=ch,role_plan=kind))
  lv={'intro':66,'coat':79,'dry':66,'patch':83,'unpick':70,'rain':86,'coda':66}[kind];off=0
  for n,l in line:
   if n>=0:notes.append(dict(bar=barno,onset=beat+off,duration=l*(.72 if kind=='dry'else .87 if l==.25 else .96),pitch=n,velocity=lv+(3 if off==1.5 else 0),voice='melody'))
   off+=l
  for t,n in [(0,ch[0]),(2,ch[0]+12)]:
   if kind=='coda'and j==9 and t==2:continue
   notes.append(dict(bar=barno,onset=beat+t,duration=.28,pitch=n,velocity=lv-29,voice='bass'))
  for t in [1,3]:
   if kind=='dry'and j>=8 and t==3:continue
   if kind=='coda'and j>=8 and t==3:continue
   for n in ch[1:]:notes.append(dict(bar=barno,onset=beat+t,duration=.27 if kind in('dry','patch')else .4,pitch=n,velocity=lv-36,voice='accompaniment'))
  if kind=='dry':pedals.append(dict(onset=beat,value=0))
  else:
   for t,v in [(0,0),(.09,28 if kind!='rain'else 43),(.87,0),(1.10,25),(1.87,0),(2.09,29),(2.87,0),(3.1,25),(3.84,0)]:pedals.append(dict(onset=beat+t,value=v))
  beat+=4
pedals=[e for e in pedals if e['onset']<beat-4]+[dict(onset=beat-4,value=0),dict(onset=beat-3.9,value=52),dict(onset=beat+1.5,value=0)]
d=dict(id=57,title='The Tailor of Rain',title_zh='裁雨的人',stage='v0_original_syncopated_narrative',bars=bars,events=notes,pedals=pedals,total_beats=beat,tail_seconds=3.8,story_relationship='Six quick stitches and two longer answers become dry and clipped; the unpicking theme reverses the ordering, then rain resolves the expanded phrase. All bass and chord support share melodic harmony.')
(P/'revisions/score_v0.json').write_text(json.dumps(d,indent=2));(P/'score.json').write_text(json.dumps(d,indent=2));(P/'thematic_material.json').write_text(json.dumps(dict(A=A,A2=A2,B=B,U=U,T=T,C=C),indent=2));print(len(bars),'bars',sum(b['beats']*60/b['bpm']for b in bars)+3.8,'seconds')
