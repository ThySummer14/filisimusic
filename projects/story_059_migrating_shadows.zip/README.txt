A Bridge for Migrating Shadows / 给迁徙的影子架桥 — v4

本版修正采样器高速离线导出时个别采样未完整载入的问题。原作旋律、节奏、故事、力度、踏板、混音参数及旧版本均保留。修订不算新作品，也不代表用户听审通过。

FULL 工程包：打开 059_migrating_shadows_v4.rpp。Media/ 含实际 float32 声部音频，可直接播放并用 REAPER 导出；所用房间效果如有，沿用原工程中的 REAPER 自带效果。它是带音频轨的独立播放工程，另附可编辑 MIDI 和事件乐谱，不是内嵌完整采样器及音库的 MIDI 工程。输出位置为相对 Renders/。

COMPACT 源包：没有 Media 音频和试听 MP3，因此不能直接播放。需要原始外部音库和播放器才能重建。

重建请阅读 Tools/SafeRegeneration/README.md，仅运行 regenerate.py 入口。Score/RenderInputs/manifest.json 指明每个声部的精确 JSON 乐谱、原始 SFZ 名称、音库 hash、details 开关及安全模式。输入完整原始 SFZ，不要把某次裁剪后的 SFZ 用于改过的乐谱。Moonlight 使用重新验证的曲谱专用 RAM 子集；Iowa 小音库完整载入 RAM。全部采样、软件及许可证仍为外部依赖，不在此包中重复分发。MIDI 修改需先同步到 JSON 乐谱，才能调用该重建器。

禁止沿用 History/ 中历史流式渲染器作为推荐重建入口；它仅为版本溯源保留。包装中的 README、音源原始署名及许可文件应一同保存。采样钢琴署名、CC BY3.0 和 Iowa 官方使用许可见原始音库说明。自然音源不等于真人演奏，也未声称真连奏或人工听审。

验收：修复声部由独立完整 RAM 参考逐样本比对；原生 REAPER API 核对设置；便携工程实际回开并再次导出得到相同 PCM。三项是不同检查。详见 Audit/ 与 metadata.json。仅相同 PCM 本身不足以证明音源完整。

故事为原创虚构。旋律与构思原创。未复制参考作品的旋律、录音或歌词。
