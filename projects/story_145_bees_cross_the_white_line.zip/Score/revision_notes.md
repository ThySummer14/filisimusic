# 145 蜂群越过那条白线

五段14/21/9/24/16，共84小节。以7/8、9/8交替，并在局部缩成5/8。内部5+9、6+7+8、9、7+8+9、5+11，不采用统一8小节改写或安静中段模板。钢琴丈量线、长笛飞行线独立，大提琴短弓有自己的旧入口动机。

## 两轮真正编曲
v0→v1主动重写第15–27及37–44小节，钢琴弱起、长笛音程及入句时值改变，五处和声重新导向。
v1→v2主动重写第51–65及76–84小节，高潮快密句选择性伸向高音，终段改用下移音区，大提琴重新分配回应和具体音程。旋律游标产生的后续实际变化也保留，具体数量、全部逐小节事件差异见READY与exact_diff，而非仅报告计划范围。

## 有意悬挂、呼吸与门长
第15小节大提琴A3→G3（Gmaj7）；第37小节长笛F#5→G5（Cmaj7）；第50小节大提琴G3→F#3（F#ø）；第69小节长笛A5→G5（Em9）；第83小节长笛E5→D#5（B7）。保留的所有非和弦音均有同线下一音半音/全音解决证据。
短弓全程D3–B3，完整0.50秒，进下一小节也积分检查弓距≥0.20秒。容不下完整弓段及释放余量的槽位直接写休止。长笛C5–B5，名义呼吸间隙≥0.14秒；优先整体推迟下一音保持门长，不能容纳才省去整音，不以截短绕过。快密音只给钢琴。

本目录运行 `python generate_score.py` 可独立重建全部谱、三版校验、精确差异与hash；全部起音名义。未渲染音频，未声称听审通过，主音乐owner统一渲染审核。

实际逐小节差异：{"v0_to_v1": {"changed_bars": [15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 37, 38, 39, 40, 41, 42, 43, 44], "bar_count": 29}, "v1_to_v2": {"changed_bars": [51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 76, 77, 78, 79, 80, 81, 82, 83, 84], "bar_count": 27}}。


## 2026-10-07 nominal sample-trigger rest-layout correction

Only listed musical onsets move later to explicit fractional-beat positions. No event is removed or added; every pitch, velocity and effective gate is retained. The existing nominal score remains free of recording onset compensation. The full tempo map and the next note’s actual pitch/velocity layer are used in the separate sample-trigger-gap checker. All flute/arco adjacent pairs must retain at least 0.14 seconds after the renderer’s one-time compensation. Full before files, hashes and exact event/source differences are retained under nominal_trigger_gap_repair. This is symbolic checking only, without rendering or listening review.

- v0: reposition 10 events in bars 6, 8, 44, 48, 55, 62, 78.
- v1: reposition 13 events in bars 6, 8, 21, 28, 39, 44, 48, 55, 62, 78.
- v2: reposition 13 events in bars 6, 8, 21, 28, 39, 44, 48, 55, 62, 78.
