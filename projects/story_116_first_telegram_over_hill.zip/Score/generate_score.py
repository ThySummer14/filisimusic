"""116: two linked arcs; the return begins in the left hand, with separated acoustic flute replies."""
from pathlib import Path
import json,sys,bisect
P=Path(__file__).resolve().parent;sys.path.insert(0,str(P));from composition_data import *
PARAM={'call':('试发的短句',108,54),'ascending':('信号越过山坡',116,72),'ridge':('第一道回声',132,89),'receive':('接收端逐字辨认',120,61),'answer':('低处传来的回答',128,79),'clear':('终于读通的一行',136,94),'weather':('山后也是晴天',88,48)}
def write(p,x):p.write_text(json.dumps(x,ensure_ascii=False,separators=(',',':'))+'\n')
def pitch(s):return 12*(int(s[-1])+1)+{'C':0,'D':2,'E':4,'F':5,'G':7,'A':9,'B':11}[s[0]]+s[1:-1].count('#')-s[1:-1].count('b')
def build(level):
 rows=[]
 for sec,hs,ls in GROUPS:assert len(hs.split())==len(ls),(sec,len(hs.split()),len(ls));rows.extend((sec,h,l) for h,l in zip(hs.split(),ls))
 assert len(rows)==128
 bars=[];events=[];pedals=[]
 for n,(sec,h,line) in enumerate(rows,1):
  for lv,rd,hd in [(1,REV1,HREV1),(2,REV2,HREV2)]:
   if level>=lv:line=rd.get(n,line);h=hd.get(n,h)
  label,bpm,dyn=PARAM[sec];ch=H[h];start=(n-1)*3
  if n>=125:bpm-=2*(n-124)
  bars.append(dict(bar=n,start=start,beats=3,bpm=bpm,meter='6/8',meter_numerator=6,meter_denominator=8,section=sec,section_title_zh=label,harmony_name=h,harmony=ch,key_region='A minor and A Dorian; G-sharp reserved for E7 resolutions'))
  def add(p,t,d,v,inst,voice,hand='none'):
   assert 0<=t<t+d<=3.00001,(n,t,d)
   events.append(dict(bar=n,onset=round(start+t,6),duration=round(d,6),pitch=p,velocity=int(v),instrument=inst,voice=voice,hand=hand))
  at=0;mel=[];lower=level>=2 and 73<=n<=84
  for i,tok in enumerate(line.split()):
   name,u=tok.split(':');dur=float(u)/2
   if name!='R':
    p=pitch(name)-(12 if lower else 0);mel.append(p);add(p,at,dur-.075,dyn-(5 if i==len(line.split())-1 else 0),'piano','signal_theme','left' if lower else 'right')
   at+=dur
  assert at==3
  if lower:
   for t,p in [(1,ch[1]+36),(2.5,ch[2]+36)]:add(p,t,.25,45,'piano','upper_tick_reply','right')
  else:
   pat=[(0,ch[0],.42),(1.5,ch[2],.42)]
   if sec=='call':pat=[(0,ch[0],.90)]
   elif sec=='ascending':pat=[(0,ch[0],.42),(1.5,ch[1],.40),(2.5,ch[2],.32)] if n%2 else [(0,ch[0],.5),(2,ch[2],.45)]
   elif sec=='ridge':pat=[(0,ch[0],.38),(1,ch[1],.30),(1.5,ch[2],.30),(2.5,ch[1],.30)]
   elif sec=='receive':pat=[(.25,ch[0],.4)] if n%2 else [(1.5,ch[1],.45)]
   elif sec=='answer':pat=[(0,ch[0],.4),(1.5,ch[1],.4),(2.5,ch[2],.3)]
   elif sec=='clear':pat=[(0,ch[0],.35),(1,ch[1],.3),(1.5,ch[2],.35),(2.5,ch[0]+12,.3)]
   elif sec=='weather':pat=[(0,ch[0],.85)] if n%2 else [(1.5,ch[2],.6)]
   if level>=1 and 25<=n<=40:pat=[(.5,ch[1],.30),(2,ch[0],.38)] if n%2 else [(0,ch[0],.45),(1.5,ch[2],.32)]
   if level>=2 and n>=125:pat=[(0,ch[0],.55),(2,ch[0]+12,.5)] if n<128 else [(0,45,2.8)]
   for t,p,dur in pat:
    while p>=min(mel):p-=12
    add(p,t,dur,max(25,dyn-25),'piano','lower_rhythmic_response','left')
  wind=WIND.get(n,[])
  if level>=1 and 25<=n<=40:wind=[wind[0]] if wind else []
  if level>=2 and 73<=n<=84:wind=[81] if n in [73,79,81] else [78] if n==75 else [77] if n==83 else []
  if level>=2 and n>=125:wind=[]
  for t,p in zip([.55,2.15],wind):add(p,t,.75 if len(wind)>1 else 1.1,48 if sec in ['call','weather'] else 66 if sec in ['ridge','clear'] else 60,'flute','decoded_signal_reply')
  pedals.append(dict(bar=n,onset=start,controller=64,value=0,instrument='piano'))
  if sec in ['call','weather']:
   pedals.extend([dict(bar=n,onset=start+.08,controller=64,value=26,instrument='piano'),dict(bar=n,onset=start+1.4,controller=64,value=0,instrument='piano')])
 events.sort(key=lambda e:(e['onset'],e['instrument'],e['pitch']))
 for i,e in enumerate(events):e['event_id']=f'116-v{level}-{i}'
 return dict(id=116,title='The First Telegram over the Hill',title_zh='山后第一封电报',version=f'v{level}',bars=bars,events=events,pedals=pedals,total_beats=384,tail_seconds=5,instrument_map={'piano':'piano','flute':'flute'},performance_contract='Two developing rhythmic arcs with hand-to-hand thematic transfer and breath-separated sampled flute; no human-listening claim.')
def proj(d,n):return {'bar':d['bars'][n-1],'events':[{k:v for k,v in e.items() if k!='event_id'} for e in d['events'] if e['bar']==n],'pedals':[e for e in d['pedals'] if e['bar']==n]}
for v in range(3):
 d=build(v);write(P/f'score_v{v}.json',d);report={'version':f'v{v}','bars':128,'events':len(d['events']),'duration_seconds':sum(b['beats']*60/b['bpm'] for b in d['bars'])+5,'human_listening_review':False};write(P/f'audit_v{v}.json',report)
 if v:
  a=build(v-1);changes=[{'bar':n,'before':proj(a,n),'after':proj(d,n)} for n in range(1,129) if proj(a,n)!=proj(d,n)];write(P/f'exact_diff_v{v-1}_to_v{v}.json',{'count':len(changes),'changed_bars':[x['bar'] for x in changes],'comparison_excludes':['version','event_id'],'changes':changes});lines=[]
  for x in changes:
   lines.append(f"BAR {x['bar']}\n")
   for side in ['before','after']:
    q=x[side];lines.append(side+' '+q['bar']['harmony_name']+' '+str([(e['instrument'],e['voice'],e['onset'],e['pitch'],e['duration'],e['velocity']) for e in q['events']])+'\n')
  (P/f'exact_diff_v{v-1}_to_v{v}.patch').write_text(''.join(lines))
write(P/'score.json',d);starts=[b['start'] for b in d['bars']];times=[];t=0
for b in d['bars']:times.append(t);t+=b['beats']*60/b['bpm']
def sec(t):
 i=max(0,bisect.bisect_right(starts,t)-1);return times[i]+(t-starts[i])*60/d['bars'][i]['bpm']
def beat(t):
 i=max(0,bisect.bisect_right(times,t)-1);return starts[i]+(t-times[i])*d['bars'][i]['bpm']/60
mp=P.parent/'assets/iowa_flute_C5_B5/mapping_manifest.json';lat={(x['layer'],x['midi']):x['voiced_onset_delay_after_tuning_seconds'] for x in json.loads(mp.read_text())['files']};alignment=[]
for e in d['events']:
 if e['instrument']!='flute':continue
 layer='pp' if e['velocity']<=55 else 'mf';target=sec(e['onset']);end=sec(e['onset']+e['duration']);delay=lat[layer,e['pitch']];trigger=target-delay;assert trigger>=0;e['nominal_onset']=e['onset'];e['onset']=beat(trigger);e['duration']=beat(end)-e['onset'];e['layer']=layer;e['attack_compensated_once']=True;assert .30<=end-target and end-trigger<=1.60;alignment.append(dict(event_id=e['event_id'],target_seconds=target,trigger_seconds=trigger,delay_seconds=delay,gate_seconds=end-trigger,layer=layer))
w=sorted([e for e in d['events'] if e['instrument']=='flute'],key=lambda e:e['onset']);gaps=[sec(b['onset'])-sec(a['onset']+a['duration']) for a,b in zip(w,w[1:])];assert min(gaps)>=.14,min(gaps)
write(P/'ensemble_score.json',d)
for inst in ['piano','flute']:write(P/f'{inst}_score.json',{**d,'events':[e for e in d['events'] if e['instrument']==inst],'pedals':d['pedals'] if inst=='piano' else []})
write(P/'revisions/flute_attack_alignment.json',{'method':'Once-only recorded voiced-onset timing compensation; real pp/mf separated vibrato notes','events':alignment,'minimum_after_compensation_gap_seconds':min(gaps)});print(json.dumps({**report,'flute_min_gap_seconds':min(gaps)}))
