import pathlib,json,aifc,numpy as np,math
P=pathlib.Path(__file__).parent;d=json.loads((P/'scale_analysis.json').read_text())[0]
with aifc.open(str(P/d['source_file']),'rb')as w:sr=w.getframerate();y=np.frombuffer(w.readframes(w.getnframes()),dtype='>i2').astype(np.float64)/32768
rows=[]
for note in d['notes']:
 onset=note['active_start_frame']/sr;target=440*2**((note['midi']-69)/12);windows=[]
 for start,length in[(.05,.65),(.25,1.0),(.7,1.5)]:
  seg=y[round((onset+start)*sr):round((onset+start+length)*sr)];seg-=seg.mean();n=2**19;sp=abs(np.fft.rfft(seg*np.hanning(len(seg)),n=n));freq=np.fft.rfftfreq(n,1/sr);lo=np.searchsorted(freq,target*2**(-1/12));hi=np.searchsorted(freq,target*2**(1/12));k=lo+int(np.argmax(sp[lo:hi]));delta=.5*(sp[k-1]-sp[k+1])/(sp[k-1]-2*sp[k]+sp[k+1]);f=(k+delta)*sr/n;c=1200*math.log2(f/target);windows.append({'start_after_detected_onset':start,'length':length,'fundamental_fft_hz':f,'cents':c,'window_rms':float(np.sqrt(np.mean(seg*seg)))})
 rows.append({'midi':note['midi'],'initial_autocorrelation_cents':note['deviation_cents'],'independent_fundamental_windows':windows});print(note['midi'],round(note['deviation_cents'],1),'FFT',[round(x['cents'],1)for x in windows])
(P/'independent_pitch_review.json').write_text(json.dumps({'method':'Independent fundamental-band FFTpeak interpolation across three post-pluck windows; detects genuine pitch drift separately from short-window autocorrelation estimates.','notes':rows},indent=2))
