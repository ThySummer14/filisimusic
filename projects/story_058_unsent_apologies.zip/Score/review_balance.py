import pathlib,json,numpy as np,math
P=pathlib.Path(__file__).parent;d=json.loads((P/'ensemble_score.json').read_text());sr=44100;c=np.memmap(P/'revisions/clarinet_stem_v2.wav',dtype='<f4',offset=44,mode='r').reshape(-1,2);p=np.memmap(P/'revisions/piano_stem_v2.wav',dtype='<f4',offset=44,mode='r').reshape(-1,2);starts={};t=0
for b in d['bars']:starts[b['bar']]=t;t+=b['beats']*60/b['bpm']
rows=[]
for b in d['bars']:
 ns=[e for e in d['events']if e['bar']==b['bar']and e['instrument']=='clarinet'];ratios=[]
 for e in ns:
  s=starts[b['bar']]+(e['onset']-b['start'])*60/b['bpm'];dur=e['duration']*60/b['bpm'];lo=round((s+.06)*sr);hi=round((s+max(.08,dur-.03))*sr);cr=float(np.sqrt(np.mean(c[lo:hi].astype(np.float64)**2)))*6.5;pr=float(np.sqrt(np.mean(p[lo:hi].astype(np.float64)**2)))*4
  if cr>1e-7 and pr>1e-7:ratios.append(20*math.log10(cr/pr))
 if ratios:rows.append({'bar':b['bar'],'section':b['section'],'median_lead_over_piano_dB':float(np.median(ratios))})
sections=[]
for title in dict.fromkeys(b['section']for b in d['bars']):
 x=[a['median_lead_over_piano_dB']for a in rows if a['section']==title]
 if x:sections.append({'section':title,'median_lead_over_piano_dB':float(np.median(x)),'min_bar_median_dB':min(x),'max_bar_median_dB':max(x)})
report={'method':'Pre-reverb stereo-energy comparison during written clarinet notes, using current track gains. This is not a loudness-model or listening-quality verdict.','sections':sections,'bars':rows};(P/'revisions/role_energy_review_v2.json').write_text(json.dumps(report,indent=2));print(json.dumps(sections,indent=2))
