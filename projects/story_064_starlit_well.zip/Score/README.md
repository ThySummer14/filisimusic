# Work 64: 记得星星的井

Original, non-rendered flute and acoustic piano draft; approximately 2:59 including four seconds of tail.

Use `score_v2.json` (also copied to `score.json`). Read `story_and_score_notes.md` for the Chinese story and musical route, `revision_log.md` for the two substantive revisions, and `integration_notes.md` before any sample-based rendering.

`flute_entry_intentions.json` gives all 52 intended pitched arrivals and layer-specific compensation instructions. `phrases_v2.json` gives the 13 breath-separated phrases.

`build_score.py` reproducibly writes the three score versions, per-version audits, phrase files, revision diff, and manifest. `verify_score.py` independently validates the saved final JSON. Both use Python's standard library only.

`audit_v0.json` intentionally preserves three failed left-hand reposition checks from the rejected initial draft. Those extra chord attacks were removed in v1; v1 and v2 pass. The final audit is `audit_v2.json`, independently read back in `validation_readback.json`.

No audio was rendered or heard. Mathematical checks do not establish musical quality or actual acoustic phrase silence. The integrator owns sample measurement, source-specific onset/release alignment, audio work, and listening review.
