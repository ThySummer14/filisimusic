# 092 — A Sail Sewn from Maps / 用地图缝成的帆

完整原创符号作品，天然原声钢琴为主、现有 Iowa 长笛 pp/mf 素材作呼吸式应答。80 小节，12/8，480 个绝对四分音符拍，含尾响总长 3:31.682。已选 v2；两个完整早期版本与逐事件修订证据一并保留。

本目录是独立草稿交付。没有修改 live 目录、渲染音频、做 DSP、下载或安装音源。参考 088 与 091 仅限字段模式与严格符号审计思想，主题、故事、音高和结构均另行创作。

## 文件

- score_v0.json / score_v1.json / score_v2.json：三个完整版本
- score.json：与 score_v2.json 字节一致的最终选择
- generate_score.py：只用 Python 标准库、无随机数的确定性生成器
- verify_symbolic.py：独立读取磁盘的审计器，不导入生成器函数
- exact_diff_v0_to_v1.json / exact_diff_v1_to_v2.json：逐小节全部变化、完整 JSON patch、前后哈希
- 同名 .patch：人可阅读的完整统一差异
- audit_v0.json / audit_v1.json / audit_v2.json：每次整手换位与固定手位内手指动作的完整证据
- independent_verification.json / reproducibility_check.json：汇总审计与新进程字节复现证据
- story_zh.txt / music_notes_zh.md / revision_notes.md：中文故事、音乐说明和两轮修订说明
- hash_manifest.json：本目录全部常规交付文件的 SHA-256 与字节数，不含清单自身

## 复核

在本目录执行 python generate_score.py，随后执行 python verify_symbolic.py。生成器的 --outdir 只接受当前独立目录或其子目录。审计器会在本目录下创建并清理临时复现目录，更新审计与哈希清单。

所有时间均按四分音符拍解释，12/8 每小节为 6 拍。自然钢琴持键与踏板是两套独立数据，不能把 CC64 当作手指持续按键。每个钢琴事件具备 hand、voice、finger、position_id、position_keys、layer 和 phrase_id；长笛具备真实 pp/mf 层、源音高、普通触发和明确释放／呼吸边界。

Iowa 长笛的可用音域为 C5–B5，本谱使用 C#5–B5；v2 的门长 0.64–1.20 秒，最短实际释放间隔 0.16 秒。没有采样循环、采样连奏或预先补偿的时间。后续集成者测量实际录音起音后，只施加一次补偿。

独立符号审计不等于试听通过，也不证明音源真实度、演奏舒适度或最终声部平衡。
