import pathlib,json,argparse
ap=argparse.ArgumentParser();ap.add_argument('--version',required=True);ap.add_argument('--clarinet-gain',type=float,default=6.5);ap.add_argument('--piano-gain',type=float,default=4.0);ap.add_argument('--end-seconds',type=float);ap.add_argument('--clarinet-source-version',default='v2');ap.add_argument('--master-volume',type=float,default=.95);a=ap.parse_args();P=pathlib.Path(__file__).parent;d=json.loads((P/'revisions/ensemble_v2.json').read_text());duration=a.end_seconds or json.loads((P/'revisions/piano_stem_v2.render.json').read_text())['duration'];r=f'''<REAPER_PROJECT 0.1 7.82 1
  SAMPLERATE 44100 0 0
  TEMPO 82 4 4 0
  MASTER_VOLUME {a.master_volume}
  RENDER_FILE "{P}/revisions/058_duet_{a.version}.wav"
  RENDER_FMT 0 2 44100
  RENDER_1X 0
  RENDER_RANGE 0 0 {duration:.10f} 0 1000
  RENDER_STEMS 0
  RENDER_DITHER 0
  <RENDER_CFG
    ZXZhdxgAAA==
  >
''';t=0;last=None;i=0
for b in d['bars']:
 if b['section']!=last:i+=1;r+=f'  MARKER {i} {t:.8f} "{b["section"]}" 0\n';last=b['section']
 t+=b['beats']*60/b['bpm']
for name,stem,gain,pan,width in [('Clarinet | actual pp/mf recordings | no true legato',f'clarinet_stem_{a.clarinet_source_version}.wav',a.clarinet_gain,-.10,1),('Piano | shared harmony and replies','piano_stem_v2.wav',a.piano_gain,-.35,.45)]:
 r+=f'''  <TRACK
    NAME "{name}"
    PANMODE 5
    VOLPAN {gain} {pan} {width} -1
    MAINSEND 1
    <ITEM
      POSITION 0
      LENGTH {duration:.10f}
      VOLPAN 1 0 1 -1
      FADEIN 1 0.003
      FADEOUT 1 0.8
      <SOURCE WAVE
        FILE "{stem}"
      >
    >
  >
'''
r+='>\n';(P/f'revisions/058_duet_{a.version}.rpp').write_text(r)
# The stock effect is instantiated and serialized by actual REAPER API, never invented opaque state.
(P/f'add_room_{a.version}.lua').write_text(f'''local path='{P}/revisions/058_duet_{a.version}.rpp'
local tr=reaper.GetMasterTrack(0)
local fx=reaper.TrackFX_AddByName(tr,'ReaVerbate (Cockos)',false,-1)
assert(fx>=0,'Bundled ReaVerbate required for this mix')
for i,v in pairs({{[0]=0.06,[1]=1,[2]=0.20,[3]=0.60,[4]=0.70,[5]=0,[6]=1,[7]=0}})do reaper.TrackFX_SetParam(tr,fx,i,v)end
reaper.Main_SaveProject(0,false)
local f=assert(io.open('{P}/revisions/native_room_{a.version}_saved.txt','w'));f:write('Actual REAPER stock ReaVerbate on master: wet0.06, dry1, room0.20, damp0.60, width0.70. Saved own project.');f:close()
reaper.Main_OnCommand(40004,0)
''');print('Two-track mastering project prepared',duration)
