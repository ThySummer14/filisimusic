raise SystemExit("Direct historical streaming is disabled. Use Tools/SafeRegeneration/regenerate.py with explicit original bank, library, RAM cap and mode.")
