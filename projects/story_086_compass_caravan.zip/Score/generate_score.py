#!/usr/bin/env python3
"""Original work 086, symbolic solo piano; standard library only.

All time values are quarter-note beats. 9/8 = 4.5 quarter-note beats per bar.
No sound renderer, samples, network, installation, or external dependencies.
The three retained drafts have real compositional changes, not cosmetic tags.
"""
import copy
import hashlib
import json
import statistics
from collections import Counter, defaultdict
from pathlib import Path

OUT = Path(__file__).resolve().parent
PC = {'C': 0, 'D': 2, 'E': 4, 'F': 5, 'G': 7, 'A': 9, 'B': 11}
BEATS = 4.5
TAIL = 7

def midi(s):
    return 12 * (int(s[-1]) + 1) + PC[s[0]] + s[1:-1].count('#') - s[1:-1].count('b')

def melody(s):
    result = [(midi(n), float(d)) for n, d in (x.split(':') for x in s.split())]
    assert abs(sum(d for _, d in result) - BEATS) < 1e-9, s
    return result

# The bass releases before the compact support grip. Harmony metadata includes
# all harmonic degrees, while only two upper notes normally sound at a time.
RAW_H = {
    'Dm': ('D2', 'D3 F3 A3'),
    'Dm/F': ('F2', 'D3 F3 A3'),
    'Dm/A': ('A2', 'D3 F3 A3'),
    'Dm/C': ('C3', 'D3 F3 A3 C4'),
    'Dm6': ('D2', 'D3 F3 A3 B3'),
    'C': ('C3', 'C3 E3 G3'),
    'C/E': ('E2', 'C3 E3 G3'),
    'C/G': ('G2', 'C3 E3 G3'),
    'G': ('G2', 'D3 G3 B3'),
    'G/B': ('B2', 'D3 G3 B3'),
    'G/D': ('D3', 'D3 G3 B3'),
    'G7': ('G2', 'D3 F3 B3'),
    'F': ('F2', 'C3 F3 A3'),
    'F/A': ('A2', 'C3 F3 A3'),
    'Em': ('E2', 'B2 E3 G3'),
    'Em7': ('E2', 'D3 E3 G3 B3'),
    'Am': ('A2', 'C3 E3 A3'),
    'Am/C': ('C3', 'C3 E3 A3'),
    'Am/E': ('E2', 'C3 E3 A3'),
}
H = {name: (midi(b), [midi(x) for x in upper.split()]) for name, (b, upper) in RAW_H.items()}

def phrase(harmonies, tunes):
    hs = harmonies.split()
    assert len(hs) == len(tunes) == 8
    return [{'h': h, 'melody': melody(t)} for h, t in zip(hs, tunes)]

# The identifying cell in D is A-F-G-A-D, with durations 1,.5,1,.5,1.5.
# Its answer descends C-B-A-G-E. Each line below is deliberately authored.
FINAL = [
    phrase('Dm C G/B Dm/A F C/G Em7 Dm/A', [
        'A4:1 F4:0.5 G4:1 A4:0.5 D5:1.5',
        'C5:1 B4:0.5 A4:1 G4:0.5 E4:1.5',
        'G4:1 B4:0.5 A4:1 G4:0.5 D5:1.5',
        'A4:1.5 F4:1 E4:0.5 D4:1.5',
        'A4:1 C5:0.5 D5:1 C5:0.5 A4:1.5',
        'G4:1 E4:0.5 F4:1 G4:0.5 C5:1.5',
        'G4:1 B4:0.5 A4:1 G4:0.5 E4:1.5',
        'A4:1 G4:0.5 F4:1 E4:0.5 D4:1.5',
    ]),
    phrase('Dm Em7 F C/E G Dm/F Em7 Am', [
        'A4:0.5 F4:0.5 G4:0.5 A4:1 D5:0.5 E5:1 F5:0.5',
        'E5:1 D5:0.5 B4:1 A4:0.5 G4:1.5',
        'C5:1 A4:0.5 G4:1 A4:0.5 F5:1.5',
        'E5:1 D5:0.5 C5:1 G4:0.5 E4:1.5',
        'G4:1 A4:0.5 B4:1 D5:0.5 E5:1.5',
        'D5:1 C5:0.5 A4:1 G4:0.5 F4:1.5',
        'G4:0.5 A4:0.5 B4:0.5 D5:1 C5:0.5 B4:1 A4:0.5',
        'E4:1 G4:0.5 A4:3',
    ]),
    phrase('Am G F Em7 Am Dm G Am', [
        'E4:1 C4:0.5 D4:1 E4:0.5 A4:1.5',
        'G4:1 F4:0.5 E4:1 D4:0.5 G4:1.5',
        'A4:1 G4:0.5 F4:1 E4:0.5 C5:1.5',
        'B4:1 A4:0.5 G4:1 E4:0.5 D4:1.5',
        'A4:1 E4:0.5 F4:1 G4:0.5 C5:1.5',
        'F4:1 E4:0.5 D4:1 F4:0.5 A4:1.5',
        'B4:1 A4:0.5 G4:1 F4:0.5 D4:1.5',
        'E4:1 G4:0.5 A4:3',
    ]),
    phrase('Am C/G F Dm/A Em7 Am/C Dm G', [
        'C5:0.5 B4:0.5 A4:0.5 E4:1 F4:0.5 G4:1 A4:0.5',
        'G4:0.5 A4:0.5 G4:0.5 E4:1 D4:0.5 C4:1 E4:0.5',
        'F4:1 E4:0.5 C4:1 D4:0.5 A4:1.5',
        'A4:0.5 B4:0.5 A4:0.5 F4:1 E4:0.5 D4:1 F4:0.5',
        'G4:1 A4:0.5 B4:1 C5:0.5 D5:1.5',
        'C5:1 B4:0.5 A4:1 G4:0.5 E4:1.5',
        'F4:0.5 G4:0.5 A4:0.5 D5:1 C5:0.5 A4:1 G4:0.5',
        'B4:1 A4:0.5 G4:3',
    ]),
    phrase('G C G/B Dm/F G/D C/E Dm/A G', [
        'D4:1.5 B3:1.5 D4:1.5',
        'C4:1.5 D4:1.5 G4:1.5',
        'G4:3 F4:1 E4:0.5',
        'F4:1.5 E4:1.5 D4:1.5',
        'D4:1.5 G4:1.5 A4:1.5',
        'G4:1.5 E4:1.5 D4:1.5',
        'F4:1 G4:0.5 A4:1 F4:0.5 D4:1.5',
        'G4:3 D4:1.5',
    ]),
    phrase('G C Am Em7 Dm C/G G/B Dm/A', [
        'B4:1 G4:0.5 A4:1 B4:0.5 D5:1.5',
        'C5:1 B4:0.5 A4:1 G4:0.5 E4:1.5',
        'A4:1 C5:0.5 B4:1 A4:0.5 E5:1.5',
        'D5:1 B4:0.5 A4:1 G4:0.5 E4:1.5',
        'F4:1 A4:0.5 G4:1 A4:0.5 D5:1.5',
        'C5:0.5 D5:0.5 E5:0.5 G5:1 F5:0.5 E5:1 D5:0.5',
        'D5:1 B4:0.5 A4:1 G4:0.5 D5:1.5',
        'A4:1 G4:0.5 F4:1 E4:0.5 D4:1.5',
    ]),
    phrase('Dm C G/B Dm/F F C/E G7 Dm/A', [
        'A4:1 F4:0.5 G4:1 A4:0.5 D5:1.5',
        'C5:1 B4:0.5 A4:1 G4:0.5 E4:1.5',
        'G4:1 B4:0.5 D5:1 E5:0.5 D5:1.5',
        'A4:1 F4:0.5 E4:1 D4:0.5 F4:1.5',
        'A4:0.5 B4:0.5 C5:0.5 D5:1 C5:0.5 A4:1 G4:0.5',
        'G4:1 E4:0.5 F4:1 G4:0.5 C5:1.5',
        'D5:1 B4:0.5 A4:1 G4:0.5 F4:1.5',
        'A4:1 G4:0.5 F4:1 E4:0.5 D4:1.5',
    ]),
    phrase('Dm/F C/E G/D Dm/C G/B Am Dm Dm', [
        'F4:1 A4:0.5 D5:3',
        'E5:1 D5:0.5 C5:1 B4:0.5 G4:1.5',
        'B4:1 G4:0.5 A4:1 B4:0.5 D5:1.5',
        'A4:1 F4:0.5 E4:1 D4:0.5 F4:1.5',
        'G4:1.5 A4:1 B4:0.5 D5:1.5',
        'A4:1 G4:0.5 E4:1 D4:0.5 E4:1.5',
        'A4:1 F4:0.5 G4:1 A4:0.5 D5:1.5',
        'D5:4.5',
    ]),
]

EARLY_G = phrase('G C G/B Dm/A G C Dm G', [
    'D5:1 B4:0.5 C5:1 D5:0.5 G5:1.5',
    'E5:1 D5:0.5 C5:1 B4:0.5 G4:1.5',
    'D5:1 B4:0.5 A4:1 G4:0.5 D5:1.5',
    'A4:1 F4:0.5 E4:1 D4:0.5 F4:1.5',
    'B4:1 D5:0.5 C5:1 B4:0.5 G4:1.5',
    'G4:1 E4:0.5 F4:1 G4:0.5 C5:1.5',
    'A4:1 G4:0.5 F4:1 E4:0.5 D4:1.5',
    'B4:1 A4:0.5 G4:3',
])
EARLY_END = copy.deepcopy(FINAL[0])
EARLY_END[-1] = {'h': 'Dm', 'melody': melody('D4:4.5')}

# Explicitly composed tenor answers; entries are (relative onset, length, pitch).
# They respond in the sustained third pulse of the leading tune. Only entries
# tagged 'passing' are nonchord tones; their stepwise resolutions are audited.
COUNTER = {
    41: [(1.5, 1.3, 'G3'), (3, .45, 'B3'), (3.5, .45, 'A3'), (4, .40, 'G3')],
    42: [(1.5, 1.3, 'G3'), (3, .45, 'E3'), (3.5, .45, 'F3'), (4, .40, 'G3')],
    43: [(1.5, 1.3, 'E3'), (3, .45, 'E3'), (3.5, .45, 'F3'), (4, .40, 'E3')],
    44: [(1.5, 1.3, 'G3'), (3, .45, 'B3'), (3.5, .45, 'A3'), (4, .40, 'G3')],
    45: [(1.5, 1.3, 'F3'), (3, .45, 'A3'), (3.5, .45, 'G3'), (4, .40, 'F3')],
    46: [(1.5, 1.3, 'E3'), (3, 1.35, 'G3')],
    47: [(1.5, 1.3, 'G3'), (3, .45, 'B3'), (3.5, .45, 'A3'), (4, .40, 'G3')],
    48: [(1.5, 1.3, 'F3'), (3, .45, 'A3'), (3.5, .45, 'G3'), (4, .40, 'F3')],
    49: [(1.5, 1.3, 'A3'), (3, .45, 'F3'), (3.5, .45, 'E3'), (4, .40, 'D3')],
    50: [(1.5, 1.3, 'G3'), (3, .45, 'E3'), (3.5, .45, 'F3'), (4, .40, 'G3')],
    51: [(1.5, 1.3, 'G3'), (3, .45, 'B3'), (3.5, .45, 'A3'), (4, .40, 'G3')],
    52: [(1.5, 1.3, 'A3'), (3, .45, 'F3'), (3.5, .45, 'E3'), (4, .40, 'D3')],
    53: [(1.5, 1.3, 'F3'), (3, 1.35, 'A3')],
    54: [(1.5, 1.3, 'G3'), (3, .45, 'E3'), (3.5, .45, 'F3'), (4, .40, 'G3')],
    55: [(1.5, 1.3, 'B3'), (3, .45, 'F3'), (3.5, .45, 'E3'), (4, .40, 'D3')],
    56: [(1.5, 1.3, 'F3'), (3, .45, 'A3'), (3.5, .45, 'G3'), (4, .40, 'F3')],
}

SCENES = [
    ('仪表台上的三个方向', 'D dorian', 92, 65),
    ('沿着里程牌出发', 'D dorian; pivot to A aeolian', 95, 69),
    ('涵洞前的刹车', 'A aeolian', 91, 67),
    ('把仪器搬过检修道', 'A aeolian; pivot to G mixolydian', 95, 71),
    ('旧水准点', 'G mixolydian', 82, 58),
    ('两处棱镜', 'G mixolydian -> A aeolian -> D dorian', 96, 72),
    ('车灯经过相同的弯', 'D dorian', 94, 70),
    ('签收以后', 'D dorian', 88, 61),
]

def version_phrases(version):
    ps = copy.deepcopy(FINAL)
    if version in ('v0', 'v1'):
        ps[6] = copy.deepcopy(FINAL[0])
        ps[7] = copy.deepcopy(EARLY_END)
    if version == 'v0':
        ps[3] = copy.deepcopy(FINAL[2])
        ps[3][-1] = {'h': 'G', 'melody': melody('B4:1 A4:0.5 G4:3')}
        ps[4] = copy.deepcopy(EARLY_G)
    return ps

def tempo_for(scene, j, version):
    base = SCENES[scene][2]
    curve = [0, 1, 1, 0, 2, 1, 0, -2]
    if scene == 4 and version == 'v0':
        base = 91
    if scene == 7:
        return [88, 88, 87, 86, 84, 80, 74, 64][j] if version == 'v2' else [88, 89, 89, 88, 88, 86, 80, 66][j]
    return base + curve[j]

def make_score(version):
    events, bars, pedals = [], [], []
    ps = version_phrases(version)
    def event(bi, on, dur, p, vel, voice, hand, function='chord'):
        e = {'bar': bi + 1, 'onset': round(bi * BEATS + on, 6),
             'duration': round(dur, 6), 'pitch': int(p), 'velocity': int(vel),
             'voice': voice, 'instrument': 'piano', 'hand': hand}
        if function != 'chord': e['harmonic_function'] = function
        events.append(e)
    for ph, pphrase in enumerate(ps):
        name, region, _, leadbase = SCENES[ph]
        for j, mb in enumerate(pphrase):
            bi = ph * 8 + j
            number = bi + 1
            start = bi * BEATS
            bass, upper = H[mb['h']]
            # The coda starts its bass in the tenor register, then F3-E3-D3-C3-B2-A2.
            # This is an actual descending line, with a final fifth down to D2.
            if version == 'v2' and ph == 7 and j < 2:
                bass += 12
            pcs = {bass % 12} | {p % 12 for p in upper}
            counter = version == 'v2' and number in COUNTER
            quiet = ph == 4 and version != 'v0'
            roles = '右手连续歌唱主线；左手低音与三组复合拍支撑'
            if quiet: roles = '右手把路标动机拉成长音；左手保留三步脉动、缩低和声位置'
            if counter: roles = '右手继续主旋律；左手在右手第三组长音下接续短句，回应声部轻于主线'
            if ph == 7: roles = '右手逐步收束；左手低音连续下行，最后一次共同落在 D'
            bars.append({'bar': number, 'start': start, 'beats': BEATS,
                         'bpm': tempo_for(ph, j, version), 'section': name,
                         'meter_numerator': 9, 'meter_denominator': 8,
                         'harmony_name': mb['h'], 'harmony': sorted(set([bass] + upper)),
                         'lead_instrument': 'piano', 'role_plan': roles,
                         'key_region': region, 'phrase_id': ph + 1, 'phrase_position': j + 1})
            contour = [0, 1, 2, 1, 4, 3, 0, -3][j]
            leadvel = leadbase + contour
            if ph == 7: leadvel -= j
            t = 0.0
            for ni, (p, ln) in enumerate(mb['melody']):
                # Articulation gaps are intentional; this is a cantabile line,
                # not pedal-dependent overlap. Shorter joints breathe at phrase ends.
                gap = .045 if ln <= .5 else .055
                if j == 7 and ni == len(mb['melody']) - 1: gap = .10
                if quiet: gap = .040
                if number == 64: gap = .16
                accent = 2 if ni == 0 else (1 if t in (1.5, 3.0) else -1)
                event(bi, t, ln - gap, p, leadvel + accent, 'melody', 'right',
                      'melodic_nonchord' if p % 12 not in pcs else 'chord')
                t += ln
            support = leadvel - (22 if quiet else 23)
            # A bass note, then two compact grips. Bass-to-grip transfers receive
            # at least 0.36 sec of released travel even at the fastest tempo.
            bass_dur = .80 if max(upper) - bass > 21 else .88
            event(bi, 0, bass_dur, bass, support + 2, 'bass', 'left')
            if counter:
                for on, dur, pstr in COUNTER[number]:
                    p = midi(pstr)
                    role = 'passing_neighbor' if p % 12 not in pcs else 'chord'
                    # Release the last tenor note early enough to return to the next bass.
                    if on == 4: dur = .26
                    if on == 3 and dur > 1.3: dur = 1.22
                    event(bi, on, dur, p, leadvel - 16 + (on == 3), 'countermelody', 'left', role)
            elif quiet:
                # Upper supports are intentionally below the lowered right-hand line.
                safe_upper = [p for p in upper if p <= 55]
                p1, p2 = safe_upper[-1], safe_upper[0]
                event(bi, 1.5, 1.33, p1, support - 2, 'accompaniment', 'left')
                event(bi, 3, 1.34, p2, support - 1, 'accompaniment', 'left')
            else:
                grip = upper[:2] if mb['h'] in ('Dm/C', 'Em7') else upper[-2:]
                # G's B3 remains below every ordinary right-hand melody note.
                for p in grip:
                    event(bi, 1.5, 1.25, p, support - 2, 'accompaniment', 'left')
                if ph in (1, 3) and j not in (3, 7):
                    # A little forward motion while keeping the right hand dominant.
                    event(bi, 3, .86, upper[0], support, 'accompaniment', 'left')
                    event(bi, 4, .18, upper[-1], support - 3, 'accompaniment', 'left')
                else:
                    for p in grip:
                        event(bi, 3, 1.30, p, support - 1, 'accompaniment', 'left')
            if number == 64:
                # Final grip replaces all ordinary support. Each hand holds an octave
                # or less. The melody's D remains the highest and strongest note.
                events = [e for e in events if not (e['bar'] == 64 and e['hand'] == 'left')]
                for p in (38, 45, 50): event(bi, 0, 4.30, p, 32 + (p == 38) * 3, 'final_bass', 'left')
                if version == 'v2':
                    for p in (65, 69): event(bi, 0, 4.30, p, 36, 'final_inner', 'right')
            # A fresh shallow-to-full pedal each dotted-quarter, released before
            # the next bass. 76 sustains on CC64-aware renderers; it is not finger reach.
            for pulse in (0, 1.5, 3):
                pedals.extend([{'onset': round(start + pulse, 6), 'value': 0},
                               {'onset': round(start + pulse + .065, 6), 'value': 76},
                               {'onset': round(start + pulse + 1.44, 6), 'value': 0}])
            if number == 64:
                pedals = [p for p in pedals if p['onset'] < start]
                pedals.extend([{'onset': start, 'value': 0}, {'onset': start + .065, 'value': 76},
                               {'onset': start + 4.44, 'value': 0}])
    pedals.append({'onset': 64 * BEATS, 'value': 0})
    return {'id': 86, 'title': 'A Caravan of Broken Compasses', 'title_zh': '坏罗盘车队',
            'version': version, 'bars': bars,
            'events': sorted(events, key=lambda e: (e['onset'], e['pitch'], e['voice'])),
            'pedals': pedals, 'total_beats': 64 * BEATS, 'tail_seconds': TAIL}

def seconds_at(score, beat):
    result = 0.0
    for b in score['bars']:
        if beat <= b['start']: break
        result += min(b['beats'], beat - b['start']) * 60 / b['bpm']
    return result

def audit(score):
    es, bars = score['events'], score['bars']
    problems, overlaps, transfers, crossings = [], [], [], []
    spans = {}
    for hand in ('left', 'right'):
        ne = [e for e in es if e['hand'] == hand]
        worst = {'maximum_semitones': 0, 'at_beat': 0, 'maximum_simultaneous_keys': 0}
        groups = defaultdict(list)
        for e in ne: groups[e['onset']].append(e)
        times = sorted(groups)
        for t in times:
            held = [e for e in ne if e['onset'] - 1e-8 <= t < e['onset'] + e['duration'] - 1e-8]
            span = max(e['pitch'] for e in held) - min(e['pitch'] for e in held)
            if span > worst['maximum_semitones']: worst.update(maximum_semitones=span, at_beat=t)
            worst['maximum_simultaneous_keys'] = max(worst['maximum_simultaneous_keys'], len(held))
            if span > 12: problems.append({'kind': 'held_hand_span', 'hand': hand, 'beat': t, 'span': span})
        spans[hand] = worst
        for ta, tb in zip(times, times[1:]):
            old, new = groups[ta], groups[tb]
            center_a = (min(e['pitch'] for e in old) + max(e['pitch'] for e in old)) / 2
            center_b = (min(e['pitch'] for e in new) + max(e['pitch'] for e in new)) / 2
            move = abs(center_b - center_a)
            if move > 12:
                release = max(e['onset'] + e['duration'] for e in ne if e['onset'] <= ta)
                gap = seconds_at(score, tb) - seconds_at(score, release)
                required = .22 if move > 21 else .18 if move > 17 else .12
                item = {'hand': hand, 'from_beat': ta, 'to_beat': tb,
                        'grip_center_move_semitones': move, 'released_seconds': round(gap, 6),
                        'required_seconds': required}
                transfers.append(item)
                if gap < required - 1e-7: problems.append({'kind': 'wide_transfer', **item})
    for p in sorted({e['pitch'] for e in es}):
        active = []
        for e in sorted([e for e in es if e['pitch'] == p], key=lambda e: e['onset']):
            active = [a for a in active if a['onset'] + a['duration'] > e['onset'] + 1e-8]
            for a in active: overlaps.append({'pitch': p, 'first_bar': a['bar'], 'second_bar': e['bar'], 'at_beat': e['onset']})
            active.append(e)
    if overlaps: problems.append({'kind': 'same_key_overlap', 'count': len(overlaps)})
    for e in es:
        b = bars[e['bar'] - 1]
        if not (b['start'] <= e['onset'] < b['start'] + b['beats'] and e['duration'] > 0 and
                e['onset'] + e['duration'] <= score['total_beats'] + 1e-8 and 21 <= e['pitch'] <= 108 and
                1 <= e['velocity'] <= 127 and e['instrument'] == 'piano' and e['hand'] in ('left', 'right')):
            problems.append({'kind': 'event_schema_or_bounds', 'event': e})
    if not all(b['beats'] == BEATS and b['start'] == i * BEATS and b['bar'] == i + 1 and
               b['meter_numerator'] == 9 and b['meter_denominator'] == 8 and b['bpm'] > 0 for i, b in enumerate(bars)):
        problems.append({'kind': 'continuous_9_8_meter'})
    if score['pedals'][-1] != {'onset': score['total_beats'], 'value': 0}:
        problems.append({'kind': 'final_pedal_release'})
    for t in sorted({e['onset'] for e in es}):
        held = [e for e in es if e['onset'] <= t < e['onset'] + e['duration'] - 1e-8]
        left = [e['pitch'] for e in held if e['hand'] == 'left']
        right = [e['pitch'] for e in held if e['hand'] == 'right']
        if left and right and max(left) >= min(right): crossings.append({'beat': t, 'left_max': max(left), 'right_min': min(right)})
    if crossings: problems.append({'kind': 'hand_crossing', 'count': len(crossings)})
    support_nonchord, melody_downbeat, passing_audit = [], [], []
    mel = [e for e in es if e['voice'] == 'melody']
    for b in bars:
        pcs = {p % 12 for p in b['harmony']}
        notes = [e for e in es if e['bar'] == b['bar']]
        for e in notes:
            if e['voice'] != 'melody' and e['pitch'] % 12 not in pcs:
                if e.get('harmonic_function') != 'passing_neighbor': support_nonchord.append(e)
                else:
                    following = [n for n in es if n['voice'] == 'countermelody' and n['onset'] > e['onset']]
                    target = min(following, key=lambda n: n['onset']) if following else None
                    valid = bool(target and target['bar'] == e['bar'] and abs(target['pitch'] - e['pitch']) <= 2 and target['pitch'] % 12 in pcs)
                    passing_audit.append({'bar': e['bar'], 'beat': e['onset'], 'pitch': e['pitch'],
                                          'resolution_pitch': target['pitch'] if target else None, 'valid': valid})
                    if not valid: problems.append({'kind': 'unresolved_counter_nonchord', 'event': e})
            if e['voice'] == 'melody' and abs(e['onset'] - b['start']) < 1e-8 and e['pitch'] % 12 not in pcs:
                melody_downbeat.append(e)
    if support_nonchord: problems.append({'kind': 'unexplained_support_nonchord', 'events': support_nonchord})
    if melody_downbeat: problems.append({'kind': 'unexplained_melody_downbeat', 'events': melody_downbeat})
    phrases, signatures = [], []
    for i in range(8):
        bs = bars[i * 8:(i + 1) * 8]
        notes = [e for e in mel if i * 8 + 1 <= e['bar'] <= (i + 1) * 8]
        first, last = notes[0], notes[-1]
        anchor = first['pitch'] % 12 in {p % 12 for p in bs[0]['harmony']} and last['pitch'] % 12 in {p % 12 for p in bs[-1]['harmony']}
        if not anchor: problems.append({'kind': 'phrase_anchor', 'phrase': i + 1})
        signatures.append(tuple((e['onset'] - bs[0]['start'], e['duration'], e['pitch']) for e in notes))
        phrases.append({'phrase': i + 1, 'bars': [i * 8 + 1, (i + 1) * 8], 'section': bs[0]['section'],
                        'start_seconds': round(seconds_at(score, bs[0]['start']), 3),
                        'end_seconds': round(seconds_at(score, bs[-1]['start'] + BEATS), 3),
                        'melody_range': [min(e['pitch'] for e in notes), max(e['pitch'] for e in notes)],
                        'melody_note_count': len(notes), 'first_and_last_are_chord_tones': anchor,
                        'last_harmony': bs[-1]['harmony_name'], 'last_melody_pitch': last['pitch']})
    intervals = sorted((e['onset'], e['onset'] + e['duration']) for e in es)
    union = []
    for a, b in intervals:
        if union and a <= union[-1][1]: union[-1][1] = max(union[-1][1], b)
        else: union.append([a, b])
    gaps = [seconds_at(score, b[0]) - seconds_at(score, a[1]) for a, b in zip(union, union[1:])]
    duration = seconds_at(score, score['total_beats']) + score['tail_seconds']
    if not 180 <= duration <= 210: problems.append({'kind': 'duration', 'seconds': duration})
    lead_vel = statistics.median(e['velocity'] for e in mel)
    support_vel = statistics.median(e['velocity'] for e in es if e['voice'] != 'melody')
    if lead_vel - support_vel < 10: problems.append({'kind': 'insufficient_symbolic_lead_prominence'})
    leaps = [{'from_bar': a['bar'], 'to_bar': b['bar'], 'interval': abs(a['pitch'] - b['pitch'])}
             for a, b in zip(mel, mel[1:]) if abs(a['pitch'] - b['pitch']) > 9]
    return {'version': score['version'], 'passed': not problems, 'problems': problems,
            'bars': len(bars), 'note_events': len(es), 'melody_notes': len(mel), 'total_beats': score['total_beats'],
            'sounding_duration_seconds': round(duration - TAIL, 6), 'tail_seconds': TAIL,
            'total_duration_seconds': round(duration, 6), 'hand_spans': spans, 'wide_transfers': transfers,
            'same_key_overlap_count': len(overlaps), 'same_key_overlaps': overlaps,
            'hand_crossing_count': len(crossings), 'hand_crossings': crossings,
            'support_harmony_mismatch_count': len(support_nonchord), 'melody_downbeat_nonchord_count': len(melody_downbeat),
            'intentional_counter_passing_notes': passing_audit,
            'unique_eight_bar_melody_sentences': len(set(signatures)),
            'maximum_all_hands_key_release_gap_seconds': round(max(gaps, default=0), 6),
            'lead_median_velocity': lead_vel, 'support_median_velocity': support_vel,
            'melody_leaps_over_ninth_semitones': leaps, 'phrases': phrases,
            'limits': 'Symbolic feasibility and consistency only. No rendering or listening test has been run; no claim of musical beauty, convincing piano tone, or musical approval follows from a numerical pass. Pedal resonance is excluded from finger span.'}

def differences(a, b):
    changes, musical = [], []
    for ba, bb in zip(a['bars'], b['bars']):
        n = ba['bar']
        ea = [e for e in a['events'] if e['bar'] == n]
        eb = [e for e in b['events'] if e['bar'] == n]
        pa = [p for p in a['pedals'] if ba['start'] <= p['onset'] < ba['start'] + BEATS]
        pb = [p for p in b['pedals'] if bb['start'] <= p['onset'] < bb['start'] + BEATS]
        if ba != bb or ea != eb or pa != pb:
            changes.append({'bar': n, 'bar_before': ba, 'bar_after': bb,
                            'events_before': ea, 'events_after': eb, 'pedals_before': pa, 'pedals_after': pb})
        def signature(es): return [(e['onset'], e['duration'], e['pitch'], e['voice'], e['hand']) for e in es]
        if signature(ea) != signature(eb) or ba['harmony_name'] != bb['harmony_name']:
            musical.append(n)
    return {'from_version': a['version'], 'to_version': b['version'],
            'changed_bars': [c['bar'] for c in changes], 'structural_harmonic_or_note_changed_bars': musical,
            'note_event_count_before': len(a['events']), 'note_event_count_after': len(b['events']),
            'exact_changes': changes}

def dump(path, value): path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()

def main():
    scores, audits = {}, {}
    for version in ('v0', 'v1', 'v2'):
        scores[version] = make_score(version)
        audits[version] = audit(scores[version])
        dump(OUT / ('score_' + version + '.json'), scores[version])
        dump(OUT / ('audit_' + version + '.json'), audits[version])
    dump(OUT / 'score.json', scores['v2'])
    for a, b in (('v0', 'v1'), ('v1', 'v2')):
        dump(OUT / ('exact_diff_' + a + '_to_' + b + '.json'), differences(scores[a], scores[b]))
    manifest = {'algorithm': 'SHA-256', 'selected_score': 'score.json', 'selected_version': 'v2',
                'score_sha256': sha(OUT / 'score.json'), 'scope': 'Symbolic draft only; no audio or live-owner files modified.',
                'files': {p.name: sha(p) for p in sorted(OUT.iterdir()) if p.is_file() and p.name != 'hash_manifest.json' and p.suffix in ('.py', '.json', '.md', '.txt')}}
    dump(OUT / 'hash_manifest.json', manifest)
    for version, result in audits.items():
        print(version, 'PASS' if result['passed'] else 'FAIL', result['total_duration_seconds'], 'seconds,', result['note_events'], 'notes')
        if result['problems']: print(json.dumps(result['problems'], ensure_ascii=False, indent=2))
    print('score.json SHA-256', sha(OUT / 'score.json'))
    if not all(a['passed'] for a in audits.values()): raise SystemExit(1)

if __name__ == '__main__': main()
