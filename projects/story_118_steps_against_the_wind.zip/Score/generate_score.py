"""118 slow introduction followed by an uninterrupted, rhythmically rephrased ascent."""
from pathlib import Path
import json,sys,bisect
P=Path(__file__).resolve().parent;sys.path.insert(0,str(P));from composition_data import *
PARAM={'foot':('阶下先站稳',84,49),'stride':('找到七拍步幅',126,72),'turn':('迎风折返',138,83),'wind':('最后一段长坡',150,95),'sea':('越过平台看见海',140,86)}
def write(p,x):p.write_text(json.dumps(x,ensure_ascii=False,separators=(',',':'))+'\n')
def pitch(s):return 12*(int(s[-1])+1)+{'C':0,'D':2,'E':4,'F':5,'G':7,'A':9,'B':11}[s[0]]+s[1:-1].count('#')-s[1:-1].count('b')
def build(level):
 rows=[]
 for sec,hs,ls in GROUPS:assert len(hs.split())==len(ls),(sec,len(hs.split()),len(ls));rows.extend((sec,h,l) for h,l in zip(hs.split(),ls))
 assert len(rows)==56
 events=[];bars=[];pedals=[]
 for n,(sec,h,line) in enumerate(rows,1):
  if level>=1:line=REV1.get(n,line)
  if level>=2:line=REV2.get(n,line)
  label,bpm,dyn=PARAM[sec];ch=H[h];start=(n-1)*7
  if n>=53:bpm=108-4*(n-53);dyn=66-5*(n-53)
  bars.append(dict(bar=n,start=start,beats=7,bpm=bpm,meter='7/4',meter_numerator=7,meter_denominator=4,section=sec,section_title_zh=label,harmony_name=h,harmony=ch,key_region='B minor with E-major Dorian lifts; late B-major arrival'))
  def add(p,t,d,v,inst,voice,hand='none'):
   assert 0<=t<t+d<=7.00001,(n,t,d)
   events.append(dict(bar=n,onset=round(start+t,6),duration=round(d,6),pitch=p,velocity=int(v),instrument=inst,voice=voice,hand=hand))
  mel=[];at=0;tokens=line.split()
  for i,tok in enumerate(tokens):
   name,u=tok.split(':');dur=float(u)/2
   if name!='R':
    p=pitch(name);mel.append(p);add(p,at,dur-.08,dyn+(3 if at==0 and sec in ['stride','turn','wind'] else -5 if i==len(tokens)-1 else 0),'piano','ascent_subject','right')
   at+=dur
  assert at==7,(n,line,at)
  if sec=='foot':pat=[(0,ch[0],.85),(4,ch[2],.70)]
  elif sec=='stride':pat=[(0,ch[0],.45),(2,ch[2],.4),(4,ch[1],.42),(5.5,ch[2],.35),(6.5,ch[0]+12,.28)]
  elif sec=='turn':pat=[(0,ch[0],.4),(1,ch[1],.35),(2.5,ch[2],.35),(4,ch[0]+12,.4),(5.5,ch[2],.35),(6.5,ch[1],.28)]
  elif sec=='wind':pat=[(0,ch[0],.35),(1,ch[1],.30),(2,ch[2],.35),(3.5,ch[1],.3),(4.5,ch[0]+12,.3),(5.5,ch[2],.3),(6.5,ch[1],.28)]
  else:pat=[(0,ch[0],.6),(2,ch[2],.5),(4,ch[1],.6),(6,ch[0]+12,.65)]
  if level>=1 and 22<=n<=32:pat=[(.5,ch[2],.35),(2,ch[0],.45),(4.5,ch[1],.35),(6,ch[2],.6)] if n%2 else [(0,ch[0],.4),(1.5,ch[1],.4),(3.5,ch[2],.4),(5.5,ch[0]+12,.5)]
  if level>=2 and 38<=n<=46:pat=[(0,ch[0],.4),(2.5,ch[2],.35),(4,ch[1],.40),(5,ch[2],.40)]
  if level>=2 and n>=53:pat=[(0,ch[0],.7),(3,ch[2],.7),(5.5,ch[1],.7)] if n<56 else [(0,35,6.8)]
  for t,p,dur in pat:
   while p>=min(mel):p-=12
   add(p,t,dur,dyn-23,'piano','two_two_three_lower_steps','left')
  avail=[p for p in range(50,60) if p%12 in {x%12 for x in ch}];assert avail
  wind=[]
  if sec=='foot':wind={2:[55],4:[57],5:[52,55],6:[59],7:[58,54],8:[59]}.get(n,[])
  elif sec in ['stride','turn']:wind=[avail[-1],avail[0]] if n%3!=0 else []
  elif sec=='wind':wind=[avail[0],avail[-1],avail[0]] if n%2 else [avail[-1]]
  else:wind=[avail[-1],avail[0]] if n<53 else [avail[0]] if n in [53,54] else []
  if level>=1 and 22<=n<=32:wind=[avail[0]] if n%2 else [avail[-1],avail[0]]
  if level>=2 and 38<=n<=46:wind=[avail[-1]] if n in [38,40,43,45] else []
  if level>=2 and n>=53:wind=[52] if n==53 else [54] if n==54 else []
  onsets=[.65,3.1,5.5] if len(wind)==3 else [.65,4.25] if len(wind)==2 else [3.1]
  body=.38 if bpm>=145 else .42 if bpm>=130 else .48 if bpm>=120 else .64
  for t,p in zip(onsets,wind):add(p,t,body*bpm/60,48 if sec=='foot' or n>=53 else 67 if sec=='wind' else 60,'cello','bowed_step_answer')
  pedals.append(dict(bar=n,onset=start,controller=64,value=0,instrument='piano'))
  if sec=='foot' or n>=53:pedals.extend([dict(bar=n,onset=start+.08,controller=64,value=25,instrument='piano'),dict(bar=n,onset=start+2.8,controller=64,value=0,instrument='piano')])
 events.sort(key=lambda e:(e['onset'],e['instrument'],e['pitch']))
 for i,e in enumerate(events):e['event_id']=f'118-v{level}-{i}'
 return dict(id=118,title='Steps against the Wind',title_zh='逆风长阶',version=f'v{level}',bars=bars,events=events,pedals=pedals,total_beats=392,tail_seconds=5,instrument_map={'piano':'piano','cello':'arco'},performance_contract='A slow opening and continuous rhythmic climb; genuine pp/mf separated short-bow cello, no legato or human-listening claim.')
def proj(d,n):return {'bar':d['bars'][n-1],'events':[{k:v for k,v in e.items() if k!='event_id'} for e in d['events'] if e['bar']==n],'pedals':[e for e in d['pedals'] if e['bar']==n]}
for v in range(3):
 d=build(v);write(P/f'score_v{v}.json',d);report={'version':f'v{v}','bars':56,'events':len(d['events']),'duration_seconds':sum(b['beats']*60/b['bpm'] for b in d['bars'])+5,'human_listening_review':False};write(P/f'audit_v{v}.json',report)
 if v:
  a=build(v-1);changes=[{'bar':n,'before':proj(a,n),'after':proj(d,n)} for n in range(1,57) if proj(a,n)!=proj(d,n)];write(P/f'exact_diff_v{v-1}_to_v{v}.json',{'count':len(changes),'changed_bars':[x['bar'] for x in changes],'comparison_excludes':['version','event_id'],'changes':changes});lines=[]
  for x in changes:
   lines.append(f"BAR {x['bar']}\n")
   for side in ['before','after']:
    q=x[side];lines.append(side+' '+q['bar']['harmony_name']+' '+str([(e['instrument'],e['voice'],e['onset'],e['pitch'],e['duration'],e['velocity']) for e in q['events']])+'\n')
  (P/f'exact_diff_v{v-1}_to_v{v}.patch').write_text(''.join(lines))
write(P/'score.json',d);starts=[b['start'] for b in d['bars']];times=[];t=0
for b in d['bars']:times.append(t);t+=b['beats']*60/b['bpm']
def sec(t):
 i=max(0,bisect.bisect_right(starts,t)-1);return times[i]+(t-starts[i])*60/d['bars'][i]['bpm']
def beat(t):
 i=max(0,bisect.bisect_right(times,t)-1);return starts[i]+(t-times[i])*d['bars'][i]['bpm']/60
mp=P.parent/'assets/iowa_cello_arco_D3_B3/mapping_manifest.json';lat={(x['layer'],x['midi']):x['coarse_voiced_delay_after_tuning_seconds'] for x in json.loads(mp.read_text())['files']};alignment=[]
for e in d['events']:
 if e['instrument']!='cello':continue
 layer='pp' if e['velocity']<=55 else 'mf';target=sec(e['onset']);end=sec(e['onset']+e['duration']);delay=lat[layer,e['pitch']];trigger=target-delay;assert trigger>=0;e['nominal_onset']=e['onset'];e['onset']=beat(trigger);e['duration']=beat(end)-e['onset'];e['layer']=layer;e['attack_compensated_once']=True;assert .30<=end-target and end-trigger<=1.15;alignment.append(dict(event_id=e['event_id'],target_seconds=target,trigger_seconds=trigger,delay_seconds=delay,gate_seconds=end-trigger,layer=layer))
w=sorted([e for e in d['events'] if e['instrument']=='cello'],key=lambda e:e['onset']);gaps=[sec(b['onset'])-sec(a['onset']+a['duration']) for a,b in zip(w,w[1:])];assert min(gaps)>=.14,min(gaps)
write(P/'ensemble_score.json',d)
for inst in ['piano','cello']:write(P/f'{inst}_score.json',{**d,'events':[e for e in d['events'] if e['instrument']==inst],'pedals':d['pedals'] if inst=='piano' else []})
write(P/'revisions/cello_attack_alignment.json',{'method':'Once-only recorded voiced-onset timing compensation; real pp/mf separated short-bow notes','events':alignment,'minimum_after_compensation_gap_seconds':min(gaps)});print(json.dumps({**report,'cello_min_gap_seconds':min(gaps)}))
