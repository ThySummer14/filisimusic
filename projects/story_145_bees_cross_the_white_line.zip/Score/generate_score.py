"""Local, dependency-free nominal-score writer and symbolic checker. No audio work."""
from pathlib import Path
import json, math, hashlib, difflib, importlib.util
from collections import Counter, defaultdict
P=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('piece_data',P/'composition_data.py');data=importlib.util.module_from_spec(spec);spec.loader.exec_module(data)

def canonical(x):return json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':'))

def sample_trigger_gap_audit(s):
 # Independent of the authored layout: integrate the actual full tempo map.
 # Check every adjacent event, including phrase/section/bar boundaries.
 def seconds_at(t):
  return sum(max(0,min(t-b['start'],b['beats']))*60/b['bpm'] for b in s['bars'] if t>b['start'])
 instruments={};violations=[]
 for inst,delays in data.SAMPLE_ONSET_DELAY_SECONDS.items():
  ee=sorted((e for e in s['events'] if e['instrument']==inst and (inst!='cello' or e.get('articulation')=='short_bow')),key=lambda e:e['onset'])
  if not ee:continue
  pairs=[]
  for a,b in zip(ee,ee[1:]):
   layer='pp' if b['velocity']<=55 else 'mf';delay=delays[(layer,b['pitch'])]
   nominal_gap=seconds_at(b['onset'])-seconds_at(a['onset']+a['duration'])
   trigger_gap=nominal_gap-delay
   pair=dict(previous_event_id=a.get('event_id'),next_event_id=b.get('event_id'),previous_bar=a['bar'],next_bar=b['bar'],next_pitch=b['pitch'],next_velocity=b['velocity'],next_layer=layer,previous_nominal_off_seconds=seconds_at(a['onset']+a['duration']),next_nominal_onset_seconds=seconds_at(b['onset']),nominal_gap_seconds=nominal_gap,next_sample_delay_seconds=delay,required_nominal_gap_seconds=delay+.14,after_comp_trigger_gap_seconds=trigger_gap,passed=trigger_gap>=.14)
   pairs.append(pair)
   if not pair['passed']:violations.append(dict(instrument=inst,**pair))
  instruments[inst]=dict(event_count=len(ee),adjacent_pair_count=len(pairs),cross_bar_pair_count=sum(p['previous_bar']!=p['next_bar'] for p in pairs),minimum_after_comp_trigger_gap_seconds=min((p['after_comp_trigger_gap_seconds'] for p in pairs),default=None),pairs=pairs)
 return dict(id=s['id'],version=s['version'],passed=not violations,required_minimum_seconds=.14,velocity_layer_rule='pp at velocity <=55, otherwise mf',formula='next nominal onset seconds - next pitch/layer sample delay - previous nominal off seconds',sample_manifest_provenance=data.SAMPLE_DELAY_PROVENANCE,instruments=instruments,violations=violations,scope='Read-only symbolic prediction from supplied sample-delay measurements; all score onsets remain nominal. Clarinet has no delay in the supplied manifest and is checked separately for nominal breathing. No audio render or listening review.')

def validate(s):
 errors=[]; bars={b['bar']:b for b in s['bars']}; voices=defaultdict(list); instruments=Counter();mx=0
 pos=0
 for b in s['bars']:
  if abs(b['start']-pos)>1e-6:errors.append(f"bar {b['bar']} discontinuous")
  pos+=b['beats']
 for e in s['events']:
  b=bars[e['bar']];p=e['pitch'];inst=e['instrument'];instruments[inst]+=1
  if not isinstance(p,int) or not 21<=p<=108:errors.append(f'bad pitch {e}')
  if not b['start']-1e-7<=e['onset']<e['onset']+e['duration']<=b['start']+b['beats']+1e-7:errors.append(f'out of bar {e}')
  if not 1<=e['velocity']<=127:errors.append(f'velocity {e}')
  if inst=='clarinet' and not 60<=p<=71:errors.append(f'clarinet range {e}')
  if inst=='flute' and not 72<=p<=83:errors.append(f'flute range {e}')
  if inst=='cello' and not (36<=p<=47 and e.get('articulation')=='pizzicato' or 50<=p<=59 and e.get('articulation')=='short_bow'):errors.append(f'cello range/articulation {e}')
  if e['hand'] not in (['left','right'] if inst=='piano' else ['none']):errors.append(f'hand {e}')
  if inst!='piano':voices[inst].append(e)
 for inst,ee in voices.items():
  ee.sort(key=lambda e:e['onset'])
  for a,b in zip(ee,ee[1:]):
   if a['onset']+a['duration']>b['onset']+1e-6:errors.append(f'{inst} simultaneous/overlap b{a["bar"]}-b{b["bar"]}')
  # Piece-specific staggered winds and separated cello attacks must all articulate.
  for e in ee:
   seconds=e['duration']*60/bars[e['bar']]['bpm']
   if inst in ('flute','clarinet') and seconds>1.6:errors.append(f'{inst} overlong sampled note b{e["bar"]}')
   if inst=='cello' and e['articulation']=='short_bow' and not .35-1e-5<=seconds<=.9+1e-5:errors.append(f'cello short bow duration b{e["bar"]}')
   if inst=='cello' and e['articulation']=='pizzicato' and not .3-1e-5<=seconds<=.8+1e-5:errors.append(f'cello pizz duration b{e["bar"]}')
 # Integrate tempo for physical bow gaps rather than treating beats as seconds.
 def seconds_at(t):
  return sum(max(0,min(t-b['start'],b['beats']))*60/b['bpm'] for b in s['bars'] if t>b['start'])
 sample_audit=sample_trigger_gap_audit(s)
 for violation in sample_audit['violations']:errors.append(f"sample trigger gap below .14 seconds: {violation}")
 wind_gaps={}
 for wind in ('clarinet','flute'):
  ww=voices.get(wind,[])
  gaps=[seconds_at(b['onset'])-seconds_at(a['onset']+a['duration']) for a,b in zip(ww,ww[1:])]
  if gaps:wind_gaps[wind]=round(min(gaps),6)
  if gaps and min(gaps)<.14-1e-5:errors.append(f'{wind} breath gap below .14 seconds')
  for e in ww:
   if e['duration']*60/bars[e['bar']]['bpm']<.24-1e-5:errors.append(f'{wind} gate below .24 seconds')
 for a,b in zip(voices.get('cello',[]),voices.get('cello',[])[1:]):
  if a.get('articulation')=='short_bow' and seconds_at(b['onset'])-seconds_at(a['onset']+a['duration'])<.2-1e-5:errors.append(f'cello bow gap b{a["bar"]}-b{b["bar"]}')
 if s['total_beats']!=pos:errors.append('total beats differs')
 pedals=s['pedals']
 for p in pedals:
  if p.get('controller')!=64 or not 0<=p['value']<=127:errors.append('pedal schema')
 for b in s['bars']:
  if abs(b['beats']-b['meter_numerator']*4/b['meter_denominator'])>1e-7:errors.append(f'meter units b{b["bar"]}')
 if not pedals or pedals[-1]['value']!=0:errors.append('no final pedal release')
 secs=sum(b['beats']*60/b['bpm'] for b in s['bars'])+s['tail_seconds']
 if not 180<=secs<=240:errors.append(f'duration outside 3–4min: {secs}')
 for hand in ('left','right'):
  attacks=defaultdict(list)
  for e in s['events']:
   if e['instrument']=='piano' and e['hand']==hand:attacks[e['onset']].append(e['pitch'])
  for t,pp in attacks.items():
   if max(pp)-min(pp)>12:errors.append(f'wide simultaneous {hand} span {max(pp)-min(pp)} at {t}')
 # All piano voices share keys. Check overlap independent of voice labels.
 keys=defaultdict(list)
 for e in s['events']:
  if e['instrument']=='piano':keys[e['pitch']].append(e)
 for p,ee in keys.items():
  ee.sort(key=lambda e:e['onset'])
  for a,b in zip(ee,ee[1:]):
   if a['onset']+a['duration']>b['onset']+1e-7:errors.append(f'piano same-key overlap pitch {p} at {b["onset"]}')
 # Check all concurrently held notes, including earlier attacks, separately by hand.
 for hand in ('left','right'):
  ee=[e for e in s['events'] if e['instrument']=='piano' and e['hand']==hand]
  moments=sorted(set(e['onset'] for e in ee))
  for t in moments:
   held=[e['pitch'] for e in ee if e['onset']<=t+1e-8 and e['onset']+e['duration']>t+1e-7]
   if held:mx=max(mx,max(held)-min(held))
   if held and max(held)-min(held)>12:errors.append(f'piano active {hand} hand span {max(held)-min(held)} at {t}')
 return dict(id=s['id'],version=s['version'],sample_trigger_gap_passed=sample_audit['passed'],minimum_sample_trigger_gap_seconds={k:v['minimum_after_comp_trigger_gap_seconds'] for k,v in sample_audit['instruments'].items()},woodwind_minimum_gap_seconds=wind_gaps,pass_all_symbolic_checks=not errors,errors=errors,bars=len(bars),events=len(s['events']),instruments=dict(instruments),duration_seconds=round(secs,3),nominal_total_beats=pos,pitch_ranges={i:[min(e['pitch'] for e in s['events'] if e['instrument']==i),max(e['pitch'] for e in s['events'] if e['instrument']==i)] for i in instruments},cross_bar_note_overlap=False,piano_same_key_overlap=False,piano_active_hand_span_limit_semitones=12,piano_active_hand_span_max_semitones=mx,final_pedal_released=True,audio_rendered=False,human_listening_review=False,review_scope='Symbolic validity only. Does not certify musical listening quality or sampled audio timing.')

def stripped(s,n):return {'bar':s['bars'][n-1], 'events':[{k:v for k,v in e.items() if k not in ('event_id','version')} for e in s['events'] if e['bar']==n], 'pedals':[e for e in s['pedals'] if e['bar']==n]}
all_scores=[];revision_counts={}
for level in range(3):
 s=data.build(level);s['events'].sort(key=lambda e:(e['onset'],e['instrument'],e['pitch']))
 for i,e in enumerate(s['events']):e['event_id']=f'{s["id"]}-v{level}-{i:05d}'
 s['pedals'].sort(key=lambda e:e['onset']);s['performance_contract']='Original nominal sample-based instrumental score; not a live performance. No audio rendered or listening approval claimed in this package. Recording onset compensation belongs to the main renderer.'
 all_scores.append(s)
 (P/f'score_v{level}.json').write_text(json.dumps(s,ensure_ascii=False,indent=2)+'\n')
 (P/f'sample_trigger_gap_audit_v{level}.json').write_text(json.dumps(sample_trigger_gap_audit(s),ensure_ascii=False,indent=2)+'\n')
 report=validate(s);(P/f'validation_v{level}.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
 assert report['pass_all_symbolic_checks'],report['errors'][:20]
for k in (1,2):
 old,new=all_scores[k-1:k+1];changes=[]
 for n in range(1,len(new['bars'])+1):
  a,b=stripped(old,n),stripped(new,n)
  if canonical(a)!=canonical(b):
   ca=Counter(canonical(e) for e in a['events']);cb=Counter(canonical(e) for e in b['events'])
   changes.append({'bar':n,'section':b['bar']['section'],'harmony_before':a['bar']['harmony_name'],'harmony_after':b['bar']['harmony_name'],'notes_removed':sum((ca-cb).values()),'notes_added':sum((cb-ca).values()),'before':a,'after':b})
 (P/f'exact_diff_v{k-1}_to_v{k}.json').write_text(json.dumps({'changed_bars':[x['bar'] for x in changes],'bar_count':len(changes),'evidence':changes},ensure_ascii=False,indent=2)+'\n')
 revision_counts[f'v{k-1}_to_v{k}']=dict(changed_bars=[x['bar'] for x in changes],bar_count=len(changes))
 assert len(changes)>=8
(P/'score.json').write_text((P/'score_v2.json').read_text())
files=['composition_data.py','generate_score.py','story_zh.txt','revision_notes.md','independent_verify.py']+[f'score_v{i}.json' for i in range(3)]+[f'validation_v{i}.json' for i in range(3)]+['score.json','exact_diff_v0_to_v1.json','exact_diff_v1_to_v2.json']
files += [f'sample_trigger_gap_audit_v{i}.json' for i in range(3)]
hashes={f:hashlib.sha256((P/f).read_bytes()).hexdigest() for f in files if (P/f).exists()};(P/'hashes.json').write_text(json.dumps(hashes,indent=2)+'\n')
(P/'READY_FOR_REVIEW.json').write_text(json.dumps(dict(id=data.ID,title=data.TITLE,title_zh=data.TITLE_ZH,status='nominal_score_ready',final_score='score_v2.json',self_contained_rebuild='python generate_score.py',audio_rendered=False,nominal_onsets_no_sample_compensation=True,symbolic_validation='validation_v2.json',human_listening_review=False,duration_seconds=validate(all_scores[-1])['duration_seconds'],versions=['v0','v1','v2'],revision_evidence=['exact_diff_v0_to_v1.json','exact_diff_v1_to_v2.json'],renderer_notes=data.RENDERER_NOTES,actual_revision_counts=revision_counts,nominal_rest_layout_repair=dict(changed_bars_by_version={s['version']:sorted({e['bar'] for e in s['nominal_rest_layout_edits']}) for s in all_scores},changed_event_count_by_version={s['version']:len(s['nominal_rest_layout_edits']) for s in all_scores},pitches_velocities_durations_preserved=True,events_added_or_removed=0,minimum_required_after_comp_trigger_gap_seconds=.14,audit_files=[f'sample_trigger_gap_audit_v{i}.json' for i in range(3)],before_snapshot='nominal_trigger_gap_repair/before',exact_repair_diff='nominal_trigger_gap_repair/exact_before_after.json')),ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in validate(all_scores[-1]).items() if k not in ('review_scope','errors')},ensure_ascii=False))
