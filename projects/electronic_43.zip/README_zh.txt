逆流灯塔 / Upstream Beacon

这是可再生成的 REAPER 工程源文件包，包含完整音符谱面、逐轨 MIDI、RPP、原创合成器代码及完整版本修订记录。为控制体积，不包含音频分轨，首次打开前需要生成。

依赖：Python 3、NumPy、SciPy、FFmpeg。需要自动混音时另外安装官方 REAPER，并把 REAPER_BIN 环境变量设为其可执行文件路径。未附带 REAPER 或任何付费插件。

在本目录运行：
python render_score.py score.json . --no-reaper
随后用 REAPER 打开 electronic_43.rpp。若已设置 REAPER_BIN，去掉 --no-reaper 可执行实际离线混音。

修改 score.json 中的音高、拍点、时值、力度与分轨参数，再生成即可得到自己的编辑版本。midi 文件夹保留逐轨 MIDI。versions 保留初稿、至少两轮实质修订及已有的后续修正。

创作和编配由 AI 辅助完成。声音为原创程序合成，无真人演奏或真实声学录音，也未使用第三方采样。原始交付版本均经过真实 REAPER 离线导出；记录包括谱面检查及数字 PCM 核验，没有可确认的人工听音评审。

已去除私有账号标识、存储链接、运行日志及工作机绝对路径。此包未声明开放源代码或音乐再授权许可证。
