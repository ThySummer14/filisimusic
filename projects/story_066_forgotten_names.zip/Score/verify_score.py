#!/usr/bin/env python3
"""Independent JSON readback checks; does not import the composition script."""
import json
import hashlib
from pathlib import Path
from collections import defaultdict, Counter
from math import isclose

P=Path(__file__).resolve().parent

def readback(name):
    s=json.loads((P/name).read_text(encoding='utf-8'))
    errs=[]
    def check(cond,msg):
        if not cond: errs.append(msg)
    check(set(s)=={'id','title','title_zh','bars','events','pedals','total_beats','tail_seconds'},'top schema')
    check(s['id']==66 and s['total_beats']==288 and s['tail_seconds']==4,'identity/duration header')
    bars=s['bars']; ev=s['events']
    check(len(bars)==72,'bar count')
    by_bar={b['bar']:b for b in bars}
    def sec(t):
        return sum(max(0,min(t-b['start'],b['beats']))*60/b['bpm'] for b in bars)
    for n,b in enumerate(bars,1):
        check(set(b)=={'bar','start','beats','bpm','section','meter_numerator','meter_denominator','harmony_name','harmony','role_plan','lead_instrument'},f'bar {n} schema')
        check(b['bar']==n and b['start']==4*(n-1) and b['beats']==4,f'bar {n} timeline')
        check(b['meter_numerator']==b['meter_denominator']==4 and b['bpm']>0 and b['lead_instrument']=='piano',f'bar {n} values')
    for n,e in enumerate(ev):
        check(set(e)=={'bar','onset','duration','pitch','velocity','voice','instrument'},f'event {n} schema')
        check(e['instrument'] in ['piano','cello'],f'event {n} instrument')
        check(0<=e['pitch']<=127 and 1<=e['velocity']<=127 and e['duration']>0,f'event {n} domain')
        b=by_bar[e['bar']]
        check(b['start']-1e-7<=e['onset'] and e['onset']+e['duration']<=b['start']+b['beats']+1e-7,f'event {n} bar bounds')
        check((e['instrument']=='cello' and e['voice']=='cello_bass') or
              (e['instrument']=='piano' and e['voice'] in ['melody','upper_support','bass','accompaniment']),f'event {n} role')
    def sounding(e,t): return e['onset']<=t+1e-7 and e['onset']+e['duration']>t+1e-7
    def overlap(a,b): return max(a['onset'],b['onset'])<min(a['onset']+a['duration'],b['onset']+b['duration'])-1e-7
    piano=[e for e in ev if e['instrument']=='piano']; cello=sorted([e for e in ev if e['instrument']=='cello'],key=lambda e:e['onset'])
    times=sorted(set([e['onset'] for e in piano]+[e['onset']+e['duration'] for e in piano]))
    hand_max={'right':0,'left':0}; hand_keys={'right':0,'left':0}; crossing=[]
    for t in times:
        RH=[e for e in piano if e['voice'] in ['melody','upper_support'] and sounding(e,t)]
        LH=[e for e in piano if e['voice'] in ['bass','accompaniment'] and sounding(e,t)]
        for h,notes in [('right',RH),('left',LH)]:
            pitches=[e['pitch'] for e in notes]
            if pitches: hand_max[h]=max(hand_max[h],max(pitches)-min(pitches))
            hand_keys[h]=max(hand_keys[h],len(notes))
        if RH and LH and min(e['pitch'] for e in RH)<=max(e['pitch'] for e in LH): crossing.append(t)
    check(hand_max['right']<=10 and hand_max['left']<=12,'piano spans')
    check(max(hand_keys.values())<=5,'piano active keys')
    check(not crossing,'hand crossing or same active pitch')
    collisions=[]
    grouped=defaultdict(list)
    for e in ev: grouped[(e['instrument'],e['pitch'])].append(e)
    for key,ns in grouped.items():
        ns.sort(key=lambda e:e['onset'])
        for i,a in enumerate(ns):
            for b in ns[i+1:]:
                if b['onset']>=a['onset']+a['duration']-1e-7: break
                if overlap(a,b): collisions.append([a,b])
    check(not collisions,'same-instrument same-key overlap')
    csecs=[]; cgaps=[]
    for e in cello:
        d=sec(e['onset']+e['duration'])-sec(e['onset']); csecs.append(d)
        check(36<=e['pitch']<=47,'cello range')
        check(e['pitch'] in by_bar[e['bar']]['harmony'],'cello harmony membership')
        check(.35-1e-6<=d<=.75+1e-6,'cello duration seconds')
    for a,b in zip(cello,cello[1:]):
        check(not overlap(a,b),'cello overlap')
        cgaps.append(sec(b['onset'])-sec(a['onset']+a['duration']))
    low=[e for e in piano if e['voice']=='bass']
    check(not any(overlap(a,b) for a in low for b in cello),'redundant low bass overlap')
    comp=[e for e in piano if e['voice']=='accompaniment']
    check(all(e['pitch'] in by_bar[e['bar']]['harmony'] for e in comp),'comping harmony membership')
    mel=sorted([e for e in piano if e['voice']=='melody'],key=lambda e:e['onset'])
    check(all(not overlap(a,b) for a,b in zip(mel,mel[1:])),'melody monophony')
    onsets=set(round(e['onset'],6) for e in mel)
    swing=sum(1 for t in onsets if abs(t-round(t))<1e-6 and round(t+2/3,6) in onsets and round(t+1,6) in onsets)
    check(swing>=35,'actual swing onset groups')
    check(all(set(p)=={'onset','value'} and 0<=p['value']<=63 and 0<=p['onset']<=288 for p in s['pedals']),'pedal schema')
    check(s['pedals'][-1]=={'onset':288,'value':0},'final pedal release')
    return {'file':name,'status':'PASS' if not errs else 'FAIL','errors':errs,
            'score_seconds':round(sec(288),6),'with_tail_seconds':round(sec(288)+4,6),
            'event_count':len(ev),'voice_counts':dict(Counter(e['voice'] for e in ev)),
            'actual_hand_spans':hand_max,'max_keys_by_hand':hand_keys,'hand_crossing_count':len(crossing),
            'key_collision_count':len(collisions),'cello_gate_seconds':[round(min(csecs),6),round(max(csecs),6)],
            'cello_min_gap_seconds':round(min(cgaps),6),'actual_swing_cells':swing,
            'sha256':hashlib.sha256((P/name).read_bytes()).hexdigest()}

def main():
    reports=[readback(f'score_v{i}.json') for i in range(3)]
    out={'status':'PASS' if all(x['status']=='PASS' for x in reports) else 'FAIL','method':'Independent JSON readback; no composition-module imports; no audio.',
         'versions':reports,'final_alias_exact_match':(P/'score.json').read_bytes()==(P/'score_v2.json').read_bytes()}
    (P/'validation_readback.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(out,ensure_ascii=False,indent=2))
    if out['status']!='PASS' or not out['final_alias_exact_match']: raise SystemExit(1)
if __name__=='__main__':main()
